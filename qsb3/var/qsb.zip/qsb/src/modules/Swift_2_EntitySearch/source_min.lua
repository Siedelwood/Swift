SCP.EntitySearch={}
ModuleEntitySearch={Properties={Name="ModuleEntitySearch"},Global={},Local={},Shared={}}function ModuleEntitySearch.Global:OnGameStart()end;function ModuleEntitySearch.Global:OnEvent(QDnlt,LmcA2auZ,...)
end
function ModuleEntitySearch.Local:OnGameStart()end;function ModuleEntitySearch.Local:OnEvent(Q,ZA,...)end
function ModuleEntitySearch.Shared:IterateEntities(...)
local _IQQ={}
if arg[1]then for pVRj=1,#arg[1]do local fuZ3z86=table.remove(arg[1][pVRj],1)
table.insert(_IQQ,{fuZ3z86,arg[1][pVRj]})end end;local XpkjA={}
for er,DFb100j in pairs(Entities)do
local XL_=Logic.GetEntitiesOfType(DFb100j)
for WYdR=1,#XL_ do local QKKks_zt=true;for Are7xU=1,#_IQQ do
if not
_IQQ[Are7xU][1](XL_[WYdR],unpack(_IQQ[Are7xU][2]))then QKKks_zt=false;break end end;if QKKks_zt then
table.insert(XpkjA,XL_[WYdR])end end end;return XpkjA end;QSB.SearchPredicate={}QSB.SearchPredicate.Custom=function(yxjl,ZG,...)
return ZG(yxjl,unpack(arg))end
QSB.SearchPredicate.OfID=function(Vu0cCAf,...)
for q=1,
#arg do if Vu0cCAf==arg[q]then return true end end;return false end
QSB.SearchPredicate.OfPlayer=function(kP7O5,...)
for lqT=1,#arg do if
Logic.EntityGetPlayer(kP7O5)==arg[lqT]then return true end end;return false end
QSB.SearchPredicate.OfName=function(mP3mlD,...)
for PrPyxMK=1,#arg do if
Logic.GetEntityName(mP3mlD)==arg[PrPyxMK]then return true end end;return false end
QSB.SearchPredicate.OfNamePrefix=function(tczrIB,...)local a=Logic.GetEntityName(tczrIB)
for wqU76o=1,#arg
do if a and a~=""then
if a:find("^"..arg[wqU76o])~=nil then return true end end end;return false end
QSB.SearchPredicate.OfNameSuffix=function(LB1Z,...)local N9L=Logic.GetEntityName(LB1Z)
for hDc_M=1,#arg do if
N9L and N9L~=""then
if N9L:find(arg[hDc_M].."$")~=nil then return true end end end;return false end
QSB.SearchPredicate.OfType=function(qW0lRiD1,...)
for iD1IUx=1,#arg do if
Logic.GetEntityType(qW0lRiD1)==arg[iD1IUx]then return true end end;return false end
QSB.SearchPredicate.OfCategory=function(JLCOx_ak,...)
for hPQ=1,#arg do if
Logic.IsEntityInCategory(JLCOx_ak,arg[hPQ])==1 then return true end end;return false end
QSB.SearchPredicate.InArea=function(R1FIoQI,...)for NsoTwDs=1,#arg,3 do
if
API.GetDistance(R1FIoQI,{X=arg[NsoTwDs],Y=arg[NsoTwDs+1]})<=arg[NsoTwDs+2]then return true end end;return false end
QSB.SearchPredicate.InTerritory=function(HGli,...)
for iy=1,#arg do if
GetTerritoryUnderEntity(HGli)==arg[iy]then return true end end;return false end;QSB.SearchPredicate.IsBuilding=function(m6SCS0)
return Logic.IsBuilding(m6SCS0)==1 end
QSB.SearchPredicate.IsFinishedBuilding=function(NUhYw6R4)
return
Logic.IsBuilding(NUhYw6R4)==1 and
Logic.IsConstructionComplete(NUhYw6R4)==1 end
QSB.SearchPredicate.IsSettler=function(Hv)return Logic.IsSettler(Hv)==1 end;Swift:RegisterModule(ModuleEntitySearch)