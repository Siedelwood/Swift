
function Swift:InitalizeBugfixesGlobal()self:AddResourceSlotsToStorehouses()end;function Swift:GlobalRestoreBugfixesAfterLoad()end
function Swift:AddResourceSlotsToStorehouses()
for QDnlt=1,8 do
local LmcA2auZ=Logic.GetStoreHouse(QDnlt)if LmcA2auZ~=0 then
Logic.AddGoodToStock(LmcA2auZ,Goods.G_Salt,0,true,true)
Logic.AddGoodToStock(LmcA2auZ,Goods.G_Dye,0,true,true)end end end;function Swift:InitalizeBugfixesLocal()end
function Swift:LocalRestoreBugfixesAfterLoad()end