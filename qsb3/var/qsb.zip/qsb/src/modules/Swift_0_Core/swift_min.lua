API=API or{}QSB=QSB or{}SCP=SCP or{Core={}}
QSB.Version="Version 3.0.0 BETA (1.1.16)"QSB.Language="de"QSB.HumanPlayerID=1;QSB.ScriptCommandSequence=2
QSB.ScriptCommands={}QSB.ScriptEvents={}QSB.CustomVariable={}Swift=Swift or{}
ParameterType=ParameterType or{}g_QuestBehaviorVersion=1;g_QuestBehaviorTypes={}g_GameExtraNo=0
if Framework then
g_GameExtraNo=Framework.GetGameExtraNo()elseif MapEditor then g_GameExtraNo=MapEditor.GetGameExtraNo()end
Swift={m_ModuleRegister={},m_BehaviorRegister={},m_ScriptEventRegister={},m_ScriptEventListener={},m_ScriptCommandRegister={},m_AIProperties={},m_Language="de",m_Environment="global",m_ProcessDebugCommands=false,m_NoQuicksaveConditions={},m_LogLevel=2,m_FileLogLevel=3}
function Swift:LoadCore()self:OverrideString()self:OverrideTable()
self:DetectEnvironment()self:DetectLanguage()
if self:IsGlobalEnvironment()then
self:InitalizeDebugModeGlobal()self:InitalizeScriptCommands()
self:InitalizeEventsGlobal()self:InitalizeAIVariables()
self:InstallBehaviorGlobal()self:OverrideQuestSystemGlobal()
self:InitalizeCallbackGlobal()self:OverrideOnMPGameStart()
self:DisableLogicFestival()self:InitalizeBugfixesGlobal()end
if self:IsLocalEnvironment()then self:InitalizeDebugModeLocal()
self:InitalizeEventsLocal()self:InstallBehaviorLocal()
self:OverrideDoQuicksave()self:AlterQuickSaveHotkey()
self:InitalizeCallbackLocal()self:ValidateTerritories()
self:InitalizeBugfixesLocal()if not Framework.IsNetworkGame()then local QDnlt=GUI.GetPlayerID()GUI.SendScriptCommand(
"QSB.HumanPlayerID = "..QDnlt)
QSB.HumanPlayerID=QDnlt end
StartSimpleHiResJob("Swift_EventJob_WaitForLoadScreenHidden")end;self:LoadExternFiles()self:LoadBehaviors()
if
self:IsLocalEnvironment()then
StartSimpleJobEx(function()
if Logic.GetTime()>1 then
for LmcA2auZ,Q in pairs(g_TexturePositions)do for ZA,_IQQ in pairs(Q)do
Swift:DispatchScriptCommand(QSB.ScriptCommands.UpdateTexturePosition,GUI.GetPlayerID(),LmcA2auZ,ZA,_IQQ)end end;return true end end)end end
function Swift:LoadModules()
for XpkjA=1,#self.m_ModuleRegister,1 do
if self:IsGlobalEnvironment()then self.m_ModuleRegister[XpkjA]["Local"]=
nil;if
self.m_ModuleRegister[XpkjA]["Global"].OnGameStart then
self.m_ModuleRegister[XpkjA]["Global"]:OnGameStart()end end
if self:IsLocalEnvironment()then self.m_ModuleRegister[XpkjA]["Global"]=
nil;if
self.m_ModuleRegister[XpkjA]["Local"].OnGameStart then
self.m_ModuleRegister[XpkjA]["Local"]:OnGameStart()end end end end
function Swift:RegisterModule(pVRj)if(type(pVRj)~="table")then
assert(false,"Modules must be tables!")return end;if pVRj.Properties==nil or
pVRj.Properties.Name==nil then
assert(false,"Expected name for Module!")return end
table.insert(self.m_ModuleRegister,pVRj)end
function Swift:IsModuleRegistered(fuZ3z86)for er,DFb100j in pairs(self.m_ModuleRegister)do
return DFb100j.Properties and
DFb100j.Properties.Name==fuZ3z86 end end
function Swift:CreateRandomSeed()local XL_=0;local WYdR=Framework.GetCurrentMapName()
local QKKks_zt=Framework.GetCurrentMapTypeAndCampaignName()local Are7xU=Framework.GetMapGUID(WYdR,QKKks_zt)
for yxjl=1,8 do
if

Logic.PlayerGetIsHumanFlag(yxjl)and Logic.PlayerGetGameState(yxjl)~=0 then
if GUI.GetPlayerID()==yxjl then local ZG=Logic.GetPlayerName(yxjl)
local Vu0cCAf=Framework.GetSystemTimeDateString()Are7xU=Are7xU..ZG.." "..Vu0cCAf
for q in Are7xU:gmatch(".")do XL_=
XL_+
((tonumber(q)~=nil and tonumber(q))or q:byte())end
if Framework.IsNetworkGame()then
Swift:DispatchScriptCommand(QSB.ScriptCommands.ProclaimateRandomSeed,0,XL_)else
GUI.SendScriptCommand("SCP.Core.ProclaimateRandomSeed("..XL_..")")end end;break end end end
function Swift:OverrideOnMPGameStart()
GameCallback_OnMPGameStart=function()
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,"","VictoryConditionHandler",1)end end
NOT=function(kP7O5,lqT)local mP3mlD=table.copy(lqT)local PrPyxMK=table.remove(mP3mlD,1)return not
PrPyxMK(kP7O5,unpack(mP3mlD))end
XOR=function(tczrIB,...)local a=table.copy(arg)local wqU76o=0
for LB1Z=1,#a do
local N9L=table.remove(a[LB1Z],1)wqU76o=wqU76o+
((N9L(tczrIB,unpack(a[LB1Z]))and 1)or 0)end;return wqU76o==1 end
ALL=function(hDc_M,...)local qW0lRiD1=table.copy(arg)
for iD1IUx=1,#qW0lRiD1 do
local JLCOx_ak=table.remove(qW0lRiD1[iD1IUx],1)if
not JLCOx_ak(hDc_M,unpack(qW0lRiD1[iD1IUx]))then return false end end;return true end
ANY=function(hPQ,...)local R1FIoQI=table.copy(arg)for NsoTwDs=1,#R1FIoQI do
local HGli=table.remove(R1FIoQI[NsoTwDs],1)
if HGli(hPQ,unpack(R1FIoQI[NsoTwDs]))then return true end end;return false end
function Swift:OverrideQuestSystemGlobal()
QuestTemplate.Trigger_Orig_QSB_Core=QuestTemplate.Trigger
QuestTemplate.Trigger=function(iy)
QuestTemplate.Trigger_Orig_QSB_Core(iy)
for m6SCS0=1,iy.Objectives[0]do
if
iy.Objectives[m6SCS0].Type==Objective.Custom2 and
iy.Objectives[m6SCS0].Data[1].SetDescriptionOverwrite then
local NUhYw6R4=iy.Objectives[m6SCS0].Data[1]:SetDescriptionOverwrite(iy)Swift:ChangeCustomQuestCaptionText(NUhYw6R4,iy)break end end
Swift:SendQuestStateEvent(iy.Identifier,"QuestTrigger")end;QuestTemplate.Interrupt_Orig_QSB_Core=QuestTemplate.Interrupt
QuestTemplate.Interrupt=function(Hv)
Hv:Interrupt_Orig_QSB_Core()
for Ch=1,Hv.Objectives[0]do if

Hv.Objectives[Ch].Type==Objective.Custom2 and Hv.Objectives[Ch].Data[1].Interrupt then
Hv.Objectives[Ch].Data[1]:Interrupt(Hv,Ch)end end
for urkh=1,Hv.Triggers[0]do if Hv.Triggers[urkh].Type==Triggers.Custom2 and
Hv.Triggers[urkh].Data[1].Interrupt then
Hv.Triggers[urkh].Data[1]:Interrupt(Hv,urkh)end end
Swift:SendQuestStateEvent(Hv.Identifier,"QuestInterrupt")end;QuestTemplate.Fail_Orig_QSB_Core=QuestTemplate.Fail
QuestTemplate.Fail=function(zhzpBSx)
zhzpBSx:Fail_Orig_QSB_Core()
Swift:SendQuestStateEvent(zhzpBSx.Identifier,"QuestFailure")end;QuestTemplate.Success_Orig_QSB_Core=QuestTemplate.Success
QuestTemplate.Success=function(rHSjalVy)
rHSjalVy:Success_Orig_QSB_Core()
Swift:SendQuestStateEvent(rHSjalVy.Identifier,"QuestSuccess")end end
function Swift:SendQuestStateEvent(TjhsnP,t5jzEd9)local JZAU2=API.GetQuestID(TjhsnP)
if Quests[JZAU2]then
Swift:DispatchScriptEvent(QSB.ScriptEvents[t5jzEd9],JZAU2)
Logic.ExecuteInLuaLocalState(string.format([[Swift:DispatchScriptEvent(QSB.ScriptEvents["%s"], %d)]],t5jzEd9,JZAU2))end end
function Swift:ChangeCustomQuestCaptionText(zPXTTg,seMLr)
if seMLr and seMLr.Visible then seMLr.QuestDescription=zPXTTg
Logic.ExecuteInLuaLocalState(
[[
            XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives/Custom/BGDeco",0)
            local identifier = "]]..
seMLr.Identifier..

[["
            for i=1, Quests[0] do
                if Quests[i].Identifier == identifier then
                    local text = Quests[i].QuestDescription
                    XGUIEng.SetText("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives/Custom/Text", "]]..
zPXTTg..[[")
                    break
                end
            end
        ]])end end
function Swift:LoadBehaviors()
for qX=1,#self.m_BehaviorRegister,1 do
local h_8=self.m_BehaviorRegister[qX]
if not _G["B_"..h_8.Name].new then
_G["B_"..h_8.Name].new=function(xL7OTb,...)
local w8T3f={...}local K=table.copy(xL7OTb)K.i47ya_6aghw_frxil={}
K.v12ya_gg56h_al125={}
for qX=1,#w8T3f,1 do
table.insert(K.v12ya_gg56h_al125,w8T3f[qX])if xL7OTb.Parameter and xL7OTb.Parameter[qX]~=nil then K:AddParameter(
qX-1,w8T3f[qX])else
table.insert(K.i47ya_6aghw_frxil,w8T3f[qX])end end;return K end end end end
function Swift:RegisterBehavior(qL)if self:IsLocalEnvironment()then return end;if
type(qL)~="table"or qL.Name==nil then
assert(false,"Behavior is invalid!")return end;if qL.RequiresExtraNo and
qL.RequiresExtraNo>g_GameExtraNo then return end;if not
_G["B_"..qL.Name]then
error(string.format("Behavior %s does not exist!",qL.Name))return end
for vfIyB=1,#g_QuestBehaviorTypes,1 do if
g_QuestBehaviorTypes[vfIyB].Name==qL.Name then return end end;table.insert(g_QuestBehaviorTypes,qL)
table.insert(self.m_BehaviorRegister,qL)end
function Swift:LoadExternFiles()
if Mission_LoadFiles then local quNsijN=Mission_LoadFiles()
for QUh2tc=1,#quNsijN,1 do if
type(quNsijN[QUh2tc])=="function"then quNsijN[QUh2tc]()else
Script.Load(quNsijN[QUh2tc])end end end end;function Swift:DetectEnvironment()
self.m_Environment=(nil~=GUI and"local")or"global"end;function Swift:IsGlobalEnvironment()return
"global"==self.m_Environment end;function Swift:IsLocalEnvironment()return"local"==
self.m_Environment end
function Swift:ValidateTerritories()
local qboV=false;local nSBOx7={Logic.GetTerritories()}
for u=1,#nSBOx7,1 do
local K,i1=GUI.ComputeTerritoryPosition(nSBOx7[u])if not K or not i1 then
error("Territory "..nSBOx7[u].." is invalid!")qboV=true end end;if qboV then
error("A territory must have a size greater 0 and no separated areas!")end end
function Swift:IsHistoryEdition()return Network.IsNATReady~=nil end
function Swift:IsCommunityPatch()return Entities.U_PolarBear~=nil end
function Swift:OverrideDoQuicksave()
self:AddBlockQuicksaveCondition(function()
return GUI and
XGUIEng.IsWidgetShownEx("/LoadScreen/LoadScreen")~=0 end)KeyBindings_SaveGame_Orig_Module_SaveGame=KeyBindings_SaveGame
KeyBindings_SaveGame=function(...)if not
Swift:CanDoQuicksave(unpack(arg))then return end
KeyBindings_SaveGame_Orig_Module_SaveGame()end end
function Swift:AlterQuickSaveHotkey()
StartSimpleHiResJobEx(function()
Input.KeyBindDown(Keys.ModifierControl+Keys.S,"KeyBindings_SaveGame(true)",2,false)return true end)end;function Swift:AddBlockQuicksaveCondition(zz1QI)
table.insert(self.m_NoQuicksaveConditions,zz1QI)end
function Swift:CanDoQuicksave(...)
for kFTAh=1,#
self.m_NoQuicksaveConditions,1 do if
self.m_NoQuicksaveConditions[kFTAh](unpack(arg))then return false end end;return true end;LOG_LEVEL_ALL=4;LOG_LEVEL_INFO=3;LOG_LEVEL_WARNING=2;LOG_LEVEL_ERROR=1
LOG_LEVEL_OFF=0
function Swift:Log(LBf,dijn4Ph,CO1)
if Swift.m_FileLogLevel>=dijn4Ph then
local RlZo=LBf:sub(1,LBf:find(":"))local SUn=LBf:sub(LBf:find(":")+1)
SUn=string.format(" (%s) %s%s",Swift.m_Environment,Framework.GetSystemTimeDateString(),SUn)Framework.WriteToLog(RlZo..SUn)end
if CO1 then
if self:IsGlobalEnvironment()then if Swift.m_LogLevel>=dijn4Ph then
Logic.ExecuteInLuaLocalState(string.format([[GUI.AddStaticNote("%s")]],LBf))end;return end
if Swift.m_LogLevel>=dijn4Ph then GUI.AddStaticNote(LBf)end end end
function Swift:SetLogLevel(Ib4,fjV1G2)
if self:IsGlobalEnvironment()then
Logic.ExecuteInLuaLocalState(string.format([[Swift.m_FileLogLevel = %d]],(
fjV1G2 or 0)))
Logic.ExecuteInLuaLocalState(string.format([[Swift.m_LogLevel = %d]],(Ib4 or 0)))self.m_FileLogLevel=(fjV1G2 or 0)
self.m_LogLevel=(Ib4 or 0)end end
function debug(Do,_)Swift:Log("DEBUG: "..Do,LOG_LEVEL_ALL,not _)end;function info(TqYJ4,DI)
Swift:Log("INFO: "..TqYJ4,LOG_LEVEL_INFO,not DI)end;function warn(b,E)
Swift:Log("WARNING: "..b,LOG_LEVEL_WARNING,not E)end;function error(KMw7_i1s,CQi)
Swift:Log("ERROR: "..KMw7_i1s,LOG_LEVEL_ERROR,not CQi)end;function Swift:OverrideTable()
API.OverrideTable()end
function Swift:OverrideString()API.OverrideString()end
function Swift:ConvertTableToString(nHlJ)assert(type(nHlJ)=="table")
local lw4Q7kbl="{"
for IN,QYf1 in pairs(nHlJ)do local RfsnisO;if(tonumber(IN))then RfsnisO=""..IN else
RfsnisO="\""..IN.."\""end
if type(QYf1)=="table"then lw4Q7kbl=lw4Q7kbl..
"["..RfsnisO.."] = "..
table.tostring(QYf1)..", "elseif type(QYf1)==
"number"then lw4Q7kbl=lw4Q7kbl..
"["..RfsnisO.."] = "..QYf1 ..", "elseif type(QYf1)=="string"then
lw4Q7kbl=
lw4Q7kbl.."["..RfsnisO.."] = \""..QYf1 .."\", "elseif type(QYf1)=="boolean"or type(QYf1)=="nil"then lw4Q7kbl=lw4Q7kbl..
"["..
RfsnisO.."] = "..tostring(QYf1)..", "else lw4Q7kbl=lw4Q7kbl..
"["..RfsnisO..
"] = \""..tostring(QYf1).."\", "end end;lw4Q7kbl=lw4Q7kbl.."}"return lw4Q7kbl end
function Swift:InitalizeScriptCommands()
Swift:CreateScriptCommand("Cmd_SendScriptEvent",API.SendScriptEvent)
Swift:CreateScriptCommand("Cmd_GlobalQsbLoaded",SCP.Core.GlobalQsbLoaded)
Swift:CreateScriptCommand("Cmd_ProclaimateRandomSeed",SCP.Core.ProclaimateRandomSeed)
Swift:CreateScriptCommand("Cmd_RegisterLoadscreenHidden",SCP.Core.LoadscreenHidden)
Swift:CreateScriptCommand("Cmd_UpdateCustomVariable",SCP.Core.UpdateCustomVariable)
Swift:CreateScriptCommand("Cmd_UpdateTexturePosition",SCP.Core.UpdateTexturePosition)end
function Swift:CreateScriptCommand(lvW2ga,T7RKP)
if not self:IsGlobalEnvironment()then return 0 end;QSB.ScriptCommandSequence=QSB.ScriptCommandSequence+1
local _L6Bs=QSB.ScriptCommandSequence;local SH=lvW2ga
if string.find(lvW2ga,"^Cmd_")then SH=string.sub(lvW2ga,5)end;self.m_ScriptCommandRegister[_L6Bs]={SH,T7RKP}
Logic.ExecuteInLuaLocalState(string.format([[
            local ID = %d
            local Name = "%s"
            Swift.m_ScriptCommandRegister[ID] = Name
            QSB.ScriptCommands[Name] = ID
        ]],_L6Bs,SH))QSB.ScriptCommands[SH]=_L6Bs;return _L6Bs end
function Swift:DispatchScriptCommand(wU4wYbA9,...)
if not self:IsLocalEnvironment()then return end;assert(wU4wYbA9 ~=nil)
if
self.m_ScriptCommandRegister[wU4wYbA9]then local fFeQcIM=GUI.GetPlayerID()local JEHSHPh3=8
local bb=Logic.GetPlayerName(JEHSHPh3)
local o5e6fP=self:EncodeScriptCommandParameters(unpack(arg))GUI.SetPlayerName(JEHSHPh3,o5e6fP)
if
Framework.IsNetworkGame()and self:IsHistoryEdition()then
GUI.SetSoldierPaymentLevel(wU4wYbA9)else
GUI.SendScriptCommand(string.format([[Swift:ProcessScriptCommand(%d, %d)]],arg[1],wU4wYbA9))end
debug(string.format("Dispatching script command %s to global.",self.m_ScriptCommandRegister[wU4wYbA9]),true)GUI.SetPlayerName(JEHSHPh3,bb)
GUI.SetSoldierPaymentLevel(PlayerSoldierPaymentLevel[fFeQcIM])end end
function Swift:ProcessScriptCommand(iq7ol,eMV)
if not self.m_ScriptCommandRegister[eMV]then return end;local WDTNkTD=Logic.GetPlayerName(8)
local Oejsws=self:DecodeScriptCommandParameters(WDTNkTD)local CkD73N0=table.remove(Oejsws,1)if
CkD73N0 ~=0 and CkD73N0 ~=iq7ol then return end
debug(string.format("Processing script command %s in global.",self.m_ScriptCommandRegister[eMV][1]),true)
self.m_ScriptCommandRegister[eMV][2](unpack(Oejsws))end
function Swift:EncodeScriptCommandParameters(...)local PlwhaRKJ=""
for Caz4NM4Z=1,#arg do local XVxxx=arg[Caz4NM4Z]
if
type(XVxxx)=="string"then XVxxx=string.replaceAll(XVxxx,'#',"<<<HT>>>")
XVxxx=string.replaceAll(XVxxx,'"',"<<<QT>>>")if XVxxx:len()==0 then XVxxx="<<<ES>>>"end elseif
type(XVxxx)=="table"then
XVxxx="{"..table.concat(XVxxx,",").."}"end
if string.len(PlwhaRKJ)>0 then PlwhaRKJ=PlwhaRKJ.."#"end;PlwhaRKJ=PlwhaRKJ..tostring(XVxxx)end;return PlwhaRKJ end
function Swift:DecodeScriptCommandParameters(hD)local G5BuU5={}
for AfwsY,T in pairs(string.slice(hD,"#"))do local WZs=T
WZs=string.replaceAll(WZs,"<<<HT>>>",'#')WZs=string.replaceAll(WZs,"<<<QT>>>",'"')
WZs=string.replaceAll(WZs,"<<<ES>>>",'')
if WZs==nil then WZs=nil elseif WZs=="true"or WZs=="false"then WZs=WZs=="true"elseif
string.indexOf(WZs,"{")==1 then
local ITdz=string.slice(string.sub(WZs,2,string.len(WZs)-1),",")WZs={}for AjfoUo=1,#ITdz do
WZs[AjfoUo]=(tonumber(ITdz[AjfoUo])~=nil and
tonumber(ITdz[AjfoUo])or ITdz)end elseif tonumber(WZs)~=nil then
WZs=tonumber(WZs)end;table.insert(G5BuU5,WZs)end;return G5BuU5 end
function Swift:InitalizeEventsGlobal()
QSB.ScriptEvents.SaveGameLoaded=Swift:CreateScriptEvent("Event_SaveGameLoaded",nil)
QSB.ScriptEvents.EscapePressed=Swift:CreateScriptEvent("Event_EscapePressed",nil)
QSB.ScriptEvents.QuestFailure=Swift:CreateScriptEvent("Event_QuestFailure",nil)
QSB.ScriptEvents.QuestInterrupt=Swift:CreateScriptEvent("Event_QuestInterrupt",nil)
QSB.ScriptEvents.QuestReset=Swift:CreateScriptEvent("Event_QuestReset",nil)
QSB.ScriptEvents.QuestSuccess=Swift:CreateScriptEvent("Event_QuestSuccess",nil)
QSB.ScriptEvents.QuestTrigger=Swift:CreateScriptEvent("Event_QuestTrigger",nil)
QSB.ScriptEvents.CustomValueChanged=Swift:CreateScriptEvent("Event_CustomValueChanged",nil)
QSB.ScriptEvents.LanguageSet=Swift:CreateScriptEvent("Event_LanguageSet",nil)end
function Swift:InitalizeEventsLocal()
QSB.ScriptEvents.SaveGameLoaded=Swift:CreateScriptEvent("Event_SaveGameLoaded",nil)
QSB.ScriptEvents.EscapePressed=Swift:CreateScriptEvent("Event_EscapePressed",nil)
QSB.ScriptEvents.QuestFailure=Swift:CreateScriptEvent("Event_QuestFailure",nil)
QSB.ScriptEvents.QuestInterrupt=Swift:CreateScriptEvent("Event_QuestInterrupt",nil)
QSB.ScriptEvents.QuestReset=Swift:CreateScriptEvent("Event_QuestReset",nil)
QSB.ScriptEvents.QuestSuccess=Swift:CreateScriptEvent("Event_QuestSuccess",nil)
QSB.ScriptEvents.QuestTrigger=Swift:CreateScriptEvent("Event_QuestTrigger",nil)
QSB.ScriptEvents.CustomValueChanged=Swift:CreateScriptEvent("Event_CustomValueChanged",nil)
QSB.ScriptEvents.LanguageSet=Swift:CreateScriptEvent("Event_LanguageSet",nil)end
function Swift:CreateScriptEvent(Er9zidsB,X)
for JFXtQwy=1,#self.m_ScriptEventRegister,1 do if
self.m_ScriptEventRegister[JFXtQwy][1]==Er9zidsB then return 0 end end;local dR=#self.m_ScriptEventRegister+1
debug(string.format("Create script event %s",Er9zidsB),true)self.m_ScriptEventRegister[dR]={Er9zidsB,X}return dR end
function Swift:DispatchScriptEvent(uMV17h0,...)
if not self.m_ScriptEventRegister[uMV17h0]then return end
for E2NZK=1,#self.m_ModuleRegister,1 do local WNWWe="Local"if self:IsGlobalEnvironment()then
WNWWe="Global"end
if self.m_ModuleRegister[E2NZK][WNWWe]and
self.m_ModuleRegister[E2NZK][WNWWe].OnEvent then
debug(string.format("Dispatching %s script event %s to Module %s",WNWWe:lower(),self.m_ScriptEventRegister[uMV17h0][1],self.m_ModuleRegister[E2NZK].Properties.Name),true)
self.m_ModuleRegister[E2NZK][WNWWe]:OnEvent(uMV17h0,self.m_ScriptEventRegister[uMV17h0],unpack(arg))end end;if GameCallback_QSB_OnEventReceived then
GameCallback_QSB_OnEventReceived(uMV17h0,unpack(arg))end
if
self.m_ScriptEventListener[uMV17h0]then
for zMzjn3lk,Trkkpmd in pairs(self.m_ScriptEventListener[uMV17h0])do if
tonumber(zMzjn3lk)then Trkkpmd(uMV17h0,unpack(arg))end end end end
function Swift:IsAllowedEventParameter(L)
if
type(L)=="function"or type(L)=="thread"or type(L)=="userdata"then return false elseif
type(L)=="table"then
for GGv,ZIzh4Si in pairs(L)do
if type(GGv)~="number"and GGv~="n"then return false end;if
type(ZIzh4Si)=="function"or type(ZIzh4Si)=="thread"or type(ZIzh4Si)=="userdata"then
return false end end end;return true end;function Swift:InitalizeAIVariables()
for c8D4n81=1,8 do self.m_AIProperties[c8D4n81]={}end end
function Swift:DisableLogicFestival()
Swift.Logic_StartFestival=Logic.StartFestival
Logic.StartFestival=function(cSjJHx,fa)
if Logic.PlayerGetIsHumanFlag(cSjJHx)~=true then if
Swift.m_AIProperties[cSjJHx].ForbidFestival==true then return end end;Swift.Logic_StartFestival(cSjJHx,fa)end end
function Swift:GetCustomVariable(M)return QSB.CustomVariable[M]end
function Swift:SetCustomVariable(dIZlrvD,jQgsATKd)
Swift:UpdateCustomVariable(dIZlrvD,jQgsATKd)local aBbGg=tostring(jQgsATKd)if type(jQgsATKd)~="number"then aBbGg=[["]]..
aBbGg..[["]]end
if GUI then
Swift:DispatchScriptCommand(QSB.ScriptCommands.UpdateCustomVariable,0,dIZlrvD,aBbGg)else
Logic.ExecuteInLuaLocalState(string.format([[Swift:UpdateCustomVariable("%s", %s)]],dIZlrvD,aBbGg))end end
function Swift:UpdateCustomVariable(D9,G)
if QSB.CustomVariable[D9]then
local gE=QSB.CustomVariable[D9]QSB.CustomVariable[D9]=G
Swift:DispatchScriptEvent(QSB.ScriptEvents.CustomValueChanged,D9,gE,G)else QSB.CustomVariable[D9]=G;Swift:DispatchScriptEvent(QSB.ScriptEvents.CustomValueChanged,D9,
nil,G)end end;function Swift:DetectLanguage()self.m_Language=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
QSB.Language=self.m_Language end
function Swift:ChangeSystemLanguage(QgC)
local CYoa=self.m_Language;local K3ipRr=QgC;self.m_Language=QgC;QSB.Language=self.m_Language
Swift:DispatchScriptEvent(QSB.ScriptEvents.LanguageSet,CYoa,K3ipRr)
Logic.ExecuteInLuaLocalState(string.format([[
            local OldLanguage = "%s"
            local NewLanguage = "%s"
            Swift.m_Language = NewLanguage
            QSB.Language = NewLanguage
            Swift:DispatchScriptEvent(QSB.ScriptEvents.LanguageSet, OldLanguage, NewLanguage)
        ]],CYoa,K3ipRr))end
function Swift:GetTextOfDesiredLanguage(F2tY)
if type(F2tY)=="table"then if F2tY[QSB.Language]then return
F2tY[QSB.Language]end;return"ERROR_NO_TEXT"end;return"ERROR_NO_TEXT"end
function Swift:Localize(rb21L2)local o_v255
if type(rb21L2)=="table"then o_v255={}
if rb21L2.en==nil and
rb21L2[QSB.Language]==nil then
for wUVm,VQ in pairs(rb21L2)do if type(VQ)=="table"then
o_v255[wUVm]=self:Localize(VQ)end end else o_v255=Swift:GetTextOfDesiredLanguage(rb21L2)end else o_v255=tostring(rb21L2)end;return o_v255 end
function Swift:ToBoolean(oTYNsnP)if type(oTYNsnP)=="boolean"then return oTYNsnP end
if
oTYNsnP==1 or
string.find(string.lower(tostring(oTYNsnP)),"^[1tjy\\+].*$")then return true end;return false end
function Swift:CopyTable(I,L)I=I or{}L=L or{}
for mR5gwW,DfbW in pairs(I)do
if"table"==type(DfbW)then
L[mR5gwW]=L[mR5gwW]or{}
for sh,rrFLbCtj in pairs(self:CopyTable(DfbW,L[mR5gwW]))do L[mR5gwW][sh]=
L[mR5gwW][sh]or rrFLbCtj end else L[mR5gwW]=DfbW end end;return L end
function Swift_EventJob_WaitForLoadScreenHidden()
if
XGUIEng.IsWidgetShownEx("/LoadScreen/LoadScreen")==0 then
Swift:DispatchScriptCommand(QSB.ScriptCommands.RegisterLoadscreenHidden,GUI.GetPlayerID())Swift.m_LoadScreenHidden=true;return true end end
function Swift_EventJob_PostTexturesToGlobal()
if Logic.GetTime()>1 then
for YcPea0vg,usLpLoaH in pairs(g_TexturePositions)do for e7dv,inx0 in
pairs(usLpLoaH)do
Swift:DispatchScriptCommand(QSB.ScriptCommands.UpdateTexturePosition,GUI.GetPlayerID(),YcPea0vg,e7dv,usLpLoaH)end end;return true end end