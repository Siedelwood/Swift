Swift=Swift or{}
Swift.Behavior={QuestCounter=0,Text={DestroySoldiers={de="{center}SOLDATEN ZERSTÖREN {cr}{cr}von der Partei: %s{cr}{cr}Anzahl: %d",en="{center}DESTROY SOLDIERS {cr}{cr}from faction: %s{cr}{cr}Amount: %d"},ActivateBuff={Pattern={de="BONUS AKTIVIEREN{cr}{cr}%s",en="ACTIVATE BUFF{cr}{cr}%s"},BuffsVanilla={["Buff_Spice"]={de="Salz",en="Salt"},["Buff_Colour"]={de="Farben",en="Color"},["Buff_Entertainers"]={de="Entertainer",en="Entertainer"},["Buff_FoodDiversity"]={de="Vielfältige Nahrung",en="Food diversity"},["Buff_ClothesDiversity"]={de="Vielfältige Kleidung",en="Clothes diversity"},["Buff_HygieneDiversity"]={de="Vielfältige Reinigung",en="Hygiene diversity"},["Buff_EntertainmentDiversity"]={de="Vielfältige Unterhaltung",en="Entertainment diversity"},["Buff_Sermon"]={de="Predigt",en="Sermon"},["Buff_Festival"]={de="Fest",en="Festival"},["Buff_ExtraPayment"]={de="Sonderzahlung",en="Extra payment"},["Buff_HighTaxes"]={de="Hohe Steuern",en="High taxes"},["Buff_NoPayment"]={de="Kein Sold",en="No payment"},["Buff_NoTaxes"]={de="Keine Steuern",en="No taxes"}},BuffsEx1={["Buff_Gems"]={de="Edelsteine",en="Gems"},["Buff_MusicalInstrument"]={de="Musikinstrumente",en="Musical instruments"},["Buff_Olibanum"]={de="Weihrauch",en="Olibanum"}}},SoldierCount={Pattern={de="SOLDATENANZAHL {cr}Partei: %s{cr}{cr}%s %d",en="SOLDIER COUNT {cr}Faction: %s{cr}{cr}%s %d"},Relation={["true"]={de="Weniger als ",en="Less than "},["false"]={de="Mindestens ",en="At least "}}},Festivals={Pattern={de="FESTE FEIERN {cr}{cr}Partei: %s{cr}{cr}Anzahl: %d",en="HOLD PARTIES {cr}{cr}Faction: %s{cr}{cr}Amount: %d"}}}}QSB.DestroyedSoldiers={}QSB.EffectNameToID={}QSB.InitalizedObjekts={}
function Swift:InstallBehaviorGlobal()
self:OverrideQuestMarkers()self:OverrideIsObjectiveCompleted()end
function Swift:InstallBehaviorLocal()self:OverrideDisplayQuestObjective()end
function Swift:OverrideQuestMarkers()
QuestTemplate.RemoveQuestMarkers=function(QDnlt)
for LmcA2auZ=1,QDnlt.Objectives[0]do
if
QDnlt.Objectives[LmcA2auZ].Type==Objective.Distance then if
QDnlt.Objectives[LmcA2auZ].Data[4]then
DestroyQuestMarker(QDnlt.Objectives[LmcA2auZ].Data[2])end end end end
QuestTemplate.ShowQuestMarkers=function(Q)
for ZA=1,Q.Objectives[0]do
if Q.Objectives[ZA].Type==
Objective.Distance then if Q.Objectives[ZA].Data[4]then
ShowQuestMarker(Q.Objectives[ZA].Data[2])end end end end
function ShowQuestMarker(_IQQ)local XpkjA=GetID(_IQQ)
local pVRj,fuZ3z86=Logic.GetEntityPosition(XpkjA)local er=EGL_Effects.E_Questmarker_low;if
Logic.IsBuilding(XpkjA)==1 then er=EGL_Effects.E_Questmarker end
DestroyQuestMarker(_IQQ)
Questmarkers[XpkjA]=Logic.CreateEffect(er,pVRj,fuZ3z86,0)end
function DestroyQuestMarker(DFb100j)local XL_=GetID(DFb100j)if Questmarkers[XL_]~=nil then
Logic.DestroyEffect(Questmarkers[XL_])Questmarkers[XL_]=nil end end end
function Swift:OverrideIsObjectiveCompleted()
QuestTemplate.IsObjectiveCompleted_Orig_QSB_CoreBehavior=QuestTemplate.IsObjectiveCompleted
QuestTemplate.IsObjectiveCompleted=function(WYdR,QKKks_zt)local Are7xU=QKKks_zt.Type;if QKKks_zt.Completed~=nil then return
QKKks_zt.Completed end;local yxjl=QKKks_zt.Data
if Are7xU==
Objective.DestroyAllPlayerUnits then local ZG=GetPlayerEntities(yxjl,0)local Vu0cCAf={}
for q=#ZG,1,-1 do
local kP7O5=Logic.GetEntityType(ZG[q])
if

Logic.IsEntityInCategory(ZG[q],EntityCategories.AttackableBuilding)==0 or
Logic.IsEntityInCategory(ZG[q],EntityCategories.Wall)==0 then if Logic.IsConstructionComplete(ZG[q])==0 then
table.insert(Vu0cCAf,ZG[q])end end
local lqT={Entities.XD_ScriptEntity,Entities.S_AIHomePosition,Entities.S_AIAreaDefinition}
if table.contains(lqT,kP7O5)then table.insert(Vu0cCAf,ZG[q])end end
if#ZG==0 or#ZG-#Vu0cCAf==0 then QKKks_zt.Completed=true end elseif Are7xU==Objective.Distance then
QKKks_zt.Completed=Swift:IsQuestPositionReached(WYdR,QKKks_zt)else
return WYdR:IsObjectiveCompleted_Orig_QSB_CoreBehavior(QKKks_zt)end end end
function Swift:OverrideDisplayQuestObjective()
GUI_Interaction.DisplayQuestObjective_Orig_QSB_CoreBehavior=GUI_Interaction.DisplayQuestObjective
GUI_Interaction.DisplayQuestObjective=function(mP3mlD,PrPyxMK)
local tczrIB,a=GUI_Interaction.GetPotentialSubQuestAndType(mP3mlD)
if a==Objective.Distance then if tczrIB.Objectives[1].Data[1]==-
65566 then
tczrIB.Objectives[1].Data[1]=Logic.GetKnightID(tczrIB.ReceivingPlayer)end end
GUI_Interaction.DisplayQuestObjective_Orig_QSB_CoreBehavior(mP3mlD,PrPyxMK)end end
function Swift:IsQuestPositionReached(wqU76o,LB1Z)local N9L=GetID(LB1Z.Data[1])if N9L==-65566 then
LB1Z.Data[1]=Logic.GetKnightID(wqU76o.ReceivingPlayer)N9L=LB1Z.Data[1]end
local hDc_M=GetID(LB1Z.Data[2])LB1Z.Data[3]=LB1Z.Data[3]or 2500
if not
(
Logic.IsEntityDestroyed(N9L)or Logic.IsEntityDestroyed(hDc_M))then if
Logic.GetDistanceBetweenEntities(N9L,hDc_M)<=LB1Z.Data[3]then
DestroyQuestMarker(hDc_M)return true end else
DestroyQuestMarker(hDc_M)return false end end
function Goal_ActivateObject(...)return B_Goal_ActivateObject:new(...)end
B_Goal_ActivateObject={Name="Goal_ActivateObject",Description={en="Goal: Activate an interactive object",de="Ziel: Aktiviere ein interaktives Objekt"},Parameter={{ParameterType.ScriptName,en="Object name",de="Skriptname"}}}function B_Goal_ActivateObject:GetGoalTable()return
{Objective.Object,{self.ScriptName}}end
function B_Goal_ActivateObject:AddParameter(qW0lRiD1,iD1IUx)if
qW0lRiD1 ==0 then self.ScriptName=iD1IUx end end
function B_Goal_ActivateObject:GetMsgKey()return"Quest_Object_Activate"end;Swift:RegisterBehavior(B_Goal_ActivateObject)function Goal_Deliver(...)return
B_Goal_Deliver:new(...)end
B_Goal_Deliver={Name="Goal_Deliver",Description={en="Goal: Deliver goods to quest giver or to another player.",de="Ziel: Liefere Waren zum Auftraggeber oder zu einem anderen Spieler."},Parameter={{ParameterType.Custom,en="Type of good",de="Ressourcentyp"},{ParameterType.Number,en="Amount of good",de="Ressourcenmenge"},{ParameterType.Custom,en="To different player",de="Anderer Empfänger"},{ParameterType.Custom,en="Ignore capture",de="Abfangen ignorieren"}}}
function B_Goal_Deliver:GetGoalTable()
local JLCOx_ak=Logic.GetGoodTypeID(self.GoodTypeName)return
{Objective.Deliver,JLCOx_ak,self.GoodAmount,self.OverrideTarget,self.IgnoreCapture}end
function B_Goal_Deliver:AddParameter(hPQ,R1FIoQI)
if(hPQ==0)then self.GoodTypeName=R1FIoQI elseif(hPQ==1)then self.GoodAmount=
R1FIoQI*1 elseif(hPQ==2)then self.OverrideTarget=tonumber(R1FIoQI)elseif(hPQ==
3)then self.IgnoreCapture=API.ToBoolean(R1FIoQI)end end
function B_Goal_Deliver:GetCustomData(NsoTwDs)local HGli={}
if NsoTwDs==0 then for iy,m6SCS0 in pairs(Goods)do if string.find(iy,"^G_")then
table.insert(HGli,iy)end end
table.sort(HGli)elseif NsoTwDs==2 then table.insert(HGli,"-")for NUhYw6R4=1,8 do
table.insert(HGli,NUhYw6R4)end elseif NsoTwDs==3 then table.insert(HGli,"true")
table.insert(HGli,"false")else assert(false)end;return HGli end
function B_Goal_Deliver:GetMsgKey()
local Hv=Logic.GetGoodTypeID(self.GoodTypeName)local Ch=Logic.GetGoodCategoryForGoodType(Hv)
local urkh={[GoodCategories.GC_Clothes]="Quest_Deliver_GC_Clothes",[GoodCategories.GC_Entertainment]="Quest_Deliver_GC_Entertainment",[GoodCategories.GC_Food]="Quest_Deliver_GC_Food",[GoodCategories.GC_Gold]="Quest_Deliver_GC_Gold",[GoodCategories.GC_Hygiene]="Quest_Deliver_GC_Hygiene",[GoodCategories.GC_Medicine]="Quest_Deliver_GC_Medicine",[GoodCategories.GC_Water]="Quest_Deliver_GC_Water",[GoodCategories.GC_Weapon]="Quest_Deliver_GC_Weapon",[GoodCategories.GC_Resource]="Quest_Deliver_Resources"}
if Ch then local zhzpBSx=urkh[Ch]if zhzpBSx then return zhzpBSx end end;return"Quest_Deliver_Goods"end;Swift:RegisterBehavior(B_Goal_Deliver)function Goal_Diplomacy(...)return
B_Goal_Diplomacy:new(...)end
B_Goal_Diplomacy={Name="Goal_Diplomacy",Description={en="Goal: A diplomatic state must b reached. Can be lower than current state or higher.",de="Ziel: Die Beziehungen zu einem Spieler müssen entweder verbessert oder verschlechtert werden."},Parameter={{ParameterType.PlayerID,en="Party",de="Partei"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Custom,en="Diplomacy state",de="Diplomatische Beziehung"}},DiploNameMap={[DiplomacyStates.Allied]={de="Verbündeter",en="Allied"},[DiplomacyStates.TradeContact]={de="Handelspartner",en="Trade Contact"},[DiplomacyStates.EstablishedContact]={de="Bekannt",en="Established Contact"},[DiplomacyStates.Undecided]={de="Unbekannt",en="Undecided"},[DiplomacyStates.Enemy]={de="Feind",en="Enemy"}},TextPattern={de="DIPLOMATIESTATUS ERREICHEN {cr}{cr}Status: %s{cr}Zur Partei: %s",en="DIPLOMATIC STATE {cr}{cr}State: %s{cr}To player: %s"}}function B_Goal_Diplomacy:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_Diplomacy:ChangeCaption(rHSjalVy)local TjhsnP=
GetPlayerName(self.PlayerID)or""
local t5jzEd9=string.format(Swift:GetTextOfDesiredLanguage(self.TextPattern),Swift:GetTextOfDesiredLanguage(self.DiploNameMap[self.DiplState]),TjhsnP)
Swift:ChangeCustomQuestCaptionText(t5jzEd9,rHSjalVy)end
function B_Goal_Diplomacy:CustomFunction(JZAU2)self:ChangeCaption(JZAU2)
if
self.Relation=="<="then if
GetDiplomacyState(JZAU2.ReceivingPlayer,self.PlayerID)<=self.DiplState then return true end elseif self.Relation==">="then
if
GetDiplomacyState(JZAU2.ReceivingPlayer,self.PlayerID)>=self.DiplState then return true end else if
GetDiplomacyState(JZAU2.ReceivingPlayer,self.PlayerID)==self.DiplState then return true end end end
function B_Goal_Diplomacy:AddParameter(zPXTTg,seMLr)
if(zPXTTg==0)then self.PlayerID=seMLr*1 elseif(zPXTTg==1)then
self.Relation=seMLr elseif(zPXTTg==2)then self.DiplState=DiplomacyStates[seMLr]end end;function B_Goal_Diplomacy:GetIcon()return{6,3}end
function B_Goal_Diplomacy:GetCustomData(qX)
if
qX==1 then return{">=","<=","=="}elseif qX==2 then return
{"Allied","TradeContact","EstablishedContact","Undecided","Enemy"}end end;Swift:RegisterBehavior(B_Goal_Diplomacy)function Goal_DiscoverPlayer(...)return
B_Goal_DiscoverPlayer:new(...)end
B_Goal_DiscoverPlayer={Name="Goal_DiscoverPlayer",Description={en="Goal: Discover the home territory of another player.",de="Ziel: Entdecke das Heimatterritorium eines Spielers."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}function B_Goal_DiscoverPlayer:GetGoalTable()return
{Objective.Discover,2,{self.PlayerID}}end
function B_Goal_DiscoverPlayer:AddParameter(h_8,xL7OTb)if(
h_8 ==0)then self.PlayerID=xL7OTb*1 end end
function B_Goal_DiscoverPlayer:GetMsgKey()
local w8T3f={[PlayerCategories.BanditsCamp]="Quest_Discover",[PlayerCategories.City]="Quest_Discover_City",[PlayerCategories.Cloister]="Quest_Discover_Cloister",[PlayerCategories.Harbour]="Quest_Discover",[PlayerCategories.Village]="Quest_Discover_Village"}local K=GetPlayerCategoryType(self.PlayerID)if K then local qL=w8T3f[K]if
qL then return qL end end;return"Quest_Discover"end;Swift:RegisterBehavior(B_Goal_DiscoverPlayer)function Goal_DiscoverTerritory(...)return
B_Goal_DiscoverTerritory:new(...)end
B_Goal_DiscoverTerritory={Name="Goal_DiscoverTerritory",Description={en="Goal: Discover a territory",de="Ziel: Entdecke ein Territorium"},Parameter={{ParameterType.TerritoryName,en="Territory",de="Territorium"}}}function B_Goal_DiscoverTerritory:GetGoalTable()return
{Objective.Discover,1,{self.TerritoryID}}end
function B_Goal_DiscoverTerritory:AddParameter(vfIyB,quNsijN)
if(
vfIyB==0)then self.TerritoryID=tonumber(quNsijN)if not self.TerritoryID then
self.TerritoryID=GetTerritoryIDByName(quNsijN)end
assert(self.TerritoryID>0)end end
function B_Goal_DiscoverTerritory:GetMsgKey()return"Quest_Discover_Territory"end;Swift:RegisterBehavior(B_Goal_DiscoverTerritory)function Goal_DestroyPlayer(...)return
B_Goal_DestroyPlayer:new(...)end
B_Goal_DestroyPlayer={Name="Goal_DestroyPlayer",Description={en="Goal: Destroy a player (destroy a main building)",de="Ziel: Zerstöre einen Spieler (ein Hauptgebäude muss zerstört werden)."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function B_Goal_DestroyPlayer:GetGoalTable()
assert(self.PlayerID<=8 and self.PlayerID>=1,
"Error in "..self.Name..": GetGoalTable: PlayerID is invalid")return{Objective.DestroyPlayers,self.PlayerID}end;function B_Goal_DestroyPlayer:AddParameter(QUh2tc,qboV)
if(QUh2tc==0)then self.PlayerID=qboV*1 end end
function B_Goal_DestroyPlayer:GetMsgKey()
local nSBOx7={[PlayerCategories.BanditsCamp]="Quest_DestroyPlayers_Bandits",[PlayerCategories.City]="Quest_DestroyPlayers_City",[PlayerCategories.Cloister]="Quest_DestroyPlayers_Cloister",[PlayerCategories.Harbour]="Quest_DestroyEntities_Building",[PlayerCategories.Village]="Quest_DestroyPlayers_Village"}local u=GetPlayerCategoryType(self.PlayerID)if u then
local K=nSBOx7[u]if K then return K end end
return"Quest_DestroyEntities_Building"end;Swift:RegisterBehavior(B_Goal_DestroyPlayer)function Goal_StealInformation(...)return
B_Goal_StealInformation:new(...)end
B_Goal_StealInformation={Name="Goal_StealInformation",Description={en="Goal: Steal information from another players castle",de="Ziel: Stehle Informationen aus der Burg eines Spielers"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function B_Goal_StealInformation:GetGoalTable()
local i1=Logic.GetHeadquarters(self.PlayerID)
if not i1 or i1 ==0 then i1=Logic.GetStoreHouse(self.PlayerID)end;assert(i1 and i1 ~=0)
return{Objective.Steal,1,{i1}}end;function B_Goal_StealInformation:AddParameter(zz1QI,kFTAh)
if(zz1QI==0)then self.PlayerID=kFTAh*1 end end;function B_Goal_StealInformation:GetMsgKey()return
"Quest_Steal_Info"end
Swift:RegisterBehavior(B_Goal_StealInformation)function Goal_DestroyAllPlayerUnits(...)
return B_Goal_DestroyAllPlayerUnits:new(...)end
B_Goal_DestroyAllPlayerUnits={Name="Goal_DestroyAllPlayerUnits",Description={en="Goal: Destroy all units owned by player (be careful with script entities)",de="Ziel: Zerstöre alle Einheiten eines Spielers (vorsicht mit Script-Entities)"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function B_Goal_DestroyAllPlayerUnits:GetGoalTable()return
{Objective.DestroyAllPlayerUnits,self.PlayerID}end;function B_Goal_DestroyAllPlayerUnits:AddParameter(LBf,dijn4Ph)
if(LBf==0)then self.PlayerID=dijn4Ph*1 end end
function B_Goal_DestroyAllPlayerUnits:GetMsgKey()
local CO1={[PlayerCategories.BanditsCamp]="Quest_DestroyPlayers_Bandits",[PlayerCategories.City]="Quest_DestroyPlayers_City",[PlayerCategories.Cloister]="Quest_DestroyPlayers_Cloister",[PlayerCategories.Harbour]="Quest_DestroyEntities_Building",[PlayerCategories.Village]="Quest_DestroyPlayers_Village"}local RlZo=GetPlayerCategoryType(self.PlayerID)if RlZo then
local SUn=CO1[RlZo]if SUn then return SUn end end
return"Quest_DestroyEntities"end
Swift:RegisterBehavior(B_Goal_DestroyAllPlayerUnits)function Goal_DestroyScriptEntity(...)
return B_Goal_DestroyScriptEntity:new(...)end
B_Goal_DestroyScriptEntity={Name="Goal_DestroyScriptEntity",Description={en="Goal: Destroy an entity",de="Ziel: Zerstöre eine Entität"},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}
function B_Goal_DestroyScriptEntity:GetGoalTable()return
{Objective.DestroyEntities,1,{self.ScriptName}}end;function B_Goal_DestroyScriptEntity:AddParameter(Ib4,fjV1G2)
if(Ib4 ==0)then self.ScriptName=fjV1G2 end end
function B_Goal_DestroyScriptEntity:GetMsgKey()
if
Logic.IsEntityAlive(self.ScriptName)then local Do=GetID(self.ScriptName)
if Do and Do~=0 then
Do=Logic.GetEntityType(Do)
if Do and Do~=0 then
if
Logic.IsEntityTypeInCategory(Do,EntityCategories.AttackableBuilding)==1 then return"Quest_DestroyEntities_Building"elseif
Logic.IsEntityTypeInCategory(Do,EntityCategories.AttackableAnimal)==1 then return"Quest_DestroyEntities_Predators"elseif
Logic.IsEntityTypeInCategory(Do,EntityCategories.Hero)==1 then return"Quest_Destroy_Leader"elseif


Logic.IsEntityTypeInCategory(Do,EntityCategories.Military)==1 or
Logic.IsEntityTypeInCategory(Do,EntityCategories.AttackableSettler)==1 or
Logic.IsEntityTypeInCategory(Do,EntityCategories.AttackableMerchant)==1 then return"Quest_DestroyEntities_Unit"end end end end;return"Quest_DestroyEntities"end
Swift:RegisterBehavior(B_Goal_DestroyScriptEntity)
function Goal_DestroyType(...)return B_Goal_DestroyType:new(...)end
B_Goal_DestroyType={Name="Goal_DestroyType",Description={en="Goal: Destroy entity types",de="Ziel: Zerstöre Entitätstypen"},Parameter={{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.Custom,en="Player",de="Spieler"}}}
function B_Goal_DestroyType:GetGoalTable()return
{Objective.DestroyEntities,2,Entities[self.EntityName],self.Amount,self.PlayerID}end
function B_Goal_DestroyType:AddParameter(_,TqYJ4)
if(_==0)then self.EntityName=TqYJ4 elseif(_==1)then
self.Amount=TqYJ4*1;self.DestroyTypeAmount=self.Amount elseif(_==2)then self.PlayerID=TqYJ4*1 end end
function B_Goal_DestroyType:GetCustomData(DI)local b={}
if DI==0 then for E,KMw7_i1s in pairs(Entities)do if string.find(E,"^[ABU]_")then
table.insert(b,E)end end
table.sort(b)elseif DI==2 then for CQi=0,8 do table.insert(b,CQi)end else assert(false)end;return b end
function B_Goal_DestroyType:GetMsgKey()local nHlJ=self.EntityName
if
Logic.IsEntityTypeInCategory(nHlJ,EntityCategories.AttackableBuilding)==1 then return"Quest_DestroyEntities_Building"elseif
Logic.IsEntityTypeInCategory(nHlJ,EntityCategories.AttackableAnimal)==1 then return"Quest_DestroyEntities_Predators"elseif
Logic.IsEntityTypeInCategory(nHlJ,EntityCategories.Hero)==1 then return"Quest_Destroy_Leader"elseif


Logic.IsEntityTypeInCategory(nHlJ,EntityCategories.Military)==1 or
Logic.IsEntityTypeInCategory(nHlJ,EntityCategories.AttackableSettler)==1 or
Logic.IsEntityTypeInCategory(nHlJ,EntityCategories.AttackableMerchant)==1 then return"Quest_DestroyEntities_Unit"end;return"Quest_DestroyEntities"end;Swift:RegisterBehavior(B_Goal_DestroyType)function Goal_EntityDistance(...)return
B_Goal_EntityDistance:new(...)end
B_Goal_EntityDistance={Name="Goal_EntityDistance",Description={en="Goal: Distance between two entities",de="Ziel: Zwei Entities sollen zueinander eine Entfernung über- oder unterschreiten."},Parameter={{ParameterType.ScriptName,en="Entity 1",de="Entity 1"},{ParameterType.ScriptName,en="Entity 2",de="Entity 2"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Distance",de="Entfernung"}}}
function B_Goal_EntityDistance:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_EntityDistance:AddParameter(lw4Q7kbl,IN)
if(lw4Q7kbl==0)then self.Entity1=IN elseif
(lw4Q7kbl==1)then self.Entity2=IN elseif(lw4Q7kbl==2)then self.bRelSmallerThan=IN=="<"elseif
(lw4Q7kbl==3)then self.Distance=IN*1 end end
function B_Goal_EntityDistance:CustomFunction(QYf1)
if Logic.IsEntityDestroyed(self.Entity1)or
Logic.IsEntityDestroyed(self.Entity2)then return false end;local RfsnisO=GetID(self.Entity1)local lvW2ga=GetID(self.Entity2)
local T7RKP=Logic.CheckEntitiesDistance(RfsnisO,lvW2ga,self.Distance)if
(self.bRelSmallerThan and T7RKP)or(not self.bRelSmallerThan and
not T7RKP)then return true end end
function B_Goal_EntityDistance:GetCustomData(_L6Bs)local SH={}if _L6Bs==2 then table.insert(SH,">")
table.insert(SH,"<")else assert(false)end;return SH end
function B_Goal_EntityDistance:Debug(wU4wYbA9)
if not IsExisting(self.Entity1)or not
IsExisting(self.Entity2)then
error(wU4wYbA9.Identifier..
": "..self.Name..
": At least 1 of the entities for distance check don't exist!")return true end;return false end;Swift:RegisterBehavior(B_Goal_EntityDistance)function Goal_KnightDistance(...)return
B_Goal_KnightDistance:new(...)end
B_Goal_KnightDistance={Name="Goal_KnightDistance",Description={en="Goal: Bring the knight close to a given entity. If the distance is left at 0 it will automatically set to 2500.",de="Ziel: Bringe den Ritter nah an eine bestimmte Entität. Wird die Entfernung 0 gelassen, ist sie automatisch 2500."},Parameter={{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Number,en="Distance",de="Entfernung"}}}
function B_Goal_KnightDistance:GetGoalTable()return
{Objective.Distance,-65566,self.Target,self.Distance,true}end
function B_Goal_KnightDistance:AddParameter(fFeQcIM,JEHSHPh3)
if(fFeQcIM==0)then self.Target=JEHSHPh3 elseif
(fFeQcIM==1)then
if JEHSHPh3 ==nil or JEHSHPh3 ==""then JEHSHPh3=0 end;self.Distance=JEHSHPh3*1
if self.Distance==0 then self.Distance=2500 end end end;Swift:RegisterBehavior(B_Goal_KnightDistance)function Goal_UnitsOnTerritory(...)return
B_Goal_UnitsOnTerritory:new(...)end
B_Goal_UnitsOnTerritory={Name="Goal_UnitsOnTerritory",Description={en="Goal: Place a certain amount of units on a territory",de="Ziel: Platziere eine bestimmte Anzahl Einheiten auf einem Gebiet"},Parameter={{ParameterType.TerritoryNameWithUnknown,en="Territory",de="Territorium"},{ParameterType.Custom,en="Player",de="Spieler"},{ParameterType.Custom,en="Category",de="Kategorie"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Number of units",de="Anzahl Einheiten"}}}
function B_Goal_UnitsOnTerritory:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_UnitsOnTerritory:AddParameter(bb,o5e6fP)
if(bb==0)then
self.TerritoryID=tonumber(o5e6fP)if self.TerritoryID==nil then
self.TerritoryID=GetTerritoryIDByName(o5e6fP)end elseif(bb==1)then
self.PlayerID=tonumber(o5e6fP)*1 elseif(bb==2)then self.Category=o5e6fP elseif(bb==3)then
self.bRelSmallerThan=(
tostring(o5e6fP)=="true"or tostring(o5e6fP)=="<")elseif(bb==4)then self.NumberOfUnits=o5e6fP*1 end end
function B_Goal_UnitsOnTerritory:CustomFunction(iq7ol)
local eMV=API.GetEntitiesOfCategoryInTerritory(self.PlayerID,EntityCategories[self.Category],self.TerritoryID)
if
self.bRelSmallerThan==false and#eMV>=self.NumberOfUnits then return true elseif
self.bRelSmallerThan==true and#eMV<self.NumberOfUnits then return true end end
function B_Goal_UnitsOnTerritory:GetCustomData(WDTNkTD)local Oejsws={}
if WDTNkTD==1 then
table.insert(Oejsws,-1)for CkD73N0=1,8 do table.insert(Oejsws,CkD73N0)end elseif
WDTNkTD==2 then
for PlwhaRKJ,Caz4NM4Z in pairs(EntityCategories)do if not string.find(PlwhaRKJ,"^G_")and PlwhaRKJ~=
"SheepPasture"then
table.insert(Oejsws,PlwhaRKJ)end end;table.sort(Oejsws)elseif WDTNkTD==3 then
table.insert(Oejsws,">=")table.insert(Oejsws,"<")else assert(false)end;return Oejsws end
function B_Goal_UnitsOnTerritory:Debug(XVxxx)
local hD={Logic.GetTerritories()}
if

tonumber(self.TerritoryID)==nil or self.TerritoryID<0 or not table.contains(hD,self.TerritoryID)then
error(XVxxx.Identifier..
": "..self.Name..": got an invalid territoryID!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<0 or self.PlayerID>8 then
error(XVxxx.Identifier..": "..self.Name..
": got an invalid playerID!")return true elseif not EntityCategories[self.Category]then
error(XVxxx.Identifier..": "..
self.Name..": got an invalid entity category!")return true elseif tonumber(self.NumberOfUnits)==nil or
self.NumberOfUnits<0 then
error(XVxxx.Identifier..": "..
self.Name..": amount is negative or nil!")return true end;return false end;Swift:RegisterBehavior(B_Goal_UnitsOnTerritory)function Goal_ActivateBuff(...)return
B_Goal_ActivateBuff:new(...)end
B_Goal_ActivateBuff={Name="Goal_ActivateBuff",Description={en="Goal: Activate a buff",de="Ziel: Aktiviere einen Buff"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Buff",de="Buff"}}}
function B_Goal_ActivateBuff:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_ActivateBuff:AddParameter(G5BuU5,AfwsY)
if(G5BuU5 ==0)then self.PlayerID=AfwsY*1 elseif
(G5BuU5 ==1)then self.BuffName=AfwsY;self.Buff=Buffs[AfwsY]end end
function B_Goal_ActivateBuff:CustomFunction(T)
if
not T.QuestDescription or T.QuestDescription==""then
local ITdz=Swift:CopyTable(Swift.Behavior.Text.ActivateBuff.BuffsVanilla)if g_GameExtraNo>=1 then
ITdz=Swift:CopyTable(Swift.Behavior.Text.ActivateBuff.BuffsEx1,ITdz)end
Swift:ChangeCustomQuestCaptionText(string.format(Swift:GetTextOfDesiredLanguage(Swift.Behavior.Text.ActivateBuff.Pattern),Swift:GetTextOfDesiredLanguage(ITdz[self.BuffName])),T)end;local WZs=Logic.GetBuff(self.PlayerID,self.Buff)if
WZs and WZs~=0 then return true end end
function B_Goal_ActivateBuff:GetCustomData(AjfoUo)local Er9zidsB={}
if AjfoUo==1 then
Er9zidsB={"Buff_Spice","Buff_Colour","Buff_Entertainers","Buff_FoodDiversity","Buff_ClothesDiversity","Buff_HygieneDiversity","Buff_EntertainmentDiversity","Buff_Sermon","Buff_Festival","Buff_ExtraPayment","Buff_HighTaxes","Buff_NoPayment","Buff_NoTaxes"}
if g_GameExtraNo>=1 then table.insert(Er9zidsB,"Buff_Gems")
table.insert(Er9zidsB,"Buff_MusicalInstrument")table.insert(Er9zidsB,"Buff_Olibanum")end;table.sort(Er9zidsB)else assert(false)end;return Er9zidsB end
function B_Goal_ActivateBuff:GetIcon()
local X={[Buffs.Buff_Spice]="Goods.G_Salt",[Buffs.Buff_Colour]="Goods.G_Dye",[Buffs.Buff_Entertainers]="Entities.U_Entertainer_NA_FireEater",[Buffs.Buff_FoodDiversity]="Needs.Nutrition",[Buffs.Buff_ClothesDiversity]="Needs.Clothes",[Buffs.Buff_HygieneDiversity]="Needs.Hygiene",[Buffs.Buff_EntertainmentDiversity]="Needs.Entertainment",[Buffs.Buff_Sermon]="Technologies.R_Sermon",[Buffs.Buff_Festival]="Technologies.R_Festival",[Buffs.Buff_ExtraPayment]={1,8},[Buffs.Buff_HighTaxes]={1,6},[Buffs.Buff_NoPayment]={1,8},[Buffs.Buff_NoTaxes]={1,6}}
if g_GameExtraNo and g_GameExtraNo>=1 then
X[Buffs.Buff_Gems]="Goods.G_Gems"
X[Buffs.Buff_MusicalInstrument]="Goods.G_MusicalInstrument"X[Buffs.Buff_Olibanum]="Goods.G_Olibanum"end;return X[self.Buff]end
function B_Goal_ActivateBuff:Debug(dR)
if not self.Buff then
error(dR.Identifier..
": "..self.Name..": buff '"..self.BuffName..
"' does not exist!")return true elseif
not tonumber(self.PlayerID)or self.PlayerID<1 or self.PlayerID>8 then
error(dR.Identifier..": "..self.Name..
": got an invalid playerID!")return true end;return false end;Swift:RegisterBehavior(B_Goal_ActivateBuff)function Goal_BuildRoad(...)return
B_Goal_BuildRoad:new(...)end
B_Goal_BuildRoad={Name="Goal_BuildRoad",Description={en="Goal: Connect two points with a street or a road",de="Ziel: Verbinde zwei Punkte mit einer Strasse oder einem Weg."},Parameter={{ParameterType.ScriptName,en="Entity 1",de="Entity 1"},{ParameterType.ScriptName,en="Entity 2",de="Entity 2"},{ParameterType.Custom,en="Only roads",de="Nur Strassen"}}}
function B_Goal_BuildRoad:GetGoalTable()return
{Objective.BuildRoad,{GetID(self.Entity1),GetID(self.Entity2),false,0,self.bRoadsOnly}}end
function B_Goal_BuildRoad:AddParameter(JFXtQwy,uMV17h0)
if(JFXtQwy==0)then self.Entity1=uMV17h0 elseif(JFXtQwy==1)then
self.Entity2=uMV17h0 elseif(JFXtQwy==2)then self.bRoadsOnly=API.ToBoolean(uMV17h0)end end;function B_Goal_BuildRoad:GetCustomData(E2NZK)local WNWWe
if E2NZK==2 then WNWWe={"true","false"}end;return WNWWe end
function B_Goal_BuildRoad:Debug(zMzjn3lk)
if
not IsExisting(self.Entity1)or
not IsExisting(self.Entity2)then
error(zMzjn3lk.Identifier..": "..self.Name..
": first or second entity does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Goal_BuildRoad)function Goal_BuildWall(...)return
B_Goal_BuildWall:new(...)end
B_Goal_BuildWall={Name="Goal_BuildWall",Description={en="Goal: Build a wall between 2 positions bo stop the movement of an (hostile) player.",de="Ziel: Baue eine Mauer zwischen 2 Punkten, die die Bewegung eines (feindlichen) Spielers zwischen den Punkten verhindert."},Parameter={{ParameterType.PlayerID,en="Enemy",de="Feind"},{ParameterType.ScriptName,en="Entity 1",de="Entity 1"},{ParameterType.ScriptName,en="Entity 2",de="Entity 2"}}}function B_Goal_BuildWall:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_BuildWall:AddParameter(Trkkpmd,L)
if(
Trkkpmd==0)then self.PlayerID=L*1 elseif(Trkkpmd==1)then self.EntityName1=L elseif
(Trkkpmd==2)then self.EntityName2=L end end
function B_Goal_BuildWall:CustomFunction(GGv)local ZIzh4Si=GetID(self.EntityName1)
local c8D4n81=GetID(self.EntityName2)if not IsExisting(ZIzh4Si)then return false end;if not
IsExisting(c8D4n81)then return false end
local cSjJHx,fa,M=Logic.EntityGetPos(ZIzh4Si)if Logic.IsBuilding(ZIzh4Si)==1 then
cSjJHx,fa=Logic.GetBuildingApproachPosition(ZIzh4Si)end
local dIZlrvD=Logic.GetPlayerSectorAtPosition(self.PlayerID,cSjJHx,fa)local cSjJHx,fa,M=Logic.EntityGetPos(c8D4n81)if
Logic.IsBuilding(c8D4n81)==1 then
cSjJHx,fa=Logic.GetBuildingApproachPosition(c8D4n81)end
local jQgsATKd=Logic.GetPlayerSectorAtPosition(self.PlayerID,cSjJHx,fa)if dIZlrvD~=jQgsATKd then return true end;return nil end
function B_Goal_BuildWall:GetMsgKey()return"Quest_Create_Wall"end;function B_Goal_BuildWall:GetIcon()return{3,9}end
function B_Goal_BuildWall:Debug(aBbGg)
if
not
IsExisting(self.EntityName1)or not IsExisting(self.EntityName2)then
error(aBbGg.Identifier..
": "..self.Name..": first or second entity does not exist!")return true elseif
not tonumber(self.PlayerID)or self.PlayerID<1 or self.PlayerID>8 then
error(aBbGg.Identifier..": "..self.Name..
": got an invalid playerID!")return true end
if
GetDiplomacyState(aBbGg.ReceivingPlayer,self.PlayerID)>-1 and not self.WarningPrinted then
warn(
aBbGg.Identifier..
": "..self.Name..": player %d is neighter enemy or unknown to quest receiver!")self.WarningPrinted=true end;return false end;Swift:RegisterBehavior(B_Goal_BuildWall)function Goal_Claim(...)return
B_Goal_Claim:new(...)end
B_Goal_Claim={Name="Goal_Claim",Description={en="Goal: Claim a territory",de="Ziel: Erobere ein Territorium"},Parameter={{ParameterType.TerritoryName,en="Territory",de="Territorium"}}}function B_Goal_Claim:GetGoalTable()
return{Objective.Claim,1,self.TerritoryID}end
function B_Goal_Claim:AddParameter(D9,G)if(D9 ==0)then
self.TerritoryID=tonumber(G)
if not self.TerritoryID then self.TerritoryID=GetTerritoryIDByName(G)end end end
function B_Goal_Claim:GetMsgKey()return"Quest_Claim_Territory"end;Swift:RegisterBehavior(B_Goal_Claim)function Goal_ClaimXTerritories(...)return
B_Goal_ClaimXTerritories:new(...)end
B_Goal_ClaimXTerritories={Name="Goal_ClaimXTerritories",Description={en="Goal: Claim the given number of territories, all player territories are counted",de="Ziel: Erobere die angegebene Anzahl Territorien, alle spielereigenen Territorien werden gezählt"},Parameter={{ParameterType.Number,en="Territories",de="Territorien"}}}
function B_Goal_ClaimXTerritories:GetGoalTable()return
{Objective.Claim,2,self.TerritoriesToClaim}end;function B_Goal_ClaimXTerritories:AddParameter(gE,QgC)
if(gE==0)then self.TerritoriesToClaim=QgC*1 end end;function B_Goal_ClaimXTerritories:GetMsgKey()return
"Quest_Claim_Territory"end
Swift:RegisterBehavior(B_Goal_ClaimXTerritories)
function Goal_Create(...)return B_Goal_Create:new(...)end
B_Goal_Create={Name="Goal_Create",Description={en="Goal: Create Buildings/Units on a specified territory",de="Ziel: Erstelle Einheiten/Gebäude auf einem bestimmten Territorium."},Parameter={{ParameterType.Entity,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.TerritoryNameWithUnknown,en="Territory",de="Territorium"}}}
function B_Goal_Create:GetGoalTable()return
{Objective.Create,assert(Entities[self.EntityName]),self.Amount,self.TerritoryID}end
function B_Goal_Create:AddParameter(CYoa,K3ipRr)
if(CYoa==0)then self.EntityName=K3ipRr elseif(CYoa==1)then
self.Amount=K3ipRr*1 elseif(CYoa==2)then self.TerritoryID=tonumber(K3ipRr)if not self.TerritoryID then
self.TerritoryID=GetTerritoryIDByName(K3ipRr)end end end
function B_Goal_Create:GetMsgKey()
return


Logic.IsEntityTypeInCategory(Entities[self.EntityName],EntityCategories.AttackableBuilding)==1 and"Quest_Create_Building"or"Quest_Create_Unit"end;Swift:RegisterBehavior(B_Goal_Create)function Goal_Produce(...)return
B_Goal_Produce:new(...)end
B_Goal_Produce={Name="Goal_Produce",Description={en="Goal: Produce an amount of goods",de="Ziel: Produziere eine Anzahl einer bestimmten Ware."},Parameter={{ParameterType.RawGoods,en="Type of good",de="Ressourcentyp"},{ParameterType.Number,en="Amount of good",de="Anzahl der Ressource"}}}
function B_Goal_Produce:GetGoalTable()
local F2tY=Logic.GetGoodTypeID(self.GoodTypeName)return{Objective.Produce,F2tY,self.GoodAmount}end
function B_Goal_Produce:AddParameter(rb21L2,o_v255)if(rb21L2 ==0)then self.GoodTypeName=o_v255 elseif(rb21L2 ==1)then self.GoodAmount=
o_v255*1 end end;function B_Goal_Produce:GetMsgKey()return"Quest_Produce"end
Swift:RegisterBehavior(B_Goal_Produce)
function Goal_GoodAmount(...)return B_Goal_GoodAmount:new(...)end
B_Goal_GoodAmount={Name="Goal_GoodAmount",Description={en="Goal: Obtain an amount of goods - either by trading or producing them",de="Ziel: Beschaffe eine Anzahl Waren - entweder durch Handel oder durch eigene Produktion."},Parameter={{ParameterType.Custom,en="Type of good",de="Warentyp"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.Custom,en="Relation",de="Relation"}}}
function B_Goal_GoodAmount:GetGoalTable()
local wUVm=Logic.GetGoodTypeID(self.GoodTypeName)
return{Objective.Produce,wUVm,self.GoodAmount,self.bRelSmallerThan}end
function B_Goal_GoodAmount:AddParameter(VQ,oTYNsnP)
if(VQ==0)then self.GoodTypeName=oTYNsnP elseif(VQ==1)then self.GoodAmount=
oTYNsnP*1 elseif(VQ==2)then self.bRelSmallerThan=oTYNsnP=="<"or
tostring(oTYNsnP)=="true"end end
function B_Goal_GoodAmount:GetCustomData(I)local L={}
if I==0 then
for mR5gwW,DfbW in pairs(Goods)do if string.find(mR5gwW,"^G_")then
table.insert(L,mR5gwW)end end;table.sort(L)elseif I==2 then table.insert(L,">=")
table.insert(L,"<")else assert(false)end;return L end;Swift:RegisterBehavior(B_Goal_GoodAmount)function Goal_SatisfyNeed(...)return
B_Goal_SatisfyNeed:new(...)end
B_Goal_SatisfyNeed={Name="Goal_SatisfyNeed",Description={en="Goal: Satisfy a need",de="Ziel: Erfuelle ein Beduerfnis"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Need,en="Need",de="Beduerfnis"}}}
function B_Goal_SatisfyNeed:GetGoalTable()return
{Objective.SatisfyNeed,Needs[self.Need],self.PlayerID}end
function B_Goal_SatisfyNeed:AddParameter(sh,rrFLbCtj)if(sh==0)then self.PlayerID=rrFLbCtj*1 elseif(sh==1)then
self.Need=rrFLbCtj end end
function B_Goal_SatisfyNeed:GetMsgKey()
local YcPea0vg={[Needs.Clothes]="Quest_SatisfyNeed_Clothes",[Needs.Entertainment]="Quest_SatisfyNeed_Entertainment",[Needs.Nutrition]="Quest_SatisfyNeed_Food",[Needs.Hygiene]="Quest_SatisfyNeed_Hygiene",[Needs.Medicine]="Quest_SatisfyNeed_Medicine"}local usLpLoaH=YcPea0vg[Needs[self.Need]]
if usLpLoaH then return usLpLoaH end end;Swift:RegisterBehavior(B_Goal_SatisfyNeed)function Goal_SettlersNumber(...)return
B_Goal_SettlersNumber:new(...)end
B_Goal_SettlersNumber={Name="Goal_SettlersNumber",Description={en="Goal: Get a given amount of settlers",de="Ziel: Erreiche eine bestimmte Anzahl Siedler."},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function B_Goal_SettlersNumber:GetGoalTable()return
{Objective.SettlersNumber,self.PlayerID or 1,self.SettlersAmount}end
function B_Goal_SettlersNumber:AddParameter(e7dv,inx0)if(e7dv==0)then self.SettlersAmount=inx0*1 elseif
(e7dv==1)then self.PlayerID=inx0*1 end end
function B_Goal_SettlersNumber:GetMsgKey()return"Quest_NumberSettlers"end;Swift:RegisterBehavior(B_Goal_SettlersNumber)function Goal_Spouses(...)return
B_Goal_Spouses:new(...)end
B_Goal_Spouses={Name="Goal_Spouses",Description={en="Goal: Get a given amount of spouses",de="Ziel: Erreiche eine bestimmte Ehefrauenanzahl"},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"}}}function B_Goal_Spouses:GetGoalTable()
return{Objective.Spouses,self.SpousesAmount}end
function B_Goal_Spouses:AddParameter(A5k5yt,B7SHDx7h)if
(A5k5yt==0)then self.SpousesAmount=B7SHDx7h*1 end end
function B_Goal_Spouses:GetMsgKey()return"Quest_NumberSpouses"end;Swift:RegisterBehavior(B_Goal_Spouses)function Goal_SoldierCount(...)return
B_Goal_SoldierCount:new(...)end
B_Goal_SoldierCount={Name="Goal_SoldierCount",Description={en="Goal: Create a specified number of soldiers",de="Ziel: Erreiche eine Anzahl grösser oder kleiner der angegebenen Menge Soldaten."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Number of soldiers",de="Anzahl Soldaten"}}}
function B_Goal_SoldierCount:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_SoldierCount:AddParameter(EEpoeR,_k)
if(EEpoeR==0)then self.PlayerID=_k*1 elseif(EEpoeR==1)then
self.bRelSmallerThan=
tostring(_k)=="true"or tostring(_k)=="<"elseif(EEpoeR==2)then self.NumberOfUnits=_k*1 end end
function B_Goal_SoldierCount:CustomFunction(Ef)
if
not Ef.QuestDescription or Ef.QuestDescription==""then local Vd=tostring(self.bRelSmallerThan)local Oynw=
GetPlayerName(self.PlayerID)or""
Swift:ChangeCustomQuestCaptionText(string.format(Swift:GetTextOfDesiredLanguage(Swift.Behavior.Text.SoldierCount.Pattern),Oynw,Swift:GetTextOfDesiredLanguage(Swift.Behavior.Text.SoldierCount.Relation[Vd]),self.NumberOfUnits),Ef)end;local KfM=Logic.GetCurrentSoldierCount(self.PlayerID)
if(
self.bRelSmallerThan and KfM<self.NumberOfUnits)then
return true elseif
(not self.bRelSmallerThan and KfM>=self.NumberOfUnits)then return true end;return nil end
function B_Goal_SoldierCount:GetCustomData(QBO)local s4ggux={}
if QBO==1 then
table.insert(s4ggux,">=")table.insert(s4ggux,"<")else assert(false)end;return s4ggux end;function B_Goal_SoldierCount:GetIcon()return{7,11}end;function B_Goal_SoldierCount:GetMsgKey()return
"Quest_Create_Unit"end
function B_Goal_SoldierCount:Debug(hrVI4meU)
if
tonumber(self.NumberOfUnits)==nil or self.NumberOfUnits<0 then
error(
hrVI4meU.Identifier..": "..self.Name..": amount can not be below 0!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
error(hrVI4meU.Identifier..": "..self.Name..
": got an invalid playerID!")return true end;return false end;Swift:RegisterBehavior(B_Goal_SoldierCount)function Goal_KnightTitle(...)return
B_Goal_KnightTitle:new(...)end
B_Goal_KnightTitle={Name="Goal_KnightTitle",Description={en="Goal: Reach a specified knight title",de="Ziel: Erreiche einen vorgegebenen Titel"},Parameter={{ParameterType.Custom,en="Knight title",de="Titel"}}}
function B_Goal_KnightTitle:GetGoalTable()return
{Objective.KnightTitle,assert(KnightTitles[self.KnightTitle])}end;function B_Goal_KnightTitle:AddParameter(xEq6TAF,UIjls)
if(xEq6TAF==0)then self.KnightTitle=UIjls end end;function B_Goal_KnightTitle:GetMsgKey()return
"Quest_KnightTitle"end
function B_Goal_KnightTitle:GetCustomData(jdLnB0vD)return
{"Knight","Mayor","Baron","Earl","Marquees","Duke","Archduke"}end;Swift:RegisterBehavior(B_Goal_KnightTitle)function Goal_Festivals(...)return
B_Goal_Festivals:new(...)end
B_Goal_Festivals={Name="Goal_Festivals",Description={en="Goal: The player has to start the given number of festivals.",de="Ziel: Der Spieler muss eine gewisse Anzahl Feste gestartet haben."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Number,en="Number of festivals",de="Anzahl Feste"}}}function B_Goal_Festivals:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_Festivals:AddParameter(PSlD,nN)
if
PSlD==0 then self.PlayerID=tonumber(nN)else
assert(PSlD==1,"Error in "..self.Name..
": AddParameter: Index is invalid.")self.NeededFestivals=tonumber(nN)end end
function B_Goal_Festivals:CustomFunction(J)
if
not J.QuestDescription or J.QuestDescription==""then local qHpY64=GetPlayerName(self.PlayerID)or""
Swift:ChangeCustomQuestCaptionText(string.format(Swift:GetTextOfDesiredLanguage(Swift.Behavior.Text.Festivals.Pattern),qHpY64,self.NeededFestivals),J)end
if Logic.GetStoreHouse(self.PlayerID)==0 then return false end
local A={Logic.GetPlayerEntities(self.PlayerID,Entities.B_TableBeer,5,0)}local g3Qeqnr=0
for z=2,#A do local qccJ5b=A[z]
if
Logic.GetIndexOnOutStockByGoodType(qccJ5b,Goods.G_Beer)~=-1 then
local ARuba=Logic.GetAmountOnOutStockByGoodType(qccJ5b,Goods.G_Beer)g3Qeqnr=g3Qeqnr+ARuba end end
if not self.FestivalStarted and g3Qeqnr>0 then
self.FestivalStarted=true;self.FestivalCounter=
(self.FestivalCounter and self.FestivalCounter+1)or 1
if
self.FestivalCounter>=self.NeededFestivals then self.FestivalCounter=nil;return true end elseif g3Qeqnr==0 then self.FestivalStarted=false end end
function B_Goal_Festivals:Debug(Wo53nZ)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
error(Wo53nZ.Identifier..": "..self.Name..
": Player "..self.PlayerID.." is dead :-(")return true elseif
GetPlayerCategoryType(self.PlayerID)~=PlayerCategories.City then
error(Wo53nZ.Identifier..": "..self.Name..
":  Player "..self.PlayerID.." is no city")return true elseif self.NeededFestivals<0 then
error(Wo53nZ.Identifier..": "..
self.Name..": Number of Festivals is negative")return true end;return false end
function B_Goal_Festivals:Reset()self.FestivalCounter=nil;self.FestivalStarted=nil end;function B_Goal_Festivals:GetIcon()return{4,15}end
Swift:RegisterBehavior(B_Goal_Festivals)
function Goal_Capture(...)return B_Goal_Capture:new(...)end
B_Goal_Capture={Name="Goal_Capture",Description={en="Goal: Capture a cart.",de="Ziel: Ein Karren muss erobert werden."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}function B_Goal_Capture:GetGoalTable()
return{Objective.Capture,1,{self.ScriptName}}end;function B_Goal_Capture:AddParameter(XRfQ,gFPRdEC)if(XRfQ==0)then
self.ScriptName=gFPRdEC end end
function B_Goal_Capture:GetMsgKey()
local lw9gLt3=GetID(self.ScriptName)
if Logic.IsEntityAlive(lw9gLt3)then
lw9gLt3=Logic.GetEntityType(lw9gLt3)
if lw9gLt3 and lw9gLt3 ~=0 then
if
Logic.IsEntityTypeInCategory(lw9gLt3,EntityCategories.AttackableMerchant)==1 then return"Quest_Capture_Cart"elseif
Logic.IsEntityTypeInCategory(lw9gLt3,EntityCategories.SiegeEngine)==1 then return"Quest_Capture_SiegeEngine"elseif


Logic.IsEntityTypeInCategory(lw9gLt3,EntityCategories.Worker)==1 or
Logic.IsEntityTypeInCategory(lw9gLt3,EntityCategories.Spouse)==1 or
Logic.IsEntityTypeInCategory(lw9gLt3,EntityCategories.Hero)==1 then return"Quest_Capture_VIPOfPlayer"end end end end;Swift:RegisterBehavior(B_Goal_Capture)function Goal_CaptureType(...)return
B_Goal_CaptureType:new(...)end
B_Goal_CaptureType={Name="Goal_CaptureType",Description={en="Goal: Capture specified entity types",de="Ziel: Nimm bestimmte Entitätstypen gefangen"},Parameter={{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function B_Goal_CaptureType:GetGoalTable()return
{Objective.Capture,2,Entities[self.EntityName],self.Amount,self.PlayerID}end
function B_Goal_CaptureType:AddParameter(T,I5)
if(T==0)then self.EntityName=I5 elseif(T==1)then self.Amount=I5*1 elseif(
T==2)then self.PlayerID=I5*1 end end
function B_Goal_CaptureType:GetCustomData(JmE)local s4={}
if JmE==0 then
for FFG,a31jEAS in pairs(Entities)do
if

string.find(FFG,"^U_.+Cart")or
Logic.IsEntityTypeInCategory(a31jEAS,EntityCategories.AttackableMerchant)==1 then table.insert(s4,FFG)end end;table.sort(s4)elseif JmE==2 then
for LS4h=0,8 do table.insert(s4,LS4h)end else assert(false)end;return s4 end
function B_Goal_CaptureType:GetMsgKey()local eux092_P=self.EntityName
if
Logic.IsEntityTypeInCategory(eux092_P,EntityCategories.AttackableMerchant)==1 then return"Quest_Capture_Cart"elseif
Logic.IsEntityTypeInCategory(eux092_P,EntityCategories.SiegeEngine)==1 then return"Quest_Capture_SiegeEngine"elseif


Logic.IsEntityTypeInCategory(eux092_P,EntityCategories.Worker)==1 or
Logic.IsEntityTypeInCategory(eux092_P,EntityCategories.Spouse)==1 or
Logic.IsEntityTypeInCategory(eux092_P,EntityCategories.Hero)==1 then return"Quest_Capture_VIPOfPlayer"end end;Swift:RegisterBehavior(B_Goal_CaptureType)function Goal_Protect(...)return
B_Goal_Protect:new(...)end
B_Goal_Protect={Name="Goal_Protect",Description={en="Goal: Protect an entity (entity needs a script name",de="Ziel: Beschütze eine Entität (Entität benötigt einen Skriptnamen)"},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}function B_Goal_Protect:GetGoalTable()
return{Objective.Protect,{self.ScriptName}}end;function B_Goal_Protect:AddParameter(ZA9,hWgmxm)if(ZA9 ==0)then
self.ScriptName=hWgmxm end end
function B_Goal_Protect:GetMsgKey()
if
Logic.IsEntityAlive(self.ScriptName)then local UBg54E=GetID(self.ScriptName)
if UBg54E and UBg54E~=0 then
UBg54E=Logic.GetEntityType(UBg54E)
if UBg54E and UBg54E~=0 then
if
Logic.IsEntityTypeInCategory(UBg54E,EntityCategories.AttackableBuilding)==1 then return"Quest_Protect_Building"elseif
Logic.IsEntityTypeInCategory(UBg54E,EntityCategories.SpecialBuilding)==1 then
local gQGq={[PlayerCategories.City]="Quest_Protect_City",[PlayerCategories.Cloister]="Quest_Protect_Cloister",[PlayerCategories.Village]="Quest_Protect_Village"}
local OyHc5FEv=GetPlayerCategoryType(Logic.EntityGetPlayer(GetID(self.ScriptName)))
if OyHc5FEv then local Dn1Xi=gQGq[OyHc5FEv]if Dn1Xi then return Dn1Xi end end;return"Quest_Protect_Building"elseif
Logic.IsEntityTypeInCategory(UBg54E,EntityCategories.Hero)==1 then return"Quest_Protect_Knight"elseif
Logic.IsEntityTypeInCategory(UBg54E,EntityCategories.AttackableMerchant)==1 then return"Quest_Protect_Cart"end end end end;return"Quest_Protect"end;Swift:RegisterBehavior(B_Goal_Protect)function Goal_Refill(...)return
B_Goal_Refill:new(...)end
B_Goal_Refill={Name="Goal_Refill",Description={en="Goal: Refill an object using a geologist",de="Ziel: Eine Mine soll durch einen Geologen wieder aufgefuellt werden."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}},RequiresExtraNo=1}function B_Goal_Refill:GetGoalTable()return
{Objective.Refill,{GetID(self.ScriptName)}}end;function B_Goal_Refill:GetIcon()return
{8,1,1}end;function B_Goal_Refill:AddParameter(_gGmBBE,rIX4)if(_gGmBBE==0)then
self.ScriptName=rIX4 end end
if
g_GameExtraNo>0 then Swift:RegisterBehavior(B_Goal_Refill)end
function Goal_ResourceAmount(...)return B_Goal_ResourceAmount:new(...)end
B_Goal_ResourceAmount={Name="Goal_ResourceAmount",Description={en="Goal: Reach a specified amount of resources in a doodad",de="Ziel: In einer Mine soll weniger oder mehr als eine angegebene Anzahl an Rohstoffen sein."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Amount",de="Menge"}}}
function B_Goal_ResourceAmount:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_ResourceAmount:AddParameter(AI14eFhp,iW2O)
if(AI14eFhp==0)then self.ScriptName=iW2O elseif
(AI14eFhp==1)then self.bRelSmallerThan=iW2O=="<"elseif(AI14eFhp==2)then self.Amount=iW2O*1 end end
function B_Goal_ResourceAmount:CustomFunction(Gdp)local nbqmx=GetID(self.ScriptName)
if
nbqmx and
nbqmx~=0 and Logic.GetResourceDoodadGoodType(nbqmx)~=0 then local IWQcC=Logic.GetResourceDoodadGoodAmount(nbqmx)if
(
self.bRelSmallerThan and IWQcC<self.Amount)or(
not self.bRelSmallerThan and IWQcC>=self.Amount)then return true end end;return nil end
function B_Goal_ResourceAmount:GetCustomData(cvRh)local W9yaJm={}
if cvRh==1 then
table.insert(W9yaJm,">=")table.insert(W9yaJm,"<")else assert(false)end;return W9yaJm end
function B_Goal_ResourceAmount:Debug(oJ1ec)
if not IsExisting(self.ScriptName)then
error(
oJ1ec.Identifier..": "..self.Name..
": entity '"..self.ScriptName.."' does not exist!")return true elseif
tonumber(self.Amount)==nil or self.Amount<0 then
error(oJ1ec.Identifier..
": "..self.Name..": error at amount! (nil or below 0)")return true end;return false end;Swift:RegisterBehavior(B_Goal_ResourceAmount)function Goal_InstantFailure()return
B_Goal_InstantFailure:new()end
B_Goal_InstantFailure={Name="Goal_InstantFailure",Description={en="Goal: Instant failure, the goal returns false.",de="Ziel: Direkter Misserfolg, das Goal sendet false."}}
function B_Goal_InstantFailure:GetGoalTable()return{Objective.DummyFail}end;Swift:RegisterBehavior(B_Goal_InstantFailure)function Goal_InstantSuccess()return
B_Goal_InstantSuccess:new()end
B_Goal_InstantSuccess={Name="Goal_InstantSuccess",Description={en="Goal: Instant success, the goal returns true.",de="Ziel: Direkter Erfolg, das Goal sendet true."}}
function B_Goal_InstantSuccess:GetGoalTable()return{Objective.Dummy}end;Swift:RegisterBehavior(B_Goal_InstantSuccess)function Goal_NoChange()return
B_Goal_NoChange:new()end
B_Goal_NoChange={Name="Goal_NoChange",Description={en="Goal: The quest state doesn't change. Use reward functions of other quests to change the state of this quest.",de="Ziel: Der Questzustand wird nicht verändert. Ein Reward einer anderen Quest sollte den Zustand dieser Quest verändern."}}
function B_Goal_NoChange:GetGoalTable()return{Objective.NoChange}end;Swift:RegisterBehavior(B_Goal_NoChange)function Goal_MapScriptFunction(...)return
B_Goal_MapScriptFunction:new(...)end
B_Goal_MapScriptFunction={Name="Goal_MapScriptFunction",Description={en="Goal: Calls a function within the global map script. Return 'true' means success, 'false' means failure and 'nil' doesn't change anything.",de="Ziel: Ruft eine Funktion im globalen Skript auf, die einen Wahrheitswert zurueckgibt. Rueckgabe 'true' gilt als erfuellt, 'false' als gescheitert und 'nil' ändert nichts."},Parameter={{ParameterType.Default,en="Function name",de="Funktionsname"}}}
function B_Goal_MapScriptFunction:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end;function B_Goal_MapScriptFunction:AddParameter(L,MMNWLk)
if(L==0)then self.FuncName=MMNWLk end end
function B_Goal_MapScriptFunction:CustomFunction(x6Ni)if
type(self.FuncName)=="function"then return
self.FuncName(unpack(self.i47ya_6aghw_frxil))end;return
_G[self.FuncName](self,x6Ni)end
function B_Goal_MapScriptFunction:Debug(Q2waXkyp)if not self.FuncName then
error(Q2waXkyp.Identifier..": "..self.Name..
": function reference is invalid!")return true end
if

type(self.FuncName)~="function"and not _G[self.FuncName]then
error(Q2waXkyp.Identifier..
": "..self.Name..": function does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Goal_MapScriptFunction)function Goal_CustomVariables(...)return
B_Goal_CustomVariables:new(...)end
B_Goal_CustomVariables={Name="Goal_CustomVariables",Description={en="Goal: A customised variable has to assume a certain value.",de="Ziel: Eine benutzerdefinierte Variable muss einen bestimmten Wert annehmen."},Parameter={{ParameterType.Default,en="Name of Variable",de="Variablenname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Default,en="Value or variable",de="Wert oder Variable"}}}
function B_Goal_CustomVariables:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_CustomVariables:AddParameter(EG72,mlTMZ)
if EG72 ==0 then self.VariableName=mlTMZ elseif EG72 ==1 then
self.Relation=mlTMZ elseif EG72 ==2 then local q=tonumber(mlTMZ)
q=(q~=nil and q)or tostring(mlTMZ)self.Value=q end end
function B_Goal_CustomVariables:CustomFunction()
local xb6=API.ObtainCustomVariable("BehaviorVariable_"..self.VariableName,0)local yK=self.Value;if type(self.Value)=="string"then
yK=API.ObtainCustomVariable("BehaviorVariable_"..
self.Value,0)end
if self.Relation=="=="then if
xb6 ==yK then return true end elseif self.Relation=="~="then if xb6 ==yK then return true end elseif
self.Relation=="<"then if xb6 <yK then return true end elseif self.Relation=="<="then
if xb6 <=yK then return true end elseif self.Relation==">="then if xb6 >=yK then return true end else
if xb6 >yK then return true end end;return nil end
function B_Goal_CustomVariables:GetCustomData(rHLz2GD)return{"==","~=","<=","<",">",">="}end
function B_Goal_CustomVariables:Debug(BlW0RhJA)local Uy={"==","~=","<=","<",">",">="}
local n={true,false,nil}
if not
API.ObtainCustomVariable("BehaviorVariable_"..self.VariableName)then
warn(BlW0RhJA.Identifier..": "..
self.Name..": variable '"..
self.VariableName.."' do not exist!")end
if not table.contains(Uy,self.Relation)then
error(BlW0RhJA.Identifier..": "..

self.Name..": '"..self.Relation.."' is an invalid relation!")return true end;return false end;Swift:RegisterBehavior(B_Goal_CustomVariables)function Goal_TributeDiplomacy(...)return
B_Goal_TributeDiplomacy:new(...)end
B_Goal_TributeDiplomacy={Name="Goal_TributeDiplomacy",Description={en="Goal: AI requests periodical tribute for better Diplomacy",de="Ziel: Die KI fordert einen regelmässigen Tribut fuer bessere Diplomatie. Der Questgeber ist der fordernde Spieler."},Parameter={{ParameterType.Number,en="Amount",de="Menge"},{ParameterType.Number,en="Time till next peyment in seconds",de="Zeit bis zur Forderung in Sekunden"},{ParameterType.Number,en="Time to pay tribute in seconds",de="Zeit bis zur Zahlung in Sekunden"},{ParameterType.Default,en="Start Message for TributQuest",de="Startnachricht der Tributquest"},{ParameterType.Default,en="Success Message for TributQuest",de="Erfolgsnachricht der Tributquest"},{ParameterType.Default,en="Failure Message for TributQuest",de="Niederlagenachricht der Tributquest"},{ParameterType.Custom,en="Restart if failed to pay",de="Nicht-bezahlen beendet die Quest"}}}
function B_Goal_TributeDiplomacy:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_TributeDiplomacy:AddParameter(TKu,M6kL)
if(TKu==0)then self.Amount=M6kL*1 elseif(TKu==1)then self.PeriodLength=
M6kL*1 elseif(TKu==2)then self.TributTime=M6kL*1 elseif(TKu==3)then
self.StartMsg=M6kL elseif(TKu==4)then self.SuccessMsg=M6kL elseif(TKu==5)then self.FailureMsg=M6kL elseif(TKu==6)then
self.RestartAtFailure=API.ToBoolean(M6kL)end end
function B_Goal_TributeDiplomacy:GetTributeQuest(M7o_)
if not self.InternTributeQuest then
local dk2X7J7=QSB.Language;local jv=self.StartMsg
if type(jv)=="table"then jv=jv[dk2X7J7]end;local MW=self.SuccessMsg
if type(MW)=="table"then MW=MW[dk2X7J7]end;local E2OQ=self.FailureMsg
if type(E2OQ)=="table"then E2OQ=E2OQ[dk2X7J7]end
Swift.Behavior.QuestCounter=Swift.Behavior.QuestCounter+1
local SnbfLb6,ay=QuestTemplate:New(M7o_.Identifier..
"_TributeDiplomacyQuest_"..Swift.Behavior.QuestCounter,M7o_.SendingPlayer,M7o_.ReceivingPlayer,{{Objective.Deliver,{Goods.G_Gold,self.Amount}}},{{Triggers.Time,0}},self.TributTime,
nil,nil,nil,nil,true,true,nil,jv,MW,E2OQ)self.InternTributeQuest=ay end end
function B_Goal_TributeDiplomacy:CheckTributeQuest(W)
if self.InternTributeQuest and self.InternTributeQuest.State==
QuestState.Over and
not self.RestartQuest then
if
self.InternTributeQuest.Result~=QuestResult.Success then
SetDiplomacyState(W.ReceivingPlayer,W.SendingPlayer,DiplomacyStates.Enemy)if not self.RestartAtFailure then return false end else
SetDiplomacyState(W.ReceivingPlayer,W.SendingPlayer,DiplomacyStates.TradeContact)end;self.RestartQuest=true;self.Time=Logic.GetTime()end end
function B_Goal_TributeDiplomacy:CheckTributePlayer(WzM)
local PSx=Logic.GetStoreHouse(WzM.SendingPlayer)
if(PSx==0 or Logic.IsEntityDestroyed(PSx))then
if

self.InternTributeQuest and self.InternTributeQuest.State==QuestState.Active then self.InternTributeQuest:Interrupt()end;return true end end
function B_Goal_TributeDiplomacy:TributQuestRestarter(I)
if
self.InternTributeQuest and self.Time and
self.RestartQuest and(
(Logic.GetTime()-self.Time)>=self.PeriodLength)then
self.InternTributeQuest.Objectives[1].Completed=nil;self.InternTributeQuest.Objectives[1].Data[3]=
nil;self.InternTributeQuest.Objectives[1].Data[4]=
nil;self.InternTributeQuest.Objectives[1].Data[5]=
nil;self.InternTributeQuest.Result=nil
self.InternTributeQuest.State=QuestState.NotTriggered
Logic.ExecuteInLuaLocalState("LocalScriptCallback_OnQuestStatusChanged("..
self.InternTributeQuest.Index..")")
StartSimpleJobEx(_G[QuestTemplate.Loop],self.InternTributeQuest.QueueID)self.RestartQuest=nil end end
function B_Goal_TributeDiplomacy:CustomFunction(wnA)self:GetTributeQuest(wnA)if
self:CheckTributeQuest(wnA)==false then return false end;if
self:CheckTributePlayer(wnA)==true then return true end
self:TributQuestRestarter(wnA)end
function B_Goal_TributeDiplomacy:Debug(cW)if self.Amount<0 then
error(cW.Identifier..": "..
self.Name..": Amount is negative!")return true end;if self.PeriodLength<
self.TributTime then
error(cW.Identifier..
": "..self.Name..": TributTime too long!")return true end end;function B_Goal_TributeDiplomacy:Reset(PHpCof2)self.Time=nil;self.InternTributeQuest=nil;self.RestartQuest=
nil end
function B_Goal_TributeDiplomacy:Interrupt(bUPpn4T2)if
self.InternTributeQuest~=nil then
if
self.InternTributeQuest.State==QuestState.Active then self.InternTributeQuest:Interrupt()end end end;function B_Goal_TributeDiplomacy:GetCustomData(sode)
if(sode==6)then return{"true","false"}end end
Swift:RegisterBehavior(B_Goal_TributeDiplomacy)
function Goal_TributeClaim(...)return B_Goal_TributeClaim:new(...)end
B_Goal_TributeClaim={Name="Goal_TributeClaim",Description={en="Goal: AI requests periodical tribute for a specified territory. The quest sender is the demanding player.",de="Ziel: Die KI fordert einen regelmässigen Tribut fuer ein Territorium. Der Questgeber ist der fordernde Spieler."},Parameter={{ParameterType.TerritoryName,en="Territory",de="Territorium"},{ParameterType.PlayerID,en="PlayerID",de="PlayerID"},{ParameterType.Number,en="Amount",de="Menge"},{ParameterType.Number,en="Length of Period in seconds",de="Sekunden bis zur nächsten Forderung"},{ParameterType.Number,en="Time to pay Tribut in seconds",de="Zeit bis zur Zahlung in Sekunden"},{ParameterType.Default,en="Start Message for TributQuest",de="Startnachricht der Tributquest"},{ParameterType.Default,en="Success Message for TributQuest",de="Erfolgsnachricht der Tributquest"},{ParameterType.Default,en="Failure Message for TributQuest",de="Niederlagenachricht der Tributquest"},{ParameterType.Number,en="How often to pay (0 = forerver)",de="Anzahl der Tributquests (0 = unendlich)"},{ParameterType.Custom,en="Other Owner cancels the Quest",de="Anderer Spieler kann Quest beenden"},{ParameterType.Custom,en="About if a rate is not payed",de="Nicht-bezahlen beendet die Quest"}}}
function B_Goal_TributeClaim:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function B_Goal_TributeClaim:AddParameter(G9zkKODk,MGt)
if(G9zkKODk==0)then if type(MGt)=="string"then
MGt=GetTerritoryIDByName(MGt)end;self.TerritoryID=MGt elseif(G9zkKODk==1)then self.PlayerID=
MGt*1 elseif(G9zkKODk==2)then self.Amount=MGt*1 elseif(G9zkKODk==3)then self.PeriodLength=
MGt*1 elseif(G9zkKODk==4)then self.TributTime=MGt*1 elseif(G9zkKODk==5)then
self.StartMsg=MGt elseif(G9zkKODk==6)then self.SuccessMsg=MGt elseif(G9zkKODk==7)then self.FailureMsg=MGt elseif(
G9zkKODk==8)then self.HowOften=MGt*1 elseif(G9zkKODk==9)then
self.OtherOwnerCancels=API.ToBoolean(MGt)elseif(G9zkKODk==10)then self.DontPayCancels=API.ToBoolean(MGt)end end
function B_Goal_TributeClaim:CureOutpost(ld9GuG4t)
local KpCCA=Logic.GetTerritoryAcquiringBuildingID(self.TerritoryID)
if

IsExisting(KpCCA)and API.GetEntityHealth(KpCCA)<25 and Logic.IsBuildingBeingKnockedDown(KpCCA)==false then while(Logic.GetEntityHealth(KpCCA)<
Logic.GetEntityMaxHealth(KpCCA)*0.6)do
Logic.HealEntity(KpCCA,1)end end end
function B_Goal_TributeClaim:RestartTributeQuest(H6)
if self.InternTributeQuest then self.InternTributeQuest.Objectives[1].Completed=
nil;self.InternTributeQuest.Objectives[1].Data[3]=
nil;self.InternTributeQuest.Objectives[1].Data[4]=
nil;self.InternTributeQuest.Objectives[1].Data[5]=
nil;self.InternTributeQuest.Result=nil
self.InternTributeQuest.State=QuestState.NotTriggered
Logic.ExecuteInLuaLocalState("LocalScriptCallback_OnQuestStatusChanged("..
self.InternTributeQuest.Index..")")
StartSimpleJobEx(_G[QuestTemplate.Loop],self.InternTributeQuest.QueueID)end end
function B_Goal_TributeClaim:CreateTributeQuest(hgsKvTz)
if not self.InternTributeQuest then local zEt=QSB.Language
local Wjojpvg=self.StartMsg
if type(Wjojpvg)=="table"then Wjojpvg=Wjojpvg[zEt]end;local l2PqbWw=self.SuccessMsg
if type(l2PqbWw)=="table"then l2PqbWw=l2PqbWw[zEt]end;local EJTH9=self.FailureMsg
if type(EJTH9)=="table"then EJTH9=EJTH9[zEt]end
Swift.Behavior.QuestCounter=Swift.Behavior.QuestCounter+1
local qTB82=function()self.Time=Logic.GetTime()end
local KL,EATFLbgY=QuestTemplate:New(hgsKvTz.Identifier..
"_TributeClaimQuest"..Swift.Behavior.QuestCounter,self.PlayerID,hgsKvTz.ReceivingPlayer,{{Objective.Deliver,{Goods.G_Gold,self.Amount}}},{{Triggers.Time,0}},self.TributTime,
nil,nil,qTB82,nil,true,true,nil,Wjojpvg,l2PqbWw,EJTH9)self.InternTributeQuest=EATFLbgY end end
function B_Goal_TributeClaim:OnTributeFailed(FF)
local rh=Logic.GetTerritoryAcquiringBuildingID(self.TerritoryID)if IsExisting(rh)then
Logic.ChangeEntityPlayerID(rh,self.PlayerID)end
Logic.SetTerritoryPlayerID(self.TerritoryID,self.PlayerID)self.InternTributeQuest.State=false;self.Time=nil;if self.DontPayCancels then
FF:Interrupt()end end
function B_Goal_TributeClaim:OnTributePaid(YcCR)
local G3p2Yn=Logic.GetTerritoryAcquiringBuildingID(self.TerritoryID)
if self.InternTributeQuest.Result==QuestResult.Success then
if
Logic.GetTerritoryPlayerID(self.TerritoryID)==self.PlayerID then if IsExisting(G3p2Yn)then
Logic.ChangeEntityPlayerID(G3p2Yn,YcCR.ReceivingPlayer)end
Logic.SetTerritoryPlayerID(self.TerritoryID,YcCR.ReceivingPlayer)end end
if self.Time and
Logic.GetTime()>=self.Time+self.PeriodLength then
if self.HowOften and self.HowOften~=0 then self.TributeCounter=(
self.TributeCounter or 0)+1;if
self.TributeCounter>=self.HowOften then return false end end;self:RestartTributeQuest()self.Time=nil end end
function B_Goal_TributeClaim:CustomFunction(_jkkD9)self:CreateTributeQuest(_jkkD9)
self:CureOutpost(_jkkD9)
if
Logic.GetTerritoryPlayerID(self.TerritoryID)==_jkkD9.ReceivingPlayer or
Logic.GetTerritoryPlayerID(self.TerritoryID)==self.PlayerID then
if
self.OtherOwner then self:RestartTributeQuest()self.OtherOwner=nil end
if self.InternTributeQuest.State==QuestState.Over then
if
self.InternTributeQuest.Result==QuestResult.Failure then
self:OnTributeFailed(_jkkD9)else self:OnTributePaid(_jkkD9)end elseif self.InternTributeQuest.State==false then
if
self.Time and Logic.GetTime()>=
self.Time+self.PeriodLength then self:RestartTributeQuest(_jkkD9)end end elseif Logic.GetTerritoryPlayerID(self.TerritoryID)==0 and
self.InternTributeQuest then if self.InternTributeQuest.State==
QuestState.Active then
self.InternTributeQuest:Interrupt()end elseif
Logic.GetTerritoryPlayerID(self.TerritoryID)~=self.PlayerID then if self.InternTributeQuest.State==
QuestState.Active then
self.InternTributeQuest:Interrupt()end;if self.OtherOwnerCancels then
_jkkD9:Interrupt()end;self.OtherOwner=true end;local D=Logic.GetStoreHouse(self.PlayerID)
if(D==0 or
Logic.IsEntityDestroyed(D))then
if
self.InternTributeQuest and
self.InternTributeQuest.State==QuestState.Active then self.InternTributeQuest:Interrupt()end;return true end end
function B_Goal_TributeClaim:Debug(DMn)if self.TerritoryID==0 then
error(DMn.Identifier..": "..
self.Name..": Unknown Territory")return true end
if not self.Quest and
Logic.GetStoreHouse(self.PlayerID)==0 then
error(DMn.Identifier..
": "..self.Name..": Player "..
self.PlayerID.." is dead. :-(")return true end;if self.Amount<0 then
error(DMn.Identifier..
": "..self.Name..": Amount is negative")return true end
if self.PeriodLength<
self.TributTime or self.PeriodLength<1 then
error(
DMn.Identifier..": "..self.Name..": Period Length is wrong")return true end;if self.HowOften<0 then
error(DMn.Identifier..
": "..self.Name..": HowOften is negative")return true end end;function B_Goal_TributeClaim:Reset(GBzFRjVV)self.InternTributeQuest=nil;self.Time=nil
self.OtherOwner=nil end
function B_Goal_TributeClaim:Interrupt(pG4C8fDK)if
type(self.InternTributeQuest)=="table"then
if
self.InternTributeQuest.State==QuestState.Active then self.InternTributeQuest:Interrupt()end end end
function B_Goal_TributeClaim:GetCustomData(LLFUU)if(LLFUU==9)or(LLFUU==10)then return
{"false","true"}end end;Swift:RegisterBehavior(B_Goal_TributeClaim)function Reprisal_ObjectDeactivate(...)return
B_Reprisal_InteractiveObjectDeactivate:new(...)end
B_Reprisal_InteractiveObjectDeactivate={Name="Reprisal_InteractiveObjectDeactivate",Description={en="Reprisal: Deactivates an interactive object",de="Vergeltung: Deaktiviert ein interaktives Objekt"},Parameter={{ParameterType.ScriptName,en="Interactive object",de="Interaktives Objekt"}}}
function B_Reprisal_InteractiveObjectDeactivate:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_InteractiveObjectDeactivate:AddParameter(kdmQtj6,Hc35_)if(kdmQtj6 ==0)then
self.ScriptName=Hc35_ end end;function B_Reprisal_InteractiveObjectDeactivate:CustomFunction(ubP)
InteractiveObjectDeactivate(self.ScriptName)end
function B_Reprisal_InteractiveObjectDeactivate:Debug(eN0UMW)
if

not Logic.IsInteractiveObject(GetID(self.ScriptName))then
warn(eN0UMW.Identifier..": "..self.Name..
": '"..self.ScriptName.."' is not a interactive object!")self.WarningPrinted=true end;local lAG=GetID(self.ScriptName)
if QSB.InitalizedObjekts[lAG]and
QSB.InitalizedObjekts[lAG]==eN0UMW.Identifier then
error(
eN0UMW.Identifier..": "..
self.Name..": you can not deactivate in the same quest the object is initalized!")return true end;return false end
Swift:RegisterBehavior(B_Reprisal_InteractiveObjectDeactivate)function Reprisal_ObjectActivate(...)
return B_Reprisal_InteractiveObjectActivate:new(...)end
B_Reprisal_InteractiveObjectActivate={Name="Reprisal_InteractiveObjectActivate",Description={en="Reprisal: Activates an interactive object",de="Vergeltung: Aktiviert ein interaktives Objekt"},Parameter={{ParameterType.ScriptName,en="Interactive object",de="Interaktives Objekt"},{ParameterType.Custom,en="Availability",de="Nutzbarkeit"}}}
function B_Reprisal_InteractiveObjectActivate:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_InteractiveObjectActivate:AddParameter(AvEtR8Y,rl3MMqfm)
if(AvEtR8Y==0)then
self.ScriptName=rl3MMqfm elseif(AvEtR8Y==1)then local nQj=0;if rl3MMqfm=="Always"or 1 then nQj=1 end;self.UsingState=
nQj*1 end end;function B_Reprisal_InteractiveObjectActivate:CustomFunction(Eq8jDq)
InteractiveObjectActivate(self.ScriptName,self.UsingState)end
function B_Reprisal_InteractiveObjectActivate:GetCustomData(LnQUN)if
LnQUN==1 then return{"Knight only","Always"}end end
function B_Reprisal_InteractiveObjectActivate:Debug(Gm1)
if not
Logic.IsInteractiveObject(GetID(self.ScriptName))then
warn(Gm1.Identifier..
": "..self.Name..": '"..
self.ScriptName.."' is not a interactive object!")self.WarningPrinted=true end;local Jp=GetID(self.ScriptName)
if QSB.InitalizedObjekts[Jp]and
QSB.InitalizedObjekts[Jp]==Gm1.Identifier then
error(
Gm1.Identifier..": "..
self.Name..": you can not activate in the same quest the object is initalized!")return true end;return false end
Swift:RegisterBehavior(B_Reprisal_InteractiveObjectActivate)function Reprisal_DiplomacyDecrease()
return B_Reprisal_SlightlyDiplomacyDecrease:new()end
B_Reprisal_SlightlyDiplomacyDecrease={Name="Reprisal_SlightlyDiplomacyDecrease",Description={en="Reprisal: Diplomacy decreases slightly to another player.",de="Vergeltung: Der Diplomatiestatus zum Auftraggeber wird um eine Stufe verringert."}}
function B_Reprisal_SlightlyDiplomacyDecrease:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_SlightlyDiplomacyDecrease:CustomFunction(NwBqNl3C)
local XuqjvYPF=NwBqNl3C.SendingPlayer;local Trh=NwBqNl3C.ReceivingPlayer
local K=GetDiplomacyState(Trh,XuqjvYPF)
if K>-2 then SetDiplomacyState(Trh,XuqjvYPF,K-1)end end;function B_Reprisal_SlightlyDiplomacyDecrease:AddParameter(uK,s0FU)
if(uK==0)then self.PlayerID=s0FU*1 end end
Swift:RegisterBehavior(B_Reprisal_SlightlyDiplomacyDecrease)
function Reprisal_Diplomacy(...)return B_Reprisal_Diplomacy:new(...)end
B_Reprisal_Diplomacy={Name="Reprisal_Diplomacy",Description={en="Reprisal: Sets Diplomacy state of two Players to a stated value.",de="Vergeltung: Setzt den Diplomatiestatus zweier Spieler auf den angegebenen Wert."},Parameter={{ParameterType.PlayerID,en="PlayerID 1",de="Spieler 1"},{ParameterType.PlayerID,en="PlayerID 2",de="Spieler 2"},{ParameterType.DiplomacyState,en="Relation",de="Beziehung"}}}
function B_Reprisal_Diplomacy:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_Diplomacy:AddParameter(wQl,g)
if(wQl==0)then self.PlayerID1=g*1 elseif(wQl==1)then
self.PlayerID2=g*1 elseif(wQl==2)then self.Relation=DiplomacyStates[g]end end;function B_Reprisal_Diplomacy:CustomFunction(m4u)
SetDiplomacyState(self.PlayerID1,self.PlayerID2,self.Relation)end
function B_Reprisal_Diplomacy:Debug(StZ)
if

not tonumber(self.PlayerID1)or self.PlayerID1 <1 or self.PlayerID1 >8 then
error(StZ.Identifier..": "..self.Name..
": PlayerID 1 is invalid!")return true elseif
not tonumber(self.PlayerID2)or self.PlayerID2 <1 or self.PlayerID2 >8 then
error(StZ.Identifier..": "..self.Name..
": PlayerID 2 is invalid!")return true elseif
not tonumber(self.Relation)or self.Relation<-2 or self.Relation>2 then
error(StZ.Identifier..": "..
self.Name..": '"..
self.Relation.."' is a invalid diplomacy state!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_Diplomacy)function Reprisal_DestroyEntity(...)return
B_Reprisal_DestroyEntity:new(...)end
B_Reprisal_DestroyEntity={Name="Reprisal_DestroyEntity",Description={en="Reprisal: Replaces an entity with an invisible script entity, which retains the entities name.",de="Vergeltung: Ersetzt eine Entity mit einer unsichtbaren Script-Entity, die den Namen übernimmt."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"}}}
function B_Reprisal_DestroyEntity:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function B_Reprisal_DestroyEntity:AddParameter(C1NqzxY,T1gVrYq)
if(C1NqzxY==0)then self.ScriptName=T1gVrYq end end;function B_Reprisal_DestroyEntity:CustomFunction(P5G)
ReplaceEntity(self.ScriptName,Entities.XD_ScriptEntity)end
function B_Reprisal_DestroyEntity:Debug(JC)
if
not IsExisting(self.ScriptName)then
warn(JC.Identifier..": "..
self.Name..": '"..self.ScriptName..
"' is already destroyed!")self.WarningPrinted=true end;return false end;Swift:RegisterBehavior(B_Reprisal_DestroyEntity)function Reprisal_DestroyEffect(...)return
B_Reprisal_DestroyEffect:new(...)end
B_Reprisal_DestroyEffect={Name="Reprisal_DestroyEffect",Description={en="Reprisal: Destroys an effect",de="Vergeltung: Zerstört einen Effekt"},Parameter={{ParameterType.Default,en="Effect name",de="Effektname"}}}
function B_Reprisal_DestroyEffect:AddParameter(PDA,K)if PDA==0 then self.EffectName=K end end
function B_Reprisal_DestroyEffect:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_DestroyEffect:CustomFunction(qne5Stra)if

not QSB.EffectNameToID[self.EffectName]or not
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])then return end
Logic.DestroyEffect(QSB.EffectNameToID[self.EffectName])end
function B_Reprisal_DestroyEffect:Debug(FKLmmhnQ)if
not QSB.EffectNameToID[self.EffectName]then
error(FKLmmhnQ.Identifier..": "..self.Name..
": Effect "..self.EffectName.." never created")end
return false end;Swift:RegisterBehavior(B_Reprisal_DestroyEffect)function Reprisal_Defeat()return
B_Reprisal_Defeat:new()end
B_Reprisal_Defeat={Name="Reprisal_Defeat",Description={en="Reprisal: The player loses the game.",de="Vergeltung: Der Spieler verliert das Spiel."}}
function B_Reprisal_Defeat:GetReprisalTable()return{Reprisal.Defeat}end;Swift:RegisterBehavior(B_Reprisal_Defeat)function Reprisal_FakeDefeat()return
B_Reprisal_FakeDefeat:new()end
B_Reprisal_FakeDefeat={Name="Reprisal_FakeDefeat",Description={en="Reprisal: Displays a defeat icon for a quest",de="Vergeltung: Zeigt ein Niederlage Icon fuer eine Quest an"}}
function B_Reprisal_FakeDefeat:GetReprisalTable()return{Reprisal.FakeDefeat}end;Swift:RegisterBehavior(B_Reprisal_FakeDefeat)function Reprisal_ReplaceEntity(...)return
B_Reprisal_ReplaceEntity:new(...)end
B_Reprisal_ReplaceEntity={Name="Reprisal_ReplaceEntity",Description={en="Reprisal: Replaces an entity with a new one of a different type. The playerID can be changed too.",de="Vergeltung: Ersetzt eine Entity durch eine neue anderen Typs. Es kann auch die Spielerzugehörigkeit geändert werden."},Parameter={{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Custom,en="New Type",de="Neuer Typ"},{ParameterType.Custom,en="New playerID",de="Neue Spieler ID"}}}
function B_Reprisal_ReplaceEntity:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_ReplaceEntity:AddParameter(F82,wJ6tY_)
if(F82 ==0)then self.ScriptName=wJ6tY_ elseif(F82 ==1)then
self.NewType=wJ6tY_ elseif(F82 ==2)then self.PlayerID=tonumber(wJ6tY_)end end
function B_Reprisal_ReplaceEntity:CustomFunction(TNg)local wO9T=GetID(self.ScriptName)
local QMcSUqdi=self.PlayerID
if QMcSUqdi==Logic.EntityGetPlayer(wO9T)then QMcSUqdi=nil end
ReplaceEntity(self.ScriptName,Entities[self.NewType],QMcSUqdi)end
function B_Reprisal_ReplaceEntity:GetCustomData(sKy2P9i)local S={}
if sKy2P9i==1 then
for AD,AkxLdb66 in pairs(Entities)do
local aUR={"^M_","^XS_","^X_","^XT_","^Z_","^XB_"}local c4=false
for ZNXs3Bwd=1,#aUR do if AD:find(aUR[ZNXs3Bwd])then c4=true;break end end;if not c4 then table.insert(S,AD)end end;table.sort(S)elseif sKy2P9i==2 then
S={"-","0","1","2","3","4","5","6","7","8"}end;return S end
function B_Reprisal_ReplaceEntity:Debug(Ginn)
if not Entities[self.NewType]then
error(Ginn.Identifier..
": "..self.Name..": got an invalid entity type!")return true elseif self.PlayerID~=nil and
(self.PlayerID<1 or self.PlayerID>8)then
error(Ginn.Identifier..": "..
self.Name..": got an invalid playerID!")return true end
if not IsExisting(self.ScriptName)then self.WarningPrinted=true
warn(
Ginn.Identifier..": "..
self.Name..": '"..self.ScriptName.."' does not exist!")end;return false end;Swift:RegisterBehavior(B_Reprisal_ReplaceEntity)function Reprisal_QuestRestart(...)return
B_Reprisal_QuestRestart:new(...)end
B_Reprisal_QuestRestart={Name="Reprisal_QuestRestart",Description={en="Reprisal: Restarts a (completed) quest so it can be triggered and completed again",de="Vergeltung: Startet eine (beendete) Quest neu, damit diese neu ausgelöst und beendet werden kann"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function B_Reprisal_QuestRestart:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function B_Reprisal_QuestRestart:AddParameter(h_pK,L)
if(h_pK==0)then self.QuestName=L end end;function B_Reprisal_QuestRestart:CustomFunction(vBKFXR3)
API.RestartQuest(self.QuestName,true)end
function B_Reprisal_QuestRestart:Debug(FP3j)
if not
Quests[GetQuestID(self.QuestName)]then
error(FP3j.Identifier..
": "..self.Name..": quest "..
self.QuestName.." does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_QuestRestart)function Reprisal_QuestFailure(...)return
B_Reprisal_QuestFailure:new(...)end
B_Reprisal_QuestFailure={Name="Reprisal_QuestFailure",Description={en="Reprisal: Lets another active quest fail",de="Vergeltung: Lässt eine andere aktive Quest fehlschlagen"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function B_Reprisal_QuestFailure:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function B_Reprisal_QuestFailure:AddParameter(fe,ggnA)
if(fe==0)then self.QuestName=ggnA end end;function B_Reprisal_QuestFailure:CustomFunction(KaD2ExEO)
API.FailQuest(self.QuestName,true)end
function B_Reprisal_QuestFailure:Debug(TpiFT)if not
Quests[GetQuestID(self.QuestName)]then
error(TpiFT.Identifier..
": "..self.Name..": got an invalid quest!")return true end
return false end;Swift:RegisterBehavior(B_Reprisal_QuestFailure)function Reprisal_QuestSuccess(...)return
B_Reprisal_QuestSuccess:new(...)end
B_Reprisal_QuestSuccess={Name="Reprisal_QuestSuccess",Description={en="Reprisal: Completes another active quest successfully",de="Vergeltung: Beendet eine andere aktive Quest erfolgreich"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function B_Reprisal_QuestSuccess:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_QuestSuccess:AddParameter(J,CH)if(J==0)then self.QuestName=CH end end;function B_Reprisal_QuestSuccess:CustomFunction(sJ05I)
API.WinQuest(self.QuestName,true)end
function B_Reprisal_QuestSuccess:Debug(HrLCim)
if not
Quests[GetQuestID(self.QuestName)]then
error(HrLCim.Identifier..
": "..self.Name..": quest "..
self.QuestName.." does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_QuestSuccess)function Reprisal_QuestActivate(...)return
B_Reprisal_QuestActivate:new(...)end
B_Reprisal_QuestActivate={Name="Reprisal_QuestActivate",Description={en="Reprisal: Activates another quest that is not triggered yet.",de="Vergeltung: Aktiviert eine andere Quest die noch nicht ausgelöst wurde."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function B_Reprisal_QuestActivate:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_QuestActivate:AddParameter(w,sUu7z)if(w==0)then self.QuestName=sUu7z else
assert(false,"Error in "..
self.Name..": AddParameter: Index is invalid")end end;function B_Reprisal_QuestActivate:CustomFunction(M5oB)
API.StartQuest(self.QuestName,true)end
function B_Reprisal_QuestActivate:Debug(xIyIKo)
if not
IsValidQuest(self.QuestName)then
error(xIyIKo.Identifier..
": "..self.Name..": Quest: "..
self.QuestName.." does not exist")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_QuestActivate)function Reprisal_QuestInterrupt(...)return
B_Reprisal_QuestInterrupt:new(...)end
B_Reprisal_QuestInterrupt={Name="Reprisal_QuestInterrupt",Description={en="Reprisal: Interrupts another active quest without success or failure",de="Vergeltung: Beendet eine andere aktive Quest ohne Erfolg oder Misserfolg"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function B_Reprisal_QuestInterrupt:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function B_Reprisal_QuestInterrupt:AddParameter(f2x,Nwl)
if(f2x==0)then self.QuestName=Nwl end end
function B_Reprisal_QuestInterrupt:CustomFunction(Xpt_SQ)
if(
GetQuestID(self.QuestName)~=nil)then
local Y=GetQuestID(self.QuestName)local SMa=Quests[Y]if SMa.State==QuestState.Active then
API.StopQuest(self.QuestName,true)end end end
function B_Reprisal_QuestInterrupt:Debug(Bo)
if
not Quests[GetQuestID(self.QuestName)]then
error(Bo.Identifier..": "..self.Name..
": quest "..self.QuestName.." does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_QuestInterrupt)function Reprisal_QuestForceInterrupt(...)return
B_Reprisal_QuestForceInterrupt:new(...)end
B_Reprisal_QuestForceInterrupt={Name="Reprisal_QuestForceInterrupt",Description={en="Reprisal: Interrupts another quest (even when it isn't active yet) without success or failure",de="Vergeltung: Beendet eine andere Quest, auch wenn diese noch nicht aktiv ist ohne Erfolg oder Misserfolg"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Custom,en="Ended quests",de="Beendete Quests"}}}
function B_Reprisal_QuestForceInterrupt:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_QuestForceInterrupt:AddParameter(zF6ZPjQ,nNQG3)
if(zF6ZPjQ==0)then self.QuestName=nNQG3 elseif(
zF6ZPjQ==1)then self.InterruptEnded=API.ToBoolean(nNQG3)end end
function B_Reprisal_QuestForceInterrupt:GetCustomData(yW)local efGM8UMy={}
if yW==1 then
table.insert(efGM8UMy,"false")table.insert(efGM8UMy,"true")else assert(false)end;return efGM8UMy end
function B_Reprisal_QuestForceInterrupt:CustomFunction(KhH)
if
(GetQuestID(self.QuestName)~=nil)then local H4tXd=GetQuestID(self.QuestName)local Nq6If=Quests[H4tXd]if
self.InterruptEnded or Nq6If.State~=QuestState.Over then
Nq6If:Interrupt()end end end
function B_Reprisal_QuestForceInterrupt:Debug(II)
if not
Quests[GetQuestID(self.QuestName)]then
error(II.Identifier..
": "..self.Name..": quest "..
self.QuestName.." does not exist!")return true end;return false end
Swift:RegisterBehavior(B_Reprisal_QuestForceInterrupt)function Reprisal_CustomVariables(...)
return B_Reprisal_CustomVariables:new(...)end
B_Reprisal_CustomVariables={Name="Reprisal_CustomVariables",Description={en="Reprisal: Executes a mathematical operation with this variable. The other operand can be a number or another custom variable.",de="Vergeltung: Führt eine mathematische Operation mit der Variable aus. Der andere Operand kann eine Zahl oder eine Custom-Varible sein."},Parameter={{ParameterType.Default,en="Name of variable",de="Variablenname"},{ParameterType.Custom,en="Operator",de="Operator"},{ParameterType.Default,en="Value or variable",de="Wert oder Variable"}}}
function B_Reprisal_CustomVariables:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_CustomVariables:AddParameter(Y_tefq,i)
if Y_tefq==0 then self.VariableName=i elseif Y_tefq==1 then
self.Operator=i elseif Y_tefq==2 then local a3u=tonumber(i)
a3u=(a3u~=nil and a3u)or tostring(i)self.Value=a3u end end
function B_Reprisal_CustomVariables:CustomFunction()
local mzhB=API.ObtainCustomVariable("BehaviorVariable_"..self.VariableName,0)local sTxVGmb=self.Value;if type(self.Value)=="string"then
sTxVGmb=API.ObtainCustomVariable(
"BehaviorVariable_"..self.Value,0)end
if self.Operator=="="then
mzhB=sTxVGmb elseif self.Operator=="+"then mzhB=mzhB+sTxVGmb elseif self.Operator=="-"then
mzhB=mzhB-sTxVGmb elseif self.Operator=="*"then mzhB=mzhB*sTxVGmb elseif self.Operator=="/"then
mzhB=mzhB/sTxVGmb elseif self.Operator=="^"then mzhB=mzhB%sTxVGmb end
API.SaveCustomVariable("BehaviorVariable_"..self.VariableName,mzhB)end
function B_Reprisal_CustomVariables:GetCustomData(GSIcq)return{"=","+","-","*","/","^"}end
function B_Reprisal_CustomVariables:Debug(Go)local DGf={"=","+","-","*","/","^"}
if not
table.contains(DGf,self.Operator)then
error(Go.Identifier..
": "..self.Name..": got an invalid operator!")return true elseif self.VariableName==""then
error(Go.Identifier..": "..
self.Name..": missing name for variable!")return true end;return false end
Swift:RegisterBehavior(B_Reprisal_CustomVariables)function Reprisal_MapScriptFunction(...)
return B_Reprisal_MapScriptFunction:new(...)end
B_Reprisal_MapScriptFunction={Name="Reprisal_MapScriptFunction",Description={en="Reprisal: Calls a function within the global map script if the quest has failed.",de="Vergeltung: Ruft eine Funktion im globalen Kartenskript auf, wenn die Quest fehlschlägt."},Parameter={{ParameterType.Default,en="Function name",de="Funktionsname"}}}
function B_Reprisal_MapScriptFunction:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function B_Reprisal_MapScriptFunction:AddParameter(kgRX7X,JB)
if kgRX7X==0 then self.FuncName=JB end end
function B_Reprisal_MapScriptFunction:CustomFunction(GGJhclKa)if
type(self.FuncName)=="function"then
self.FuncName(unpack(self.i47ya_6aghw_frxil))return end
_G[self.FuncName](self,GGJhclKa)end
function B_Reprisal_MapScriptFunction:Debug(KWahIz)if not self.FuncName then
error(KWahIz.Identifier..": "..self.Name..
": function reference is invalid!")return true end
if

type(self.FuncName)~="function"and not _G[self.FuncName]then
error(KWahIz.Identifier..
": "..self.Name..": function does not exist!")return true end;return false end
Swift:RegisterBehavior(B_Reprisal_MapScriptFunction)
function Reprisal_Technology(...)return B_Reprisal_Technology:new(...)end
B_Reprisal_Technology={Name="Reprisal_Technology",Description={en="Reprisal: Locks or unlocks a technology for the given player",de="Vergeltung: Sperrt oder erlaubt eine Technolgie fuer den angegebenen Player"},Parameter={{ParameterType.PlayerID,en="PlayerID",de="SpielerID"},{ParameterType.Custom,en="Un / Lock",de="Sperren/Erlauben"},{ParameterType.Custom,en="Technology",de="Technologie"}}}
function B_Reprisal_Technology:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_Technology:AddParameter(X2kyW,pVlvW)
if(X2kyW==0)then self.PlayerID=pVlvW*1 elseif
(X2kyW==1)then self.LockType=pVlvW=="Lock"elseif(X2kyW==2)then self.Technology=pVlvW end end
function B_Reprisal_Technology:CustomFunction(QcKn_)
if
self.PlayerID and
Logic.GetStoreHouse(self.PlayerID)~=0 and Technologies[self.Technology]then
if self.LockType then
LockFeaturesForPlayer(self.PlayerID,Technologies[self.Technology])else
UnLockFeaturesForPlayer(self.PlayerID,Technologies[self.Technology])end else return false end end
function B_Reprisal_Technology:GetCustomData(jiM)local YUdA={}if(jiM==1)then YUdA[1]="Lock"
YUdA[2]="UnLock"elseif(jiM==2)then
for lx3cpJ,Yx9 in pairs(Technologies)do table.insert(YUdA,lx3cpJ)end end
return YUdA end
function B_Reprisal_Technology:Debug(Mn)
if not Technologies[self.Technology]then
error(
Mn.Identifier..": "..self.Name..": got an invalid technology type!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
error(Mn.Identifier..": "..self.Name..
": got an invalid playerID!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_Technology)function Reward_DEBUG(...)return
B_Reward_DEBUG:new(...)end
B_Reward_DEBUG={Name="Reward_DEBUG",Description={en="Reward: Start the debug mode. See documentation for more information.",de="Lohn: Startet den Debug-Modus. Für mehr Informationen siehe Dokumentation."},Parameter={{ParameterType.Custom,en="Check quest while runtime",de="Quests zur Laufzeit prüfen"},{ParameterType.Custom,en="Use quest trace",de="Questverfolgung"},{ParameterType.Custom,en="Activate developing cheats",de="Cheats aktivieren"},{ParameterType.Custom,en="Activate developing shell",de="Eingabe aktivieren"}}}function B_Reward_DEBUG:GetRewardTable(ut0)return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_DEBUG:AddParameter(ZFhlP6eg,ExUgDG)
if(
ZFhlP6eg==0)then self.CheckWhileRuntime=API.ToBoolean(ExUgDG)elseif
(ZFhlP6eg==1)then self.UseQuestTrace=API.ToBoolean(ExUgDG)elseif(ZFhlP6eg==2)then
self.DevelopingCheats=API.ToBoolean(ExUgDG)elseif(ZFhlP6eg==3)then self.DevelopingShell=API.ToBoolean(ExUgDG)end end
function B_Reward_DEBUG:CustomFunction(jc4o42jz)
API.ActivateDebugMode(self.CheckWhileRuntime,self.UseQuestTrace,self.DevelopingCheats,self.DevelopingShell)end
function B_Reward_DEBUG:GetCustomData(jc)return{"true","false"}end;Swift:RegisterBehavior(B_Reward_DEBUG)function Reprisal_Technology(...)return
B_Reprisal_Technology:new(...)end
B_Reprisal_Technology={Name="Reprisal_Technology",Description={en="Reprisal: Locks or unlocks a technology for the given player",de="Vergeltung: Sperrt oder erlaubt eine Technolgie fuer den angegebenen Player"},Parameter={{ParameterType.PlayerID,en="PlayerID",de="SpielerID"},{ParameterType.Custom,en="Un / Lock",de="Sperren/Erlauben"},{ParameterType.Custom,en="Technology",de="Technologie"}}}
function B_Reprisal_Technology:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_Technology:AddParameter(Ojz_,x)
if(Ojz_==0)then self.PlayerID=x*1 elseif(Ojz_==1)then self.LockType=
x=="Lock"elseif(Ojz_==2)then self.Technology=x end end
function B_Reprisal_Technology:CustomFunction(Xtecl)
if
self.PlayerID and
Logic.GetStoreHouse(self.PlayerID)~=0 and Technologies[self.Technology]then
if self.LockType then
LockFeaturesForPlayer(self.PlayerID,Technologies[self.Technology])else
UnLockFeaturesForPlayer(self.PlayerID,Technologies[self.Technology])end else return false end end
function B_Reprisal_Technology:GetCustomData(KVcYU)local _={}
if(KVcYU==1)then _[1]="Lock"_[2]="UnLock"elseif
(KVcYU==2)then for C,CJeG in pairs(Technologies)do table.insert(_,C)end end;return _ end
function B_Reprisal_Technology:Debug(F43eMG)
if not Technologies[self.Technology]then
error(
F43eMG.Identifier..": "..self.Name..": got an invalid technology type!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
error(F43eMG.Identifier..": "..self.Name..
": got an invalid playerID!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_Technology)function Reward_ObjectDeactivate(...)return
B_Reward_InteractiveObjectDeactivate:new(...)end
B_Reward_InteractiveObjectDeactivate=Swift:CopyTable(B_Reprisal_InteractiveObjectDeactivate)
B_Reward_InteractiveObjectDeactivate.Name="Reward_InteractiveObjectDeactivate"
B_Reward_InteractiveObjectDeactivate.Description.en="Reward: Deactivates an interactive object"
B_Reward_InteractiveObjectDeactivate.Description.de="Lohn: Deaktiviert ein interaktives Objekt"B_Reward_InteractiveObjectDeactivate.GetReprisalTable=nil
B_Reward_InteractiveObjectDeactivate.GetRewardTable=function(mCzjh4,lU)return
{Reward.Custom,{mCzjh4,mCzjh4.CustomFunction}}end
Swift:RegisterBehavior(B_Reward_InteractiveObjectDeactivate)function Reward_ObjectActivate(...)
return B_Reward_InteractiveObjectActivate:new(...)end
B_Reward_InteractiveObjectActivate=Swift:CopyTable(B_Reprisal_InteractiveObjectActivate)
B_Reward_InteractiveObjectActivate.Name="Reward_InteractiveObjectActivate"
B_Reward_InteractiveObjectActivate.Description.en="Reward: Activates an interactive object"
B_Reward_InteractiveObjectActivate.Description.de="Lohn: Aktiviert ein interaktives Objekt"B_Reward_InteractiveObjectActivate.GetReprisalTable=nil
B_Reward_InteractiveObjectActivate.GetRewardTable=function(epQue9,cHUJrj)return
{Reward.Custom,{epQue9,epQue9.CustomFunction}}end
Swift:RegisterBehavior(B_Reward_InteractiveObjectActivate)
function Reward_ObjectInit(...)return B_Reward_ObjectInit:new(...)end
B_Reward_ObjectInit={Name="Reward_ObjectInit",Description={en="Reward: Setup an interactive object with costs and rewards.",de="Lohn: Initialisiert ein interaktives Objekt mit seinen Kosten und Schätzen."},Parameter={{ParameterType.ScriptName,en="Interactive object",de="Interaktives Objekt"},{ParameterType.Number,en="Distance to use",de="Nutzungsentfernung"},{ParameterType.Number,en="Waittime",de="Wartezeit"},{ParameterType.Custom,en="Reward good",de="Belohnungsware"},{ParameterType.Number,en="Reward amount",de="Anzahl"},{ParameterType.Custom,en="Cost good 1",de="Kostenware 1"},{ParameterType.Number,en="Cost amount 1",de="Anzahl 1"},{ParameterType.Custom,en="Cost good 2",de="Kostenware 2"},{ParameterType.Number,en="Cost amount 2",de="Anzahl 2"},{ParameterType.Custom,en="Availability",de="Verfügbarkeit"}}}function B_Reward_ObjectInit:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_ObjectInit:AddParameter(EI0x,E)
if(
EI0x==0)then self.ScriptName=E elseif(EI0x==1)then self.Distance=E*1 elseif(EI0x==2)then self.Waittime=
E*1 elseif(EI0x==3)then self.RewardType=E elseif(EI0x==4)then self.RewardAmount=E*1 elseif(
EI0x==5)then self.FirstCostType=E elseif(EI0x==6)then self.FirstCostAmount=E*1 elseif
(EI0x==7)then self.SecondCostType=E elseif(EI0x==8)then self.SecondCostAmount=E*1 elseif(EI0x==9)then
local lacOdjf9=nil
if E=="Always"or E==1 then lacOdjf9=1 elseif E=="Never"or E==2 then lacOdjf9=2 elseif
E=="Knight only"or E==0 then lacOdjf9=0 end;self.UsingState=lacOdjf9 end end
function B_Reward_ObjectInit:CustomFunction(R2h4lP4l)local Fh=GetID(self.ScriptName)
if Fh==0 then return end;QSB.InitalizedObjekts[Fh]=R2h4lP4l.Identifier
Logic.InteractiveObjectClearCosts(Fh)Logic.InteractiveObjectClearRewards(Fh)
Logic.InteractiveObjectSetInteractionDistance(Fh,self.Distance)
Logic.InteractiveObjectSetTimeToOpen(Fh,self.Waittime)if self.RewardType and self.RewardType~="-"then
Logic.InteractiveObjectAddRewards(Fh,Goods[self.RewardType],self.RewardAmount)end;if
self.FirstCostType and self.FirstCostType~="-"then
Logic.InteractiveObjectAddCosts(Fh,Goods[self.FirstCostType],self.FirstCostAmount)end;if
self.SecondCostType and self.SecondCostType~="-"then
Logic.InteractiveObjectAddCosts(Fh,Goods[self.SecondCostType],self.SecondCostAmount)end
Logic.InteractiveObjectSetAvailability(Fh,true)
if self.UsingState then for a2e9fa=1,8 do
Logic.InteractiveObjectSetPlayerState(Fh,a2e9fa,self.UsingState)end end
Logic.InteractiveObjectSetRewardResourceCartType(Fh,Entities.U_ResourceMerchant)
Logic.InteractiveObjectSetRewardGoldCartType(Fh,Entities.U_GoldCart)
Logic.InteractiveObjectSetCostResourceCartType(Fh,Entities.U_ResourceMerchant)
Logic.InteractiveObjectSetCostGoldCartType(Fh,Entities.U_GoldCart)RemoveInteractiveObjectFromOpenedList(Fh)
table.insert(HiddenTreasures,Fh)end
function B_Reward_ObjectInit:GetCustomData(Rc9_ZID)
if
Rc9_ZID==3 or Rc9_ZID==5 or Rc9_ZID==7 then
local H1HF2wD6={"-","G_Beer","G_Bread","G_Broom","G_Carcass","G_Cheese","G_Clothes","G_Dye","G_Gold","G_Grain","G_Herb","G_Honeycomb","G_Iron","G_Leather","G_Medicine","G_Milk","G_RawFish","G_Salt","G_Sausage","G_SmokedFish","G_Soap","G_Stone","G_Water","G_Wood","G_Wool"}if g_GameExtraNo>=1 then H1HF2wD6[#H1HF2wD6+1]="G_Gems"H1HF2wD6[
#H1HF2wD6+1]="G_MusicalInstrument"
H1HF2wD6[#H1HF2wD6+1]="G_Olibanum"end
return H1HF2wD6 elseif Rc9_ZID==9 then return{"-","Knight only","Always","Never"}end end
function B_Reward_ObjectInit:Debug(hBph)
if
Logic.IsInteractiveObject(GetID(self.ScriptName))==false then
error(hBph.Identifier..": "..
self.Name..": '"..self.ScriptName..
"' is not a interactive object!")return true end;if self.UsingState~=1 and self.Distance<50 then
warn(hBph.Identifier..": "..
self.Name..": distance is maybe too short!")end;if
self.Waittime<0 then
error(hBph.Identifier..
": "..self.Name..": waittime must be equal or greater than 0!")return true end
if
self.RewardType and self.RewardType~="-"then
if
not Goods[self.RewardType]then
error(hBph.Identifier..": "..self.Name..
": '"..self.RewardType.."' is invalid good type!")return true elseif self.RewardAmount<1 then
error(hBph.Identifier..": "..
self.Name..": amount can not be 0 or negative!")return true end end
if self.FirstCostType and self.FirstCostType~="-"then
if not
Goods[self.FirstCostType]then
error(hBph.Identifier..
": "..self.Name..": '"..
self.FirstCostType.."' is invalid good type!")return true elseif self.FirstCostAmount<1 then
error(hBph.Identifier..": "..
self.Name..": amount can not be 0 or negative!")return true end end
if self.SecondCostType and self.SecondCostType~="-"then
if not
Goods[self.SecondCostType]then
error(hBph.Identifier..
": "..self.Name..": '"..
self.SecondCostType.."' is invalid good type!")return true elseif self.SecondCostAmount<1 then
error(hBph.Identifier..": "..
self.Name..": amount can not be 0 or negative!")return true end end;return false end;Swift:RegisterBehavior(B_Reward_ObjectInit)function Reward_Diplomacy(...)return
B_Reward_Diplomacy:new(...)end
B_Reward_Diplomacy=Swift:CopyTable(B_Reprisal_Diplomacy)B_Reward_Diplomacy.Name="Reward_Diplomacy"
B_Reward_Diplomacy.Description.en="Reward: Sets Diplomacy state of two Players to a stated value."
B_Reward_Diplomacy.Description.de="Lohn: Setzt den Diplomatiestatus zweier Spieler auf den angegebenen Wert."B_Reward_Diplomacy.GetReprisalTable=nil
B_Reward_Diplomacy.GetRewardTable=function(bxNo9h,Khst)return
{Reward.Custom,{bxNo9h,bxNo9h.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_Diplomacy)function Reward_DiplomacyIncrease()return
B_Reward_SlightlyDiplomacyIncrease:new()end
B_Reward_SlightlyDiplomacyIncrease={Name="Reward_SlightlyDiplomacyIncrease",Description={en="Reward: Diplomacy increases slightly to another player",de="Lohn: Verbesserung des Diplomatiestatus zu einem anderen Spieler"}}
function B_Reward_SlightlyDiplomacyIncrease:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_SlightlyDiplomacyIncrease:CustomFunction(pUT)local ISg1=pUT.SendingPlayer
local Gh5UJya=pUT.ReceivingPlayer;local k=GetDiplomacyState(Gh5UJya,ISg1)if k<2 then
SetDiplomacyState(Gh5UJya,ISg1,k+1)end end
function B_Reward_SlightlyDiplomacyIncrease:AddParameter(Z8Ue,TXbmx)if(Z8Ue==0)then
self.PlayerID=TXbmx*1 end end
Swift:RegisterBehavior(B_Reward_SlightlyDiplomacyIncrease)
function Reward_TradeOffers(...)return B_Reward_Merchant:new(...)end
B_Reward_Merchant={Name="Reward_Merchant",Description={en="Reward: Deletes all existing offers for a merchant and sets new offers, if given",de="Lohn: Löscht alle Angebote eines Händlers und setzt neue, wenn angegeben"},Parameter={{ParameterType.Custom,en="PlayerID",de="PlayerID"},{ParameterType.Custom,en="Amount 1",de="Menge 1"},{ParameterType.Custom,en="Offer 1",de="Angebot 1"},{ParameterType.Custom,en="Amount 2",de="Menge 2"},{ParameterType.Custom,en="Offer 2",de="Angebot 2"},{ParameterType.Custom,en="Amount 3",de="Menge 3"},{ParameterType.Custom,en="Offer 3",de="Angebot 3"},{ParameterType.Custom,en="Amount 4",de="Menge 4"},{ParameterType.Custom,en="Offer 4",de="Angebot 4"}}}function B_Reward_Merchant:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_Merchant:AddParameter(r,Pqgz415t)
if(
r==0)then self.PlayerID=Pqgz415t*1 elseif(r==1)then Pqgz415t=Pqgz415t or 0;self.AmountOffer1=
Pqgz415t*1 elseif(r==2)then self.Offer1=Pqgz415t elseif(r==3)then
Pqgz415t=Pqgz415t or 0;self.AmountOffer2=Pqgz415t*1 elseif(r==4)then self.Offer2=Pqgz415t elseif(r==5)then Pqgz415t=
Pqgz415t or 0;self.AmountOffer3=Pqgz415t*1 elseif(r==6)then
self.Offer3=Pqgz415t elseif(r==7)then Pqgz415t=Pqgz415t or 0;self.AmountOffer4=Pqgz415t*1 elseif(r==8)then
self.Offer4=Pqgz415t end end
function B_Reward_Merchant:CustomFunction()
if
(self.PlayerID>1)and(self.PlayerID<9)then local McNxKV=Logic.GetStoreHouse(self.PlayerID)
Logic.RemoveAllOffers(McNxKV)
for WcwGYJh=1,4 do
if
self["Offer"..WcwGYJh]and self["Offer"..WcwGYJh]~="-"then
if Goods[self["Offer"..WcwGYJh]]then
AddOffer(McNxKV,self["AmountOffer"..WcwGYJh],Goods[self[
"Offer"..WcwGYJh]])elseif
Logic.IsEntityTypeInCategory(Entities[self["Offer"..WcwGYJh]],EntityCategories.Military)==1 then
AddMercenaryOffer(McNxKV,self["AmountOffer"..WcwGYJh],Entities[self[
"Offer"..WcwGYJh]])else
AddEntertainerOffer(McNxKV,Entities[self["Offer"..WcwGYJh]])end end end end end
function B_Reward_Merchant:Debug(gJt)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
error(gJt.Identifier..": "..self.Name..
": Player "..self.PlayerID.." is dead. :-(")return true end end
function B_Reward_Merchant:GetCustomData(hCs8M)local GkjCn_mq={1,2,3,4,5,6,7,8}
local T9sySp={"1","2","3","4","5","6","7","8","9"}
local DL0mMXM={"-","G_Beer","G_Bow","G_Bread","G_Broom","G_Candle","G_Carcass","G_Cheese","G_Clothes","G_Cow","G_Grain","G_Herb","G_Honeycomb","G_Iron","G_Leather","G_Medicine","G_Milk","G_RawFish","G_Sausage","G_Sheep","G_SmokedFish","G_Soap","G_Stone","G_Sword","G_Wood","G_Wool","G_Salt","G_Dye","U_AmmunitionCart","U_BatteringRamCart","U_CatapultCart","U_SiegeTowerCart","U_MilitaryBandit_Melee_ME","U_MilitaryBandit_Melee_SE","U_MilitaryBandit_Melee_NA","U_MilitaryBandit_Melee_NE","U_MilitaryBandit_Ranged_ME","U_MilitaryBandit_Ranged_NA","U_MilitaryBandit_Ranged_NE","U_MilitaryBandit_Ranged_SE","U_MilitaryBow_RedPrince","U_MilitaryBow","U_MilitarySword_RedPrince","U_MilitarySword","U_Entertainer_NA_FireEater","U_Entertainer_NA_StiltWalker","U_Entertainer_NE_StrongestMan_Barrel","U_Entertainer_NE_StrongestMan_Stone"}
if g_GameExtraNo and g_GameExtraNo>=1 then
table.insert(DL0mMXM,"G_Gems")table.insert(DL0mMXM,"G_Olibanum")
table.insert(DL0mMXM,"G_MusicalInstrument")
table.insert(DL0mMXM,"G_MilitaryBandit_Ranged_AS")table.insert(DL0mMXM,"G_MilitaryBandit_Melee_AS")
table.insert(DL0mMXM,"U_MilitarySword_Khana")table.insert(DL0mMXM,"U_MilitaryBow_Khana")end
if(hCs8M==0)then return GkjCn_mq elseif
(hCs8M==1)or(hCs8M==3)or(hCs8M==5)or(hCs8M==7)then return T9sySp elseif
(hCs8M==2)or(hCs8M==4)or(hCs8M==6)or(hCs8M==8)then
return DL0mMXM end end;Swift:RegisterBehavior(B_Reward_Merchant)function Reward_DestroyEntity(...)return
B_Reward_DestroyEntity:new(...)end
B_Reward_DestroyEntity=Swift:CopyTable(B_Reprisal_DestroyEntity)B_Reward_DestroyEntity.Name="Reward_DestroyEntity"
B_Reward_DestroyEntity.Description.en="Reward: Replaces an entity with an invisible script entity, which retains the entities name."
B_Reward_DestroyEntity.Description.de="Lohn: Ersetzt eine Entity mit einer unsichtbaren Script-Entity, die den Namen übernimmt."B_Reward_DestroyEntity.GetReprisalTable=nil
B_Reward_DestroyEntity.GetRewardTable=function(o4Kvi75g,ELb)return
{Reward.Custom,{o4Kvi75g,o4Kvi75g.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_DestroyEntity)function Reward_DestroyEffect(...)return
B_Reward_DestroyEffect:new(...)end
B_Reward_DestroyEffect=Swift:CopyTable(B_Reprisal_DestroyEffect)B_Reward_DestroyEffect.Name="Reward_DestroyEffect"
B_Reward_DestroyEffect.Description.en="Reward: Destroys an effect."
B_Reward_DestroyEffect.Description.de="Lohn: Zerstört einen Effekt."B_Reward_DestroyEffect.GetReprisalTable=nil
B_Reward_DestroyEffect.GetRewardTable=function(FV5,sX)return
{Reward.Custom,{FV5,FV5.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_DestroyEffect)function Reward_CreateBattalion(...)return
B_Reward_CreateBattalion:new(...)end
B_Reward_CreateBattalion={Name="Reward_CreateBattalion",Description={en="Reward: Replaces a script entity with a battalion, which retains the entities name",de="Lohn: Ersetzt eine Script-Entity durch ein Bataillon, welches den Namen der Script-Entity übernimmt"},Parameter={{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Number,en="Number of soldiers",de="Anzahl Soldaten"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}
function B_Reward_CreateBattalion:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_CreateBattalion:AddParameter(DH6mUlGB,A4ZRczp)
if(DH6mUlGB==0)then
self.ScriptNameEntity=A4ZRczp elseif(DH6mUlGB==1)then self.PlayerID=A4ZRczp*1 elseif(DH6mUlGB==2)then
self.UnitKey=A4ZRczp elseif(DH6mUlGB==3)then self.Orientation=A4ZRczp*1 elseif(DH6mUlGB==4)then self.SoldierCount=
A4ZRczp*1 elseif(DH6mUlGB==5)then
self.HideFromAI=API.ToBoolean(A4ZRczp)end end
function B_Reward_CreateBattalion:CustomFunction(rUT)if
not IsExisting(self.ScriptNameEntity)then return false end
local g=GetPosition(self.ScriptNameEntity)
local JPi=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],g.X,g.Y,self.Orientation,self.PlayerID,self.SoldierCount)local Kkl6fa=GetID(self.ScriptNameEntity)if Logic.IsBuilding(Kkl6fa)==
0 then DestroyEntity(self.ScriptNameEntity)
Logic.SetEntityName(JPi,self.ScriptNameEntity)end;if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,JPi,true)end end
function B_Reward_CreateBattalion:GetCustomData(t)local H={}
if t==2 then for glZrOuSo,Zdzaj in pairs(Entities)do
if
Logic.IsEntityTypeInCategory(Zdzaj,EntityCategories.Soldier)==1 then table.insert(H,glZrOuSo)end end
table.sort(H)elseif t==5 then table.insert(H,"false")table.insert(H,"true")else
assert(false)end;return H end
function B_Reward_CreateBattalion:Debug(UxRGyO9e)
if not Entities[self.UnitKey]then
error(
UxRGyO9e.Identifier..": "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
error(
UxRGyO9e.Identifier..": "..self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
error(UxRGyO9e.Identifier..": "..self.Name..
": playerID is wrong!")return true elseif tonumber(self.Orientation)==nil then
error(UxRGyO9e.Identifier..": "..
self.Name..": orientation must be a number!")return true elseif
tonumber(self.SoldierCount)==nil or self.SoldierCount<1 then
error(UxRGyO9e.Identifier..
": "..self.Name..": you can not create a empty batallion!")return true end;return false end;Swift:RegisterBehavior(B_Reward_CreateBattalion)function Reward_CreateSeveralBattalions(...)return
B_Reward_CreateSeveralBattalions:new(...)end
B_Reward_CreateSeveralBattalions={Name="Reward_CreateSeveralBattalions",Description={en="Reward: Creates a given amount of battalions",de="Lohn: Erstellt eine gegebene Anzahl Bataillone"},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Number,en="Number of soldiers",de="Anzahl Soldaten"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}
function B_Reward_CreateSeveralBattalions:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_CreateSeveralBattalions:AddParameter(fvj_L,_CPU89l)
if(fvj_L==0)then
self.Amount=_CPU89l*1 elseif(fvj_L==1)then self.ScriptNameEntity=_CPU89l elseif(fvj_L==2)then
self.PlayerID=_CPU89l*1 elseif(fvj_L==3)then self.UnitKey=_CPU89l elseif(fvj_L==4)then
self.Orientation=_CPU89l*1 elseif(fvj_L==5)then self.SoldierCount=_CPU89l*1 elseif(fvj_L==6)then
self.HideFromAI=API.ToBoolean(_CPU89l)end end
function B_Reward_CreateSeveralBattalions:CustomFunction(U)if
not IsExisting(self.ScriptNameEntity)then return false end
local Kwxn=GetID(self.ScriptNameEntity)local yp5DGSwX,Sb1Mw7R,fuF=Logic.EntityGetPos(Kwxn)if
Logic.IsBuilding(Kwxn)==1 then
yp5DGSwX,Sb1Mw7R=Logic.GetBuildingApproachPosition(Kwxn)end
for pA2=1,self.Amount do
local M5lAedm=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],yp5DGSwX,Sb1Mw7R,self.Orientation,self.PlayerID,self.SoldierCount)
Logic.SetEntityName(M5lAedm,self.ScriptNameEntity.."_"..pA2)if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,M5lAedm,true)end end end
function B_Reward_CreateSeveralBattalions:GetCustomData(_uYRl2kj)local tbN={}
if _uYRl2kj==3 then for x,m in pairs(Entities)do
if
Logic.IsEntityTypeInCategory(m,EntityCategories.Soldier)==1 then table.insert(tbN,x)end end
table.sort(tbN)elseif _uYRl2kj==6 then table.insert(tbN,"false")
table.insert(tbN,"true")else assert(false)end;return tbN end
function B_Reward_CreateSeveralBattalions:Debug(VVQ)
if not Entities[self.UnitKey]then
error(
VVQ.Identifier..": "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
error(VVQ.Identifier..": "..
self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
error(VVQ.Identifier..": "..self.Name..
": playerDI is wrong!")return true elseif tonumber(self.Orientation)==nil then
error(VVQ.Identifier..": "..self.Name..
": orientation must be a number!")return true elseif
tonumber(self.SoldierCount)==nil or self.SoldierCount<1 then
error(VVQ.Identifier..
": "..self.Name..": you can not create a empty batallion!")return true elseif
tonumber(self.Amount)==nil or self.Amount<0 then
error(VVQ.Identifier..
": "..self.Name..": amount can not be negative!")return true end;return false end
Swift:RegisterBehavior(B_Reward_CreateSeveralBattalions)
function Reward_CreateEffect(...)return B_Reward_CreateEffect:new(...)end
B_Reward_CreateEffect={Name="Reward_CreateEffect",Description={en="Reward: Creates an effect at a specified position",de="Lohn: Erstellt einen Effekt an der angegebenen Position"},Parameter={{ParameterType.Default,en="Effect name",de="Effektname"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.ScriptName,en="Location",de="Ort"},{ParameterType.Number,en="Orientation (in degrees)(-1: from locating entity)",de="Ausrichtung (in Grad)(-1: von Positionseinheit)"}}}
function B_Reward_CreateEffect:AddParameter(Jb,q)
if Jb==0 then self.EffectName=q elseif Jb==1 then
self.Type=EGL_Effects[q]elseif Jb==2 then self.PlayerID=q*1 elseif Jb==3 then self.Location=q elseif Jb==4 then self.Orientation=q*1 end end;function B_Reward_CreateEffect:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_CreateEffect:CustomFunction(cpea)if
Logic.IsEntityDestroyed(self.Location)then return end
local tjDBv=assert(GetID(self.Location),cpea.Identifier.."Error in "..
self.Name..": CustomFunction: Entity is invalid")
if QSB.EffectNameToID[self.EffectName]and
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])then return end;local vmn7v,Au1mzs=Logic.GetEntityPosition(tjDBv)
local u39i=tonumber(self.Orientation)
local Fdg7p=Logic.CreateEffectWithOrientation(self.Type,vmn7v,Au1mzs,u39i,self.PlayerID)if self.EffectName~=""then
QSB.EffectNameToID[self.EffectName]=Fdg7p end end
function B_Reward_CreateEffect:Debug(GD3AP)
if QSB.EffectNameToID[self.EffectName]and
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])then
error(GD3AP.Identifier..": "..self.Name..
": effect already exists!")return true elseif not IsExisting(self.Location)then
error(GD3AP.Identifier..": "..
self.Name..
": location '"..self.Location.."' is missing!")return true elseif self.PlayerID and
(self.PlayerID<0 or self.PlayerID>8)then
error(GD3AP.Identifier..
": "..self.Name..": invalid playerID!")return true elseif tonumber(self.Orientation)==nil then
error(GD3AP.Identifier..": "..self.Name..
": invalid orientation!")return true end end
function B_Reward_CreateEffect:GetCustomData(jph00k)
assert(jph00k==1,"Error in "..
self.Name..": GetCustomData: Index is invalid.")local wE_4o={}
for F,bUO1NvT in pairs(EGL_Effects)do table.insert(wE_4o,F)end;table.sort(wE_4o)return wE_4o end;Swift:RegisterBehavior(B_Reward_CreateEffect)function Reward_CreateEntity(...)return
B_Reward_CreateEntity:new(...)end
B_Reward_CreateEntity={Name="Reward_CreateEntity",Description={en="Reward: Replaces an entity by a new one of a given type",de="Lohn: Ersetzt eine Entity durch eine neue gegebenen Typs"},Parameter={{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}function B_Reward_CreateEntity:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_CreateEntity:AddParameter(K,RQG)
if(
K==0)then self.ScriptNameEntity=RQG elseif(K==1)then self.PlayerID=RQG*1 elseif(K==2)then
self.UnitKey=RQG elseif(K==3)then self.Orientation=RQG*1 elseif(K==4)then
self.HideFromAI=API.ToBoolean(RQG)end end
function B_Reward_CreateEntity:CustomFunction(tVwI_N)if
not IsExisting(self.ScriptNameEntity)then return false end
local Jkp2lGXG=GetPosition(self.ScriptNameEntity)local ifcyuS
if
Logic.IsEntityTypeInCategory(self.UnitKey,EntityCategories.Soldier)==1 then
ifcyuS=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],Jkp2lGXG.X,Jkp2lGXG.Y,self.Orientation,self.PlayerID,1)local R,X6_=Logic.GetSoldiersAttachedToLeader(ifcyuS)
Logic.SetOrientation(X6_,API.Round(self.Orientation))else
ifcyuS=Logic.CreateEntityOnUnblockedLand(Entities[self.UnitKey],Jkp2lGXG.X,Jkp2lGXG.Y,self.Orientation,self.PlayerID)end;local V03W=GetID(self.ScriptNameEntity)if
Logic.IsBuilding(V03W)==0 then DestroyEntity(self.ScriptNameEntity)
Logic.SetEntityName(ifcyuS,self.ScriptNameEntity)end;if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,ifcyuS,true)end end
function B_Reward_CreateEntity:GetCustomData(tN5u)local Yqc0GWr={}
if tN5u==2 then
for UC7,WbvvcjER in pairs(Entities)do
local rOLxXC={"^M_*","^XS_*","^X_*","^XT_*","^Z_*"}local w762p7sZ=false;for _7jt=1,#rOLxXC do
if UC7:find(rOLxXC[_7jt])then w762p7sZ=true;break end end;if not w762p7sZ then
table.insert(Yqc0GWr,UC7)end end;table.sort(Yqc0GWr)elseif tN5u==4 or tN5u==5 then
table.insert(Yqc0GWr,"false")table.insert(Yqc0GWr,"true")else assert(false)end;return Yqc0GWr end
function B_Reward_CreateEntity:Debug(ORXyFQ)
if not Entities[self.UnitKey]then
error(ORXyFQ.Identifier..
": "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
error(ORXyFQ.Identifier..
": "..self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<0 or self.PlayerID>8 then
error(ORXyFQ.Identifier..": "..self.Name..
": playerID is not valid!")return true elseif tonumber(self.Orientation)==nil then
error(ORXyFQ.Identifier..": "..self.Name..
": orientation must be a number!")return true end;return false end;Swift:RegisterBehavior(B_Reward_CreateEntity)
B_Reward_CreateSettler=Swift:CopyTable(B_Reward_CreateEntity)B_Reward_CreateSettler.Name="Reward_CreateSettler"
B_Reward_CreateSettler.Description.en="Reward: Replaces an entity by a new one of a given type"
B_Reward_CreateSettler.Description.de="Lohn: Ersetzt eine Entity durch eine neue gegebenen Typs"Swift:RegisterBehavior(B_Reward_CreateSettler)function Reward_CreateSeveralEntities(...)return
B_Reward_CreateSeveralEntities:new(...)end
B_Reward_CreateSeveralEntities={Name="Reward_CreateSeveralEntities",Description={en="Reward: Creating serveral battalions at the position of a entity. They retains the entities name and a _[index] suffix",de="Lohn: Erzeugt mehrere Entities an der Position der Entity. Sie übernimmt den Namen der Script Entity und den Suffix _[index]"},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}
function B_Reward_CreateSeveralEntities:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_CreateSeveralEntities:AddParameter(OL1oV,Q)
if(OL1oV==0)then self.Amount=Q*1 elseif
(OL1oV==1)then self.ScriptNameEntity=Q elseif(OL1oV==2)then self.PlayerID=Q*1 elseif(OL1oV==3)then
self.UnitKey=Q elseif(OL1oV==4)then self.Orientation=Q*1 elseif(OL1oV==5)then
self.HideFromAI=API.ToBoolean(Q)end end
function B_Reward_CreateSeveralEntities:CustomFunction(HQvT5)if
not IsExisting(self.ScriptNameEntity)then return false end
local dN=GetPosition(self.ScriptNameEntity)local B35igHj
for o8pPC2=1,self.Amount do
if
Logic.IsEntityTypeInCategory(self.UnitKey,EntityCategories.Soldier)==1 then
B35igHj=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],dN.X,dN.Y,self.Orientation,self.PlayerID,1)local f7nUIW,bDgD=Logic.GetSoldiersAttachedToLeader(B35igHj)
Logic.SetOrientation(bDgD,API.Round(self.Orientation))else
B35igHj=Logic.CreateEntityOnUnblockedLand(Entities[self.UnitKey],dN.X,dN.Y,self.Orientation,self.PlayerID)end
Logic.SetEntityName(B35igHj,self.ScriptNameEntity.."_"..o8pPC2)if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,B35igHj,true)end end end
function B_Reward_CreateSeveralEntities:GetCustomData(Kg8PhSq)local Tcv_={}
if Kg8PhSq==3 then
for lygY,HG in pairs(Entities)do
local u={"^M_*","^XS_*","^X_*","^XT_*","^Z_*"}local m9i=false
for EqPMP=1,#u do if lygY:find(u[EqPMP])then m9i=true;break end end;if not m9i then table.insert(Tcv_,lygY)end end;table.sort(Tcv_)elseif Kg8PhSq==5 or Kg8PhSq==6 then
table.insert(Tcv_,"false")table.insert(Tcv_,"true")else assert(false)end;return Tcv_ end
function B_Reward_CreateSeveralEntities:Debug(JR)
if not Entities[self.UnitKey]then
error(
JR.Identifier..": "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
error(JR.Identifier..": "..
self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
error(JR.Identifier..": "..self.Name..
": spawnpoint does not exist!")return true elseif tonumber(self.Orientation)==nil then
error(JR.Identifier..": "..self.Name..
": orientation must be a number!")return true elseif
tonumber(self.Amount)==nil or self.Amount<0 then
error(JR.Identifier..
": "..self.Name..": amount can not be negative!")return true end;return false end
Swift:RegisterBehavior(B_Reward_CreateSeveralEntities)
function Reward_MoveSettler(...)return B_Reward_MoveSettler:new(...)end
B_Reward_MoveSettler={Name="Reward_MoveSettler",Description={en="Reward: Moves a (NPC) settler to a destination. Must not be AI controlled, or it won't move",de="Lohn: Bewegt einen (NPC) Siedler zu einem Zielort. Darf keinem KI Spieler gehören, ansonsten wird sich der Siedler nicht bewegen"},Parameter={{ParameterType.ScriptName,en="Settler",de="Siedler"},{ParameterType.ScriptName,en="Destination",de="Ziel"}}}function B_Reward_MoveSettler:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function B_Reward_MoveSettler:AddParameter(G1Cl6,h)
if(
G1Cl6 ==0)then self.ScriptNameUnit=h elseif(G1Cl6 ==1)then self.ScriptNameDest=h end end
function B_Reward_MoveSettler:CustomFunction(fYUikw)if

Logic.IsEntityDestroyed(self.ScriptNameUnit)or Logic.IsEntityDestroyed(self.ScriptNameDest)then return false end
local W9qTCm=GetID(self.ScriptNameDest)local YlaSjEKp,u_ogp8=Logic.GetEntityPosition(W9qTCm)if
Logic.IsBuilding(W9qTCm)==1 then
YlaSjEKp,u_ogp8=Logic.GetBuildingApproachPosition(W9qTCm)end
Logic.MoveSettler(GetID(self.ScriptNameUnit),YlaSjEKp,u_ogp8)end
function B_Reward_MoveSettler:Debug(K)
if not IsExisting(self.ScriptNameUnit)then
error(
K.Identifier..": "..self.Name..": mover entity does not exist!")return true elseif not IsExisting(self.ScriptNameDest)then
error(K.Identifier..": "..self.Name..
": destination does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reward_MoveSettler)function Reward_Victory()return
B_Reward_Victory:new()end
B_Reward_Victory={Name="Reward_Victory",Description={en="Reward: The player wins the game.",de="Lohn: Der Spieler gewinnt das Spiel."}}
function B_Reward_Victory:GetRewardTable()return{Reward.Victory}end;Swift:RegisterBehavior(B_Reward_Victory)function Reward_Defeat()return
B_Reward_Defeat:new()end
B_Reward_Defeat={Name="Reward_Defeat",Description={en="Reward: The player loses the game.",de="Lohn: Der Spieler verliert das Spiel."}}function B_Reward_Defeat:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_Defeat:CustomFunction(ob)
ob:TerminateEventsAndStuff()
Logic.ExecuteInLuaLocalState("GUI_Window.MissionEndScreenSetVictoryReasonText("..
g_VictoryAndDefeatType.DefeatMissionFailed..")")Defeated(ob.ReceivingPlayer)end;Swift:RegisterBehavior(B_Reward_Defeat)function Reward_FakeVictory()return
B_Reward_FakeVictory:new()end
B_Reward_FakeVictory={Name="Reward_FakeVictory",Description={en="Reward: Display a victory icon for a quest",de="Lohn: Zeigt ein Siegesicon fuer diese Quest"}}
function B_Reward_FakeVictory:GetRewardTable()return{Reward.FakeVictory}end;Swift:RegisterBehavior(B_Reward_FakeVictory)
function Reward_AI_SpawnAndAttackTerritory(...)return
B_Reward_AI_SpawnAndAttackTerritory:new(...)end
B_Reward_AI_SpawnAndAttackTerritory={Name="Reward_AI_SpawnAndAttackTerritory",Description={en="Reward: Spawns AI troops and attacks a territory (Hint: Use for hidden quests as a surprise)",de="Lohn: Erstellt KI Truppen und greift ein Territorium an (Tipp: Fuer eine versteckte Quest als Ueberraschung verwenden)"},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.ScriptName,en="Spawn point",de="Erstellungsort"},{ParameterType.TerritoryName,en="Territory",de="Territorium"},{ParameterType.Number,en="Sword",de="Schwert"},{ParameterType.Number,en="Bow",de="Bogen"},{ParameterType.Number,en="Catapults",de="Katapulte"},{ParameterType.Number,en="Siege towers",de="Belagerungstuerme"},{ParameterType.Number,en="Rams",de="Rammen"},{ParameterType.Number,en="Ammo carts",de="Munitionswagen"},{ParameterType.Custom,en="Soldier type",de="Soldatentyp"},{ParameterType.Custom,en="Reuse troops",de="Verwende bestehende Truppen"}}}
function B_Reward_AI_SpawnAndAttackTerritory:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_AI_SpawnAndAttackTerritory:AddParameter(a3,MvWxr)
if(a3 ==0)then
self.AIPlayerID=MvWxr*1 elseif(a3 ==1)then self.Spawnpoint=MvWxr elseif(a3 ==2)then
self.TerritoryID=tonumber(MvWxr)if not self.TerritoryID then
self.TerritoryID=GetTerritoryIDByName(MvWxr)end elseif(a3 ==3)then self.NumSword=MvWxr*1 elseif
(a3 ==4)then self.NumBow=MvWxr*1 elseif(a3 ==5)then self.NumCatapults=MvWxr*1 elseif(a3 ==6)then self.NumSiegeTowers=
MvWxr*1 elseif(a3 ==7)then self.NumRams=MvWxr*1 elseif(a3 ==8)then
self.NumAmmoCarts=MvWxr*1 elseif(a3 ==9)then
if MvWxr=="Normal"or MvWxr==false then self.TroopType=false elseif MvWxr==
"RedPrince"or MvWxr==true then self.TroopType=true elseif MvWxr=="Bandit"or
MvWxr==2 then self.TroopType=2 elseif MvWxr=="Cultist"or MvWxr==3 then
self.TroopType=3 else assert(false)end elseif(a3 ==10)then self.ReuseTroops=API.ToBoolean(MvWxr)end end
function B_Reward_AI_SpawnAndAttackTerritory:GetCustomData(HgY6)local Wc={}
if HgY6 ==9 then
table.insert(Wc,"Normal")table.insert(Wc,"RedPrince")
table.insert(Wc,"Bandit")
if g_GameExtraNo>=1 then table.insert(Wc,"Cultist")end elseif HgY6 ==10 then table.insert(Wc,"false")
table.insert(Wc,"true")else assert(false)end;return Wc end
function B_Reward_AI_SpawnAndAttackTerritory:CustomFunction(eQ5)
local kvR=Logic.GetTerritoryAcquiringBuildingID(self.TerritoryID)
if kvR~=0 then
AIScript_SpawnAndAttackCity(self.AIPlayerID,kvR,self.Spawnpoint,self.NumSword,self.NumBow,self.NumCatapults,self.NumSiegeTowers,self.NumRams,self.NumAmmoCarts,self.TroopType,self.ReuseTroops)end end
function B_Reward_AI_SpawnAndAttackTerritory:Debug(So)
if self.AIPlayerID<2 then
error(So.Identifier..": "..
self.Name..
": Player "..self.AIPlayerID.." is wrong")return true elseif Logic.IsEntityDestroyed(self.Spawnpoint)then
error(So.Identifier..
": "..self.Name..": Entity "..
self.SpawnPoint.." is missing")return true elseif self.TerritoryID==0 then
error(So.Identifier..
": "..self.Name..": Territory unknown")return true elseif self.NumSword<0 then
error(So.Identifier..": "..
self.Name..": Number of Swords is negative")return true elseif self.NumBow<0 then
error(So.Identifier..": "..
self.Name..": Number of Bows is negative")return true elseif self.NumBow+self.NumSword<1 then
error(So.Identifier..": "..self.Name..
": No Soldiers?")return true elseif self.NumCatapults<0 then
error(So.Identifier..": "..
self.Name..": Catapults is negative")return true elseif self.NumSiegeTowers<0 then
error(So.Identifier..": "..
self.Name..": SiegeTowers is negative")return true elseif self.NumRams<0 then
error(So.Identifier..
": "..self.Name..": Rams is negative")return true elseif self.NumAmmoCarts<0 then
error(So.Identifier..": "..
self.Name..": AmmoCarts is negative")return true end;return false end
Swift:RegisterBehavior(B_Reward_AI_SpawnAndAttackTerritory)function Reward_AI_SpawnAndAttackArea(...)
return B_Reward_AI_SpawnAndAttackArea:new(...)end
B_Reward_AI_SpawnAndAttackArea={Name="Reward_AI_SpawnAndAttackArea",Description={en="Reward: Spawns AI troops and attacks everything within the specified area, except the players main buildings",de="Lohn: Erstellt KI Truppen und greift ein angegebenes Gebiet an, aber nicht die Hauptgebauede eines Spielers"},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.ScriptName,en="Spawn point",de="Erstellungsort"},{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Number,en="Radius",de="Radius"},{ParameterType.Number,en="Sword",de="Schwert"},{ParameterType.Number,en="Bow",de="Bogen"},{ParameterType.Custom,en="Soldier type",de="Soldatentyp"},{ParameterType.Custom,en="Reuse troops",de="Verwende bestehende Truppen"}}}
function B_Reward_AI_SpawnAndAttackArea:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_AI_SpawnAndAttackArea:AddParameter(Wi,X1WM)
if(Wi==0)then self.AIPlayerID=X1WM*1 elseif
(Wi==1)then self.Spawnpoint=X1WM elseif(Wi==2)then self.TargetName=X1WM elseif(Wi==3)then
self.Radius=X1WM*1 elseif(Wi==4)then self.NumSword=X1WM*1 elseif(Wi==5)then self.NumBow=X1WM*1 elseif(Wi==6)then
if
X1WM=="Normal"or X1WM==false then self.TroopType=false elseif
X1WM=="RedPrince"or X1WM==true then self.TroopType=true elseif X1WM=="Bandit"or X1WM==2 then self.TroopType=2 elseif X1WM==
"Cultist"or X1WM==3 then self.TroopType=3 else assert(false)end elseif(Wi==7)then self.ReuseTroops=API.ToBoolean(X1WM)end end
function B_Reward_AI_SpawnAndAttackArea:GetCustomData(OVBAVy)local Joa={}
if OVBAVy==6 then
table.insert(Joa,"Normal")table.insert(Joa,"RedPrince")
table.insert(Joa,"Bandit")
if g_GameExtraNo>=1 then table.insert(Joa,"Cultist")end elseif OVBAVy==7 then table.insert(Joa,"false")
table.insert(Joa,"true")else assert(false)end;return Joa end
function B_Reward_AI_SpawnAndAttackArea:CustomFunction(NF0)
if

Logic.IsEntityAlive(self.TargetName)and Logic.IsEntityAlive(self.Spawnpoint)then local OeF=GetID(self.TargetName)
AIScript_SpawnAndRaidSettlement(self.AIPlayerID,OeF,self.Spawnpoint,self.Radius,self.NumSword,self.NumBow,self.TroopType,self.ReuseTroops)end end
function B_Reward_AI_SpawnAndAttackArea:Debug(sawaLtSr)
if self.AIPlayerID<2 then
error(sawaLtSr.Identifier..": "..

self.Name..": Player "..self.AIPlayerID.." is wrong")return true elseif Logic.IsEntityDestroyed(self.Spawnpoint)then
error(sawaLtSr.Identifier..": "..

self.Name..": Entity "..self.SpawnPoint.." is missing")return true elseif Logic.IsEntityDestroyed(self.TargetName)then
error(sawaLtSr.Identifier..": "..

self.Name..": Entity "..self.TargetName.." is missing")return true elseif self.Radius<1 then
error(sawaLtSr.Identifier..": "..
self.Name..": Radius is to small or negative")return true elseif self.NumSword<0 then
error(sawaLtSr.Identifier..": "..
self.Name..": Number of Swords is negative")return true elseif self.NumBow<0 then
error(sawaLtSr.Identifier..": "..
self.Name..": Number of Bows is negative")return true elseif self.NumBow+self.NumSword<1 then
error(sawaLtSr.Identifier..": "..self.Name..
": No Soldiers?")return true end;return false end
Swift:RegisterBehavior(B_Reward_AI_SpawnAndAttackArea)function Reward_AI_SpawnAndProtectArea(...)
return B_Reward_AI_SpawnAndProtectArea:new(...)end
B_Reward_AI_SpawnAndProtectArea={Name="Reward_AI_SpawnAndProtectArea",Description={en="Reward: Spawns AI troops and defends a specified area",de="Lohn: Erstellt KI Truppen und verteidigt ein angegebenes Gebiet"},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.ScriptName,en="Spawn point",de="Erstellungsort"},{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Number,en="Radius",de="Radius"},{ParameterType.Number,en="Time (-1 for infinite)",de="Zeit (-1 fuer unendlich)"},{ParameterType.Number,en="Sword",de="Schwert"},{ParameterType.Number,en="Bow",de="Bogen"},{ParameterType.Custom,en="Capture tradecarts",de="Handelskarren angreifen"},{ParameterType.Custom,en="Soldier type",de="Soldatentyp"},{ParameterType.Custom,en="Reuse troops",de="Verwende bestehende Truppen"}}}
function B_Reward_AI_SpawnAndProtectArea:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_AI_SpawnAndProtectArea:AddParameter(KWeL,K)
if(KWeL==0)then self.AIPlayerID=K*1 elseif
(KWeL==1)then self.Spawnpoint=K elseif(KWeL==2)then self.TargetName=K elseif(KWeL==3)then
self.Radius=K*1 elseif(KWeL==4)then self.Time=K*1 elseif(KWeL==5)then self.NumSword=K*1 elseif(KWeL==6)then
self.NumBow=K*1 elseif(KWeL==7)then self.CaptureTradeCarts=API.ToBoolean(K)elseif(KWeL==8)then
if
K=="Normal"or K==true then self.TroopType=false elseif K=="RedPrince"or K==false then
self.TroopType=true elseif K=="Bandit"or K==2 then self.TroopType=2 elseif K=="Cultist"or K==3 then
self.TroopType=3 else assert(false)end elseif(KWeL==9)then self.ReuseTroops=API.ToBoolean(K)end end
function B_Reward_AI_SpawnAndProtectArea:GetCustomData(rvhod9t)local bfx5oN={}
if rvhod9t==7 then
table.insert(bfx5oN,"false")table.insert(bfx5oN,"true")elseif rvhod9t==8 then
table.insert(bfx5oN,"Normal")table.insert(bfx5oN,"RedPrince")
table.insert(bfx5oN,"Bandit")
if g_GameExtraNo>=1 then table.insert(bfx5oN,"Cultist")end elseif rvhod9t==9 then table.insert(bfx5oN,"false")
table.insert(bfx5oN,"true")else assert(false)end;return bfx5oN end
function B_Reward_AI_SpawnAndProtectArea:CustomFunction(XDKTNXw)
if

Logic.IsEntityAlive(self.TargetName)and Logic.IsEntityAlive(self.Spawnpoint)then local RyTb=GetID(self.TargetName)
AIScript_SpawnAndProtectArea(self.AIPlayerID,RyTb,self.Spawnpoint,self.Radius,self.NumSword,self.NumBow,self.Time,self.TroopType,self.ReuseTroops,self.CaptureTradeCarts)end end
function B_Reward_AI_SpawnAndProtectArea:Debug(ImqF1v)
if self.AIPlayerID<2 then
error(ImqF1v.Identifier..": "..
self.Name..
": Player "..self.AIPlayerID.." is wrong")return true elseif Logic.IsEntityDestroyed(self.Spawnpoint)then
error(ImqF1v.Identifier..": "..
self.Name..
": Entity "..self.SpawnPoint.." is missing")return true elseif Logic.IsEntityDestroyed(self.TargetName)then
error(ImqF1v.Identifier..": "..
self.Name..
": Entity "..self.TargetName.." is missing")return true elseif self.Radius<1 then
error(ImqF1v.Identifier..": "..
self.Name..": Radius is to small or negative")return true elseif self.Time<-1 then
error(ImqF1v.Identifier..": "..
self.Name..": Time is smaller than -1")return true elseif self.NumSword<0 then
error(ImqF1v.Identifier..": "..
self.Name..": Number of Swords is negative")return true elseif self.NumBow<0 then
error(ImqF1v.Identifier..": "..
self.Name..": Number of Bows is negative")return true elseif self.NumBow+self.NumSword<1 then
error(ImqF1v.Identifier..": "..self.Name..
": No Soldiers?")return true end;return false end
Swift:RegisterBehavior(B_Reward_AI_SpawnAndProtectArea)function Reward_AI_SetNumericalFact(...)
return B_Reward_AI_SetNumericalFact:new(...)end
B_Reward_AI_SetNumericalFact={Name="Reward_AI_SetNumericalFact",Description={en="Reward: Sets a numerical fact for the AI player",de="Lohn: Setzt eine Verhaltensregel fuer den KI-Spieler. "},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.Custom,en="Numerical Fact",de="Verhaltensregel"},{ParameterType.Number,en="Value",de="Wert"}}}
function B_Reward_AI_SetNumericalFact:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_AI_SetNumericalFact:AddParameter(K,Ru)
if(K==0)then self.AIPlayerID=Ru*1 elseif(K==1)then
local Vy5qF={["Courage"]="FEAR",["Reconstruction"]="BARB",["Build Order"]="BPMX",["Conquer Outposts"]="FCOP",["Mount Outposts"]="FMOP",["max. Bowmen"]="FMBM",["max. Swordmen"]="FMSM",["max. Rams"]="FMRA",["max. Catapults"]="FMCA",["max. Ammunition Carts"]="FMAC",["max. Siege Towers"]="FMST",["max. Wall Catapults"]="FMBA",["FEAR"]="FEAR",["BARB"]="BARB",["BPMX"]="BPMX",["FCOP"]="FCOP",["FMOP"]="FMOP",["FMBM"]="FMBM",["FMSM"]="FMSM",["FMRA"]="FMRA",["FMCA"]="FMCA",["FMAC"]="FMAC",["FMST"]="FMST",["FMBA"]="FMBA"}self.NumericalFact=Vy5qF[Ru]elseif(K==2)then self.Value=Ru*1 end end;function B_Reward_AI_SetNumericalFact:CustomFunction(rokDhenZ)
AICore.SetNumericalFact(self.AIPlayerID,self.NumericalFact,self.Value)end
function B_Reward_AI_SetNumericalFact:GetCustomData(td8OL)
if(
td8OL==1)then
return
{"Courage","Reconstruction","Build Order","Conquer Outposts","Mount Outposts","max. Bowmen","max. Swordmen","max. Rams","max. Catapults","max. Ammunition Carts","max. Siege Towers","max. Wall Catapults"}end end
function B_Reward_AI_SetNumericalFact:Debug(W)
if
Logic.GetStoreHouse(self.AIPlayerID)==0 then
error(W.Identifier..": "..self.Name..
": Player "..self.AIPlayerID.." is wrong or dead!")return true elseif not self.NumericalFact then
error(W.Identifier..": "..
self.Name..": invalid numerical fact choosen!")return true else
if
self.NumericalFact=="BARB"or self.NumericalFact=="FCOP"or self.NumericalFact=="FMOP"then
if
self.Value~=0 and self.Value~=1 then
error(W.Identifier..": "..self.Name..
": BARB, FCOP, FMOP: value must be 1 or 0!")return true end elseif self.NumericalFact=="FEAR"then if self.Value<=0 then
error(W.Identifier..": "..self.Name..
": FEAR: value must greater than 0!")return true end else if
self.Value<0 then
error(W.Identifier..
": "..self.Name..": value must always greater than or equal 0!")return true end end end;return false end
Swift:RegisterBehavior(B_Reward_AI_SetNumericalFact)function Reward_AI_Aggressiveness(...)
return B_Reward_AI_Aggressiveness:new(...)end
B_Reward_AI_Aggressiveness={Name="Reward_AI_Aggressiveness",Description={en="Reward: Sets the AI player's aggressiveness.",de="Lohn: Setzt die Aggressivität des KI-Spielers fest."},Parameter={{ParameterType.PlayerID,en="AI player",de="KI-Spieler"},{ParameterType.Custom,en="Aggressiveness (1-3)",de="Aggressivität (1-3)"}}}
function B_Reward_AI_Aggressiveness:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_AI_Aggressiveness:AddParameter(CS,i)if CS==0 then self.AIPlayer=i*1 elseif CS==1 then
self.Aggressiveness=tonumber(i)end end
function B_Reward_AI_Aggressiveness:CustomFunction()
local v2VylMn=(PlayerAIs[self.AIPlayer]or
AIPlayerTable[self.AIPlayer]or
AIPlayer:new(self.AIPlayer,AIPlayerProfile_City))PlayerAIs[self.AIPlayer]=v2VylMn
if self.Aggressiveness>=2 then
v2VylMn.m_ProfileLoop=AIProfile_Skirmish;v2VylMn.Skirmish=v2VylMn.Skirmish or{}
v2VylMn.Skirmish.Claim_MinTime=
SkirmishDefault.Claim_MinTime+ (self.Aggressiveness-2)*390
v2VylMn.Skirmish.Claim_MaxTime=v2VylMn.Skirmish.Claim_MinTime*2 else v2VylMn.m_ProfileLoop=AIPlayerProfile_City end end
function B_Reward_AI_Aggressiveness:Debug(Oi)
if self.AIPlayer<1 or
Logic.GetStoreHouse(self.AIPlayer)==0 then
error(Oi.Identifier..
": "..self.Name..": Player "..
self.AIPlayer.." is wrong")return true end end
function B_Reward_AI_Aggressiveness:GetCustomData(KwcrRu)return{"1","2","3"}end
Swift:RegisterBehavior(B_Reward_AI_Aggressiveness)
function Reward_AI_SetEnemy(...)return B_Reward_AI_SetEnemy:new(...)end
B_Reward_AI_SetEnemy={Name="Reward_AI_SetEnemy",Description={en="Reward:Sets the enemy of an AI player (the AI only handles one enemy properly).",de="Lohn: Legt den Feind eines KI-Spielers fest (die KI behandelt nur einen Feind korrekt)."},Parameter={{ParameterType.PlayerID,en="AI player",de="KI-Spieler"},{ParameterType.PlayerID,en="Enemy",de="Feind"}}}function B_Reward_AI_SetEnemy:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function B_Reward_AI_SetEnemy:AddParameter(bgFJ,fqGD1rfW)
if
bgFJ==0 then self.AIPlayer=fqGD1rfW*1 elseif bgFJ==1 then self.Enemy=fqGD1rfW*1 end end;function B_Reward_AI_SetEnemy:CustomFunction()
local K0=PlayerAIs[self.AIPlayer]
if K0 and K0.Skirmish then K0.Skirmish.Enemy=self.Enemy end end
function B_Reward_AI_SetEnemy:Debug(_1To2)
if
self.AIPlayer<1 or self.AIPlayer>8 or
Logic.PlayerGetIsHumanFlag(self.AIPlayer)then
error(_1To2.Identifier..
": "..self.Name..": Player "..
self.AIPlayer.." is wrong")return true end;return false end;Swift:RegisterBehavior(B_Reward_AI_SetEnemy)function Reward_ReplaceEntity(...)return
B_Reward_ReplaceEntity:new(...)end
B_Reward_ReplaceEntity=Swift:CopyTable(B_Reprisal_ReplaceEntity)B_Reward_ReplaceEntity.Name="Reward_ReplaceEntity"
B_Reward_ReplaceEntity.Description.en="Reward: Replaces an entity with a new one of a different type. The playerID can be changed too."
B_Reward_ReplaceEntity.Description.de="Lohn: Ersetzt eine Entity durch eine neue anderen Typs. Es kann auch die Spielerzugehörigkeit geändert werden."B_Reward_ReplaceEntity.GetReprisalTable=nil
B_Reward_ReplaceEntity.GetRewardTable=function(lkzs,Hhwf3oO)return
{Reward.Custom,{lkzs,lkzs.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_ReplaceEntity)function Reward_SetResourceAmount(...)return
B_Reward_SetResourceAmount:new(...)end
B_Reward_SetResourceAmount={Name="Reward_SetResourceAmount",Description={en="Reward: Set the current and maximum amount of a resource doodad (the amount can also set to 0)",de="Lohn: Setzt die aktuellen sowie maximalen Resourcen in einem Doodad (auch 0 ist möglich)"},Parameter={{ParameterType.ScriptName,en="Ressource",de="Resource"},{ParameterType.Number,en="Amount",de="Menge"}}}
function B_Reward_SetResourceAmount:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_SetResourceAmount:AddParameter(Oh5,LgQF)if(Oh5 ==0)then self.ScriptName=LgQF elseif(Oh5 ==1)then self.Amount=
LgQF*1 end end
function B_Reward_SetResourceAmount:CustomFunction(emGbhJGH)if
Logic.IsEntityDestroyed(self.ScriptName)then return false end
local e_Ev8OQ=GetID(self.ScriptName)
if Logic.GetResourceDoodadGoodType(e_Ev8OQ)==0 then return false end
Logic.SetResourceDoodadGoodAmount(e_Ev8OQ,self.Amount)end
function B_Reward_SetResourceAmount:Debug(zBMvU6)
if not IsExisting(self.ScriptName)then
error(
zBMvU6.Identifier..": "..self.Name..": resource entity does not exist!")return true elseif
not type(self.Amount)=="number"or self.Amount<0 then
error(zBMvU6.Identifier..
": "..self.Name..": resource amount can not be negative!")return true end;return false end
Swift:RegisterBehavior(B_Reward_SetResourceAmount)
function Reward_Resources(...)return B_Reward_Resources:new(...)end
B_Reward_Resources={Name="Reward_Resources",Description={en="Reward: The player receives a given amount of Goods in his store.",de="Lohn: Legt der Partei die angegebenen Rohstoffe ins Lagerhaus."},Parameter={{ParameterType.RawGoods,en="Type of good",de="Resourcentyp"},{ParameterType.Number,en="Amount of good",de="Anzahl der Resource"}}}
function B_Reward_Resources:AddParameter(ZmbDgbg,hMxy)if(ZmbDgbg==0)then self.GoodTypeName=hMxy elseif
(ZmbDgbg==1)then self.GoodAmount=hMxy*1 end end
function B_Reward_Resources:GetRewardTable()
local hj3=Logic.GetGoodTypeID(self.GoodTypeName)return{Reward.Resources,hj3,self.GoodAmount}end;Swift:RegisterBehavior(B_Reward_Resources)function Reward_SendCart(...)return
B_Reward_SendCart:new(...)end
B_Reward_SendCart={Name="Reward_SendCart",Description={en="Reward: Sends a cart to a player. It spawns at a building or by replacing an entity. The cart can replace the entity if it's not a building.",de="Lohn: Sendet einen Karren zu einem Spieler. Der Karren wird an einem Gebäude oder einer Entity erstellt. Er ersetzt die Entity, wenn diese kein Gebäude ist."},Parameter={{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Owning player",de="Besitzer"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Custom,en="Good type",de="Warentyp"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.Custom,en="Override target player",de="Anderer Zielspieler"},{ParameterType.Custom,en="Ignore reservations",de="Ignoriere Reservierungen"},{ParameterType.Custom,en="Replace entity",de="Entity ersetzen"}}}function B_Reward_SendCart:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_SendCart:AddParameter(M7q3pa8,guEhw)
if(
M7q3pa8 ==0)then self.ScriptNameEntity=guEhw elseif(M7q3pa8 ==1)then
self.PlayerID=guEhw*1 elseif(M7q3pa8 ==2)then self.UnitKey=guEhw elseif(M7q3pa8 ==3)then self.GoodType=guEhw elseif(
M7q3pa8 ==4)then self.GoodAmount=guEhw*1 elseif(M7q3pa8 ==5)then
self.OverrideTargetPlayer=tonumber(guEhw)elseif(M7q3pa8 ==6)then self.IgnoreReservation=API.ToBoolean(guEhw)elseif
(M7q3pa8 ==7)then self.ReplaceEntity=API.ToBoolean(guEhw)end end
function B_Reward_SendCart:CustomFunction(sll)if
not IsExisting(self.ScriptNameEntity)then return false end
local BzNBgGvD=API.SendCart(self.ScriptNameEntity,self.PlayerID,Goods[self.GoodType],self.GoodAmount,Entities[self.UnitKey],self.IgnoreReservation)
if self.ReplaceEntity and
Logic.IsBuilding(GetID(self.ScriptNameEntity))==0 then
DestroyEntity(self.ScriptNameEntity)
Logic.SetEntityName(BzNBgGvD,self.ScriptNameEntity)end;if self.OverrideTargetPlayer then
Logic.ResourceMerchant_OverrideTargetPlayerID(BzNBgGvD,self.OverrideTargetPlayer)end end
function B_Reward_SendCart:GetCustomData(KIQCH)local L4bw={}
if KIQCH==2 then
L4bw={"U_ResourceMerchant","U_Medicus","U_Marketer","U_ThiefCart","U_GoldCart","U_Noblemen_Cart","U_RegaliaCart"}elseif KIQCH==3 then
for XhBEPD,Uq in pairs(Goods)do if string.find(XhBEPD,"^G_")then
table.insert(L4bw,XhBEPD)end end;table.sort(L4bw)elseif KIQCH==5 then table.insert(L4bw,"-")for RmyiI_D=1,8 do
table.insert(L4bw,RmyiI_D)end elseif KIQCH==6 then table.insert(L4bw,"false")
table.insert(L4bw,"true")elseif KIQCH==7 then table.insert(L4bw,"false")
table.insert(L4bw,"true")end;return L4bw end
function B_Reward_SendCart:Debug(w_2iiJwx)
if not IsExisting(self.ScriptNameEntity)then
error(
w_2iiJwx.Identifier..": "..self.Name..": spawnpoint does not exist!")return true elseif
not tonumber(self.PlayerID)or self.PlayerID<1 or self.PlayerID>8 then
error(w_2iiJwx.Identifier..": "..self.Name..
": got a invalid playerID!")return true elseif not Entities[self.UnitKey]then
error(w_2iiJwx.Identifier..": "..
self.Name..
": entity type '"..self.UnitKey.."' is invalid!")return true elseif not Goods[self.GoodType]then
error(w_2iiJwx.Identifier..": "..
self.Name..": good type '"..
self.GoodType.."' is invalid!")return true elseif
not tonumber(self.GoodAmount)or self.GoodAmount<1 then
error(w_2iiJwx.Identifier..
": "..self.Name..": good amount can not be below 1!")return true elseif
tonumber(self.OverrideTargetPlayer)and(self.OverrideTargetPlayer<1 or
self.OverrideTargetPlayer>8)then
error(w_2iiJwx.Identifier..": "..
self.Name..": overwrite target player with invalid playerID!")return true end;return false end;Swift:RegisterBehavior(B_Reward_SendCart)function Reward_Units(...)return
B_Reward_Units:new(...)end
B_Reward_Units={Name="Reward_Units",Description={en="Reward: Units",de="Lohn: Einheiten"},Parameter={{ParameterType.Entity,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"}}}
function B_Reward_Units:AddParameter(RRESd,S1qoVmFR)if(RRESd==0)then self.EntityName=S1qoVmFR elseif(RRESd==1)then self.Amount=
S1qoVmFR*1 end end
function B_Reward_Units:GetRewardTable()return
{Reward.Units,assert(Entities[self.EntityName]),self.Amount}end;Swift:RegisterBehavior(B_Reward_Units)function Reward_QuestRestart(...)return
B_Reward_QuestRestart:new(...)end
B_Reward_QuestRestart=Swift:CopyTable(B_Reprisal_QuestRestart)B_Reward_QuestRestart.Name="Reward_QuestRestart"
B_Reward_QuestRestart.Description.en="Reward: Restarts a (completed) quest so it can be triggered and completed again."
B_Reward_QuestRestart.Description.de="Lohn: Startet eine (beendete) Quest neu, damit diese neu ausgelöst und beendet werden kann."B_Reward_QuestRestart.GetReprisalTable=nil
B_Reward_QuestRestart.GetRewardTable=function(f2,O3rHR)return
{Reward.Custom,{f2,f2.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_QuestRestart)function Reward_QuestFailure(...)return
B_Reward_QuestFailure:new(...)end
B_Reward_QuestFailure=Swift:CopyTable(B_Reprisal_QuestFailure)B_Reward_QuestFailure.Name="Reward_QuestFailure"
B_Reward_QuestFailure.Description.en="Reward: Lets another active quest fail."
B_Reward_QuestFailure.Description.de="Lohn: Lässt eine andere aktive Quest fehlschlagen."B_Reward_QuestFailure.GetReprisalTable=nil
B_Reward_QuestFailure.GetRewardTable=function(YU80,ARnO_0E)return
{Reward.Custom,{YU80,YU80.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_QuestFailure)function Reward_QuestSuccess(...)return
B_Reward_QuestSuccess:new(...)end
B_Reward_QuestSuccess=Swift:CopyTable(B_Reprisal_QuestSuccess)B_Reward_QuestSuccess.Name="Reward_QuestSuccess"
B_Reward_QuestSuccess.Description.en="Reward: Completes another active quest successfully."
B_Reward_QuestSuccess.Description.de="Lohn: Beendet eine andere aktive Quest erfolgreich."B_Reward_QuestSuccess.GetReprisalTable=nil
B_Reward_QuestSuccess.GetRewardTable=function(Qh,lqxbMC)return
{Reward.Custom,{Qh,Qh.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_QuestSuccess)function Reward_QuestActivate(...)return
B_Reward_QuestActivate:new(...)end
B_Reward_QuestActivate=Swift:CopyTable(B_Reprisal_QuestActivate)B_Reward_QuestActivate.Name="Reward_QuestActivate"
B_Reward_QuestActivate.Description.en="Reward: Activates another quest that is not triggered yet."
B_Reward_QuestActivate.Description.de="Lohn: Aktiviert eine andere Quest die noch nicht ausgelöst wurde."B_Reward_QuestActivate.GetReprisalTable=nil
B_Reward_QuestActivate.GetRewardTable=function(qOk5Jm,tpSe2fs)return
{Reward.Custom,{qOk5Jm,qOk5Jm.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_QuestActivate)function Reward_QuestInterrupt(...)return
B_Reward_QuestInterrupt:new(...)end
B_Reward_QuestInterrupt=Swift:CopyTable(B_Reprisal_QuestInterrupt)B_Reward_QuestInterrupt.Name="Reward_QuestInterrupt"
B_Reward_QuestInterrupt.Description.en="Reward: Interrupts another active quest without success or failure."
B_Reward_QuestInterrupt.Description.de="Lohn: Beendet eine andere aktive Quest ohne Erfolg oder Misserfolg."B_Reward_QuestInterrupt.GetReprisalTable=nil
B_Reward_QuestInterrupt.GetRewardTable=function(AuVgc7,vxnB)return
{Reward.Custom,{AuVgc7,AuVgc7.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_QuestInterrupt)function Reward_QuestForceInterrupt(...)return
B_Reward_QuestForceInterrupt:new(...)end
B_Reward_QuestForceInterrupt=Swift:CopyTable(B_Reprisal_QuestForceInterrupt)
B_Reward_QuestForceInterrupt.Name="Reward_QuestForceInterrupt"
B_Reward_QuestForceInterrupt.Description.en="Reward: Interrupts another quest (even when it isn't active yet) without success or failure."
B_Reward_QuestForceInterrupt.Description.de="Lohn: Beendet eine andere Quest, auch wenn diese noch nicht aktiv ist ohne Erfolg oder Misserfolg."B_Reward_QuestForceInterrupt.GetReprisalTable=nil
B_Reward_QuestForceInterrupt.GetRewardTable=function(ZQOXXXd,cyBmTv)return
{Reward.Custom,{ZQOXXXd,ZQOXXXd.CustomFunction}}end
Swift:RegisterBehavior(B_Reward_QuestForceInterrupt)
function Reward_CustomVariables(...)return B_Reward_CustomVariables:new(...)end
B_Reward_CustomVariables=Swift:CopyTable(B_Reprisal_CustomVariables)B_Reward_CustomVariables.Name="Reward_CustomVariables"
B_Reward_CustomVariables.Description.en="Reward: Executes a mathematical operation with this variable. The other operand can be a number or another custom variable."
B_Reward_CustomVariables.Description.de="Lohn: Führt eine mathematische Operation mit der Variable aus. Der andere Operand kann eine Zahl oder eine Custom-Varible sein."B_Reward_CustomVariables.GetReprisalTable=nil
B_Reward_CustomVariables.GetRewardTable=function(_TKd0F,Z)return
{Reward.Custom,{_TKd0F,_TKd0F.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_CustomVariables)function Reward_MapScriptFunction(...)return
B_Reward_MapScriptFunction:new(...)end
B_Reward_MapScriptFunction=Swift:CopyTable(B_Reprisal_MapScriptFunction)B_Reward_MapScriptFunction.Name="Reward_MapScriptFunction"
B_Reward_MapScriptFunction.Description.en="Reward: Calls a function within the global map script if the quest has failed."
B_Reward_MapScriptFunction.Description.de="Lohn: Ruft eine Funktion im globalen Kartenskript auf, wenn die Quest fehlschlägt."B_Reward_MapScriptFunction.GetReprisalTable=nil
B_Reward_MapScriptFunction.GetRewardTable=function(Dw,bsFpM)return
{Reward.Custom,{Dw,Dw.CustomFunction}}end
Swift:RegisterBehavior(B_Reward_MapScriptFunction)
function Reward_Technology(...)return B_Reward_Technology:new(...)end
B_Reward_Technology=Swift:CopyTable(B_Reprisal_Technology)B_Reward_Technology.Name="Reward_Technology"
B_Reward_Technology.Description.en="Reward: Locks or unlocks a technology for the given player."
B_Reward_Technology.Description.de="Lohn: Sperrt oder erlaubt eine Technolgie fuer den angegebenen Player."B_Reward_Technology.GetReprisalTable=nil
B_Reward_Technology.GetRewardTable=function(h,doBTofya)return
{Reward.Custom,{h,h.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_Technology)function Reward_PrestigePoints(...)return
B_Reward_PrestigePoints:mew(...)end
B_Reward_PrestigePoints={Name="Reward_PrestigePoints",Description={en="Reward: Prestige",de="Lohn: Prestige"},Parameter={{ParameterType.Number,en="Points",de="Punkte"}}}
function B_Reward_PrestigePoints:AddParameter(rNP,TL)if(rNP==0)then self.Points=TL end end;function B_Reward_PrestigePoints:GetRewardTable()
return{Reward.PrestigePoints,self.Points}end
Swift:RegisterBehavior(B_Reward_PrestigePoints)
function Reward_AI_MountOutpost(...)return B_Reward_AI_MountOutpost:new(...)end
B_Reward_AI_MountOutpost={Name="Reward_AI_MountOutpost",Description={en="Reward: Places a troop of soldiers on a named outpost.",de="Lohn: Platziert einen Trupp Soldaten auf einem Aussenposten der KI."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Soldiers type",de="Soldatentyp"}}}
function B_Reward_AI_MountOutpost:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_AI_MountOutpost:AddParameter(Tzgj_W,g0AS39)if Tzgj_W==0 then self.Scriptname=g0AS39 else
self.SoldiersType=g0AS39 end end
function B_Reward_AI_MountOutpost:CustomFunction(t2)
local PDewNmM=assert(not
Logic.IsEntityDestroyed(self.Scriptname)and GetID(self.Scriptname),
t2.Identifier..
": Error in "..self.Name..": CustomFunction: Outpost is invalid")local GFlD=Logic.EntityGetPlayer(PDewNmM)
local y3owm5E,psHOEe2=Logic.GetBuildingApproachPosition(PDewNmM)
local R1zT=Logic.CreateBattalionOnUnblockedLand(Entities[self.SoldiersType],y3owm5E,psHOEe2,0,GFlD,0)AICore.HideEntityFromAI(GFlD,R1zT,true)
Logic.CommandEntityToMountBuilding(R1zT,PDewNmM)end
function B_Reward_AI_MountOutpost:GetCustomData(J2Df)
if J2Df==1 then local YyS={}
for o,MY16y in pairs(Entities)do
if
string.find(o,"U_MilitaryBandit")or string.find(o,"U_MilitarySword")or
string.find(o,"U_MilitaryBow")then YyS[#YyS+1]=o end end;return YyS end end
function B_Reward_AI_MountOutpost:Debug(ZBUghmX)
if Logic.IsEntityDestroyed(self.Scriptname)then
error(
ZBUghmX.Identifier..": "..
self.Name..": Outpost "..self.Scriptname.." is missing")return true end end;Swift:RegisterBehavior(B_Reward_AI_MountOutpost)function Reward_QuestRestartForceActive(...)return
B_Reward_QuestRestartForceActive:new(...)end
B_Reward_QuestRestartForceActive={Name="Reward_QuestRestartForceActive",Description={en="Reward: Restarts a (completed) quest and triggers it immediately.",de="Lohn: Startet eine (beendete) Quest neu und triggert sie sofort."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function B_Reward_QuestRestartForceActive:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function B_Reward_QuestRestartForceActive:AddParameter(ncK,Deq)self.QuestName=Deq end
function B_Reward_QuestRestartForceActive:CustomFunction(GH3wE)
local xZFv,bc0w4j=self:ResetQuest(GH3wE)if xZFv then bc0w4j:SetMsgKeyOverride()
bc0w4j:SetIconOverride()bc0w4j:Trigger()end end
B_Reward_QuestRestartForceActive.ResetQuest=B_Reward_QuestRestart.CustomFunction
function B_Reward_QuestRestartForceActive:Debug(OGMxal0)
if not
Quests[GetQuestID(self.QuestName)]then
error(OGMxal0.Identifier..
": "..self.Name..": Quest: "..
self.QuestName.." does not exist")return true end;return false end
Swift:RegisterBehavior(B_Reward_QuestRestartForceActive)
function Reward_UpgradeBuilding(...)return B_Reward_UpgradeBuilding:new(...)end
B_Reward_UpgradeBuilding={Name="Reward_UpgradeBuilding",Description={en="Reward: Upgrades a building",de="Lohn: Baut ein Gebäude aus"},Parameter={{ParameterType.ScriptName,en="Building",de="Gebäude"}}}
function B_Reward_UpgradeBuilding:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function B_Reward_UpgradeBuilding:AddParameter(QlewVjkq,Q)
if QlewVjkq==0 then self.Building=Q end end
function B_Reward_UpgradeBuilding:CustomFunction(yI)
local EDE3=GetID(self.Building)
if EDE3 ~=0 and Logic.IsBuilding(EDE3)==1 and
Logic.IsBuildingUpgradable(EDE3,true)and
Logic.IsBuildingUpgradable(EDE3,false)then
Logic.UpgradeBuilding(EDE3)end end
function B_Reward_UpgradeBuilding:Debug(FpWG11U)local kRY46C=GetID(self.Building)
if not
(
kRY46C~=0 and
Logic.IsBuilding(kRY46C)==1 and Logic.IsBuildingUpgradable(kRY46C,true)and Logic.IsBuildingUpgradable(kRY46C,false))then
error(
FpWG11U.Identifier..": "..self.Name..": Building is wrong")return true end end;Swift:RegisterBehavior(B_Reward_UpgradeBuilding)function Reward_SetBuildingUpgradeLevel(...)return
B_Reward_SetBuildingUpgradeLevel:new(...)end
B_Reward_SetBuildingUpgradeLevel={Name="Reward_SetBuildingUpgradeLevel",Description={en="Reward: Sets the upgrade level of the specified building.",de="Lohn: Legt das Upgrade-Level eines Gebaeudes fest."},Parameter={{ParameterType.ScriptName,en="Building",de="Gebäude"},{ParameterType.Custom,en="Upgrade level",de="Upgrade-Level"}}}
function B_Reward_SetBuildingUpgradeLevel:GetRewardTable()return
{Reward.Custom,self,self.CustomFunction}end
function B_Reward_SetBuildingUpgradeLevel:AddParameter(MvOaiq,DUic_1K)
if MvOaiq==0 then self.Building=DUic_1K elseif
MvOaiq==1 then self.UpgradeLevel=tonumber(DUic_1K)end end
function B_Reward_SetBuildingUpgradeLevel:CustomFunction()
local rVj9z4=Logic.GetEntityIDByName(self.Building)local mWkmCx=Logic.GetUpgradeLevel(rVj9z4)
local qQpo=Logic.GetMaxUpgradeLevel(rVj9z4)
if rVj9z4 ~=0 and Logic.IsBuilding(rVj9z4)==1 and
(
Logic.IsBuildingUpgradable(rVj9z4,true)or(qQpo~=0 and qQpo==mWkmCx))then
Logic.SetUpgradableBuildingState(rVj9z4,math.min(self.UpgradeLevel,qQpo),0)end end
function B_Reward_SetBuildingUpgradeLevel:Debug(qXKzBXo0)
local cJ=Logic.GetEntityIDByName(self.Building)local HI4G3oH=Logic.GetMaxUpgradeLevel(cJ)
if not cJ or
Logic.IsBuilding(cJ)==0 then
error(qXKzBXo0.Identifier..": "..
self.Name..": Building "..self.Building..
" is missing or no building.")return true elseif not self.UpgradeLevel or self.UpgradeLevel<0 then
error(
qXKzBXo0.Identifier..": "..self.Name..": Upgrade level is wrong")return true end end;function B_Reward_SetBuildingUpgradeLevel:GetCustomData(ncWw)
if ncWw==1 then return{"0","1","2","3"}end end
Swift:RegisterBehavior(B_Reward_SetBuildingUpgradeLevel)function Trigger_PlayerDiscovered(...)
return B_Trigger_PlayerDiscovered:new(...)end
B_Trigger_PlayerDiscovered={Name="Trigger_PlayerDiscovered",Description={en="Trigger: if a given player has been discovered",de="Auslöser: wenn ein angegebener Spieler entdeckt wurde"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function B_Trigger_PlayerDiscovered:GetTriggerTable()return
{Triggers.PlayerDiscovered,self.PlayerID}end;function B_Trigger_PlayerDiscovered:AddParameter(kdS,OS60)
if(kdS==0)then self.PlayerID=OS60*1 end end
Swift:RegisterBehavior(B_Trigger_PlayerDiscovered)
function Trigger_OnDiplomacy(...)return B_Trigger_OnDiplomacy:new(...)end
B_Trigger_OnDiplomacy={Name="Trigger_OnDiplomacy",Description={en="Trigger: if diplomatic relations have been established with a player",de="Auslöser: wenn ein angegebener Diplomatie-Status mit einem Spieler erreicht wurde."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.DiplomacyState,en="Relation",de="Beziehung"}}}
function B_Trigger_OnDiplomacy:GetTriggerTable()return
{Triggers.Diplomacy,self.PlayerID,assert(DiplomacyStates[self.DiplState])}end
function B_Trigger_OnDiplomacy:AddParameter(dl,b2UK)if(dl==0)then self.PlayerID=b2UK*1 elseif(dl==1)then
self.DiplState=b2UK end end;Swift:RegisterBehavior(B_Trigger_OnDiplomacy)function Trigger_OnNeedUnsatisfied(...)return
B_Trigger_OnNeedUnsatisfied:new(...)end
B_Trigger_OnNeedUnsatisfied={Name="Trigger_OnNeedUnsatisfied",Description={en="Trigger: if a specified need is unsatisfied",de="Auslöser: wenn ein bestimmtes Beduerfnis nicht befriedigt ist."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Need,en="Need",de="Beduerfnis"},{ParameterType.Number,en="Workers on strike",de="Streikende Arbeiter"}}}
function B_Trigger_OnNeedUnsatisfied:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnNeedUnsatisfied:AddParameter(FC0yhp,lL30T)
if(FC0yhp==0)then self.PlayerID=lL30T*1 elseif(
FC0yhp==1)then self.Need=lL30T elseif(FC0yhp==2)then self.WorkersOnStrike=lL30T*1 end end
function B_Trigger_OnNeedUnsatisfied:CustomFunction(zt)
return
Logic.GetNumberOfStrikingWorkersPerNeed(self.PlayerID,Needs[self.Need])>=self.WorkersOnStrike end
function B_Trigger_OnNeedUnsatisfied:Debug(Ofgm3g)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
error(Ofgm3g.Identifier..": "..self.Name..
": "..self.PlayerID.." does not exist.")return true elseif not Needs[self.Need]then
error(Ofgm3g.Identifier..": "..self.Name..": "..
self.Need.." does not exist.")return true elseif self.WorkersOnStrike<0 then
error(Ofgm3g.Identifier..": "..
self.Name..": WorkersOnStrike value negative")return true end;return false end
Swift:RegisterBehavior(B_Trigger_OnNeedUnsatisfied)function Trigger_OnResourceDepleted(...)
return B_Trigger_OnResourceDepleted:new(...)end
B_Trigger_OnResourceDepleted={Name="Trigger_OnResourceDepleted",Description={en="Trigger: if a resource is (temporarily) depleted",de="Auslöser: wenn eine Ressource (zeitweilig) verbraucht ist"},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}
function B_Trigger_OnResourceDepleted:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function B_Trigger_OnResourceDepleted:AddParameter(z6WE21dc,rJg9H)
if(z6WE21dc==0)then self.ScriptName=rJg9H end end
function B_Trigger_OnResourceDepleted:CustomFunction(sNyznm3W)
local UU=GetID(self.ScriptName)return

not UU or UU==0 or Logic.GetResourceDoodadGoodType(UU)==0 or Logic.GetResourceDoodadGoodAmount(UU)==0 end
Swift:RegisterBehavior(B_Trigger_OnResourceDepleted)function Trigger_OnAmountOfGoods(...)
return B_Trigger_OnAmountOfGoods:new(...)end
B_Trigger_OnAmountOfGoods={Name="Trigger_OnAmountOfGoods",Description={en="Trigger: if the player has gathered a given amount of resources in his storehouse",de="Auslöser: wenn der Spieler eine bestimmte Menge einer Ressource in seinem Lagerhaus hat"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.RawGoods,en="Type of good",de="Resourcentyp"},{ParameterType.Number,en="Amount of good",de="Anzahl der Resource"}}}
function B_Trigger_OnAmountOfGoods:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnAmountOfGoods:AddParameter(YBciOAz2,wJvNH)if(YBciOAz2 ==0)then self.PlayerID=wJvNH*1 elseif(
YBciOAz2 ==1)then self.GoodTypeName=wJvNH elseif(YBciOAz2 ==2)then
self.GoodAmount=wJvNH*1 end end
function B_Trigger_OnAmountOfGoods:CustomFunction(dOvZoN)
local IP01vP=Logic.GetStoreHouse(self.PlayerID)if(IP01vP==0)then return false end
local DIoX3=Logic.GetGoodTypeID(self.GoodTypeName)
local sjXYan=Logic.GetAmountOnOutStockByGoodType(IP01vP,DIoX3)if(sjXYan>=self.GoodAmount)then return true end
return false end
function B_Trigger_OnAmountOfGoods:Debug(KxB8fW)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
error(KxB8fW.Identifier..": "..self.Name..
": "..self.PlayerID.." does not exist.")return true elseif not Goods[self.GoodTypeName]then
error(KxB8fW.Identifier..": "..self.Name..
": Good type is wrong.")return true elseif self.GoodAmount<0 then
error(KxB8fW.Identifier..": "..
self.Name..": Good amount is negative.")return true end;return false end;Swift:RegisterBehavior(B_Trigger_OnAmountOfGoods)function Trigger_OnQuestActive(...)return
B_Trigger_OnQuestActiveWait:new(...)end
Trigger_OnQuestActiveWait=Trigger_OnQuestActive
B_Trigger_OnQuestActiveWait={Name="Trigger_OnQuestActiveWait",Description={en="Trigger: if a given quest has been activated. Waiting time optional",de="Auslöser: wenn eine angegebene Quest aktiviert wurde. Optional mit Wartezeit"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function B_Trigger_OnQuestActiveWait:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnQuestActiveWait:AddParameter(M,JmyAd)if(M==0)then self.QuestName=JmyAd elseif(M==1)then
self.WaitTime=(
JmyAd~=nil and tonumber(JmyAd))or 0 end end
function B_Trigger_OnQuestActiveWait:CustomFunction(L)
local U=GetQuestID(self.QuestName)
if U~=nil then assert(type(U)=="number")if(Quests[U].State==
QuestState.Active)then
self.WasActivated=self.WasActivated or true end
if self.WasActivated then
if self.WaitTime and
self.WaitTime>0 then
self.WaitTimeTimer=self.WaitTimeTimer or Logic.GetTime()if
Logic.GetTime()>=self.WaitTimeTimer+self.WaitTime then return true end else return true end end end;return false end
function B_Trigger_OnQuestActiveWait:Debug(uAbuU)
if type(self.QuestName)~="string"then
error(
uAbuU.Identifier..": "..self.Name..": invalid quest name!")return true elseif self.WaitTime and
(type(self.WaitTime)~="number"or self.WaitTime<0)then
error(uAbuU.Identifier..": "..
self.Name..": waitTime must be a number!")return true end;return false end;function B_Trigger_OnQuestActiveWait:Interrupt(EF205E)end
function B_Trigger_OnQuestActiveWait:Reset(YFR5myC)self.WaitTimeTimer=
nil;self.WasActivated=nil end
Swift:RegisterBehavior(B_Trigger_OnQuestActiveWait)
B_Trigger_OnQuestActive=Swift:CopyTable(B_Trigger_OnQuestActiveWait)B_Trigger_OnQuestActive.Name="Trigger_OnQuestActive"
B_Trigger_OnQuestActive.Description.en="Reward: Starts the quest after another has been activated."
B_Trigger_OnQuestActive.Description.de="Lohn: Startet den Quest, wenn ein anderer aktiviert wird."
B_Trigger_OnQuestActive.Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}
function B_Trigger_OnQuestActive:AddParameter(K1Lgio,KMu)if(K1Lgio==0)then self.QuestName=KMu
self.WaitTime=0 end end;Swift:RegisterBehavior(B_Trigger_OnQuestActive)function Trigger_OnQuestFailure(...)return
B_Trigger_OnQuestFailureWait:new(...)end
Trigger_OnQuestFailureWait=Trigger_OnQuestFailure
B_Trigger_OnQuestFailureWait={Name="Trigger_OnQuestFailureWait",Description={en="Trigger: if a given quest has failed. Waiting time optional",de="Auslöser: wenn eine angegebene Quest fehlgeschlagen ist. Optional mit Wartezeit"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function B_Trigger_OnQuestFailureWait:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnQuestFailureWait:AddParameter(PPqE,sOE)if(PPqE==0)then self.QuestName=sOE elseif(PPqE==1)then
self.WaitTime=(
sOE~=nil and tonumber(sOE))or 0 end end
function B_Trigger_OnQuestFailureWait:CustomFunction(hf9m_U8)
if
(GetQuestID(self.QuestName)~=nil)then local dTQ=GetQuestID(self.QuestName)
if(Quests[dTQ].Result==
QuestResult.Failure)then
if
self.WaitTime and self.WaitTime>0 then
self.WaitTimeTimer=self.WaitTimeTimer or Logic.GetTime()if
Logic.GetTime()>=self.WaitTimeTimer+self.WaitTime then return true end else return true end end end;return false end
function B_Trigger_OnQuestFailureWait:Debug(k29Z4)
if type(self.QuestName)~="string"then
error(
k29Z4.Identifier..": "..self.Name..": invalid quest name!")return true elseif self.WaitTime and
(type(self.WaitTime)~="number"or self.WaitTime<0)then
error(k29Z4.Identifier..": "..
self.Name..": waitTime must be a number!")return true end;return false end
function B_Trigger_OnQuestFailureWait:Interrupt(a)self.WaitTimeTimer=nil end
function B_Trigger_OnQuestFailureWait:Reset(i)self.WaitTimeTimer=nil end
Swift:RegisterBehavior(B_Trigger_OnQuestFailureWait)
B_Trigger_OnQuestFailure=Swift:CopyTable(B_Trigger_OnQuestFailureWait)B_Trigger_OnQuestFailure.Name="Trigger_OnQuestFailure"
B_Trigger_OnQuestFailure.Description.en="Reward: Starts the quest after another has failed."
B_Trigger_OnQuestFailure.Description.de="Lohn: Startet den Quest, wenn ein anderer fehlschlägt."
B_Trigger_OnQuestFailure.Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}function B_Trigger_OnQuestFailure:AddParameter(t,TmE)
if(t==0)then self.QuestName=TmE;self.WaitTime=0 end end
Swift:RegisterBehavior(B_Trigger_OnQuestFailure)function Trigger_OnQuestNotTriggered(...)
return B_Trigger_OnQuestNotTriggered:new(...)end
B_Trigger_OnQuestNotTriggered={Name="Trigger_OnQuestNotTriggered",Description={en="Trigger: if a given quest is not yet active. Should be used in combination with other triggers.",de="Auslöser: wenn eine angegebene Quest noch inaktiv ist. Sollte mit weiteren Triggern kombiniert werden."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function B_Trigger_OnQuestNotTriggered:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function B_Trigger_OnQuestNotTriggered:AddParameter(xR,LJ3E)
if(xR==0)then self.QuestName=LJ3E end end
function B_Trigger_OnQuestNotTriggered:CustomFunction(Vjx)
if(
GetQuestID(self.QuestName)~=nil)then
local curjMDD=GetQuestID(self.QuestName)if
(Quests[curjMDD].State==QuestState.NotTriggered)then return true end end;return false end
function B_Trigger_OnQuestNotTriggered:Debug(gBS9Zk)if type(self.QuestName)~="string"then
error(
gBS9Zk.Identifier..": "..self.Name..": invalid quest name!")return true end
return false end
Swift:RegisterBehavior(B_Trigger_OnQuestNotTriggered)function Trigger_OnQuestInterrupted(...)
return B_Trigger_OnQuestInterruptedWait:new(...)end
Trigger_OnQuestInterruptedWait=Trigger_OnQuestInterrupted
B_Trigger_OnQuestInterruptedWait={Name="Trigger_OnQuestInterruptedWait",Description={en="Trigger: if a given quest has been interrupted. Should be used in combination with other triggers.",de="Auslöser: wenn eine angegebene Quest abgebrochen wurde. Sollte mit weiteren Triggern kombiniert werden."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function B_Trigger_OnQuestInterruptedWait:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnQuestInterruptedWait:AddParameter(Xr,UPp)if(Xr==0)then self.QuestName=UPp elseif(Xr==1)then
self.WaitTime=(
UPp~=nil and tonumber(UPp))or 0 end end
function B_Trigger_OnQuestInterruptedWait:CustomFunction(hWpZC)
if
(GetQuestID(self.QuestName)~=nil)then local bFF8=GetQuestID(self.QuestName)
if
(Quests[bFF8].State==
QuestState.Over and
Quests[bFF8].Result==QuestResult.Interrupted)then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end end;return false end
function B_Trigger_OnQuestInterruptedWait:Debug(RXM)
if type(self.QuestName)~="string"then
error(
RXM.Identifier..": "..self.Name..": invalid quest name!")return true elseif self.WaitTime and
(type(self.WaitTime)~="number"or self.WaitTime<0)then
error(RXM.Identifier..": "..
self.Name..": waitTime must be a number!")return true end;return false end
function B_Trigger_OnQuestInterruptedWait:Interrupt(Ieb1cGC)self.WaitTimeTimer=nil end
function B_Trigger_OnQuestInterruptedWait:Reset(Bf)self.WaitTimeTimer=nil end
Swift:RegisterBehavior(B_Trigger_OnQuestInterruptedWait)
B_Trigger_OnQuestInterrupted=Swift:CopyTable(B_Trigger_OnQuestInterruptedWait)
B_Trigger_OnQuestInterrupted.Name="Trigger_OnQuestInterrupted"
B_Trigger_OnQuestInterrupted.Description.en="Reward: Starts the quest after another is interrupted."
B_Trigger_OnQuestInterrupted.Description.de="Lohn: Startet den Quest, wenn ein anderer abgebrochen wurde."
B_Trigger_OnQuestInterrupted.Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}
function B_Trigger_OnQuestInterrupted:AddParameter(hKJi2,jW)if(hKJi2 ==0)then self.QuestName=jW
self.WaitTime=0 end end
Swift:RegisterBehavior(B_Trigger_OnQuestInterrupted)function Trigger_OnQuestOver(...)
return B_Trigger_OnQuestOverWait:new(...)end
Trigger_OnQuestOverWait=Trigger_OnQuestOver
B_Trigger_OnQuestOverWait={Name="Trigger_OnQuestOverWait",Description={en="Trigger: if a given quest has been finished, regardless of its result. Waiting time optional",de="Auslöser: wenn eine angegebene Quest beendet wurde, unabhängig von deren Ergebnis. Wartezeit optional"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function B_Trigger_OnQuestOverWait:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnQuestOverWait:AddParameter(JkVK,oXM7)if(JkVK==0)then self.QuestName=oXM7 elseif(JkVK==1)then
self.WaitTime=(
oXM7 ~=nil and tonumber(oXM7))or 0 end end
function B_Trigger_OnQuestOverWait:CustomFunction(z__Va)
if
(GetQuestID(self.QuestName)~=nil)then local uGbp=GetQuestID(self.QuestName)
if
(Quests[uGbp].State==
QuestState.Over and
Quests[uGbp].Result~=QuestResult.Interrupted)then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end end;return false end
function B_Trigger_OnQuestOverWait:Debug(OXK0)
if type(self.QuestName)~="string"then
error(
OXK0.Identifier..": "..self.Name..": invalid quest name!")return true elseif self.WaitTime and
(type(self.WaitTime)~="number"or self.WaitTime<0)then
error(OXK0.Identifier..": "..
self.Name..": waitTime must be a number!")return true end;return false end
function B_Trigger_OnQuestOverWait:Interrupt(Ek3QueoD)self.WaitTimeTimer=nil end
function B_Trigger_OnQuestOverWait:Reset(g)self.WaitTimeTimer=nil end;Swift:RegisterBehavior(B_Trigger_OnQuestOverWait)
B_Trigger_OnQuestOver=Swift:CopyTable(B_Trigger_OnQuestOverWait)B_Trigger_OnQuestOver.Name="Trigger_OnQuestOver"
B_Trigger_OnQuestOver.Description.en="Reward: Starts the quest after another finished."
B_Trigger_OnQuestOver.Description.de="Lohn: Startet den Quest, wenn ein anderer abgeschlossen wurde."
B_Trigger_OnQuestOver.Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}function B_Trigger_OnQuestOver:AddParameter(m_l,L)
if(m_l==0)then self.QuestName=L;self.WaitTime=0 end end
Swift:RegisterBehavior(B_Trigger_OnQuestOver)function Trigger_OnQuestSuccess(...)
return B_Trigger_OnQuestSuccessWait:new(...)end
Trigger_OnQuestSuccessWait=Trigger_OnQuestSuccess
B_Trigger_OnQuestSuccessWait={Name="Trigger_OnQuestSuccessWait",Description={en="Trigger: if a given quest has been finished successfully. Waiting time optional",de="Auslöser: wenn eine angegebene Quest erfolgreich abgeschlossen wurde. Wartezeit optional"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function B_Trigger_OnQuestSuccessWait:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnQuestSuccessWait:AddParameter(XmcB,l5Nd)if(XmcB==0)then self.QuestName=l5Nd elseif
(XmcB==1)then
self.WaitTime=(l5Nd~=nil and tonumber(l5Nd))or 0 end end
function B_Trigger_OnQuestSuccessWait:CustomFunction()
if
(GetQuestID(self.QuestName)~=nil)then local sEMv=GetQuestID(self.QuestName)
if(Quests[sEMv].Result==
QuestResult.Success)then
if
self.WaitTime and self.WaitTime>0 then
self.WaitTimeTimer=self.WaitTimeTimer or Logic.GetTime()if
Logic.GetTime()>=self.WaitTimeTimer+self.WaitTime then return true end else return true end end end;return false end
function B_Trigger_OnQuestSuccessWait:Debug(VPX)
if type(self.QuestName)~="string"then
error(
VPX.Identifier..": "..self.Name..": invalid quest name!")return true elseif self.WaitTime and
(type(self.WaitTime)~="number"or self.WaitTime<0)then
error(VPX.Identifier..": "..
self.Name..": waittime must be a number!")return true end;return false end
function B_Trigger_OnQuestSuccessWait:Interrupt(c)self.WaitTimeTimer=nil end
function B_Trigger_OnQuestSuccessWait:Reset(VGJdue)self.WaitTimeTimer=nil end
Swift:RegisterBehavior(B_Trigger_OnQuestSuccessWait)
B_Trigger_OnQuestSuccess=Swift:CopyTable(B_Trigger_OnQuestSuccessWait)B_Trigger_OnQuestSuccess.Name="Trigger_OnQuestSuccess"
B_Trigger_OnQuestSuccess.Description.en="Reward: Starts the quest after another finished successfully."
B_Trigger_OnQuestSuccess.Description.de="Lohn: Startet den Quest, wenn ein anderer erfolgreich abgeschlossen wurde."
B_Trigger_OnQuestSuccess.Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}
function B_Trigger_OnQuestSuccess:AddParameter(ztMtdy,rA)if(ztMtdy==0)then self.QuestName=rA
self.WaitTime=0 end end;Swift:RegisterBehavior(B_Trigger_OnQuestSuccess)function Trigger_CustomVariables(...)return
B_Trigger_CustomVariables:new(...)end
B_Trigger_CustomVariables={Name="Trigger_CustomVariables",Description={en="Trigger: if the variable has a certain value.",de="Auslöser: wenn die Variable einen bestimmen Wert eingenommen hat."},Parameter={{ParameterType.Default,en="Name of Variable",de="Variablennamen"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Default,en="Value",de="Wert"}}}
function B_Trigger_CustomVariables:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_CustomVariables:AddParameter(zHapMi,Jmsve1Q)
if zHapMi==0 then self.VariableName=Jmsve1Q elseif zHapMi==1 then
self.Relation=Jmsve1Q elseif zHapMi==2 then local _B8W1YL=tonumber(Jmsve1Q)_B8W1YL=
(_B8W1YL~=nil and _B8W1YL)or Jmsve1Q;self.Value=_B8W1YL end end
function B_Trigger_CustomVariables:CustomFunction()
local F=API.ObtainCustomVariable("BehaviorVariable_"..self.VariableName,0)local FN7=self.Value;if type(self.Value)=="string"then
FN7=API.ObtainCustomVariable(
"BehaviorVariable_"..self.Value,0)end
if self.Relation=="=="then return
F==FN7 elseif self.Relation~="~="then return F~=FN7 elseif self.Relation==">"then return F>FN7 elseif
self.Relation==">="then return F>=FN7 elseif self.Relation=="<="then return F<=FN7 else return F<FN7 end;return false end
function B_Trigger_CustomVariables:GetCustomData(cpNryuPy)if cpNryuPy==1 then
return{"==","~=","<=","<",">",">="}end end
function B_Trigger_CustomVariables:Debug(mVKRd8)local TBV0052={"==","~=","<=","<",">",">="}local cGBeq={true,false,
nil}
if not
API.ObtainCustomVariable("BehaviorVariable_"..self.VariableName)then
warn(mVKRd8.Identifier..": "..
self.Name..": variable '"..self.VariableName..
"' do not exist!")end
if not table.contains(TBV0052,self.Relation)then
error(mVKRd8.Identifier..
": "..self.Name..
": '"..self.Relation.."' is an invalid relation!")return true end;return false end;Swift:RegisterBehavior(B_Trigger_CustomVariables)function Trigger_AlwaysActive()return
B_Trigger_AlwaysActive:new()end
B_Trigger_AlwaysActive={Name="Trigger_AlwaysActive",Description={en="Trigger: the map has been started.",de="Auslöser: Start der Karte."}}
function B_Trigger_AlwaysActive:GetTriggerTable()return{Triggers.Time,0}end;Swift:RegisterBehavior(B_Trigger_AlwaysActive)function Trigger_OnMonth(...)return
B_Trigger_OnMonth:new(...)end
B_Trigger_OnMonth={Name="Trigger_OnMonth",Description={en="Trigger: a specified month",de="Auslöser: ein bestimmter Monat"},Parameter={{ParameterType.Custom,en="Month",de="Monat"}}}
function B_Trigger_OnMonth:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnMonth:AddParameter(PRXb,t)if(PRXb==0)then self.Month=t*1 end end;function B_Trigger_OnMonth:CustomFunction(Jk3TbYo)
return self.Month==Logic.GetCurrentMonth()end
function B_Trigger_OnMonth:GetCustomData(Nm61D3Il)
local Qjx7nk={}if Nm61D3Il==0 then for ZfqIP=1,12 do table.insert(Qjx7nk,ZfqIP)end else
assert(false)end;return Qjx7nk end
function B_Trigger_OnMonth:Debug(p4ZD2RW)if self.Month<1 or self.Month>12 then
error(
p4ZD2RW.Identifier..": "..self.Name..": Month has the wrong value")return true end
return false end;Swift:RegisterBehavior(B_Trigger_OnMonth)function Trigger_OnMonsoon()return
B_Trigger_OnMonsoon:new()end
B_Trigger_OnMonsoon={Name="Trigger_OnMonsoon",Description={en="Trigger: on monsoon.",de="Auslöser: wenn der Monsun beginnt."},RequiresExtraNo=1}
function B_Trigger_OnMonsoon:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnMonsoon:CustomFunction(o)if Logic.GetWeatherDoesShallowWaterFlood(0)then
return true end end;Swift:RegisterBehavior(B_Trigger_OnMonsoon)function Trigger_Time(...)return
B_Trigger_Time:new(...)end
B_Trigger_Time={Name="Trigger_Time",Description={en="Trigger: a given amount of time since map start",de="Auslöser: eine gewisse Anzahl Sekunden nach Spielbeginn"},Parameter={{ParameterType.Number,en="Time (sec.)",de="Zeit (Sek.)"}}}
function B_Trigger_Time:GetTriggerTable()return{Triggers.Time,self.Time}end
function B_Trigger_Time:AddParameter(QK5cr,e575)if(QK5cr==0)then self.Time=e575*1 end end;Swift:RegisterBehavior(B_Trigger_Time)function Trigger_OnWaterFreezes()return
B_Trigger_OnWaterFreezes:new()end
B_Trigger_OnWaterFreezes={Name="Trigger_OnWaterFreezes",Description={en="Trigger: if the water starts freezing",de="Auslöser: wenn die Gewässer gefrieren"}}
function B_Trigger_OnWaterFreezes:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function B_Trigger_OnWaterFreezes:CustomFunction(OP)
if Logic.GetWeatherDoesWaterFreeze(0)then return true end end
Swift:RegisterBehavior(B_Trigger_OnWaterFreezes)
function Trigger_NeverTriggered()return B_Trigger_NeverTriggered:new()end
B_Trigger_NeverTriggered={Name="Trigger_NeverTriggered",Description={en="Trigger: Never triggers a Quest. The quest may be set active by Reward_QuestActivate or Reward_QuestRestartForceActive",de="Auslöser: Löst nie eine Quest aus. Die Quest kann von Reward_QuestActivate oder Reward_QuestRestartForceActive aktiviert werden."}}function B_Trigger_NeverTriggered:GetTriggerTable()return
{Triggers.Custom2,{self,function()end}}end
Swift:RegisterBehavior(B_Trigger_NeverTriggered)function Trigger_OnAtLeastOneQuestFailure(...)
return B_Trigger_OnAtLeastOneQuestFailure:new(...)end
B_Trigger_OnAtLeastOneQuestFailure={Name="Trigger_OnAtLeastOneQuestFailure",Description={en="Trigger: if one or both of the given quests have failed.",de="Auslöser: wenn einer oder beide der angegebenen Aufträge fehlgeschlagen sind."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function B_Trigger_OnAtLeastOneQuestFailure:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnAtLeastOneQuestFailure:AddParameter(HxUqj4B,dryo7a)self.QuestTable={}
if(HxUqj4B==0)then
self.Quest1=dryo7a elseif(HxUqj4B==1)then self.Quest2=dryo7a end end
function B_Trigger_OnAtLeastOneQuestFailure:CustomFunction(Vvmt)
local z1jKKH=Quests[GetQuestID(self.Quest1)]local A=Quests[GetQuestID(self.Quest2)]
if
(z1jKKH.State==
QuestState.Over and z1jKKH.Result==QuestResult.Failure)or
(A.State==QuestState.Over and A.Result==QuestResult.Failure)then return true end;return false end
function B_Trigger_OnAtLeastOneQuestFailure:Debug(i)
if self.Quest1 ==self.Quest2 then
error(i.Identifier..
": "..self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
error(i.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
error(i.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Swift:RegisterBehavior(B_Trigger_OnAtLeastOneQuestFailure)function Trigger_OnAtLeastOneQuestSuccess(...)
return B_Trigger_OnAtLeastOneQuestSuccess:new(...)end
B_Trigger_OnAtLeastOneQuestSuccess={Name="Trigger_OnAtLeastOneQuestSuccess",Description={en="Trigger: if one or both of the given quests are won.",de="Auslöser: wenn einer oder beide der angegebenen Aufträge gewonnen wurden."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function B_Trigger_OnAtLeastOneQuestSuccess:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnAtLeastOneQuestSuccess:AddParameter(_ASR7X,lneZ2)self.QuestTable={}if(_ASR7X==0)then
self.Quest1=lneZ2 elseif(_ASR7X==1)then self.Quest2=lneZ2 end end
function B_Trigger_OnAtLeastOneQuestSuccess:CustomFunction(wZLxwQr)
local Z=Quests[GetQuestID(self.Quest1)]local b3h1=Quests[GetQuestID(self.Quest2)]
if
(Z.State==
QuestState.Over and Z.Result==QuestResult.Success)or
(b3h1.State==QuestState.Over and b3h1.Result==QuestResult.Success)then return true end;return false end
function B_Trigger_OnAtLeastOneQuestSuccess:Debug(AGn)
if self.Quest1 ==self.Quest2 then
error(
AGn.Identifier..": "..self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
error(AGn.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
error(AGn.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Swift:RegisterBehavior(B_Trigger_OnAtLeastOneQuestSuccess)
function Trigger_OnAtLeastXOfYQuestsSuccess(...)return
B_Trigger_OnAtLeastXOfYQuestsSuccess:new(...)end
B_Trigger_OnAtLeastXOfYQuestsSuccess={Name="Trigger_OnAtLeastXOfYQuestsSuccess",Description={en="Trigger: if at least X of Y given quests has been finished successfully.",de="Auslöser: wenn X von Y angegebener Quests erfolgreich abgeschlossen wurden."},Parameter={{ParameterType.Custom,en="Least Amount",de="Mindest Anzahl"},{ParameterType.Custom,en="Quest Amount",de="Quest Anzahl"},{ParameterType.QuestName,en="Quest name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest name 2",de="Questname 2"},{ParameterType.QuestName,en="Quest name 3",de="Questname 3"},{ParameterType.QuestName,en="Quest name 4",de="Questname 4"},{ParameterType.QuestName,en="Quest name 5",de="Questname 5"}}}
function B_Trigger_OnAtLeastXOfYQuestsSuccess:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_OnAtLeastXOfYQuestsSuccess:AddParameter(EQVz,pYXX)
if(EQVz==0)then
self.LeastAmount=tonumber(pYXX)elseif(EQVz==1)then self.QuestAmount=tonumber(pYXX)elseif(EQVz==2)then
self.QuestName1=pYXX elseif(EQVz==3)then self.QuestName2=pYXX elseif(EQVz==4)then self.QuestName3=pYXX elseif(EQVz==5)then
self.QuestName4=pYXX elseif(EQVz==6)then self.QuestName5=pYXX end end
function B_Trigger_OnAtLeastXOfYQuestsSuccess:CustomFunction()local GvHSsw=0
for XvK5=1,self.QuestAmount do local bK2=GetQuestID(self["QuestName"..
XvK5])if
IsValidQuest(bK2)then
if(Quests[bK2].Result==QuestResult.Success)then GvHSsw=
GvHSsw+1;if GvHSsw>=self.LeastAmount then return true end end end end;return false end
function B_Trigger_OnAtLeastXOfYQuestsSuccess:Debug(U)local FVkHUl7=self.LeastAmount
local FOA=self.QuestAmount
if FVkHUl7 <=0 or FVkHUl7 >5 then
error(U.Identifier..": "..
self.Name..": LeastAmount is wrong")return true elseif FOA<=0 or FOA>5 then
error(U.Identifier..
": "..self.Name..": QuestAmount is wrong")return true elseif FVkHUl7 >FOA then
error(U.Identifier..": "..
self.Name..": LeastAmount is greater than QuestAmount")return true end
for eF0tAUG=1,FOA do
if
not IsValidQuest(self["QuestName"..eF0tAUG])then
error(U.Identifier..
": "..self.Name..": Quest "..
self["QuestName"..eF0tAUG].." not found")return true end end;return false end
function B_Trigger_OnAtLeastXOfYQuestsSuccess:GetCustomData(_x)if(_x==0)or(_x==1)then return
{"1","2","3","4","5"}end end
Swift:RegisterBehavior(B_Trigger_OnAtLeastXOfYQuestsSuccess)function Trigger_MapScriptFunction(...)
return B_Trigger_MapScriptFunction:new(...)end
B_Trigger_MapScriptFunction={Name="Trigger_MapScriptFunction",Description={en="Trigger: Calls a function within the global map script. If the function returns true the quest will be started",de="Auslöser: Ruft eine Funktion im globalen Skript auf. Wenn sie true sendet, wird die Quest gestartet."},Parameter={{ParameterType.Default,en="Function name",de="Funktionsname"}}}
function B_Trigger_MapScriptFunction:GetTriggerTable(J2o6d)return
{Triggers.Custom2,{self,self.CustomFunction}}end;function B_Trigger_MapScriptFunction:AddParameter(r,PKiW0)
if(r==0)then self.FuncName=PKiW0 end end
function B_Trigger_MapScriptFunction:CustomFunction(odc5tp)if
type(self.FuncName)=="function"then return
self.FuncName(unpack(self.i47ya_6aghw_frxil))end;return
_G[self.FuncName](self,odc5tp)end
function B_Trigger_MapScriptFunction:Debug(t3yD)if not self.FuncName then
error(t3yD.Identifier..": "..self.Name..
": function reference is invalid!")return true end
if

type(self.FuncName)~="function"and not _G[self.FuncName]then
error(t3yD.Identifier..
": "..self.Name..": function does not exist!")return true end;return false end
Swift:RegisterBehavior(B_Trigger_MapScriptFunction)function Trigger_OnEffectDestroyed(...)
return B_Trigger_OnEffectDestroyed:new(...)end
B_Trigger_OnEffectDestroyed={Name="Trigger_OnEffectDestroyed",Description={en="Trigger: Starts a quest after an effect was destroyed",de="Auslöser: Startet eine Quest, nachdem ein Effekt zerstoert wurde"},Parameter={{ParameterType.Default,en="Effect name",de="Effektname"}}}
function B_Trigger_OnEffectDestroyed:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function B_Trigger_OnEffectDestroyed:AddParameter(_nofE2,kPOaEej)
if _nofE2 ==0 then self.EffectName=kPOaEej end end
function B_Trigger_OnEffectDestroyed:CustomFunction()return

not QSB.EffectNameToID[self.EffectName]or not
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])end
function B_Trigger_OnEffectDestroyed:Debug(XrKR)if
not QSB.EffectNameToID[self.EffectName]then
error(XrKR.Identifier..
": "..self.Name..": Effect has never existed")return true end end
Swift:RegisterBehavior(B_Trigger_OnEffectDestroyed)