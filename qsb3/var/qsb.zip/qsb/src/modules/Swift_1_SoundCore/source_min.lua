
ModuleSoundCore={Properties={Name="ModuleSoundCore"},Global={},Local={SoundBackup={}}}function ModuleSoundCore.Local:OnGameStart()end
function ModuleSoundCore.Local:AdjustSound(QDnlt,LmcA2auZ,Q,ZA,_IQQ)
self:SaveSound()if QDnlt then Sound.SetGlobalVolume(QDnlt)end;if LmcA2auZ then
Sound.SetMusicVolume(LmcA2auZ)end
if Q then Sound.SetSpeechVolume(Q)end;if ZA then Sound.SetFXSoundpointVolume(ZA)
Sound.SetFXAtmoVolume(ZA)end;if _IQQ then
Sound.Set2DFXVolume(_IQQ)Sound.SetFXVolume(_IQQ)end end
function ModuleSoundCore.Local:SaveSound()
if not self.SoundBackup.Saved then
self.SoundBackup.Saved=true
self.SoundBackup.FXSP=Sound.GetFXSoundpointVolume()self.SoundBackup.FXAtmo=Sound.GetFXAtmoVolume()
self.SoundBackup.FXVol=Sound.GetFXVolume()self.SoundBackup.Sound=Sound.GetGlobalVolume()
self.SoundBackup.Music=Sound.GetMusicVolume()self.SoundBackup.Voice=Sound.GetSpeechVolume()
self.SoundBackup.UI=Sound.Get2DFXVolume()end end
function ModuleSoundCore.Local:RestoreSound()
if self.SoundBackup.Saved then
Sound.SetFXSoundpointVolume(self.SoundBackup.FXSP)
Sound.SetFXAtmoVolume(self.SoundBackup.FXAtmo)Sound.SetFXVolume(self.SoundBackup.FXVol)
Sound.SetGlobalVolume(self.SoundBackup.Sound)
Sound.SetMusicVolume(self.SoundBackup.Music)
Sound.SetSpeechVolume(self.SoundBackup.Voice)Sound.Set2DFXVolume(self.SoundBackup.UI)
self.SoundBackup={}end end;Swift:RegisterModule(ModuleSoundCore)