
ModuleShipSalesment={Properties={Name="ModuleShipSalesment"},Global={Harbors={}},Local={},Shared={}}QSB.ShipTraderState={Waiting=1,MovingIn=2,Anchored=3,MovingOut=4}
function ModuleShipSalesment.Global:OnGameStart()
QSB.ScriptEvents.TradeShipSpawned=API.RegisterScriptEvent("Event_TradeShipSpawned")
QSB.ScriptEvents.TradeShipArrived=API.RegisterScriptEvent("Event_TradeShipArrived")
QSB.ScriptEvents.TradeShipLeft=API.RegisterScriptEvent("Event_TradeShipLeft")
QSB.ScriptEvents.TradeShipDespawned=API.RegisterScriptEvent("Event_TradeShipDespawned")
API.StartJob(function()
ModuleShipSalesment.Global:ControlHarbors()end)end
function ModuleShipSalesment.Global:CreateHarbor(QDnlt)if self.Harbors[QDnlt]then
self:DisposeHarbor(QDnlt)end
self.Harbors[QDnlt]={AddedOffers={},Routes={}}end
function ModuleShipSalesment.Global:DisposeHarbor(LmcA2auZ)
local Q=Logic.GetStoreHouse(LmcA2auZ)for ZA,_IQQ in pairs(self.Harbors[LmcA2auZ].Routes)do
self:PurgeTradeRoute(LmcA2auZ,_IQQ.Name)end;if IsExisting(Q)then
Logic.RemoveAllOffers(Q)end end
function ModuleShipSalesment.Global:AddTradeRoute(XpkjA,pVRj)if not self.Harbors[XpkjA]then
return end
for fuZ3z86=#self.Harbors[XpkjA].Routes,1,-1 do if
self.Harbors[XpkjA].Routes[fuZ3z86].Name==pVRj.Name then return end end;pVRj.Interval=pVRj.Interval or 300
pVRj.Duration=pVRj.Duration or 120;pVRj.Timer=pVRj.Interval-1
pVRj.State=QSB.ShipTraderState.Waiting
table.insert(self.Harbors[XpkjA].Routes,pVRj)end
function ModuleShipSalesment.Global:AlterTradeRouteOffers(er,DFb100j,XL_)if not self.Harbors[er]then
return end
for WYdR=#self.Harbors[er].Routes,1,-1 do if
self.Harbors[er].Routes[WYdR].Name==DFb100j then
self.Harbors[er].Routes[WYdR].Offers=XL_;return end end end
function ModuleShipSalesment.Global:PurgeAllTradeRoutes(QKKks_zt)if
not self.Harbors[QKKks_zt]then return end
for Are7xU=#self.Harbors[QKKks_zt].Routes,1,
-1 do
local yxjl=table.remove(self.Harbors[QKKks_zt].Routes,Are7xU)
if IsExisting(yxjl.ShipID)then DestroyEntity(yxjl.ShipID)end
if JobIsRunning(yxjl.ShipID)then EndJob(yxjl.ShipJob)end end end
function ModuleShipSalesment.Global:PurgeTradeRoute(ZG,Vu0cCAf)
if not self.Harbors[ZG]then return end
for q=#self.Harbors[ZG].Routes,1,-1 do
if
self.Harbors[ZG].Routes[q].Name==Vu0cCAf then
local kP7O5=table.remove(self.Harbors[ZG].Routes,q)
if IsExisting(kP7O5.ShipID)then DestroyEntity(kP7O5.ShipID)end
if JobIsRunning(kP7O5.ShipID)then EndJob(kP7O5.ShipJob)end;break end end end
function ModuleShipSalesment.Global:ShutdownTradeRoute(lqT,mP3mlD)if not self.Harbors[lqT]then
return end
for PrPyxMK=#self.Harbors[lqT].Routes,1,-1 do
if
self.Harbors[lqT].Routes[PrPyxMK].Name==mP3mlD then
return
API.StartJob(function(lqT,tczrIB)
if
self.Harbors[lqT].Routes[tczrIB].State==QSB.ShipTraderState.Waiting then
local a=self.Harbors[lqT].Routes[tczrIB].Name
ModuleShipSalesment.Global:PurgeTradeRoute(lqT,a)return true end end,lqT,PrPyxMK)end end;return 0 end
function ModuleShipSalesment.Global:SpawnShip(wqU76o,LB1Z)
local N9L=self.Harbors[wqU76o].Routes[LB1Z]local hDc_M=GetID(N9L.Path[1])
local qW0lRiD1,iD1IUx,JLCOx_ak=Logic.EntityGetPos(hDc_M)local hPQ=Logic.GetEntityOrientation(hDc_M)
local R1FIoQI=Logic.CreateEntity(Entities.D_X_TradeShip,qW0lRiD1,iD1IUx,hPQ,0)
self.Harbors[wqU76o].Routes[LB1Z].ShipID=R1FIoQI;self:SendShipSpawnedEvent(wqU76o,N9L,R1FIoQI)
Logic.SetSpeedFactor(R1FIoQI,3.0)return R1FIoQI end
function ModuleShipSalesment.Global:DespawnShip(NsoTwDs,HGli)
local iy=self.Harbors[NsoTwDs].Routes[HGli].ShipID
local m6SCS0=self.Harbors[NsoTwDs].Routes[HGli]self:SendShipDespawnedEvent(NsoTwDs,m6SCS0,iy)
DestroyEntity(iy)end
function ModuleShipSalesment.Global:MoveShipIn(NUhYw6R4,Hv)
local Ch=self.Harbors[NUhYw6R4].Routes[Hv]
local urkh=self.Harbors[NUhYw6R4].Routes[Hv].ShipID;local zhzpBSx={}for TjhsnP=1,#Ch.Path do
table.insert(zhzpBSx,GetID(Ch.Path[TjhsnP]))end
local rHSjalVy=Path:new(urkh,zhzpBSx,nil,nil,nil,nil,true,nil,nil,300)
self.Harbors[NUhYw6R4].Routes[Hv].ShipJob=rHSjalVy.Job;return urkh end
function ModuleShipSalesment.Global:MoveShipOut(t5jzEd9,JZAU2)
local zPXTTg=self.Harbors[t5jzEd9].Routes[JZAU2]
local seMLr=self.Harbors[t5jzEd9].Routes[JZAU2].ShipID;local qX={}for xL7OTb=1,#zPXTTg.Path do
table.insert(qX,GetID(zPXTTg.Path[xL7OTb]))end
local h_8=Path:new(seMLr,table.invert(qX),nil,nil,nil,nil,true,nil,nil,300)
self.Harbors[t5jzEd9].Routes[JZAU2].ShipJob=h_8.Job;return seMLr end
function ModuleShipSalesment.Global:SendShipSpawnedEvent(w8T3f,K,qL)
API.SendScriptEvent(QSB.ScriptEvents.TradeShipSpawned,w8T3f,K.Name,qL)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.TradeShipSpawned, %d, "%s", %d)]],w8T3f,K.Name,qL))end
function ModuleShipSalesment.Global:SendShipDespawnedEvent(vfIyB,quNsijN,QUh2tc)
API.SendScriptEvent(QSB.ScriptEvents.TradeShipDespawned,vfIyB,quNsijN.Name,QUh2tc)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.TradeShipDespawned, %d, "%s", %d)]],vfIyB,quNsijN.Name,QUh2tc))end
function ModuleShipSalesment.Global:SendShipArrivedEvent(qboV,nSBOx7,u)
API.SendScriptEvent(QSB.ScriptEvents.TradeShipArrived,qboV,nSBOx7.Name,u)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.TradeShipArrived, %d, "%s", %d)]],qboV,nSBOx7.Name,u))end
function ModuleShipSalesment.Global:SendShipLeftEvent(K,i1,zz1QI)
API.SendScriptEvent(QSB.ScriptEvents.TradeShipLeft,K,i1.Name,zz1QI)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.TradeShipLeft, %d, "%s", %d)]],K,i1.Name,zz1QI))end
function ModuleShipSalesment.Global:AddTradeOffers(kFTAh,LBf)
local dijn4Ph=self.Harbors[kFTAh]local CO1=dijn4Ph.Routes[LBf]local RlZo={}
if CO1.Amount==#CO1.Offers then
RlZo=table.copy(CO1.Offers)else local Ib4={}
while(#Ib4 <CO1.Amount)do
local fjV1G2=math.random(1,#CO1.Offers)if not table.contains(Ib4,fjV1G2)then
table.insert(Ib4,fjV1G2)end end;for Do=1,#Ib4 do
table.insert(RlZo,table.copy(CO1.Offers[Ib4[Do]]))end end;local SUn
for _=1,#RlZo do local TqYJ4=true;local DI=false;local b=Goods[RlZo[_][1]]
if not b then
TqYJ4=false;b=Entities[RlZo[_][1]]
if
Logic.IsEntityTypeInCategory(Entities[RlZo[_][1]],EntityCategories.Military)==1 then DI=true end end
SUn=ModuleTradingCore.Global:GetStorehouseInformation(kFTAh)
if SUn.OfferCount>=4 then
local E=table.remove(self.Harbors[kFTAh].AddedOffers,1)API.RemoveTradeOffer(kFTAh,E)
SUn=ModuleTradingCore.Global:GetStorehouseInformation(kFTAh)end;API.RemoveTradeOffer(kFTAh,b)
if TqYJ4 then
AddOffer(SUn.Storehouse,RlZo[_][2],b,9999)else if not DI then AddEntertainerOffer(SUn.Storehouse,b)else
AddMercenaryOffer(SUn.Storehouse,RlZo[_][2],b,9999)end end
table.insert(self.Harbors[kFTAh].AddedOffers,b)
SUn=ModuleTradingCore.Global:GetStorehouseInformation(kFTAh)end
Logic.ExecuteInLuaLocalState(string.format([[GameCallback_CloseNPCInteraction(GUI.GetPlayerID(), %d)]],SUn.Storehouse))end
function ModuleShipSalesment.Global:ControlHarbors()
for KMw7_i1s,CQi in pairs(self.Harbors)do
if
Logic.GetStoreHouse(KMw7_i1s)==0 then self:DisposeHarbor(KMw7_i1s)else
if
#CQi.Routes>0 then
local nHlJ=ModuleTradingCore.Global:GetStorehouseInformation(KMw7_i1s)
for lw4Q7kbl=1,#nHlJ[1]do
if nHlJ[1][lw4Q7kbl][5]==0 then
ModuleTradingCore.Global:RemoveTradeOfferByData(nHlJ,lw4Q7kbl)
for IN=#CQi.AddedOffers,1,-1 do if
CQi.AddedOffers[IN]==nHlJ[1][lw4Q7kbl][3]then
table.remove(self.Harbors[KMw7_i1s].AddedOffers,IN)end end end end
for QYf1=1,#CQi.Routes do
if
CQi.Routes[QYf1].State==QSB.ShipTraderState.Waiting then self.Harbors[KMw7_i1s].Routes[QYf1].Timer=
CQi.Routes[QYf1].Timer+1
if CQi.Routes[QYf1].Timer>=
CQi.Routes[QYf1].Interval then
self.Harbors[KMw7_i1s].Routes[QYf1].State=QSB.ShipTraderState.MovingIn
self.Harbors[KMw7_i1s].Routes[QYf1].Timer=0;self:SpawnShip(KMw7_i1s,QYf1)
self:MoveShipIn(KMw7_i1s,QYf1)end elseif
CQi.Routes[QYf1].State==QSB.ShipTraderState.MovingIn then
local RfsnisO=CQi.Routes[QYf1].Path[#CQi.Routes[QYf1].Path]local lvW2ga=CQi.Routes[QYf1].ShipID
if IsNear(lvW2ga,RfsnisO,300)then
self.Harbors[KMw7_i1s].Routes[QYf1].State=QSB.ShipTraderState.Anchored
self:SendShipArrivedEvent(KMw7_i1s,CQi.Routes[QYf1],lvW2ga)self:AddTradeOffers(KMw7_i1s,QYf1)end elseif
CQi.Routes[QYf1].State==QSB.ShipTraderState.Anchored then local T7RKP=CQi.Routes[QYf1].ShipID;self.Harbors[KMw7_i1s].Routes[QYf1].Timer=
CQi.Routes[QYf1].Timer+1
if CQi.Routes[QYf1].Timer>=
CQi.Routes[QYf1].Duration then
self.Harbors[KMw7_i1s].Routes[QYf1].State=QSB.ShipTraderState.MovingOut
self.Harbors[KMw7_i1s].Routes[QYf1].Timer=0
self:SendShipLeftEvent(KMw7_i1s,CQi.Routes[QYf1],T7RKP)self:MoveShipOut(KMw7_i1s,QYf1)end elseif
CQi.Routes[QYf1].State==QSB.ShipTraderState.MovingOut then local _L6Bs=CQi.Routes[QYf1].Path[1]
local SH=CQi.Routes[QYf1].ShipID
if IsNear(SH,_L6Bs,300)then
self.Harbors[KMw7_i1s].Routes[QYf1].State=QSB.ShipTraderState.Waiting;self:DespawnShip(KMw7_i1s,QYf1)end end end end end end end
function ModuleShipSalesment.Local:OnGameStart()
QSB.ScriptEvents.TradeShipSpawned=API.RegisterScriptEvent("Event_TradeShipSpawned")
QSB.ScriptEvents.TradeShipArrived=API.RegisterScriptEvent("Event_TradeShipArrived")
QSB.ScriptEvents.TradeShipLeft=API.RegisterScriptEvent("Event_TradeShipLeft")
QSB.ScriptEvents.TradeShipDespawned=API.RegisterScriptEvent("Event_TradeShipDespawned")end;Swift:RegisterModule(ModuleShipSalesment)