
ModuleQuests={Properties={Name="ModuleQuests"},Global={QuestMessageID=0,ExternalTriggerConditions={},ExternalTimerConditions={},ExternalDecisionConditions={},SegmentsOfQuest={}},Local={},Shared={}}QSB.SegmentResult={Success=1,Failure=2,Ignore=3}
function ModuleQuests.Global:OnGameStart()
Quest_Loop=self.QuestLoop;self:OverrideMethods()
table.insert(self.ExternalTriggerConditions,function(QDnlt,LmcA2auZ)
if LmcA2auZ and
string.find(LmcA2auZ.Identifier,"^DialogSystemQuest_.*$")then return true end;return not API.IsCinematicEventActive(QDnlt)end)
table.insert(self.ExternalTimerConditions,function(Q,ZA)
return not API.IsCinematicEventActive(Q)end)end
function ModuleQuests.Global:OnEvent(_IQQ,XpkjA,...)if _IQQ==QSB.ScriptEvents.ChatClosed then
if
Swift:IsProcessDebugCommands()then self:ProcessChatInput(arg[1])end end end
function ModuleQuests.Global:QuestMessage(pVRj,fuZ3z86,er,DFb100j,XL_,WYdR,QKKks_zt)
self.QuestMessageID=self.QuestMessageID+1;if pVRj then
pVRj=API.ConvertPlaceholders(API.Localize(pVRj))end
local Are7xU,yxjl=QuestTemplate:New(
(QKKks_zt~=nil and QKKks_zt)or("QSB_QuestMessage_"..self.QuestMessageID),(
fuZ3z86 or 1),(er or 1),{{Objective.Dummy}},{self:GetWaitTimeInlineTrigger(WYdR,DFb100j)},0,
nil,nil,XL_,nil,false,(pVRj~=nil),nil,nil,pVRj,nil)return yxjl.Identifier end
function ModuleQuests.Global:CreateNestedQuest(ZG)if not ZG.Segments then return end
table.insert(ZG,Goal_MapScriptFunction(self:GetCheckQuestSegmentsInlineGoal(),ZG.Name))local Vu0cCAf=self:CreateSimpleQuest(ZG)
Quests[GetQuestID(Vu0cCAf)].Visible=false;self.SegmentsOfQuest[Vu0cCAf]={}for q=1,#ZG.Segments,1 do
self:CreateSegmentForSegmentedQuest(ZG.Segments[q],Vu0cCAf,q)end;return Vu0cCAf end
function ModuleQuests.Global:CreateSegmentForSegmentedQuest(kP7O5,lqT,mP3mlD)local PrPyxMK=kP7O5.Name or
lqT.."@Segment"..mP3mlD
local tczrIB=Quests[GetQuestID(lqT)]
local a={Name=PrPyxMK,Segments=kP7O5.Segments,Result=kP7O5.Result or QSB.SegmentResult.Success,Sender=kP7O5.Sender or
tczrIB.SendingPlayer,Receiver=kP7O5.Receiver or tczrIB.ReceivingPlayer,Time=kP7O5.Time,Suggestion=kP7O5.Suggestion,Success=kP7O5.Success,Failure=kP7O5.Failure,Description=kP7O5.Description,Loop=kP7O5.Loop,Callback=kP7O5.Callback}
for wqU76o=1,#kP7O5 do table.insert(a,kP7O5[wqU76o])end
table.insert(a,Trigger_OnQuestActive(lqT,0))if a.Segments then self:CreateNestedQuest(a)else
self:CreateSimpleQuest(a)end
table.insert(self.SegmentsOfQuest[lqT],a)end
function ModuleQuests.Global:GetCheckQuestSegmentsInlineGoal()
return
function(LB1Z)local N9L=true
local hDc_M=ModuleQuests.Global.SegmentsOfQuest[LB1Z]
for qW0lRiD1=1,#hDc_M,1 do
local iD1IUx=Quests[GetQuestID(hDc_M[qW0lRiD1].Name)]if not iD1IUx then return false end
if iD1IUx.State==QuestState.Over and
iD1IUx.Result~=QuestResult.Interrupted then
if
hDc_M[qW0lRiD1].Result==QSB.SegmentResult.Success and
iD1IUx.Result~=QuestResult.Success then
ModuleQuests.Global:AbortAllQuestSegments(LB1Z)return false end
if
hDc_M[qW0lRiD1].Result==QSB.SegmentResult.Failure and
iD1IUx.Result~=QuestResult.Failure then
ModuleQuests.Global:AbortAllQuestSegments(LB1Z)return false end end;if iD1IUx.State~=QuestState.Over then N9L=false end end;if N9L then return true end end end
function ModuleQuests.Global:AbortAllQuestSegments(JLCOx_ak)
for hPQ=1,#self.SegmentsOfQuest[JLCOx_ak],1
do
local R1FIoQI=self.SegmentsOfQuest[JLCOx_ak][hPQ].Name
if
API.IsValidQuest(JLCOx_ak)and
Quests[GetQuestID(R1FIoQI)].State~=QuestState.Over then API.StopQuest(R1FIoQI,true)end end end
function ModuleQuests.Global:OverrideMethods()
API.FailQuest_Orig_ModuleQuest=API.FailQuest
API.FailQuest=function(NsoTwDs,HGli)
if ModuleQuests.Global.SegmentsOfQuest[NsoTwDs]then
for iy,m6SCS0 in
pairs(ModuleQuests.Global.SegmentsOfQuest[NsoTwDs])do
if
API.IsValidQuest(m6SCS0.Name)and
Quests[GetQuestID(m6SCS0.Name)].State~=QuestState.Over then API.FailQuest_Orig_ModuleQuest(m6SCS0.Name,true)end end end;API.FailQuest_Orig_ModuleQuest(NsoTwDs,HGli)end;API.RestartQuest_Orig_ModuleQuest=API.RestartQuest
API.RestartQuest=function(NUhYw6R4,Hv)
if
ModuleQuests.Global.SegmentsOfQuest[NUhYw6R4]then
for Ch,urkh in
pairs(ModuleQuests.Global.SegmentsOfQuest[NUhYw6R4])do if API.IsValidQuest(urkh.Name)then
API.StopQuest_Orig_ModuleQuest(urkh.Name,true)
API.RestartQuest_Orig_ModuleQuest(urkh.Name,true)end end end;API.RestartQuest_Orig_ModuleQuest(NUhYw6R4,Hv)end;API.StartQuest_Orig_ModuleQuest=API.StartQuest
API.StartQuest=function(zhzpBSx,rHSjalVy)
if
ModuleQuests.Global.SegmentsOfQuest[zhzpBSx]then
for TjhsnP,t5jzEd9 in
pairs(ModuleQuests.Global.SegmentsOfQuest[zhzpBSx])do
if
API.IsValidQuest(t5jzEd9.Name)and
Quests[GetQuestID(t5jzEd9.Name)].State~=QuestState.Over then
API.StartQuest_Orig_ModuleQuest(t5jzEd9.Name,true)end end end;API.StartQuest_Orig_ModuleQuest(zhzpBSx,rHSjalVy)end;API.StopQuest_Orig_ModuleQuest=API.StopQuest
API.StopQuest=function(JZAU2,zPXTTg)
if
ModuleQuests.Global.SegmentsOfQuest[JZAU2]then
for seMLr,qX in
pairs(ModuleQuests.Global.SegmentsOfQuest[JZAU2])do
if
API.IsValidQuest(qX.Name)and
Quests[GetQuestID(qX.Name)].State~=QuestState.Over then API.StopQuest_Orig_ModuleQuest(qX.Name,true)end end end;API.StopQuest_Orig_ModuleQuest(JZAU2,zPXTTg)end;API.WinQuest_Orig_ModuleQuest=API.WinQuest
API.WinQuest=function(h_8,xL7OTb)
if
ModuleQuests.Global.SegmentsOfQuest[h_8]then
for w8T3f,K in
pairs(ModuleQuests.Global.SegmentsOfQuest[h_8])do if API.IsValidQuest(K.Name)and Quests[GetQuestID(K.Name)].State~=
QuestState.Over then
API.StopQuest_Orig_ModuleQuest(K.Name,true)end end end;API.WinQuest_Orig_ModuleQuest(h_8,xL7OTb)end end
function ModuleQuests.Global:CreateSimpleQuest(qL)
if not qL.Name then
QSB.AutomaticQuestNameCounter=(
QSB.AutomaticQuestNameCounter or 0)+1
qL.Name=string.format("AutoNamed_Quest_%d",QSB.AutomaticQuestNameCounter)end
if not self:QuestValidateQuestName(qL.Name)then
error("Quest '"..
tostring(qL.Name).."': invalid questname! Contains forbidden characters!")return end
local vfIyB={qL.Name,(qL.Sender~=nil and qL.Sender)or 1,(
qL.Receiver~=nil and qL.Receiver)or 1,{},{},(
qL.Time~=nil and qL.Time)or 0,{},{},qL.Callback,qL.Loop,qL.Visible==
true or qL.Suggestion~=nil,qL.EndMessage==true or(
qL.Failure~=nil or qL.Success~=nil),API.ConvertPlaceholders(
(
type(qL.Description)=="table"and API.Localize(qL.Description))or qL.Description),API.ConvertPlaceholders(
(
type(qL.Suggestion)=="table"and API.Localize(qL.Suggestion))or qL.Suggestion),API.ConvertPlaceholders(
(
type(qL.Success)=="table"and API.Localize(qL.Success))or qL.Success),API.ConvertPlaceholders(
(
type(qL.Failure)=="table"and API.Localize(qL.Failure))or qL.Failure)}
if not self:QuestValidateQuestData(vfIyB)then
error("ModuleQuests: Failed to vaidate quest data. Table has been copied to log.")API.DumpTable(vfIyB,"Quest")return end
for qboV,nSBOx7 in pairs(qL)do
if tonumber(qboV)~=nil then
if type(nSBOx7)=="table"then
if nSBOx7.GetGoalTable then
table.insert(vfIyB[4],nSBOx7:GetGoalTable())local u=#vfIyB[4]vfIyB[4][u].Context=nSBOx7
vfIyB[4][u].FuncOverrideIcon=vfIyB[4][u].Context.GetIcon
vfIyB[4][u].FuncOverrideMsgKey=vfIyB[4][u].Context.GetMsgKey elseif nSBOx7.GetReprisalTable then
table.insert(vfIyB[8],nSBOx7:GetReprisalTable())elseif nSBOx7.GetRewardTable then
table.insert(vfIyB[7],nSBOx7:GetRewardTable())else
table.insert(vfIyB[5],nSBOx7:GetTriggerTable())end end end end;if#vfIyB[4]==0 then
table.insert(vfIyB[4],{Objective.Dummy})end;if#vfIyB[5]==0 then
table.insert(vfIyB[5],{Triggers.Time,0})end;if vfIyB[11]then
table.insert(vfIyB[5],self:GetFreeSpaceInlineTrigger())end
local quNsijN,QUh2tc=QuestTemplate:New(unpack(vfIyB,1,16))QUh2tc.MsgTableOverride=qL.MSGKeyOverwrite
QUh2tc.IconOverride=qL.IconOverwrite;QUh2tc.QuestInfo=qL.InfoText
QUh2tc.Arguments=(qL.Arguments~=nil and
table.copy(qL.Arguments))or{}return qL.Name,Quests[0]end
function ModuleQuests.Global:QuestValidateQuestData(K)
return
(









(type(K[1])=="string"and
self:QuestValidateQuestName(K[1])and
Quests[GetQuestID(K[1])]==nil)and
(type(K[2])=="number"and K[2]>=1 and K[2]<=8)and
(
type(K[3])=="number"and K[3]>=1 and K[3]<=8)and(type(K[6])=="number"and K[6]>=0)and((K[9]~=nil and type(K[9])=="function")or(K[9]==
nil))and(
(K[10]~=nil and type(K[10])=="function")or(K[10]==nil))and(type(K[11])=="boolean")and(type(K[12])=="boolean")and((K[13]~=nil and type(K[13])=="string")or(
K[13]==nil))and((K[14]~=nil and type(K[14])=="string")or(
K[14]==nil))and((K[15]~=nil and type(K[15])=="string")or(
K[15]==nil))and((K[16]~=nil and type(K[16])=="string")or(
K[16]==nil)))end
function ModuleQuests.Global:QuestValidateQuestName(i1)return
string.find(i1,"^[A-Za-z0-9_ @ÄÖÜäöüß]+$")~=nil end
function ModuleQuests.Global:GetWaitTimeInlineTrigger(zz1QI,kFTAh)
return
{Triggers.Custom2,{{QuestName=zz1QI,WaitTime=kFTAh or 1},function(LBf,dijn4Ph)if
not LBf.QuestName then return true end
local CO1=GetQuestID(LBf.QuestName)
if
(
Quests[CO1]and Quests[CO1].State==QuestState.Over and Quests[CO1].Result~=QuestResult.Interrupted)then
LBf.WaitTimeTimer=LBf.WaitTimeTimer or math.floor(Logic.GetTime())if
math.floor(Logic.GetTime())>=LBf.WaitTimeTimer+LBf.WaitTime then return true end end;return false end}}end
function ModuleQuests.Global:GetFreeSpaceInlineTrigger()
return
{Triggers.Custom2,{{},function(RlZo,SUn)local Ib4=0
if Quests[0]>0 then for fjV1G2=1,Quests[0],1
do
if Quests[fjV1G2].State==QuestState.Active and
Quests[fjV1G2].Visible==true then Ib4=Ib4+1 end end end;return Ib4 <6 end}}end
function ModuleQuests.Global.QuestLoop(Do)local _=JobQueue_GetParameter(Do)if
_.LoopCallback~=nil then _:LoopCallback()end
if _.State==
QuestState.NotTriggered then local TqYJ4=true
for DI=1,#ModuleQuests.Global.ExternalTriggerConditions,1
do
if not
ModuleQuests.Global.ExternalTriggerConditions[DI](_.ReceivingPlayer,_)then TqYJ4=false;break end end
if TqYJ4 then
for b=1,_.Triggers[0]do
local E=ModuleQuests.Global:SerializeBehavior(_.Triggers[b],Triggers.Custom2,4)if E then
debug("Quest '".._.Identifier.."' "..E,true)end
TqYJ4=TqYJ4 and _:IsTriggerActive(_.Triggers[b])end end;if TqYJ4 then _:SetMsgKeyOverride()_:SetIconOverride()
_:Trigger()end elseif _.State==QuestState.Active then
for CQi=1,#
ModuleQuests.Global.ExternalTimerConditions,1 do
if not
ModuleQuests.Global.ExternalTimerConditions[CQi](_.ReceivingPlayer,_)then _.StartTime=_.StartTime+1;break end end;local KMw7_i1s=true
for nHlJ=1,#ModuleQuests.Global.ExternalDecisionConditions,1 do
if not
ModuleQuests.Global.ExternalDecisionConditions[nHlJ](_.ReceivingPlayer,_)then KMw7_i1s=false;break end end
if KMw7_i1s then local lw4Q7kbl=true;local IN=false
for QYf1=1,_.Objectives[0]do
local RfsnisO=ModuleQuests.Global:SerializeBehavior(_.Objectives[QYf1],Objective.Custom2,1)if RfsnisO then
debug("Quest '".._.Identifier.."' "..RfsnisO,true)end
local lvW2ga=_:IsObjectiveCompleted(_.Objectives[QYf1])
if
_.Objectives[QYf1].Type==Objective.Deliver and lvW2ga==nil then if _.Objectives[QYf1].Data[4]==nil then
_.Objectives[QYf1].Data[4]=0 end
if
_.Objectives[QYf1].Data[3]~=nil then _.Objectives[QYf1].Data[4]=
_.Objectives[QYf1].Data[4]+1 end;local T7RKP=_.StartTime;local _L6Bs=_.Duration
local SH=_.Objectives[QYf1].Data[4]
local wU4wYbA9=_.StartTime+_.Duration-_.Objectives[QYf1].Data[4]if
_.Duration>0 and _.StartTime+_.Duration+
_.Objectives[QYf1].Data[4]<Logic.GetTime()then lvW2ga=false end else
if

_.Duration>0 and _.StartTime+_.Duration<Logic.GetTime()then
if
lvW2ga==nil and
(
_.Objectives[QYf1].Type==Objective.Protect or
_.Objectives[QYf1].Type==Objective.Dummy or _.Objectives[QYf1].Type==Objective.NoChange)then lvW2ga=true elseif lvW2ga==nil or
_.Objectives[QYf1].Type==Objective.DummyFail then lvW2ga=false end end end;lw4Q7kbl=(lvW2ga==true)and lw4Q7kbl
IN=lvW2ga==false or IN end;if lw4Q7kbl then _:Success()elseif IN then _:Fail()end end else if _.IsEventQuest==true then
Logic.ExecuteInLuaLocalState("StopEventMusic(nil, ".._.ReceivingPlayer..")")end
if
_.Result==QuestResult.Success then
for fFeQcIM=1,_.Rewards[0]do
local JEHSHPh3=ModuleQuests.Global:SerializeBehavior(_.Rewards[fFeQcIM],Reward.Custom,3)if JEHSHPh3 then
debug("Quest '".._.Identifier.."' "..JEHSHPh3,true)end
_:AddReward(_.Rewards[fFeQcIM])end elseif _.Result==QuestResult.Failure then
for bb=1,_.Reprisals[0]do
local o5e6fP=ModuleQuests.Global:SerializeBehavior(_.Reprisals[bb],Reprisal.Custom,3)if o5e6fP then
debug("Quest '".._.Identifier.."' "..o5e6fP,true)end
_:AddReprisal(_.Reprisals[bb])end end;if _.EndCallback~=nil then _:EndCallback()end;return true end end
function ModuleQuests.Global:SerializeBehavior(iq7ol,eMV,WDTNkTD)local Oejsws="Objective"local CkD73N0=Objective
if
WDTNkTD==2 then Oejsws="Reprisal"CkD73N0=Reprisal elseif WDTNkTD==3 then Oejsws="Reward"CkD73N0=Reward elseif
WDTNkTD==4 then Oejsws="Trigger"CkD73N0=Triggers end;local PlwhaRKJ="Running {"
local Caz4NM4Z=GetNameOfKeyInTable(CkD73N0,iq7ol.Type)
if iq7ol.Type==eMV then local XVxxx=iq7ol.Data[1].FuncName;PlwhaRKJ=PlwhaRKJ..Oejsws.."."..
Caz4NM4Z..""
if
XVxxx==nil then return else PlwhaRKJ=PlwhaRKJ..", "..tostring(XVxxx)end
if
iq7ol.Data and iq7ol.Data[1].i47ya_6aghw_frxil and#
iq7ol.Data[1].i47ya_6aghw_frxil>0 then
for hD=1,#iq7ol.Data[1].i47ya_6aghw_frxil,1 do
PlwhaRKJ=PlwhaRKJ..
", ("..
type(iq7ol.Data[1].i47ya_6aghw_frxil[hD])..") "..
tostring(iq7ol.Data[1].i47ya_6aghw_frxil[hD])end end else
PlwhaRKJ=PlwhaRKJ..Oejsws.."."..Caz4NM4Z..""
if iq7ol.Data then
if type(iq7ol.Data)=="table"then for G5BuU5=1,#iq7ol.Data do
PlwhaRKJ=PlwhaRKJ..", ("..

type(iq7ol.Data[G5BuU5])..") "..tostring(iq7ol.Data[G5BuU5])end else PlwhaRKJ=PlwhaRKJ..
", ("..
type(iq7ol.Data)..") "..tostring(iq7ol.Data)end end end;PlwhaRKJ=PlwhaRKJ.."}"return PlwhaRKJ end
function ModuleQuests.Global:FindQuestNames(AfwsY,T)local WZs=FindQuestsByName(AfwsY,T)if
#WZs==0 then return{}end;local ITdz={}for AjfoUo=1,#WZs,1 do
table.insert(ITdz,WZs[AjfoUo].Identifier)end;return ITdz end
function ModuleQuests.Global:ProcessChatInput(Er9zidsB)
local X=ModuleInputOutputCore.Shared:CommandTokenizer(Er9zidsB)
for dR=1,#X,1 do
if

X[1]=="fail"or X[1]=="restart"or X[1]=="start"or X[1]=="stop"or X[1]=="win"then local JFXtQwy=self:FindQuestNames(X[2],true)if#JFXtQwy~=1 then
error(
"Unable to find quest containing '"..X[2].."'")return end
if X[1]=="fail"then
API.FailQuest(JFXtQwy[1])
info("fail quest '"..JFXtQwy[1].."'")elseif X[1]=="restart"then API.RestartQuest(JFXtQwy[1])info("restart quest '"..
JFXtQwy[1].."'")elseif
X[1]=="start"then API.StartQuest(JFXtQwy[1])
info("trigger quest '"..JFXtQwy[1].."'")elseif X[1]=="stop"then API.StopQuest(JFXtQwy[1])info("interrupt quest '"..JFXtQwy[1]..
"'")elseif
X[1]=="win"then API.WinQuest(JFXtQwy[1])
info("win quest '"..JFXtQwy[1].."'")end end end end;Swift:RegisterModule(ModuleQuests)