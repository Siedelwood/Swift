SCP.InputOutputCore={}
ModuleInputOutputCore={Properties={Name="ModuleInputOutputCore"},Global={},Local={DisableQuestTimerToggling=false,CheatsDisabled=false,Chat={Data={},History={},Visible={},Widgets={}},Requester={ActionFunction=
nil,ActionRequester=nil,Next=nil,Queue={}}},Shared={Colors={red="{@color:255,80,80,255}",blue="{@color:104,104,232,255}",yellow="{@color:255,255,80,255}",green="{@color:80,180,0,255}",white="{@color:255,255,255,255}",black="{@color:0,0,0,255}",grey="{@color:140,140,140,255}",azure="{@color:0,160,190,255}",orange="{@color:255,176,30,255}",amber="{@color:224,197,117,255}",violet="{@color:180,100,190,255}",pink="{@color:255,170,200,255}",scarlet="{@color:190,0,0,255}",magenta="{@color:190,0,89,255}",olive="{@color:74,120,0,255}",sky="{@color:145,170,210,255}",tooltip="{@color:51,51,120,255}",lucid="{@color:0,0,0,0}",none="{@color:none}"},Placeholders={Names={},EntityTypes={}}}}
function ModuleInputOutputCore.Global:OnGameStart()
QSB.ScriptEvents.ChatOpened=API.RegisterScriptEvent("Event_ChatOpened")
QSB.ScriptEvents.ChatClosed=API.RegisterScriptEvent("Event_ChatClosed")
API.RegisterScriptCommand("Cmd_SetDecisionResult",SCP.InputOutputCore.SetDecisionResult)end
function ModuleInputOutputCore.Global:OnEvent(QDnlt,LmcA2auZ,...)
if
QDnlt==QSB.ScriptEvents.ChatClosed then
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.ChatClosed, "%s", %d, %s)]],arg[1],arg[2],tostring(
arg[3]==true)))
for Q=1,Quests[0],1 do
if Quests[Q].State==QuestState.Active and QSB.GoalInputDialogQuest==
Quests[Q].Identifier then
for ZA=1,#
Quests[Q].Objectives,1 do
if
Quests[Q].Objectives[ZA].Type==Objective.Custom2 then if
Quests[Q].Objectives[ZA].Data[1].Name=="Goal_InputDialog"then
Quests[Q].Objectives[ZA].Data[1].InputDialogResult=arg[1]end end end end end end end
function ModuleInputOutputCore.Local:OnGameStart()
QSB.ScriptEvents.ChatOpened=API.RegisterScriptEvent("Event_ChatOpened")
QSB.ScriptEvents.ChatClosed=API.RegisterScriptEvent("Event_ChatClosed")for _IQQ=1,8 do self.Chat.Data[_IQQ]={}
self.Chat.History[_IQQ]={}self.Chat.Visible[_IQQ]=false
self.Chat.Widgets[_IQQ]={}end
self:OverrideQuicksave()self:OverrideCheats()self:OverrideChatLog()
self:DialogOverwriteOriginal()self:DialogAltF4Hotkey()
self:OverrideDebugInput()self:OverrideShowQuestTimerButton()end
function ModuleInputOutputCore.Local:OnEvent(XpkjA,pVRj,...)
if
XpkjA==QSB.ScriptEvents.SaveGameLoaded then self:OverrideDebugInput()self:OverrideCheats()
self:DialogAltF4Hotkey()elseif XpkjA==QSB.ScriptEvents.ChatClosed then
if arg[3]then
if arg[1]=="restartmap"then
Framework.RestartMap()elseif arg[1]:find("^> ")then
GUI.SendScriptCommand(arg[1]:sub(3),true)elseif arg[1]:find("^>> ")then
GUI.SendScriptCommand(string.format("Logic.ExecuteInLuaLocalState(\"%s\")",arg[1]:sub(4)),true)elseif arg[1]:find("^< ")then
GUI.SendScriptCommand(string.format([[Script.Load("%s")]],arg[1]:sub(3)))elseif arg[1]:find("^<< ")then Script.Load(arg[1]:sub(4))elseif
arg[1]:find("^clear$")then GUI.ClearNotes()elseif arg[1]:find("^version$")then
GUI.AddStaticNote(QSB.Version)elseif arg[1]=="dummy"then API.Note("Debug: proccessing commands")end end;self.DisableQuestTimerToggling=false end end
function ModuleInputOutputCore.Local:ShowTextWindow(fuZ3z86)
fuZ3z86.PlayerID=fuZ3z86.PlayerID or 1;fuZ3z86.Button=fuZ3z86.Button or{}
local er=GUI.GetPlayerID()if fuZ3z86.PlayerID~=er then return end;if
XGUIEng.IsWidgetShown("/InGame/Root/Normal/ChatOptions")==1 then
self:UpdateChatLogText(fuZ3z86)return end
self.Chat.Data[er]=fuZ3z86;self:CloseTextWindow(er)self:AlterChatLog()
XGUIEng.SetText("/InGame/Root/Normal/ChatOptions/ChatLog",fuZ3z86.Content)
XGUIEng.SetText("/InGame/Root/Normal/MessageLog/Name","{center}"..fuZ3z86.Caption)if fuZ3z86.DisableClose then
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/Exit",0)end
if fuZ3z86.Pause then if not
Framework.IsNetworkGame()then
Game.GameTimeSetFactor(GUI.GetPlayerID(),0.0000001)
XGUIEng.ShowWidget("/InGame/Root/Normal/PauseScreen",1)end end;self:ShouldShowSlider(fuZ3z86.Content)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions",1)end
function ModuleInputOutputCore.Local:CloseTextWindow(DFb100j)
assert(DFb100j~=nil)local XL_=GUI.GetPlayerID()if DFb100j~=XL_ then return end
GUI_Chat.CloseChatMenu()end;function ModuleInputOutputCore.Local:UpdateChatLogText(WYdR)
XGUIEng.SetText("/InGame/Root/Normal/ChatOptions/ChatLog",WYdR.Content)end
function ModuleInputOutputCore.Local:AlterChatLog()
local QKKks_zt=GUI.GetPlayerID()if self.Chat.Visible[QKKks_zt]then return end
self.Chat.Visible[QKKks_zt]=true
self.Chat.History[QKKks_zt]=table.copy(g_Chat.ChatHistory)g_Chat.ChatHistory={}self:AlterChatLogDisplay()end
function ModuleInputOutputCore.Local:RestoreChatLog()
local Are7xU=GUI.GetPlayerID()if not self.Chat.Visible[Are7xU]then return end
self.Chat.Visible[Are7xU]=false;g_Chat.ChatHistory={}for yxjl=1,#self.Chat.History[Are7xU]do
GUI_Chat.ChatlogAddMessage(self.Chat.History[Are7xU][yxjl])end
self:RestoreChatLogDisplay()self.Chat.History[Are7xU]={}
self.Chat.Widgets[Are7xU]={}self.Chat.Data[Are7xU]={}end
function ModuleInputOutputCore.Local:UpdateToggleWhisperTarget()
local ZG=GUI.GetPlayerID()local Vu0cCAf="/InGame/Root/Normal/ChatOptions/"
if


not self.Chat.Data[ZG]or not self.Chat.Data[ZG].Button or not self.Chat.Data[ZG].Button.Action then
XGUIEng.ShowWidget(Vu0cCAf.."ToggleWhisperTarget",0)return end;local q=self.Chat.Data[ZG].Button.Text
XGUIEng.SetText(
Vu0cCAf.."ToggleWhisperTarget","{center}"..q)end
function ModuleInputOutputCore.Local:ShouldShowSlider(kP7O5)
local lqT=string.len(kP7O5)local mP3mlD=1;local PrPyxMK=0
while(true)do
local tczrIB,a=string.find(kP7O5,"{cr}",mP3mlD)if not a then break end
if a-mP3mlD<=58 then lqT=lqT+58- (a-mP3mlD)end;mP3mlD=a+1 end;if(lqT+ (PrPyxMK*55))>1000 then
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatLogSlider",1)end end
function ModuleInputOutputCore.Local:OverrideChatLog()
GUI_Chat.ChatlogAddMessage_Orig_InputOutputCore=GUI_Chat.ChatlogAddMessage
GUI_Chat.ChatlogAddMessage=function(wqU76o)local LB1Z=GUI.GetPlayerID()if not
ModuleInputOutputCore.Local.Chat.Visible[LB1Z]then
GUI_Chat.ChatlogAddMessage_Orig_InputOutputCore(wqU76o)return end
table.insert(ModuleInputOutputCore.Local.Chat.History[LB1Z],wqU76o)end
GUI_Chat.DisplayChatLog_Orig_InputOutputCore=GUI_Chat.DisplayChatLog
GUI_Chat.DisplayChatLog=function()local N9L=GUI.GetPlayerID()if not
ModuleInputOutputCore.Local.Chat.Visible[N9L]then
GUI_Chat.DisplayChatLog_Orig_InputOutputCore()end end;GUI_Chat.CloseChatMenu_Orig_InputOutputCore=GUI_Chat.CloseChatMenu
GUI_Chat.CloseChatMenu=function()
local hDc_M=GUI.GetPlayerID()if not
ModuleInputOutputCore.Local.Chat.Visible[hDc_M]then
GUI_Chat.CloseChatMenu_Orig_InputOutputCore()return end
if
ModuleInputOutputCore.Local.Chat.Data[hDc_M].Pause then if not Framework.IsNetworkGame()then
Game.GameTimeSetFactor(GUI.GetPlayerID(),1)
XGUIEng.ShowWidget("/InGame/Root/Normal/PauseScreen",0)end end
ModuleInputOutputCore.Local:RestoreChatLog()
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions",0)end
GUI_Chat.ToggleWhisperTargetUpdate_Orig_InputOutputCore=GUI_Chat.ToggleWhisperTargetUpdate
GUI_Chat.ToggleWhisperTargetUpdate=function()local qW0lRiD1=GUI.GetPlayerID()if not
ModuleInputOutputCore.Local.Chat.Visible[qW0lRiD1]then
GUI_Chat.ToggleWhisperTargetUpdate_Orig_InputOutputCore()return end
ModuleInputOutputCore.Local:UpdateToggleWhisperTarget()end
GUI_Chat.CheckboxMessageTypeWhisperUpdate_Orig_InputOutputCore=GUI_Chat.CheckboxMessageTypeWhisperUpdate
GUI_Chat.CheckboxMessageTypeWhisperUpdate=function()local iD1IUx=GUI.GetPlayerID()if not
ModuleInputOutputCore.Local.Chat.Visible[iD1IUx]then
GUI_Chat.CheckboxMessageTypeWhisperUpdate_Orig_InputOutputCore()return end end
GUI_Chat.ToggleWhisperTarget_Orig_InputOutputCore=GUI_Chat.ToggleWhisperTarget
GUI_Chat.ToggleWhisperTarget=function()local JLCOx_ak=GUI.GetPlayerID()if not
ModuleInputOutputCore.Local.Chat.Visible[JLCOx_ak]then
GUI_Chat.ToggleWhisperTarget_Orig_InputOutputCore()return end
if
ModuleInputOutputCore.Local.Chat.Data[JLCOx_ak].Button.Action then
local hPQ=ModuleInputOutputCore.Local.Chat.Data[JLCOx_ak]
ModuleInputOutputCore.Local.Chat.Data[JLCOx_ak].Button.Action(hPQ)end end end
function ModuleInputOutputCore.Local:AlterChatLogDisplay()
local R1FIoQI=GUI.GetPlayerID()local NsoTwDs,HGli,iy,m6SCS0;local NUhYw6R4;local Hv="/InGame/Root/Normal/ChatOptions/"
iy,m6SCS0=XGUIEng.GetWidgetLocalPosition(
Hv.."ToggleWhisperTarget")
NsoTwDs,HGli=XGUIEng.GetWidgetSize(Hv.."ToggleWhisperTarget")
self.Chat.Widgets[R1FIoQI]["ToggleWhisperTarget"]={X=iy,Y=m6SCS0,W=NsoTwDs,H=HGli}
NUhYw6R4=self.Chat.Widgets[R1FIoQI]["ToggleWhisperTarget"]
iy,m6SCS0=XGUIEng.GetWidgetLocalPosition(Hv.."ChatLog")NsoTwDs,HGli=XGUIEng.GetWidgetSize(Hv.."ChatLog")
self.Chat.Widgets[R1FIoQI]["ChatLog"]={X=iy,Y=m6SCS0,W=NsoTwDs,H=HGli}
NUhYw6R4=self.Chat.Widgets[R1FIoQI]["ChatLog"]
iy,m6SCS0=XGUIEng.GetWidgetLocalPosition(Hv.."ChatLogSlider")
NsoTwDs,HGli=XGUIEng.GetWidgetSize(Hv.."ChatLogSlider")
self.Chat.Widgets[R1FIoQI]["ChatLogSlider"]={X=iy,Y=m6SCS0,W=NsoTwDs,H=HGli}
NUhYw6R4=self.Chat.Widgets[R1FIoQI]["ChatLogSlider"]
XGUIEng.ShowWidget(Hv.."ChatModeAllPlayers",0)XGUIEng.ShowWidget(Hv.."ChatModeTeam",0)XGUIEng.ShowWidget(
Hv.."ChatModeWhisper",0)
XGUIEng.ShowWidget(
Hv.."ChatChooseModeCaption",0)
XGUIEng.ShowWidget(Hv.."Background/TitleBig",1)
XGUIEng.ShowWidget(Hv.."Background/TitleBig/Info",0)XGUIEng.ShowWidget(Hv.."ChatLogCaption",0)XGUIEng.ShowWidget(
Hv.."BGChoose",0)
XGUIEng.ShowWidget(Hv.."BGChatLog",0)XGUIEng.ShowWidget(Hv.."ChatLogSlider",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/BG",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Close",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Slider",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Text",0)
XGUIEng.SetText("/InGame/Root/Normal/MessageLog/Name","{center}Test")
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/MessageLog",15,90)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/MessageLog/Name",0,0)
XGUIEng.SetTextColor("/InGame/Root/Normal/MessageLog/Name",51,51,121,255)
XGUIEng.SetWidgetSize(Hv.."ChatLogSlider",46,600)
XGUIEng.SetWidgetLocalPosition(Hv.."ChatLogSlider",780,130)
XGUIEng.SetWidgetSize(Hv.."Background/DialogBG/1 (2)/2",150,400)
XGUIEng.SetWidgetPositionAndSize(Hv.."Background/DialogBG/1 (2)/3",400,500,350,400)
XGUIEng.SetWidgetLocalPosition(Hv.."ToggleWhisperTarget",280,760)
XGUIEng.SetWidgetLocalPosition(Hv.."ChatLog",140,150)XGUIEng.SetWidgetSize(Hv.."ChatLog",640,560)end
function ModuleInputOutputCore.Local:RestoreChatLogDisplay()
local Ch=GUI.GetPlayerID()local urkh;local zhzpBSx="/InGame/Root/Normal/ChatOptions/"
urkh=self.Chat.Widgets[Ch]["ToggleWhisperTarget"]
XGUIEng.SetWidgetLocalPosition(zhzpBSx.."ToggleWhisperTarget",urkh.X,urkh.Y)
XGUIEng.SetWidgetSize(zhzpBSx.."ToggleWhisperTarget",urkh.W,urkh.H)urkh=self.Chat.Widgets[Ch]["ChatLog"]
XGUIEng.SetWidgetLocalPosition(
zhzpBSx.."ChatLog",urkh.X,urkh.Y)
XGUIEng.SetWidgetSize(zhzpBSx.."ChatLog",urkh.W,urkh.H)
urkh=self.Chat.Widgets[Ch]["ChatLogSlider"]
XGUIEng.SetWidgetLocalPosition(zhzpBSx.."ChatLogSlider",urkh.X,urkh.Y)
XGUIEng.SetWidgetSize(zhzpBSx.."ChatLogSlider",urkh.W,urkh.H)
XGUIEng.ShowWidget(zhzpBSx.."ChatModeAllPlayers",1)
XGUIEng.ShowWidget(zhzpBSx.."ChatModeTeam",1)
XGUIEng.ShowWidget(zhzpBSx.."ChatModeWhisper",1)
XGUIEng.ShowWidget(zhzpBSx.."ChatChooseModeCaption",1)
XGUIEng.ShowWidget(zhzpBSx.."Background/TitleBig",1)
XGUIEng.ShowWidget(zhzpBSx.."Background/TitleBig/Info",1)
XGUIEng.ShowWidget(zhzpBSx.."ChatLogCaption",1)XGUIEng.ShowWidget(zhzpBSx.."BGChoose",1)XGUIEng.ShowWidget(
zhzpBSx.."BGChatLog",1)XGUIEng.ShowWidget(
zhzpBSx.."ChatLogSlider",1)
XGUIEng.ShowWidget(
zhzpBSx.."ToggleWhisperTarget",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog",0)end
function ModuleInputOutputCore.Local:OverrideQuicksave()
API.AddBlockQuicksaveCondition(function()return
ModuleInputOutputCore.Local.DialogWindowShown end)
KeyBindings_SaveGame=function(...)
if not Swift:CanDoQuicksave(unpack(arg))then return end
if



g_Throneroom~=nil or Framework and Framework.IsNetworkGame()or
XGUIEng.IsWidgetShownEx("/InGame/MissionStatistic")==1 or
GUI_Window.IsOpen("MissionEndScreen")or
XGUIEng.IsWidgetShownEx("/LoadScreen/LoadScreen")==1 or XGUIEng.IsWidgetShownEx("/InGame/Dialog")==1 then return end
OpenDialog(XGUIEng.GetStringTableText("UI_Texts/MainMenuSaveGame_center")..
"{cr}{cr}{cr}{cr}{cr}".."QuickSave",
XGUIEng.GetStringTableText("UI_Texts/Saving_center").."{cr}{cr}{cr}")XGUIEng.ShowWidget("/InGame/Dialog/Ok",0)
Dialog_SetUpdateCallback(KeyBindings_SaveGame_Delayed)end
SaveDialog_HoldGameState=function(rHSjalVy)SaveDialog.Name=rHSjalVy
if SaveDialog_SearchFilename(rHSjalVy)==
true then
OpenRequesterDialog("{cr}"..rHSjalVy.." : "..
XGUIEng.GetStringTableText("UI_Texts/ConfirmOverwriteFile"),XGUIEng.GetStringTableText("UI_Texts/MainMenuSaveGame_center"),"SaveDialog_SaveFile()")else SaveDialog_SaveFile()end end
SaveDialog_SaveFile=function()CloseSaveDialog()
GUI_Window.Toggle("MainMenu")local TjhsnP
if string.len(SaveDialog.Name)>15 then
TjhsnP=
XGUIEng.GetStringTableText("UI_Texts/MainMenuSaveGame_center").."{cr}{cr}{cr}{cr}{cr}"..SaveDialog.Name else
TjhsnP=XGUIEng.GetStringTableText("UI_Texts/MainMenuSaveGame_center")..
"{cr}{cr}{cr}{cr}{cr}"..SaveDialog.Name end
OpenDialog(TjhsnP,XGUIEng.GetStringTableText("UI_Texts/Saving_center").."{cr}{cr}{cr}")XGUIEng.ShowWidget("/InGame/Dialog/Ok",0)
Framework.SaveGame(SaveDialog.Name,"--")end
GUI_Window.MainMenuSaveClicked=function()GUI_Window.CloseInGameMenu()
OpenDialog(
XGUIEng.GetStringTableText("UI_Texts/MainMenuSaveGame_center").."{cr}{cr}{cr}{cr}{cr}".."QuickSave",
XGUIEng.GetStringTableText("UI_Texts/Saving_center").."{cr}{cr}{cr}")XGUIEng.ShowWidget("/InGame/Dialog/Ok",0)
Framework.SaveGame("QuickSave","Quicksave")end end
function ModuleInputOutputCore.Local:OverrideCheats()
if self.CheatsDisabled then
Input.KeyBindDown(
Keys.ModifierControl+Keys.ModifierShift+Keys.Divide,"KeyBindings_EnableDebugMode(0)",2,false)else
Input.KeyBindDown(Keys.ModifierControl+Keys.ModifierShift+Keys.Divide,"KeyBindings_EnableDebugMode(1)",2,false)end end
function ModuleInputOutputCore.Local:OverrideDebugInput()
StartSimpleJobEx(function(t5jzEd9)
if
not
API.IsLoadscreenVisible()and Logic.GetTime()>t5jzEd9+1 then
Swift.InitalizeQsbDebugShell=function(JZAU2)if not JZAU2.m_DevelopingShell then return end
Input.KeyBindDown(
Keys.ModifierShift+Keys.OemPipe,"API.ShowTextInput(GUI.GetPlayerID(), true)",2,false)end;Swift:InitalizeQsbDebugShell()return true end end,Logic.GetTime())end
function ModuleInputOutputCore.Local:OverrideShowQuestTimerButton()
GUI_Interaction.TimerButtonClicked_Orig_ModuleInputOutputCore=GUI_Interaction.TimerButtonClicked
GUI_Interaction.TimerButtonClicked=function()if ModuleInputOutputCore.Local.DisableQuestTimerToggling then
return end
GUI_Interaction.TimerButtonClicked_Orig_ModuleInputOutputCore()end end
function ModuleInputOutputCore.Local:DialogAltF4Hotkey()
StartSimpleJobEx(function()
if not
API.IsLoadscreenVisible()then
Input.KeyBindDown(Keys.ModifierAlt+Keys.F4,"ModuleInputOutputCore.Local:DialogAltF4Action()",2,false)return true end end)end
function ModuleInputOutputCore.Local:DialogAltF4Action()
Input.KeyBindDown(Keys.ModifierAlt+Keys.F4,"",30,false)
self:OpenRequesterDialog(XGUIEng.GetStringTableText("UI_Texts/MainMenuExitGame_center"),XGUIEng.GetStringTableText("UI_Texts/ConfirmQuitCurrentGame"),function(zPXTTg)if
zPXTTg then Framework.ExitGame()end;if not
Framework.IsNetworkGame()then
Game.GameTimeSetFactor(GUI.GetPlayerID(),1)end;if not ModuleDisplayCore or not
ModuleDisplayCore.Local.PauseScreenShown then
XGUIEng.ShowWidget("/InGame/Root/Normal/PauseScreen",0)end
ModuleInputOutputCore.Local:DialogAltF4Hotkey()end)if not Framework.IsNetworkGame()then
Game.GameTimeSetFactor(GUI.GetPlayerID(),0.0000001)end
XGUIEng.ShowWidget("/InGame/Root/Normal/PauseScreen",1)end
function ModuleInputOutputCore.Local:Callback(seMLr)
if self.Requester.ActionFunction then self.Requester.ActionFunction(
CustomGame.Knight+1,seMLr)end;self:OnDialogClosed()end
function ModuleInputOutputCore.Local:CallbackRequester(qX,h_8)if self.Requester.ActionRequester then
self.Requester.ActionRequester(qX,h_8)end;self:OnDialogClosed()end
function ModuleInputOutputCore.Local:OnDialogClosed()
self:DialogQueueStartNext()self:RestoreSaveGame()end
function ModuleInputOutputCore.Local:DialogQueueStartNext()
self.Requester.Next=table.remove(self.Requester.Queue,1)
DialogQueueStartNext_HiResControl=function()
local xL7OTb=ModuleInputOutputCore.Local.Requester.Next
if xL7OTb and xL7OTb[1]and xL7OTb[2]then local w8T3f=xL7OTb[1]
ModuleInputOutputCore.Local[w8T3f](ModuleInputOutputCore.Local,unpack(xL7OTb[2]))
ModuleInputOutputCore.Local.Requester.Next=nil end;return true end
StartSimpleHiResJob("DialogQueueStartNext_HiResControl")end;function ModuleInputOutputCore.Local:DialogQueuePush(K,qL)local vfIyB={K,qL}
table.insert(self.Requester.Queue,vfIyB)end
function ModuleInputOutputCore.Local:OpenDialog(quNsijN,QUh2tc,qboV)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then
assert(type(quNsijN)=="string")assert(type(QUh2tc)=="string")quNsijN="{center}"..
API.ConvertPlaceholders(quNsijN)
QUh2tc=API.ConvertPlaceholders(QUh2tc)
if string.len(QUh2tc)<35 then QUh2tc=QUh2tc.."{cr}"end;g_MapAndHeroPreview.SelectKnight=function(nSBOx7)end
XGUIEng.ShowAllSubWidgets("/InGame/Dialog/BG",1)XGUIEng.ShowWidget("/InGame/Dialog/Backdrop",0)
XGUIEng.ShowWidget(RequesterDialog,1)XGUIEng.ShowWidget(RequesterDialog_Yes,0)
XGUIEng.ShowWidget(RequesterDialog_No,0)XGUIEng.ShowWidget(RequesterDialog_Ok,1)
if type(qboV)==
"function"then self.Requester.ActionFunction=qboV
local u="XGUIEng.ShowWidget(RequesterDialog, 0)"
u=u.."; if not Framework.IsNetworkGame() then Game.GameTimeSetFactor(GUI.GetPlayerID(), 1) end"u=u.."; XGUIEng.PopPage()"
u=u..
"; ModuleInputOutputCore.Local.Callback(ModuleInputOutputCore.Local, GUI.GetPlayerID())"XGUIEng.SetActionFunction(RequesterDialog_Ok,u)else self.Requester.ActionFunction=
nil;local K="XGUIEng.ShowWidget(RequesterDialog, 0)"
K=K..
"; if not Framework.IsNetworkGame() then Game.GameTimeSetFactor(GUI.GetPlayerID(), 1) end"K=K.."; XGUIEng.PopPage()"
K=K..
"; ModuleInputOutputCore.Local.Callback(ModuleInputOutputCore.Local, GUI.GetPlayerID())"XGUIEng.SetActionFunction(RequesterDialog_Ok,K)end
XGUIEng.SetText(RequesterDialog_Message,"{center}"..QUh2tc)XGUIEng.SetText(RequesterDialog_Title,quNsijN)
XGUIEng.SetText(
RequesterDialog_Title.."White",quNsijN)XGUIEng.PushPage(RequesterDialog,false)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/QuickSave",0)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/SaveGame",0)self.DialogWindowShown=true;if not Framework.IsNetworkGame()then
Game.GameTimeSetFactor(GUI.GetPlayerID(),0.0000001)
XGUIEng.ShowWidget("/InGame/Root/Normal/PauseScreen",1)end else
self:DialogQueuePush("OpenDialog",{quNsijN,QUh2tc,qboV})end end
function ModuleInputOutputCore.Local:OpenRequesterDialog(i1,zz1QI,kFTAh,LBf)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then assert(type(i1)=="string")assert(
type(zz1QI)=="string")i1="{center}"..i1
self:OpenDialog(i1,zz1QI,kFTAh)XGUIEng.ShowWidget(RequesterDialog_Yes,1)
XGUIEng.ShowWidget(RequesterDialog_No,1)XGUIEng.ShowWidget(RequesterDialog_Ok,0)
if LBf then
XGUIEng.SetText(RequesterDialog_Yes,XGUIEng.GetStringTableText("UI_Texts/Ok_center"))
XGUIEng.SetText(RequesterDialog_No,XGUIEng.GetStringTableText("UI_Texts/Cancel_center"))else
XGUIEng.SetText(RequesterDialog_Yes,XGUIEng.GetStringTableText("UI_Texts/Yes_center"))
XGUIEng.SetText(RequesterDialog_No,XGUIEng.GetStringTableText("UI_Texts/No_center"))end;self.Requester.ActionRequester=nil
if kFTAh then
assert(type(kFTAh)=="function")self.Requester.ActionRequester=kFTAh end;local dijn4Ph="XGUIEng.ShowWidget(RequesterDialog, 0)"
dijn4Ph=dijn4Ph..
"; if not Framework.IsNetworkGame() then Game.GameTimeSetFactor(GUI.GetPlayerID(), 1) end"dijn4Ph=dijn4Ph.."; XGUIEng.PopPage()"
dijn4Ph=dijn4Ph..
"; ModuleInputOutputCore.Local.CallbackRequester(ModuleInputOutputCore.Local, true, GUI.GetPlayerID())"
XGUIEng.SetActionFunction(RequesterDialog_Yes,dijn4Ph)local dijn4Ph="XGUIEng.ShowWidget(RequesterDialog, 0)"
dijn4Ph=dijn4Ph..
"; if not Framework.IsNetworkGame() then Game.GameTimeSetFactor(GUI.GetPlayerID(), 1) end"dijn4Ph=dijn4Ph.."; XGUIEng.PopPage()"
dijn4Ph=dijn4Ph..
"; ModuleInputOutputCore.Local.CallbackRequester(ModuleInputOutputCore.Local, false, GUI.GetPlayerID())"
XGUIEng.SetActionFunction(RequesterDialog_No,dijn4Ph)else
self:DialogQueuePush("OpenRequesterDialog",{i1,zz1QI,kFTAh,LBf})end end
function ModuleInputOutputCore.Local:OpenSelectionDialog(CO1,RlZo,SUn,Ib4)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then self:OpenDialog(CO1,RlZo,SUn)
local fjV1G2=XGUIEng.GetWidgetID(CustomGame.Widget.KnightsList)XGUIEng.ListBoxPopAll(fjV1G2)for E=1,#Ib4 do
XGUIEng.ListBoxPushItem(fjV1G2,Ib4[E])end
XGUIEng.ListBoxSetSelectedIndex(fjV1G2,0)CustomGame.Knight=0;local Do="XGUIEng.ShowWidget(RequesterDialog, 0)"
Do=Do..
"; if not Framework.IsNetworkGame() then Game.GameTimeSetFactor(GUI.GetPlayerID(), 1) end"Do=Do.."; XGUIEng.PopPage()"
Do=Do.."; XGUIEng.PopPage()"Do=Do.."; XGUIEng.PopPage()"
Do=Do..
"; ModuleInputOutputCore.Local.Callback(ModuleInputOutputCore.Local, GUI.GetPlayerID())"XGUIEng.SetActionFunction(RequesterDialog_Ok,Do)
local _="/InGame/Singleplayer/CustomGame/ContainerSelection/"
XGUIEng.SetText(_.."HeroComboBoxMain/HeroComboBox","")if Ib4[1]then
XGUIEng.SetText(_.."HeroComboBoxMain/HeroComboBox",Ib4[1])end
XGUIEng.PushPage(_.."HeroComboBoxContainer",false)
XGUIEng.PushPage(_.."HeroComboBoxMain",false)
XGUIEng.ShowWidget(_.."HeroComboBoxContainer",0)local TqYJ4={GUI.GetScreenSize()}
local DI,b=XGUIEng.GetWidgetScreenPosition(RequesterDialog_Ok)
XGUIEng.SetWidgetScreenPosition(_.."HeroComboBoxMain",DI-25,b-
(90* (TqYJ4[2]/1080)))
XGUIEng.SetWidgetScreenPosition(_.."HeroComboBoxContainer",DI-25,b-
(20* (TqYJ4[2]/1080)))else
self:DialogQueuePush("OpenSelectionDialog",{CO1,RlZo,SUn,Ib4})end end
function ModuleInputOutputCore.Local:RestoreSaveGame()
if not ModuleInterfaceCore or not
ModuleInterfaceCore.Local.ForbidRegularSave then
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/QuickSave",1)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/SaveGame",1)end;self.DialogWindowShown=false end
function ModuleInputOutputCore.Local:DialogOverwriteOriginal()
OpenDialog_Orig_Windows=OpenDialog
OpenDialog=function(KMw7_i1s,CQi,nHlJ)
if XGUIEng.IsWidgetShown(RequesterDialog)==0 then
local lw4Q7kbl="XGUIEng.ShowWidget(RequesterDialog, 0)"lw4Q7kbl=lw4Q7kbl.."; XGUIEng.PopPage()"
OpenDialog_Orig_Windows(CQi,KMw7_i1s)end end;OpenRequesterDialog_Orig_Windows=OpenRequesterDialog
OpenRequesterDialog=function(IN,QYf1,RfsnisO,lvW2ga,T7RKP)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then local _L6Bs="XGUIEng.ShowWidget(RequesterDialog, 0)"_L6Bs=_L6Bs..
"; XGUIEng.PopPage()"
XGUIEng.SetActionFunction(RequesterDialog_Yes,_L6Bs)local _L6Bs="XGUIEng.ShowWidget(RequesterDialog, 0)"
_L6Bs=_L6Bs.."; XGUIEng.PopPage()"
XGUIEng.SetActionFunction(RequesterDialog_No,_L6Bs)
OpenRequesterDialog_Orig_Windows(IN,QYf1,RfsnisO,lvW2ga,T7RKP)end end end
function ModuleInputOutputCore.Local:ShowInputBox(SH,wU4wYbA9)if GUI.GetPlayerID()~=SH then
return end
Swift:SetProcessDebugCommands(wU4wYbA9)
StartSimpleHiResJob("ModuleInputOutputCore_Local_InputBoxJob")end
function ModuleInputOutputCore_Local_InputBoxJob()Input.ChatMode()if
not Framework.IsNetworkGame()then
Game.GameTimeSetFactor(GUI.GetPlayerID(),0.0000001)end
XGUIEng.SetText("/InGame/Root/Normal/ChatInput/ChatInput","")
XGUIEng.ShowWidget("/InGame/Root/Normal/PauseScreen",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatInput",1)
XGUIEng.SetFocus("/InGame/Root/Normal/ChatInput/ChatInput")
ModuleInputOutputCore.Local.DisableQuestTimerToggling=true;return true end
function ModuleInputOutputCore_Local_DisableQuestToggle(fFeQcIM)if GUI.GetPlayerID()==fFeQcIM then
ModuleInputOutputCore.Local.DisableQuestTimerToggling=true end;return true end
function ModuleInputOutputCore.Local:PrepareInputVariable(JEHSHPh3)
API.SendScriptEventToGlobal(QSB.ScriptEvents.ChatOpened,JEHSHPh3)
API.SendScriptEvent(QSB.ScriptEvents.ChatOpened,JEHSHPh3)
GUI_Chat.Abort_Orig_ModuleInputOutputCore=GUI_Chat.Abort_Orig_ModuleInputOutputCore or GUI_Chat.Abort
GUI_Chat.Confirm_Orig_ModuleInputOutputCore=GUI_Chat.Confirm_Orig_ModuleInputOutputCore or GUI_Chat.Confirm
GUI_Chat.Confirm=function()
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatInput",0)if not ModuleDisplayCore or
not ModuleDisplayCore.Local.PauseScreenShown then
XGUIEng.ShowWidget("/InGame/Root/Normal/PauseScreen",0)end
local bb=XGUIEng.GetText("/InGame/Root/Normal/ChatInput/ChatInput")local o5e6fP=Swift:IsProcessDebugCommands()
Swift.m_ChatBoxInput=bb
ModuleInputOutputCore.Local:LocalToGlobal(bb,o5e6fP)g_Chat.JustClosed=1;if not Framework.IsNetworkGame()then
Game.GameTimeSetFactor(JEHSHPh3,1)end;Input.GameMode()
if

bb:len()>0 and Framework.IsNetworkGame()and not o5e6fP then
GUI.SendChatMessage(bb,JEHSHPh3,g_Chat.CurrentMessageType,g_Chat.CurrentWhisperTarget)end end
if not Framework.IsNetworkGame()then GUI_Chat.Abort=function()end end end
function ModuleInputOutputCore.Local:LocalToGlobal(iq7ol,eMV)iq7ol=(iq7ol==nil and"")or
iq7ol
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.ChatClosed,(iq7ol or
"<<<ES>>>"),GUI.GetPlayerID(),eMV==true)Swift:SetProcessDebugCommands(false)end
function ModuleInputOutputCore.Shared:Note(WDTNkTD)
WDTNkTD=self:ConvertPlaceholders(Swift:Localize(WDTNkTD))
if Swift:IsGlobalEnvironment()then
Logic.ExecuteInLuaLocalState(string.format([[GUI.AddNote("%s")]],WDTNkTD))else GUI.AddNote(WDTNkTD)end end
function ModuleInputOutputCore.Shared:StaticNote(Oejsws)
Oejsws=self:ConvertPlaceholders(Swift:Localize(Oejsws))if Swift:IsGlobalEnvironment()then
Logic.ExecuteInLuaLocalState(string.format([[GUI.AddStaticNote("%s")]],Oejsws))return end
GUI.AddStaticNote(Oejsws)end
function ModuleInputOutputCore.Shared:Message(CkD73N0)
CkD73N0=self:ConvertPlaceholders(Swift:Localize(CkD73N0))if Swift:IsGlobalEnvironment()then
Logic.ExecuteInLuaLocalState(string.format([[Message("%s")]],CkD73N0))return end
Message(CkD73N0)end
function ModuleInputOutputCore.Shared:ClearNotes()if Swift:IsGlobalEnvironment()then
Logic.ExecuteInLuaLocalState([[GUI.ClearNotes()]])return end;GUI.ClearNotes()end
function ModuleInputOutputCore.Shared:ConvertPlaceholders(PlwhaRKJ)local Caz4NM4Z,XVxxx,hD,G5BuU5
while true do
local AfwsY,T,WZs,ITdz,Caz4NM4Z,XVxxx,hD,G5BuU5
if PlwhaRKJ:find("{n:")then
AfwsY,T,WZs,Caz4NM4Z,XVxxx,hD,G5BuU5=self:SplicePlaceholderText(PlwhaRKJ,"{n:")ITdz=self.Placeholders.Names[T]
PlwhaRKJ=AfwsY..
Swift:Localize(ITdz or("n:"..
tostring(T)..": not found"))..WZs elseif PlwhaRKJ:find("{t:")then
AfwsY,T,WZs,Caz4NM4Z,XVxxx,hD,G5BuU5=self:SplicePlaceholderText(PlwhaRKJ,"{t:")ITdz=self.Placeholders.EntityTypes[T]
PlwhaRKJ=AfwsY..
Swift:Localize(
ITdz or("n:"..tostring(T)..": not found"))..WZs elseif PlwhaRKJ:find("{v:")then
AfwsY,T,WZs,Caz4NM4Z,XVxxx,hD,G5BuU5=self:SplicePlaceholderText(PlwhaRKJ,"{v:")ITdz=self:ReplaceValuePlaceholder(T)
PlwhaRKJ=AfwsY..
Swift:Localize(ITdz or("v:"..
tostring(T)..": not found"))..WZs end;if
Caz4NM4Z==nil or XVxxx==nil or hD==nil or G5BuU5 ==nil then break end end;PlwhaRKJ=self:ReplaceColorPlaceholders(PlwhaRKJ)
return PlwhaRKJ end
function ModuleInputOutputCore.Shared:SplicePlaceholderText(AjfoUo,Er9zidsB)
local X,dR=AjfoUo:find(Er9zidsB)local JFXtQwy,uMV17h0=AjfoUo:find("}",dR)local E2NZK=AjfoUo:sub(1,X-1)local WNWWe=AjfoUo:sub(
dR+1,JFXtQwy-1)
local zMzjn3lk=AjfoUo:sub(uMV17h0+1)return E2NZK,WNWWe,zMzjn3lk,X,dR,JFXtQwy,uMV17h0 end
function ModuleInputOutputCore.Shared:ReplaceColorPlaceholders(Trkkpmd)
for L,GGv in pairs(self.Colors)do Trkkpmd=Trkkpmd:gsub(
"{"..L.."}",GGv)end;return Trkkpmd end
function ModuleInputOutputCore.Shared:ReplaceValuePlaceholder(ZIzh4Si)local c8D4n81=_G
local cSjJHx=string.slice(ZIzh4Si,"%.")
for fa=1,#cSjJHx do local M=cSjJHx[fa]local dIZlrvD=tonumber(M)
if dIZlrvD~=nil then M=dIZlrvD end;if not c8D4n81[M]then return nil end;c8D4n81=c8D4n81[M]end;return c8D4n81 end
function ModuleInputOutputCore.Shared:CommandTokenizer(jQgsATKd)local aBbGg={}if jQgsATKd==nil then
return aBbGg end;local D9={jQgsATKd}local G={}
local gE,QgC=string.find(jQgsATKd,"%s+&&%s+")
if gE then D9={}while(gE)do local CYoa=string.sub(jQgsATKd,1,gE-1)
table.insert(D9,CYoa)jQgsATKd=string.sub(jQgsATKd,QgC+1)
gE,QgC=string.find(jQgsATKd,"%s+&&%s+")end
if
string.len(jQgsATKd)>0 then table.insert(D9,jQgsATKd)end end
for K3ipRr=1,#D9,1 do local gE,QgC=string.find(D9[K3ipRr],"%s+&%s+")
if gE then local F2tY=""
while
(gE)do local rb21L2=string.sub(D9[K3ipRr],1,gE-1)
table.insert(G,F2tY..rb21L2)
if string.find(rb21L2," ")then F2tY=
string.sub(rb21L2,1,string.find(rb21L2," ")-1).." "end;D9[K3ipRr]=string.sub(D9[K3ipRr],QgC+1)
gE,QgC=string.find(D9[K3ipRr],"%s+&%s+")end;if string.len(D9[K3ipRr])>0 then
table.insert(G,F2tY..D9[K3ipRr])end else
table.insert(G,D9[K3ipRr])end end
for o_v255=1,#G,1 do local wUVm={}local gE,QgC=string.find(G[o_v255],"%s+")
if gE then while(gE)do local VQ=string.sub(G[o_v255],1,
gE-1)table.insert(wUVm,VQ)G[o_v255]=string.sub(G[o_v255],
QgC+1)
gE,QgC=string.find(G[o_v255],"%s+")end
table.insert(wUVm,G[o_v255])else table.insert(wUVm,G[o_v255])end;table.insert(aBbGg,wUVm)end;return aBbGg end;Swift:RegisterModule(ModuleInputOutputCore)