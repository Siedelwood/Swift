
ModuleKnightTitleRequirements={Properties={Name="ModuleKnightTitleRequirements"},Global={},Local={},Shared={}}QSB.RequirementTooltipTypes={}QSB.ConsumedGoodsCounter={}
function ModuleKnightTitleRequirements.Global:OnGameStart()
self:OverwritePromotionCelebration()self:OverwriteConsumedGoods()end
function ModuleKnightTitleRequirements.Global:RegisterConsumedGoods(QDnlt,LmcA2auZ)QSB.ConsumedGoodsCounter[QDnlt]=
QSB.ConsumedGoodsCounter[QDnlt]or{}QSB.ConsumedGoodsCounter[QDnlt][LmcA2auZ]=
QSB.ConsumedGoodsCounter[QDnlt][LmcA2auZ]or 0;QSB.ConsumedGoodsCounter[QDnlt][LmcA2auZ]=
QSB.ConsumedGoodsCounter[QDnlt][LmcA2auZ]+1 end
function ModuleKnightTitleRequirements.Global:OverwritePromotionCelebration()
GameCallback_KnightTitleChanged_Orig_QSB_Requirements=GameCallback_KnightTitleChanged
GameCallback_KnightTitleChanged=function(Q,ZA)
GameCallback_KnightTitleChanged_Orig_QSB_Requirements(Q,ZA)local _IQQ=QSB.ConsumedGoodsCounter[Q]QSB.ConsumedGoodsCounter[Q]=
_IQQ or{}for XpkjA,pVRj in pairs(QSB.ConsumedGoodsCounter[Q])do
QSB.ConsumedGoodsCounter[Q][XpkjA]=0 end end end
function ModuleKnightTitleRequirements.Global:OverwriteConsumedGoods()
GameCallback_ConsumeGood_Orig_QSB_Requirements=GameCallback_ConsumeGood
GameCallback_ConsumeGood=function(fuZ3z86,er,DFb100j)
GameCallback_ConsumeGood_Orig_QSB_Requirements(fuZ3z86,er,DFb100j)local XL_=Logic.EntityGetPlayer(fuZ3z86)
ModuleKnightTitleRequirements.Global:RegisterConsumedGoods(XL_,er)
Logic.ExecuteInLuaLocalState([[
            ModuleKnightTitleRequirements.Local:RegisterConsumedGoods(
                ]]..XL_..[[, ]]..er..
[[
            );
        ]])end end
function ModuleKnightTitleRequirements.Local:OnGameStart()
self:OverwriteTooltips()self:InitTexturePositions()
self:OverwriteUpdateRequirements()self:OverwritePromotionCelebration()end
function ModuleKnightTitleRequirements.Local:RegisterConsumedGoods(WYdR,QKKks_zt)QSB.ConsumedGoodsCounter[WYdR]=
QSB.ConsumedGoodsCounter[WYdR]or{}QSB.ConsumedGoodsCounter[WYdR][QKKks_zt]=
QSB.ConsumedGoodsCounter[WYdR][QKKks_zt]or 0;QSB.ConsumedGoodsCounter[WYdR][QKKks_zt]=
QSB.ConsumedGoodsCounter[WYdR][QKKks_zt]+1 end
function ModuleKnightTitleRequirements.Local:InitTexturePositions()
g_TexturePositions.EntityCategories[EntityCategories.GC_Food_Supplier]={1,1}
g_TexturePositions.EntityCategories[EntityCategories.GC_Clothes_Supplier]={1,2}
g_TexturePositions.EntityCategories[EntityCategories.GC_Hygiene_Supplier]={16,1}
g_TexturePositions.EntityCategories[EntityCategories.GC_Entertainment_Supplier]={1,4}
g_TexturePositions.EntityCategories[EntityCategories.GC_Luxury_Supplier]={16,3}
g_TexturePositions.EntityCategories[EntityCategories.GC_Weapon_Supplier]={1,7}
g_TexturePositions.EntityCategories[EntityCategories.GC_Medicine_Supplier]={2,10}
g_TexturePositions.EntityCategories[EntityCategories.Outpost]={12,3}
g_TexturePositions.EntityCategories[EntityCategories.Spouse]={5,15}
g_TexturePositions.EntityCategories[EntityCategories.CattlePasture]={3,16}
g_TexturePositions.EntityCategories[EntityCategories.SheepPasture]={4,1}
g_TexturePositions.EntityCategories[EntityCategories.Soldier]={7,12}
g_TexturePositions.EntityCategories[EntityCategories.GrainField]={14,2}
g_TexturePositions.EntityCategories[EntityCategories.BeeHive]={2,1}
g_TexturePositions.EntityCategories[EntityCategories.OuterRimBuilding]={3,4}
g_TexturePositions.EntityCategories[EntityCategories.CityBuilding]={8,1}
g_TexturePositions.EntityCategories[EntityCategories.Leader]={7,11}
g_TexturePositions.EntityCategories[EntityCategories.Range]={9,8}
g_TexturePositions.EntityCategories[EntityCategories.Melee]={9,7}
g_TexturePositions.EntityCategories[EntityCategories.SiegeEngine]={2,15}
g_TexturePositions.Entities[Entities.B_Beehive]={2,1}
g_TexturePositions.Entities[Entities.B_Cathedral_Big]={3,12}
g_TexturePositions.Entities[Entities.B_CattlePasture]={3,16}
g_TexturePositions.Entities[Entities.B_GrainField_ME]={1,13}
g_TexturePositions.Entities[Entities.B_GrainField_NA]={1,13}
g_TexturePositions.Entities[Entities.B_GrainField_NE]={1,13}
g_TexturePositions.Entities[Entities.B_GrainField_SE]={1,13}
g_TexturePositions.Entities[Entities.U_MilitaryBallista]={10,5}
g_TexturePositions.Entities[Entities.B_Outpost]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_ME]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_NA]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_NE]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_SE]={12,3}
g_TexturePositions.Entities[Entities.B_SheepPasture]={4,1}
g_TexturePositions.Entities[Entities.U_SiegeEngineCart]={9,4}
g_TexturePositions.Entities[Entities.U_Trebuchet]={9,1}
if Framework.GetGameExtraNo()~=0 then
g_TexturePositions.Entities[Entities.B_GrainField_AS]={1,13}
g_TexturePositions.Entities[Entities.B_Outpost_AS]={12,3}end
g_TexturePositions.Needs[Needs.Medicine]={2,10}
g_TexturePositions.Technologies[Technologies.R_Castle_Upgrade_1]={4,7}
g_TexturePositions.Technologies[Technologies.R_Castle_Upgrade_2]={4,7}
g_TexturePositions.Technologies[Technologies.R_Castle_Upgrade_3]={4,7}
g_TexturePositions.Technologies[Technologies.R_Cathedral_Upgrade_1]={4,5}
g_TexturePositions.Technologies[Technologies.R_Cathedral_Upgrade_2]={4,5}
g_TexturePositions.Technologies[Technologies.R_Cathedral_Upgrade_3]={4,5}
g_TexturePositions.Technologies[Technologies.R_Storehouse_Upgrade_1]={4,6}
g_TexturePositions.Technologies[Technologies.R_Storehouse_Upgrade_2]={4,6}
g_TexturePositions.Technologies[Technologies.R_Storehouse_Upgrade_3]={4,6}
g_TexturePositions.Buffs=g_TexturePositions.Buffs or{}
g_TexturePositions.Buffs[Buffs.Buff_ClothesDiversity]={1,2}
g_TexturePositions.Buffs[Buffs.Buff_EntertainmentDiversity]={1,4}
g_TexturePositions.Buffs[Buffs.Buff_FoodDiversity]={1,1}
g_TexturePositions.Buffs[Buffs.Buff_HygieneDiversity]={1,3}
g_TexturePositions.Buffs[Buffs.Buff_Colour]={5,11}
g_TexturePositions.Buffs[Buffs.Buff_Entertainers]={5,12}
g_TexturePositions.Buffs[Buffs.Buff_ExtraPayment]={1,8}
g_TexturePositions.Buffs[Buffs.Buff_Sermon]={4,14}
g_TexturePositions.Buffs[Buffs.Buff_Spice]={5,10}
g_TexturePositions.Buffs[Buffs.Buff_NoTaxes]={1,6}
if Framework.GetGameExtraNo()~=0 then
g_TexturePositions.Buffs[Buffs.Buff_Gems]={1,1,1}
g_TexturePositions.Buffs[Buffs.Buff_MusicalInstrument]={1,3,1}
g_TexturePositions.Buffs[Buffs.Buff_Olibanum]={1,2,1}end
g_TexturePositions.GoodCategories=g_TexturePositions.GoodCategories or{}
g_TexturePositions.GoodCategories[GoodCategories.GC_Ammunition]={10,6}
g_TexturePositions.GoodCategories[GoodCategories.GC_Animal]={4,16}
g_TexturePositions.GoodCategories[GoodCategories.GC_Clothes]={1,2}
g_TexturePositions.GoodCategories[GoodCategories.GC_Document]={5,6}
g_TexturePositions.GoodCategories[GoodCategories.GC_Entertainment]={1,4}
g_TexturePositions.GoodCategories[GoodCategories.GC_Food]={1,1}
g_TexturePositions.GoodCategories[GoodCategories.GC_Gold]={1,8}
g_TexturePositions.GoodCategories[GoodCategories.GC_Hygiene]={16,1}
g_TexturePositions.GoodCategories[GoodCategories.GC_Luxury]={16,3}
g_TexturePositions.GoodCategories[GoodCategories.GC_Medicine]={2,10}
g_TexturePositions.GoodCategories[GoodCategories.GC_None]={15,16}
g_TexturePositions.GoodCategories[GoodCategories.GC_RawFood]={3,4}
g_TexturePositions.GoodCategories[GoodCategories.GC_RawMedicine]={2,2}
g_TexturePositions.GoodCategories[GoodCategories.GC_Research]={5,6}
g_TexturePositions.GoodCategories[GoodCategories.GC_Resource]={3,4}
g_TexturePositions.GoodCategories[GoodCategories.GC_Tools]={4,12}
g_TexturePositions.GoodCategories[GoodCategories.GC_Water]={1,16}
g_TexturePositions.GoodCategories[GoodCategories.GC_Weapon]={8,5}end
function ModuleKnightTitleRequirements.Local:OverwriteUpdateRequirements()
GUI_Knight.UpdateRequirements=function()
local Are7xU=ModuleKnightTitleRequirements.Local.RequirementWidgets;local yxjl=1;local ZG=GUI.GetPlayerID()
local Vu0cCAf=Logic.GetKnightTitle(ZG)local q=Vu0cCAf+1;local kP7O5=Logic.GetKnightID(ZG)
local lqT=Logic.GetEntityType(kP7O5)
XGUIEng.SetText("/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/NextKnightTitle","{center}"..
GUI_Knight.GetTitleNameByTitleID(lqT,q))
XGUIEng.SetText("/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/NextKnightTitleWhite","{center}"..
GUI_Knight.GetTitleNameByTitleID(lqT,q))
if KnightTitleRequirements[q].Settlers~=nil then SetIcon(
Are7xU[yxjl].."/Icon",{5,16})
local mP3mlD,PrPyxMK,tczrIB=DoesNeededNumberOfSettlersForKnightTitleExist(ZG,q)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..PrPyxMK.."/"..tczrIB)if mP3mlD then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]="Settlers"yxjl=yxjl+1 end
if KnightTitleRequirements[q].RichBuildings~=nil then SetIcon(
Are7xU[yxjl].."/Icon",{8,4})
local a,wqU76o,LB1Z=DoNeededNumberOfRichBuildingsForKnightTitleExist(ZG,q)if LB1Z==-1 then
LB1Z=Logic.GetNumberOfPlayerEntitiesInCategory(ZG,EntityCategories.CityBuilding)end
XGUIEng.SetText(Are7xU[yxjl]..
"/Amount","{center}"..wqU76o.."/"..LB1Z)if a then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]="RichBuildings"
yxjl=yxjl+1 end
if KnightTitleRequirements[q].Headquarters~=nil then SetIcon(
Are7xU[yxjl].."/Icon",{4,7})
local N9L,hDc_M,qW0lRiD1=DoNeededSpecialBuildingUpgradeForKnightTitleExist(ZG,q,EntityCategories.Headquarters)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..
hDc_M+1 .."/"..qW0lRiD1+1)if N9L then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]="Headquarters"
yxjl=yxjl+1 end
if KnightTitleRequirements[q].Storehouse~=nil then SetIcon(
Are7xU[yxjl].."/Icon",{4,6})
local iD1IUx,JLCOx_ak,hPQ=DoNeededSpecialBuildingUpgradeForKnightTitleExist(ZG,q,EntityCategories.Storehouse)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..JLCOx_ak+1 .."/"..hPQ+1)if iD1IUx then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]="Storehouse"
yxjl=yxjl+1 end
if KnightTitleRequirements[q].Cathedrals~=nil then SetIcon(
Are7xU[yxjl].."/Icon",{4,5})
local R1FIoQI,NsoTwDs,HGli=DoNeededSpecialBuildingUpgradeForKnightTitleExist(ZG,q,EntityCategories.Cathedrals)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..
NsoTwDs+1 .."/"..HGli+1)if R1FIoQI then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]="Cathedrals"
yxjl=yxjl+1 end
if
KnightTitleRequirements[q].FullDecoratedBuildings~=nil then
local iy,m6SCS0,NUhYw6R4=DoNeededNumberOfFullDecoratedBuildingsForKnightTitleExist(ZG,q)
local Hv=KnightTitleRequirements[q].FullDecoratedBuildings
SetIcon(Are7xU[yxjl].."/Icon",g_TexturePositions.Needs[Needs.Wealth])
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..m6SCS0 .."/"..NUhYw6R4)if iy then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]="FullDecoratedBuildings"yxjl=
yxjl+1 end
if KnightTitleRequirements[q].Reputation~=nil then SetIcon(
Are7xU[yxjl].."/Icon",{5,14})
local Ch,urkh,zhzpBSx=DoesNeededCityReputationForKnightTitleExist(ZG,q)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..urkh.."/"..zhzpBSx)if Ch then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]="Reputation"
yxjl=yxjl+1 end
if KnightTitleRequirements[q].Goods~=nil then
for rHSjalVy=1,#
KnightTitleRequirements[q].Goods do
local TjhsnP=KnightTitleRequirements[q].Goods[rHSjalVy][1]
SetIcon(Are7xU[yxjl].."/Icon",g_TexturePositions.Goods[TjhsnP])
local t5jzEd9,JZAU2,zPXTTg=DoesNeededNumberOfGoodTypesForKnightTitleExist(ZG,q,rHSjalVy)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..JZAU2 .."/"..zPXTTg)if t5jzEd9 then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]="Goods"..rHSjalVy;yxjl=
yxjl+1 end end
if KnightTitleRequirements[q].Category~=nil then
for seMLr=1,#
KnightTitleRequirements[q].Category do
local qX=KnightTitleRequirements[q].Category[seMLr][1]
SetIcon(Are7xU[yxjl].."/Icon",g_TexturePositions.EntityCategories[qX])
local h_8,xL7OTb,w8T3f=DoesNeededNumberOfEntitiesInCategoryForKnightTitleExist(ZG,q,seMLr)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..xL7OTb.."/"..w8T3f)if h_8 then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)
local K={Logic.GetEntityTypesInCategory(qX)}
if
Logic.IsEntityTypeInCategory(K[1],EntityCategories.GC_Weapon_Supplier)==1 then QSB.RequirementTooltipTypes[yxjl]=
"Weapons"..seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.SiegeEngine)==1 then QSB.RequirementTooltipTypes[yxjl]="HeavyWeapons"..
seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.Spouse)==1 then
QSB.RequirementTooltipTypes[yxjl]="Spouse"..seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.Worker)==1 then QSB.RequirementTooltipTypes[yxjl]="Worker"..seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.Soldier)==1 then
QSB.RequirementTooltipTypes[yxjl]="Soldiers"..seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.Leader)==1 then QSB.RequirementTooltipTypes[yxjl]="Leader"..seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.Outpost)==1 then
QSB.RequirementTooltipTypes[yxjl]="Outposts"..seMLr elseif Logic.IsEntityTypeInCategory(K[1],EntityCategories.CattlePasture)==
1 then
QSB.RequirementTooltipTypes[yxjl]="Cattle"..seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.SheepPasture)==1 then QSB.RequirementTooltipTypes[yxjl]="Sheep"..seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.CityBuilding)==1 then QSB.RequirementTooltipTypes[yxjl]="CityBuilding"..
seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.OuterRimBuilding)==1 then QSB.RequirementTooltipTypes[yxjl]=
"OuterRimBuilding"..seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.GrainField)==1 then QSB.RequirementTooltipTypes[yxjl]="FarmerBuilding"..
seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.BeeHive)==1 then QSB.RequirementTooltipTypes[yxjl]="FarmerBuilding"..
seMLr elseif
Logic.IsEntityTypeInCategory(K[1],EntityCategories.AttackableBuilding)==1 then QSB.RequirementTooltipTypes[yxjl]=
"Buildings"..seMLr else QSB.RequirementTooltipTypes[yxjl]=
"EntityCategoryDefault"..seMLr end;yxjl=yxjl+1 end end
if KnightTitleRequirements[q].Entities~=nil then
for qL=1,#
KnightTitleRequirements[q].Entities do
local vfIyB=KnightTitleRequirements[q].Entities[qL][1]local quNsijN=Logic.GetEntityTypeName(vfIyB)
SetIcon(Are7xU[yxjl].."/Icon",g_TexturePositions.Entities[vfIyB])
local QUh2tc,qboV,nSBOx7=DoesNeededNumberOfEntitiesOfTypeForKnightTitleExist(ZG,q,qL)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..qboV.."/"..nSBOx7)if QUh2tc then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)local u="Entities"..qL;if
quNsijN=="B_Beehive"or quNsijN:find("GrainField")or quNsijN:find("Pasture")then
u="FarmerBuilding"..qL end
QSB.RequirementTooltipTypes[yxjl]=u;yxjl=yxjl+1 end end
if KnightTitleRequirements[q].Consume~=nil then
for K=1,#
KnightTitleRequirements[q].Consume do
local i1=KnightTitleRequirements[q].Consume[K][1]
SetIcon(Are7xU[yxjl].."/Icon",g_TexturePositions.Goods[i1])
local zz1QI,kFTAh,LBf=DoNeededNumberOfConsumedGoodsForKnightTitleExist(ZG,q,K)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..kFTAh.."/"..LBf)if zz1QI then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]="Consume"..K
yxjl=yxjl+1 end end
if KnightTitleRequirements[q].Products~=nil then
for dijn4Ph=1,#
KnightTitleRequirements[q].Products do
local CO1=KnightTitleRequirements[q].Products[dijn4Ph][1]
SetIcon(Are7xU[yxjl].."/Icon",g_TexturePositions.GoodCategories[CO1])
local RlZo,SUn,Ib4=DoNumberOfProductsInCategoryExist(ZG,q,dijn4Ph)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..SUn.."/"..Ib4)if RlZo then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)
QSB.RequirementTooltipTypes[yxjl]="Products"..dijn4Ph;yxjl=yxjl+1 end end
if KnightTitleRequirements[q].Buff~=nil then
for fjV1G2=1,#
KnightTitleRequirements[q].Buff do
local Do=KnightTitleRequirements[q].Buff[fjV1G2]
SetIcon(Are7xU[yxjl].."/Icon",g_TexturePositions.Buffs[Do])
local _=DoNeededDiversityBuffForKnightTitleExist(ZG,q,fjV1G2)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","")if _ then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]="Buff"..fjV1G2
yxjl=yxjl+1 end end
if KnightTitleRequirements[q].Custom~=nil then
for TqYJ4=1,#
KnightTitleRequirements[q].Custom do
local DI=KnightTitleRequirements[q].Custom[TqYJ4][2]API.SetIcon(Are7xU[yxjl].."/Icon",DI)
local b,E,KMw7_i1s=DoCustomFunctionForKnightTitleSucceed(ZG,q,TqYJ4)if E and KMw7_i1s then
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..E.."/"..KMw7_i1s)else
XGUIEng.SetText(Are7xU[yxjl].."/Amount","")end
if b then XGUIEng.ShowWidget(
Are7xU[yxjl].."/Done",1)else XGUIEng.ShowWidget(
Are7xU[yxjl].."/Done",0)end;XGUIEng.ShowWidget(Are7xU[yxjl],1)QSB.RequirementTooltipTypes[yxjl]=
"Custom"..TqYJ4;yxjl=yxjl+1 end end
if KnightTitleRequirements[q].DecoratedBuildings~=nil then
for CQi=1,#
KnightTitleRequirements[q].DecoratedBuildings do
local nHlJ=KnightTitleRequirements[q].DecoratedBuildings[CQi][1]
SetIcon(Are7xU[yxjl].."/Icon",g_TexturePositions.Goods[nHlJ])
local lw4Q7kbl,IN,QYf1=DoNeededNumberOfDecoratedBuildingsForKnightTitleExist(ZG,q,CQi)
XGUIEng.SetText(Are7xU[yxjl].."/Amount","{center}"..IN.."/"..QYf1)if lw4Q7kbl then
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",1)else
XGUIEng.ShowWidget(Are7xU[yxjl].."/Done",0)end
XGUIEng.ShowWidget(Are7xU[yxjl],1)
QSB.RequirementTooltipTypes[yxjl]="DecoratedBuildings"..CQi;yxjl=yxjl+1 end end
for RfsnisO=yxjl,6 do XGUIEng.ShowWidget(Are7xU[RfsnisO],0)end end end
function ModuleKnightTitleRequirements.Local:OverwritePromotionCelebration()
StartKnightsPromotionCelebration=function(lvW2ga,T7RKP,_L6Bs)if

lvW2ga~=GUI.GetPlayerID()or Logic.GetTime()<5 then return end
local SH=Logic.GetMarketplace(lvW2ga)
if _L6Bs==1 then local fFeQcIM=Logic.GetKnightID(lvW2ga)local JEHSHPh3
repeat JEHSHPh3=1+
XGUIEng.GetRandom(3)until JEHSHPh3 ~=g_LastGotPromotionMessageRandom;g_LastGotPromotionMessageRandom=JEHSHPh3
local bb="Title_GotPromotion"..JEHSHPh3
LocalScriptCallback_QueueVoiceMessage(lvW2ga,bb,false,lvW2ga)GUI.StartFestival(lvW2ga,1)end;local wU4wYbA9=QSB.ConsumedGoodsCounter[lvW2ga]QSB.ConsumedGoodsCounter[lvW2ga]=
wU4wYbA9 or{}for o5e6fP,iq7ol in
pairs(QSB.ConsumedGoodsCounter[lvW2ga])do
QSB.ConsumedGoodsCounter[lvW2ga][o5e6fP]=0 end
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopCenter/KnightTitleMenuBig",0)g_WantsPromotionMessageInterval=30;g_TimeOfPromotionPossible=nil end end
function ModuleKnightTitleRequirements.Local:OverwriteTooltips()
GUI_Tooltip.SetNameAndDescription_Orig_QSB_Requirements=GUI_Tooltip.SetNameAndDescription
GUI_Tooltip.SetNameAndDescription=function(eMV,WDTNkTD,Oejsws,CkD73N0,PlwhaRKJ)local Caz4NM4Z=XGUIEng.GetCurrentWidgetID()
local XVxxx=GUI.GetSelectedEntity()local hD=GUI.GetPlayerID()
for G5BuU5,AfwsY in
pairs(ModuleKnightTitleRequirements.Local.RequirementWidgets)do
if
AfwsY.."/Icon"==XGUIEng.GetWidgetPathByID(Caz4NM4Z)then local T=QSB.RequirementTooltipTypes[G5BuU5]
local WZs=tonumber(string.sub(T,string.len(T)))
if WZs~=nil then T=string.sub(T,1,string.len(T)-1)end
ModuleKnightTitleRequirements.Local:RequirementTooltipWrapped(T,WZs)return end end
GUI_Tooltip.SetNameAndDescription_Orig_QSB_Requirements(eMV,WDTNkTD,Oejsws,CkD73N0,PlwhaRKJ)end
GUI_Knight.RequiredGoodTooltip=function()local ITdz=QSB.RequirementTooltipTypes[2]
local AjfoUo=tonumber(string.sub(ITdz,string.len(ITdz)))if AjfoUo~=nil then
ITdz=string.sub(ITdz,1,string.len(ITdz)-1)end
ModuleKnightTitleRequirements.Local:RequirementTooltipWrapped(ITdz,AjfoUo)end
if Framework.GetGameExtraNo()~=0 then
ModuleKnightTitleRequirements.Local.BuffTypeNames[Buffs.Buff_Gems]={de="Edelsteine beschaffen",en="Obtain gems"}
ModuleKnightTitleRequirements.Local.BuffTypeNames[Buffs.Buff_Olibanum]={de="Weihrauch beschaffen",en="Obtain olibanum"}
ModuleKnightTitleRequirements.Local.BuffTypeNames[Buffs.Buff_MusicalInstrument]={de="Muskinstrumente beschaffen",en="Obtain instruments"}end end
function ModuleKnightTitleRequirements.Local:RequirementTooltipWrapped(Er9zidsB,X)
local dR=GUI.GetPlayerID()local JFXtQwy=Logic.GetKnightTitle(dR)local uMV17h0=""local E2NZK=""
if

Er9zidsB=="Consume"or Er9zidsB=="Goods"or Er9zidsB=="DecoratedBuildings"then
local WNWWe=KnightTitleRequirements[JFXtQwy+1][Er9zidsB][X][1]local zMzjn3lk=Logic.GetGoodTypeName(WNWWe)
local Trkkpmd=XGUIEng.GetStringTableText(
"UI_ObjectNames/"..zMzjn3lk)if Trkkpmd==nil then Trkkpmd="Goods."..zMzjn3lk end
uMV17h0=Trkkpmd
E2NZK=ModuleKnightTitleRequirements.Local.Description[Er9zidsB].Text elseif Er9zidsB=="Products"then
local L=ModuleKnightTitleRequirements.Local.GoodCategoryNames
local GGv=KnightTitleRequirements[JFXtQwy+1][Er9zidsB][X][1]local ZIzh4Si=API.Localize(L[GGv])if ZIzh4Si==nil then
ZIzh4Si="ERROR: Name missng!"end;uMV17h0=ZIzh4Si
E2NZK=ModuleKnightTitleRequirements.Local.Description[Er9zidsB].Text elseif Er9zidsB=="Entities"then
local c8D4n81=KnightTitleRequirements[JFXtQwy+1][Er9zidsB][X][1]local cSjJHx=Logic.GetEntityTypeName(c8D4n81)local fa=XGUIEng.GetStringTableText(
"Names/"..cSjJHx)if fa==nil then fa="Entities."..
cSjJHx end;uMV17h0=fa
E2NZK=ModuleKnightTitleRequirements.Local.Description[Er9zidsB].Text elseif Er9zidsB=="Custom"then
local M=KnightTitleRequirements[JFXtQwy+1].Custom[X]uMV17h0=M[3]E2NZK=M[4]elseif Er9zidsB=="Buff"then
local dIZlrvD=ModuleKnightTitleRequirements.Local.BuffTypeNames
local jQgsATKd=KnightTitleRequirements[JFXtQwy+1][Er9zidsB][X]local aBbGg=API.Localize(dIZlrvD[jQgsATKd])if aBbGg==nil then
aBbGg="ERROR: Name missng!"end;uMV17h0=aBbGg
E2NZK=ModuleKnightTitleRequirements.Local.Description[Er9zidsB].Text else
uMV17h0=ModuleKnightTitleRequirements.Local.Description[Er9zidsB].Title
E2NZK=ModuleKnightTitleRequirements.Local.Description[Er9zidsB].Text end
API.SetTooltipNormal(API.Localize(uMV17h0),API.Localize(E2NZK),nil)end
ModuleKnightTitleRequirements.Local.RequirementWidgets={[1]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Settlers",[2]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Goods",[3]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/RichBuildings",[4]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Castle",[5]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Storehouse",[6]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Cathedral"}
ModuleKnightTitleRequirements.Local.GoodCategoryNames={[GoodCategories.GC_Ammunition]={de="Munition",en="Ammunition"},[GoodCategories.GC_Animal]={de="Nutztiere",en="Livestock"},[GoodCategories.GC_Clothes]={de="Kleidung",en="Clothes"},[GoodCategories.GC_Document]={de="Dokumente",en="Documents"},[GoodCategories.GC_Entertainment]={de="Unterhaltung",en="Entertainment"},[GoodCategories.GC_Food]={de="Nahrungsmittel",en="Food"},[GoodCategories.GC_Gold]={de="Gold",en="Gold"},[GoodCategories.GC_Hygiene]={de="Hygieneartikel",en="Hygiene"},[GoodCategories.GC_Luxury]={de="Dekoration",en="Decoration"},[GoodCategories.GC_Medicine]={de="Medizin",en="Medicine"},[GoodCategories.GC_None]={de="Nichts",en="None"},[GoodCategories.GC_RawFood]={de="Nahrungsmittel",en="Food"},[GoodCategories.GC_RawMedicine]={de="Medizin",en="Medicine"},[GoodCategories.GC_Research]={de="Forschung",en="Research"},[GoodCategories.GC_Resource]={de="Rohstoffe",en="Resource"},[GoodCategories.GC_Tools]={de="Werkzeug",en="Tools"},[GoodCategories.GC_Water]={de="Wasser",en="Water"},[GoodCategories.GC_Weapon]={de="Waffen",en="Weapon"}}
ModuleKnightTitleRequirements.Local.BuffTypeNames={[Buffs.Buff_ClothesDiversity]={de="Vielfältige Kleidung",en="Clothes variety"},[Buffs.Buff_Colour]={de="Farben beschaffen",en="Obtain color"},[Buffs.Buff_Entertainers]={de="Gaukler anheuern",en="Hire entertainer"},[Buffs.Buff_EntertainmentDiversity]={de="Vielfältige Unterhaltung",en="Entertainment variety"},[Buffs.Buff_ExtraPayment]={de="Sonderzahlung",en="Extra payment"},[Buffs.Buff_Festival]={de="Fest veranstalten",en="Hold Festival"},[Buffs.Buff_FoodDiversity]={de="Vielfältige Nahrung",en="Food variety"},[Buffs.Buff_HygieneDiversity]={de="Vielfältige Hygiene",en="Hygiene variety"},[Buffs.Buff_NoTaxes]={de="Steuerbefreiung",en="No taxes"},[Buffs.Buff_Sermon]={de="Pregigt abhalten",en="Hold sermon"},[Buffs.Buff_Spice]={de="Salz beschaffen",en="Obtain salt"}}
ModuleKnightTitleRequirements.Local.Description={Settlers={Title={de="Benötigte Siedler",en="Needed settlers"},Text={de="- Benötigte Menge an Siedlern",en="- Needed number of settlers"}},RichBuildings={Title={de="Reiche Häuser",en="Rich city buildings"},Text={de="- Menge an reichen Stadtgebäuden",en="- Needed amount of rich city buildings"}},Goods={Title={de="Waren lagern",en="Store Goods"},Text={de="- Benötigte Menge",en="- Needed amount"}},FullDecoratedBuildings={Title={de="Dekorierte Häuser",en="Decorated City buildings"},Text={de="- Menge an voll dekorierten Gebäuden",en="- Amount of full decoraded city buildings"}},DecoratedBuildings={Title={de="Dekoration",en="Decoration"},Text={de="- Menge an Dekorationsgütern in der Siedlung",en="- Amount of decoration goods in settlement"}},Headquarters={Title={de="Burgstufe",en="Castle level"},Text={de="- Benötigte Ausbauten der Burg",en="- Needed castle upgrades"}},Storehouse={Title={de="Lagerhausstufe",en="Storehouse level"},Text={de="- Benötigte Ausbauten des Lagerhauses",en="- Needed storehouse upgrades"}},Cathedrals={Title={de="Kirchenstufe",en="Cathedral level"},Text={de="- Benötigte Ausbauten der Kirche",en="- Needed cathedral upgrades"}},Reputation={Title={de="Ruf der Stadt",en="City reputation"},Text={de="- Benötigter Ruf der Stadt",en="- Needed city reputation"}},EntityCategoryDefault={Title={de="",en=""},Text={de="- Benötigte Anzahl",en="- Needed amount"}},Cattle={Title={de="Kühe",en="Cattle"},Text={de="- Benötigte Menge an Kühen",en="- Needed amount of cattle"}},Sheep={Title={de="Schafe",en="Sheeps"},Text={de="- Benötigte Menge an Schafen",en="- Needed amount of sheeps"}},Outposts={Title={de="Territorien",en="Territories"},Text={de="- Zu erobernde Territorien",en="- Territories to claim"}},CityBuilding={Title={de="Stadtgebäude",en="City buildings"},Text={de="- Menge benötigter Stadtgebäude",en="- Needed amount of city buildings"}},OuterRimBuilding={Title={de="Rohstoffgebäude",en="Gatherer"},Text={de="- Menge benötigter Rohstoffgebäude",en="- Needed amount of gatherer"}},FarmerBuilding={Title={de="Farmeinrichtungen",en="Farming structure"},Text={de="- Menge benötigter Nutzfläche",en="- Needed amount of farming structure"}},Consume={Title={de="",en=""},Text={de="- Durch Siedler zu konsumierende Menge",en="- Amount to be consumed by the settlers"}},Products={Title={de="",en=""},Text={de="- Benötigte Menge",en="- Needed amount"}},Buff={Title={de="Bonus aktivieren",en="Activate Buff"},Text={de="- Aktiviere diesen Bonus auf den Ruf der Stadt",en="- Raise the city reputatition with this buff"}},Leader={Title={de="Batalione",en="Battalions"},Text={de="- Menge an Batalionen unterhalten",en="- Battalions you need under your command"}},Soldiers={Title={de="Soldaten",en="Soldiers"},Text={de="- Menge an Streitkräften unterhalten",en="- Soldiers you need under your command"}},Worker={Title={de="Arbeiter",en="Workers"},Text={de="- Menge an arbeitender Bevölkerung",en="- Workers you need under your reign"}},Entities={Title={de="",en=""},Text={de="- Benötigte Menge",en="- Needed Amount"}},Buildings={Title={de="Gebäude",en="Buildings"},Text={de="- Gesamtmenge an Gebäuden",en="- Amount of buildings"}},Weapons={Title={de="Waffen",en="Weapons"},Text={de="- Benötigte Menge an Waffen",en="- Needed amount of weapons"}},HeavyWeapons={Title={de="Belagerungsgeräte",en="Siege Engines"},Text={de="- Benötigte Menge an Belagerungsgeräten",en="- Needed amount of siege engine"}},Spouse={Title={de="Ehefrauen",en="Spouses"},Text={de="- Benötigte Anzahl Ehefrauen in der Stadt",en="- Needed amount of spouses in your city"}}}
Swift:RegisterModule(ModuleKnightTitleRequirements)