SCP.ConstructionAndKnockdown={}
ModuleConstructionControl={Properties={Name="ModuleConstructionControl"},Global={ConstructionConditionCounter=0,ConstructionConditions={},KnockdownConditionCounter=0,KnockdownConditions={}},Local={WallData={
-1}},Shared={WallTypes={"B_PalisadeSegment","B_PalisadeGate","B_WallGate_AS","B_WallSegment_AS","B_WallGate_NA","B_WallSegment_NA","B_WallGate_NE","B_WallSegment_NE","B_WallGate_ME","B_WallSegment_ME","B_WallGate_SE","B_WallSegment_SE"}}}
function ModuleConstructionControl.Global:OnGameStart()
API.RegisterScriptCommand("Cmd_CheckCancelKnockdown",SCP.ConstructionAndKnockdown.CancelKnockdown)self:OverrideCanPlayerPlaceBuilding()end
function ModuleConstructionControl.Global:OnEvent(QDnlt,LmcA2auZ,...)end
function ModuleConstructionControl.Global:OverrideCanPlayerPlaceBuilding()
GameCallback_CanPlayerPlaceBuilding_Orig_ConstructionControl=GameCallback_CanPlayerPlaceBuilding
GameCallback_CanPlayerPlaceBuilding=function(Q,ZA,_IQQ,XpkjA)
if not
ModuleConstructionControl.Global:CheckConstructionConditions(Q,ZA,_IQQ,XpkjA)then return false end
return GameCallback_CanPlayerPlaceBuilding_Orig_ConstructionControl(Q,ZA,_IQQ,XpkjA)end
API.StartHiResJob(function()
for pVRj=1,#ModuleConstructionControl.Shared.WallTypes
do
local fuZ3z86=Entities[ModuleConstructionControl.Shared.WallTypes[pVRj]]
if fuZ3z86 then local er=Logic.GetEntitiesOfType(fuZ3z86)
for DFb100j=1,#er do
local XL_=Logic.EntityGetPlayer(er[DFb100j])local WYdR,QKKks_zt,Are7xU=Logic.EntityGetPos(er[DFb100j])
if

Logic.IsConstructionComplete(er[DFb100j])==0 and not
self:CheckConstructionConditions(XL_,fuZ3z86,WYdR,QKKks_zt)then
Logic.ExecuteInLuaLocalState(string.format([[
                            if GUI.GetPlayerID() == %d then
                                -- TODO: Add message
                                GUI.CancelState()
                            end
                        ]],XL_))DestroyEntity(er[DFb100j])end end end end end)end
function ModuleConstructionControl.Global:CheckCancelBuildingKnockdown(yxjl,ZG,Vu0cCAf)
if
Logic.EntityGetPlayer(ZG)==yxjl and Vu0cCAf==1 and not
self:CheckKnockdownConditions(ZG)then
Logic.ExecuteInLuaLocalState(string.format([[GUI.CancelBuildingKnockDown(%d)]],ZG))end end
function ModuleConstructionControl.Global:GenerateConstructionConditionID()self.ConstructionConditionCounter=
self.ConstructionConditionCounter+1
return self.ConstructionConditionCounter end
function ModuleConstructionControl.Global:CheckConstructionConditions(q,kP7O5,lqT,mP3mlD)
for PrPyxMK,tczrIB in
pairs(self.ConstructionConditions)do if not tczrIB(q,kP7O5,lqT,mP3mlD)then return false end end;return true end
function ModuleConstructionControl.Global:GenerateKnockdownConditionID()self.KnockdownConditionCounter=
self.KnockdownConditionCounter+1
return self.KnockdownConditionCounter end
function ModuleConstructionControl.Global:CheckKnockdownConditions(a)
for wqU76o,LB1Z in
pairs(self.KnockdownConditions)do if IsExisting(a)and not LB1Z(a)then return false end end;return true end;function ModuleConstructionControl.Local:OnGameStart()
self:OverrideDeleteEntityStateBuilding()end
function ModuleConstructionControl.Local:OverrideDeleteEntityStateBuilding()
GameCallback_GUI_DeleteEntityStateBuilding_Orig_ConstructionControl=GameCallback_GUI_DeleteEntityStateBuilding
GameCallback_GUI_DeleteEntityStateBuilding=function(N9L,hDc_M)
GameCallback_GUI_DeleteEntityStateBuilding_Orig_ConstructionControl(N9L,hDc_M)
API.BroadcastScriptCommand(QSB.ScriptCommands.CheckCancelKnockdown,GUI.GetPlayerID(),N9L,hDc_M)end end;Swift:RegisterModule(ModuleConstructionControl)