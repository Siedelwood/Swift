SCP.CastleStore={}
ModuleCastleStore={Properties={Name="ModuleCastleStore"},Global={UpdateCastleStoreInitalized=false,BackupGoods={},CastleStore={UpdateCastleStore=true,CapacityBase=75,Goods={[Goods.G_Wood]={0,true,false,35},[Goods.G_Stone]={0,true,false,35},[Goods.G_Iron]={0,true,false,35},[Goods.G_Carcass]={0,true,false,15},[Goods.G_Grain]={0,true,false,15},[Goods.G_RawFish]={0,true,false,15},[Goods.G_Milk]={0,true,false,15},[Goods.G_Herb]={0,true,false,15},[Goods.G_Wool]={0,true,false,15},[Goods.G_Honeycomb]={0,true,false,15}}}},Local={CastleStore={},Player={}},Shared={Text={ShowCastle={Text={de="Finanzansicht",en="Financial view"}},ShowCastleStore={Text={de="Lageransicht",en="Storeage view"}},GoodButtonDisabled={Text={de="Diese Ware wird nicht angenommen.",en="This good will not be stored."}},CityTab={Title={de="Güter verwaren",en="Keep goods"},Text={de="[UMSCHALT + N]{cr}- Lagert Waren im Burglager ein {cr}- Waren verbleiben auch im Lager, wenn Platz vorhanden ist",en="[SHIFT + N]{cr}- Stores goods inside the vault {cr}- Goods also remain in the warehouse when space is available"}},StorehouseTab={Title={de="Güter zwischenlagern",en="Store in vault"},Text={de="[UMSCHALT + B]{cr}- Lagert Waren im Burglager ein {cr}- Lagert waren wieder aus, sobald Platz frei wird",en="[SHIFT + B]{cr}- Stores goods inside the vault {cr}- Allows to extrac goods as soon as space becomes available"}},MultiTab={Title={de="Lager räumen",en="Clear store"},Text={de="[UMSCHALT + M]{cr}- Lagert alle Waren aus {cr}- Benötigt Platz im Lagerhaus",en="[Shift + M]{cr}- Removes all goods {cr}- Requires space in the storehouse"}}}}}QSB.CastleStoreObjects={}QSB.CastleStorePlayerData={}
function ModuleCastleStore.Global:OnGameStart()
QSB.CastleStore=self.CastleStore
API.RegisterScriptCommand("Cmd_CastleStoreAcceptAllGoods",SCP.CastleStore.AcceptAllGoods)
API.RegisterScriptCommand("Cmd_CastleStoreLockAllGoods",SCP.CastleStore.LockAllGoods)
API.RegisterScriptCommand("Cmd_CastleStoreRefuseAllGoods",SCP.CastleStore.RefuseAllGoods)
API.RegisterScriptCommand("Cmd_CastleStoreToggleGoodState",SCP.CastleStore.ToggleGoodState)
API.RegisterScriptCommand("Cmd_CastleStoreObjectPayStep1",SCP.CastleStore.ObjectPayStep1)
API.RegisterScriptCommand("Cmd_CastleStoreObjectPayStep3",SCP.CastleStore.ObjectPayStep3)for QDnlt=1,8 do self.BackupGoods[QDnlt]={}end
self:OverwriteGameFunctions()end
function ModuleCastleStore.Global.CastleStore:New(LmcA2auZ)
assert(self==
ModuleCastleStore.Global.CastleStore,"Can not be used from instance!")local Q=table.copy(self)Q.PlayerID=LmcA2auZ
QSB.CastleStoreObjects[LmcA2auZ]=Q
if not self.UpdateCastleStoreInitalized then self.UpdateCastleStoreInitalized=true
API.StartHiResJob(function()
ModuleCastleStore.Global.CastleStore:UpdateStores()end)end
Logic.ExecuteInLuaLocalState([[
        QSB.CastleStore:CreateStore(]]..Q.PlayerID..[[);
    ]])return Q end
function ModuleCastleStore.Global.CastleStore:GetInstance(ZA)
assert(self==
ModuleCastleStore.Global.CastleStore,"Can not be used from instance!")return QSB.CastleStoreObjects[ZA]end
function ModuleCastleStore.Global.CastleStore:GetGoodAmountWithCastleStore(_IQQ,XpkjA,pVRj)
assert(
self==ModuleCastleStore.Global.CastleStore,"Can not be used from instance!")local fuZ3z86=self:GetInstance(XpkjA)
local er=GetPlayerGoodsInSettlement(_IQQ,XpkjA,pVRj)
if
fuZ3z86 ~=nil and _IQQ~=Goods.G_Gold and
Logic.GetGoodCategoryForGoodType(_IQQ)==GoodCategories.GC_Resource then er=er+fuZ3z86:GetAmount(_IQQ)end;return er end
function ModuleCastleStore.Global.CastleStore:Dispose()
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLuaLocalState([[
        QSB.CastleStore:DeleteStore(]]..self.PlayerID..[[);
    ]])QSB.CastleStoreObjects[self.PlayerID]=nil end
function ModuleCastleStore.Global.CastleStore:SetUperLimitInStorehouseForGoodType(DFb100j,XL_)
assert(
self~=ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")self.Goods[DFb100j][4]=XL_
Logic.ExecuteInLuaLocalState(
[[
        QSB.CastleStorePlayerData[]]..self.PlayerID..
[[].Goods[]]..DFb100j..[[][4] = ]]..XL_..[[
    ]])return self end
function ModuleCastleStore.Global.CastleStore:SetStorageLimit(WYdR)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")self.CapacityBase=math.floor(WYdR/2)
Logic.ExecuteInLuaLocalState(
[[
        QSB.CastleStorePlayerData[]]..self.PlayerID..
[[].CapacityBase = ]]..math.floor(WYdR/2)..[[
    ]])return self end
function ModuleCastleStore.Global.CastleStore:GetAmount(QKKks_zt)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")
if self.Goods[QKKks_zt]then return self.Goods[QKKks_zt][1]end;return 0 end
function ModuleCastleStore.Global.CastleStore:GetTotalAmount()
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")local Are7xU=0
for yxjl,ZG in pairs(self.Goods)do Are7xU=Are7xU+ZG[1]end;return Are7xU end
function ModuleCastleStore.Global.CastleStore:GetLimit()
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")local Vu0cCAf=0;local q=Logic.GetHeadquarters(self.PlayerID)if q~=0 then
Vu0cCAf=Logic.GetUpgradeLevel(q)end;local kP7O5=self.CapacityBase;for lqT=1,(Vu0cCAf+1),1 do
kP7O5=kP7O5*2 end;return kP7O5 end
function ModuleCastleStore.Global.CastleStore:IsGoodAccepted(mP3mlD)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")return self.Goods[mP3mlD][2]==true end
function ModuleCastleStore.Global.CastleStore:SetGoodAccepted(PrPyxMK,tczrIB)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")self.Goods[PrPyxMK][2]=tczrIB==true
Logic.ExecuteInLuaLocalState(
[[
        QSB.CastleStore:SetAccepted(
            ]]..
self.PlayerID..[[, ]]..PrPyxMK..
[[, ]]..tostring(tczrIB==true)..[[
        )
    ]])return self end
function ModuleCastleStore.Global.CastleStore:IsGoodLocked(a)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")return self.Goods[a][3]==true end
function ModuleCastleStore.Global.CastleStore:SetGoodLocked(wqU76o,LB1Z)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")self.Goods[wqU76o][3]=LB1Z==true
Logic.ExecuteInLuaLocalState(
[[
        QSB.CastleStore:SetLocked(
            ]]..
self.PlayerID..[[, ]]..wqU76o..
[[, ]]..tostring(LB1Z==true)..[[
        )
    ]])return self end
function ModuleCastleStore.Global.CastleStore:ActivateTemporaryMode()
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLuaLocalState([[
        QSB.CastleStore.OnStorehouseTabClicked(QSB.CastleStore, ]]..
self.PlayerID..[[)
    ]])return self end
function ModuleCastleStore.Global.CastleStore:ActivateStockMode()
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLuaLocalState([[
        QSB.CastleStore.OnCityTabClicked(QSB.CastleStore, ]]..self.PlayerID..[[)
    ]])return self end
function ModuleCastleStore.Global.CastleStore:ActivateOutsourceMode()
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLuaLocalState([[
        QSB.CastleStore.OnMultiTabClicked(QSB.CastleStore, ]]..self.PlayerID..[[)
    ]])return self end
function ModuleCastleStore.Global.CastleStore:Store(N9L,hDc_M)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")
if self:IsGoodAccepted(N9L)then
if self:GetLimit()>=
self:GetTotalAmount()+hDc_M then
local qW0lRiD1=Logic.GetUpgradeLevel(Logic.GetHeadquarters(self.PlayerID))
if GetPlayerResources(N9L,self.PlayerID)> (self.Goods[N9L][4]*
(qW0lRiD1+1))then AddGood(N9L,
hDc_M* (-1),self.PlayerID)self.Goods[N9L][1]=
self.Goods[N9L][1]+hDc_M
Logic.ExecuteInLuaLocalState(
[[
                    QSB.CastleStore:SetAmount(
                        ]]..self.PlayerID..
[[, ]]..N9L..[[, ]]..
self.Goods[N9L][1]..[[
                    )
                ]])end end end;return self end
function ModuleCastleStore.Global.CastleStore:Outsource(iD1IUx,JLCOx_ak)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")
local hPQ=Logic.GetUpgradeLevel(Logic.GetHeadquarters(self.PlayerID))
if
Logic.GetPlayerUnreservedStorehouseSpace(self.PlayerID)>=JLCOx_ak then
if self:GetAmount(iD1IUx)>=JLCOx_ak then
AddGood(iD1IUx,JLCOx_ak,self.PlayerID)
self.Goods[iD1IUx][1]=self.Goods[iD1IUx][1]-JLCOx_ak
Logic.ExecuteInLuaLocalState([[
                QSB.CastleStore:SetAmount(
                    ]]..self.PlayerID..
[[, ]]..iD1IUx..
[[, ]]..
self.Goods[iD1IUx][1]..[[
                )
            ]])end end;return self end
function ModuleCastleStore.Global.CastleStore:Add(R1FIoQI,NsoTwDs)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")
if self.Goods[R1FIoQI]then
for HGli=1,NsoTwDs,1 do if
self:GetLimit()>self:GetTotalAmount()then
self.Goods[R1FIoQI][1]=self.Goods[R1FIoQI][1]+1 end end
Logic.ExecuteInLuaLocalState([[
            QSB.CastleStore:SetAmount(
                ]]..
self.PlayerID..[[, ]]..
R1FIoQI..[[, ]]..
self.Goods[R1FIoQI][1]..[[
            )
        ]])end;return self end
function ModuleCastleStore.Global.CastleStore:Remove(iy,m6SCS0)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")
if self.Goods[iy]then
if self:GetAmount(iy)>0 then
local NUhYw6R4=(
m6SCS0 <=self:GetAmount(iy)and m6SCS0)or self:GetAmount(iy)
self.Goods[iy][1]=self.Goods[iy][1]-NUhYw6R4
Logic.ExecuteInLuaLocalState([[
                QSB.CastleStore:SetAmount(
                    ]]..
self.PlayerID..[[, ]]..iy..
[[, ]]..
self.Goods[iy][1]..[[
                )
            ]])end end;return self end
function ModuleCastleStore.Global.CastleStore:EnableStore(Hv)
assert(self~=
ModuleCastleStore.Global.CastleStore,"Can not be used in static context!")self.UpdateCastleStore=Hv==true end
function ModuleCastleStore.Global.CastleStore:UpdateStores()
for Ch,urkh in
pairs(QSB.CastleStoreObjects)do
if urkh~=nil and urkh.UpdateCastleStore and
Logic.GetStoreHouse(Ch)~=0 then
local zhzpBSx=Logic.GetUpgradeLevel(Logic.GetHeadquarters(urkh.PlayerID))
for rHSjalVy,TjhsnP in pairs(urkh.Goods)do
if TjhsnP~=nil then
if TjhsnP[2]==true then
local t5jzEd9=GetPlayerResources(rHSjalVy,urkh.PlayerID)local JZAU2=urkh:GetAmount(rHSjalVy)
if
t5jzEd9 < (
urkh.Goods[rHSjalVy][4]* (zhzpBSx+1))then
if TjhsnP[3]==false then urkh:Outsource(rHSjalVy,1)end else urkh:Store(rHSjalVy,1)end else urkh:Outsource(rHSjalVy,1)end end end end end end
function ModuleCastleStore.Global:OverwriteGameFunctions()
QuestTemplate.IsObjectiveCompleted_Orig_QSB_CastleStore=QuestTemplate.IsObjectiveCompleted
QuestTemplate.IsObjectiveCompleted=function(zPXTTg,seMLr)local qX=seMLr.Type;local h_8=seMLr.Data;if
seMLr.Completed~=nil then return seMLr.Completed end
if qX==Objective.Produce then
local xL7OTb=GetPlayerGoodsInSettlement(h_8[1],zPXTTg.ReceivingPlayer,true)
local w8T3f=QSB.CastleStore:GetInstance(zPXTTg.ReceivingPlayer)if w8T3f and
Logic.GetGoodCategoryForGoodType(h_8[1])==GoodCategories.GC_Resource then
xL7OTb=xL7OTb+w8T3f:GetAmount(h_8[1])end
if(not h_8[3]and
xL7OTb>=h_8[2])or
(h_8[3]and xL7OTb<h_8[2])then seMLr.Completed=true end else
return QuestTemplate.IsObjectiveCompleted_Orig_QSB_CastleStore(zPXTTg,seMLr)end end
QuestTemplate.SendGoods=function(K)
for qL=1,K.Objectives[0]do
if
K.Objectives[qL].Type==Objective.Deliver then
if K.Objectives[qL].Data[3]==nil then
local vfIyB=K.Objectives[qL].Data[1]local quNsijN=K.Objectives[qL].Data[2]
local QUh2tc=QSB.CastleStore:GetGoodAmountWithCastleStore(vfIyB,K.ReceivingPlayer,true)
if QUh2tc>=quNsijN then local qboV=K.ReceivingPlayer
local nSBOx7=
K.Objectives[qL].Data[6]and K.Objectives[qL].Data[6]or K.SendingPlayer;local u={}u.Good=vfIyB;u.Amount=quNsijN;u.PlayerID=nSBOx7;u.ID=nil
K.Objectives[qL].Data[5]=u;K.Objectives[qL].Data[3]=1
QuestMerchants[#QuestMerchants+1]=u
if vfIyB==Goods.G_Gold then local Ki1=Logic.GetHeadquarters(qboV)if Ki1 ==0 then
Ki1=Logic.GetStoreHouse(qboV)end
K.Objectives[qL].Data[3]=Logic.CreateEntityAtBuilding(Entities.U_GoldCart,Ki1,0,nSBOx7)
Logic.HireMerchant(K.Objectives[qL].Data[3],nSBOx7,vfIyB,quNsijN,K.ReceivingPlayer)Logic.RemoveGoodFromStock(Ki1,vfIyB,quNsijN)if
MapCallback_DeliverCartSpawned then
MapCallback_DeliverCartSpawned(K,K.Objectives[qL].Data[3],vfIyB)end elseif vfIyB==Goods.G_Water then
local zz1QI=Logic.GetMarketplace(qboV)
K.Objectives[qL].Data[3]=Logic.CreateEntityAtBuilding(Entities.U_Marketer,zz1QI,0,nSBOx7)
Logic.HireMerchant(K.Objectives[qL].Data[3],nSBOx7,vfIyB,quNsijN,K.ReceivingPlayer)Logic.RemoveGoodFromStock(zz1QI,vfIyB,quNsijN)if
MapCallback_DeliverCartSpawned then
MapCallback_DeliverCartSpawned(K,K.Objectives[qL].Data[3],vfIyB)end else
if
Logic.GetGoodCategoryForGoodType(vfIyB)==GoodCategories.GC_Resource then
local kFTAh=Entities.U_ResourceMerchant
if

vfIyB==Goods.G_MusicalInstrument or vfIyB==Goods.G_Olibanum or vfIyB==Goods.G_Gems or
vfIyB==Goods.G_Dye or vfIyB==Goods.G_Salt then kFTAh=Entities.U_Marketer end;local LBf=Logic.GetStoreHouse(nSBOx7)
local dijn4Ph=Logic.GetNumberOfGoodTypesOnOutStock(LBf)
if dijn4Ph~=nil then
for SUn=0,dijn4Ph-1 do
local Ib4=Logic.GetGoodTypeOnOutStockByIndex(LBf,SUn)local fjV1G2=Logic.GetAmountOnOutStockByIndex(LBf,SUn)if fjV1G2 >=
quNsijN then
Logic.RemoveGoodFromStock(LBf,Ib4,quNsijN,false)end end end;local CO1=Logic.GetStoreHouse(qboV)
local RlZo=GetPlayerResources(vfIyB,qboV)
if RlZo<quNsijN then local Do=quNsijN-RlZo
AddGood(vfIyB,RlZo* (-1),qboV)
local _=QSB.CastleStore:GetInstance(K.ReceivingPlayer)if _ then _:Remove(vfIyB,Do)end else
AddGood(vfIyB,quNsijN* (-1),qboV)end
K.Objectives[qL].Data[3]=Logic.CreateEntityAtBuilding(kFTAh,CO1,0,nSBOx7)
Logic.HireMerchant(K.Objectives[qL].Data[3],nSBOx7,vfIyB,quNsijN,K.ReceivingPlayer)else
Logic.StartTradeGoodGathering(qboV,nSBOx7,vfIyB,quNsijN,0)end end end end end end end end
function ModuleCastleStore.Global:InteractiveObjectPayStep1(TqYJ4,DI)if DI==nil then return end;local b=DI;if
IO_SlaveToMaster[b]then b=IO_SlaveToMaster[b]end
local E=QSB.CastleStore:GetInstance(TqYJ4)E:EnableStore(false)self.BackupGoods[TqYJ4]={}
for KMw7_i1s,CQi in
pairs(E.Goods)do local nHlJ=GetPlayerResources(KMw7_i1s,TqYJ4)
self.BackupGoods[TqYJ4][KMw7_i1s]=nHlJ;AddGood(KMw7_i1s,(-1)*nHlJ,TqYJ4)end
if IO[b].m_Costs and IO[b].m_Costs[1]then
local lw4Q7kbl=IO[b].m_Costs[1]
if self.BackupGoods[TqYJ4][lw4Q7kbl]then
AddGood(lw4Q7kbl,IO[b].m_Costs[2],TqYJ4)
self.BackupGoods[TqYJ4][lw4Q7kbl]=
self.BackupGoods[TqYJ4][lw4Q7kbl]-IO[b].m_Costs[2]
if self.BackupGoods[TqYJ4][lw4Q7kbl]<0 then
QSB.CastleStore:GetInstance(TqYJ4):Remove(lw4Q7kbl,(
-1)*self.BackupGoods[lw4Q7kbl])self.BackupGoods[TqYJ4][lw4Q7kbl]=0 end end end
if IO[b].m_Costs and IO[b].m_Costs[3]then
local IN=IO[b].m_Costs[3]
if self.BackupGoods[TqYJ4][IN]then
AddGood(IN,IO[b].m_Costs[4],TqYJ4)
self.BackupGoods[TqYJ4][IN]=
self.BackupGoods[TqYJ4][IN]-IO[b].m_Costs[4]
if self.BackupGoods[TqYJ4][IN]<0 then
QSB.CastleStore:GetInstance(TqYJ4):Remove(IN,(
-1)*self.BackupGoods[TqYJ4][IN])self.BackupGoods[TqYJ4][IN]=0 end end end
Logic.ExecuteInLuaLocalState(string.format("ModuleCastleStore.Local:InteractiveObjectPayStep2(%d, '%s')",TqYJ4,DI))end
function ModuleCastleStore.Global:InteractiveObjectPayStep3(QYf1,RfsnisO)if RfsnisO==nil then return end
local lvW2ga=QSB.CastleStore:GetInstance(QYf1)lvW2ga:EnableStore(true)
for T7RKP,_L6Bs in pairs(lvW2ga.Goods)do
local SH=self.BackupGoods[QYf1][T7RKP]AddGood(T7RKP,SH,QYf1)end;self.BackupGoods[QYf1]={}end
function ModuleCastleStore.Local:OnGameStart()
IO=Logic.CreateReferenceToTableInGlobaLuaState("IO")QSB.CastleStore=self.CastleStore
self:OverwriteGameFunctions()self:OverwriteGetStringTableText()
self:OverwriteInteractiveObject()end
function ModuleCastleStore.Local:OnEvent(wU4wYbA9,fFeQcIM,JEHSHPh3)if
wU4wYbA9 ==QSB.ScriptEvents.SaveGameLoaded then self:OverwriteGetStringTableText()
self.CastleStore:ActivateHotkeys()end end
function ModuleCastleStore.Local.CastleStore:CreateStore(bb)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
local o5e6fP={StoreMode=1,CapacityBase=75,Goods={[Goods.G_Wood]={0,true,false,35},[Goods.G_Stone]={0,true,false,35},[Goods.G_Iron]={0,true,false,35},[Goods.G_Carcass]={0,true,false,15},[Goods.G_Grain]={0,true,false,15},[Goods.G_RawFish]={0,true,false,15},[Goods.G_Milk]={0,true,false,15},[Goods.G_Herb]={0,true,false,15},[Goods.G_Wool]={0,true,false,15},[Goods.G_Honeycomb]={0,true,false,15}}}QSB.CastleStorePlayerData[bb]=o5e6fP
self:ActivateHotkeys()self:DescribeHotkeys()end
function ModuleCastleStore.Local.CastleStore:DeleteStore(iq7ol)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")QSB.CastleStorePlayerData[iq7ol]=nil end
function ModuleCastleStore.Local.CastleStore:GetAmount(eMV,WDTNkTD)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
if not self:HasCastleStore(eMV)or not
QSB.CastleStorePlayerData[eMV].Goods[WDTNkTD]then return 0 end;return
QSB.CastleStorePlayerData[eMV].Goods[WDTNkTD][1]end
function ModuleCastleStore.Local.CastleStore:GetGoodAmountWithCastleStore(Oejsws,CkD73N0,PlwhaRKJ)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
local Caz4NM4Z=GetPlayerGoodsInSettlement(Oejsws,CkD73N0,PlwhaRKJ)
if self:HasCastleStore(CkD73N0)then
if
Oejsws~=Goods.G_Gold and
Logic.GetGoodCategoryForGoodType(Oejsws)==GoodCategories.GC_Resource then
Caz4NM4Z=Caz4NM4Z+self:GetAmount(CkD73N0,Oejsws)end end;return Caz4NM4Z end
function ModuleCastleStore.Local.CastleStore:GetTotalAmount(XVxxx)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(XVxxx)then return 0 end
local hD=0;for G5BuU5,AfwsY in
pairs(QSB.CastleStorePlayerData[XVxxx].Goods)do hD=hD+AfwsY[1]end;return hD end
function ModuleCastleStore.Local.CastleStore:SetAmount(T,WZs,ITdz)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
if not self:HasCastleStore(T)or not
QSB.CastleStorePlayerData[T].Goods[WZs]then return end
QSB.CastleStorePlayerData[T].Goods[WZs][1]=ITdz;return self end
function ModuleCastleStore.Local.CastleStore:IsAccepted(AjfoUo,Er9zidsB)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(AjfoUo)or not
QSB.CastleStorePlayerData[AjfoUo].Goods[Er9zidsB]then
return false end;return
QSB.CastleStorePlayerData[AjfoUo].Goods[Er9zidsB][2]==true end
function ModuleCastleStore.Local.CastleStore:SetAccepted(X,dR,JFXtQwy)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
if self:HasCastleStore(X)and
QSB.CastleStorePlayerData[X].Goods[dR]then QSB.CastleStorePlayerData[X].Goods[dR][2]=
JFXtQwy==true end;return self end
function ModuleCastleStore.Local.CastleStore:IsLocked(uMV17h0,E2NZK)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(uMV17h0)or not
QSB.CastleStorePlayerData[uMV17h0].Goods[E2NZK]then
return false end;return
QSB.CastleStorePlayerData[uMV17h0].Goods[E2NZK][3]==true end
function ModuleCastleStore.Local.CastleStore:SetLocked(WNWWe,zMzjn3lk,Trkkpmd)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
if self:HasCastleStore(WNWWe)and
QSB.CastleStorePlayerData[WNWWe].Goods[zMzjn3lk]then QSB.CastleStorePlayerData[WNWWe].Goods[zMzjn3lk][3]=
Trkkpmd==true end;return self end
function ModuleCastleStore.Local.CastleStore:HasCastleStore(L)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")return QSB.CastleStorePlayerData[L]~=nil end
function ModuleCastleStore.Local.CastleStore:GetStore(GGv)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")return QSB.CastleStorePlayerData[GGv]end
function ModuleCastleStore.Local.CastleStore:GetLimit(ZIzh4Si)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")local c8D4n81=0;local cSjJHx=Logic.GetHeadquarters(ZIzh4Si)if cSjJHx~=0 then
c8D4n81=Logic.GetUpgradeLevel(cSjJHx)end
local fa=QSB.CastleStorePlayerData[ZIzh4Si].CapacityBase;for M=1,(c8D4n81+1),1 do fa=fa*2 end;return fa end
function ModuleCastleStore.Local.CastleStore:OnStorehouseTabClicked(dIZlrvD)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
QSB.CastleStorePlayerData[dIZlrvD].StoreMode=1;self:UpdateBehaviorTabs(dIZlrvD)
API.BroadcastScriptCommand(QSB.ScriptCommands.CastleStoreAcceptAllGoods,dIZlrvD)end
function ModuleCastleStore.Local.CastleStore:OnCityTabClicked(jQgsATKd)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
QSB.CastleStorePlayerData[jQgsATKd].StoreMode=2;self:UpdateBehaviorTabs(jQgsATKd)
API.BroadcastScriptCommand(QSB.ScriptCommands.CastleStoreLockAllGoods,jQgsATKd)end
function ModuleCastleStore.Local.CastleStore:OnMultiTabClicked(aBbGg)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
QSB.CastleStorePlayerData[aBbGg].StoreMode=3;self:UpdateBehaviorTabs(aBbGg)
API.BroadcastScriptCommand(QSB.ScriptCommands.CastleStoreRefuseAllGoods,aBbGg)end
function ModuleCastleStore.Local.CastleStore:GoodClicked(D9,G)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")if self:HasCastleStore(D9)then
API.BroadcastScriptCommand(QSB.ScriptCommands.CastleStoreToggleGoodState,D9,G)end end
function ModuleCastleStore.Local.CastleStore:DestroyGoodsClicked(gE)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")if self:HasCastleStore(gE)then
QSB.CastleStore.ToggleStore()end end
function ModuleCastleStore.Local.CastleStore:SelectionChanged(QgC)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
if self:HasCastleStore(QgC)then local CYoa=GUI.GetSelectedEntity()if
Logic.GetHeadquarters(QgC)==CYoa then self:ShowCastleMenu()else
self:RestoreStorehouseMenu()end end end
function ModuleCastleStore.Local.CastleStore:UpdateBehaviorTabs(K3ipRr)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")
if not QSB.CastleStore:HasCastleStore(K3ipRr)then return end
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons",0)
if
QSB.CastleStorePlayerData[K3ipRr].StoreMode==1 then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/StorehouseTabButtonUp",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/CityTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/Tab03Down",1)elseif
QSB.CastleStorePlayerData[K3ipRr].StoreMode==2 then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/StorehouseTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/CityTabButtonUp",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/Tab03Down",1)else
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/StorehouseTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/CityTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/Tab03Up",1)end end
function ModuleCastleStore.Local.CastleStore:UpdateGoodsDisplay(F2tY)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(F2tY)then return end
local rb21L2="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InStorehouse/Goods"local o_v255=""if
self:GetLimit(F2tY)==self:GetTotalAmount(F2tY)then o_v255="{@color:255,32,32,255}"end
for wUVm,VQ in
pairs(QSB.CastleStorePlayerData[F2tY].Goods)do local oTYNsnP=Logic.GetGoodTypeName(wUVm)local I=rb21L2 ..
"/"..oTYNsnP.."/Amount"
local L=rb21L2 .."/"..oTYNsnP.."/Button"local mR5gwW=rb21L2 .."/"..oTYNsnP.."/BG"XGUIEng.SetText(I,
"{center}"..o_v255 ..VQ[1])
XGUIEng.DisableButton(L,0)
if
self:IsAccepted(F2tY,wUVm)and self:IsLocked(F2tY,wUVm)then XGUIEng.SetMaterialColor(L,0,230,180,120,255)
XGUIEng.SetMaterialColor(L,1,230,180,120,255)XGUIEng.SetMaterialColor(L,7,230,180,120,255)elseif
not
self:IsAccepted(F2tY,wUVm)and not self:IsLocked(F2tY,wUVm)then XGUIEng.SetMaterialColor(L,0,190,90,90,255)
XGUIEng.SetMaterialColor(L,1,190,90,90,255)XGUIEng.SetMaterialColor(L,7,190,90,90,255)else
XGUIEng.SetMaterialColor(L,0,255,255,255,255)XGUIEng.SetMaterialColor(L,1,255,255,255,255)
XGUIEng.SetMaterialColor(L,7,255,255,255,255)end end end
function ModuleCastleStore.Local.CastleStore:UpdateStorageLimit(DfbW)
assert(self==
ModuleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(DfbW)then return end
local sh=XGUIEng.GetCurrentWidgetID()local rrFLbCtj=GUI.GetPlayerID()
local YcPea0vg=QSB.CastleStore:GetTotalAmount(rrFLbCtj)local usLpLoaH=QSB.CastleStore:GetLimit(rrFLbCtj)
local e7dv=XGUIEng.GetStringTableText("UI_Texts/StorageLimit_colon")
local inx0="{center}"..e7dv.." "..YcPea0vg.."/"..usLpLoaH;XGUIEng.SetText(sh,inx0)end
function ModuleCastleStore.Local.CastleStore:ToggleStore()
assert(self==nil,"This function is procedural!")
if QSB.CastleStore:HasCastleStore(GUI.GetPlayerID())then
if
Logic.GetHeadquarters(GUI.GetPlayerID())==GUI.GetSelectedEntity()then
if
XGUIEng.IsWidgetShown("/InGame/Root/Normal/AlignBottomRight/Selection/Castle")==1 then
QSB.CastleStore.ShowCastleStoreMenu(QSB.CastleStore)else
QSB.CastleStore.ShowCastleMenu(QSB.CastleStore)end end end end
function ModuleCastleStore.Local.CastleStore:RestoreStorehouseMenu()
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InCity/Goods",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InCity",0)
SetIcon("/InGame/Root/Normal/AlignBottomRight/DialogButtons/PlayerButtons/DestroyGoods",{16,8})
local A5k5yt="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/"
SetIcon(A5k5yt.."StorehouseTabButtonUp/up/B_StoreHouse",{3,13})
SetIcon(A5k5yt.."StorehouseTabButtonDown/down/B_StoreHouse",{3,13})
SetIcon(A5k5yt.."CityTabButtonUp/up/CityBuildingsNumber",{8,1})
SetIcon(A5k5yt.."TabButtons/CityTabButtonDown/down/CityBuildingsNumber",{8,1})
SetIcon(A5k5yt.."TabButtons/Tab03Up/up/B_Castle_ME",{3,14})
SetIcon(A5k5yt.."Tab03Down/down/B_Castle_ME",{3,14})
for B7SHDx7h,EEpoeR in
ipairs{"G_Carcass","G_Grain","G_Milk","G_RawFish","G_Iron","G_Wood","G_Stone","G_Honeycomb","G_Herb","G_Wool"}do
local A5k5yt="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InStorehouse/Goods/"
XGUIEng.SetMaterialColor(A5k5yt..EEpoeR.."/Button",0,255,255,255,255)
XGUIEng.SetMaterialColor(A5k5yt..EEpoeR.."/Button",1,255,255,255,255)
XGUIEng.SetMaterialColor(A5k5yt..EEpoeR.."/Button",7,255,255,255,255)end end
function ModuleCastleStore.Local.CastleStore:ShowCastleMenu()
local _k="/InGame/Root/Normal/AlignBottomRight/"
XGUIEng.ShowWidget(_k.."Selection/BGBig",0)
XGUIEng.ShowWidget(_k.."Selection/Storehouse",0)
XGUIEng.ShowWidget(_k.."Selection/BGSmall",1)
XGUIEng.ShowWidget(_k.."Selection/Castle",1)
if g_HideSoldierPayment~=nil then
XGUIEng.ShowWidget(_k.."Selection/Castle/Treasury/Payment",0)
XGUIEng.ShowWidget(_k.."Selection/Castle/LimitSoldiers",0)end;GUI_BuildingInfo.PaymentLevelSliderUpdate()
GUI_BuildingInfo.TaxationLevelSliderUpdate()GUI_Trade.StorehouseSelected()
local Ef,KfM=XGUIEng.GetWidgetLocalPosition(_k..
"Selection/AnchorInfoForSmall")
XGUIEng.SetWidgetLocalPosition(_k.."Selection/Info",Ef,KfM)
XGUIEng.ShowWidget(_k.."DialogButtons/PlayerButtons",1)
XGUIEng.ShowWidget(_k.."DialogButtons/PlayerButtons/DestroyGoods",1)
XGUIEng.DisableButton(_k.."DialogButtons/PlayerButtons/DestroyGoods",0)
SetIcon(_k.."DialogButtons/PlayerButtons/DestroyGoods",{10,9})end
function ModuleCastleStore.Local.CastleStore:ShowCastleStoreMenu()
local Vd="/InGame/Root/Normal/AlignBottomRight/"
XGUIEng.ShowWidget(Vd.."Selection/Selection/BGSmall",0)
XGUIEng.ShowWidget(Vd.."Selection/Castle",0)
XGUIEng.ShowWidget(Vd.."Selection/BGSmall",0)
XGUIEng.ShowWidget(Vd.."Selection/BGBig",1)
XGUIEng.ShowWidget(Vd.."Selection/Storehouse",1)
XGUIEng.ShowWidget(Vd.."Selection/Storehouse/AmountContainer",0)
XGUIEng.ShowAllSubWidgets(Vd.."Selection/Storehouse/TabButtons",1)
XGUIEng.ShowWidget(Vd.."Selection/Storehouse/TabButtons",1)GUI_Trade.StorehouseSelected()
local Oynw,QBO=XGUIEng.GetWidgetLocalPosition(Vd..
"Selection/AnchorInfoForBig")
XGUIEng.SetWidgetLocalPosition(Vd.."Selection/Info",Oynw,QBO)
XGUIEng.ShowWidget(Vd.."DialogButtons/PlayerButtons",1)
XGUIEng.ShowWidget(Vd.."DialogButtons/PlayerButtons/DestroyGoods",1)
XGUIEng.ShowWidget(Vd.."Selection/Storehouse/InStorehouse",1)
XGUIEng.ShowWidget(Vd.."Selection/Storehouse/InMulti",0)
XGUIEng.ShowWidget(Vd.."Selection/Storehouse/InCity",1)
XGUIEng.ShowAllSubWidgets(Vd.."Selection/Storehouse/InCity/Goods",0)
XGUIEng.ShowWidget(Vd.."Selection/Storehouse/InCity/Goods/G_Beer",1)
XGUIEng.DisableButton(Vd.."DialogButtons/PlayerButtons/DestroyGoods",0)local s4ggux=Vd.."DialogButtons/PlayerButtons/"
local hrVI4meU=Vd.."Selection/Storehouse/TabButtons/"SetIcon(s4ggux.."DestroyGoods",{3,14})
SetIcon(hrVI4meU..
"StorehouseTabButtonUp/up/B_StoreHouse",{10,9})
SetIcon(hrVI4meU.."StorehouseTabButtonDown/down/B_StoreHouse",{10,9})
SetIcon(hrVI4meU.."CityTabButtonUp/up/CityBuildingsNumber",{15,6})
SetIcon(hrVI4meU.."CityTabButtonDown/down/CityBuildingsNumber",{15,6})
SetIcon(hrVI4meU.."Tab03Up/up/B_Castle_ME",{7,1})
SetIcon(hrVI4meU.."Tab03Down/down/B_Castle_ME",{7,1})self:UpdateBehaviorTabs(GUI.GetPlayerID())end
function ModuleCastleStore.Local:OverwriteInteractiveObject()
GUI_Interaction.InteractiveObjectClicked_Orig_CastleStore=GUI_Interaction.InteractiveObjectClicked
GUI_Interaction.InteractiveObjectClicked=function()
local xEq6TAF=tonumber(XGUIEng.GetWidgetNameByID(XGUIEng.GetCurrentWidgetID()))
local UIjls=g_Interaction.ActiveObjectsOnScreen[xEq6TAF]local jdLnB0vD=GUI.GetPlayerID()if not UIjls then return end;if not
QSB.CastleStore:HasCastleStore(jdLnB0vD)then
GUI_Interaction.InteractiveObjectClicked_Orig_CastleStore()return end
local PSlD=Logic.GetEntityName(UIjls)
if IO_SlaveToMaster[PSlD]then PSlD=IO_SlaveToMaster[PSlD]end;local nN=Logic.GetEntityName(GetID(PSlD))
local J={Logic.InteractiveObjectGetEffectiveCosts(nN,jdLnB0vD)}local A,g3Qeqnr=AreCostsAffordable(J,false)
if IO[PSlD]then if not
self:OnObjectClicked_CanPlayerPayCosts(IO[PSlD])then return end end;if not A then Message(g3Qeqnr)return end;if IO[PSlD]and
not IO[PSlD].m_Fullfilled then
Message(XGUIEng.GetStringTableText("UI_ButtonDisabled/PromoteKnight"))return end;if

not IO[PSlD]or(IO[PSlD]and not IO[PSlD].m_Costs)then
GUI_Interaction.InteractiveObjectClicked_Orig_CastleStore()return end;if not
GUI_Interaction.InteractionClickOverride or
not GUI_Interaction.InteractionClickOverride(nN)then
Sound.FXPlay2DSound("ui\\menu_click")end
if
not
GUI_Interaction.InteractionSpeechFeedbackOverride or not
GUI_Interaction.InteractionSpeechFeedbackOverride(nN)then
GUI_FeedbackSpeech.Add("SpeechOnly_CartsSent",g_FeedbackSpeech.Categories.CartsUnderway,nil,nil)end;J=IO[PSlD].m_Costs
if
not Mission_Callback_OverrideObjectInteraction or not
Mission_Callback_OverrideObjectInteraction(nN,jdLnB0vD,J)then local PSlD=Logic.GetEntityName(nN)local A=true;if J and J[1]then A=A and
GetPlayerResources(J[1],jdLnB0vD)>=J[2]
if J[3]then A=A and
GetPlayerResources(J[3],jdLnB0vD)>=J[4]end end;if A then
GUI_Interaction.InteractiveObjectClicked_Orig_CastleStore()return end
API.BroadcastScriptCommand(QSB.ScriptCommands.CastleStoreObjectPayStep1,jdLnB0vD,PSlD)end
if not Framework.IsNetworkGame()then local qHpY64={}
Logic.GetKnights(jdLnB0vD,qHpY64)local z=API.GetClosestToTarget(UIjls,qHpY64)
API.SendScriptEventToGlobal(QSB.ScriptEvents.ObjectClicked,UIjls,z,jdLnB0vD)
API.SendScriptEvent(QSB.ScriptEvents.ObjectClicked,UIjls,z,jdLnB0vD)end end end
function ModuleCastleStore.Local:OnObjectClicked_CanPlayerPayCosts(qccJ5b)
local ARuba=GUI.GetPlayerID()local Wo53nZ=true
if not qccJ5b.m_Costs or
type(qccJ5b.m_Costs[1])~="number"then return Wo53nZ end
if qccJ5b.m_Costs[1]then
local XRfQ=GetPlayerResources(qccJ5b.m_Costs[1],GUI.GetPlayerID())
if
not QSB.CastleStore:IsLocked(ARuba,qccJ5b.m_Costs[1])then
XRfQ=QSB.CastleStore:GetGoodAmountWithCastleStore(qccJ5b.m_Costs[1],GUI.GetPlayerID(),true)end
Wo53nZ=Wo53nZ and(XRfQ>=qccJ5b.m_Costs[2])end
if qccJ5b.m_Costs[3]then
local gFPRdEC=GetPlayerResources(qccJ5b.m_Costs[3],GUI.GetPlayerID())
if
not QSB.CastleStore:IsLocked(ARuba,qccJ5b.m_Costs[3])then
gFPRdEC=QSB.CastleStore:GetGoodAmountWithCastleStore(qccJ5b.m_Costs[3],GUI.GetPlayerID(),true)end
Wo53nZ=Wo53nZ and(gFPRdEC>=qccJ5b.m_Costs[4])end
if not Wo53nZ then
local lw9gLt3=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_NotEnough_Resources")Message(lw9gLt3)end;return Wo53nZ end
function ModuleCastleStore.Local.CastleStore:HotkeyStoreGoods()
local T=GUI.GetPlayerID()
if
ModuleCastleStore.Local.CastleStore:HasCastleStore(T)==false then return end
ModuleCastleStore.Local.CastleStore:OnStorehouseTabClicked(T)end
function ModuleCastleStore.Local.CastleStore:HotkeyLockGoods()
local I5=GUI.GetPlayerID()
if
ModuleCastleStore.Local.CastleStore:HasCastleStore(I5)==false then return end
ModuleCastleStore.Local.CastleStore:OnCityTabClicked(I5)end
function ModuleCastleStore.Local.CastleStore:HotkeyEmptyStore()
local JmE=GUI.GetPlayerID()
if
ModuleCastleStore.Local.CastleStore:HasCastleStore(JmE)==false then return end
ModuleCastleStore.Local.CastleStore:OnMultiTabClicked(JmE)end
function ModuleCastleStore.Local.CastleStore:ActivateHotkeys()
Input.KeyBindDown(
Keys.ModifierShift+Keys.B,"ModuleCastleStore.Local.CastleStore:HotkeyStoreGoods()",2,false)
Input.KeyBindDown(Keys.ModifierShift+Keys.N,"ModuleCastleStore.Local.CastleStore:HotkeyLockGoods()",2,false)
Input.KeyBindDown(Keys.ModifierShift+Keys.M,"ModuleCastleStore.Local.CastleStore:HotkeyEmptyStore()",2,false)end
function ModuleCastleStore.Local.CastleStore:DescribeHotkeys()
if not
self.HotkeysAddToList then
API.AddShortcut({de="Umschalt + B",en="Shift + B"},{de="Burglager: Waren einlagern",en="Vault: Store goods"})
API.AddShortcut({de="Umschalt + N",en="Shift + N"},{de="Burglager: Waren sperren",en="Vault: Lock goods"})
API.AddShortcut({de="Umschalt + M",en="Shift + M"},{de="Burglager: Lager räumen",en="Vault: Empty store"})self.HotkeysAddToList=true end end
function ModuleCastleStore.Local:OverwriteGetStringTableText()
GetStringTableText_Orig_QSB_CatsleStore=XGUIEng.GetStringTableText
XGUIEng.GetStringTableText=function(s4)local FFG=GUI.GetSelectedEntity()
local a31jEAS=GUI.GetPlayerID()local LS4h=XGUIEng.GetCurrentWidgetID()
if
s4 =="UI_ObjectNames/DestroyGoods"then
if Logic.GetHeadquarters(a31jEAS)==FFG then
if
XGUIEng.IsWidgetShown("/InGame/Root/Normal/AlignBottomRight/Selection/Castle")==1 then return
API.Localize(ModuleCastleStore.Shared.Text.ShowCastleStore.Text)else return
API.Localize(ModuleCastleStore.Shared.Text.ShowCastle.Text)end end end;if s4 =="UI_ObjectDescription/DestroyGoods"then return""end
if s4 ==
"UI_ObjectNames/CityBuildingsNumber"then
if Logic.GetHeadquarters(a31jEAS)==FFG then return
API.Localize(ModuleCastleStore.Shared.Text.CityTab.Title)end end
if s4 =="UI_ObjectDescription/CityBuildingsNumber"then
if
Logic.GetHeadquarters(a31jEAS)==FFG then return
API.Localize(ModuleCastleStore.Shared.Text.CityTab.Text)end end
if s4 =="UI_ObjectNames/B_StoreHouse"then
if
Logic.GetHeadquarters(a31jEAS)==FFG then return
API.Localize(ModuleCastleStore.Shared.Text.StorehouseTab.Title)end end
if s4 =="UI_ObjectDescription/B_StoreHouse"then
if
Logic.GetHeadquarters(a31jEAS)==FFG then return
API.Localize(ModuleCastleStore.Shared.Text.StorehouseTab.Text)end end
if s4 =="UI_ObjectNames/B_Castle_ME"then
local eux092_P="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/"local ZA9=eux092_P.."Tab03Down/down/B_Castle_ME"local hWgmxm=eux092_P..
"Tab03Up/up/B_Castle_ME"
if
XGUIEng.GetWidgetPathByID(LS4h)==
ZA9 or XGUIEng.GetWidgetPathByID(LS4h)==hWgmxm then
if Logic.GetHeadquarters(a31jEAS)==FFG then return
API.Localize(ModuleCastleStore.Shared.Text.MultiTab.Title)end end end
if s4 =="UI_ObjectDescription/B_Castle_ME"then
if
Logic.GetHeadquarters(a31jEAS)==FFG then return
API.Localize(ModuleCastleStore.Shared.Text.MultiTab.Text)end end
if s4 =="UI_ButtonDisabled/NotEnoughGoods"then
if
Logic.GetHeadquarters(a31jEAS)==FFG then return
API.Localize(ModuleCastleStore.Shared.Text.GoodButtonDisabled.Text)end end;return GetStringTableText_Orig_QSB_CatsleStore(s4)end end
function ModuleCastleStore.Local:OverwriteGameFunctions()
GameCallback_GUI_SelectionChanged_Orig_QSB_CastleStore=GameCallback_GUI_SelectionChanged
GameCallback_GUI_SelectionChanged=function(UBg54E)
GameCallback_GUI_SelectionChanged_Orig_QSB_CastleStore(UBg54E)
QSB.CastleStore:SelectionChanged(GUI.GetPlayerID())end;GUI_Trade.GoodClicked_Orig_QSB_CastleStore=GUI_Trade.GoodClicked
GUI_Trade.GoodClicked=function()
local gQGq=Goods[XGUIEng.GetWidgetNameByID(XGUIEng.GetWidgetsMotherID(XGUIEng.GetCurrentWidgetID()))]local OyHc5FEv=GUI.GetSelectedEntity()local Dn1Xi=GUI.GetPlayerID()if
Logic.IsEntityInCategory(OyHc5FEv,EntityCategories.Storehouse)==1 then
GUI_Trade.GoodClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:GoodClicked(Dn1Xi,gQGq)end
GUI_Trade.DestroyGoodsClicked_Orig_QSB_CastleStore=GUI_Trade.DestroyGoodsClicked
GUI_Trade.DestroyGoodsClicked=function()local _gGmBBE=GUI.GetSelectedEntity()
local rIX4=GUI.GetPlayerID()if
Logic.IsEntityInCategory(_gGmBBE,EntityCategories.Storehouse)==1 then
GUI_Trade.DestroyGoodsClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:DestroyGoodsClicked(rIX4)end;GUI_Trade.SellUpdate_Orig_QSB_CastleStore=GUI_Trade.SellUpdate
GUI_Trade.SellUpdate=function()
local AI14eFhp=GUI.GetSelectedEntity()local iW2O=GUI.GetPlayerID()if
Logic.IsEntityInCategory(AI14eFhp,EntityCategories.Storehouse)==1 then
GUI_Trade.SellUpdate_Orig_QSB_CastleStore()return end
QSB.CastleStore:UpdateGoodsDisplay(iW2O)end
GUI_Trade.CityTabButtonClicked_Orig_QSB_CastleStore=GUI_Trade.CityTabButtonClicked
GUI_Trade.CityTabButtonClicked=function()local Gdp=GUI.GetSelectedEntity()
local nbqmx=GUI.GetPlayerID()if
Logic.IsEntityInCategory(Gdp,EntityCategories.Storehouse)==1 then
GUI_Trade.CityTabButtonClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:OnCityTabClicked(nbqmx)end
GUI_Trade.StorehouseTabButtonClicked_Orig_QSB_CastleStore=GUI_Trade.StorehouseTabButtonClicked
GUI_Trade.StorehouseTabButtonClicked=function()local IWQcC=GUI.GetSelectedEntity()
local cvRh=GUI.GetPlayerID()if
Logic.IsEntityInCategory(IWQcC,EntityCategories.Storehouse)==1 then
GUI_Trade.StorehouseTabButtonClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:OnStorehouseTabClicked(cvRh)end
GUI_Trade.MultiTabButtonClicked_Orig_QSB_CastleStore=GUI_Trade.MultiTabButtonClicked
GUI_Trade.MultiTabButtonClicked=function()local W9yaJm=GUI.GetSelectedEntity()
local oJ1ec=GUI.GetPlayerID()if
Logic.IsEntityInCategory(W9yaJm,EntityCategories.Storehouse)==1 then
GUI_Trade.MultiTabButtonClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:OnMultiTabClicked(oJ1ec)end
GUI_BuildingInfo.StorageLimitUpdate_Orig_QSB_CastleStore=GUI_BuildingInfo.StorageLimitUpdate
GUI_BuildingInfo.StorageLimitUpdate=function()local L=GUI.GetSelectedEntity()
local MMNWLk=GUI.GetPlayerID()if
Logic.IsEntityInCategory(L,EntityCategories.Storehouse)==1 then
GUI_BuildingInfo.StorageLimitUpdate_Orig_QSB_CastleStore()return end
QSB.CastleStore:UpdateStorageLimit(MMNWLk)end
GUI_Interaction.SendGoodsClicked=function()
local x6Ni,Q2waXkyp=GUI_Interaction.GetPotentialSubQuestAndType(g_Interaction.CurrentMessageQuestIndex)if not x6Ni then return end
local EG72=GUI_Interaction.GetPotentialSubQuestIndex(g_Interaction.CurrentMessageQuestIndex)local mlTMZ=x6Ni.Objectives[1].Data[1]
local q=x6Ni.Objectives[1].Data[2]local xb6={mlTMZ,q}local yK,rHLz2GD=AreCostsAffordable(xb6,true)
local BlW0RhJA=GUI.GetPlayerID()
if
Logic.GetGoodCategoryForGoodType(mlTMZ)==GoodCategories.GC_Resource then
rHLz2GD=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_NotEnough_Resources")yK=false
if QSB.CastleStore:IsLocked(BlW0RhJA,mlTMZ)then yK=
GetPlayerResources(mlTMZ,BlW0RhJA)>=q else
yK=
(GetPlayerResources(mlTMZ,BlW0RhJA)+
QSB.CastleStore:GetAmount(BlW0RhJA,mlTMZ))>=q end end
local Uy=x6Ni.Objectives[1].Data[6]and
x6Ni.Objectives[1].Data[6]or x6Ni.SendingPlayer;local n=PlayerSectorTypes.Thief
local TKu=CanEntityReachTarget(Uy,Logic.GetStoreHouse(GUI.GetPlayerID()),Logic.GetStoreHouse(Uy),
nil,n)
if TKu==false then
local M6kL=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_GenericUnreachable")Message(M6kL)return end
if yK==true then Sound.FXPlay2DSound("ui\\menu_click")
GUI.QuestTemplate_SendGoods(EG72)
GUI_FeedbackSpeech.Add("SpeechOnly_CartsSent",g_FeedbackSpeech.Categories.CartsUnderway,nil,nil)else Message(rHLz2GD)end end
GUI_Tooltip.SetCosts=function(M7o_,dk2X7J7,jv)local MW=XGUIEng.GetWidgetPathByID(M7o_)
local E2OQ=MW.."/1Good"local SnbfLb6=MW.."/2Goods"local ay=0;local W;local WzM;for I=2,#dk2X7J7,2 do
if dk2X7J7[I]~=0 then ay=ay+1 end end
if ay==0 then XGUIEng.ShowWidget(E2OQ,0)
XGUIEng.ShowWidget(SnbfLb6,0)return elseif ay==1 then XGUIEng.ShowWidget(E2OQ,1)
XGUIEng.ShowWidget(SnbfLb6,0)W=E2OQ.."/Good1Of1"elseif ay==2 then XGUIEng.ShowWidget(E2OQ,0)
XGUIEng.ShowWidget(SnbfLb6,1)W=SnbfLb6 .."/Good1Of2"WzM=SnbfLb6 .."/Good2Of2"elseif ay>2 then
GUI.AddNote("Debug: Invalid Costs table. Not more than 2 GoodTypes allowed.")end;local PSx=1
for wnA=1,#dk2X7J7,2 do
if dk2X7J7[wnA+1]~=0 then local cW=dk2X7J7[wnA]
local PHpCof2=dk2X7J7[wnA+1]local bUPpn4T2;local sode;if PSx==1 then bUPpn4T2=W.."/Icon"sode=W.."/Amount"else
bUPpn4T2=WzM.."/Icon"sode=WzM.."/Amount"end
SetIcon(bUPpn4T2,g_TexturePositions.Goods[cW],44)local G9zkKODk=GUI.GetPlayerID()
local MGt=GetPlayerGoodsInSettlement(cW,G9zkKODk,jv)
if
Logic.GetGoodCategoryForGoodType(cW)==GoodCategories.GC_Resource and cW~=Goods.G_Gold then if not
QSB.CastleStore:IsLocked(G9zkKODk,cW)then
MGt=MGt+QSB.CastleStore:GetAmount(G9zkKODk,cW)end end;local ld9GuG4t=""if MGt<PHpCof2 then ld9GuG4t="{@script:ColorRed}"end
if
PHpCof2 >0 then
XGUIEng.SetText(sode,"{center}"..ld9GuG4t..PHpCof2)else XGUIEng.SetText(sode,"")end;PSx=PSx+1 end end end end
function ModuleCastleStore.Local:InteractiveObjectPayStep2(KpCCA,H6)if H6 ==nil then return end
GUI.ExecuteObjectInteraction(GetID(H6),KpCCA)
API.BroadcastScriptCommand(QSB.ScriptCommands.CastleStoreObjectPayStep3,KpCCA,H6)end;Swift:RegisterModule(ModuleCastleStore)