
ModuleObjectInteraction={Properties={Name="ModuleObjectInteraction"},Global={SlaveSequence=0},Local={},Shared={Text={}}}QSB.IO={LastHeroEntityID=0,LastObjectEntityID=0}
function ModuleObjectInteraction.Global:OnGameStart()
QSB.ScriptEvents.ObjectClicked=API.RegisterScriptEvent("Event_ObjectClicked")
QSB.ScriptEvents.ObjectInteraction=API.RegisterScriptEvent("Event_ObjectInteraction")
QSB.ScriptEvents.ObjectReset=API.RegisterScriptEvent("Event_ObjectReset")
QSB.ScriptEvents.ObjectDelete=API.RegisterScriptEvent("Event_ObjectDelete")IO={}IO_UserDefindedNames={}IO_SlaveToMaster={}IO_SlaveState={}
self:OverrideObjectInteraction()self:StartObjectDestructionController()
self:StartObjectConditionController()self:CreateDefaultObjectNames()end
function ModuleObjectInteraction.Global:OnEvent(QDnlt,LmcA2auZ,...)
if
QDnlt==QSB.ScriptEvents.ObjectInteraction then self:OnObjectInteraction(arg[1],arg[2],arg[3])elseif
QDnlt==QSB.ScriptEvents.ChatClosed then if Swift:IsProcessDebugCommands()then
self:ProcessChatInput(arg[1])end end end
function ModuleObjectInteraction.Global:OnObjectInteraction(Q,ZA,_IQQ)
QSB.IO.LastObjectEntityID=GetID(Q)QSB.IO.LastHeroEntityID=ZA;if IO_SlaveToMaster[Q]then
Q=IO_SlaveToMaster[Q]end
if IO[Q]then IO[Q].IsUsed=true
Logic.ExecuteInLuaLocalState(string.format([[
                local ScriptName = "%s"
                if IO[ScriptName] then
                    IO[ScriptName].IsUsed = true
                end
            ]],Q))if IO[Q].Action then IO[Q]:Action(_IQQ,ZA)end end end
function ModuleObjectInteraction.Global:CreateObject(XpkjA)
local pVRj=GetID(XpkjA.Name)if pVRj==0 then return end;self:DestroyObject(XpkjA.Name)
local fuZ3z86=Logic.GetEntityTypeName(Logic.GetEntityType(pVRj))if fuZ3z86 and not fuZ3z86:find("^I_X_")then
self:CreateSlaveObject(XpkjA)end;XpkjA.IsActive=true
XpkjA.IsUsed=false;XpkjA.Player=XpkjA.Player or{1,2,3,4,5,6,7,8}
IO[XpkjA.Name]=XpkjA
Logic.ExecuteInLuaLocalState(string.format([[IO["%s"] = %s]],XpkjA.Name,table.tostring(IO[XpkjA.Name])))self:SetupObject(XpkjA)return XpkjA end
function ModuleObjectInteraction.Global:DestroyObject(er)
if not IO[er]then return end
if IO[er].Slave then IO_SlaveToMaster[IO[er].Slave]=nil
Logic.ExecuteInLuaLocalState(string.format([[IO_SlaveToMaster["%s"] = nil]],IO[er].Slave))IO_SlaveState[IO[er].Slave]=nil
DestroyEntity(IO[er].Slave)end;self:SetObjectState(er,2)
API.SendScriptEvent(QSB.ScriptEvents.ObjectDelete,er)
Logic.ExecuteInLuaLocalState(string.format([[
            local ScriptName = "%s"
            API.SendScriptEvent(QSB.ScriptEvents.ObjectDelete, ScriptName)
            IO[ScriptName] = nil
        ]],er))IO[er]=nil end
function ModuleObjectInteraction.Global:CreateSlaveObject(DFb100j)local XL_
for QKKks_zt,Are7xU in
pairs(IO_SlaveToMaster)do if Are7xU==DFb100j.Name and IsExisting(QKKks_zt)then
XL_=QKKks_zt end end
if XL_==nil then self.SlaveSequence=self.SlaveSequence+1;XL_="QSB_SlaveObject_"..
self.SlaveSequence end;local WYdR=GetID(XL_)
if not IsExisting(XL_)then
local yxjl,ZG,Vu0cCAf=Logic.EntityGetPos(GetID(DFb100j.Name))
WYdR=Logic.CreateEntity(Entities.I_X_DragonBoatWreckage,yxjl,ZG,0,0)Logic.SetModel(WYdR,Models.Effects_E_Mosquitos)
Logic.SetEntityName(WYdR,XL_)IO_SlaveToMaster[XL_]=DFb100j.Name
Logic.ExecuteInLuaLocalState(string.format([[IO_SlaveToMaster["%s"] = "%s"]],XL_,DFb100j.Name))DFb100j.Slave=XL_ end;IO_SlaveState[XL_]=1;return WYdR end
function ModuleObjectInteraction.Global:SetupObject(q)local kP7O5=GetID(
(q.Slave and q.Slave)or q.Name)
Logic.InteractiveObjectClearCosts(kP7O5)Logic.InteractiveObjectClearRewards(kP7O5)
Logic.InteractiveObjectSetInteractionDistance(kP7O5,q.Distance)
Logic.InteractiveObjectSetTimeToOpen(kP7O5,q.Waittime)
local lqT=q.RewardResourceCartType or Entities.U_ResourceMerchant
Logic.InteractiveObjectSetRewardResourceCartType(kP7O5,lqT)local mP3mlD=q.RewardGoldCartType or Entities.U_GoldCart
Logic.InteractiveObjectSetRewardGoldCartType(kP7O5,mP3mlD)
local PrPyxMK=q.CostResourceCartType or Entities.U_ResourceMerchant
Logic.InteractiveObjectSetCostResourceCartType(kP7O5,PrPyxMK)local tczrIB=q.CostGoldCartType or Entities.U_GoldCart
Logic.InteractiveObjectSetCostGoldCartType(kP7O5,tczrIB)if GetNameOfKeyInTable(Entities,q.Replacement)then
Logic.InteractiveObjectSetReplacingEntityType(kP7O5,q.Replacement)end;if q.Reward then
Logic.InteractiveObjectAddRewards(kP7O5,q.Reward[1],q.Reward[2])end;if q.Costs and q.Costs[1]then
Logic.InteractiveObjectAddCosts(kP7O5,q.Costs[1],q.Costs[2])end;if q.Costs and q.Costs[3]then
Logic.InteractiveObjectAddCosts(kP7O5,q.Costs[3],q.Costs[4])end
table.insert(HiddenTreasures,kP7O5)
API.InteractiveObjectActivate(Logic.GetEntityName(kP7O5),q.State or 0)end
function ModuleObjectInteraction.Global:ResetObject(a)local wqU76o=GetID(
(IO[a].Slave and IO[a].Slave)or a)
RemoveInteractiveObjectFromOpenedList(wqU76o)table.insert(HiddenTreasures,wqU76o)
Logic.InteractiveObjectSetAvailability(wqU76o,true)
self:SetObjectState(wqU76o,IO[a].State or 0)IO[a].IsUsed=false;IO[a].IsActive=true
API.SendScriptEvent(QSB.ScriptEvents.ObjectReset,a)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.ObjectReset, "%s")]],a))end
function ModuleObjectInteraction.Global:SetObjectState(LB1Z,N9L,...)
arg=(
(not arg or#arg==0)and{1,2,3,4,5,6,7,8})or arg;for hDc_M=1,8 do
Logic.InteractiveObjectSetPlayerState(GetID(LB1Z),hDc_M,2)end;for qW0lRiD1=1,#arg,1 do
Logic.InteractiveObjectSetPlayerState(GetID(LB1Z),arg[qW0lRiD1],N9L)end;Logic.InteractiveObjectSetAvailability(GetID(LB1Z),
N9L~=2)end
function ModuleObjectInteraction.Global:CreateDefaultObjectNames()
IO_UserDefindedNames["D_X_ChestClosed"]={de="Schatztruhe",en="Treasure Chest",fr="Coffre au trésor"}
IO_UserDefindedNames["D_X_ChestOpenEmpty"]={de="Leere Truhe",en="Empty Chest",fr="Coffre vide"}
Logic.ExecuteInLuaLocalState(string.format([[IO_UserDefindedNames = %s]],table.tostring(IO_UserDefindedNames)))end
function ModuleObjectInteraction.Global:OverrideObjectInteraction()
GameCallback_OnObjectInteraction=function(iD1IUx,JLCOx_ak)
OnInteractiveObjectOpened(iD1IUx,JLCOx_ak)OnTreasureFound(iD1IUx,JLCOx_ak)
local hPQ=Logic.GetEntityName(iD1IUx)
if IO_SlaveToMaster[hPQ]then hPQ=IO_SlaveToMaster[hPQ]end;local R1FIoQI={}Logic.GetKnights(JLCOx_ak,R1FIoQI)
local NsoTwDs=API.GetClosestToTarget(iD1IUx,R1FIoQI)
API.SendScriptEvent(QSB.ScriptEvents.ObjectInteraction,hPQ,NsoTwDs,JLCOx_ak)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.ObjectInteraction, "%s", %d, %d)]],hPQ,NsoTwDs,JLCOx_ak))end
QuestTemplate.AreObjectsActivated=function(HGli,iy)
for m6SCS0=1,iy[0]do if not iy[-m6SCS0]then
iy[-m6SCS0]=GetID(iy[m6SCS0])end
local NUhYw6R4=Logic.GetEntityName(iy[-m6SCS0])
if IO_SlaveToMaster[NUhYw6R4]then NUhYw6R4=IO_SlaveToMaster[NUhYw6R4]end
if IO[NUhYw6R4]then
if IO[NUhYw6R4].IsUsed~=true then return false end elseif Logic.IsInteractiveObject(iy[-m6SCS0])then if not
IsInteractiveObjectOpen(iy[-m6SCS0])then return false end end end;return true end end
function ModuleObjectInteraction.Global:ProcessChatInput(Hv)
local Ch=ModuleInputOutputCore.Shared:CommandTokenizer(Hv)
for urkh=1,#Ch,1 do
if Ch[1]=="enableobject"then
local zhzpBSx=(Ch[3]and tonumber(Ch[3]))or nil
local rHSjalVy=(Ch[4]and tonumber(Ch[4]))or nil;if not IsExisting(Ch[2])then
error("object "..Ch[2].." does not exist!")return end
API.InteractiveObjectActivate(Ch[2],zhzpBSx,rHSjalVy)info("activated object "..Ch[2]..".")elseif
Ch[1]=="disableobject"then
local TjhsnP=(Ch[3]and tonumber(Ch[3]))or nil;if not IsExisting(Ch[2])then
error("object "..Ch[2].." does not exist!")return end
API.InteractiveObjectDeactivate(Ch[2],TjhsnP)
info("deactivated object "..Ch[2]..".")elseif Ch[1]=="initobject"then
if not IsExisting(Ch[2])then error("object "..
Ch[2].." does not exist!")return end
API.SetupObject({Name=Ch[2],Waittime=0,State=0})
info("quick initalization of object "..Ch[2]..".")end end end
function ModuleObjectInteraction.Global:StartObjectDestructionController()
API.StartJobByEventType(Events.LOGIC_EVENT_ENTITY_DESTROYED,function()
local t5jzEd9=Event.GetEntityID()local JZAU2=Logic.GetEntityName(t5jzEd9)
local zPXTTg=IO_SlaveToMaster[JZAU2]
if JZAU2 and zPXTTg then local seMLr=IO[zPXTTg]if not seMLr then return end
info("slave "..JZAU2 .." of master "..
zPXTTg.." has been deleted!")info("try to create new slave...")
IO_SlaveToMaster[JZAU2]=nil
Logic.ExecuteInLuaLocalState(string.format([[IO_SlaveToMaster["%s"] = nil]],JZAU2))
local qX=ModuleObjectInteraction.Global:CreateSlaveObject(seMLr)
if not IsExisting(qX)then error("failed to create slave!")return end
ModuleObjectInteraction.Global:SetupObject(seMLr)if seMLr.IsUsed==true or
(IO_SlaveState[JZAU2]and IO_SlaveState[JZAU2]==0)then
API.InteractiveObjectDeactivate(seMLr.Slave)end
info(
"new slave created for master "..zPXTTg..".")end end)end
function ModuleObjectInteraction.Global:StartObjectConditionController()
API.StartHiResJob(function()
for h_8,xL7OTb in pairs(IO)do
if
xL7OTb and not xL7OTb.IsUsed and xL7OTb.IsActive then
IO[h_8].IsFullfilled=true;if IO[h_8].Condition then local w8T3f=xL7OTb:Condition()
IO[h_8].IsFullfilled=w8T3f end
Logic.ExecuteInLuaLocalState(string.format([[
                        local ScriptName = "%s"
                        if IO[ScriptName] then
                            IO[ScriptName].IsFullfilled = %s
                        end
                    ]],h_8,tostring(IO[h_8].IsFullfilled)))end end end)end
function ModuleObjectInteraction.Local:OnGameStart()
QSB.ScriptEvents.ObjectClicked=API.RegisterScriptEvent("Event_ObjectClicked")
QSB.ScriptEvents.ObjectInteraction=API.RegisterScriptEvent("Event_ObjectInteraction")
QSB.ScriptEvents.ObjectReset=API.RegisterScriptEvent("Event_ObjectReset")
QSB.ScriptEvents.ObjectDelete=API.RegisterScriptEvent("Event_ObjectDelete")IO={}IO_UserDefindedNames={}IO_SlaveToMaster={}
self:OverrideGameFunctions()end
function ModuleObjectInteraction.Local:OnEvent(K,qL,vfIyB,quNsijN,QUh2tc)
if
K==QSB.ScriptEvents.ObjectReset then if IO[vfIyB]then IO[vfIyB].IsUsed=false end elseif K==
QSB.ScriptEvents.ObjectInteraction then QSB.IO.LastObjectEntityID=GetID(vfIyB)
QSB.IO.LastHeroEntityID=quNsijN end end
function ModuleObjectInteraction.Local:OverrideGameFunctions()
g_CurrentDisplayedQuestID=0
GUI_Interaction.InteractiveObjectClicked_Orig_ModuleObjectInteraction=GUI_Interaction.InteractiveObjectClicked
GUI_Interaction.InteractiveObjectClicked=function()
local qboV=tonumber(XGUIEng.GetWidgetNameByID(XGUIEng.GetCurrentWidgetID()))local nSBOx7=g_Interaction.ActiveObjectsOnScreen[qboV]
local u=GUI.GetPlayerID()if not nSBOx7 then return end;local K=Logic.GetEntityName(nSBOx7)if
IO_SlaveToMaster[K]then K=IO_SlaveToMaster[K]end
if IO[K]then
if
not IO[K].IsFullfilled then
local i1=XGUIEng.GetStringTableText("UI_ButtonDisabled/PromoteKnight")if IO[K].ConditionInfo then
i1=API.ConvertPlaceholders(API.Localize(IO[K].ConditionInfo))end;Message(i1)return end
if
type(IO[K].Costs)=="table"and#IO[K].Costs~=0 then local zz1QI=Logic.GetStoreHouse(u)
local kFTAh=Logic.GetHeadquarters(u)
if
zz1QI==nil or zz1QI==0 or kFTAh==nil or kFTAh==0 then
API.Note("DEBUG: Player needs special buildings when using activation costs!")return end end end
GUI_Interaction.InteractiveObjectClicked_Orig_ModuleObjectInteraction()
if not Framework.IsNetworkGame()then local LBf={}
Logic.GetKnights(u,LBf)local dijn4Ph=API.GetClosestToTarget(nSBOx7,LBf)
API.SendScriptEventToGlobal(QSB.ScriptEvents.ObjectClicked,K,dijn4Ph,u)
API.SendScriptEvent(QSB.ScriptEvents.ObjectClicked,K,dijn4Ph,u)end end
GUI_Interaction.InteractiveObjectUpdate=function()
if g_Interaction.ActiveObjects==nil then return end;local CO1=GUI.GetPlayerID()
for RlZo=1,#g_Interaction.ActiveObjects do
local SUn=g_Interaction.ActiveObjects[RlZo]local Ib4=SUn;local fjV1G2=Logic.GetEntityName(SUn)if IO_SlaveToMaster[fjV1G2]then
Ib4=GetID(IO_SlaveToMaster[fjV1G2])end
local Do,_=GUI.GetEntityInfoScreenPosition(Ib4)local TqYJ4,DI=GUI.GetScreenSize()
if

Do~=0 and _~=0 and Do>-50 and _>-50 and Do< (TqYJ4+50)and _< (DI+50)then if
not table.contains(g_Interaction.ActiveObjectsOnScreen,SUn)then
table.insert(g_Interaction.ActiveObjectsOnScreen,SUn)end else
for RlZo=1,#
g_Interaction.ActiveObjectsOnScreen do if
g_Interaction.ActiveObjectsOnScreen[RlZo]==SUn then
table.remove(g_Interaction.ActiveObjectsOnScreen,RlZo)end end end end
for b=1,#g_Interaction.ActiveObjectsOnScreen do
local E="/InGame/Root/Normal/InteractiveObjects/"..b
if XGUIEng.IsWidgetExisting(E)==1 then
local KMw7_i1s=g_Interaction.ActiveObjectsOnScreen[b]local CQi=KMw7_i1s;local nHlJ=Logic.GetEntityName(KMw7_i1s)if
IO_SlaveToMaster[nHlJ]then CQi=GetID(IO_SlaveToMaster[nHlJ])
nHlJ=Logic.GetEntityName(CQi)end
local lw4Q7kbl=Logic.GetEntityType(KMw7_i1s)local IN,QYf1=GUI.GetEntityInfoScreenPosition(CQi)
local RfsnisO={XGUIEng.GetWidgetScreenSize(E)}
XGUIEng.SetWidgetScreenPosition(E,IN- (RfsnisO[1]/2),QYf1-
(RfsnisO[2]/2))
local lvW2ga={Logic.InteractiveObjectGetCosts(KMw7_i1s)}
local T7RKP={Logic.InteractiveObjectGetEffectiveCosts(KMw7_i1s,CO1)}
local _L6Bs=Logic.InteractiveObjectGetAvailability(KMw7_i1s)
local SH=Logic.InteractiveObjectHasPlayerEnoughSpaceForRewards(KMw7_i1s,CO1)local wU4wYbA9=false;if
lvW2ga[1]~=nil and T7RKP[1]==nil and _L6Bs==true then wU4wYbA9=true end
if SH==false then wU4wYbA9=true end
if IO[nHlJ]and type(IO[nHlJ].Player)=="table"then
wU4wYbA9=
not self:IsAvailableForGuiPlayer(nHlJ)elseif IO[nHlJ]and type(IO[nHlJ].Player)=="number"then wU4wYbA9=
IO[nHlJ].Player~=CO1 end;if wU4wYbA9 ==true then XGUIEng.DisableButton(E,1)else
XGUIEng.DisableButton(E,0)end;if
GUI_Interaction.InteractiveObjectUpdateEx1 ~=nil then
GUI_Interaction.InteractiveObjectUpdateEx1(E,lw4Q7kbl)end
XGUIEng.ShowWidget(E,1)end end
for fFeQcIM=#g_Interaction.ActiveObjectsOnScreen+1,2 do local JEHSHPh3=
"/InGame/Root/Normal/InteractiveObjects/"..fFeQcIM
XGUIEng.ShowWidget(JEHSHPh3,0)end
for bb=1,#g_Interaction.ActiveObjectsOnScreen do
local o5e6fP="/InGame/Root/Normal/InteractiveObjects/"..bb;local iq7ol=g_Interaction.ActiveObjectsOnScreen[bb]
local eMV=Logic.GetEntityName(iq7ol)
if IO_SlaveToMaster[eMV]then eMV=IO_SlaveToMaster[eMV]end
if IO[eMV]and IO[eMV].Texture then
local WDTNkTD=(IO[eMV].Texture[1])or 14;local Oejsws=(IO[eMV].Texture[2])or 10;local CkD73N0=
(IO[eMV].Texture[3])or 0
API.SetIcon(o5e6fP,{WDTNkTD,Oejsws,CkD73N0},nil,nil)end end end
GUI_Interaction.InteractiveObjectMouseOver_Orig_ModuleObjectInteraction=GUI_Interaction.InteractiveObjectMouseOver
GUI_Interaction.InteractiveObjectMouseOver=function()local PlwhaRKJ=GUI.GetPlayerID()
local Caz4NM4Z=tonumber(XGUIEng.GetWidgetNameByID(XGUIEng.GetCurrentWidgetID()))
local XVxxx=g_Interaction.ActiveObjectsOnScreen[Caz4NM4Z]local hD=Logic.GetEntityType(XVxxx)
if g_GameExtraNo>0 then
local ITdz=Logic.GetEntityTypeName(hD)
if
table.contains({"R_StoneMine","R_IronMine","B_Cistern","B_Well","I_X_TradePostConstructionSite"},ITdz)then
GUI_Interaction.InteractiveObjectMouseOver_Orig_ModuleObjectInteraction()return end end;local G5BuU5=Logic.GetEntityTypeName(hD)
if

string.find(G5BuU5,"^I_X_")and tonumber(Logic.GetEntityName(XVxxx))~=nil then
GUI_Interaction.InteractiveObjectMouseOver_Orig_ModuleObjectInteraction()return end
local AfwsY={Logic.InteractiveObjectGetEffectiveCosts(XVxxx,PlwhaRKJ)}local T=Logic.GetEntityName(XVxxx)if IO_SlaveToMaster[T]then
T=IO_SlaveToMaster[T]end;local WZs
if IO[T]and IO[T].IsUsed~=true then
local AjfoUo="InteractiveObjectAvailable"
if

(IO[T]and type(IO[T].Player)=="table"and not
self:IsAvailableForGuiPlayer(T))or
(IO[T]and type(IO[T].Player)=="number"and IO[T].Player~=
PlwhaRKJ)or
Logic.InteractiveObjectGetAvailability(XVxxx)==false then AjfoUo="InteractiveObjectNotAvailable"end;local Er9zidsB;if
Logic.InteractiveObjectHasPlayerEnoughSpaceForRewards(XVxxx,PlwhaRKJ)==false then
Er9zidsB="InteractiveObjectAvailableReward"end
local X=IO[T].Title or(
"UI_ObjectNames/"..AjfoUo)X=API.ConvertPlaceholders(API.Localize(X))
if X and
X:find("^[A-Za-z0-9_]+/[A-Za-z0-9_]+$")then X=XGUIEng.GetStringTableText(X)end
local dR=IO[T].Text or("UI_ObjectDescription/"..AjfoUo)dR=API.ConvertPlaceholders(API.Localize(dR))
if dR and
dR:find("^[A-Za-z0-9_]+/[A-Za-z0-9_]+$")then dR=XGUIEng.GetStringTableText(dR)end;local JFXtQwy=IO[T].DisabledText or Er9zidsB
if JFXtQwy then
JFXtQwy=API.ConvertPlaceholders(API.Localize(JFXtQwy))
if
JFXtQwy and JFXtQwy:find("^[A-Za-z0-9_]+/[A-Za-z0-9_]+$")then JFXtQwy=XGUIEng.GetStringTableText(JFXtQwy)end end;AfwsY=IO[T].Costs
if
AfwsY and AfwsY[1]and AfwsY[1]~=Goods.G_Gold and
Logic.GetGoodCategoryForGoodType(AfwsY[1])~=GoodCategories.GC_Resource then WZs=true end;API.SetTooltipCosts(X,dR,JFXtQwy,AfwsY,WZs)return end
GUI_Interaction.InteractiveObjectMouseOver_Orig_ModuleObjectInteraction()end
GUI_Interaction.DisplayQuestObjective_Orig_ModuleObjectInteraction=GUI_Interaction.DisplayQuestObjective
GUI_Interaction.DisplayQuestObjective=function(uMV17h0,E2NZK)local WNWWe=tonumber(uMV17h0)
if WNWWe then uMV17h0=WNWWe end
local zMzjn3lk,Trkkpmd=GUI_Interaction.GetPotentialSubQuestAndType(uMV17h0)local L="/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives"
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)local GGv;local ZIzh4Si;g_CurrentDisplayedQuestID=uMV17h0
if Trkkpmd==Objective.Object then GGv=L..
"/List"
ZIzh4Si=Wrapped_GetStringTableText(uMV17h0,"UI_Texts/QuestInteraction")local c8D4n81={}
for cSjJHx=1,zMzjn3lk.Objectives[1].Data[0]do local fa
if
Logic.IsEntityDestroyed(zMzjn3lk.Objectives[1].Data[cSjJHx])then
fa=g_Interaction.SavedQuestEntityTypes[uMV17h0][cSjJHx]else
fa=Logic.GetEntityType(GetID(zMzjn3lk.Objectives[1].Data[cSjJHx]))end
local M=Logic.GetEntityName(zMzjn3lk.Objectives[1].Data[cSjJHx])local dIZlrvD=""
if fa~=nil and fa~=0 then
local jQgsATKd=Logic.GetEntityTypeName(fa)
dIZlrvD=Wrapped_GetStringTableText(uMV17h0,"Names/"..jQgsATKd)if dIZlrvD==""then
dIZlrvD=Wrapped_GetStringTableText(uMV17h0,"UI_ObjectNames/"..jQgsATKd)end;if dIZlrvD==""then
dIZlrvD=IO_UserDefindedNames[jQgsATKd]end;if dIZlrvD==nil then
dIZlrvD=IO_UserDefindedNames[M]end;if dIZlrvD==nil then
dIZlrvD="Debug: ObjectName missing for "..jQgsATKd end end
table.insert(c8D4n81,API.Localize(API.ConvertPlaceholders(dIZlrvD)))end;for aBbGg=1,4 do local D9=c8D4n81[aBbGg]if D9 ==nil then D9=""end
XGUIEng.SetText(GGv..
"/Entry"..aBbGg,"{center}"..D9)end
SetIcon(GGv.."/QuestTypeIcon",{14,10})
XGUIEng.SetText(GGv.."/Caption","{center}"..ZIzh4Si)XGUIEng.ShowWidget(GGv,1)else
GUI_Interaction.DisplayQuestObjective_Orig_ModuleObjectInteraction(uMV17h0,E2NZK)end end end
function ModuleObjectInteraction.Local:IsAvailableForGuiPlayer(G)
local gE=GUI.GetPlayerID()
if IO[G]and type(IO[G].Player)=="table"then for QgC=1,8 do
if
IO[G].Player[QgC]and IO[G].Player[QgC]==gE then return true end end;return false end;return true end;Swift:RegisterModule(ModuleObjectInteraction)