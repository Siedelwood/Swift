
ModuleInteractiveSites={Properties={Name="ModuleInteractiveSites"},Global={CreatedSites={}},Local={},Shared={},Texts={Description={Title={de="Gebäude bauen",en="Create building"},Text={de=
"Beauftragt den Bau eines Gebäudes. Ein Siedler wird aus".." dem Lagerhaus kommen und mit dem Bau beginnen.",en=
"Order a building. A worker will come out of the".." storehouse and erect it."}}}}QSB.NonPlayerCharacterObjects={}
function ModuleInteractiveSites.Global:OnGameStart()
QSB.ScriptEvents.InteractiveSiteConstructed=API.RegisterScriptEvent("Event_InteractiveSiteConstructed")self:OverrideConstructionCompleteCallback()end
function ModuleInteractiveSites.Global:OnEvent(QDnlt,LmcA2auZ,...)
if
QDnlt==QSB.ScriptEvents.ObjectReset then
if IO[arg[1]]and IO[arg[1]].IsInteractiveSite then end elseif QDnlt==QSB.ScriptEvents.ObjectDelete then if IO[arg[1]]and
IO[arg[1]].IsInteractiveSite then end end end
function ModuleInteractiveSites.Global:OverrideConstructionCompleteCallback()
GameCallback_OnBuildingConstructionComplete_Orig_QSB_InteractiveSites=GameCallback_OnBuildingConstructionComplete
GameCallback_OnBuildingConstructionComplete=function(Q,ZA)
GameCallback_OnBuildingConstructionComplete_Orig_QSB_InteractiveSites(Q,ZA)
if ModuleInteractiveSites.Global.CreatedSites[ZA]then
local _IQQ=ModuleInteractiveSites.Global.CreatedSites[ZA]
if _IQQ then
API.SendScriptEvent(QSB.ScriptEvents.InteractiveSiteConstructed,_IQQ.Name,Q,ZA)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(%d, "%s", %d, %d)]],QSB.ScriptEvents.InteractiveSiteConstructed,_IQQ.Name,Q,ZA))end end end end
function ModuleInteractiveSites.Global:CreateIOBuildingSite(XpkjA)local pVRj=XpkjA.Costs or
{Logic.GetEntityTypeFullCost(XpkjA.Type)}local fuZ3z86=XpkjA.Title or
ModuleInteractiveSites.Texts.Description.Title
local er=
XpkjA.Text or ModuleInteractiveSites.Texts.Description.Text;local DFb100j=GetID(XpkjA.Name)
Logic.SetModel(DFb100j,Models.Buildings_B_BuildingPlot_10x10)Logic.SetVisible(DFb100j,true)
API.SetupObject{Name=XpkjA.Name,IsInteractiveSite=true,Title=fuZ3z86,Text=er,Texture=
XpkjA.Texture or{14,10},Distance=XpkjA.Distance or 1500,Type=XpkjA.Type,Costs=pVRj,PlayerID=XpkjA.PlayerID,Condition=function(XpkjA)return
self:ConditionIOConstructionSite(XpkjA)end,Action=function(XpkjA,XL_,WYdR)
self:CallbackIOConstructionSite(XpkjA,XL_,WYdR)end}end
function ModuleInteractiveSites.Global:CallbackIOConstructionSite(QKKks_zt,Are7xU,yxjl)
local ZG=GetPosition(QKKks_zt.Name)local Vu0cCAf=GetID(QKKks_zt.Name)
local q=Logic.GetEntityOrientation(Vu0cCAf)
local kP7O5=Logic.CreateConstructionSite(ZG.X,ZG.Y,q,QKKks_zt.Type,QKKks_zt.PlayerID)Logic.SetVisible(Vu0cCAf,false)
if(kP7O5 ==nil)then
warn("For object '"..
QKKks_zt.Name.."' building placement failed! Building created instead")
kP7O5=Logic.CreateEntity(QKKks_zt.Type,ZG.X,ZG.Y,q,QKKks_zt.PlayerID)end;self.CreatedSites[kP7O5]=QKKks_zt end
function ModuleInteractiveSites.Global:ConditionIOConstructionSite(lqT)
local mP3mlD=GetID(lqT.Name)local PrPyxMK=GetTerritoryUnderEntity(mP3mlD)
local tczrIB=Logic.GetTerritoryPlayerID(PrPyxMK)
if Logic.GetStoreHouse(lqT.PlayerID)==0 then return false end;if lqT.PlayerID~=tczrIB then return false end;return true end
function ModuleInteractiveSites.Local:OnGameStart()
QSB.ScriptEvents.InteractiveSiteConstructed=API.RegisterScriptEvent("Event_InteractiveSiteConstructed")end;Swift:RegisterModule(ModuleInteractiveSites)