SCP.MilitaryLimit={}
ModuleMilitaryLimit={Properties={Name="ModuleMilitaryLimit"},Global={SoldierLimitCalculators={},SoldierKillsCounter={}},Local={SelectionBackup={},RecruitLocked={},RefillLocked={}},Shared={DefaultSoldierLimits={25,43,61,91,91},SoldierLimits={}}}QSB.DestroyedSoldiers={}
function ModuleMilitaryLimit.Global:OnGameStart()
QSB.ScriptEvents.ProducedThief=API.RegisterScriptEvent("Event_ProducedThief")
QSB.ScriptEvents.ProducedBattalion=API.RegisterScriptEvent("Event_ProducedBattalion")
QSB.ScriptEvents.RefilledBattalion=API.RegisterScriptEvent("Event_RefilledBattalion")
API.RegisterScriptCommand("Cmd_MilitaryLimitProduceUnits",SCP.MilitaryLimit.ProduceUnits)
API.RegisterScriptCommand("Cmd_MilitaryLimitRefillBattalion",SCP.MilitaryLimit.RefillBattalion)
for QDnlt=0,8 do self.SoldierKillsCounter[QDnlt]={}end;if API.IsHistoryEditionNetworkGame()then return end;for LmcA2auZ=1,8 do
self:SetLimitsForPlayer(LmcA2auZ)end;self:UpdateSoldierLimits()
API.StartJob(function()
ModuleMilitaryLimit.Global:UpdateSoldierLimits()end)end
function ModuleMilitaryLimit.Global:OnEvent(Q,ZA,...)if
Q==QSB.ScriptEvents.EntityKilled then
self:OnEntityKilledController(arg[1],arg[2],arg[3],arg[4])end end
function ModuleMilitaryLimit.Global:OnEntityKilledController(_IQQ,XpkjA,pVRj,fuZ3z86)
if _IQQ~=0 and pVRj~=0 then self.SoldierKillsCounter[fuZ3z86][XpkjA]=
self.SoldierKillsCounter[fuZ3z86][XpkjA]or 0
if
Logic.IsEntityTypeInCategory(fuZ3z86,EntityCategories.Soldier)==1 then self.SoldierKillsCounter[fuZ3z86][XpkjA]=
self.SoldierKillsCounter[fuZ3z86][XpkjA]+1 end end end
function ModuleMilitaryLimit.Global:GetEnemySoldierKillsOfPlayer(er,DFb100j)return
self.SoldierKillsCounter[er][DFb100j]or 0 end
function ModuleMilitaryLimit.Global:SetLimitsForPlayer(XL_,WYdR)local QKKks_zt=WYdR
if not QKKks_zt then
QKKks_zt=function(Are7xU)
local yxjl=1;local ZG=Logic.GetHeadquarters(Are7xU)if ZG~=0 then yxjl=
Logic.GetUpgradeLevel(ZG)+1 end;return
ModuleMilitaryLimit.Shared.DefaultSoldierLimits[yxjl]end end;self.SoldierLimitCalculators[XL_]=QKKks_zt end
function ModuleMilitaryLimit.Global:ProduceUnit(Vu0cCAf,q,kP7O5,lqT)
local mP3mlD,PrPyxMK=Logic.GetBuildingApproachPosition(q)local tczrIB,a=Logic.GetRallyPoint(q)
local wqU76o=Logic.GetEntityOrientation(q)self:SubFromPlayerGoods(Vu0cCAf,q,lqT)
if
kP7O5 ==Entities.U_Thief then
local LB1Z=Logic.CreateEntityOnUnblockedLand(kP7O5,mP3mlD,PrPyxMK,wqU76o-90,Vu0cCAf)
API.SendScriptEvent(QSB.ScriptEvents.ProducedThief,LB1Z,q,lqT)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.ProducedThief, %d, %d, %s)]],LB1Z,q,table.tostring(lqT)))else
local N9L=Logic.CreateBattalionOnUnblockedLand(kP7O5,mP3mlD,PrPyxMK,0-90,Vu0cCAf,6)Logic.MoveSettler(N9L,tczrIB,a,-1)
API.SendScriptEvent(QSB.ScriptEvents.ProducedBattalion,N9L,q,lqT)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.ProducedBattalion, %d, %d, %s)]],N9L,q,table.tostring(lqT)))end end
function ModuleMilitaryLimit.Global:RefillBattalion(hDc_M,qW0lRiD1,iD1IUx,JLCOx_ak)
local hPQ,R1FIoQI,NsoTwDs=Logic.EntityGetPos(iD1IUx)local HGli,iy=Logic.GetBuildingApproachPosition(qW0lRiD1)
local m6SCS0=Logic.GetEntityOrientation(iD1IUx)local NUhYw6R4=Logic.LeaderGetSoldiersType(iD1IUx)
local Hv=Logic.GetSoldiersAttachedToLeader(iD1IUx)
local Ch=Logic.CreateBattalion(NUhYw6R4,hPQ,R1FIoQI,m6SCS0,hDc_M,Hv+1)
Logic.SetEntityName(Ch,Logic.GetEntityName(iD1IUx))
local urkh={Logic.GetSoldiersAttachedToLeader(iD1IUx)}
local zhzpBSx={Logic.GetSoldiersAttachedToLeader(Ch)}
for rHSjalVy=2,zhzpBSx[1]do
local TjhsnP,t5jzEd9,JZAU2=Logic.EntityGetPos(urkh[rHSjalVy])
Logic.DEBUG_SetSettlerPosition(zhzpBSx[rHSjalVy],TjhsnP,t5jzEd9)
Logic.SetOrientation(zhzpBSx[rHSjalVy],Logic.GetEntityOrientation(urkh[rHSjalVy]))end
Logic.DEBUG_SetPosition(zhzpBSx[#zhzpBSx],HGli,iy)Logic.DestroyEntity(iD1IUx)
Logic.ExecuteInLuaLocalState(string.format([[
            local ID1 = %d
            local ID2 = %d
            for i= #ModuleMilitaryLimit.Local.SelectionBackup, 1, -1 do
                if ModuleMilitaryLimit.Local.SelectionBackup[i] ~= ID1 then
                    GUI.SelectEntity(ModuleMilitaryLimit.Local.SelectionBackup[i])
                end
            end
            ModuleMilitaryLimit.Local.SelectionBackup = {}

            GUI.SelectEntity(ID2)
            GUI_MultiSelection.CreateEX()
            local Selection = {GUI.GetSelectedEntities()}
            for i= #Selection, 1, -1 do
                if Selection[i] ~= ID2 then
                    GUI.DeselectEntity(Selection[i])
                end
            end
        ]],iD1IUx,Ch))self:SubFromPlayerGoods(hDc_M,qW0lRiD1,JLCOx_ak)
API.SendScriptEvent(QSB.ScriptEvents.RefilledBattalion,Ch,qW0lRiD1,Hv,
Hv+1,JLCOx_ak)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.RefilledBattalion, %d, %d, %d, %d, %s)]],Ch,qW0lRiD1,Hv,Hv+1,table.tostring(JLCOx_ak)))end
function ModuleMilitaryLimit.Global:SubFromPlayerGoods(zPXTTg,seMLr,qX)
for h_8=1,3,2 do
if qX[h_8]then
local xL7OTb=Logic.GetGoodCategoryForGoodType(qX[h_8])
if
qX[h_8]==Goods.G_Gold or xL7OTb==GoodCategories.GC_Resource then AddGood(qX[h_8],(-1)*qX[h_8+1],zPXTTg)else Logic.RemoveGoodFromStock(seMLr,qX[h_8],qX[
h_8+1])end end end end
function ModuleMilitaryLimit.Global:UpdateSoldierLimits()
for w8T3f=1,8 do
local K=self.SoldierLimitCalculators[w8T3f](w8T3f)
ModuleMilitaryLimit.Shared.SoldierLimits[w8T3f]=K
Logic.ExecuteInLuaLocalState(string.format([[ModuleMilitaryLimit.Shared.SoldierLimits[%d] = %d]],w8T3f,K))end end
function ModuleMilitaryLimit.Local:OnGameStart()
QSB.ScriptEvents.ProducedThief=API.RegisterScriptEvent("Event_ProducedThief")
QSB.ScriptEvents.ProducedBattalion=API.RegisterScriptEvent("Event_ProducedBattalion")
QSB.ScriptEvents.RefilledBattalion=API.RegisterScriptEvent("Event_RefilledBattalion")self:OverrideUI()end
function ModuleMilitaryLimit.Local:OnEvent(qL,vfIyB,...)local quNsijN=GUI.GetPlayerID()
if qL==
QSB.ScriptEvents.ProducedBattalion then if quNsijN==Logic.EntityGetPlayer(arg[1])then
self.RecruitLocked[quNsijN]=false end elseif
qL==QSB.ScriptEvents.ProducedThief then if quNsijN==Logic.EntityGetPlayer(arg[1])then
self.RecruitLocked[quNsijN]=false end elseif
qL==QSB.ScriptEvents.RefilledBattalion then if quNsijN==Logic.EntityGetPlayer(arg[1])then
self.RefillLocked[quNsijN]=false end end end
function ModuleMilitaryLimit.Local:OverrideUI()
function GUI_CityOverview.LimitUpdate()
local QUh2tc=XGUIEng.GetCurrentWidgetID()local qboV=GUI.GetPlayerID()
local nSBOx7=Logic.GetCurrentSoldierCount(qboV)
local u=ModuleMilitaryLimit.Shared:GetLimitForPlayer(qboV)local K="{@color:none}"
if nSBOx7 >=u then K="{@color:255,20,30,255}"end
XGUIEng.SetText(QUh2tc,"{center}"..K..nSBOx7 .."/"..u)end
GUI_BuildingButtons.BuyBattalionClicked_Orig_MilitaryLimit=GUI_BuildingButtons.BuyBattalionClicked
GUI_BuildingButtons.BuyBattalionClicked=function()local i1=GUI.GetPlayerID()
local zz1QI=GUI.GetSelectedEntity()local kFTAh=Logic.GetEntityType(zz1QI)local LBf
if
kFTAh==Entities.B_Barracks then LBf=Entities.U_MilitarySword elseif kFTAh==Entities.B_BarracksArchers then
LBf=Entities.U_MilitaryBow elseif
Logic.IsEntityInCategory(zz1QI,EntityCategories.Headquarters)==1 then LBf=Entities.U_Thief else return
GUI_BuildingButtons.BuyBattalionClicked_Orig_MilitaryLimit()end;local dijn4Ph={Logic.GetUnitCost(zz1QI,LBf)}
local CO1,RlZo=AreCostsAffordable(dijn4Ph)local SUn=Logic.GetCurrentSoldierCount(i1)
local Ib4=ModuleMilitaryLimit.Shared:GetLimitForPlayer(i1)local fjV1G2;if LBf==Entities.U_Thief then fjV1G2=1 else
fjV1G2=Logic.GetBattalionSize(zz1QI)end;if(SUn+fjV1G2)>Ib4 then CO1=false
RlZo=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_SoldierLimitReached")end
if CO1 ==true then
ModuleMilitaryLimit.Local.RecruitLocked[i1]=true;Sound.FXPlay2DSound("ui\\menu_click")if
LBf~=Entities.U_Thief then
StartKnightVoiceForPermanentSpecialAbility(Entities.U_KnightChivalry)end
API.BroadcastScriptCommand(QSB.ScriptCommands.MilitaryLimitProduceUnits,i1,zz1QI,LBf,dijn4Ph)else Message(RlZo)end end
GUI_BuildingButtons.BuyBattalionUpdate_Orig_MilitaryLimit=GUI_BuildingButtons.BuyBattalionUpdate
GUI_BuildingButtons.BuyBattalionUpdate=function()
local Do=XGUIEng.GetCurrentWidgetID()local _=GUI.GetPlayerID()local TqYJ4=GUI.GetSelectedEntity()
local DI=Logic.GetEntityType(TqYJ4)
if DI==Entities.B_BarracksArchers then
SetIcon(Do,g_TexturePositions.Entities[Entities.U_MilitaryBow])elseif
Logic.IsEntityInCategory(TqYJ4,EntityCategories.Headquarters)==1 then
SetIcon(Do,g_TexturePositions.Entities[Entities.U_Thief])elseif DI==Entities.B_Barracks then
SetIcon(Do,g_TexturePositions.Entities[Entities.U_MilitarySword])else
return GUI_BuildingButtons.BuyBattalionUpdate_Orig_MilitaryLimit()end;local b=true
if
DI~=Entities.B_Barracks and DI~=Entities.B_BarracksArchers and
Logic.IsEntityInCategory(TqYJ4,EntityCategories.Headquarters)==0 then b=false end
if Logic.IsConstructionComplete(TqYJ4)==0 then b=false end;local E=true
if
Logic.IsEntityInCategory(TqYJ4,EntityCategories.Headquarters)==1 then local _=GUI.GetPlayerID()
local KMw7_i1s=Logic.TechnologyGetState(_,Technologies.R_Thieves)if EnableRights==true then
if KMw7_i1s==TechnologyStates.Locked then b=false end
if KMw7_i1s~=TechnologyStates.Researched then E=false end end end;if E then
if ModuleMilitaryLimit.Local.RecruitLocked[_]then E=false end end
XGUIEng.ShowWidget(Do,(b and 1)or 0)XGUIEng.DisableButton(Do,(E and 0)or 1)end
function GUI_Military.RefillClicked()local CQi=GUI.GetPlayerID()
local nHlJ=GUI.GetSelectedEntity()local lw4Q7kbl=Logic.GetRefillerID(nHlJ)
local IN=Logic.LeaderGetMaxNumberOfSoldiers(nHlJ)local QYf1=Logic.GetSoldiersAttachedToLeader(nHlJ)
local RfsnisO=Logic.LeaderGetSoldiersType(nHlJ)
local lvW2ga={Logic.GetEntityTypeRefillCost(lw4Q7kbl,RfsnisO)}local T7RKP=Logic.GetCurrentSoldierCount(CQi)
local _L6Bs=ModuleMilitaryLimit.Shared:GetLimitForPlayer(CQi)local SH,wU4wYbA9
if QYf1 <IN then
if T7RKP<_L6Bs then SH,wU4wYbA9=AreCostsAffordable(lvW2ga)if
SH==false then Message(wU4wYbA9)return end
local fFeQcIM=Logic.CanRefillBattalion(nHlJ)
if fFeQcIM==false then
local JEHSHPh3=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_NotCloseToBarracksForRefilling")Message(JEHSHPh3)else
local bb=table.copy(g_MultiSelection.EntityList)ModuleMilitaryLimit.Local.SelectionBackup=bb
ModuleMilitaryLimit.Local.RefillLocked[CQi]=true;GUI.ClearSelection()
API.BroadcastScriptCommand(QSB.ScriptCommands.MilitaryLimitRefillBattalion,CQi,lw4Q7kbl,nHlJ,lvW2ga)end end end end
function GUI_Military.RefillUpdate()local o5e6fP=XGUIEng.GetCurrentWidgetID()
local iq7ol=GUI.GetPlayerID()local eMV=GUI.GetSelectedEntity()
local WDTNkTD={GUI.GetSelectedEntities()}
if
eMV==nil or
Logic.IsEntityInCategory(eMV,EntityCategories.Leader)==0 or#WDTNkTD>1 then XGUIEng.ShowWidget(o5e6fP,0)return end;local Oejsws=Logic.GetRefillerID(eMV)
local CkD73N0=Logic.LeaderGetMaxNumberOfSoldiers(eMV)local PlwhaRKJ=Logic.GetSoldiersAttachedToLeader(eMV)
if Oejsws==0 or
PlwhaRKJ==CkD73N0 then
XGUIEng.DisableButton(o5e6fP,1)else
if ModuleMilitaryLimit.Local.RefillLocked[iq7ol]then
XGUIEng.DisableButton(o5e6fP,1)else XGUIEng.DisableButton(o5e6fP,0)end end end end
function ModuleMilitaryLimit.Shared:GetLimitForPlayer(Caz4NM4Z)
if
API.IsHistoryEditionNetworkGame()then return Logic.GetCurrentSoldierLimit(Caz4NM4Z)end;return self.SoldierLimits[Caz4NM4Z]end;Swift:RegisterModule(ModuleMilitaryLimit)