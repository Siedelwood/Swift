
ModuleTradingCore={Properties={Name="ModuleTradingCore"},Global={Analysis={PlayerOffersAmount={[1]={},[2]={},[3]={},[4]={},[5]={},[6]={},[7]={},[8]={}}},Lambda={},Event={}},Local={Lambda={PurchaseTraderAbility={},PurchaseBasePrice={},PurchaseInflation={},PurchaseAllowed={},SaleBasePrice={},SaleDeflation={},SaleAllowed={}},ShowKnightTraderAbility=true},Shared={}}
QSB.TraderTypes={GoodTrader=0,MercenaryTrader=1,EntertainerTrader=2,Unknown=3}
function ModuleTradingCore.Global:OnGameStart()
QSB.ScriptEvents.GoodsSold=API.RegisterScriptEvent("Event_GoodsSold")
QSB.ScriptEvents.GoodsPurchased=API.RegisterScriptEvent("Event_GoodsPurchased")self:OverwriteBasePricesAndRefreshRates()end
function ModuleTradingCore.Global:OnEvent(QDnlt,LmcA2auZ,...)
if
QDnlt==QSB.ScriptEvents.GoodsPurchased then
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.GoodsPurchased, %d, %d, %d, %d, %d, %d, %d)]],arg[1],arg[2],arg[3],arg[4],arg[5],arg[6],arg[7]))
self:PerformFakeTrade(arg[1],arg[2],arg[3],arg[4],arg[5],arg[6],arg[7])elseif QDnlt==QSB.ScriptEvents.GoodsSold then
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.GoodsSold, g_Trade.GoodType, PlayerID, TargetID, g_Trade.GoodAmount, Price)]],arg[1],arg[2],arg[3],arg[4],arg[5]))end end
function ModuleTradingCore.Global:OverwriteBasePricesAndRefreshRates()
MerchantSystem.BasePrices[Entities.U_CatapultCart]=
MerchantSystem.BasePrices[Entities.U_CatapultCart]or 1000
MerchantSystem.BasePrices[Entities.U_BatteringRamCart]=
MerchantSystem.BasePrices[Entities.U_BatteringRamCart]or 450
MerchantSystem.BasePrices[Entities.U_SiegeTowerCart]=
MerchantSystem.BasePrices[Entities.U_SiegeTowerCart]or 600
MerchantSystem.BasePrices[Entities.U_AmmunitionCart]=
MerchantSystem.BasePrices[Entities.U_AmmunitionCart]or 180
MerchantSystem.BasePrices[Entities.U_MilitarySword_RedPrince]=
MerchantSystem.BasePrices[Entities.U_MilitarySword_RedPrince]or 150
MerchantSystem.BasePrices[Entities.U_MilitarySword]=
MerchantSystem.BasePrices[Entities.U_MilitarySword]or 150
MerchantSystem.BasePrices[Entities.U_MilitaryBow_RedPrince]=
MerchantSystem.BasePrices[Entities.U_MilitaryBow_RedPrince]or 220
MerchantSystem.BasePrices[Entities.U_MilitaryBow]=
MerchantSystem.BasePrices[Entities.U_MilitaryBow]or 220
MerchantSystem.RefreshRates[Entities.U_CatapultCart]=
MerchantSystem.RefreshRates[Entities.U_CatapultCart]or 270
MerchantSystem.RefreshRates[Entities.U_BatteringRamCart]=
MerchantSystem.RefreshRates[Entities.U_BatteringRamCart]or 190
MerchantSystem.RefreshRates[Entities.U_SiegeTowerCart]=
MerchantSystem.RefreshRates[Entities.U_SiegeTowerCart]or 220
MerchantSystem.RefreshRates[Entities.U_AmmunitionCart]=
MerchantSystem.RefreshRates[Entities.U_AmmunitionCart]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_RedPrince]=
MerchantSystem.RefreshRates[Entities.U_MilitarySword_RedPrince]or 150
MerchantSystem.RefreshRates[Entities.U_MilitarySword]=
MerchantSystem.RefreshRates[Entities.U_MilitarySword]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_RedPrince]=
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_RedPrince]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow]=
MerchantSystem.RefreshRates[Entities.U_MilitaryBow]or 150
if g_GameExtraNo>=1 then
MerchantSystem.BasePrices[Entities.U_MilitaryBow_Khana]=
MerchantSystem.BasePrices[Entities.U_MilitaryBow_Khana]or 220
MerchantSystem.BasePrices[Entities.U_MilitarySword_Khana]=
MerchantSystem.BasePrices[Entities.U_MilitarySword_Khana]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_Khana]=
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_Khana]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_Khana]=
MerchantSystem.RefreshRates[Entities.U_MilitarySword_Khana]or 150 end end
function ModuleTradingCore.Global:PerformFakeTrade(Q,ZA,_IQQ,XpkjA,pVRj,fuZ3z86,er)
local DFb100j=Logic.GetStoreHouse(XpkjA)local XL_=Logic.GetStoreHouse(pVRj)local WYdR=
Logic.GetEntityOrientation(XL_)-90
if Q==0 then
if
Logic.GetGoodCategoryForGoodType(_IQQ)~=GoodCategories.GC_Animal then
API.SendCart(XL_,XpkjA,_IQQ,fuZ3z86,nil,false)else
StartSimpleJobEx(function(yxjl,ZG,_IQQ,Vu0cCAf)if Logic.GetTime()>yxjl+5 then return true end
local q,kP7O5=Logic.GetBuildingApproachPosition(ZG)
local lqT=
(_IQQ~=Goods.G_Cow and Entities.A_X_Sheep01)or Entities.A_X_Cow01
Logic.CreateEntityOnUnblockedLand(lqT,q,kP7O5,0,Vu0cCAf)end,Logic.GetTime(),XL_,_IQQ,XpkjA)end elseif Q==1 then local mP3mlD,PrPyxMK=Logic.GetBuildingApproachPosition(XL_)
local tczrIB=Logic.CreateBattalionOnUnblockedLand(_IQQ,mP3mlD,PrPyxMK,WYdR,XpkjA)Logic.MoveSettler(tczrIB,mP3mlD,PrPyxMK,-1)else
local a,wqU76o=Logic.GetBuildingApproachPosition(XL_)Logic.HireEntertainer(_IQQ,XpkjA,a,wqU76o)end
API.SendCart(DFb100j,pVRj,Goods.G_Gold,er,nil,false)AddGood(Goods.G_Gold,(-1)*er,XpkjA)local QKKks_zt=0
local Are7xU=self:GetStorehouseInformation(pVRj)
for LB1Z=1,#Are7xU[1]do if Are7xU[1][LB1Z][3]==_IQQ and
Are7xU[1][LB1Z][5]>0 then
QKKks_zt=Are7xU[1][LB1Z][5]-1 end end;self:ModifyTradeOffer(pVRj,_IQQ,QKKks_zt)
Logic.ExecuteInLuaLocalState(string.format("GameCallback_MerchantInteraction(%d, %d, %d)",XL_,XpkjA,ZA))end
function ModuleTradingCore.Global:GetStorehouseInformation(N9L)
local hDc_M=Logic.GetStoreHouse(N9L)local qW0lRiD1={Player=N9L,Storehouse=hDc_M,OfferCount=0,{}}
local iD1IUx=Logic.GetNumberOfMerchants(Logic.GetStoreHouse(N9L))local JLCOx_ak=0
if hDc_M~=0 then
for hPQ=0,iD1IUx,1 do
local R1FIoQI={Logic.GetMerchantOfferIDs(hDc_M,hPQ,N9L)}
for NsoTwDs=1,#R1FIoQI,1 do local HGli,iy,m6SCS0,NUhYw6R4=0,0,0,0
if Logic.IsGoodTrader(hDc_M,hPQ)then
HGli,iy,m6SCS0,NUhYw6R4=Logic.GetGoodTraderOffer(hDc_M,R1FIoQI[NsoTwDs],N9L)
if HGli==Goods.G_Sheep or HGli==Goods.G_Cow then iy=5 end elseif Logic.IsMercenaryTrader(hDc_M,hPQ)then
HGli,iy,m6SCS0,NUhYw6R4=Logic.GetMercenaryOffer(hDc_M,R1FIoQI[NsoTwDs],N9L)elseif Logic.IsEntertainerTrader(hDc_M,hPQ)then
HGli,iy,m6SCS0,NUhYw6R4=Logic.GetEntertainerTraderOffer(hDc_M,R1FIoQI[NsoTwDs],N9L)end;JLCOx_ak=JLCOx_ak+1
local Hv={hPQ,R1FIoQI[NsoTwDs],HGli,iy,m6SCS0}table.insert(qW0lRiD1[1],Hv)end end end;qW0lRiD1.OfferCount=JLCOx_ak;return qW0lRiD1 end
function ModuleTradingCore.Global:GetOfferCount(Ch)
local urkh=self:GetStorehouseInformation(Ch)if urkh then return urkh.OfferCount end;return 0 end
function ModuleTradingCore.Global:GetOfferAndTrader(zhzpBSx,rHSjalVy)
local TjhsnP=self:GetStorehouseInformation(zhzpBSx)
if TjhsnP then
for t5jzEd9=1,#TjhsnP[1],1 do if TjhsnP[1][t5jzEd9][3]==rHSjalVy then
return
TjhsnP[1][t5jzEd9][2],TjhsnP[1][t5jzEd9][1],TjhsnP.Storehouse end end end;return-1,-1,-1 end
function ModuleTradingCore.Global:GetTraderType(JZAU2,zPXTTg)
if
Logic.IsGoodTrader(JZAU2,zPXTTg)==true then return QSB.TraderTypes.GoodTrader elseif
Logic.IsMercenaryTrader(JZAU2,zPXTTg)==true then return QSB.TraderTypes.MercenaryTrader elseif
Logic.IsEntertainerTrader(JZAU2,zPXTTg)==true then return QSB.TraderTypes.EntertainerTrader else return
QSB.TraderTypes.Unknown end end
function ModuleTradingCore.Global:RemoveTradeOffer(seMLr,qX)
local h_8,xL7OTb,w8T3f=self:GetOfferAndTrader(seMLr,qX)if not IsExisting(w8T3f)then return end
local K=(xL7OTb==1 and 2)or(
xL7OTb==2 and 1)or 0;Logic.RemoveOffer(w8T3f,K,h_8)end
function ModuleTradingCore.Global:RemoveTradeOfferByData(qL,vfIyB)
local quNsijN=qL[1][vfIyB][2]local QUh2tc=qL[1][vfIyB][1]local qboV=qL.Storehouse;if
not IsExisting(qboV)then return end;local nSBOx7=
(QUh2tc==1 and 2)or(QUh2tc==2 and 1)or 0
Logic.RemoveOffer(qboV,nSBOx7,quNsijN)end
function ModuleTradingCore.Global:ModifyTradeOffer(u,K,i1)
local zz1QI,kFTAh,LBf=self:GetOfferAndTrader(u,K)if not IsExisting(LBf)then return end;if i1 ==nil or i1 ==-1 then
i1=self.Analysis.PlayerOffersAmount[u][K]end;if
self.Analysis.PlayerOffersAmount[u][K]and
self.Analysis.PlayerOffersAmount[u][K]<i1 then
i1=self.Analysis.PlayerOffersAmount[u][K]end
Logic.ModifyTraderOffer(LBf,zz1QI,i1,kFTAh)end
function ModuleTradingCore.Local:OnGameStart()
QSB.ScriptEvents.GoodsSold=API.RegisterScriptEvent("Event_GoodsSold")
QSB.ScriptEvents.GoodsPurchased=API.RegisterScriptEvent("Event_GoodsPurchased")g_Merchant.BuyFromPlayer={}
if API.IsHistoryEditionNetworkGame()then return end;self:OverrideMerchantComputePurchasePrice()
self:OverrideMerchantComputeSellingPrice()self:OverrideMerchantSellGoodsClicked()
self:OverrideMerchantPurchaseOfferUpdate()self:OverrideMerchantPurchaseOfferClicked()end
function ModuleTradingCore.Local:OverrideMerchantPurchaseOfferUpdate()
GUI_Merchant.OfferUpdate=function(dijn4Ph)
local CO1=XGUIEng.GetCurrentWidgetID()local RlZo=XGUIEng.GetWidgetsMotherID(CO1)
local SUn=GUI.GetPlayerID()local Ib4=g_Merchant.ActiveMerchantBuilding
if Ib4 ==0 or
Logic.IsEntityDestroyed(Ib4)==true then return end
if g_Merchant.Offers[dijn4Ph]==nil then
XGUIEng.ShowWidget(RlZo,0)return else XGUIEng.ShowWidget(RlZo,1)end;local fjV1G2=g_Merchant.Offers[dijn4Ph].TraderType
local Do=g_Merchant.Offers[dijn4Ph].OfferIndex;local _,TqYJ4,DI,b=0,0,0,0
if fjV1G2 ==g_Merchant.GoodTrader then
_,TqYJ4,DI,b=Logic.GetGoodTraderOffer(Ib4,Do,SUn)
if _==Goods.G_Sheep or _==Goods.G_Cow then TqYJ4=5 end
SetIcon(CO1,g_TexturePositions.Goods[_])elseif fjV1G2 ==g_Merchant.MercenaryTrader then
_,TqYJ4,DI,b=Logic.GetMercenaryOffer(Ib4,Do,SUn)local CQi=Logic.GetEntityTypeName(_)
if _==Entities.U_Thief then TqYJ4=1 elseif
string.find(CQi,"U_MilitarySword")or string.find(CQi,"U_MilitaryBow")then TqYJ4=6 elseif
string.find(CQi,"Cart")then TqYJ4=1 else TqYJ4=TqYJ4 end
SetIcon(CO1,g_TexturePositions.Entities[_])elseif fjV1G2 ==g_Merchant.EntertainerTrader then
_,TqYJ4,DI,b=Logic.GetEntertainerTraderOffer(Ib4,Do,SUn)
if not
(Logic.CanHireEntertainer(SUn)==true and
Logic.EntertainerIsOnTheMap(_)==false)then DI=0 end
SetIcon(CO1,g_TexturePositions.Entities[_])end
local E=XGUIEng.GetWidgetPathByID(RlZo).."/OfferAmount"XGUIEng.SetText(E,"{center}"..DI)local KMw7_i1s=
XGUIEng.GetWidgetPathByID(RlZo).."/OfferGoodAmount"XGUIEng.SetText(KMw7_i1s,
"{center}"..TqYJ4)
if DI==0 then
XGUIEng.DisableButton(CO1,1)else XGUIEng.DisableButton(CO1,0)end end end
function ModuleTradingCore.Local:OverrideMerchantPurchaseOfferClicked()
local nHlJ=function(IN,QYf1,RfsnisO,lvW2ga,T7RKP,_L6Bs)return true end;self.Lambda.PurchaseAllowed.Default=nHlJ
local lw4Q7kbl={Locked=false}
GameCallback_MerchantInteraction=function(SH,wU4wYbA9,fFeQcIM)if wU4wYbA9 ==GUI.GetPlayerID()then
lw4Q7kbl.Locked=false end end
GUI_Merchant.OfferClicked=function(JEHSHPh3)local bb=XGUIEng.GetCurrentWidgetID()
local o5e6fP=GUI.GetPlayerID()local iq7ol=g_Merchant.ActiveMerchantBuilding;if
iq7ol==0 or lw4Q7kbl.Locked then return end;local eMV=Logic.GetMarketplace(o5e6fP)
local WDTNkTD=Logic.EntityGetPlayer(iq7ol)
local Oejsws=g_Merchant.Offers[JEHSHPh3].TraderType
local CkD73N0=g_Merchant.Offers[JEHSHPh3].OfferIndex;local PlwhaRKJ=true;local Caz4NM4Z,XVxxx,hD,G5BuU5=0,0,0,0
if Oejsws==g_Merchant.GoodTrader then
Caz4NM4Z,XVxxx,hD,G5BuU5=Logic.GetGoodTraderOffer(iq7ol,CkD73N0,o5e6fP)
if
Logic.GetGoodCategoryForGoodType(Caz4NM4Z)==GoodCategories.GC_Resource then
if
Logic.GetPlayerUnreservedStorehouseSpace(o5e6fP)<XVxxx then PlwhaRKJ=false
local AfwsY=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_MerchantStorehouseSpace")Message(AfwsY)end elseif
Logic.GetGoodCategoryForGoodType(Caz4NM4Z)==GoodCategories.GC_Animal then PlwhaRKJ=true else
if
Logic.CanFitAnotherMerchantOnMarketplace(eMV)==false then PlwhaRKJ=false
local T=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_MerchantMarketplaceFull")Message(T)end end elseif Oejsws==g_Merchant.EntertainerTrader then
Caz4NM4Z,XVxxx,hD,G5BuU5=Logic.GetEntertainerTraderOffer(iq7ol,CkD73N0,iq7ol)
if
Logic.CanFitAnotherEntertainerOnMarketplace(eMV)==false then PlwhaRKJ=false
local WZs=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_MerchantMarketplaceFull")Message(WZs)end elseif Oejsws==g_Merchant.MercenaryTrader then
Caz4NM4Z,XVxxx,hD,G5BuU5=Logic.GetMercenaryOffer(iq7ol,CkD73N0,o5e6fP)local ITdz=Logic.GetEntityTypeName(Caz4NM4Z)
local AjfoUo=Logic.GetCurrentSoldierCount(o5e6fP)local Er9zidsB=Logic.GetCurrentSoldierLimit(o5e6fP)
if
API.GetPlayerSoldierLimit then Er9zidsB=API.GetPlayerSoldierLimit(o5e6fP)end;local X
if Caz4NM4Z==Entities.U_Thief then X=1 elseif string.find(ITdz,"U_MilitarySword")or
string.find(ITdz,"U_MilitaryBow")then X=6 elseif string.find(ITdz,"Cart")then X=0 else X=XVxxx end
if(AjfoUo+X)>Er9zidsB then PlwhaRKJ=false
local dR=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_SoldierLimitReached")Message(dR)end end
if PlwhaRKJ then
if
ModuleTradingCore.Local.Lambda.PurchaseAllowed[WDTNkTD]then
PlwhaRKJ=ModuleTradingCore.Local.Lambda.PurchaseAllowed[WDTNkTD](Oejsws,Caz4NM4Z,o5e6fP,WDTNkTD,XVxxx,G5BuU5)else
PlwhaRKJ=ModuleTradingCore.Local.Lambda.PurchaseAllowed.Default(Oejsws,Caz4NM4Z,o5e6fP,WDTNkTD,XVxxx,G5BuU5)end
if not PlwhaRKJ then
local JFXtQwy=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_GenericNotReadyYet")Message(JFXtQwy)return end end
if PlwhaRKJ==true then
local uMV17h0=ComputePrice(iq7ol,CkD73N0,o5e6fP,Oejsws)
local E2NZK=GetPlayerGoodsInSettlement(Goods.G_Gold,o5e6fP)local WNWWe=PlayerSectorTypes.Civil
local zMzjn3lk=CanEntityReachTarget(o5e6fP,Logic.GetStoreHouse(WDTNkTD),Logic.GetStoreHouse(o5e6fP),
nil,WNWWe)
if zMzjn3lk==false then
local Trkkpmd=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_GenericUnreachable")Message(Trkkpmd)return end
if uMV17h0 <=E2NZK then lw4Q7kbl.Locked=true
GUI.ChangeMerchantOffer(iq7ol,o5e6fP,CkD73N0,uMV17h0)Sound.FXPlay2DSound("ui\\menu_click")if
ModuleTradingCore.Local.ShowKnightTraderAbility then
StartKnightVoiceForPermanentSpecialAbility(Entities.U_KnightTrading)end;g_Merchant.BuyFromPlayer[WDTNkTD]=
g_Merchant.BuyFromPlayer[WDTNkTD]or{}
g_Merchant.BuyFromPlayer[WDTNkTD][Caz4NM4Z]=(
g_Merchant.BuyFromPlayer[WDTNkTD][Caz4NM4Z]or 0)+1
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.GoodsPurchased,Oejsws,CkD73N0,Caz4NM4Z,o5e6fP,WDTNkTD,XVxxx,uMV17h0)else
local L=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_NotEnough_G_Gold")Message(L)end end end end
function ModuleTradingCore.Local:OverrideMerchantSellGoodsClicked()
local GGv=function(ZIzh4Si,c8D4n81,cSjJHx,fa,M)return true end;self.Lambda.SaleAllowed.Default=GGv
GUI_Trade.SellClicked=function()
Sound.FXPlay2DSound("ui\\menu_click")if g_Trade.GoodAmount==0 then return end
local dIZlrvD=GUI.GetPlayerID()
local jQgsATKd=tonumber(XGUIEng.GetWidgetNameByID(XGUIEng.GetWidgetsMotherID(XGUIEng.GetCurrentWidgetID())))local aBbGg=g_Trade.TargetPlayers[jQgsATKd]
local D9=PlayerSectorTypes.Civil
if g_Trade.GoodType==Goods.G_Gold then D9=PlayerSectorTypes.Thief end
local G=CanEntityReachTarget(aBbGg,Logic.GetStoreHouse(dIZlrvD),Logic.GetStoreHouse(aBbGg),nil,D9)
if G==false then
local CYoa=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_GenericUnreachable")Message(CYoa)return end
if g_Trade.GoodType==Goods.G_Gold then elseif
Logic.GetGoodCategoryForGoodType(g_Trade.GoodType)==GoodCategories.GC_Resource then
local K3ipRr=Logic.GetPlayerUnreservedStorehouseSpace(aBbGg)
if K3ipRr<g_Trade.GoodAmount then
local F2tY=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_TargetFactionStorehouseSpace")Message(F2tY)return end else
if Logic.GetNumberOfTradeGatherers(dIZlrvD)>=1 then
local rb21L2=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_TradeGathererUnderway")Message(rb21L2)return end
if
Logic.CanFitAnotherMerchantOnMarketplace(Logic.GetMarketplace(aBbGg))==false then
local o_v255=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_TargetFactionMarketplaceFull")Message(o_v255)return end end;local gE
if Logic.PlayerGetIsHumanFlag(aBbGg)then gE=0 else
gE=GUI_Trade.ComputeSellingPrice(aBbGg,g_Trade.GoodType,g_Trade.GoodAmount)gE=gE/g_Trade.GoodAmount end;local QgC=true
if
ModuleTradingCore.Local.Lambda.SaleAllowed[aBbGg]then
QgC=ModuleTradingCore.Local.Lambda.SaleAllowed[aBbGg](dIZlrvD,aBbGg,g_Trade.GoodType,g_Trade.GoodAmount,gE)else
QgC=ModuleTradingCore.Local.Lambda.SaleAllowed.Default(dIZlrvD,aBbGg,g_Trade.GoodType,g_Trade.GoodAmount,gE)end
if not QgC then
local wUVm=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_GenericNotReadyYet")Message(wUVm)return end
GUI.StartTradeGoodGathering(dIZlrvD,aBbGg,g_Trade.GoodType,g_Trade.GoodAmount,gE)
GUI_FeedbackSpeech.Add("SpeechOnly_CartsSent",g_FeedbackSpeech.Categories.CartsUnderway,nil,nil)
StartKnightVoiceForPermanentSpecialAbility(Entities.U_KnightTrading)
if gE~=0 then if g_Trade.SellToPlayers[aBbGg]==nil then
g_Trade.SellToPlayers[aBbGg]={}end
if
g_Trade.SellToPlayers[aBbGg][g_Trade.GoodType]==nil then
g_Trade.SellToPlayers[aBbGg][g_Trade.GoodType]=g_Trade.GoodAmount else
g_Trade.SellToPlayers[aBbGg][g_Trade.GoodType]=
g_Trade.SellToPlayers[aBbGg][g_Trade.GoodType]+g_Trade.GoodAmount end
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.GoodsSold,g_Trade.GoodType,dIZlrvD,aBbGg,g_Trade.GoodAmount,gE)end end end
function ModuleTradingCore.Local:OverrideMerchantComputePurchasePrice()
local VQ=function(L,mR5gwW,DfbW)
local sh=Logic.GetKnightTraderAbilityModifier(mR5gwW)return math.ceil(L/sh)end;self.Lambda.PurchaseTraderAbility.Default=VQ
local oTYNsnP=function(rrFLbCtj,YcPea0vg,usLpLoaH)
local e7dv=MerchantSystem.BasePrices[rrFLbCtj]return(e7dv==nil and 3)or e7dv end;self.Lambda.PurchaseBasePrice.Default=oTYNsnP
local I=function(inx0,A5k5yt,B7SHDx7h,EEpoeR)inx0=
(inx0 >8 and 8)or inx0;local _k=A5k5yt+
(math.ceil(A5k5yt/4)*inx0)return
(_k<A5k5yt and A5k5yt)or _k end;self.Lambda.PurchaseInflation.Default=I
ComputePrice=function(Ef,KfM,Vd,Oynw)
local QBO=Logic.EntityGetPlayer(Ef)local s4ggux=Logic.GetGoodOfOffer(Ef,KfM,Vd,Oynw)local hrVI4meU
if
ModuleTradingCore.Local.Lambda.PurchaseBasePrice[QBO]then
hrVI4meU=ModuleTradingCore.Local.Lambda.PurchaseBasePrice[QBO](s4ggux,Vd,QBO)else
hrVI4meU=ModuleTradingCore.Local.Lambda.PurchaseBasePrice.Default(s4ggux,Vd,QBO)end;local xEq6TAF
if
ModuleTradingCore.Local.Lambda.PurchaseTraderAbility[QBO]then
xEq6TAF=ModuleTradingCore.Local.Lambda.PurchaseTraderAbility[QBO](hrVI4meU,Vd,QBO)else
xEq6TAF=ModuleTradingCore.Local.Lambda.PurchaseTraderAbility.Default(hrVI4meU,Vd,QBO)end;local UIjls=0;if g_Merchant.BuyFromPlayer[QBO]and
g_Merchant.BuyFromPlayer[QBO][s4ggux]then
UIjls=g_Merchant.BuyFromPlayer[QBO][s4ggux]end;local jdLnB0vD
if
ModuleTradingCore.Local.Lambda.PurchaseInflation[QBO]then
jdLnB0vD=ModuleTradingCore.Local.Lambda.PurchaseInflation[QBO](UIjls,xEq6TAF,Vd,QBO)else
jdLnB0vD=ModuleTradingCore.Local.Lambda.PurchaseInflation.Default(UIjls,xEq6TAF,Vd,QBO)end;return jdLnB0vD end end
function ModuleTradingCore.Local:OverrideMerchantComputeSellingPrice()
local PSlD=function(J,A,g3Qeqnr)
local qHpY64=MerchantSystem.BasePrices[J]return(qHpY64 ==nil and 3)or qHpY64 end;self.Lambda.SaleBasePrice.Default=PSlD;local nN=function(z,qccJ5b,ARuba)return
z-math.ceil(z/4)end
self.Lambda.SaleDeflation.Default=nN
GUI_Trade.ComputeSellingPrice=function(Wo53nZ,XRfQ,gFPRdEC)if XRfQ==Goods.G_Gold then return 0 end
local lw9gLt3=GUI.GetPlayerID()local T=MerchantSystem.Waggonload;local I5
if
ModuleTradingCore.Local.Lambda.SaleBasePrice[Wo53nZ]then
I5=ModuleTradingCore.Local.Lambda.SaleBasePrice[Wo53nZ](XRfQ,lw9gLt3,Wo53nZ)else
I5=ModuleTradingCore.Local.Lambda.SaleBasePrice.Default(XRfQ,lw9gLt3,Wo53nZ)end;local JmE=0;if g_Trade.SellToPlayers[Wo53nZ]~=nil and
g_Trade.SellToPlayers[Wo53nZ][XRfQ]~=nil then
JmE=g_Trade.SellToPlayers[Wo53nZ][XRfQ]end
local s4=math.ceil(I5/4)local FFG
if
ModuleTradingCore.Local.Lambda.SaleDeflation[Wo53nZ]then
FFG=ModuleTradingCore.Local.Lambda.SaleDeflation[Wo53nZ](I5,lw9gLt3,Wo53nZ)else
FFG=ModuleTradingCore.Local.Lambda.SaleDeflation.Default(I5,lw9gLt3,Wo53nZ)end;local a31jEAS=math.ceil(gFPRdEC/T)local LS4h=math.ceil(JmE/T)
local eux092_P=0;for ZA9=1,a31jEAS do eux092_P=eux092_P+math.min(LS4h*s4,FFG)LS4h=LS4h+
1 end;return
(a31jEAS*I5)-eux092_P end end;Swift:RegisterModule(ModuleTradingCore)