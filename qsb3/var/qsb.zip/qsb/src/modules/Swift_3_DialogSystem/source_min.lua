
ModuleDialogSystem={Properties={Name="ModuleDialogSystem"},Global={DialogPageCounter=0,DialogCounter=0,Dialog={},DialogQueue={}},Local={Dialog={}},Shared={Text={Continue={de="{cr}{cr}{azure}(Weiter mit ESC)",en="{cr}{cr}{azure}(Continue with ESC)"}}}}QSB.CinematicEventTypes.Dialog=4
QSB.Dialog={TIMER_PER_CHAR=0.175,CAMERA_ROTATIONDEFAULT=-45,CAMERA_ZOOMDEFAULT=0.5,DLGCAMERA_ROTATIONDEFAULT=-45,DLGCAMERA_ZOOMDEFAULT=0.15}
function ModuleDialogSystem.Global:OnGameStart()
QSB.ScriptEvents.DialogStarted=API.RegisterScriptEvent("Event_DialogStarted")
QSB.ScriptEvents.DialogEnded=API.RegisterScriptEvent("Event_DialogEnded")
QSB.ScriptEvents.DialogOptionSelected=API.RegisterScriptEvent("Event_DialogOptionSelected")for QDnlt=1,8 do self.DialogQueue[QDnlt]={}end
API.AddDisableDecisionCondition(function(LmcA2auZ,Q)if
ModuleDialogSystem.Global.Dialog[LmcA2auZ]~=nil then
return Q.Identifier:contains("DialogSystemQuest_")end;return true end)
API.StartHiResJob(function()
ModuleDialogSystem.Global:Update()end)end
function ModuleDialogSystem.Global:OnEvent(ZA,_IQQ,...)
if
ZA==QSB.ScriptEvents.EscapePressed then
if self.Dialog[arg[1]]~=nil then
if Logic.GetTime()-
self.Dialog[arg[1]].PageStartedTime>=1 then
local XpkjA=self.Dialog[arg[1]].CurrentPage;local pVRj=self.Dialog[arg[1]][XpkjA]if
not
self.Dialog[arg[1]].DisableSkipping and not pVRj.DisableSkipping and not pVRj.MC then
self:NextPage(arg[1])end end end elseif ZA==QSB.ScriptEvents.DialogOptionSelected then
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.DialogOptionSelected, %d, %d)]],arg[1],arg[2]))
ModuleDialogSystem.Global:OnOptionSelected(arg[1],arg[2])end end
function ModuleDialogSystem.Global:StartDialog(fuZ3z86,er,DFb100j)self.DialogQueue[er]=
self.DialogQueue[er]or{}self.DialogCounter=
(self.DialogCounter or 0)+1
DFb100j.DialogName="Dialog #"..self.DialogCounter
ModuleDisplayCore.Global:PushCinematicEventToQueue(er,QSB.CinematicEventTypes.Dialog,fuZ3z86,DFb100j)end
function ModuleDialogSystem.Global:EndDialog(XL_)
Logic.SetGlobalInvulnerability(0)if self.Dialog[XL_].Finished then
self.Dialog[XL_]:Finished()end
API.FinishCinematicEvent(self.Dialog[XL_].Name,XL_)
API.SendScriptEvent(QSB.ScriptEvents.DialogEnded,XL_,self.Dialog[XL_])
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.DialogEnded, %d, %s)]],XL_,table.tostring(self.Dialog[XL_])))self.Dialog[XL_]=nil end
function ModuleDialogSystem.Global:CanStartDialog(WYdR)
return self.Dialog[WYdR]==nil and not
API.IsCinematicEventActive(WYdR)and
not API.IsLoadscreenVisible()end
function ModuleDialogSystem.Global:NextDialog(QKKks_zt)
if self:CanStartDialog(QKKks_zt)then
local Are7xU=ModuleDisplayCore.Global:PopCinematicEventFromQueue(QKKks_zt)
assert(Are7xU[1]==QSB.CinematicEventTypes.Dialog)API.StartCinematicEvent(Are7xU[2],QKKks_zt)
Logic.ExecuteInLuaLocalState(string.format([[ModuleDialogSystem.Local:ResetTimerButtons(%d)]],QKKks_zt))local yxjl=Are7xU[3]yxjl.Name=Are7xU[2]yxjl.PlayerID=QKKks_zt
yxjl.CurrentPage=0;self.Dialog[QKKks_zt]=yxjl;if yxjl.EnableGlobalImmortality then
Logic.SetGlobalInvulnerability(1)end;if self.Dialog[QKKks_zt].Starting then
self.Dialog[QKKks_zt]:Starting()end
API.SendScriptEvent(QSB.ScriptEvents.DialogStarted,QKKks_zt,self.Dialog[QKKks_zt])
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.DialogStarted, %d, %s)]],QKKks_zt,table.tostring(self.Dialog[QKKks_zt])))self:NextPage(QKKks_zt)end end
function ModuleDialogSystem.Global:NextPage(ZG)
if self.Dialog[ZG]==nil then return end
self.Dialog[ZG].CurrentPage=self.Dialog[ZG].CurrentPage+1;self.Dialog[ZG].PageStartedTime=Logic.GetTime()if
self.Dialog[ZG].PageQuest then
API.StopQuest(self.Dialog[ZG].PageQuest,true)end
local Vu0cCAf=self.Dialog[ZG].CurrentPage;if Vu0cCAf<=0 then self:EndDialog(ZG)return end
local q=self.Dialog[ZG][Vu0cCAf]
if type(q)=="table"then
if q.MC then
for kP7O5=1,#q.MC,1 do if
type(q.MC[kP7O5][3])=="function"then
self.Dialog[ZG][Vu0cCAf].MC[kP7O5].Visible=
not q.MC[kP7O5][3](ZG,Vu0cCAf,kP7O5)end end end
if Vu0cCAf<=#self.Dialog[ZG]then if
self.Dialog[ZG][Vu0cCAf].Action then
self.Dialog[ZG][Vu0cCAf]:Action()end
self.Dialog[ZG].PageQuest=self:DisplayPage(ZG,Vu0cCAf)else self:EndDialog(ZG)end elseif type(q)=="number"or type(q)=="string"then
local lqT=self:GetPageIDByName(ZG,self.Dialog[ZG][Vu0cCAf])self.Dialog[ZG].CurrentPage=lqT-1
self:NextPage(ZG)else self:EndDialog(ZG)end end
function ModuleDialogSystem.Global:OnOptionSelected(mP3mlD,PrPyxMK)if
self.Dialog[mP3mlD]==nil then return end
local tczrIB=self.Dialog[mP3mlD].CurrentPage;if
type(self.Dialog[mP3mlD][tczrIB])~="table"then return end
local a=self.Dialog[mP3mlD][tczrIB]
if a.MC then local wqU76o;for LB1Z=1,#a.MC,1 do
if a.MC[LB1Z].ID==PrPyxMK then wqU76o=a.MC[LB1Z]end end
if wqU76o~=nil then local N9L=wqU76o[2]
if
type(wqU76o[2])=="function"then N9L=wqU76o[2](mP3mlD,tczrIB,PrPyxMK)end
self.Dialog[mP3mlD][tczrIB].MC.Selected=wqU76o.ID
self.Dialog[mP3mlD].CurrentPage=self:GetPageIDByName(mP3mlD,N9L)-1;self:NextPage(mP3mlD)end end end
function ModuleDialogSystem.Global:DisplayPage(hDc_M,qW0lRiD1)
if self.Dialog[hDc_M]==nil then return end;self.DialogPageCounter=self.DialogPageCounter+1
local iD1IUx=self.Dialog[hDc_M][qW0lRiD1]local JLCOx_ak="DialogSystemQuest_"..
hDc_M.."_".. (self.DialogPageCounter-1)
local hPQ=
"DialogSystemQuest_"..hDc_M.."_"..self.DialogPageCounter
local R1FIoQI=API.ConvertPlaceholders(API.Localize(iD1IUx.Text))local NsoTwDs=""
if
not self.Dialog[hDc_M].DisableSkipping and not
iD1IUx.DisableSkipping and not iD1IUx.MC then
NsoTwDs=API.ConvertPlaceholders(API.Localize(ModuleDialogSystem.Shared.Text.Continue))end;local HGli=iD1IUx.Sender or hDc_M
local iy=
(
self.Dialog[hDc_M].DisableSkipping or iD1IUx.DisableSkipping)==true
API.CreateQuest{Name=hPQ,Suggestion=R1FIoQI..NsoTwDs,Sender=(HGli==-1 and hDc_M)or HGli,Receiver=hDc_M,Goal_NoChange(),Trigger_Time(0)}
API.StartJob(function(m6SCS0,hDc_M,NUhYw6R4,Hv)if not m6SCS0 then return true end;if
Logic.GetTime()>=NUhYw6R4+Hv then
ModuleDialogSystem.Global:NextPage(hDc_M)return true end end,iy,hDc_M,Logic.GetTime(),12)
Logic.ExecuteInLuaLocalState(string.format([[ModuleDialogSystem.Local:DisplayPage(%d, %s)]],hDc_M,table.tostring(iD1IUx)))return hPQ end
function ModuleDialogSystem.Global:GetCurrentDialog(Ch)return self.Dialog[Ch]end
function ModuleDialogSystem.Global:GetCurrentDialogPage(urkh)
if self.Dialog[urkh]then
local zhzpBSx=self.Dialog[urkh].CurrentPage;return self.Dialog[urkh][zhzpBSx]end end
function ModuleDialogSystem.Global:GetPageIDByName(rHSjalVy,TjhsnP)
if type(TjhsnP)=="string"then
if
self.Dialog[rHSjalVy]~=nil then
for t5jzEd9=1,#self.Dialog[rHSjalVy],1 do if
type(self.Dialog[rHSjalVy][t5jzEd9])=="table"and
self.Dialog[rHSjalVy][t5jzEd9].Name==TjhsnP then
return t5jzEd9 end end end;return 0 end;return TjhsnP end
function ModuleDialogSystem.Global:Update()
for JZAU2=1,8 do
if self:CanStartDialog(JZAU2)then
local zPXTTg=ModuleDisplayCore.Global:LookUpCinematicInFromQueue(JZAU2)
if
zPXTTg and zPXTTg[1]==QSB.CinematicEventTypes.Dialog then self:NextDialog(JZAU2)end end end end
function ModuleDialogSystem.Local:OnGameStart()
QSB.ScriptEvents.DialogStarted=API.RegisterScriptEvent("Event_DialogStarted")
QSB.ScriptEvents.DialogEnded=API.RegisterScriptEvent("Event_DialogEnded")
QSB.ScriptEvents.DialogOptionSelected=API.RegisterScriptEvent("Event_DialogOptionSelected")self:OverrideTimerButtonClicked()
API.StartHiResJob(function()
ModuleDialogSystem.Local:Update()end)end
function ModuleDialogSystem.Local:OnEvent(seMLr,qX,...)
if
seMLr==QSB.ScriptEvents.DialogStarted then
ModuleDialogSystem.Local:StartDialog(arg[1],arg[2])elseif seMLr==QSB.ScriptEvents.DialogEnded then
ModuleDialogSystem.Local:EndDialog(arg[1],arg[2])elseif seMLr==QSB.ScriptEvents.QuestTrigger then local h_8=Quests[arg[1]]
if h_8 then
local xL7OTb=g_PlayerPortrait[h_8.SendingPlayer]
SetPortraitWithCameraSettings("/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait",xL7OTb)
if GUI.GetPlayerID()==h_8.ReceivingPlayer then
if not
self:IsAnyCinematicEventActive(h_8.ReceivingPlayer)then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/Update",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles/Update",1)else
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)end end end end end
function ModuleDialogSystem.Local:OverrideTimerButtonClicked()
GUI_Interaction.TimerButtonClicked_Orig_ModuleDialogSystem=GUI_Interaction.TimerButtonClicked
GUI_Interaction.TimerButtonClicked=function()local w8T3f=XGUIEng.GetCurrentWidgetID()
local K=XGUIEng.GetWidgetNameByID(XGUIEng.GetWidgetsMotherID(w8T3f))local qL=tonumber(K)local vfIyB=g_Interaction.TimerQuests[qL]
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/Update",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles/Update",1)
if not
(g_Interaction.CurrentMessageQuestIndex==vfIyB and not
QuestLog.IsQuestLogShown())then
ModuleDialogSystem.Local:ResetTimerButtons(GUI.GetPlayerID())end
GUI_Interaction.TimerButtonClicked_Orig_ModuleDialogSystem()end end
function ModuleDialogSystem.Local:StartDialog(quNsijN,QUh2tc)
if GUI.GetPlayerID()==quNsijN then
API.DeactivateNormalInterface()API.DeactivateBorderScroll()
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/Update",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles",1)XGUIEng.ShowWidget("/InGame/Root/3dWorldView",0)
Input.CutsceneMode()GUI.ClearSelection()
self.Dialog[quNsijN]=self.Dialog[quNsijN]or{}
self.Dialog[quNsijN].SubtitlesPosition={XGUIEng.GetWidgetScreenPosition("/InGame/Root/Normal/AlignBottomLeft/SubTitles")}
self.Dialog[quNsijN].Backup={Rotation=Camera.RTS_GetRotationAngle(),Zoom=Camera.RTS_GetZoomFactor(),Position={Camera.RTS_GetLookAtPosition()},Speed=Game.GameTimeGetFactor(quNsijN)}
if not QUh2tc.EnableFoW then Display.SetRenderFogOfWar(0)end;if not QUh2tc.EnableBorderPins then
Display.SetRenderBorderPins(0)end
if
not Framework.IsNetworkGame()then Game.GameTimeSetFactor(quNsijN,1)end end end
function ModuleDialogSystem.Local:EndDialog(qboV,nSBOx7)
if GUI.GetPlayerID()==qboV then
XGUIEng.SetText("/InGame/Root/Normal/AlignBottomLeft/SubTitles/VoiceText1","")XGUIEng.ShowWidget("/InGame/Root/3dWorldView",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/Update",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles/BG",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles/VoiceText1",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles/Update",0)Input.GameMode()
self:ResetSubtitlesPosition(qboV)Camera.RTS_FollowEntity(0)
if self.Dialog[qboV].Backup then
if
nSBOx7.RestoreCamera then
Camera.RTS_SetRotationAngle(self.Dialog[qboV].Backup.Rotation)
Camera.RTS_SetZoomFactor(self.Dialog[qboV].Backup.Zoom)
Camera.RTS_SetLookAtPosition(self.Dialog[qboV].Backup.Position[1],self.Dialog[qboV].Backup.Position[2])end;if
nSBOx7.RestoreGameSpeed and not Framework.IsNetworkGame()then
Game.GameTimeSetFactor(qboV,self.Dialog[qboV].Backup.Speed)end end;self.Dialog[qboV]=nil;API.ActivateNormalInterface()
API.ActivateBorderScroll()Display.SetRenderFogOfWar(1)
Display.SetRenderBorderPins(1)end end
function ModuleDialogSystem.Local:DisplayPage(u,K)
if GUI.GetPlayerID()==u then
GUI.ClearSelection()self.Dialog[u].PageData=K
if K.Sender~=-1 then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomLeft/Message",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/QuestLog",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/Update",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles/Update",1)self:ResetPlayerPortrait(K.Sender,K.Head)
self:ResetSubtitlesPosition(u)self:SetSubtitlesText(u)
self:SetSubtitlesPosition(u)else
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles/Update",1)self:ResetSubtitlesPosition(u)
self:SetSubtitlesText(u)self:SetSubtitlesPosition(u)end
if K.Title then local i1=API.ConvertPlaceholders(K.Title)
if
i1:find("^[A-Za-Z0-9_]+/[A-Za-Z0-9_]+$")then i1=XGUIEng.GetStringTableText(i1)end;if i1:sub(1,1)~="{"then i1="{center}"..i1 end
XGUIEng.SetText("/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait/PlayerName",i1)end;if K.Target then Camera.RTS_FollowEntity(GetID(K.Target))else
Camera.RTS_FollowEntity(0)end;if K.Position then
Camera.RTS_SetLookAtPosition(K.Position.X,K.Position.Y)end;if K.Zoom then
Camera.RTS_SetZoomFactor(K.Zoom)end;if K.Rotation then
Camera.RTS_SetRotationAngle(K.Rotation)end;if K.MC then
self:SetOptionsDialogContent(u)end end end
function ModuleDialogSystem.Local:SetSubtitlesText(zz1QI)
local kFTAh=self.Dialog[zz1QI].PageData;local LBf="/InGame/Root/Normal/AlignBottomLeft/SubTitles"
local dijn4Ph=API.ConvertPlaceholders(API.Localize(kFTAh.Text))local CO1=""
if
not self.Dialog[zz1QI].DisableSkipping and
not kFTAh.DisableSkipping and not kFTAh.MC then
CO1=API.ConvertPlaceholders(API.Localize(ModuleDialogSystem.Shared.Text.Continue))end
XGUIEng.SetText(LBf.."/VoiceText1",dijn4Ph..CO1)end
function ModuleDialogSystem.Local:SetSubtitlesPosition(RlZo)
local SUn=self.Dialog[RlZo].PageData;local Ib4="/InGame/Root/Normal/AlignBottomLeft/SubTitles"
local fjV1G2=XGUIEng.GetTextHeight(Ib4 .."/VoiceText1",true)
local Do,_=XGUIEng.GetWidgetSize(Ib4 .."/VoiceText1")local TqYJ4,DI=XGUIEng.GetWidgetLocalPosition(Ib4)
if
SUn.Sender~=-1 then
XGUIEng.SetWidgetSize(Ib4 .."/BG",Do+10,fjV1G2+120)DI=675-fjV1G2
XGUIEng.SetWidgetLocalPosition(Ib4,TqYJ4,DI)else
XGUIEng.SetWidgetSize(Ib4 .."/BG",Do+10,fjV1G2+35)DI=1115-fjV1G2
XGUIEng.SetWidgetLocalPosition(Ib4,46,DI)end end
function ModuleDialogSystem.Local:ResetPlayerPortrait(b,E)
local KMw7_i1s="/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait/3DPortraitFaceFX"local CQi=g_PlayerPortrait[b]
if E then if
not Models["Heads_"..tostring(E)]then E="H_NPC_Generic_Trader"end;CQi=E end
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)SetPortraitWithCameraSettings(KMw7_i1s,CQi)
GUI.PortraitWidgetSetRegister(KMw7_i1s,"Mood_Friendly",1,2,0)
GUI.PortraitWidgetSetRegister(KMw7_i1s,"Mood_Angry",1,2,0)end
function ModuleDialogSystem.Local:ResetSubtitlesPosition(nHlJ)
local lw4Q7kbl=self.Dialog[nHlJ].SubtitlesPosition;local IN="/InGame/Root/Normal/AlignBottomLeft/SubTitles"
XGUIEng.SetWidgetScreenPosition(IN,lw4Q7kbl[1],lw4Q7kbl[2])end
function ModuleDialogSystem.Local:SetOptionsDialogContent(QYf1)
local RfsnisO="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"local lvW2ga=self.Dialog[QYf1].PageData
local T7RKP=XGUIEng.GetWidgetID(RfsnisO.."/ListBox")XGUIEng.ListBoxPopAll(T7RKP)
self.Dialog[QYf1].MCSelectionOptionsMap={}
for _L6Bs=1,#lvW2ga.MC,1 do
if lvW2ga.MC[_L6Bs].Visible~=false then
XGUIEng.ListBoxPushItem(T7RKP,lvW2ga.MC[_L6Bs][1])
table.insert(self.Dialog[QYf1].MCSelectionOptionsMap,lvW2ga.MC[_L6Bs].ID)end end;XGUIEng.ListBoxSetSelectedIndex(T7RKP,0)
self:SetOptionsDialogPosition(QYf1)self.Dialog[QYf1].MCSelectionIsShown=true end
function ModuleDialogSystem.Local:SetOptionsDialogPosition(SH)
local wU4wYbA9={GUI.GetScreenSize()}
local fFeQcIM="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"local JEHSHPh3=self.Dialog[SH].PageData
self.Dialog[SH].MCSelectionBoxPosition={XGUIEng.GetWidgetScreenPosition(fFeQcIM)}
local bb={XGUIEng.GetWidgetScreenSize(fFeQcIM)}
local o5e6fP=math.ceil((wU4wYbA9[1]*0.06)+ (bb[1]/2))
local iq7ol=math.ceil(wU4wYbA9[2]-
(bb[2]+60* (wU4wYbA9[2]/540)))if JEHSHPh3.Sender==-1 then
o5e6fP=15* (wU4wYbA9[1]/960)
iq7ol=math.ceil(wU4wYbA9[2]-
(bb[2]+0* (wU4wYbA9[2]/540)))end
XGUIEng.SetWidgetScreenPosition(fFeQcIM,o5e6fP,iq7ol)XGUIEng.PushPage(fFeQcIM,false)
XGUIEng.ShowWidget(fFeQcIM,1)
if JEHSHPh3.Sender==-1 then local eMV="/InGame/Root/Normal/AlignBottomLeft/SubTitles"
local WDTNkTD,Oejsws=XGUIEng.GetWidgetLocalPosition(eMV)
XGUIEng.SetWidgetLocalPosition(eMV,WDTNkTD,Oejsws-220)end end
function ModuleDialogSystem.Local:OnOptionSelected(CkD73N0)
local PlwhaRKJ="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"local Caz4NM4Z=self.Dialog[CkD73N0].MCSelectionBoxPosition
XGUIEng.SetWidgetScreenPosition(PlwhaRKJ,Caz4NM4Z[1],Caz4NM4Z[2])XGUIEng.ShowWidget(PlwhaRKJ,0)XGUIEng.PopPage()
local XVxxx=XGUIEng.ListBoxGetSelectedIndex(
PlwhaRKJ.."/ListBox")+1
local hD=self.Dialog[CkD73N0].MCSelectionOptionsMap[XVxxx]
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.DialogOptionSelected,CkD73N0,hD)end
function ModuleDialogSystem.Local:ResetTimerButtons(G5BuU5)if GUI.GetPlayerID()~=G5BuU5 then
return end;local AfwsY="/InGame/Root/Normal/AlignTopLeft/QuestTimers/"
for T=1,6
do local WZs=AfwsY..T.."/TimerButton"
local ITdz=g_Interaction.TimerQuests[T]
if ITdz~=nil then local AjfoUo=Quests[ITdz]
if

g_Interaction.CurrentMessageQuestIndex==ITdz and not QuestLog.IsQuestLogShown()then g_Interaction.CurrentMessageQuestIndex=nil
g_VoiceMessageIsRunning=false;g_VoiceMessageEndTime=nil
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait",0)
XGUIEng.ShowWidget(QuestLog.Widget.Main,0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/SubTitles",0)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)XGUIEng.HighLightButton(WZs,0)end;if AjfoUo then
self:ResetPlayerPortrait(AjfoUo.SendingPlayer)end end end end
function ModuleDialogSystem.Local:IsAnyCinematicEventActive(Er9zidsB)
for X,dR in
pairs(ModuleDisplayCore.Local.CinematicEventStatus[Er9zidsB])do if dR==1 then return true end end;return false end
function ModuleDialogSystem.Local:Update()
for JFXtQwy=1,8 do
if GUI.GetPlayerID()==JFXtQwy and
self.Dialog[JFXtQwy]then
if self.Dialog[JFXtQwy].MCSelectionIsShown then
local uMV17h0="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"
if XGUIEng.IsWidgetShown(uMV17h0)==0 then
self.Dialog[JFXtQwy].MCSelectionIsShown=false;self:OnOptionSelected(JFXtQwy)end end end end end;Swift:RegisterModule(ModuleDialogSystem)