
ModuleLifestockBreeding={Properties={Name="ModuleLifestockBreeding"},Global={AnimalChildren={},GrothTime=45,ShrinkedSize=0.4,MinAmountNearby=2,AreaSizeNearby=3000,AllowBreedCattle=true,CattlePastures={},CattleBaby=true,CattleFeedingTimer=45,CattleMoneyCost=300,AllowBreedSheeps=true,SheepPastures={},SheepBaby=true,SheepFeedingTimer=45,SheepMoneyCost=300},Local={AllowBreedCattle=true,AllowBreedSheeps=true,Description={BreedingActive={Title={de="Zucht aktiv",en="Breeding active"},Text={de="- Klicken um Zucht zu stoppen",en="- Click to stop breeding"},Disabled={de="Zucht ist gesperrt!",en="Breeding is locked!"}},BreedingInactive={Title={de="Zucht gestoppt",en="Breeding stopped"},Text={de="- Klicken um Zucht zu starten {cr}- Benötigt Platz {cr}- Benötigt Getreide",en="- Click to allow breeding {cr}- Requires space {cr}- Requires grain"},Disabled={de="Zucht ist gesperrt!",en="Breeding is locked!"}}}}}
function ModuleLifestockBreeding.Global:OnGameStart()
MerchantSystem.BasePricesOrigModuleLifestockBreeding={}
MerchantSystem.BasePricesOrigModuleLifestockBreeding[Goods.G_Sheep]=MerchantSystem.BasePrices[Goods.G_Sheep]
MerchantSystem.BasePricesOrigModuleLifestockBreeding[Goods.G_Cow]=MerchantSystem.BasePrices[Goods.G_Cow]
MerchantSystem.BasePrices[Goods.G_Sheep]=ModuleLifestockBreeding.Global.SheepMoneyCost
MerchantSystem.BasePrices[Goods.G_Cow]=ModuleLifestockBreeding.Global.CattleMoneyCost
QSB.ScriptEvents.AnimalBred=API.RegisterScriptEvent("Event_AnimalBred")
StartSimpleJobEx(function()
ModuleLifestockBreeding.Global:AnimalBreedController()end)
StartSimpleJobEx(function()
ModuleLifestockBreeding.Global:AnimalGrouthController()end)end
function ModuleLifestockBreeding.Global:GetScale(QDnlt)local LmcA2auZ=GetID(QDnlt)
local Q=QSB.ScriptingValue.Size;local ZA=Logic.GetEntityScriptingValue(LmcA2auZ,Q)return
API.ConvertIntegerToFloat(ZA)end
function ModuleLifestockBreeding.Global:SetScale(_IQQ,XpkjA)local pVRj=GetID(_IQQ)
local fuZ3z86=QSB.ScriptingValue.Size;local er=API.ConvertFloatToInteger(XpkjA)
Logic.SetEntityScriptingValue(pVRj,fuZ3z86,er)end
function ModuleLifestockBreeding.Global:CreateAnimal(DFb100j,XL_,WYdR)
local QKKks_zt=Logic.EntityGetPlayer(DFb100j)local Are7xU,yxjl=Logic.GetBuildingApproachPosition(DFb100j)
local ZG=Entities.A_X_Sheep01
if not Framework.IsNetworkGame()then ZG=
(XL_==0 and Entities["A_X_Sheep0"..
math.random(1,2)])or ZG end;local Vu0cCAf=(XL_>0 and XL_)or ZG
local q=Logic.CreateEntity(Vu0cCAf,Are7xU,yxjl,0,QKKks_zt)if WYdR==true then self:SetScale(q,self.ShrinkedSize)
table.insert(self.AnimalChildren,{q,self.GrothTime})end
API.SendScriptEvent(QSB.ScriptEvents.AnimalBred,q)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.AnimalBred, %d)]],q))end
function ModuleLifestockBreeding.Global:BreedingTimeTillNext(kP7O5)
if
self.MinAmountNearby<=kP7O5 then local lqT=240- (kP7O5*15)if lqT<30 then lqT=30 end;return lqT end;return-1 end
function ModuleLifestockBreeding.Global:IsCattleNeeded(mP3mlD)
local PrPyxMK={Logic.GetPlayerEntitiesInCategory(mP3mlD,EntityCategories.CattlePasture)}
local tczrIB=Logic.GetNumberOfEntitiesOfTypeOfPlayer(mP3mlD,Entities.B_CattlePasture)return#PrPyxMK<tczrIB*5 end
function ModuleLifestockBreeding.Global:IsSheepNeeded(a)
local wqU76o={Logic.GetPlayerEntitiesInCategory(a,EntityCategories.SheepPasture)}
local LB1Z=Logic.GetNumberOfEntitiesOfTypeOfPlayer(a,Entities.B_SheepPasture)return#wqU76o<LB1Z*5 end
function ModuleLifestockBreeding.Global:CountCattleNearby(N9L)
local hDc_M=Logic.EntityGetPlayer(N9L)local qW0lRiD1,iD1IUx,JLCOx_ak=Logic.EntityGetPos(N9L)
local hPQ=self.AreaSizeNearby
local R1FIoQI={Logic.GetPlayerEntitiesInArea(hDc_M,Entities.A_X_Cow01,qW0lRiD1,iD1IUx,hPQ,16)}table.remove(R1FIoQI,1)return#R1FIoQI end
function ModuleLifestockBreeding.Global:CountSheepsNearby(NsoTwDs)
local HGli=Logic.EntityGetPlayer(NsoTwDs)local iy,m6SCS0,NUhYw6R4=Logic.EntityGetPos(NsoTwDs)
local Hv=self.AreaSizeNearby
local Ch={Logic.GetPlayerEntitiesInArea(HGli,Entities.A_X_Sheep01,iy,m6SCS0,Hv,16)}
local urkh={Logic.GetPlayerEntitiesInArea(HGli,Entities.A_X_Sheep02,iy,m6SCS0,Hv,16)}table.remove(Ch,1)table.remove(urkh,1)
return#Ch+#urkh end
function ModuleLifestockBreeding.Global:AnimalBreedController()
for zhzpBSx=1,8,1 do
if self.AllowBreedCattle then
local rHSjalVy=GetPlayerEntities(zhzpBSx,Entities.B_CattlePasture)
for TjhsnP,t5jzEd9 in pairs(rHSjalVy)do local JZAU2=self:CountCattleNearby(t5jzEd9)self.CattlePastures[t5jzEd9]=
self.CattlePastures[t5jzEd9]or 0
if

self:IsCattleNeeded(zhzpBSx)and Logic.IsBuildingStopped(t5jzEd9)==false then
self.CattlePastures[t5jzEd9]=self.CattlePastures[t5jzEd9]+1;local seMLr=self.CattleFeedingTimer
if

self.CattlePastures[t5jzEd9]>0 and seMLr>0 and Logic.GetTime()%seMLr==0 then
if GetPlayerResources(Goods.G_Grain,zhzpBSx)>0 then AddGood(Goods.G_Grain,
-1,zhzpBSx)else self.CattlePastures[t5jzEd9]=
self.CattlePastures[t5jzEd9]-seMLr end end end;local zPXTTg=self:BreedingTimeTillNext(JZAU2)
if zPXTTg>-1 and
self.CattlePastures[t5jzEd9]>zPXTTg then
if self:IsCattleNeeded(zhzpBSx)then
self:CreateAnimal(t5jzEd9,Entities.A_X_Cow01,self.CattleBaby)self.CattlePastures[t5jzEd9]=0 end end end end
if self.AllowBreedSheeps then
local qX=GetPlayerEntities(zhzpBSx,Entities.B_SheepPasture)
for h_8,xL7OTb in pairs(qX)do local w8T3f=self:CountSheepsNearby(xL7OTb)self.SheepPastures[xL7OTb]=
self.SheepPastures[xL7OTb]or 0
if self:IsSheepNeeded(zhzpBSx)and
Logic.IsBuildingStopped(xL7OTb)==false then self.SheepPastures[xL7OTb]=
self.SheepPastures[xL7OTb]+1;local qL=self.SheepFeedingTimer
if

self.SheepPastures[xL7OTb]>0 and qL>0 and Logic.GetTime()%qL==0 then
if GetPlayerResources(Goods.G_Grain,zhzpBSx)>0 then AddGood(Goods.G_Grain,
-1,zhzpBSx)else self.SheepPastures[xL7OTb]=
self.SheepPastures[xL7OTb]-qL end end end;local K=self:BreedingTimeTillNext(w8T3f)
if K>-1 and
self.SheepPastures[xL7OTb]>K then
if self:IsSheepNeeded(zhzpBSx)then
self:CreateAnimal(xL7OTb,0,self.SheepBaby)self.SheepPastures[xL7OTb]=0 end end end end end end
function ModuleLifestockBreeding.Global:AnimalGrouthController()
for vfIyB,quNsijN in
pairs(self.AnimalChildren)do
if quNsijN then
if not IsExisting(quNsijN[1])then
self.AnimalChildren[vfIyB]=nil else
self.AnimalChildren[vfIyB][2]=quNsijN[2]-1
if quNsijN[2]<0 then
self.AnimalChildren[vfIyB][2]=self.GrothTime;local QUh2tc=self:GetScale(quNsijN[1])
if QUh2tc<1 then self:SetScale(quNsijN[1],
QUh2tc+0.1)
local qboV=Logic.GetResourceDoodadGoodAmount(GetID(quNsijN[1]))if qboV~=0 then
Logic.SetResourceDoodadGoodAmount(GetID(quNsijN[1]),0)end else
self.AnimalChildren[vfIyB]=nil end end end end end end
function ModuleLifestockBreeding.Local:OnGameStart()
MerchantSystem.BasePricesOrigModuleLifestockBreeding={}
MerchantSystem.BasePricesOrigModuleLifestockBreeding[Goods.G_Sheep]=MerchantSystem.BasePrices[Goods.G_Sheep]
MerchantSystem.BasePricesOrigModuleLifestockBreeding[Goods.G_Cow]=MerchantSystem.BasePrices[Goods.G_Cow]
MerchantSystem.BasePrices[Goods.G_Sheep]=ModuleLifestockBreeding.Local.SheepMoneyCost
MerchantSystem.BasePrices[Goods.G_Cow]=ModuleLifestockBreeding.Local.CattleMoneyCost
QSB.ScriptEvents.AnimalBred=API.RegisterScriptEvent("Event_AnimalBred")self:InitBuyLifestockButton()end
function ModuleLifestockBreeding.Local:ToggleBreedingState(nSBOx7)
local u=Logic.GetEntityType(nSBOx7)
if u==Entities.B_CattlePasture then
GUI.SetStoppedState(nSBOx7,not
Logic.IsBuildingStopped(nSBOx7))elseif u==Entities.B_SheepPasture then
GUI.SetStoppedState(nSBOx7,not
Logic.IsBuildingStopped(nSBOx7))end end
function ModuleLifestockBreeding.Local:InitBuyLifestockButton()
HouseMenuStopProductionClicked_Orig_Stockbreeding=HouseMenuStopProductionClicked
HouseMenuStopProductionClicked=function()
HouseMenuStopProductionClicked_Orig_Stockbreeding()local i1=HouseMenu.Widget.CurrentBuilding;local zz1QI=Entities[i1]
local kFTAh=GUI.GetPlayerID()local LBf=HouseMenu.StopProductionBool
if zz1QI==Entities.B_CattleFarm then
local dijn4Ph=GetPlayerEntities(kFTAh,Entities.B_CattlePasture)
for CO1=1,#dijn4Ph,1 do GUI.SetStoppedState(dijn4Ph[CO1],LBf)end elseif zz1QI==Entities.B_SheepFarm then
local RlZo=GetPlayerEntities(kFTAh,Entities.B_SheepPasture)
for SUn=1,#RlZo,1 do GUI.SetStoppedState(RlZo[SUn],LBf)end end end
local K={XGUIEng.GetWidgetLocalPosition("/InGame/Root/Normal/BuildingButtons/BuyCatapultCart")}
API.AddBuildingButtonByTypeAtPosition(Entities.B_CattlePasture,K[1],K[2],function(Ib4,fjV1G2)
ModuleLifestockBreeding.Local:ToggleBreedingState(fjV1G2)end,function(Do,_)
local TqYJ4=API.Localize(ModuleLifestockBreeding.Local.Description.BreedingActive)if Logic.IsBuildingStopped(_)then
TqYJ4=API.Localize(ModuleLifestockBreeding.Local.Description.BreedingInactive)end
API.SetTooltipCosts(TqYJ4.Title,TqYJ4.Text,TqYJ4.Disabled,{Goods.G_Grain,1},false)end,function(DI,b)
local E={4,13}if Logic.IsBuildingStopped(b)then E={4,12}end
SetIcon(DI,E)local KMw7_i1s=
(ModuleLifestockBreeding.Local.AllowBreedCattle and 0)or 1
XGUIEng.DisableButton(DI,KMw7_i1s)end)
API.AddBuildingButtonByTypeAtPosition(Entities.B_SheepPasture,K[1],K[2],function(CQi,nHlJ)
ModuleLifestockBreeding.Local:ToggleBreedingState(nHlJ)end,function(lw4Q7kbl,IN)
local QYf1=API.Localize(ModuleLifestockBreeding.Local.Description.BreedingActive)if Logic.IsBuildingStopped(IN)then
QYf1=API.Localize(ModuleLifestockBreeding.Local.Description.BreedingInactive)end
API.SetTooltipCosts(QYf1.Title,QYf1.Text,QYf1.Disabled,{Goods.G_Grain,1},false)end,function(RfsnisO,lvW2ga)
local T7RKP={4,13}if Logic.IsBuildingStopped(lvW2ga)then T7RKP={4,12}end
SetIcon(RfsnisO,T7RKP)local _L6Bs=
(ModuleLifestockBreeding.Local.AllowBreedSheeps and 0)or 1
XGUIEng.DisableButton(RfsnisO,_L6Bs)end)end;Swift:RegisterModule(ModuleLifestockBreeding)