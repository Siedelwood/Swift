
ModuleMinimap={Properties={Name="ModuleMinimap"},Global={MarkerCounter=1000000,CreatedMinimapMarkers={}},Local={},Shared={}}function ModuleMinimap.Global:OnGameStart()end
function ModuleMinimap.Global:OnEvent(QDnlt,LmcA2auZ,...)
if
QDnlt==QSB.ScriptEvents.SaveGameLoaded then for Q,ZA in
pairs(self.CreatedMinimapMarkers)do
if ZA and ZA[4]~=7 then self:ShowMinimapMarker(Q)end end end end
function ModuleMinimap.Global:CreateMinimapMarker(_IQQ,XpkjA,pVRj,fuZ3z86,er)local DFb100j=self.MarkerCounter;self.MarkerCounter=
self.MarkerCounter+1
self.CreatedMinimapMarkers[DFb100j]={_IQQ,XpkjA,pVRj,fuZ3z86,er}self:ShowMinimapMarker(DFb100j)return DFb100j end
function ModuleMinimap.Global:DestroyMinimapMarker(XL_)
self.CreatedMinimapMarkers[XL_]=nil
Logic.ExecuteInLuaLocalState(string.format([[GUI.DestroyMinimapSignal(%d)]],XL_))end
function ModuleMinimap.Global:ShowMinimapMarker(WYdR)
local QKKks_zt=self.CreatedMinimapMarkers[WYdR]
Logic.ExecuteInLuaLocalState(string.format([[ModuleMinimap.Local:ShowMinimapMarker(%d, %d, %s, %f, %f, %d)]],WYdR,QKKks_zt[1],
(
type(QKKks_zt[2])=="table"and table.tostring(QKKks_zt[2]))or tostring(QKKks_zt[2]),QKKks_zt[3],QKKks_zt[4],QKKks_zt[5]))end;function ModuleMinimap.Local:OnGameStart()end
function ModuleMinimap.Local:ShowMinimapMarker(Are7xU,yxjl,ZG,Vu0cCAf,q,kP7O5)if
GUI.GetPlayerID()~=yxjl then return end;local lqT,mP3mlD,PrPyxMK,tczrIB=0,0,0,255
if
type(ZG)=="number"then lqT,mP3mlD,PrPyxMK=GUI.GetPlayerColor(ZG)else lqT=ZG[1]mP3mlD=ZG[2]
PrPyxMK=ZG[3]tczrIB=ZG[4]or tczrIB end
GUI.CreateMinimapSignalRGBA(Are7xU,Vu0cCAf,q,lqT,mP3mlD,PrPyxMK,tczrIB,kP7O5)end;Swift:RegisterModule(ModuleMinimap)