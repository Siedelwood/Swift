
ModuleExtendedCamera={Properties={Name="ModuleExtendedCamera"},Global={},Local={ExtendedZoomAllowed=true},Shared={}}function ModuleExtendedCamera.Global:OnGameStart()end
function ModuleExtendedCamera.Local:OnGameStart()
self:RegisterExtendedZoomHotkey()self:ActivateExtendedZoomHotkey()end
function ModuleExtendedCamera.Local:OnEvent(QDnlt,LmcA2auZ)
if
QDnlt==QSB.ScriptEvents.SaveGameLoaded then
if self.ExtendedZoomActive then self:ActivateExtendedZoom()end;self:ActivateExtendedZoomHotkey()end end
function ModuleExtendedCamera.Local:SetCameraToEntity(Q,ZA,_IQQ)local XpkjA=GetPosition(Q)
local pVRj=(ZA or-45)local fuZ3z86=(_IQQ or 0.5)
Camera.RTS_SetLookAtPosition(XpkjA.X,XpkjA.Y)Camera.RTS_SetRotationAngle(pVRj)
Camera.RTS_SetZoomFactor(fuZ3z86)end
function ModuleExtendedCamera.Local:RegisterExtendedZoomHotkey()
API.AddShortcut({de="STRG + SHIFT + K",en="CTRL + SHIFT + K"},{de="Alternativen Zoom ein/aus",en="Alternative zoom on/off"})end
function ModuleExtendedCamera.Local:ActivateExtendedZoomHotkey()
Input.KeyBindDown(Keys.ModifierControl+
Keys.ModifierShift+Keys.K,"ModuleExtendedCamera.Local:ToggleExtendedZoom()",2)end
function ModuleExtendedCamera.Local:ToggleExtendedZoom()if self.ExtendedZoomAllowed then
if self.ExtendedZoomActive then
self:DeactivateExtendedZoom()else self:ActivateExtendedZoom()end end end
function ModuleExtendedCamera.Local:ActivateExtendedZoom()
self.ExtendedZoomActive=true;Camera.RTS_SetZoomFactorMax(0.8701)
Camera.RTS_SetZoomFactor(0.8700)Camera.RTS_SetZoomFactorMin(0.0999)end
function ModuleExtendedCamera.Local:DeactivateExtendedZoom()
self.ExtendedZoomActive=false;Camera.RTS_SetZoomFactor(0.5000)
Camera.RTS_SetZoomFactorMax(0.5001)Camera.RTS_SetZoomFactorMin(0.0999)end;Swift:RegisterModule(ModuleExtendedCamera)