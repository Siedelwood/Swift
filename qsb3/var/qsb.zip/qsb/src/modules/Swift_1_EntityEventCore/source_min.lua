
ModuleEntityEventCore={Properties={Name="ModuleEntityEventCore"},Global={RegisteredEntities={},MineAmounts={},AttackedEntities={},OverkillEntities={},DisableThiefStorehouseHeist=false,DisableThiefCathedralSabotage=false,DisableThiefCisternSabotage=false,StaticSpawnerTypes={"B_NPC_BanditsHQ_ME","B_NPC_BanditsHQ_NA","B_NPC_BanditsHQ_NE","B_NPC_BanditsHQ_SE","B_NPC_BanditsHutBig_ME","B_NPC_BanditsHutBig_NA","B_NPC_BanditsHutBig_NE","B_NPC_BanditsHutBig_SE","B_NPC_BanditsHutSmall_ME","B_NPC_BanditsHutSmall_NA","B_NPC_BanditsHutSmall_NE","B_NPC_BanditsHutSmall_SE","B_NPC_Barracks_ME","B_NPC_Barracks_NA","B_NPC_Barracks_NE","B_NPC_Barracks_SE","B_NPC_BanditsHQ_AS","B_NPC_BanditsHutBig_AS","B_NPC_BanditsHutSmall_AS","B_NPC_Barracks_AS"},DynamicSpawnerTypes={"S_AxisDeer_AS","S_Deer_ME","S_FallowDeer_SE","S_Gazelle_NA","S_Herbs","S_Moose_NE","S_RawFish","S_Reindeer_NE","S_WildBoar","S_Zebra_NA"}},Local={}}
function ModuleEntityEventCore.Global:OnGameStart()
QSB.ScriptEvents.BuildingPlaced=API.RegisterScriptEvent("Event_BuildingPlaced")
QSB.ScriptEvents.SettlerArrived=API.RegisterScriptEvent("Event_SettlerArrived")
QSB.ScriptEvents.EntitySpawned=API.RegisterScriptEvent("Event_EntitySpawned")
QSB.ScriptEvents.EntityDestroyed=API.RegisterScriptEvent("Event_EntityDestroyed")
QSB.ScriptEvents.EntityHurt=API.RegisterScriptEvent("Event_EntityHurt")
QSB.ScriptEvents.EntityKilled=API.RegisterScriptEvent("Event_EntityKilled")
QSB.ScriptEvents.EntityOwnerChanged=API.RegisterScriptEvent("Event_EntityOwnerChanged")
QSB.ScriptEvents.EntityResourceChanged=API.RegisterScriptEvent("Event_EntityResourceChanged")
QSB.ScriptEvents.ThiefInfiltratedBuilding=API.RegisterScriptEvent("Event_ThiefInfiltratedBuilding")
QSB.ScriptEvents.ThiefDeliverEarnings=API.RegisterScriptEvent("Event_ThiefDeliverEarnings")
QSB.ScriptEvents.BuildingConstructed=API.RegisterScriptEvent("Event_BuildingConstructed")
QSB.ScriptEvents.BuildingUpgraded=API.RegisterScriptEvent("Event_BuildingUpgraded")self:StartTriggers()self:OverrideCallback()
self:OverrideLogic()
local QDnlt=Logic.CreateEntity(Entities.XD_ScriptEntity,5,5,0,0)Logic.DestroyEntity(QDnlt)end
function ModuleEntityEventCore.Global:OnEvent(LmcA2auZ,Q,...)
if
LmcA2auZ==QSB.ScriptEvents.SaveGameLoaded then self:OnSaveGameLoaded()elseif
LmcA2auZ==QSB.ScriptEvents.EntityHurt then self.AttackedEntities[arg[1]]={arg[3],100}end end
function ModuleEntityEventCore.Global:TriggerEntityOnwershipChangedEvent(ZA,_IQQ,XpkjA,pVRj)ZA=(
type(ZA)~="table"and{ZA})or ZA
XpkjA=(
type(XpkjA)~="table"and{XpkjA})or XpkjA
assert(#ZA==#XpkjA,"Sums of entities with changed owner does not add up!")
for fuZ3z86=1,#ZA do
API.SendScriptEvent(QSB.ScriptEvents.EntityOwnerChanged,ZA[fuZ3z86],_IQQ,XpkjA[fuZ3z86],pVRj)
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.EntityOwnerChanged, %d)",ZA[fuZ3z86],_IQQ,XpkjA[fuZ3z86],pVRj))end end;function ModuleEntityEventCore.Global:OnSaveGameLoaded()
self:OverrideLogic()end
function ModuleEntityEventCore.Global:CleanTaggedAndDeadEntities()
for er,DFb100j in
pairs(self.AttackedEntities)do
self.AttackedEntities[er][2]=DFb100j[2]-1
if DFb100j[2]<=0 then self.AttackedEntities[er]=nil else
if IsExisting(er)and
IsExisting(DFb100j[1])and Logic.IsKnight(er)then
if not
self.OverkillEntities[er]and
Logic.KnightGetResurrectionProgress(er)~=1 then
local XL_=Logic.EntityGetPlayer(er)local WYdR=Logic.EntityGetPlayer(DFb100j[1])
self:TriggerEntityKilledEvent(er,XL_,DFb100j[1],WYdR)self.OverkillEntities[er]=50
self.AttackedEntities[er]=nil end end end end
for QKKks_zt,Are7xU in pairs(self.OverkillEntities)do
self.OverkillEntities[QKKks_zt]=Are7xU-1
if Are7xU<=0 then self.OverkillEntities[QKKks_zt]=nil end end end
function ModuleEntityEventCore.Global:OverrideCallback()
GameCallback_EntityHurt_Orig_QSB_EntityCore=GameCallback_EntityHurt
GameCallback_EntityHurt=function(yxjl,ZG,Vu0cCAf,q)
GameCallback_EntityHurt_Orig_QSB_EntityCore(yxjl,ZG,Vu0cCAf,q)
API.SendScriptEvent(QSB.ScriptEvents.EntityHurt,yxjl,ZG,Vu0cCAf,q)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.EntityHurt, %d, %d, %d, %d)]],yxjl,ZG,Vu0cCAf,q))end;GameCallback_SettlerSpawned_Orig_QSB_EntityCore=GameCallback_SettlerSpawned
GameCallback_SettlerSpawned=function(kP7O5,lqT)
GameCallback_SettlerSpawned_Orig_QSB_EntityCore(kP7O5,lqT)
ModuleEntityEventCore.Global:TriggerSettlerArrivedEvent(lqT)end
GameCallback_OnBuildingConstructionComplete_Orig_QSB_EntityCore=GameCallback_OnBuildingConstructionComplete
GameCallback_OnBuildingConstructionComplete=function(mP3mlD,PrPyxMK)
GameCallback_OnBuildingConstructionComplete_Orig_QSB_EntityCore(mP3mlD,PrPyxMK)
ModuleEntityEventCore.Global:TriggerConstructionCompleteEvent(mP3mlD,PrPyxMK)end
GameCallback_FarmAnimalChangedPlayerID_Orig_QSB_EntityCore=GameCallback_FarmAnimalChangedPlayerID
GameCallback_FarmAnimalChangedPlayerID=function(tczrIB,a,wqU76o)
GameCallback_FarmAnimalChangedPlayerID_Orig_QSB_EntityCore(tczrIB,a,wqU76o)local LB1Z=Logic.EntityGetPlayer(wqU76o)
local N9L=Logic.EntityGetPlayer(a)
ModuleEntityEventCore.Global:TriggerEntityOnwershipChangedEvent(wqU76o,LB1Z,a,N9L)end;GameCallback_EntityCaptured_Orig_QSB_EntityCore=GameCallback_EntityCaptured
GameCallback_EntityCaptured=function(hDc_M,qW0lRiD1,iD1IUx,JLCOx_ak)
GameCallback_EntityCaptured_Orig_QSB_EntityCore(hDc_M,qW0lRiD1,iD1IUx,JLCOx_ak)
ModuleEntityEventCore.Global:TriggerEntityOnwershipChangedEvent(hDc_M,qW0lRiD1,iD1IUx,JLCOx_ak)end;GameCallback_CartFreed_Orig_QSB_EntityCore=GameCallback_CartFreed
GameCallback_CartFreed=function(hPQ,R1FIoQI,NsoTwDs,HGli)
GameCallback_CartFreed_Orig_QSB_EntityCore(hPQ,R1FIoQI,NsoTwDs,HGli)
ModuleEntityEventCore.Global:TriggerEntityOnwershipChangedEvent(hPQ,R1FIoQI,NsoTwDs,HGli)end
GameCallback_OnThiefDeliverEarnings_Orig_QSB_EntityCore=GameCallback_OnThiefDeliverEarnings
GameCallback_OnThiefDeliverEarnings=function(iy,m6SCS0,NUhYw6R4,Hv)
GameCallback_OnThiefDeliverEarnings_Orig_QSB_EntityCore(iy,m6SCS0,NUhYw6R4,Hv)local Ch=Logic.EntityGetPlayer(NUhYw6R4)
ModuleEntityEventCore.Global:TriggerThiefDeliverEarningsEvent(m6SCS0,iy,NUhYw6R4,Ch,Hv)end
GameCallback_OnThiefStealBuilding_Orig_QSB_EntityCore=GameCallback_OnThiefStealBuilding
GameCallback_OnThiefStealBuilding=function(urkh,zhzpBSx,rHSjalVy,TjhsnP)
ModuleEntityEventCore.Global:TriggerThiefStealFromBuildingEvent(urkh,zhzpBSx,rHSjalVy,TjhsnP)end
GameCallback_OnBuildingUpgradeFinished_Orig_QSB_EntityCore=GameCallback_OnBuildingUpgradeFinished
GameCallback_OnBuildingUpgradeFinished=function(t5jzEd9,JZAU2,zPXTTg)
GameCallback_OnBuildingUpgradeFinished_Orig_QSB_EntityCore(t5jzEd9,JZAU2,zPXTTg)
ModuleEntityEventCore.Global:TriggerUpgradeCompleteEvent(t5jzEd9,JZAU2,zPXTTg)end end
function ModuleEntityEventCore.Global:OverrideLogic()
self.Logic_ChangeEntityPlayerID=Logic.ChangeEntityPlayerID
Logic.ChangeEntityPlayerID=function(...)local seMLr=arg[1]
local qX=Logic.EntityGetPlayer(arg[1])
local h_8=self.Logic_ChangeEntityPlayerID(unpack(arg))local xL7OTb=Logic.EntityGetPlayer(h_8[1])
ModuleEntityEventCore.Global:TriggerEntityOnwershipChangedEvent(seMLr,qX,h_8,xL7OTb)return h_8 end;self.Logic_ChangeSettlerPlayerID=Logic.ChangeSettlerPlayerID
Logic.ChangeSettlerPlayerID=function(...)
local w8T3f={arg[1]}
w8T3f=Array_Append(w8T3f,API.GetGroupSoldiers(arg[1]))local K=Logic.EntityGetPlayer(arg[1])
local qL={self.Logic_ChangeSettlerPlayerID(unpack(arg))}
qL=Array_Append(qL,API.GetGroupSoldiers(qL[1]))local vfIyB=Logic.EntityGetPlayer(qL[1])
ModuleEntityEventCore.Global:TriggerEntityOnwershipChangedEvent(w8T3f,K,qL,vfIyB)return qL[1]end end
function ModuleEntityEventCore.Global:TriggerThiefDeliverEarningsEvent(quNsijN,QUh2tc,qboV,nSBOx7,u)
API.SendScriptEvent(QSB.ScriptEvents.ThiefDeliverEarnings,quNsijN,QUh2tc,qboV,nSBOx7,u)
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.ThiefDeliverEarnings, %d, %d, %d, %d, %d)",quNsijN,QUh2tc,qboV,nSBOx7,u))end
function ModuleEntityEventCore.Global:TriggerThiefStealFromBuildingEvent(K,i1,zz1QI,kFTAh)
local LBf=Logic.GetHeadquarters(kFTAh)local dijn4Ph=Logic.GetCathedral(kFTAh)
local CO1=Logic.GetStoreHouse(kFTAh)
local RlZo=Logic.IsEntityInCategory(CO1,EntityCategories.VillageStorehouse)==0;local SUn=Logic.GetEntityType(zz1QI)
if CO1 ==zz1QI and
(not RlZo or LBf==0)then if not self.DisableThiefStorehouseHeist then
GameCallback_OnThiefStealBuilding_Orig_QSB_EntityCore(K,i1,zz1QI,kFTAh)end end
if dijn4Ph==zz1QI then if not self.DisableThiefCathedralSabotage then
GameCallback_OnThiefStealBuilding_Orig_QSB_EntityCore(K,i1,zz1QI,kFTAh)end end
if
Framework.GetGameExtraNo()>0 and SUn==Entities.B_Cistern then if not self.DisableThiefCisternSabotage then
GameCallback_OnThiefStealBuilding_Orig_QSB_EntityCore(K,i1,zz1QI,kFTAh)end end
API.SendScriptEvent(QSB.ScriptEvents.ThiefInfiltratedBuilding,K,i1,zz1QI,kFTAh)
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.ThiefInfiltratedBuilding, %d, %d, %d, %d)",K,i1,zz1QI,kFTAh))end
function ModuleEntityEventCore.Global:TriggerEntitySpawnedEvent(Ib4,fjV1G2)
API.SendScriptEvent(QSB.ScriptEvents.EntitySpawned,Ib4,fjV1G2)
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.EntityArrived, %d, %d)",Ib4,fjV1G2))end
function ModuleEntityEventCore.Global:TriggerSettlerArrivedEvent(Do)
API.SendScriptEvent(QSB.ScriptEvents.SettlerArrived,Do)
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.SettlerArrived, %d)",Do))end
function ModuleEntityEventCore.Global:TriggerEntityDestroyedEvent(_)
API.SendScriptEvent(QSB.ScriptEvents.EntityDestroyed,_)
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.EntityDestroyed, %d)",_))end
function ModuleEntityEventCore.Global:TriggerEntityKilledEvent(TqYJ4,DI,b,E)
API.SendScriptEvent(QSB.ScriptEvents.EntityKilled,TqYJ4,DI,b,E)
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.EntityKilled, %d, %d, %d, %d)",TqYJ4,DI,b,E))end
function ModuleEntityEventCore.Global:TriggerConstructionCompleteEvent(KMw7_i1s,CQi)
API.SendScriptEvent(QSB.ScriptEvents.BuildingConstructed,KMw7_i1s,CQi)
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.BuildingConstructed, %d, %d)",KMw7_i1s,CQi))end
function ModuleEntityEventCore.Global:TriggerUpgradeCompleteEvent(nHlJ,lw4Q7kbl,IN)
API.SendScriptEvent(QSB.ScriptEvents.BuildingUpgraded,nHlJ,lw4Q7kbl,IN)
Logic.ExecuteInLuaLocalState(string.format("API.SendScriptEvent(QSB.ScriptEvents.BuildingUpgraded, %d, %d, %d)",nHlJ,lw4Q7kbl,IN))end
function ModuleEntityEventCore.Global:StartTriggers()
function ModuleEntityEventCore_Trigger_EveryTurn()if
Logic.GetCurrentTurn()>0 then
ModuleEntityEventCore.Global:CleanTaggedAndDeadEntities()
ModuleEntityEventCore.Global:CheckOnSpawnerEntities()end end
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,"","ModuleEntityEventCore_Trigger_EveryTurn",1)
function ModuleEntityEventCore_Trigger_EntityDestroyed()local QYf1=Event.GetEntityID()
local RfsnisO=Event.GetPlayerID()
if ModuleEntityEventCore.Global.AttackedEntities[QYf1]~=
nil then
local lvW2ga=ModuleEntityEventCore.Global.AttackedEntities[QYf1][1]local T7RKP=Logic.EntityGetPlayer(lvW2ga)ModuleEntityEventCore.Global.AttackedEntities[QYf1]=
nil
ModuleEntityEventCore.Global:TriggerEntityKilledEvent(QYf1,RfsnisO,lvW2ga,T7RKP)end end
Trigger.RequestTrigger(Events.LOGIC_EVENT_ENTITY_DESTROYED,"","ModuleEntityEventCore_Trigger_EntityDestroyed",1)
function ModuleEntityEventCore_Trigger_MineWatch()
local _L6Bs={Entities.R_IronMine,Entities.R_StoneMine}
for SH=1,#_L6Bs do local wU4wYbA9=Logic.GetEntitiesOfType(_L6Bs[SH])
for fFeQcIM=1,#wU4wYbA9
do local JEHSHPh3=self.MineAmounts[wU4wYbA9[fFeQcIM]]
local bb=Logic.GetResourceDoodadGoodAmount(wU4wYbA9[fFeQcIM])
if JEHSHPh3 and bb and JEHSHPh3 ~=bb then
local o5e6fP=Logic.GetResourceDoodadGoodType(wU4wYbA9[fFeQcIM])
API.SendScriptEvent(QSB.ScriptEvents.EntityResourceChanged,wU4wYbA9[fFeQcIM],o5e6fP,JEHSHPh3,bb)
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.EntityResourceChanged, %d, %d, %d, %d)]],wU4wYbA9[fFeQcIM],o5e6fP,JEHSHPh3,bb))end;self.MineAmounts[wU4wYbA9[fFeQcIM]]=bb end end end
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_SECOND,"","ModuleEntityEventCore_Trigger_MineWatch",1)end
function ModuleEntityEventCore.Global:CheckOnSpawnerEntities()local iq7ol={}
for eMV=1,#self.DynamicSpawnerTypes
do
if Entities[self.DynamicSpawnerTypes[eMV]]then
if
Logic.GetCurrentTurn()%10 ==eMV then
for WDTNkTD,Oejsws in
pairs(Logic.GetEntitiesOfType(Entities[self.DynamicSpawnerTypes[eMV]]))do table.insert(iq7ol,Oejsws)end end end end
for CkD73N0=1,#self.StaticSpawnerTypes do
if
Entities[self.StaticSpawnerTypes[CkD73N0]]then
if Logic.GetCurrentTurn()%10 ==CkD73N0 then
for PlwhaRKJ,Caz4NM4Z in
pairs(Logic.GetEntitiesOfType(Entities[self.StaticSpawnerTypes[CkD73N0]]))do table.insert(iq7ol,Caz4NM4Z)end end end end
for XVxxx=1,#iq7ol do
for hD,G5BuU5 in
pairs{Logic.GetSpawnedEntities(iq7ol[XVxxx])}do
if not self.RegisteredEntities[G5BuU5]then
self:TriggerEntitySpawnedEvent(G5BuU5,iq7ol[XVxxx])self.RegisteredEntities[G5BuU5]=iq7ol[XVxxx]end end end end
function ModuleEntityEventCore.Local:OnGameStart()
QSB.ScriptEvents.BuildingPlaced=API.RegisterScriptEvent("Event_BuildingPlaced")
QSB.ScriptEvents.SettlerArrived=API.RegisterScriptEvent("Event_SettlerArrived")
QSB.ScriptEvents.EntitySpawned=API.RegisterScriptEvent("Event_EntitySpawned")
QSB.ScriptEvents.EntityDestroyed=API.RegisterScriptEvent("Event_EntityDestroyed")
QSB.ScriptEvents.EntityHurt=API.RegisterScriptEvent("Event_EntityHurt")
QSB.ScriptEvents.EntityKilled=API.RegisterScriptEvent("Event_EntityKilled")
QSB.ScriptEvents.EntityOwnerChanged=API.RegisterScriptEvent("Event_EntityOwnerChanged")
QSB.ScriptEvents.EntityResourceChanged=API.RegisterScriptEvent("Event_EntityResourceChanged")
QSB.ScriptEvents.ThiefInfiltratedBuilding=API.RegisterScriptEvent("Event_ThiefInfiltratedBuilding")
QSB.ScriptEvents.ThiefDeliverEarnings=API.RegisterScriptEvent("Event_ThiefDeliverEarnings")
QSB.ScriptEvents.BuildingConstructed=API.RegisterScriptEvent("Event_BuildingConstructed")
QSB.ScriptEvents.BuildingUpgraded=API.RegisterScriptEvent("Event_BuildingUpgraded")self:OverrideAfterBuildingPlacement()end
function ModuleEntityEventCore.Local:OverrideAfterBuildingPlacement()
GameCallback_GUI_AfterBuildingPlacement_Orig_EntityEventCore=GameCallback_GUI_AfterBuildingPlacement
GameCallback_GUI_AfterBuildingPlacement=function()
GameCallback_GUI_AfterBuildingPlacement_Orig_EntityEventCore()local AfwsY,T=GUI.Debug_GetMapPositionUnderMouse()
API.StartHiResDelay(0,function()
local WZs={Logic.GetPlayerEntitiesInArea(GUI.GetPlayerID(),0,AfwsY,T,50,16)}
for ITdz=2,WZs[1]+1 do
if WZs[ITdz]and WZs[ITdz]~=0 and
Logic.IsBuilding(WZs[ITdz])==1 then
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.BuildingPlaced,WZs[ITdz])
API.SendScriptEvent(QSB.ScriptEvents.BuildingPlaced,WZs[ITdz])end end end,AfwsY,T)end end
function ModuleEntityEventCore.Local:OnEvent(AjfoUo,Er9zidsB,...)end;Swift:RegisterModule(ModuleEntityEventCore)