
ModuleBriefingSystem={Properties={Name="ModuleBriefingSystem"},Global={Briefing={},BriefingQueue={},BriefingCounter=0},Local={Briefing={}},Shared={Text={NextButton={de="Weiter",en="Forward"},PrevButton={de="Zurück",en="Previous"},EndButton={de="Beenden",en="Close"}}}}QSB.CinematicEventTypes.Briefing=2
QSB.Briefing={TIMER_PER_CHAR=0.175,CAMERA_ANGLEDEFAULT=43,CAMERA_ROTATIONDEFAULT=-45,CAMERA_ZOOMDEFAULT=6500,CAMERA_FOVDEFAULT=42,DLGCAMERA_ANGLEDEFAULT=27,DLGCAMERA_ROTATIONDEFAULT=-45,DLGCAMERA_ZOOMDEFAULT=1750,DLGCAMERA_FOVDEFAULT=25}
function ModuleBriefingSystem.Global:OnGameStart()
QSB.ScriptEvents.BriefingStarted=API.RegisterScriptEvent("Event_BriefingStarted")
QSB.ScriptEvents.BriefingEnded=API.RegisterScriptEvent("Event_BriefingEnded")
QSB.ScriptEvents.BriefingPageShown=API.RegisterScriptEvent("Event_BriefingPageShown")
QSB.ScriptEvents.BriefingOptionSelected=API.RegisterScriptEvent("Event_BriefingOptionSelected")
QSB.ScriptEvents.BriefingLeftClick=API.RegisterScriptEvent("Event_BriefingLeftClick")
QSB.ScriptEvents.BriefingSkipButtonPressed=API.RegisterScriptEvent("Event_BriefingSkipButtonPressed")for QDnlt=1,8 do self.BriefingQueue[QDnlt]={}end
API.StartHiResJob(function()
ModuleBriefingSystem.Global:UpdateQueue()
ModuleBriefingSystem.Global:BriefingExecutionController()end)end
function ModuleBriefingSystem.Global:OnEvent(LmcA2auZ,Q,...)
if
LmcA2auZ==QSB.ScriptEvents.EscapePressed then elseif LmcA2auZ==QSB.ScriptEvents.BriefingStarted then
self:NextPage(arg[1])elseif LmcA2auZ==QSB.ScriptEvents.BriefingEnded then
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.BriefingEnded, %d, %s)]],arg[1],table.tostring(arg[2])))elseif LmcA2auZ==QSB.ScriptEvents.BriefingPageShown then
local ZA=self.Briefing[arg[1]][arg[2]]if type(ZA)=="table"then ZA=table.tostring(ZA)end
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.BriefingPageShown, %d, %d, %s)]],arg[1],arg[2],ZA))elseif LmcA2auZ==QSB.ScriptEvents.BriefingOptionSelected then
self:OnOptionSelected(arg[1],arg[2])elseif LmcA2auZ==QSB.ScriptEvents.BriefingSkipButtonPressed then
self:SkipButtonPressed(arg[1])end end
function ModuleBriefingSystem.Global:UpdateQueue()
for _IQQ=1,8 do
if self:CanStartBriefing(_IQQ)then
local XpkjA=ModuleDisplayCore.Global:LookUpCinematicInFromQueue(_IQQ)
if
XpkjA and XpkjA[1]==QSB.CinematicEventTypes.Briefing then self:NextBriefing(_IQQ)end end end end
function ModuleBriefingSystem.Global:BriefingExecutionController()
for pVRj=1,8 do
if self.Briefing[pVRj]and not
self.Briefing[pVRj].DisplayIngameCutscene then
local fuZ3z86=self.Briefing[pVRj].CurrentPage;local er=self.Briefing[pVRj][fuZ3z86]
if
er and er.Duration>0 then if(er.Started+er.Duration)<Logic.GetTime()then
self:NextPage(pVRj)end end end end end
function ModuleBriefingSystem.Global:StartBriefing(DFb100j,XL_,WYdR)self.BriefingQueue[XL_]=
self.BriefingQueue[XL_]or{}self.BriefingCounter=
(self.BriefingCounter or 0)+1
WYdR.BriefingName="Briefing #"..self.BriefingCounter
ModuleDisplayCore.Global:PushCinematicEventToQueue(XL_,QSB.CinematicEventTypes.Briefing,DFb100j,WYdR)end
function ModuleBriefingSystem.Global:EndBriefing(QKKks_zt)
Logic.SetGlobalInvulnerability(0)if self.Briefing[QKKks_zt].Finished then
self.Briefing[QKKks_zt]:Finished()end
API.FinishCinematicEvent(self.Briefing[QKKks_zt].Name,QKKks_zt)
API.SendScriptEvent(QSB.ScriptEvents.BriefingEnded,QKKks_zt,self.Briefing[QKKks_zt])self.Briefing[QKKks_zt]=nil end
function ModuleBriefingSystem.Global:NextBriefing(Are7xU)
if self:CanStartBriefing(Are7xU)then
local yxjl=ModuleDisplayCore.Global:PopCinematicEventFromQueue(Are7xU)
assert(yxjl[1]==QSB.CinematicEventTypes.Briefing)API.StartCinematicEvent(yxjl[2],Are7xU)local ZG=yxjl[3]
ZG.Name=yxjl[2]ZG.PlayerID=Are7xU;ZG.CurrentPage=0;if ZG.EnableSoothingCamera==nil then
ZG.EnableSoothingCamera=true end;self.Briefing[Are7xU]=ZG
self:TransformAnimations(Are7xU)
if ZG.EnableGlobalImmortality then Logic.SetGlobalInvulnerability(1)end;if self.Briefing[Are7xU].Starting then
self.Briefing[Are7xU]:Starting()end
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.BriefingStarted, %d, %s)]],Are7xU,table.tostring(self.Briefing[Are7xU])))
API.SendScriptEvent(QSB.ScriptEvents.BriefingStarted,Are7xU,self.Briefing[Are7xU])end end
function ModuleBriefingSystem.Global:TransformAnimations(Vu0cCAf)
if
self.Briefing[Vu0cCAf].PageAnimations then
for q,kP7O5 in pairs(self.Briefing[Vu0cCAf].PageAnimations)do
local lqT=self:GetPageIDByName(Vu0cCAf,q)
if lqT~=0 then
self.Briefing[Vu0cCAf][lqT].Animations={}self.Briefing[Vu0cCAf][lqT].Animations.PurgeOld=
kP7O5.PurgeOld==true
for mP3mlD=1,#kP7O5,1 do
if
#kP7O5[mP3mlD]==9 then
table.insert(self.Briefing[Vu0cCAf][lqT].Animations,{Duration=
kP7O5[mP3mlD][9]or(2*60),Start={Position=(type(kP7O5[mP3mlD][1])~="table"and
{kP7O5[mP3mlD][1],0})or
kP7O5[mP3mlD][1],Rotation=kP7O5[mP3mlD][2],Zoom=kP7O5[mP3mlD][3],Angle=kP7O5[mP3mlD][4]},End={Position=
(
type(kP7O5[mP3mlD][5])~="table"and{kP7O5[mP3mlD][5],0})or kP7O5[mP3mlD][5],Rotation=kP7O5[mP3mlD][6],Zoom=kP7O5[mP3mlD][7],Angle=kP7O5[mP3mlD][8]}})elseif#kP7O5[mP3mlD]==5 then
table.insert(self.Briefing[Vu0cCAf][lqT].Animations,{Duration=
kP7O5[mP3mlD][5]or(2*60),Start={Position=(type(kP7O5[mP3mlD][1])~="table"and
{kP7O5[mP3mlD][1],0})or
kP7O5[mP3mlD][1],LookAt=
(
type(kP7O5[mP3mlD][2])~="table"and{kP7O5[mP3mlD][1],0})or kP7O5[mP3mlD][2]},End={Position=
(
type(kP7O5[mP3mlD][3])~="table"and{kP7O5[mP3mlD][5],0})or kP7O5[mP3mlD][3],LookAt=
(
type(kP7O5[mP3mlD][4])~="table"and{kP7O5[mP3mlD][1],0})or kP7O5[mP3mlD][4]}})end end end end;self.Briefing[Vu0cCAf].PageAnimations=nil end end
function ModuleBriefingSystem.Global:NextPage(PrPyxMK)if
self.Briefing[PrPyxMK]==nil then return end;self.Briefing[PrPyxMK].CurrentPage=
self.Briefing[PrPyxMK].CurrentPage+1
local tczrIB=self.Briefing[PrPyxMK].CurrentPage
if tczrIB==-1 or tczrIB==0 then self:EndBriefing(PrPyxMK)return end;local a=self.Briefing[PrPyxMK][tczrIB]
if
type(a)=="table"then
if tczrIB<=#self.Briefing[PrPyxMK]then
self.Briefing[PrPyxMK][tczrIB].Started=Logic.GetTime()
self.Briefing[PrPyxMK][tczrIB].Duration=a.Duration or-1;if self.Briefing[PrPyxMK][tczrIB].Action then
self.Briefing[PrPyxMK][tczrIB]:Action()end
self:DisplayPage(PrPyxMK,tczrIB)else self:EndBriefing(PrPyxMK)end elseif type(a)=="number"or type(a)=="string"then
local wqU76o=self:GetPageIDByName(PrPyxMK,self.Briefing[PrPyxMK][tczrIB])self.Briefing[PrPyxMK].CurrentPage=wqU76o-1
self:NextPage(PrPyxMK)else self:EndBriefing(PrPyxMK)end end
function ModuleBriefingSystem.Global:DisplayPage(LB1Z,N9L)if
self.Briefing[LB1Z]==nil then return end
local hDc_M=self.Briefing[LB1Z][N9L]
if type(hDc_M)=="table"then
local qW0lRiD1=self.Briefing[LB1Z].CurrentPage
if hDc_M.MC then
for iD1IUx=1,#hDc_M.MC,1 do if
type(hDc_M.MC[iD1IUx][3])=="function"then
self.Briefing[LB1Z][qW0lRiD1].MC[iD1IUx].Visible=hDc_M.MC[iD1IUx][3](LB1Z,qW0lRiD1,iD1IUx)end end end end
API.SendScriptEvent(QSB.ScriptEvents.BriefingPageShown,LB1Z,N9L,self.Briefing[LB1Z][N9L])end
function ModuleBriefingSystem.Global:SkipButtonPressed(JLCOx_ak,hPQ)if
not self.Briefing[JLCOx_ak]then return end
local R1FIoQI=self.Briefing[JLCOx_ak].CurrentPage;if self.Briefing[JLCOx_ak][R1FIoQI].OnForward then
self.Briefing[JLCOx_ak][R1FIoQI]:OnForward()end
self:NextPage(JLCOx_ak)end
function ModuleBriefingSystem.Global:OnOptionSelected(NsoTwDs,HGli)if
self.Briefing[NsoTwDs]==nil then return end
local iy=self.Briefing[NsoTwDs].CurrentPage;if
type(self.Briefing[NsoTwDs][iy])~="table"then return end
local m6SCS0=self.Briefing[NsoTwDs][iy]
if m6SCS0.MC then local NUhYw6R4;for Hv=1,#m6SCS0.MC,1 do if m6SCS0.MC[Hv].ID==HGli then
NUhYw6R4=m6SCS0.MC[Hv]end end
if NUhYw6R4 ~=
nil then local Ch=NUhYw6R4[2]if type(NUhYw6R4[2])=="function"then
Ch=NUhYw6R4[2](NsoTwDs,iy,HGli)end
self.Briefing[NsoTwDs][iy].MC.Selected=NUhYw6R4.ID
self.Briefing[NsoTwDs].CurrentPage=self:GetPageIDByName(NsoTwDs,Ch)-1;self:NextPage(NsoTwDs)end end end;function ModuleBriefingSystem.Global:GetCurrentBriefing(urkh)
return self.Briefing[urkh]end
function ModuleBriefingSystem.Global:GetCurrentBriefingPage(zhzpBSx)
if
self.Briefing[zhzpBSx]then local rHSjalVy=self.Briefing[zhzpBSx].CurrentPage;return
self.Briefing[zhzpBSx][rHSjalVy]end end
function ModuleBriefingSystem.Global:GetPageIDByName(TjhsnP,t5jzEd9)
if type(t5jzEd9)=="string"then
if
self.Briefing[TjhsnP]~=nil then
for JZAU2=1,#self.Briefing[TjhsnP],1 do if
type(self.Briefing[TjhsnP][JZAU2])=="table"and
self.Briefing[TjhsnP][JZAU2].Name==t5jzEd9 then
return JZAU2 end end end;return 0 end;return t5jzEd9 end
function ModuleBriefingSystem.Global:CanStartBriefing(zPXTTg)return


self.Briefing[zPXTTg]==nil and not API.IsCinematicEventActive(zPXTTg)and not API.IsLoadscreenVisible()end
function ModuleBriefingSystem.Local:OnGameStart()
QSB.ScriptEvents.BriefingStarted=API.RegisterScriptEvent("Event_BriefingStarted")
QSB.ScriptEvents.BriefingEnded=API.RegisterScriptEvent("Event_BriefingEnded")
QSB.ScriptEvents.BriefingPageShown=API.RegisterScriptEvent("Event_BriefingPageShown")
QSB.ScriptEvents.BriefingOptionSelected=API.RegisterScriptEvent("Event_BriefingOptionSelected")
QSB.ScriptEvents.BriefingLeftClick=API.RegisterScriptEvent("Event_BriefingLeftClick")
QSB.ScriptEvents.BriefingSkipButtonPressed=API.RegisterScriptEvent("Event_BriefingSkipButtonPressed")self:OverrideThroneRoomFunctions()end
function ModuleBriefingSystem.Local:OnEvent(seMLr,qX,...)
if
seMLr==QSB.ScriptEvents.EscapePressed then elseif seMLr==QSB.ScriptEvents.BriefingStarted then
self:StartBriefing(arg[1],arg[2])elseif seMLr==QSB.ScriptEvents.BriefingEnded then
self:EndBriefing(arg[1],arg[2])elseif seMLr==QSB.ScriptEvents.BriefingPageShown then
self:DisplayPage(arg[1],arg[2],arg[3])elseif seMLr==QSB.ScriptEvents.BriefingSkipButtonPressed then
self:SkipButtonPressed(arg[1])end end
function ModuleBriefingSystem.Local:StartBriefing(h_8,xL7OTb)if GUI.GetPlayerID()~=h_8 then
return end;self.Briefing[h_8]=xL7OTb
self.Briefing[h_8].LastSkipButtonPressed=0;self.Briefing[h_8].CurrentPage=0
API.DeactivateNormalInterface()API.DeactivateBorderScroll()
if
not Framework.IsNetworkGame()then Game.GameTimeSetFactor(h_8,1)end;self:ActivateCinematicMode(h_8)end
function ModuleBriefingSystem.Local:EndBriefing(w8T3f,K)if GUI.GetPlayerID()~=w8T3f then
return end;if not Framework.IsNetworkGame()then
Game.GameTimeSetFactor(w8T3f,1)end
self:DeactivateCinematicMode(w8T3f)API.ActivateNormalInterface()
API.ActivateBorderScroll()self.Briefing[w8T3f]=nil
Display.SetRenderFogOfWar(1)Display.SetRenderBorderPins(1)
Display.SetRenderSky(0)end
function ModuleBriefingSystem.Local:DisplayPage(qL,vfIyB,quNsijN)
if GUI.GetPlayerID()~=qL then return end;self.Briefing[qL][vfIyB]=quNsijN;self.Briefing[qL].AnimationQueue=
self.Briefing[qL].AnimationQueue or{}
self.Briefing[qL].CurrentPage=vfIyB
if type(self.Briefing[qL][vfIyB])=="table"then
self.Briefing[qL][vfIyB].Started=Logic.GetTime()self:DisplayPageBars(qL,vfIyB)
self:DisplayPageTitle(qL,vfIyB)self:DisplayPageText(qL,vfIyB)
self:DisplayPageControls(qL,vfIyB)self:DisplayPageAnimations(qL,vfIyB)
self:DisplayPageFader(qL,vfIyB)self:DisplayPagePortraits(qL,vfIyB)
self:DisplayPageSplashScreen(qL,vfIyB)if self.Briefing[qL][vfIyB].MC then
self:DisplayPageOptionsDialog(qL,vfIyB)end end end
function ModuleBriefingSystem.Local:DisplayPageBars(QUh2tc,qboV)
local nSBOx7=self.Briefing[QUh2tc][qboV]local u=
(nSBOx7.BarOpacity~=nil and nSBOx7.BarOpacity)or 1;local K=(255*u)
local i1=(255*u)local zz1QI=(nSBOx7.BigBars and 1)or 0;local kFTAh=
(nSBOx7.BigBars and 0)or 1;if u==0 then zz1QI=0;kFTAh=0 end
XGUIEng.ShowWidget("/InGame/ThroneRoomBars",zz1QI)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",kFTAh)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",zz1QI)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",kFTAh)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars/BarBottom",1,K)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars/BarTop",1,K)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars_2/BarBottom",1,i1)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars_2/BarTop",1,i1)end
function ModuleBriefingSystem.Local:DisplayPageTitle(LBf,dijn4Ph)
local CO1=self.Briefing[LBf][dijn4Ph]local RlZo="/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight"
XGUIEng.SetText(RlZo,"")
if CO1.Title then local SUn=API.ConvertPlaceholders(CO1.Title)
if
SUn:find("^[A-Za-Z0-9_]+/[A-Za-Z0-9_]+$")then SUn=XGUIEng.GetStringTableText(SUn)end;if SUn:sub(1,1)~="{"then
SUn="{@color:255,250,0,255}{center}"..SUn end;XGUIEng.SetText(RlZo,SUn)end end
function ModuleBriefingSystem.Local:DisplayPageText(Ib4,fjV1G2)
local Do=self.Briefing[Ib4][fjV1G2]local _="/InGame/ThroneRoom/Main/MissionBriefing/Text"
XGUIEng.SetText(_,"")
if Do.Text then local TqYJ4=API.ConvertPlaceholders(Do.Text)
if
TqYJ4:find("^[A-Za-Z0-9_]+/[A-Za-Z0-9_]+$")then TqYJ4=XGUIEng.GetStringTableText(TqYJ4)end
if TqYJ4:sub(1,1)~="{"then TqYJ4="{center}"..TqYJ4 end
if not Do.BigBars then TqYJ4="{cr}{cr}{cr}"..TqYJ4 end;XGUIEng.SetText(_,TqYJ4)end end
function ModuleBriefingSystem.Local:DisplayPageControls(DI,b)
local E=self.Briefing[DI][b]local KMw7_i1s=1
KMw7_i1s=((E.Duration==nil or E.Duration==-1)and
1)or 0;if E.DisableSkipping~=nil then
KMw7_i1s=(E.DisableSkipping and 0)or 1 end;if E.MC~=nil then KMw7_i1s=0 end
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip",KMw7_i1s)end
function ModuleBriefingSystem.Local:DisplayPageAnimations(CQi,nHlJ)
local lw4Q7kbl=self.Briefing[CQi][nHlJ]
if lw4Q7kbl.Animations then if lw4Q7kbl.Animations.PurgeOld then self.Briefing[CQi].CurrentAnimation=
nil
self.Briefing[CQi].AnimationQueue={}end;for IN=1,#lw4Q7kbl.Animations,1
do local QYf1=table.copy(lw4Q7kbl.Animations[IN])
table.insert(self.Briefing[CQi].AnimationQueue,QYf1)end end end
function ModuleBriefingSystem.Local:DisplayPageFader(RfsnisO,lvW2ga)
local T7RKP=self.Briefing[RfsnisO][lvW2ga]g_Fade.To=T7RKP.FaderAlpha or 0;local _L6Bs=T7RKP.FadeIn;if _L6Bs then
FadeIn(_L6Bs)end;local SH=T7RKP.FadeOut
if SH then
self.Briefing[RfsnisO].FaderJob=API.StartHiResJob(function(wU4wYbA9,fFeQcIM)if
Logic.GetTimeMs()>wU4wYbA9- (fFeQcIM*1000)then
FadeOut(fFeQcIM)return true end end,
Logic.GetTimeMs()+ ((T7RKP.Duration or 0)*1000),SH)end end
function ModuleBriefingSystem.Local:DisplayPagePortraits(JEHSHPh3,bb)
local o5e6fP=self.Briefing[JEHSHPh3][bb]if o5e6fP.Portrait then self:SetPagePortraits(JEHSHPh3,bb)else
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1,0)end end
function ModuleBriefingSystem.Local:SetPagePortraits(iq7ol,eMV,WDTNkTD,Oejsws,CkD73N0,PlwhaRKJ,Caz4NM4Z,XVxxx)
local hD=self.Briefing[iq7ol][eMV]
if type(hD.Portrait)=="table"then
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1,255)
XGUIEng.SetMaterialTexture("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1,XVxxx or hD.Portrait.Image)
XGUIEng.SetWidgetPositionAndSize("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",0,0,400,600)
XGUIEng.SetMaterialUV("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1,WDTNkTD or 0,Oejsws or 0,CkD73N0 or 1,PlwhaRKJ or 1)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1,Caz4NM4Z or 1)else
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1,255)
XGUIEng.SetMaterialTexture("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1,XVxxx or hD.Portrait)
XGUIEng.SetWidgetPositionAndSize("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",0,0,400,600)
XGUIEng.SetMaterialUV("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1,WDTNkTD or 0,Oejsws or 0,CkD73N0 or 1,PlwhaRKJ or 1)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1,Caz4NM4Z or 1)end end
function ModuleBriefingSystem.Local:AnimatePortrait(G5BuU5)
local AfwsY=self.Briefing[G5BuU5].CurrentPage;local T=self.Briefing[G5BuU5][AfwsY]
local WZs="/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG"
if type(T.Portrait)=="table"then local ITdz,AjfoUo,Er9zidsB,X,dR,JFXtQwy=0,0,1,1,255,nil;if
type(T.Portrait.Animation)=="function"then
ITdz,AjfoUo,Er9zidsB,X,dR,JFXtQwy=T.Portrait.Animation(T)end
self:SetPagePortraits(G5BuU5,AfwsY,ITdz,AjfoUo,Er9zidsB,X,dR,JFXtQwy)end end
function ModuleBriefingSystem.Local:DisplayPageSplashScreen(uMV17h0,E2NZK)
local WNWWe=self.Briefing[uMV17h0][E2NZK]if WNWWe.Splashscreen then self:SetPageSplashScreen(uMV17h0,E2NZK)else
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/BG",1,0)end end
function ModuleBriefingSystem.Local:SetPageSplashScreen(zMzjn3lk,Trkkpmd,L,GGv,ZIzh4Si,c8D4n81,cSjJHx,fa)
local M=self.Briefing[zMzjn3lk][Trkkpmd]local dIZlrvD="/InGame/ThroneRoom/KnightInfo/BG"
local jQgsATKd={GUI.GetScreenSize()}local aBbGg,D9,G,gE=L or 0,GGv or 0,ZIzh4Si or 1,c8D4n81 or 1;if jQgsATKd[1]/
jQgsATKd[2]<1.6 then aBbGg=aBbGg+ (aBbGg/0.125)G=G- (G*
0.125)end
if
type(M.Splashscreen)=="table"then
XGUIEng.SetMaterialAlpha(dIZlrvD,0,cSjJHx or 255)
XGUIEng.SetMaterialTexture(dIZlrvD,0,fa or M.Splashscreen.Image)XGUIEng.SetMaterialUV(dIZlrvD,0,aBbGg,D9,G,gE)else XGUIEng.SetMaterialAlpha(dIZlrvD,0,
cSjJHx or 255)
XGUIEng.SetMaterialTexture(dIZlrvD,0,
fa or M.Splashscreen)XGUIEng.SetMaterialUV(dIZlrvD,0,aBbGg,D9,G,gE)end end
function ModuleBriefingSystem.Local:AnimateSplashScreen(QgC)
local CYoa=self.Briefing[QgC].CurrentPage;local K3ipRr=self.Briefing[QgC][CYoa]
if
type(K3ipRr.Splashscreen)=="table"then local F2tY,rb21L2,o_v255,wUVm,VQ,oTYNsnP=0,0,1,1,255,nil;if
type(K3ipRr.Splashscreen.Animation)=="function"then
F2tY,rb21L2,o_v255,wUVm,VQ,oTYNsnP=K3ipRr.Splashscreen.Animation(K3ipRr)end
self:SetPageSplashScreen(QgC,CYoa,F2tY,rb21L2,o_v255,wUVm,VQ,oTYNsnP)end end
function ModuleBriefingSystem.Local:DisplayPageOptionsDialog(I,L)
local mR5gwW="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"local DfbW={GUI.GetScreenSize()}
local sh=self.Briefing[I][L]
local rrFLbCtj=XGUIEng.GetWidgetID(mR5gwW.."/ListBox")
self.Briefing[I].MCSelectionBoxPosition={XGUIEng.GetWidgetScreenPosition(mR5gwW)}XGUIEng.ListBoxPopAll(rrFLbCtj)
self.Briefing[I].MCSelectionOptionsMap={}
for inx0=1,#sh.MC,1 do
if sh.MC[inx0].Visible~=false then
XGUIEng.ListBoxPushItem(rrFLbCtj,sh.MC[inx0][1])
table.insert(self.Briefing[I].MCSelectionOptionsMap,sh.MC[inx0].ID)end end;XGUIEng.ListBoxSetSelectedIndex(rrFLbCtj,0)
local YcPea0vg={XGUIEng.GetWidgetScreenSize(mR5gwW)}
local usLpLoaH=math.ceil((DfbW[1]/2)- (YcPea0vg[1]/2))
local e7dv=math.ceil(DfbW[2]- (YcPea0vg[2]-10))
if sh.Text and sh.Text~=""then e7dv=math.ceil((DfbW[2]/2)-
(YcPea0vg[2]/2))end
XGUIEng.SetWidgetScreenPosition(mR5gwW,usLpLoaH,e7dv)XGUIEng.PushPage(mR5gwW,false)
XGUIEng.ShowWidget(mR5gwW,1)self.Briefing[I].MCSelectionIsShown=true end
function ModuleBriefingSystem.Local:OnOptionSelected(A5k5yt)
local B7SHDx7h="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"local EEpoeR=self.Briefing[A5k5yt].MCSelectionBoxPosition
XGUIEng.SetWidgetScreenPosition(B7SHDx7h,EEpoeR[1],EEpoeR[2])XGUIEng.ShowWidget(B7SHDx7h,0)XGUIEng.PopPage()
local _k=XGUIEng.ListBoxGetSelectedIndex(
B7SHDx7h.."/ListBox")+1
local Ef=self.Briefing[A5k5yt].MCSelectionOptionsMap[_k]
API.SendScriptEvent(QSB.ScriptEvents.BriefingOptionSelected,A5k5yt,Ef)
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.BriefingOptionSelected,A5k5yt,Ef)end
function ModuleBriefingSystem.Local:ThroneRoomCameraControl(KfM,Vd)
if Vd then
if
self.Briefing[KfM].CurrentAnimation then local nN=Logic.GetTime()
local J=self.Briefing[KfM].CurrentAnimation
if nN>J.Started+J.Duration then if
#self.Briefing[KfM].AnimationQueue>0 then
self.Briefing[KfM].CurrentAnimation=nil end end end
if self.Briefing[KfM].CurrentAnimation==nil then
if

self.Briefing[KfM].AnimationQueue and#self.Briefing[KfM].AnimationQueue>0 then
local A=table.remove(self.Briefing[KfM].AnimationQueue,1)A.Started=Logic.GetTime()
self.Briefing[KfM].CurrentAnimation=A end end;local Oynw,QBO,s4ggux=self:GetPagePosition(KfM)
local hrVI4meU,xEq6TAF,UIjls=self:GetPageLookAt(KfM)if Oynw and not hrVI4meU then
hrVI4meU,xEq6TAF,UIjls,Oynw,QBO,s4ggux,FOV=self:GetCameraProperties(KfM)end
Camera.ThroneRoom_SetPosition(Oynw,QBO,s4ggux)
Camera.ThroneRoom_SetLookAt(hrVI4meU,xEq6TAF,UIjls)Camera.ThroneRoom_SetFOV(FOV)
self:AnimatePortrait(KfM)self:AnimateSplashScreen(KfM)
if
self.Briefing[KfM].MCSelectionIsShown then
local g3Qeqnr="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"
if XGUIEng.IsWidgetShown(g3Qeqnr)==0 then
self.Briefing[KfM].MCSelectionIsShown=false;self:OnOptionSelected(KfM)end end
local jdLnB0vD=API.Localize(ModuleBriefingSystem.Shared.Text.NextButton)local PSlD=self.Briefing[KfM].CurrentPage;if PSlD==#
self.Briefing[KfM]or
self.Briefing[KfM][PSlD+1]==-1 then
jdLnB0vD=API.Localize(ModuleBriefingSystem.Shared.Text.EndButton)end
XGUIEng.SetText("/InGame/ThroneRoom/Main/Skip",
"{center}"..jdLnB0vD)end end
function ModuleBriefingSystem.Local:GetPagePosition(qHpY64)local zqccJ5b,ARuba
if
self.Briefing[qHpY64].CurrentAnimation then
zqccJ5b=self.Briefing[qHpY64].CurrentAnimation.Start.Position
ARuba=self.Briefing[qHpY64].CurrentAnimation.End.Position end;local Wo53nZ,XRfQ,gFPRdEC=self:ConvertPosition(zqccJ5b)
if ARuba then
local lw9gLt3,T,I5=self:ConvertPosition(ARuba.Position)
if lw9gLt3 then
Wo53nZ=Wo53nZ+ (lw9gLt3-Wo53nZ)*self:GetLERP(qHpY64)
XRfQ=XRfQ+ (T-XRfQ)*self:GetLERP(qHpY64)
gFPRdEC=gFPRdEC+ (I5-gFPRdEC)*self:GetLERP(qHpY64)end end;return Wo53nZ,XRfQ,gFPRdEC end
function ModuleBriefingSystem.Local:GetPageLookAt(JmE)local s4,FFG;if
self.Briefing[JmE].CurrentAnimation then
s4=self.Briefing[JmE].CurrentAnimation.Start.LookAt
FFG=self.Briefing[JmE].CurrentAnimation.End.LookAt end
local a31jEAS,LS4h,eux092_P=self:ConvertPosition(s4)
if FFG and a31jEAS then local ZA9,hWgmxm,UBg54E=self:ConvertPosition(FFG.LookAt)
if
ZA9 then
a31jEAS=a31jEAS+ (ZA9-a31jEAS)*self:GetLERP(JmE)
LS4h=LS4h+ (hWgmxm-LS4h)*self:GetLERP(JmE)
eux092_P=eux092_P+ (UBg54E-eux092_P)*self:GetLERP(JmE)end end;return a31jEAS,LS4h,eux092_P end
function ModuleBriefingSystem.Local:GetCameraProperties(gQGq)local OyHc5FEv,Dn1Xi;if
self.Briefing[gQGq].CurrentAnimation then
OyHc5FEv=self.Briefing[gQGq].CurrentAnimation.Start
Dn1Xi=self.Briefing[gQGq].CurrentAnimation.End end
local _gGmBBE=OyHc5FEv.Position
local rIX4=(Dn1Xi and Dn1Xi.Position)or OyHc5FEv.Position;local AI14eFhp=OyHc5FEv.Rotation;local iW2O=(Dn1Xi and Dn1Xi.Rotation)or
OyHc5FEv.Rotation;local Gdp=OyHc5FEv.Angle
local nbqmx=(
Dn1Xi and Dn1Xi.Angle)or OyHc5FEv.Angle;local IWQcC=OyHc5FEv.Zoom
local cvRh=(Dn1Xi and Dn1Xi.Zoom)or OyHc5FEv.Zoom;local W9yaJm=(OyHc5FEv.FOV)or 42.0
local oJ1ec=(
(Dn1Xi and Dn1Xi.FOV)or OyHc5FEv.FOV)or 42.0;local L=self:GetLERP(gQGq)
local MMNWLk,x6Ni,Q2waXkyp=self:ConvertPosition(_gGmBBE)local EG72,mlTMZ,q=self:ConvertPosition(rIX4)local xb6=MMNWLk+
(EG72-MMNWLk)*L
local yK=x6Ni+ (mlTMZ-x6Ni)*L;local rHLz2GD=Q2waXkyp+ (q-Q2waXkyp)*L;local BlW0RhJA=W9yaJm+
(oJ1ec-W9yaJm)*L
local Uy=IWQcC+ (cvRh-IWQcC)*L;local n=Gdp+ (nbqmx-Gdp)*L;local TKu=AI14eFhp+
(iW2O-AI14eFhp)*L
local M6kL=Uy*math.cos(math.rad(n))
local M7o_=xb6+math.cos(math.rad(TKu-90))*M6kL
local dk2X7J7=yK+math.sin(math.rad(TKu-90))*M6kL
local jv=rHLz2GD+ (Uy)*math.sin(math.rad(n))return xb6,yK,rHLz2GD,M7o_,dk2X7J7,jv,BlW0RhJA end
function ModuleBriefingSystem.Local:ConvertPosition(MW)local E2OQ,SnbfLb6,ay
if MW and MW[3]then
E2OQ=MW[1]SnbfLb6=MW[2]ay=MW[3]elseif MW and not MW[3]then
E2OQ,SnbfLb6,ay=Logic.EntityGetPos(GetID(MW[1]))ay=ay+ (MW[2]or 0)end;return E2OQ,SnbfLb6,ay end
function ModuleBriefingSystem.Local:GetLERP(W)
if self.Briefing[W].CurrentAnimation then
local WzM=self.Briefing[W].CurrentAnimation;local PSx=Logic.GetTime()local I=Framework.GetTimeMs()
local wnA=Game.GameTimeGetFactor(GUI.GetPlayerID())local cW=API.LERP(WzM.Started,PSx,WzM.Duration)
if
self.Briefing[W].EnableCameraSoothing then
if WzM.LastLogicTime~=PSx then WzM.LastLogicTime=PSx;WzM.LastFrameworkTime=I end
cW=cW+math.max(
(I-WzM.LastFrameworkTime)/WzM.Duration/1000*wnA,0)end;return math.min(cW,1)end;return 1 end
function ModuleBriefingSystem.Local:SkipButtonPressed(PHpCof2,bUPpn4T2)if
not self.Briefing[PHpCof2]then return end;if
(self.Briefing[PHpCof2].LastSkipButtonPressed+500)<Logic.GetTimeMs()then
self.Briefing[PHpCof2].LastSkipButtonPressed=Logic.GetTimeMs()end end;function ModuleBriefingSystem.Local:GetCurrentBriefing(sode)
return self.Briefing[sode]end
function ModuleBriefingSystem.Local:GetCurrentBriefingPage(G9zkKODk)if
self.Briefing[G9zkKODk]then local MGt=self.Briefing[G9zkKODk].CurrentPage;return
self.Briefing[G9zkKODk][MGt]end end
function ModuleBriefingSystem.Local:GetPageIDByName(ld9GuG4t,KpCCA)
if type(KpCCA)=="string"then
if
self.Briefing[ld9GuG4t]~=nil then for H6=1,#self.Briefing[ld9GuG4t],1 do
if
type(self.Briefing[ld9GuG4t][H6])=="table"and
self.Briefing[ld9GuG4t][H6].Name==KpCCA then return H6 end end end;return 0 end;return KpCCA end
function ModuleBriefingSystem.Local:OverrideThroneRoomFunctions()
GameCallback_Camera_ThroneRoomLeftClick_Orig_ModuleBriefingSystem=GameCallback_Camera_ThroneRoomLeftClick
GameCallback_Camera_ThroneRoomLeftClick=function(hgsKvTz)
GameCallback_Camera_ThroneRoomLeftClick_Orig_ModuleBriefingSystem(hgsKvTz)
if hgsKvTz==GUI.GetPlayerID()then
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.BriefingLeftClick,hgsKvTz)
API.SendScriptEvent(QSB.ScriptEvents.BriefingLeftClick,hgsKvTz)end end
GameCallback_Camera_SkipButtonPressed_Orig_ModuleBriefingSystem=GameCallback_Camera_SkipButtonPressed
GameCallback_Camera_SkipButtonPressed=function(zEt)
GameCallback_Camera_SkipButtonPressed_Orig_ModuleBriefingSystem(zEt)
if zEt==GUI.GetPlayerID()then
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.BriefingSkipButtonPressed,zEt)
API.SendScriptEvent(QSB.ScriptEvents.BriefingSkipButtonPressed,zEt)end end
GameCallback_Camera_ThroneroomCameraControl_Orig_ModuleBriefingSystem=GameCallback_Camera_ThroneroomCameraControl
GameCallback_Camera_ThroneroomCameraControl=function(Wjojpvg)
GameCallback_Camera_ThroneroomCameraControl_Orig_ModuleBriefingSystem(Wjojpvg)
if Wjojpvg==GUI.GetPlayerID()then
local l2PqbWw=ModuleBriefingSystem.Local:GetCurrentBriefing(Wjojpvg)if l2PqbWw~=nil then
ModuleBriefingSystem.Local:ThroneRoomCameraControl(Wjojpvg,ModuleBriefingSystem.Local:GetCurrentBriefingPage(Wjojpvg))end end end;GameCallback_Escape_Orig_BriefingSystem=GameCallback_Escape
GameCallback_Escape=function()if
ModuleBriefingSystem.Local.Briefing[GUI.GetPlayerID()]then return end
GameCallback_Escape_Orig_BriefingSystem()end end
function ModuleBriefingSystem.Local:ActivateCinematicMode(EJTH9)
if self.CinematicActive or
GUI.GetPlayerID()~=EJTH9 then return end;self.CinematicActive=true;local qTB82=API.IsLoadscreenVisible()if qTB82 then
XGUIEng.PopPage()end;local KL,EATFLbgY=GUI.GetScreenSize()
XGUIEng.ShowWidget("/InGame/ThroneRoom",1)
XGUIEng.PushPage("/InGame/ThroneRoom/KnightInfo",false)XGUIEng.PushPage("/InGame/ThroneRoomBars",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_2",false)
XGUIEng.PushPage("/InGame/ThroneRoom/Main",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_Dodge",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_2_Dodge",false)
XGUIEng.PushPage("/InGame/ThroneRoom/KnightInfo/LeftFrame",false)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/StartButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/Frame",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/DialogBG",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/FrameEdges",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogBottomRight3pcs",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/KnightInfoButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/BackButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Briefing",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/TitleContainer",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/MissionBriefing/Text",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/MissionBriefing/Title",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/MissionBriefing/Objectives",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/updater",1)
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Text"," ")
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Title"," ")
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Objectives"," ")
local FF,rh=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight")
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",FF,65* (EATFLbgY/1080))
XGUIEng.SetWidgetPositionAndSize("/InGame/ThroneRoom/KnightInfo/Objectives",2,0,2000,20)
XGUIEng.ShowAllSubWidgets("/InGame/ThroneRoom/KnightInfo",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/Text",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/BG",1)
XGUIEng.SetText("/InGame/ThroneRoom/KnightInfo/Text"," ")
XGUIEng.SetWidgetPositionAndSize("/InGame/ThroneRoom/KnightInfo/Text",200,300,1000,10)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/BG",1)
XGUIEng.SetMaterialColor("/InGame/ThroneRoom/KnightInfo/BG",0,255,255,255,0)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/BG",0,0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/LeftFrame",1)
XGUIEng.ShowAllSubWidgets("/InGame/ThroneRoom/KnightInfo/LeftFrame",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",1)
XGUIEng.SetWidgetPositionAndSize("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",0,0,400,600)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/LeftFrame/KnightBG",0,0)GUI.ClearSelection()GUI.ClearNotes()
GUI.ForbidContextSensitiveCommandsInSelectionState()GUI.ActivateCutSceneState()
GUI.SetFeedbackSoundOutputState(0)GUI.EnableBattleSignals(false)
Input.CutsceneMode()if not self.Briefing[EJTH9].EnableFoW then
Display.SetRenderFogOfWar(0)end;if self.Briefing[EJTH9].EnableSky then
Display.SetRenderSky(1)end
if
not self.Briefing[EJTH9].EnableBorderPins then Display.SetRenderBorderPins(0)end;Display.SetUserOptionOcclusionEffect(0)
Camera.SwitchCameraBehaviour(5)InitializeFader()g_Fade.To=0;SetFaderAlpha(0)if qTB82 then
XGUIEng.PushPage("/LoadScreen/LoadScreen",false)end end
function ModuleBriefingSystem.Local:DeactivateCinematicMode(YcCR)
if not self.CinematicActive or
GUI.GetPlayerID()~=YcCR then return end;self.CinematicActive=false;g_Fade.To=0;SetFaderAlpha(0)
XGUIEng.PopPage()Camera.SwitchCameraBehaviour(0)
Display.UseStandardSettings()Input.GameMode()GUI.EnableBattleSignals(true)
GUI.SetFeedbackSoundOutputState(1)GUI.ActivateSelectionState()
GUI.PermitContextSensitiveCommandsInSelectionState()Display.SetRenderSky(0)
Display.SetRenderBorderPins(1)Display.SetRenderFogOfWar(1)if
Options.GetIntValue("Display","Occlusion",0)>0 then
Display.SetUserOptionOcclusionEffect(1)end
XGUIEng.PopPage()XGUIEng.PopPage()XGUIEng.PopPage()
XGUIEng.PopPage()XGUIEng.PopPage()XGUIEng.PopPage()
XGUIEng.PopPage()XGUIEng.ShowWidget("/InGame/ThroneRoom",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars",0)XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",0)end;Swift:RegisterModule(ModuleBriefingSystem)