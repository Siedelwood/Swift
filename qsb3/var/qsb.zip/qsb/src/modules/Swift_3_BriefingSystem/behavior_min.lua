
function Reprisal_Briefing(...)return B_Reprisal_Briefing:new(...)end
B_Reprisal_Briefing={Name="Reprisal_Briefing",Description={en="Reprisal: Calls a function to start an new briefing.",de="Lohn: Ruft die Funktion auf und startet das enthaltene Briefing."},Parameter={{ParameterType.Default,en="Briefing name",de="Name des Briefing"},{ParameterType.Default,en="Briefing function",de="Funktion mit Briefing"}}}
function B_Reprisal_Briefing:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_Briefing:AddParameter(QDnlt,LmcA2auZ)if(QDnlt==0)then self.BriefingName=LmcA2auZ elseif
(QDnlt==1)then self.Function=LmcA2auZ end end;function B_Reprisal_Briefing:CustomFunction(Q)
_G[self.Function](self.BriefingName,Q.ReceivingPlayer)end
function B_Reprisal_Briefing:Debug(ZA)
if
self.BriefingName==nil or self.BriefingName==""then
error(string.format("%s: %s: Dialog name is invalid!",ZA.Identifier,self.Name))return true end
if not type(_G[self.Function])=="function"then
error(
ZA.Identifier..": "..
self.Name..": '"..self.Function.."' was not found!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_Briefing)function Reward_Briefing(...)return
B_Reward_Briefing:new(...)end
B_Reward_Briefing=Swift:CopyTable(B_Reprisal_Briefing)B_Reward_Briefing.Name="Reward_Briefing"
B_Reward_Briefing.Description.en="Reward: Calls a function to start an new briefing."
B_Reward_Briefing.Description.de="Lohn: Ruft die Funktion auf und startet das enthaltene Briefing."B_Reward_Briefing.GetReprisalTable=nil
B_Reward_Briefing.GetRewardTable=function(_IQQ,XpkjA)return
{Reward.Custom,{_IQQ,_IQQ.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_Briefing)function Trigger_Briefing(...)return
B_Trigger_Briefing:new(...)end
B_Trigger_Briefing={Name="Trigger_Briefing",Description={en="Trigger: Checks if an briefing has concluded and starts the quest if so.",de="Auslöser: Prüft, ob ein Briefing beendet ist und startet dann den Quest."},Parameter={{ParameterType.Default,en="Briefing name",de="Name des Briefing"},{ParameterType.PlayerID,en="Player ID",de="Player ID"},{ParameterType.Number,en="Wait time",de="Wartezeit"}}}
function B_Trigger_Briefing:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function B_Trigger_Briefing:AddParameter(pVRj,fuZ3z86)
if(pVRj==0)then self.BriefingName=fuZ3z86 elseif(pVRj==1)then self.PlayerID=
fuZ3z86*1 elseif(pVRj==2)then fuZ3z86=fuZ3z86 or 0
self.WaitTime=fuZ3z86*1 end end
function B_Trigger_Briefing:CustomFunction(er)
if

API.GetCinematicEventStatus(self.BriefingName,self.PlayerID)==QSB.CinematicEventStatus.Concluded then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end;return false end
function B_Trigger_Briefing:Debug(DFb100j)if self.WaitTime<0 then
error(string.format("%s: %s: Wait time must be 0 or greater!",DFb100j.Identifier,self.Name))return true end
if
self.PlayerID<1 or self.PlayerID>8 then
error(string.format("%s: %s: Player-ID must be between 1 and 8!",DFb100j.Identifier,self.Name))return true end
if self.BriefingName==nil or self.BriefingName==""then
error(string.format("%s: %s: Dialog name is invalid!",DFb100j.Identifier,self.Name))return true end;return false end;Swift:RegisterBehavior(B_Trigger_Briefing)