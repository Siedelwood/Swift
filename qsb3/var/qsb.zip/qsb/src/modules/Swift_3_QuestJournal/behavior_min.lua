QSB.JournalEntryNameToQuestName={}QSB.JournalEntryNameToID={}function Reprisal_JournalEnable(...)return
B_Reprisal_JournalEnable:new(...)end
B_Reprisal_JournalEnable={Name="Reprisal_JournalEnable",Description={en="Reprisal: Displays the journal for a quest or hides it.",de="Vergeltung: Zeigt das Tagebuch für einen Quest an oder versteckt es."},Parameter={{ParameterType.QuestName,en="Quest name",de="Name Quest"},{ParameterType.Custom,en="Journal active",de="Tagebuch aktiv"}}}
function B_Reprisal_JournalEnable:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_JournalEnable:AddParameter(QDnlt,LmcA2auZ)
if(QDnlt==0)then self.QuestName=LmcA2auZ elseif
(QDnlt==1)then self.ActiveFlag=API.ToBoolean(LmcA2auZ)end end;function B_Reprisal_JournalEnable:CustomFunction(Q)
API.ShowJournalForQuest(self.QuestName,self.ActiveFlag==true)end
function B_Reprisal_JournalEnable:Debug(ZA)
if

not API.IsValidQuest(GetQuestID(self.QuestName))then
error(ZA.Identifier..
": "..self.Name..": quest '"..
tostring(self.QuestName).."' does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_JournalEnable)function Reward_JournalEnable(...)return
B_Reward_JournalEnable:new(...)end
B_Reward_JournalEnable=Swift:CopyTable(B_Reprisal_JournalEnable)B_Reward_JournalEnable.Name="Reward_JournalEnable"
B_Reward_JournalEnable.Description.en="Reward: Displays the journal for a quest or hides it."
B_Reward_JournalEnable.Description.de="Lohn: Zeigt das Tagebuch für einen Quest an oder versteckt es."B_Reward_JournalEnable.GetReprisalTable=nil
B_Reward_JournalEnable.GetRewardTable=function(_IQQ,XpkjA)return
{Reward.Custom,{_IQQ,_IQQ.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_JournalEnable)function Reprisal_JournalWrite(...)return
B_Reprisal_JournalWrite:new(...)end
B_Reprisal_JournalWrite={Name="Reprisal_JournalWrite",Description={en="Reprisal: Adds or alters a journal entry to a quest.",de="Lohn: Schreibt oder ändert einen Tagebucheintrag."},Parameter={{ParameterType.QuestName,en="Quest name",de="Name Quest"},{ParameterType.Default,en="Entry name",de="Name Eintrag"},{ParameterType.Default,en="Entry text",de="Text Eintrag"}}}
function B_Reprisal_JournalWrite:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_JournalWrite:AddParameter(pVRj,fuZ3z86)
if(pVRj==0)then self.QuestName=fuZ3z86 elseif(pVRj==1)then
self.EntryName=fuZ3z86 elseif(pVRj==2)then self.EntryText=fuZ3z86 end end
function B_Reprisal_JournalWrite:CustomFunction(er)
if
QSB.JournalEntryNameToQuestName[self.EntryName]then local DFb100j=QSB.JournalEntryNameToID[self.EntryName]
API.AlterJournalEntry(DFb100j,self.EntryText)else local XL_=API.CreateJournalEntry(self.EntryText)
API.AddJournalEntryToQuest(XL_,self.QuestName)
QSB.JournalEntryNameToQuestName[self.EntryName]=self.QuestName;QSB.JournalEntryNameToID[self.EntryName]=XL_ end end
function B_Reprisal_JournalWrite:Debug(WYdR)
if not
API.IsValidQuest(GetQuestID(self.QuestName))then
error(WYdR.Identifier..": "..
self.Name..": quest '"..tostring(self.QuestName)..
"' does not exist!")return true end
if
QSB.JournalEntryNameToQuestName[self.EntryName]~=self.QuestName then
error(WYdR.Identifier..": "..
self.Name..": entry name '"..
tostring(self.EntryName).."' is already in use in another quest!")return true end
if not QSB.JournalEntryNameToID[self.EntryName]then
error(
WYdR.Identifier..": "..self.Name..
": entry '"..tostring(self.EntryName).."' does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_JournalWrite)function Reward_JournalWrite(...)return
B_Reward_JournalWrite:new(...)end
B_Reward_JournalWrite=Swift:CopyTable(B_Reprisal_JournalWrite)B_Reward_JournalWrite.Name="Reward_JournalWrite"
B_Reward_JournalWrite.Description.en="Reward: Adds or alters a journal entry to a quest."
B_Reward_JournalWrite.Description.de="Lohn: Schreibt oder ändert einen Tagebucheintrag."B_Reward_JournalWrite.GetReprisalTable=nil
B_Reward_JournalWrite.GetRewardTable=function(QKKks_zt,Are7xU)return
{Reward.Custom,{QKKks_zt,QKKks_zt.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_JournalWrite)function Reprisal_JournalRemove(...)return
B_Reprisal_JournalRemove:new(...)end
B_Reprisal_JournalRemove={Name="Reprisal_JournalRemove",Description={en="Reprisal: Remove a journal entry from a quest.",de="Vergeltung: Entfernt einen Tagebucheintrag vom Quest."},Parameter={{ParameterType.QuestName,en="Quest name",de="Name Quest"},{ParameterType.Default,en="Entry name",de="Name Eintrag"}}}
function B_Reprisal_JournalRemove:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_JournalRemove:AddParameter(yxjl,ZG)if(yxjl==0)then self.QuestName=ZG elseif(yxjl==1)then
self.EntryName=ZG end end
function B_Reprisal_JournalRemove:CustomFunction(Vu0cCAf)
if
QSB.JournalEntryNameToQuestName[self.EntryName]then local q=QSB.JournalEntryNameToID[self.EntryName]
API.RemoveJournalEntryFromQuest(q,self.QuestName)API.DeleteJournalEntry(q)QSB.JournalEntryNameToQuestName[self.EntryName]=
nil
QSB.JournalEntryNameToID[self.EntryName]=nil end end
function B_Reprisal_JournalRemove:Debug(kP7O5)
if not
API.IsValidQuest(GetQuestID(self.QuestName))then
error(kP7O5.Identifier..": "..
self.Name..": quest '"..
tostring(self.QuestName).."' does not exist!")return true end
if
QSB.JournalEntryNameToQuestName[self.EntryName]~=self.QuestName then
error(kP7O5.Identifier..": "..
self.Name..": entry name '"..
tostring(self.EntryName).."' is already in use in another quest!")return true end
if not QSB.JournalEntryNameToID[self.EntryName]then
error(
kP7O5.Identifier..": "..self.Name..
": entry '"..tostring(self.EntryName).."' does not exist!")return true end;return false end;Swift:RegisterBehavior(B_Reprisal_JournalRemove)function Reward_JournalRemove(...)return
B_Reward_JournalRemove:new(...)end
B_Reward_JournalRemove=Swift:CopyTable(B_Reprisal_JournalRemove)B_Reward_JournalRemove.Name="Reward_JournalRemove"
B_Reward_JournalRemove.Description.en="Reward: Remove a journal entry from a quest."
B_Reward_JournalRemove.Description.de="Lohn: Entfernt einen Tagebucheintrag vom Quest."B_Reward_JournalRemove.GetReprisalTable=nil
B_Reward_JournalRemove.GetRewardTable=function(lqT,mP3mlD)return
{Reward.Custom,{lqT,lqT.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_JournalRemove)function Reprisal_JournaHighlight(...)return
B_Reprisal_JournaHighlight:new(...)end
B_Reprisal_JournaHighlight={Name="Reprisal_JournaHighlight",Description={en="Reprisal: Highlights or unhighlights a journal entry of a quest.",de="Vergeltung: Hebt einen Tagebucheintrag hevor oder hebt die Hervorhebung auf."},Parameter={{ParameterType.QuestName,en="Quest name",de="Name Quest"},{ParameterType.Default,en="Name of entry",de="Name Eintrag"},{ParameterType.Custom,en="Highlight entry",de="Hebe hervor"}}}
function B_Reprisal_JournaHighlight:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function B_Reprisal_JournaHighlight:AddParameter(PrPyxMK,tczrIB)
if(PrPyxMK==0)then self.QuestName=tczrIB elseif
(PrPyxMK==1)then self.EntryName=tczrIB elseif(PrPyxMK==2)then
self.IsImportant=API.ToBoolean(tczrIB)end end
function B_Reprisal_JournaHighlight:GetCustomData(a)return{"true","false"}end
function B_Reprisal_JournaHighlight:CustomFunction(wqU76o)
if
QSB.JournalEntryNameToQuestName[self.EntryName]then local LB1Z=QSB.JournalEntryNameToID[self.EntryName]API.HighlightJournalEntry(LB1Z,
self.IsImportant==true)end end
function B_Reprisal_JournaHighlight:Debug(N9L)
if not
API.IsValidQuest(GetQuestID(self.QuestName))then
error(N9L.Identifier..": "..
self.Name..": quest '"..tostring(self.QuestName)..
"' does not exist!")return true end
if
QSB.JournalEntryNameToQuestName[self.EntryName]~=self.QuestName then
error(N9L.Identifier..": "..
self.Name..": entry name '"..
tostring(self.EntryName).."' is not mapped to the quest!")return true end
if not QSB.JournalEntryNameToID[self.EntryName]then
error(
N9L.Identifier..": "..self.Name..
": entry '"..tostring(self.EntryName).."' does not exist!")return true end;return false end
Swift:RegisterBehavior(B_Reprisal_JournaHighlight)
function Reward_JournaHighlight(...)return B_Reward_JournaHighlight:new(...)end
B_Reward_JournaHighlight=Swift:CopyTable(B_Reprisal_JournaHighlight)B_Reward_JournaHighlight.Name="Reward_JournaHighlight"
B_Reward_JournaHighlight.Description.en="Reward: Highlights or unhighlights a journal entry of a quest."
B_Reward_JournaHighlight.Description.de="Lohn: Hebt einen Tagebucheintrag hevor oder hebt die Hervorhebung auf."B_Reward_JournaHighlight.GetReprisalTable=nil
B_Reward_JournaHighlight.GetRewardTable=function(hDc_M,qW0lRiD1)return
{Reward.Custom,{hDc_M,hDc_M.CustomFunction}}end;Swift:RegisterBehavior(B_Reward_JournaHighlight)