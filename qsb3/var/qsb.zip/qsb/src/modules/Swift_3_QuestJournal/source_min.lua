
ModuleQuestJournal={Properties={Name="ModuleQuestJournal"},Global={Journal={ID=0},CustomInputAllowed={},InputShown={},TextColor="{tooltip}"},Local={CurrentJournalEntry=
nil,NextButton="/InGame/Root/Normal/AlignBottomLeft/Message/MessagePortrait/TutorialNextButton",NextButtonIcon={16,10}},Shared={Text={Next={de="Tagebuch anzeigen",en="Show Journal"},Title={de="Tagebuch",en="Journal"},Note={de="Notiz",en="Note"}}}}
function ModuleQuestJournal.Global:OnGameStart()
QSB.ScriptEvents.QuestJournalDisplayed=API.RegisterScriptEvent("Event_QuestJournalDisplayed")
QSB.ScriptEvents.QuestJournalPlayerNote=API.RegisterScriptEvent("Event_QuestJournalPlayerNote")end
function ModuleQuestJournal.Global:OnEvent(QDnlt,LmcA2auZ,...)
if
QDnlt==QSB.ScriptEvents.ChatClosed then self:ProcessChatInput(arg[1],arg[2])elseif QDnlt==
QSB.ScriptEvents.QuestJournalPlayerNote then self.InputShown[arg[1]]=arg[2]elseif QDnlt==
QSB.ScriptEvents.QuestJournalDisplayed then
local Q=self:DisplayJournalEntry(arg[1],arg[2])
Logic.ExecuteInLuaLocalState(string.format([[API.SendScriptEvent(QSB.ScriptEvents.QuestJournalDisplayed, "%s", %d, "%s", %s)]],arg[1],arg[2],Q,tostring(
self.CustomInputAllowed[arg[1]]~=nil)))end end
function ModuleQuestJournal.Global:CreateJournalEntry(ZA,_IQQ,XpkjA)
self.Journal.ID=self.Journal.ID+1
table.insert(self.Journal,{ID=self.Journal.ID,AlwaysVisible=XpkjA==true,Quests={},Rank=_IQQ,ZA})return self.Journal.ID end
function ModuleQuestJournal.Global:GetJournalEntry(pVRj)for fuZ3z86=1,#self.Journal do
if
self.Journal[fuZ3z86].ID==pVRj then return self.Journal[fuZ3z86]end end end
function ModuleQuestJournal.Global:UpdateJournalEntry(er,DFb100j,XL_,WYdR,QKKks_zt)
for Are7xU=1,#self.Journal do
if
self.Journal[Are7xU].ID==er then
self.Journal[Are7xU].AlwaysVisible=WYdR==true;self.Journal[Are7xU].Deleted=QKKks_zt==true
self.Journal[Are7xU].Rank=XL_
self.Journal[Are7xU][1]=self.Journal[Are7xU][1]or DFb100j end end end
function ModuleQuestJournal.Global:AssociateJournalEntryToQuest(yxjl,ZG,Vu0cCAf)
for q=1,#self.Journal do if
self.Journal[q].ID==yxjl then
self.Journal[q].Quests[ZG]=Vu0cCAf==true end end end
function ModuleQuestJournal.Global:DisplayJournalEntry(kP7O5,lqT)
local mP3mlD=Quests[GetQuestID(kP7O5)]
if
mP3mlD and mP3mlD.QuestNotes and mP3mlD.ReceivingPlayer==lqT then local PrPyxMK=self:GetJournalEntriesSorted()local tczrIB=false;local a=false
local wqU76o=""
for LB1Z=1,#PrPyxMK,1 do
if
PrPyxMK[LB1Z].AlwaysVisible or PrPyxMK[LB1Z].Quests[kP7O5]then
if not PrPyxMK[LB1Z].Deleted then
local N9L=API.ConvertPlaceholders(API.Localize(PrPyxMK[LB1Z][1]))if PrPyxMK[LB1Z].Rank==1 then
N9L="{scarlet}"..N9L..self.TextColor;tczrIB=true end;if
PrPyxMK[LB1Z].Rank==0 then
if tczrIB then tczrIB=false;N9L="{cr}----------{cr}{cr}"..N9L end;a=true end
if
PrPyxMK[LB1Z].Rank==-1 then local hDc_M=""if a then a=false;hDc_M="{violet}"
N9L="{cr}----------{cr}{cr}"..N9L end
N9L=hDc_M..N9L..self.TextColor end;wqU76o=wqU76o..
((wqU76o~=""and"{cr}")or"")..N9L end end end;return wqU76o end end
function ModuleQuestJournal.Global:GetJournalEntriesSorted()local qW0lRiD1={}for iD1IUx=1,#self.Journal,1 do
table.insert(qW0lRiD1,self.Journal[iD1IUx])end
table.sort(qW0lRiD1,function(JLCOx_ak,hPQ)return
JLCOx_ak.Rank>hPQ.Rank end)return qW0lRiD1 end
function ModuleQuestJournal.Global:ProcessChatInput(R1FIoQI,NsoTwDs)
if self.InputShown[NsoTwDs]then
if R1FIoQI and R1FIoQI~=
""then
local HGli=self:CreateJournalEntry(R1FIoQI,-1,false)
self:AssociateJournalEntryToQuest(HGli,self.InputShown[NsoTwDs],true)end;self.InputShown[NsoTwDs]=nil end end
function ModuleQuestJournal.Local:OnGameStart()
QSB.ScriptEvents.QuestJournalDisplayed=API.RegisterScriptEvent("Event_QuestJournalDisplayed")
QSB.ScriptEvents.QuestJournalPlayerNote=API.RegisterScriptEvent("Event_QuestJournalPlayerNote")self:OverrideUpdateVoiceMessage()
self:OverrideTutorialNext()self:OverrideStringKeys()end
function ModuleQuestJournal.Local:OnEvent(iy,m6SCS0,...)
if
iy==QSB.ScriptEvents.QuestJournalDisplayed then
self:DisplayQuestJournal(arg[1],arg[2],arg[3],arg[4])elseif iy==QSB.ScriptEvents.ChatClosed then
if arg[2]==GUI.GetPlayerID()then
if
self.CurrentJournalEntry then local NUhYw6R4=table.copy(self.CurrentJournalEntry)self.CurrentJournalEntry=
nil
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.QuestJournalDisplayed,NUhYw6R4.QuestName,GUI.GetPlayerID())end end end end
function ModuleQuestJournal.Local:DisplayQuestJournal(Hv,Ch,urkh,zhzpBSx)
if
urkh and GUI.GetPlayerID()==Ch then
local rHSjalVy=API.Localize(ModuleQuestJournal.Shared.Text.Title)
local TjhsnP={PlayerID=Ch,Caption=rHSjalVy,Content=API.ConvertPlaceholders(urkh),QuestName=Hv}
if zhzpBSx then
TjhsnP.Button={Text=API.Localize{de="Notiz",en="Note"},Action=function(t5jzEd9)
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.QuestJournalPlayerNote,t5jzEd9.PlayerID,t5jzEd9.QuestName)API.ShowTextInput(t5jzEd9.PlayerID,false)end}end;self.CurrentJournalEntry=TjhsnP
ModuleInputOutputCore.Local:ShowTextWindow(TjhsnP)end end
function ModuleQuestJournal.Local:OverrideUpdateVoiceMessage()
GUI_Interaction.UpdateVoiceMessage_Orig_ModuleQuestJournal=GUI_Interaction.UpdateVoiceMessage
GUI_Interaction.UpdateVoiceMessage=function()
GUI_Interaction.UpdateVoiceMessage_Orig_ModuleQuestJournal()
if not QuestLog.IsQuestLogShown()then
if
ModuleQuestJournal.Local:IsShowingJournalButton(g_Interaction.CurrentMessageQuestIndex)then
XGUIEng.ShowWidget(ModuleQuestJournal.Local.NextButton,1)
SetIcon(ModuleQuestJournal.Local.NextButton,ModuleQuestJournal.Local.NextButtonIcon)else
XGUIEng.ShowWidget(ModuleQuestJournal.Local.NextButton,0)end end end end
function ModuleQuestJournal.Local:IsShowingJournalButton(JZAU2)if
not g_Interaction.CurrentMessageQuestIndex then return false end;local zPXTTg=Quests[JZAU2]
if
type(zPXTTg)=="table"and zPXTTg.QuestNotes then return true end;return false end
function ModuleQuestJournal.Local:OverrideTutorialNext()
GUI_Interaction.TutorialNext_Orig_ModuleQuestJournal=GUI_Interaction.TutorialNext
GUI_Interaction.TutorialNext=function()
if g_Interaction.CurrentMessageQuestIndex then
local seMLr=g_Interaction.CurrentMessageQuestIndex;local qX=Quests[seMLr]
API.BroadcastScriptEventToGlobal(QSB.ScriptEvents.QuestJournalDisplayed,qX.Identifier,GUI.GetPlayerID())end end end
function ModuleQuestJournal.Local:OverrideStringKeys()
GetStringTableText_Orig_ModuleQuestJournal=XGUIEng.GetStringTableText
XGUIEng.GetStringTableText=function(h_8)
if h_8 =="UI_ObjectNames/TutorialNextButton"then return
API.Localize(ModuleQuestJournal.Shared.Text.Next)end;return GetStringTableText_Orig_ModuleQuestJournal(h_8)end end;Swift:RegisterModule(ModuleQuestJournal)