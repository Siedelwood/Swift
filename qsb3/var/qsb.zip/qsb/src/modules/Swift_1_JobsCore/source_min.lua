
ModuleJobsCore={Properties={Name="ModuleJobsCore"},Global={},Local={},Shared={EventJobID=0,EventJobs={},TimeLineData={},SecondsSinceGameStart=0,LastTimeStamp=0}}function ModuleJobsCore.Global:OnGameStart()
ModuleJobsCore.Shared:InstallBaseEventJobs()end;function ModuleJobsCore.Local:OnGameStart()
ModuleJobsCore.Shared:InstallBaseEventJobs()end
function ModuleJobsCore.Shared:CreateEventJob(QDnlt,LmcA2auZ,...)self.EventJobID=
self.EventJobID+1
local Q=Trigger.RequestTrigger(QDnlt,"","ModuleJobCore_EventJob_BasicEventJobExecutor",1,{},{self.EventJobID})
self.EventJobs[self.EventJobID]={Q,LmcA2auZ,table.copy(arg)}return Q end
function ModuleJobsCore.Shared:InstallBaseEventJobs()
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,"","ModuleJobCore_EventJob_RealtimeController",1)end
function ModuleJobCore_EventJob_RealtimeController()if not ModuleJobsCore.Shared.LastTimeStamp then
ModuleJobsCore.Shared.LastTimeStamp=math.floor(Framework.TimeGetTime())end
local ZA=math.floor(Framework.TimeGetTime())
if ModuleJobsCore.Shared.LastTimeStamp~=ZA then
ModuleJobsCore.Shared.LastTimeStamp=ZA;ModuleJobsCore.Shared.SecondsSinceGameStart=
ModuleJobsCore.Shared.SecondsSinceGameStart+1 end end
function ModuleJobCore_EventJob_BasicEventJobExecutor(_IQQ)
if
ModuleJobsCore.Shared.EventJobs[_IQQ]then
local XpkjA=ModuleJobsCore.Shared.EventJobs[_IQQ][3]
local pVRj=ModuleJobsCore.Shared.EventJobs[_IQQ][2](unpack(XpkjA))if pVRj then
ModuleJobsCore.Shared.EventJobs[_IQQ]=nil;return true end end end;Swift:RegisterModule(ModuleJobsCore)