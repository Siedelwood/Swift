
ModuleWeatherManipulation={Properties={Name="ModuleWeatherManipulation"},Global={EventQueue={},ActiveEvent=nil},Local={ActiveEvent=nil}}function ModuleWeatherManipulation.Global:OnGameStart()
API.StartHiResJob(function()
ModuleWeatherManipulation.Global:EventController()end)end
function ModuleWeatherManipulation.Global:OnEvent(QDnlt,LmcA2auZ)
if
QDnlt==QSB.ScriptEvents.SaveGameLoaded then
if self:IsEventActive()then
Logic.ExecuteInLuaLocalState(
[[
                Display.StopAllEnvironmentSettingsSequences()
                ModuleWeatherManipulation.Local:DisplayEvent(]]..self:GetEventRemainingTime()..[[)
            ]])end end end
function ModuleWeatherManipulation.Global:AddEvent(Q,ZA)
local _IQQ=table.copy(Q)_IQQ.Duration=ZA;table.insert(self.EventQueue,_IQQ)end
function ModuleWeatherManipulation.Global:PurgeAllEvents()if
#self.EventQueue>0 then
for XpkjA=#self.EventQueue,1-1 do self.EventQueue:remove(XpkjA)end end end
function ModuleWeatherManipulation.Global:NextEvent()if
not self:IsEventActive()then
if#self.EventQueue>0 then self:ActivateEvent()end end end
function ModuleWeatherManipulation.Global:ActivateEvent()if
#self.EventQueue==0 then return end
local pVRj=table.remove(self.EventQueue,1)self.ActiveEvent=pVRj
Logic.ExecuteInLuaLocalState([[
        ModuleWeatherManipulation.Local.ActiveEvent = ]]..

table.tostring(pVRj)..[[
        ModuleWeatherManipulation.Local:DisplayEvent()
    ]])Logic.WeatherEventClearGoodTypesNotGrowing()for fuZ3z86=1,#
pVRj.NotGrowing,1 do
Logic.WeatherEventAddGoodTypeNotGrowing(pVRj.NotGrowing[fuZ3z86])end
if pVRj.Rain then
Logic.WeatherEventSetPrecipitationFalling(true)Logic.WeatherEventSetPrecipitationHeaviness(1)
Logic.WeatherEventSetWaterRegenerationFactor(1)if pVRj.Snow then
Logic.WeatherEventSetPrecipitationIsSnow(true)end end
if pVRj.Ice then Logic.WeatherEventSetWaterFreezes(true)end;if pVRj.Monsoon then
Logic.WeatherEventSetShallowWaterFloods(true)end
Logic.WeatherEventSetTemperature(pVRj.Temperature)Logic.ActivateWeatherEvent()end
function ModuleWeatherManipulation.Global:StopEvent()
Logic.ExecuteInLuaLocalState("ModuleWeatherManipulation.Local.ActiveEvent = nil")self.ActiveEvent=nil;Logic.DeactivateWeatherEvent()end;function ModuleWeatherManipulation.Global:GetEventRemainingTime()if not
self:IsEventActive()then return 0 end
return self.ActiveEvent.Duration end;function ModuleWeatherManipulation.Global:IsEventActive()return
self.ActiveEvent~=nil end
function ModuleWeatherManipulation.Global:EventController()
if
self:IsEventActive()then
self.ActiveEvent.Duration=self.ActiveEvent.Duration-1
if self.ActiveEvent.Loop then self.ActiveEvent:Loop()end;if self.ActiveEvent.Duration==0 then self:StopEvent()
self:NextEvent()end end end
function ModuleWeatherManipulation.Local:OnGameStart()end
function ModuleWeatherManipulation.Local:DisplayEvent(er)
if self:IsEventActive()then
local DFb100j=Display.AddEnvironmentSettingsSequence(self.ActiveEvent.GFX)
Display.PlayEnvironmentSettingsSequence(DFb100j,er or self.ActiveEvent.Duration)end end;function ModuleWeatherManipulation.Local:IsEventActive()
return self.ActiveEvent~=nil end
WeatherEvent={GFX="ne_winter_sequence.xml",NotGrowing={},Rain=false,Snow=false,Ice=false,Monsoon=false,Temperature=10}function WeatherEvent:New()return table.copy(self)end
Swift:RegisterModule(ModuleWeatherManipulation)