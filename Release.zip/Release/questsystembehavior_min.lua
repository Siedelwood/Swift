API=API or{}QSB=QSB or{Version="0.0.6"}
ParameterType=ParameterType or{}g_QuestBehaviorVersion=1;g_QuestBehaviorTypes={}g_GameExtraNo=0
if Framework then
g_GameExtraNo=Framework.GetGameExtraNo()elseif MapEditor then g_GameExtraNo=MapEditor.GetGameExtraNo()end;function API.Install()Core:InitalizeBundles()end
function API.InstanceTable(abn5,AvK)AvK=
AvK or{}assert(type(abn5)=="table")assert(type(AvK)==
"table")
for rhVu,ngzOjWHO in pairs(abn5)do if type(ngzOjWHO)=="table"then
AvK[rhVu]=API.InstanceTable(ngzOjWHO)else AvK[rhVu]=ngzOjWHO end end;return AvK end;CopyTableRecursive=API.InstanceTable
function API.TraverseTable(dM,U)for _u,aLgiy in pairs(U)do
if aLgiy==dM then return true end end;return false end;Inside=API.TraverseTable
function API.DumpTable(mvi,g4KV)local dT7iYDf4="{"if g4KV then
dT7iYDf4=g4KV.." = \n"..dT7iYDf4 end;Framework.WriteToLog(dT7iYDf4)
for L,WRH9 in
pairs(mvi)do
if type(WRH9)=="table"then
Framework.WriteToLog("["..L.."] = ")API.DumpTable(WRH9)elseif type(WRH9)=="string"then
Framework.WriteToLog("["..L.."] = \""..WRH9 ..
"\"")else
Framework.WriteToLog("["..L.."] = "..tostring(WRH9))end end;Framework.WriteToLog("}")end
function API.ConvertTableToString(cJoBcud)assert(type(cJoBcud)=="table")
local e="{"
for B6zKxgVs,O3_X in pairs(cJoBcud)do local DVs8kf2w
if(tonumber(B6zKxgVs))then DVs8kf2w=""..B6zKxgVs else DVs8kf2w=
"\""..B6zKxgVs.."\""end
if type(O3_X)=="table"then e=e..
"["..DVs8kf2w.."] = "..
API.ConvertTableToString(O3_X)..", "elseif type(O3_X)==
"number"then
e=e.."["..DVs8kf2w.."] = "..O3_X..", "elseif type(O3_X)=="string"then e=e..
"["..DVs8kf2w.."] = \""..O3_X.."\", "elseif type(O3_X)=="boolean"or type(O3_X)==
"nil"then
e=e.."["..DVs8kf2w..
"] = \""..tostring(O3_X).."\", "else e=e..
"["..DVs8kf2w.."] = \""..tostring(O3_X).."\", "end end;e=e.."}"return e end
function API.GetQuestID(vms5)if type(vms5)=="number"then return vms5 end;for M7,v3 in pairs(Quests)do
if v3 and
M7 >0 then if v3.Identifier==vms5 then return M7 end end end end;GetQuestID=API.GetQuestID;function API.IsValidateQuest(ihKb)
return Quests[ihKb]~=nil or
Quests[API.GetQuestID(ihKb)]~=nil end
IsValidQuest=API.IsValidateQuest
function API.FailAllQuests(...)for JGSK=1,#arg,1 do
API.FailQuest(arg[JGSK].Identifier)end end;FailQuestsByName=API.FailAllQuests
function API.FailQuest(rA5U)
local Uc06=Quests[GetQuestID(rA5U)]if Uc06 then API.Info("fail quest "..rA5U)
Uc06:RemoveQuestMarkers()Uc06:Fail()end end;FailQuestByName=API.FailQuest
function API.RestartAllQuests(...)for lcBL=1,#arg,1 do
API.RestartQuest(arg[lcBL].Identifier)end end;RestartQuestsByName=API.RestartAllQuests
function API.RestartQuest(DHPxI)
local dx=GetQuestID(DHPxI)local RRuSHnxf=Quests[dx]
if RRuSHnxf then
API.Info("restart quest "..DHPxI)
if RRuSHnxf.Objectives then local scRP0=RRuSHnxf.Objectives
for AI0R2TQ6=1,scRP0[0]do
local yA=scRP0[AI0R2TQ6]yA.Completed=nil;local XmVolesU=yA.Type
if XmVolesU==Objective.Deliver then
local eZ0l3ch=yA.Data;eZ0l3ch[3]=nil;eZ0l3ch[4]=nil;eZ0l3ch[5]=nil elseif
g_GameExtraNo and g_GameExtraNo>=1 and XmVolesU==Objective.Refill then
yA.Data[2]=nil elseif
XmVolesU==Objective.Protect or XmVolesU==Objective.Object then local W_63_9=yA.Data
for h9dyA_4T=1,W_63_9[0],1 do W_63_9[-h9dyA_4T]=nil end elseif
XmVolesU==Objective.DestroyEntities and yA.Data[1]~=1 and yA.DestroyTypeAmount then
yA.Data[3]=yA.DestroyTypeAmount elseif XmVolesU==Objective.Distance then if yA.Data[1]==-65565 then yA.Data[4].NpcInstance=
nil end elseif XmVolesU==Objective.Custom2 and
yA.Data[1].Reset then
yA.Data[1]:Reset(RRuSHnxf,AI0R2TQ6)end end end
local function mcYOuT(oh,DZXGTh)local RRuSHnxf=RRuSHnxf;local Su9Koz=RRuSHnxf[oh]
if Su9Koz then
for Uk7e=1,Su9Koz[0]do local KwQCk_G=Su9Koz[Uk7e]
if
KwQCk_G.Type==DZXGTh then local ptZa=KwQCk_G.Data[1]if ptZa and ptZa.Reset then
ptZa:Reset(RRuSHnxf,Uk7e)end end end end end;mcYOuT("Triggers",Triggers.Custom2)
mcYOuT("Rewards",Reward.Custom)mcYOuT("Reprisals",Reprisal.Custom)
RRuSHnxf.Result=nil;local Rr=RRuSHnxf.State;RRuSHnxf.State=QuestState.NotTriggered
Logic.ExecuteInLuaLocalState(
"LocalScriptCallback_OnQuestStatusChanged("..RRuSHnxf.Index..")")if Rr==QuestState.Over then
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_SECOND,"",QuestTemplate.Loop,1,0,{RRuSHnxf.QueueID})end
return dx,RRuSHnxf end end;RestartQuestByName=API.RestartQuest
function API.StartAllQuests(...)for PEqsd=1,#arg,1 do
API.StartQuest(arg[PEqsd].Identifier)end end;StartQuestsByName=API.StartAllQuests
function API.StartQuest(iSj)
local iXxD6s=Quests[GetQuestID(iSj)]
if iXxD6s then API.Info("start quest "..iSj)
iXxD6s:SetMsgKeyOverride()iXxD6s:SetIconOverride()iXxD6s:Trigger()end end;StartQuestByName=API.StartQuest;function API.StopAllQuests(...)for oiY=1,#arg,1 do
API.StopQuest(arg[oiY].Identifier)end end
StopQuestwByName=API.StopAllQuests
function API.StopQuest(FsYIVlkf)local HLXS0Q_=Quests[GetQuestID(FsYIVlkf)]
if HLXS0Q_ then API.Info(
"interrupt quest "..FsYIVlkf)
HLXS0Q_:RemoveQuestMarkers()HLXS0Q_:Interrupt(-1)end end;StopQuestByName=API.StopQuest;function API.WinAllQuests(...)for Kw=1,#arg,1 do
API.WinQuest(arg[Kw].Identifier)end end
WinQuestsByName=API.WinAllQuests
function API.WinQuest(nvaIsNv7)local vDnoL55=Quests[GetQuestID(nvaIsNv7)]
if vDnoL55 then API.Info(
"win quest "..nvaIsNv7)
vDnoL55:RemoveQuestMarkers()vDnoL55:Success()end end;WinQuestByName=API.WinQuest
function API.Note(xlAK)xlAK=API.EnsureMessage(xlAK)
local zr1y=Logic.DEBUG_AddNote;if GUI then zr1y=GUI.AddNote end;zr1y(xlAK)end;GUI_Note=API.Note
function API.StaticNote(Hs)Hs=API.EnsureMessage(Hs)if not GUI then
Logic.ExecuteInLuaLocalState(
'GUI.AddStaticNote("'..Hs..'")')return end
GUI.AddStaticNote(Hs)end
function API.ClearNotes()if not GUI then
Logic.ExecuteInLuaLocalState('GUI.ClearNotes()')return end;GUI.ClearNotes()end;function API.Log(jk)local qzSFyIO=(GUI and"Local")or"Global"
local Z65=Logic.GetTimeMs()
Framework.WriteToLog(qzSFyIO..":"..Z65 ..": "..jk)end
function API.Message(umyCNfj)
umyCNfj=API.EnsureMessage(umyCNfj)if not GUI then
Logic.ExecuteInLuaLocalState('Message("'..umyCNfj..'")')return end;Message(umyCNfj)end
function API.Dbg(FT)
if QSB.Log.CurrentLevel<=QSB.Log.Level.ERROR then API.StaticNote("DEBUG: "..
FT)end;API.Log("DEBUG: "..FT)end;dbg=API.Dbg
function API.EnsureMessage(YVLXYq)local bJfct=
(Network.GetDesiredLanguage()=="de"and"de")or"en"if
type(YVLXYq)=="table"then YVLXYq=YVLXYq[bJfct]end
return tostring(YVLXYq)end
function API.Warn(OhuFpq_N)
if QSB.Log.CurrentLevel<=QSB.Log.Level.WARNING then API.StaticNote(
"WARNING: "..OhuFpq_N)end;API.Log("WARNING: "..OhuFpq_N)end;warn=API.Warn
function API.Info(Dzg)if QSB.Log.CurrentLevel<=QSB.Log.Level.INFO then API.Note(
"INFO: "..Dzg)end;API.Log(
"INFO: "..Dzg)end;info=API.Info
QSB.Log={Level={OFF=90000,ERROR=3000,WARNING=2000,INFO=1000,ALL=0}}QSB.Log.CurrentLevel=QSB.Log.Level.ALL
function API.SetLogLevel(_4O)assert(type(_4O)==
"number")QSB.Log.CurrentLevel=_4O end
function API.SendCart(C,fLI2zRe,_Fr2YU,Xfn,U,Ebsw)local UlikV=GetID(C)if not IsExisting(UlikV)then return end
local JtAjijkG;local s,YAtG_LV3,LfEJbh_=Logic.EntityGetPos(UlikV)
local JD=Logic.GetGoodCategoryForGoodType(_Fr2YU)local u=0
if Logic.IsBuilding(UlikV)==1 then
s,YAtG_LV3=Logic.GetBuildingApproachPosition(UlikV)u=Logic.GetEntityOrientation(UlikV)-90 end
if JD==GoodCategories.GC_Resource then
JtAjijkG=Logic.CreateEntityOnUnblockedLand(Entities.U_ResourceMerchant,s,YAtG_LV3,u,fLI2zRe)elseif _Fr2YU==Goods.G_Medicine then
JtAjijkG=Logic.CreateEntityOnUnblockedLand(Entities.U_Medicus,s,YAtG_LV3,u,fLI2zRe)elseif _Fr2YU==Goods.G_Gold then
if U then
JtAjijkG=Logic.CreateEntityOnUnblockedLand(U,s,YAtG_LV3,u,fLI2zRe)else
JtAjijkG=Logic.CreateEntityOnUnblockedLand(Entities.U_GoldCart,s,YAtG_LV3,u,fLI2zRe)end else
JtAjijkG=Logic.CreateEntityOnUnblockedLand(Entities.U_Marketer,s,YAtG_LV3,u,fLI2zRe)end
Logic.HireMerchant(JtAjijkG,fLI2zRe,_Fr2YU,Xfn,fLI2zRe,Ebsw)return JtAjijkG end;SendCart=API.SendCart
function API.ReplaceEntity(pzDMZwG,XPoQB,XxJ)local o5sms=GetID(pzDMZwG)
if o5sms==0 then return end;local JQi1jg=GetPosition(o5sms)
local wVzn=XxJ or Logic.EntityGetPlayer(o5sms)local pE=Logic.GetEntityOrientation(o5sms)
local RSjapQ=Logic.GetEntityName(o5sms)DestroyEntity(o5sms)
if
Logic.IsEntityTypeInCategory(XPoQB,EntityCategories.Soldier)==1 then return
CreateBattalion(wVzn,XPoQB,JQi1jg.X,JQi1jg.Y,1,RSjapQ,pE)else
return CreateEntity(wVzn,XPoQB,JQi1jg,RSjapQ,pE)end end;ReplaceEntity=API.ReplaceEntity
function API.LookAt(QJf,zC,pfZ3SPy_)local pDNa2ox6=GetEntityId(QJf)
local Do6yo7nm=GetEntityId(zC)
assert(not
(Logic.IsEntityDestroyed(pDNa2ox6)or Logic.IsEntityDestroyed(Do6yo7nm)),"LookAt: One Entity is wrong or dead")local y06X3k,ivnJjrA=Logic.GetEntityPosition(pDNa2ox6)
local d3fMjkg,el=Logic.GetEntityPosition(Do6yo7nm)
local Wu_uIt=math.deg(math.atan2((el-ivnJjrA),(d3fMjkg-y06X3k)))
if Logic.IsBuilding(pDNa2ox6)==1 then Wu_uIt=Wu_uIt-90 end;pfZ3SPy_=pfZ3SPy_ or 0
Logic.SetOrientation(pDNa2ox6,Wu_uIt+pfZ3SPy_)end;LookAt=API.LookAt;function API.Confront(w,sgeP)API.LookAt(w,sgeP)
API.LookAt(sgeP,w)end
function API.GetDistance(CM,Qlmlet)
if(type(CM)=="string")or(
type(CM)=="number")then CM=GetPosition(CM)end
if(type(Qlmlet)=="string")or
(type(Qlmlet)=="number")then Qlmlet=GetPosition(Qlmlet)end;if type(CM)~="table"or type(Qlmlet)~="table"then
return{X=1,Y=1}end;local _=(CM.X-Qlmlet.X)local RkGFh6=(CM.Y-
Qlmlet.Y)return
math.sqrt((_^2)+ (RkGFh6^2))end;GetDistance=API.GetDistance
function API.ValidatePosition(hw18)
if type(hw18)=="table"then
if
(hw18.X~=nil and
type(hw18.X)=="number")and(hw18.Y~=nil and
type(hw18.Y)=="number")then local nvCiFt7r={Logic.WorldGetSize()}
if

hw18.X<=nvCiFt7r[1]and hw18.X>=0 and hw18.Y<=nvCiFt7r[2]and hw18.Y>=0 then return true end end end;return false end;IsValidPosition=API.ValidatePosition
function API.LocateEntity(xSebv5Jc)if
(type(xSebv5Jc)=="table")then return xSebv5Jc end;if
(not IsExisting(xSebv5Jc))then return{X=0,Y=0,Z=0}end
local mMp,rDtVf,vj=Logic.EntityGetPos(GetID(xSebv5Jc))return{X=mMp,Y=rDtVf,Z=vj}end;GetPosition=API.LocateEntity
function API.ActivateIO(z,Zg)State=State or 0;if GUI then
GUI.SendScriptCommand(
'API.ActivateIO("'..z..'", '..State..')')return end
if not IsExisting(z)then return end
Logic.InteractiveObjectSetAvailability(GetID(z),true)for ykRppH=1,8 do
Logic.InteractiveObjectSetPlayerState(GetID(z),ykRppH,State)end end;InteractiveObjectActivate=API.ActivateIO
function API.DeactivateIO(WQ6)if GUI then
GUI.SendScriptCommand('API.DeactivateIO("'..
WQ6 ..'")')return end
if not IsExisting(WQ6)then return end
Logic.InteractiveObjectSetAvailability(GetID(WQ6),false)for y36Aetn=1,8 do
Logic.InteractiveObjectSetPlayerState(GetID(WQ6),y36Aetn,2)end end;InteractiveObjectDeactivate=API.DeactivateIO
function API.GetEntitiesOfCategoryInTerritory(iPL3B4cr,GI2hz6SK,Oh)local PG={}
local n={}
if(iPL3B4cr==-1)then
for O=0,8 do local N5UjTN=0
repeat
n={Logic.GetEntitiesOfCategoryInTerritory(Oh,O,GI2hz6SK,N5UjTN)}PG=Array_Append(PG,n)N5UjTN=N5UjTN+#n until#n==0 end else local qLH5=0
repeat
n={Logic.GetEntitiesOfCategoryInTerritory(Oh,iPL3B4cr,GI2hz6SK,qLH5)}PG=Array_Append(PG,n)qLH5=qLH5+#n until#n==0 end;return PG end;GetEntitiesOfCategoryInTerritory=API.GetEntitiesOfCategoryInTerritory
function API.EnsureScriptName(tE)
if
type(tE)=="string"then return tE else assert(type(tE)=="number")
local VcV0EuD=Logic.GetEntityName(tE)
if
(type(VcV0EuD)~="string"or VcV0EuD=="")then
QSB.GiveEntityNameCounter=(QSB.GiveEntityNameCounter or 0)+1
VcV0EuD="EnsureScriptName_Name_"..QSB.GiveEntityNameCounter;Logic.SetEntityName(tE,VcV0EuD)end;return VcV0EuD end end;GiveEntityName=API.EnsureScriptName;function API.Bridge(pX4gCR,gad4ZcL)
if not GUI then
Logic.ExecuteInLuaLocalState(pX4gCR)else GUI.SendScriptCommand(pX4gCR,gad4ZcL)end end;function API.ToBoolean(dk)return
Core:ToBoolean(dk)end
AcceptAlternativeBoolean=API.ToBoolean
function API.AddSaveGameAction(E)if GUI then
API.Dbg("API.AddSaveGameAction: Can not be used from the local script!")return end;return
Core:AppendFunction("Mission_OnSaveGameLoaded",E)end;AddOnSaveGameLoadedAction=API.AddSaveGameAction
function API.AddHotKey(OO,y)if not GUI then
API.Dbg("API.AddHotKey: Can not be used from the global script!")return end
table.insert(Core.Data.HotkeyDescriptions,{OO,y})return#Core.Data.HotkeyDescriptions end
function API.RemoveHotKey(cR6rJlAl)if not GUI then
API.Dbg("API.RemoveHotKey: Can not be used from the global script!")return end
if

type(cR6rJlAl)~="number"or cR6rJlAl>#Core.Data.HotkeyDescriptions then
API.Dbg("API.RemoveHotKey: No candidate found or Index is nil!")return end;Core.Data.HotkeyDescriptions[cR6rJlAl]=nil end
Core={Data={Overwrite={StackedFunctions={},AppendedFunctions={},Fields={}},HotkeyDescriptions={},BundleInitializerList={}}}
function Core:InitalizeBundles()
if not GUI then self:SetupGobal_HackCreateQuest()
self:SetupGlobal_HackQuestSystem()else self:SetupLocal_HackRegisterHotkey()end
for M6ilzGJ,iW6CD in pairs(self.Data.BundleInitializerList)do local wZdg=_G[iW6CD]
if not GUI then if wZdg.Global~=
nil and wZdg.Global.Install~=nil then
wZdg.Global:Install()end else
if wZdg.Local~=nil and
wZdg.Local.Install~=nil then wZdg.Local:Install()end end end end
function Core:SetupGobal_HackCreateQuest()
CreateQuest=function(BaX,SJsW11k,Ki1HJT,wjim8xCV,E,QLam,qTDt,v,Ta)local u={}local nArcvQl={}local h6Ub7U={}local Gm={}
local YKA7cU=Logic.Quest_GetQuestNumberOfBehaviors(BaX)
for mCsewfX=0,YKA7cU-1 do
local yY=Logic.Quest_GetQuestBehaviorName(BaX,mCsewfX)local Xf=GetBehaviorTemplateByName(yY)
assert(Xf,"No template for name: "..yY..
" - using an invalid QuestSystemBehavior.lua?!")local UlFdiZ7v={}Table_Copy(UlFdiZ7v,Xf)
local U=Logic.Quest_GetQuestBehaviorParameter(BaX,mCsewfX)
for wFeA=1,#U do UlFdiZ7v:AddParameter(wFeA-1,U[wFeA])end
if(UlFdiZ7v.GetGoalTable~=nil)then
nArcvQl[#nArcvQl+1]=UlFdiZ7v:GetGoalTable()nArcvQl[#nArcvQl].Context=UlFdiZ7v
nArcvQl[#nArcvQl].FuncOverrideIcon=UlFdiZ7v.GetIcon
nArcvQl[#nArcvQl].FuncOverrideMsgKey=UlFdiZ7v.GetMsgKey end;if(UlFdiZ7v.GetTriggerTable~=nil)then
u[#u+1]=UlFdiZ7v:GetTriggerTable()end
if
(UlFdiZ7v.GetReprisalTable~=nil)then Gm[#Gm+1]=UlFdiZ7v:GetReprisalTable()end;if(UlFdiZ7v.GetRewardTable~=nil)then
h6Ub7U[#h6Ub7U+1]=UlFdiZ7v:GetRewardTable()end end;if(#u==0)or(#nArcvQl==0)then return end
if
Core:CheckQuestName(BaX)then
local JQgI=QuestTemplate:New(BaX,SJsW11k,Ki1HJT,nArcvQl,u,assert(tonumber(E)),h6Ub7U,Gm,nil,nil,(not wjim8xCV or(qTDt and
qTDt~="")),(not wjim8xCV or
(v and v~="")or(Ta and Ta~="")),QLam,qTDt,v,Ta)g_QuestNameToID[BaX]=JQgI else
dbg("Quest '"..tostring(questName)..
"': invalid questname! Contains forbidden characters!")end end end
function Core:SetupGlobal_HackQuestSystem()
QuestTemplate.Trigger_Orig_QSB_Core=QuestTemplate.Trigger
QuestTemplate.Trigger=function(N)
QuestTemplate.Trigger_Orig_QSB_Core(N)
for fs52REi=1,N.Objectives[0]do
if

N.Objectives[fs52REi].Type==Objective.Custom2 and N.Objectives[fs52REi].Data[1].SetDescriptionOverwrite then
local PUNkgaiM=N.Objectives[fs52REi].Data[1]:SetDescriptionOverwrite(N)
Core:ChangeCustomQuestCaptionText(N.Identifier,PUNkgaiM)break end end end;QuestTemplate.Interrupt_Orig_QSB_Core=QuestTemplate.Interrupt
QuestTemplate.Interrupt=function(s6FbB)
QuestTemplate.Interrupt_Orig_QSB_Core(s6FbB)
for X=1,s6FbB.Objectives[0]do if

s6FbB.Objectives[X].Type==Objective.Custom2 and s6FbB.Objectives[X].Data[1].Interrupt then
s6FbB.Objectives[X].Data[1]:Interrupt(s6FbB,X)end end
for dc61=1,s6FbB.Triggers[0]do if

s6FbB.Triggers[dc61].Type==Triggers.Custom2 and s6FbB.Triggers[dc61].Data[1].Interrupt then
s6FbB.Triggers[dc61].Data[1]:Interrupt(s6FbB,dc61)end end end end
function Core:SetupLocal_HackRegisterHotkey()
function g_KeyBindingsOptions:OnShow()
local aguhyl=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if Game~=nil then
XGUIEng.ShowWidget("/InGame/KeyBindingsMain/Backdrop",1)else
XGUIEng.ShowWidget("/InGame/KeyBindingsMain/Backdrop",0)end
if
g_KeyBindingsOptions.Descriptions==nil then g_KeyBindingsOptions.Descriptions={}
DescRegister("MenuInGame")DescRegister("MenuDiplomacy")
DescRegister("MenuProduction")DescRegister("MenuPromotion")
DescRegister("MenuWeather")DescRegister("ToggleOutstockInformations")
DescRegister("JumpMarketplace")DescRegister("JumpMinimapEvent")
DescRegister("BuildingUpgrade")DescRegister("BuildLastPlaced")
DescRegister("BuildStreet")DescRegister("BuildTrail")DescRegister("KnockDown")
DescRegister("MilitaryAttack")DescRegister("MilitaryStandGround")
DescRegister("MilitaryGroupAdd")DescRegister("MilitaryGroupSelect")
DescRegister("MilitaryGroupStore")DescRegister("MilitaryToggleUnits")
DescRegister("UnitSelect")DescRegister("UnitSelectToggle")
DescRegister("UnitSelectSameType")DescRegister("StartChat")DescRegister("StopChat")
DescRegister("QuickSave")DescRegister("QuickLoad")
DescRegister("TogglePause")DescRegister("RotateBuilding")
DescRegister("ExitGame")DescRegister("Screenshot")
DescRegister("ResetCamera")DescRegister("CameraMove")
DescRegister("CameraMoveMouse")DescRegister("CameraZoom")
DescRegister("CameraZoomMouse")DescRegister("CameraRotate")
for p,gOPDv in
pairs(Core.Data.HotkeyDescriptions)do
if gOPDv then gOPDv[1]=
(type(gOPDv[1])=="table"and gOPDv[1][aguhyl])or gOPDv[1]gOPDv[2]=
(
type(gOPDv[2])=="table"and gOPDv[2][aguhyl])or gOPDv[2]
table.insert(g_KeyBindingsOptions.Descriptions,1,gOPDv)end end end
XGUIEng.ListBoxPopAll(g_KeyBindingsOptions.Widget.ShortcutList)
XGUIEng.ListBoxPopAll(g_KeyBindingsOptions.Widget.ActionList)
for aSdZU3,YKDL in ipairs(g_KeyBindingsOptions.Descriptions)do
XGUIEng.ListBoxPushItem(g_KeyBindingsOptions.Widget.ShortcutList,YKDL[1])
XGUIEng.ListBoxPushItem(g_KeyBindingsOptions.Widget.ActionList,YKDL[2])end end end
function Core:RegisterBundle(oFyb6OLp)
local oGdh_mv=string.format("Error while initialize bundle '%s': does not exist!",tostring(oFyb6OLp))assert(_G[oFyb6OLp]~=nil,oGdh_mv)
table.insert(self.Data.BundleInitializerList,oFyb6OLp)end
function Core:RegisterAddOn(WjvvK)
local TASVwBgU=string.format("Error while initialize addon '%s': does not exist!",tostring(WjvvK))assert(_G[WjvvK]~=nil,TASVwBgU)
table.insert(self.Data.BundleInitializerList,WjvvK)end
function Core:RegisterBehavior(KjUncMB)if GUI then return end
if KjUncMB.RequiresExtraNo and
KjUncMB.RequiresExtraNo>g_GameExtraNo then return end
if not _G["b_"..KjUncMB.Name]then
dbg("AddQuestBehavior: can not find "..
KjUncMB.Name.."!")else
if not _G["b_"..KjUncMB.Name].new then
_G["b_"..KjUncMB.Name].new=function(XkT,...)
local c3dr=API.InstanceTable(XkT)
if XkT.Parameter then for NGH=1,table.getn(XkT.Parameter)do
c3dr:AddParameter(NGH-1,arg[NGH])end end;return c3dr end end;table.insert(g_QuestBehaviorTypes,KjUncMB)end end
function Core:CheckQuestName(tIc)return
not string.find(tIc,"[ \"§$%&/\(\)\[\[\?ß\*+#,;:\.^\<\>\|]")end
function Core:ChangeCustomQuestCaptionText(MD2O,HQ)HQ.QuestDescription=MD2O
Logic.ExecuteInLuaLocalState(
[[
        XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives/Custom/BGDeco",0)
        local identifier = "]]..
HQ.Identifier..

[["
        for i=1, Quests[0] do
            if Quests[i].Identifier == identifier then
                local text = Quests[i].QuestDescription
                XGUIEng.SetText("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives/Custom/Text", "]]..MD2O..[[")
                break;
            end
        end
    ]])end
function Core:StackFunction(cng,lE,nI2F0id)
if
not self.Data.Overwrite.StackedFunctions[cng]then
self.Data.Overwrite.StackedFunctions[cng]={Original=self:GetFunctionInString(cng),Attachments={}}
local N4aMD_P=function(...)local pCi
for NzeoQJ,AwGfFV in
pairs(self.Data.Overwrite.StackedFunctions[cng].Attachments)do pCi=AwGfFV(unpack(arg))if pCi~=nil then return pCi end end
pCi=self.Data.Overwrite.StackedFunctions[cng].Original(unpack(arg))return pCi end;self:ReplaceFunction(cng,N4aMD_P)end
nI2F0id=nI2F0id or#
self.Data.Overwrite.StackedFunctions[cng].Attachments
table.insert(self.Data.Overwrite.StackedFunctions[cng].Attachments,nI2F0id,lE)end
function Core:AppendFunction(wCRY,d0uKSVw1,lNOqUk8)
if
not self.Data.Overwrite.AppendedFunctions[wCRY]then
self.Data.Overwrite.AppendedFunctions[wCRY]={Original=self:GetFunctionInString(wCRY),Attachments={}}
local YAnZNei=function(...)
local h8YWR44E=self.Data.Overwrite.AppendedFunctions[wCRY].Original(unpack(arg))
for VF,fTrMe in
pairs(self.Data.Overwrite.AppendedFunctions[wCRY].Attachments)do h8YWR44E=fTrMe(unpack(arg))end;return h8YWR44E end;self:ReplaceFunction(wCRY,YAnZNei)end
lNOqUk8=lNOqUk8 or#
self.Data.Overwrite.AppendedFunctions[wCRY].Attachments
table.insert(self.Data.Overwrite.AppendedFunctions[wCRY].Attachments,lNOqUk8,d0uKSVw1)end
function Core:ReplaceFunction(ypDndT8,MV65)local Y3D66Ym9,q=ypDndT8:find("%.")
if Y3D66Ym9 then
local PhJ=ypDndT8:sub(1,Y3D66Ym9-1)local h=ypDndT8:sub(q+1,ypDndT8:len())
local Y3D66Ym9,q=h:find("%.")
if Y3D66Ym9 then local j2K=h;local h=j2K:sub(1,Y3D66Ym9-1)
local r8hgwQ=j2K:sub(q+1,j2K:len())_G[PhJ][h][r8hgwQ]=MV65 else _G[PhJ][h]=MV65 end else _G[ypDndT8]=MV65;return end end
function Core:GetFunctionInString(_6U,GLSzBQs)
if not GLSzBQs then local c,xg=_6U:find("%.")
if c then
local Id2KoP_G=_6U:sub(1,c-1)local Y2or=_6U:sub(xg+1,_6U:len())return
self:GetFunctionInString(Y2or,_G[Id2KoP_G])else return _G[_6U]end end
if type(GLSzBQs)=="table"then local zN8ASHV5,iju=_6U:find("%.")
if zN8ASHV5 then
local XsWgh=_6U:sub(1,zN8ASHV5-1)local l4Hdz=_6U:sub(iju+1,_6U:len())return
self:GetFunctionInString(l4Hdz,GLSzBQs[XsWgh])else return GLSzBQs[_6U]end end end
function Core:ToBoolean(NSXCgSH)local Wq=tostring(NSXCgSH)
if
Wq==true or Wq=="true"or Wq=="Yes"or Wq=="On"or Wq=="+"then return true end
if
Wq==false or Wq=="false"or Wq=="No"or Wq=="Off"or Wq=="-"then return false end;return false end;API=API or{}QSB=QSB or{}
QSB.EffectNameToID=QSB.EffectNameToID or{}QSB.InitalizedObjekts=QSB.InitalizedObjekts or{}QSB.DestroyedSoldiers=
QSB.DestroyedSoldiers or{}function Goal_ActivateObject(...)return
b_Goal_ActivateObject:new(...)end
b_Goal_ActivateObject={Name="Goal_ActivateObject",Description={en="Goal: Activate an interactive object",de="Ziel: Aktiviere ein interaktives Objekt"},Parameter={{ParameterType.ScriptName,en="Object name",de="Skriptname"}}}function b_Goal_ActivateObject:GetGoalTable(SbOQ)return
{Objective.Object,{self.ScriptName}}end
function b_Goal_ActivateObject:AddParameter(IiuHGo,cGqxtYr)if
IiuHGo==0 then self.ScriptName=cGqxtYr end end
function b_Goal_ActivateObject:GetMsgKey()return"Quest_Object_Activate"end;Core:RegisterBehavior(b_Goal_ActivateObject)function Goal_Deliver(...)return
b_Goal_Deliver:new(...)end
b_Goal_Deliver={Name="Goal_Deliver",Description={en="Goal: Deliver goods to quest giver or to another player.",de="Ziel: Liefere Waren zum Auftraggeber oder zu einem anderen Spieler."},Parameter={{ParameterType.Custom,en="Type of good",de="Ressourcentyp"},{ParameterType.Number,en="Amount of good",de="Ressourcenmenge"},{ParameterType.Custom,en="To different player",de="Anderer Empfänger"},{ParameterType.Custom,en="Ignore capture",de="Abfangen ignorieren"}}}
function b_Goal_Deliver:GetGoalTable(bgJFKeeZ)
local yu9fg0nN=Logic.GetGoodTypeID(self.GoodTypeName)return
{Objective.Deliver,yu9fg0nN,self.GoodAmount,self.OverrideTarget,self.IgnoreCapture}end
function b_Goal_Deliver:AddParameter(wgx,zlU7X)
if(wgx==0)then self.GoodTypeName=zlU7X elseif(wgx==1)then self.GoodAmount=zlU7X*
1 elseif(wgx==2)then self.OverrideTarget=tonumber(zlU7X)elseif
(wgx==3)then self.IgnoreCapture=AcceptAlternativeBoolean(zlU7X)end end
function b_Goal_Deliver:GetCustomData(t)local f6qbO={}
if t==0 then for kk,QrubIAv in pairs(Goods)do if string.find(kk,"^G_")then
table.insert(f6qbO,kk)end end
table.sort(f6qbO)elseif t==2 then table.insert(f6qbO,"-")for bLHDW=1,8 do
table.insert(f6qbO,bLHDW)end elseif t==3 then table.insert(f6qbO,"true")
table.insert(f6qbO,"false")else assert(false)end;return f6qbO end
function b_Goal_Deliver:GetMsgKey()
local YjFd7b=Logic.GetGoodTypeID(self.GoodTypeName)local jZgPYb=Logic.GetGoodCategoryForGoodType(YjFd7b)
local zN2={[GoodCategories.GC_Clothes]="Quest_Deliver_GC_Clothes",[GoodCategories.GC_Entertainment]="Quest_Deliver_GC_Entertainment",[GoodCategories.GC_Food]="Quest_Deliver_GC_Food",[GoodCategories.GC_Gold]="Quest_Deliver_GC_Gold",[GoodCategories.GC_Hygiene]="Quest_Deliver_GC_Hygiene",[GoodCategories.GC_Medicine]="Quest_Deliver_GC_Medicine",[GoodCategories.GC_Water]="Quest_Deliver_GC_Water",[GoodCategories.GC_Weapon]="Quest_Deliver_GC_Weapon",[GoodCategories.GC_Resource]="Quest_Deliver_Resources"}
if jZgPYb then local IN69pa5=zN2[jZgPYb]if IN69pa5 then return IN69pa5 end end;return"Quest_Deliver_Goods"end;Core:RegisterBehavior(b_Goal_Deliver)function Goal_Diplomacy(...)return
b_Goal_Diplomacy:new(...)end
b_Goal_Diplomacy={Name="Goal_Diplomacy",Description={en="Goal: Reach a diplomatic state",de="Ziel: Erreiche einen bestimmten Diplomatiestatus zu einem anderen Spieler."},Parameter={{ParameterType.PlayerID,en="Party",de="Partei"},{ParameterType.DiplomacyState,en="Relation",de="Beziehung"}}}
function b_Goal_Diplomacy:GetGoalTable(U)return
{Objective.Diplomacy,self.PlayerID,DiplomacyStates[self.DiplState]}end
function b_Goal_Diplomacy:AddParameter(OWJ,WtalJw)if(OWJ==0)then self.PlayerID=WtalJw*1 elseif(OWJ==1)then
self.DiplState=WtalJw end end;function b_Goal_Diplomacy:GetIcon()return{6,3}end
Core:RegisterBehavior(b_Goal_Diplomacy)
function Goal_DiscoverPlayer(...)return b_Goal_DiscoverPlayer:new(...)end
b_Goal_DiscoverPlayer={Name="Goal_DiscoverPlayer",Description={en="Goal: Discover the home territory of another player.",de="Ziel: Entdecke das Heimatterritorium eines Spielers."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}function b_Goal_DiscoverPlayer:GetGoalTable()return
{Objective.Discover,2,{self.PlayerID}}end
function b_Goal_DiscoverPlayer:AddParameter(JYrf2,KHDOUlRY)if(
JYrf2 ==0)then self.PlayerID=KHDOUlRY*1 end end
function b_Goal_DiscoverPlayer:GetMsgKey()
local I0JvPpn={[PlayerCategories.BanditsCamp]="Quest_Discover",[PlayerCategories.City]="Quest_Discover_City",[PlayerCategories.Cloister]="Quest_Discover_Cloister",[PlayerCategories.Harbour]="Quest_Discover",[PlayerCategories.Village]="Quest_Discover_Village"}local Ce4ZE=GetPlayerCategoryType(self.PlayerID)if Ce4ZE then
local OVx_mN=I0JvPpn[Ce4ZE]if OVx_mN then return OVx_mN end end
return"Quest_Discover"end;Core:RegisterBehavior(b_Goal_DiscoverPlayer)function Goal_DiscoverTerritory(...)return
b_Goal_DiscoverTerritory:new(...)end
b_Goal_DiscoverTerritory={Name="Goal_DiscoverTerritory",Description={en="Goal: Discover a territory",de="Ziel: Entdecke ein Territorium"},Parameter={{ParameterType.TerritoryName,en="Territory",de="Territorium"}}}function b_Goal_DiscoverTerritory:GetGoalTable()return
{Objective.Discover,1,{self.TerritoryID}}end
function b_Goal_DiscoverTerritory:AddParameter(lB,byE)if(
lB==0)then self.TerritoryID=tonumber(byE)if not self.TerritoryID then
self.TerritoryID=GetTerritoryIDByName(byE)end
assert(self.TerritoryID>0)end end
function b_Goal_DiscoverTerritory:GetMsgKey()return"Quest_Discover_Territory"end;Core:RegisterBehavior(b_Goal_DiscoverTerritory)function Goal_DestroyPlayer(...)return
b_Goal_DestroyPlayer:new(...)end
b_Goal_DestroyPlayer={Name="Goal_DestroyPlayer",Description={en="Goal: Destroy a player (destroy a main building)",de="Ziel: Zerstöre einen Spieler (ein Hauptgebäude muss zerstört werden)."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function b_Goal_DestroyPlayer:GetGoalTable()
assert(self.PlayerID<=8 and self.PlayerID>=1,
"Error in "..self.Name..": GetGoalTable: PlayerID is invalid")return{Objective.DestroyPlayers,self.PlayerID}end;function b_Goal_DestroyPlayer:AddParameter(bITCI,K)
if(bITCI==0)then self.PlayerID=K*1 end end
function b_Goal_DestroyPlayer:GetMsgKey()
local F5dtVpnN={[PlayerCategories.BanditsCamp]="Quest_DestroyPlayers_Bandits",[PlayerCategories.City]="Quest_DestroyPlayers_City",[PlayerCategories.Cloister]="Quest_DestroyPlayers_Cloister",[PlayerCategories.Harbour]="Quest_DestroyEntities_Building",[PlayerCategories.Village]="Quest_DestroyPlayers_Village"}local kxeBp=GetPlayerCategoryType(self.PlayerID)if kxeBp then
local a=F5dtVpnN[kxeBp]if a then return a end end
return"Quest_DestroyEntities_Building"end;Core:RegisterBehavior(b_Goal_DestroyPlayer)function Goal_StealInformation(...)return
b_Goal_StealInformation:new(...)end
b_Goal_StealInformation={Name="Goal_StealInformation",Description={en="Goal: Steal information from another players castle",de="Ziel: Stehle Informationen aus der Burg eines Spielers"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function b_Goal_StealInformation:GetGoalTable()
local kQ=Logic.GetHeadquarters(self.PlayerID)
if not kQ or kQ==0 then kQ=Logic.GetStoreHouse(self.PlayerID)end;assert(kQ and kQ~=0)
return{Objective.Steal,1,{kQ}}end;function b_Goal_StealInformation:AddParameter(EE9LAE,iVx)
if(EE9LAE==0)then self.PlayerID=iVx*1 end end;function b_Goal_StealInformation:GetMsgKey()return
"Quest_Steal_Info"end
Core:RegisterBehavior(b_Goal_StealInformation)function Goal_DestroyAllPlayerUnits(...)
return b_Goal_DestroyAllPlayerUnits:new(...)end
b_Goal_DestroyAllPlayerUnits={Name="Goal_DestroyAllPlayerUnits",Description={en="Goal: Destroy all units owned by player (be careful with script entities)",de="Ziel: Zerstöre alle Einheiten eines Spielers (vorsicht mit Script-Entities)"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function b_Goal_DestroyAllPlayerUnits:GetGoalTable()return
{Objective.DestroyAllPlayerUnits,self.PlayerID}end;function b_Goal_DestroyAllPlayerUnits:AddParameter(eg,AQviNt)
if(eg==0)then self.PlayerID=AQviNt*1 end end
function b_Goal_DestroyAllPlayerUnits:GetMsgKey()
local T6={[PlayerCategories.BanditsCamp]="Quest_DestroyPlayers_Bandits",[PlayerCategories.City]="Quest_DestroyPlayers_City",[PlayerCategories.Cloister]="Quest_DestroyPlayers_Cloister",[PlayerCategories.Harbour]="Quest_DestroyEntities_Building",[PlayerCategories.Village]="Quest_DestroyPlayers_Village"}local NviN0i=GetPlayerCategoryType(self.PlayerID)if NviN0i then
local BlMQce=T6[NviN0i]if BlMQce then return BlMQce end end;return
"Quest_DestroyEntities"end
Core:RegisterBehavior(b_Goal_DestroyAllPlayerUnits)function Goal_DestroyScriptEntity(...)
return b_Goal_DestroyScriptEntity:new(...)end
b_Goal_DestroyScriptEntity={Name="Goal_DestroyScriptEntity",Description={en="Goal: Destroy an entity",de="Ziel: Zerstöre eine Entität"},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}
function b_Goal_DestroyScriptEntity:GetGoalTable()return
{Objective.DestroyEntities,1,{self.ScriptName}}end;function b_Goal_DestroyScriptEntity:AddParameter(o,dpRE)
if(o==0)then self.ScriptName=dpRE end end
function b_Goal_DestroyScriptEntity:GetMsgKey()
if
Logic.IsEntityAlive(self.ScriptName)then local fEiXwWq=GetID(self.ScriptName)
if fEiXwWq and fEiXwWq~=0 then
fEiXwWq=Logic.GetEntityType(fEiXwWq)
if fEiXwWq and fEiXwWq~=0 then
if
Logic.IsEntityTypeInCategory(fEiXwWq,EntityCategories.AttackableBuilding)==1 then return"Quest_DestroyEntities_Building"elseif
Logic.IsEntityTypeInCategory(fEiXwWq,EntityCategories.AttackableAnimal)==1 then return"Quest_DestroyEntities_Predators"elseif
Logic.IsEntityTypeInCategory(fEiXwWq,EntityCategories.Hero)==1 then return"Quest_Destroy_Leader"elseif


Logic.IsEntityTypeInCategory(fEiXwWq,EntityCategories.Military)==1 or
Logic.IsEntityTypeInCategory(fEiXwWq,EntityCategories.AttackableSettler)==1 or
Logic.IsEntityTypeInCategory(fEiXwWq,EntityCategories.AttackableMerchant)==1 then return"Quest_DestroyEntities_Unit"end end end end;return"Quest_DestroyEntities"end;Core:RegisterBehavior(b_Goal_DestroyScriptEntity)function Goal_DestroyType(...)return
b_Goal_DestroyType:new(...)end
b_Goal_DestroyType={Name="Goal_DestroyType",Description={en="Goal: Destroy entity types",de="Ziel: Zerstöre Entitätstypen"},Parameter={{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.Custom,en="Player",de="Spieler"}}}
function b_Goal_DestroyType:GetGoalTable(r3JzMga6)return
{Objective.DestroyEntities,2,Entities[self.EntityName],self.Amount,self.PlayerID}end
function b_Goal_DestroyType:AddParameter(Tuyw,FYLcr2nu)
if(Tuyw==0)then self.EntityName=FYLcr2nu elseif(Tuyw==1)then self.Amount=
FYLcr2nu*1;self.DestroyTypeAmount=self.Amount elseif(Tuyw==2)then self.PlayerID=
FYLcr2nu*1 end end
function b_Goal_DestroyType:GetCustomData(ioS69)local AiP={}
if ioS69 ==0 then
for S2jwpoi,_ in pairs(Entities)do if
string.find(S2jwpoi,"^[ABU]_")then table.insert(AiP,S2jwpoi)end end;table.sort(AiP)elseif ioS69 ==2 then
for WX9u=0,8 do table.insert(AiP,WX9u)end else assert(false)end;return AiP end
function b_Goal_DestroyType:GetMsgKey()local u0riyU=self.EntityName
if
Logic.IsEntityTypeInCategory(u0riyU,EntityCategories.AttackableBuilding)==1 then return"Quest_DestroyEntities_Building"elseif
Logic.IsEntityTypeInCategory(u0riyU,EntityCategories.AttackableAnimal)==1 then return"Quest_DestroyEntities_Predators"elseif
Logic.IsEntityTypeInCategory(u0riyU,EntityCategories.Hero)==1 then return"Quest_Destroy_Leader"elseif


Logic.IsEntityTypeInCategory(u0riyU,EntityCategories.Military)==1 or
Logic.IsEntityTypeInCategory(u0riyU,EntityCategories.AttackableSettler)==1 or
Logic.IsEntityTypeInCategory(u0riyU,EntityCategories.AttackableMerchant)==1 then return"Quest_DestroyEntities_Unit"end;return"Quest_DestroyEntities"end;Core:RegisterBehavior(b_Goal_DestroyType)
do
GameCallback_EntityKilled_Orig_QSB_Goal_DestroySoldiers=GameCallback_EntityKilled
GameCallback_EntityKilled=function(U,H,WNph,ytF,d,gRm)
if H~=0 and ytF~=0 then QSB.DestroyedSoldiers[ytF]=
QSB.DestroyedSoldiers[ytF]or{}QSB.DestroyedSoldiers[ytF][H]=
QSB.DestroyedSoldiers[ytF][H]or 0
if

Logic.IsEntityTypeInCategory(d,EntityCategories.Military)==1 and
Logic.IsEntityInCategory(U,EntityCategories.HeavyWeapon)==0 then QSB.DestroyedSoldiers[ytF][H]=
QSB.DestroyedSoldiers[ytF][H]+1 end end
GameCallback_EntityKilled_Orig_QSB_Goal_DestroySoldiers(U,H,WNph,ytF,d,gRm)end end
function Goal_DestroySoldiers(...)return b_Goal_DestroySoldiers:new(...)end
b_Goal_DestroySoldiers={Name="Goal_DestroySoldiers",Description={en="Goal: Destroy a given amount of enemy soldiers",de="Ziel: Zerstöre eine Anzahl gegnerischer Soldaten"},Parameter={{ParameterType.PlayerID,en="Attacking Player",de="Angreifer"},{ParameterType.PlayerID,en="Defending Player",de="Verteidiger"},{ParameterType.Number,en="Amount",de="Anzahl"}}}
function b_Goal_DestroySoldiers:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_DestroySoldiers:AddParameter(LPX0,g)
if(LPX0 ==0)then self.AttackingPlayer=g*1 elseif
(LPX0 ==1)then self.AttackedPlayer=g*1 elseif(LPX0 ==2)then self.KillsNeeded=g*1 end end
function b_Goal_DestroySoldiers:CustomFunction(_l)
if
not _l.QuestDescription or _l.QuestDescription==""then local ipUPIzc=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
local N8=(ipUPIzc=="de"and
"SOLDATEN ZERST�REN {cr}{cr}von der Partei: ")or
"DESTROY SOLDIERS {cr}{cr}from faction: "
local Gzk=(ipUPIzc=="de"and"Anzahl: ")or"Amount: "local J7nsK=GetPlayerName(self.AttackedPlayer)if
J7nsK==""or J7nsK==nil then
J7nsK=
((ipUPIzc=="de"and"Spieler ")or"Player ")..self.AttackedPlayer end;local dXbd="{center}"..
N8 ..J7nsK.."{cr}{cr}"..Gzk.." "..
self.KillsNeeded
Core:ChangeCustomQuestCaptionText(dXbd,_l)end;local qao=0
if QSB.DestroyedSoldiers[self.AttackingPlayer]and
QSB.DestroyedSoldiers[self.AttackingPlayer][self.AttackedPlayer]then
qao=QSB.DestroyedSoldiers[self.AttackingPlayer][self.AttackedPlayer]end;self.SaveAmount=self.SaveAmount or qao;return self.KillsNeeded<=
qao-self.SaveAmount or nil end
function b_Goal_DestroySoldiers:DEBUG(vQj)
if
Logic.GetStoreHouse(self.AttackingPlayer)==0 then
dbg(vQj.Identifier.." "..self.Name..
": Player "..self.AttackinPlayer.." is dead :-(")return true elseif Logic.GetStoreHouse(self.AttackedPlayer)==0 then
dbg(
vQj.Identifier.." "..
self.Name..": Player "..self.AttackedPlayer.." is dead :-(")return true elseif self.KillsNeeded<0 then
dbg(vQj.Identifier..
" "..self.Name..": Amount negative")return true end end;function b_Goal_DestroySoldiers:GetIcon()return{7,12}end;function b_Goal_DestroySoldiers:Reset()self.SaveAmount=
nil end
Core:RegisterBehavior(b_Goal_DestroySoldiers)
function Goal_EntityDistance(...)return b_Goal_EntityDistance:new(...)end
b_Goal_EntityDistance={Name="Goal_EntityDistance",Description={en="Goal: Distance between two entities",de="Ziel: Zwei Entities sollen zueinander eine Entfernung über- oder unterschreiten."},Parameter={{ParameterType.ScriptName,en="Entity 1",de="Entity 1"},{ParameterType.ScriptName,en="Entity 2",de="Entity 2"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Distance",de="Entfernung"}}}
function b_Goal_EntityDistance:GetGoalTable(sVBxyy)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_EntityDistance:AddParameter(N9d,S7)
if(N9d==0)then self.Entity1=S7 elseif(N9d==1)then
self.Entity2=S7 elseif(N9d==2)then self.bRelSmallerThan=S7 =="<"elseif(N9d==3)then self.Distance=S7*1 end end
function b_Goal_EntityDistance:CustomFunction(bJtvRSR)
if Logic.IsEntityDestroyed(self.Entity1)or
Logic.IsEntityDestroyed(self.Entity2)then return false end;local aBhZK5=GetID(self.Entity1)local Jz8JUscj=GetID(self.Entity2)
local O=Logic.CheckEntitiesDistance(aBhZK5,Jz8JUscj,self.Distance)
if(self.bRelSmallerThan and O)or
(not self.bRelSmallerThan and not O)then return true end end
function b_Goal_EntityDistance:GetCustomData(tGmbAgE)local oU_r={}
if tGmbAgE==2 then
table.insert(oU_r,">")table.insert(oU_r,"<")else assert(false)end;return oU_r end
function b_Goal_EntityDistance:DEBUG(n_lv)
if not IsExisting(self.Entity1)or not
IsExisting(self.Entity2)then
dbg(""..n_lv.Identifier..
" "..self.Name..
": At least 1 of the entities for distance check don't exist!")return true end;return false end;Core:RegisterBehavior(b_Goal_EntityDistance)function Goal_KnightDistance(...)return
b_Goal_KnightDistance:new(...)end
b_Goal_KnightDistance={Name="Goal_KnightDistance",Description={en="Goal: Bring the knight close to a given entity",de="Ziel: Bringe den Ritter nah an eine bestimmte Entität"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.ScriptName,en="Target",de="Ziel"}}}
function b_Goal_KnightDistance:GetGoalTable()return
{Objective.Distance,Logic.GetKnightID(self.PlayerID),self.Target,2500,true}end
function b_Goal_KnightDistance:AddParameter(UYQF,WXx)if(UYQF==0)then self.PlayerID=WXx*1 elseif(UYQF==1)then
self.Target=WXx end end;Core:RegisterBehavior(b_Goal_KnightDistance)function Goal_UnitsOnTerritory(...)return
b_Goal_UnitsOnTerritory:new(...)end
b_Goal_UnitsOnTerritory={Name="Goal_UnitsOnTerritory",Description={en="Goal: Place a certain amount of units on a territory",de="Ziel: Platziere eine bestimmte Anzahl Einheiten auf einem Gebiet"},Parameter={{ParameterType.TerritoryNameWithUnknown,en="Territory",de="Territorium"},{ParameterType.Custom,en="Player",de="Spieler"},{ParameterType.Custom,en="Category",de="Kategorie"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Number of units",de="Anzahl Einheiten"}}}
function b_Goal_UnitsOnTerritory:GetGoalTable(W4EuxJXi)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_UnitsOnTerritory:AddParameter(BlYNd61h,XDPndG)
if(BlYNd61h==0)then
self.TerritoryID=tonumber(XDPndG)if self.TerritoryID==nil then
self.TerritoryID=GetTerritoryIDByName(XDPndG)end elseif(BlYNd61h==1)then self.PlayerID=
tonumber(XDPndG)*1 elseif(BlYNd61h==2)then self.Category=XDPndG elseif
(BlYNd61h==3)then
self.bRelSmallerThan=(tostring(XDPndG)=="true"or tostring(XDPndG)=="<")elseif(BlYNd61h==4)then self.NumberOfUnits=XDPndG*1 end end
function b_Goal_UnitsOnTerritory:CustomFunction(sJYFQIP4)
local Ogq0S2=GetEntitiesOfCategoryInTerritory(self.PlayerID,EntityCategories[self.Category],self.TerritoryID)
if
self.bRelSmallerThan==false and#Ogq0S2 >=self.NumberOfUnits then return true elseif
self.bRelSmallerThan==true and#Ogq0S2 <self.NumberOfUnits then return true end end
function b_Goal_UnitsOnTerritory:GetCustomData(n8Cw3SR)local GJqd7gt={}
if n8Cw3SR==1 then
table.insert(GJqd7gt,-1)for slE5aDm2=1,8 do table.insert(GJqd7gt,slE5aDm2)end elseif
n8Cw3SR==2 then for aL_g,IMUI10L in pairs(EntityCategories)do
if not string.find(aL_g,"^G_")and
aL_g~="SheepPasture"then table.insert(GJqd7gt,aL_g)end end
table.sort(GJqd7gt)elseif n8Cw3SR==3 then table.insert(GJqd7gt,">=")
table.insert(GJqd7gt,"<")else assert(false)end;return GJqd7gt end
function b_Goal_UnitsOnTerritory:DEBUG(vPA)
local pUXZ6G4={Logic.GetTerritories()}
if

tonumber(self.TerritoryID)==nil or self.TerritoryID<0 or not Inside(self.TerritoryID,pUXZ6G4)then
dbg(""..vPA.Identifier..
" "..self.Name..": got an invalid territoryID!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<0 or self.PlayerID>8 then
dbg(""..vPA.Identifier.." "..self.Name..
": got an invalid playerID!")return true elseif not EntityCategories[self.Category]then
dbg(""..
vPA.Identifier.." "..
self.Name..": got an invalid playerID!")return true elseif tonumber(self.NumberOfUnits)==nil or
self.NumberOfUnits<0 then
dbg(""..vPA.Identifier.." "..
self.Name..": amount is negative or nil!")return true end;return false end;Core:RegisterBehavior(b_Goal_UnitsOnTerritory)function Goal_ActivateBuff(...)return
b_Goal_ActivateBuff:new(...)end
b_Goal_ActivateBuff={Name="Goal_ActivateBuff",Description={en="Goal: Activate a buff",de="Ziel: Aktiviere einen Buff"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Buff",de="Buff"}}}
function b_Goal_ActivateBuff:GetGoalTable(mk)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_ActivateBuff:AddParameter(OeQex1U4,i0cV9)
if(OeQex1U4 ==0)then self.PlayerID=i0cV9*1 elseif
(OeQex1U4 ==1)then self.BuffName=i0cV9;self.Buff=Buffs[i0cV9]end end
function b_Goal_ActivateBuff:CustomFunction(EGD)
if
not EGD.QuestDescription or EGD.QuestDescription==""then local B_kkL=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
local u=(B_kkL=="de"and
"BONUS AKTIVIEREN{cr}{cr}")or"ACTIVATE BUFF{cr}{cr}"
local EO6Y={["Buff_Spice"]={de="Salz",en="Salt"},["Buff_Colour"]={de="Farben",en="Color"},["Buff_Entertainers"]={de="Entertainer",en="Entertainer"},["Buff_FoodDiversity"]={de="Vielf�ltige Nahrung",en="Food diversity"},["Buff_ClothesDiversity"]={de="Vielf�ltige Kleidung",en="Clothes diversity"},["Buff_HygieneDiversity"]={de="Vielf�ltige Reinigung",en="Hygiene diversity"},["Buff_EntertainmentDiversity"]={de="Vielf�ltige Unterhaltung",en="Entertainment diversity"},["Buff_Sermon"]={de="Predigt",en="Sermon"},["Buff_Festival"]={de="Fest",en="Festival"},["Buff_ExtraPayment"]={de="Sonderzahlung",en="Extra payment"},["Buff_HighTaxes"]={de="Hohe Steuern",en="High taxes"},["Buff_NoPayment"]={de="Kein Sold",en="No payment"},["Buff_NoTaxes"]={de="Keine Steuern",en="No taxes"}}
if g_GameExtraNo>=1 then
EO6Y["Buff_Gems"]={de="Edelsteine",en="Gems"}
EO6Y["Buff_MusicalInstrument"]={de="Musikinstrumente",en="Musical instruments"}EO6Y["Buff_Olibanum"]={de="Weihrauch",en="Olibanum"}end
local i_053JPY="{center}"..u..EO6Y[self.BuffName][B_kkL]Core:ChangeCustomQuestCaptionText(i_053JPY,EGD)end;local VWiGCreH=Logic.GetBuff(self.PlayerID,self.Buff)if VWiGCreH and
VWiGCreH~=0 then return true end end
function b_Goal_ActivateBuff:GetCustomData(l)local UK={}
if l==1 then
UK={"Buff_Spice","Buff_Colour","Buff_Entertainers","Buff_FoodDiversity","Buff_ClothesDiversity","Buff_HygieneDiversity","Buff_EntertainmentDiversity","Buff_Sermon","Buff_Festival","Buff_ExtraPayment","Buff_HighTaxes","Buff_NoPayment","Buff_NoTaxes"}
if g_GameExtraNo>=1 then table.insert(UK,"Buff_Gems")
table.insert(UK,"Buff_MusicalInstrument")table.insert(UK,"Buff_Olibanum")end;table.sort(UK)else assert(false)end;return UK end
function b_Goal_ActivateBuff:GetIcon()
local NzaICo={[Buffs.Buff_Spice]="Goods.G_Salt",[Buffs.Buff_Colour]="Goods.G_Dye",[Buffs.Buff_Entertainers]="Entities.U_Entertainer_NA_FireEater",[Buffs.Buff_FoodDiversity]="Needs.Nutrition",[Buffs.Buff_ClothesDiversity]="Needs.Clothes",[Buffs.Buff_HygieneDiversity]="Needs.Hygiene",[Buffs.Buff_EntertainmentDiversity]="Needs.Entertainment",[Buffs.Buff_Sermon]="Technologies.R_Sermon",[Buffs.Buff_Festival]="Technologies.R_Festival",[Buffs.Buff_ExtraPayment]={1,8},[Buffs.Buff_HighTaxes]={1,6},[Buffs.Buff_NoPayment]={1,8},[Buffs.Buff_NoTaxes]={1,6}}
if g_GameExtraNo and g_GameExtraNo>=1 then
NzaICo[Buffs.Buff_Gems]="Goods.G_Gems"
NzaICo[Buffs.Buff_MusicalInstrument]="Goods.G_MusicalInstrument"NzaICo[Buffs.Buff_Olibanum]="Goods.G_Olibanum"end;return NzaICo[self.Buff]end
function b_Goal_ActivateBuff:DEBUG(k1X83nYm)
if not self.Buff then
dbg(""..k1X83nYm.Identifier..
" "..self.Name..": buff '"..self.BuffName..
"' does not exist!")return true elseif
not tonumber(self.PlayerID)or self.PlayerID<1 or self.PlayerID>8 then
dbg(""..
k1X83nYm.Identifier.." "..self.Name..
": got an invalid playerID!")return true end;return false end;Core:RegisterBehavior(b_Goal_ActivateBuff)function Goal_BuildRoad(...)return
b_Goal_BuildRoad:new(...)end
b_Goal_BuildRoad={Name="Goal_BuildRoad",Description={en="Goal: Connect two points with a street or a road",de="Ziel: Verbinde zwei Punkte mit einer Strasse oder einem Weg."},Parameter={{ParameterType.ScriptName,en="Entity 1",de="Entity 1"},{ParameterType.ScriptName,en="Entity 2",de="Entity 2"},{ParameterType.Custom,en="Only roads",de="Nur Strassen"}}}
function b_Goal_BuildRoad:GetGoalTable(xxzxfj)return
{Objective.BuildRoad,{GetID(self.Entity1),GetID(self.Entity2),false,0,self.bRoadsOnly}}end
function b_Goal_BuildRoad:AddParameter(_ad1m4I,H1QsS)
if(_ad1m4I==0)then self.Entity1=H1QsS elseif(_ad1m4I==1)then
self.Entity2=H1QsS elseif(_ad1m4I==2)then
self.bRoadsOnly=AcceptAlternativeBoolean(H1QsS)end end;function b_Goal_BuildRoad:GetCustomData(rIMx)local TiA
if rIMx==2 then TiA={"true","false"}end;return TiA end
function b_Goal_BuildRoad:DEBUG(Y51P)
if
not IsExisting(self.Entity1)or
not IsExisting(self.Entity2)then
dbg(""..Y51P.Identifier.." "..
self.Name..": first or second entity does not exist!")return true end;return false end;Core:RegisterBehavior(b_Goal_BuildRoad)function Goal_BuildWall(...)return
b_Goal_BuildWall:new(...)end
b_Goal_BuildWall={Name="Goal_BuildWall",Description={en="Goal: Build a wall between 2 positions bo stop the movement of an (hostile) player.",de="Ziel: Baue eine Mauer zwischen 2 Punkten, die die Bewegung eines (feindlichen) Spielers zwischen den Punkten verhindert."},Parameter={{ParameterType.PlayerID,en="Enemy",de="Feind"},{ParameterType.ScriptName,en="Entity 1",de="Entity 1"},{ParameterType.ScriptName,en="Entity 2",de="Entity 2"}}}
function b_Goal_BuildWall:GetGoalTable(ichL)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_BuildWall:AddParameter(NOK,Alv)
if(NOK==0)then self.PlayerID=Alv*1 elseif(NOK==1)then
self.EntityName1=Alv elseif(NOK==2)then self.EntityName2=Alv end end
function b_Goal_BuildWall:CustomFunction(YeLO2)local CkrmO=GetID(self.EntityName1)
local ooovsSJe=GetID(self.EntityName2)if not IsExisting(CkrmO)then return false end;if not
IsExisting(ooovsSJe)then return false end
local s5IsD,KvYEVoXt,VWWD_P=Logic.EntityGetPos(CkrmO)if Logic.IsBuilding(CkrmO)==1 then
s5IsD,KvYEVoXt=Logic.GetBuildingApproachPosition(CkrmO)end
local zsMuNkv=Logic.GetPlayerSectorAtPosition(self.PlayerID,s5IsD,KvYEVoXt)local s5IsD,KvYEVoXt,VWWD_P=Logic.EntityGetPos(ooovsSJe)if
Logic.IsBuilding(ooovsSJe)==1 then
s5IsD,KvYEVoXt=Logic.GetBuildingApproachPosition(ooovsSJe)end
local aXxi=Logic.GetPlayerSectorAtPosition(self.PlayerID,s5IsD,KvYEVoXt)if zsMuNkv~=aXxi then return true end;return nil end
function b_Goal_BuildWall:GetMsgKey()return"Quest_Create_Wall"end;function b_Goal_BuildWall:GetIcon()return{3,9}end
function b_Goal_BuildWall:DEBUG(Q18a7QTy)
if
not
IsExisting(self.EntityName1)or not IsExisting(self.EntityName2)then
dbg(""..Q18a7QTy.Identifier..
" "..self.Name..": first or second entity does not exist!")return true elseif
not tonumber(self.PlayerID)or self.PlayerID<1 or self.PlayerID>8 then
dbg(""..
Q18a7QTy.Identifier.." "..self.Name..
": got an invalid playerID!")return true end
if
GetDiplomacyState(Q18a7QTy.ReceivingPlayer,self.PlayerID)>-1 and not self.WarningPrinted then
warn(""..
Q18a7QTy.Identifier..
" "..self.Name..": player %d is neighter enemy or unknown to quest receiver!")self.WarningPrinted=true end;return false end;Core:RegisterBehavior(b_Goal_BuildWall)function Goal_Claim(...)return
b_Goal_Claim:new(...)end
b_Goal_Claim={Name="Goal_Claim",Description={en="Goal: Claim a territory",de="Ziel: Erobere ein Territorium"},Parameter={{ParameterType.TerritoryName,en="Territory",de="Territorium"}}}function b_Goal_Claim:GetGoalTable(K5Rp6)
return{Objective.Claim,1,self.TerritoryID}end
function b_Goal_Claim:AddParameter(GTIA,gdPUe)
if(GTIA==0)then
self.TerritoryID=tonumber(gdPUe)if not self.TerritoryID then
self.TerritoryID=GetTerritoryIDByName(gdPUe)end end end
function b_Goal_Claim:GetMsgKey()return"Quest_Claim_Territory"end;Core:RegisterBehavior(b_Goal_Claim)function Goal_ClaimXTerritories(...)return
b_Goal_ClaimXTerritories:new(...)end
b_Goal_ClaimXTerritories={Name="Goal_ClaimXTerritories",Description={en="Goal: Claim the given number of territories, all player territories are counted",de="Ziel: Erobere die angegebene Anzahl Territorien, alle spielereigenen Territorien werden gezählt"},Parameter={{ParameterType.Number,en="Territories",de="Territorien"}}}
function b_Goal_ClaimXTerritories:GetGoalTable(_bxEn)return
{Objective.Claim,2,self.TerritoriesToClaim}end
function b_Goal_ClaimXTerritories:AddParameter(pcN_ceXY,_P)if(pcN_ceXY==0)then
self.TerritoriesToClaim=_P*1 end end
function b_Goal_ClaimXTerritories:GetMsgKey()return"Quest_Claim_Territory"end;Core:RegisterBehavior(b_Goal_ClaimXTerritories)function Goal_Create(...)return
b_Goal_Create:new(...)end
b_Goal_Create={Name="Goal_Create",Description={en="Goal: Create Buildings/Units on a specified territory",de="Ziel: Erstelle Einheiten/Gebäude auf einem bestimmten Territorium."},Parameter={{ParameterType.Entity,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.TerritoryNameWithUnknown,en="Territory",de="Territorium"}}}
function b_Goal_Create:GetGoalTable(rq)return
{Objective.Create,assert(Entities[self.EntityName]),self.Amount,self.TerritoryID}end
function b_Goal_Create:AddParameter(mo,I)
if(mo==0)then self.EntityName=I elseif(mo==1)then self.Amount=I*1 elseif
(mo==2)then self.TerritoryID=tonumber(I)if not self.TerritoryID then
self.TerritoryID=GetTerritoryIDByName(I)end end end
function b_Goal_Create:GetMsgKey()
return


Logic.IsEntityTypeInCategory(Entities[self.EntityName],EntityCategories.AttackableBuilding)==1 and"Quest_Create_Building"or"Quest_Create_Unit"end;Core:RegisterBehavior(b_Goal_Create)function Goal_Produce(...)return
b_Goal_Produce:new(...)end
b_Goal_Produce={Name="Goal_Produce",Description={en="Goal: Produce an amount of goods",de="Ziel: Produziere eine Anzahl einer bestimmten Ware."},Parameter={{ParameterType.RawGoods,en="Type of good",de="Ressourcentyp"},{ParameterType.Number,en="Amount of good",de="Anzahl der Ressource"}}}
function b_Goal_Produce:GetGoalTable(RAAJAsR)
local c1pjj7=Logic.GetGoodTypeID(self.GoodTypeName)return{Objective.Produce,c1pjj7,self.GoodAmount}end
function b_Goal_Produce:AddParameter(BMv,NQh8)if(BMv==0)then self.GoodTypeName=NQh8 elseif(BMv==1)then
self.GoodAmount=NQh8*1 end end;function b_Goal_Produce:GetMsgKey()return"Quest_Produce"end
Core:RegisterBehavior(b_Goal_Produce)
function Goal_GoodAmount(...)return b_Goal_GoodAmount:new(...)end
b_Goal_GoodAmount={Name="Goal_GoodAmount",Description={en="Goal: Obtain an amount of goods - either by trading or producing them",de="Ziel: Beschaffe eine Anzahl Waren - entweder durch Handel oder durch eigene Produktion."},Parameter={{ParameterType.Custom,en="Type of good",de="Warentyp"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.Custom,en="Relation",de="Relation"}}}
function b_Goal_GoodAmount:GetGoalTable(P)
local bkTe=Logic.GetGoodTypeID(self.GoodTypeName)
return{Objective.Produce,bkTe,self.GoodAmount,self.bRelSmallerThan}end
function b_Goal_GoodAmount:AddParameter(ohmPbyDd,D)
if(ohmPbyDd==0)then self.GoodTypeName=D elseif
(ohmPbyDd==1)then self.GoodAmount=D*1 elseif(ohmPbyDd==2)then self.bRelSmallerThan=D=="<"or
tostring(D)=="true"end end
function b_Goal_GoodAmount:GetCustomData(DfDLWkT)local MTU8HP4d={}
if DfDLWkT==0 then for hIM_cG0i,jD in pairs(Goods)do
if
string.find(hIM_cG0i,"^G_")then table.insert(MTU8HP4d,hIM_cG0i)end end
table.sort(MTU8HP4d)elseif DfDLWkT==2 then table.insert(MTU8HP4d,">=")
table.insert(MTU8HP4d,"<")else assert(false)end;return MTU8HP4d end;Core:RegisterBehavior(b_Goal_GoodAmount)function Goal_SatisfyNeed(...)return
b_Goal_SatisfyNeed:new(...)end
b_Goal_SatisfyNeed={Name="Goal_SatisfyNeed",Description={en="Goal: Satisfy a need",de="Ziel: Erfuelle ein Beduerfnis"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Need,en="Need",de="Beduerfnis"}}}
function b_Goal_SatisfyNeed:GetGoalTable(me)return
{Objective.SatisfyNeed,self.PlayerID,assert(Needs[self.Need])}end
function b_Goal_SatisfyNeed:AddParameter(sgU5HAMG,FDydY)if(sgU5HAMG==0)then self.PlayerID=FDydY*1 elseif
(sgU5HAMG==1)then self.Need=FDydY end end
function b_Goal_SatisfyNeed:GetMsgKey()
local PEZ_={[Needs.Clothes]="Quest_SatisfyNeed_Clothes",[Needs.Entertainment]="Quest_SatisfyNeed_Entertainment",[Needs.Nutrition]="Quest_SatisfyNeed_Food",[Needs.Hygiene]="Quest_SatisfyNeed_Hygiene",[Needs.Medicine]="Quest_SatisfyNeed_Medicine"}local c=PEZ_[Needs[self.Need]]if c then return c end end;Core:RegisterBehavior(b_Goal_SatisfyNeed)function Goal_SettlersNumber(...)return
b_Goal_SettlersNumber:new(...)end
b_Goal_SettlersNumber={Name="Goal_SettlersNumber",Description={en="Goal: Get a given amount of settlers",de="Ziel: Erreiche eine bestimmte Anzahl Siedler."},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"}}}
function b_Goal_SettlersNumber:GetGoalTable()return
{Objective.SettlersNumber,1,self.SettlersAmount}end;function b_Goal_SettlersNumber:AddParameter(ElbTbcZG,r3)
if(ElbTbcZG==0)then self.SettlersAmount=r3*1 end end;function b_Goal_SettlersNumber:GetMsgKey()return
"Quest_NumberSettlers"end
Core:RegisterBehavior(b_Goal_SettlersNumber)
function Goal_Spouses(...)return b_Goal_Spouses:new(...)end
b_Goal_Spouses={Name="Goal_Spouses",Description={en="Goal: Get a given amount of spouses",de="Ziel: Erreiche eine bestimmte Ehefrauenanzahl"},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"}}}function b_Goal_Spouses:GetGoalTable()
return{Objective.Spouses,self.SpousesAmount}end
function b_Goal_Spouses:AddParameter(p,UiVYRok)if(p==0)then self.SpousesAmount=
UiVYRok*1 end end
function b_Goal_Spouses:GetMsgKey()return"Quest_NumberSpouses"end;Core:RegisterBehavior(b_Goal_Spouses)function Goal_SoldierCount(...)return
b_Goal_SoldierCount:new(...)end
b_Goal_SoldierCount={Name="Goal_SoldierCount",Description={en="Goal: Create a specified number of soldiers",de="Ziel: Erreiche eine Anzahl grösser oder kleiner der angegebenen Menge Soldaten."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Number of soldiers",de="Anzahl Soldaten"}}}
function b_Goal_SoldierCount:GetGoalTable(jvPsY9)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_SoldierCount:AddParameter(tE,Bmuypm)
if(tE==0)then self.PlayerID=Bmuypm*1 elseif(tE==1)then
self.bRelSmallerThan=
tostring(Bmuypm)=="true"or tostring(Bmuypm)=="<"elseif(tE==2)then self.NumberOfUnits=Bmuypm*1 end end
function b_Goal_SoldierCount:CustomFunction(hW)
if
not hW.QuestDescription or hW.QuestDescription==""then local kCwLIk=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
local _l=(kCwLIk=="de"and
"SOLDATENANZAHL {cr}Partei: ")or"SOLDIERS {cr}faction: "local rjQ=tostring(self.bRelSmallerThan)
local Euo0={["true"]={de="Weniger als",en="Less than"},["false"]={de="Mindestens",en="At least"}}local LIV=GetPlayerName(self.PlayerID)
if LIV==""or LIV==nil then LIV=
((kCwLIk==
"de"and"Spieler ")or"Player ")..self.PlayerID end
local vydlAbZ3="{center}"..
_l..LIV.."{cr}{cr}"..
Euo0[rjQ][kCwLIk].." "..self.NumberOfUnits;Core:ChangeCustomQuestCaptionText(vydlAbZ3,hW)end;local iOcgdUx=Logic.GetCurrentSoldierCount(self.PlayerID)
if
(
self.bRelSmallerThan and iOcgdUx<self.NumberOfUnits)then return true elseif
(not self.bRelSmallerThan and iOcgdUx>=self.NumberOfUnits)then return true end;return nil end
function b_Goal_SoldierCount:GetCustomData(BXxv5z)local mKLU={}
if BXxv5z==1 then
table.insert(mKLU,">=")table.insert(mKLU,"<")else assert(false)end;return mKLU end;function b_Goal_SoldierCount:GetIcon()return{7,11}end;function b_Goal_SoldierCount:GetMsgKey()return
"Quest_Create_Unit"end
function b_Goal_SoldierCount:DEBUG(Him)
if
tonumber(self.NumberOfUnits)==nil or self.NumberOfUnits<0 then
dbg(""..

Him.Identifier.." "..self.Name..": amount can not be below 0!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
dbg(""..Him.Identifier.." "..self.Name..
": got an invalid playerID!")return true end;return false end;Core:RegisterBehavior(b_Goal_SoldierCount)function Goal_KnightTitle(...)return
b_Goal_KnightTitle:new(...)end
b_Goal_KnightTitle={Name="Goal_KnightTitle",Description={en="Goal: Reach a specified knight title",de="Ziel: Erreiche einen vorgegebenen Titel"},Parameter={{ParameterType.Custom,en="Knight title",de="Titel"}}}
function b_Goal_KnightTitle:GetGoalTable()return
{Objective.KnightTitle,assert(KnightTitles[self.KnightTitle])}end;function b_Goal_KnightTitle:AddParameter(cPDhu,UQnOS)
if(cPDhu==0)then self.KnightTitle=UQnOS end end;function b_Goal_KnightTitle:GetMsgKey()return
"Quest_KnightTitle"end
function b_Goal_KnightTitle:GetCustomData(tRWU)return
{"Knight","Mayor","Baron","Earl","Marquees","Duke","Archduke"}end;Core:RegisterBehavior(b_Goal_KnightTitle)function Goal_Festivals(...)return
b_Goal_Festivals:new(...)end
b_Goal_Festivals={Name="Goal_Festivals",Description={en="Goal: The player has to start the given number of festivals.",de="Ziel: Der Spieler muss eine gewisse Anzahl Feste gestartet haben."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Number,en="Number of festivals",de="Anzahl Feste"}}}function b_Goal_Festivals:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_Festivals:AddParameter(X2Zy_nb,ITtw3N7E)
if
X2Zy_nb==0 then self.PlayerID=tonumber(ITtw3N7E)else
assert(X2Zy_nb==1,"Error in "..self.Name..
": AddParameter: Index is invalid.")self.NeededFestivals=tonumber(ITtw3N7E)end end
function b_Goal_Festivals:CustomFunction(yozOp)
if not yozOp.QuestDescription or
yozOp.QuestDescription==""then
local CLSdD=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
local Fh=(CLSdD=="de"and"FESTE FEIERN {cr}{cr}Partei: ")or
"HOLD PARTIES {cr}{cr}faction: "
local IlAPA=(CLSdD=="de"and"Anzahl: ")or"Amount: "local jLKMpQuK=GetPlayerName(self.PlayerID)
if
jLKMpQuK==""or jLKMpQuK==nil then jLKMpQuK=
((CLSdD=="de"and"Spieler ")or"Player ")..self.PlayerID end
local sUQpby="{center}"..Fh..jLKMpQuK..
"{cr}{cr}"..IlAPA.." "..self.NeededFestivals;Core:ChangeCustomQuestCaptionText(sUQpby,yozOp)end
if Logic.GetStoreHouse(self.PlayerID)==0 then return false end
local wxU={Logic.GetPlayerEntities(self.PlayerID,Entities.B_TableBeer,5,0)}local kOmS5sy=0
for mbA=2,#wxU do local _qPhpaFx=wxU[mbA]
if
Logic.GetIndexOnOutStockByGoodType(_qPhpaFx,Goods.G_Beer)~=-1 then
local zex=Logic.GetAmountOnOutStockByGoodType(_qPhpaFx,Goods.G_Beer)kOmS5sy=kOmS5sy+zex end end
if not self.FestivalStarted and kOmS5sy>0 then
self.FestivalStarted=true;self.FestivalCounter=
(self.FestivalCounter and self.FestivalCounter+1)or 1
if
self.FestivalCounter>=self.NeededFestivals then self.FestivalCounter=nil;return true end elseif kOmS5sy==0 then self.FestivalStarted=false end end
function b_Goal_Festivals:DEBUG(pPGcdu)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
dbg(pPGcdu.Identifier..": Error in "..self.Name..
": Player "..self.PlayerID.." is dead :-(")return true elseif
GetPlayerCategoryType(self.PlayerID)~=PlayerCategories.City then
dbg(pPGcdu.Identifier..": Error in "..self.Name..
":  Player "..self.PlayerID.." is no city")return true elseif self.NeededFestivals<0 then
dbg(pPGcdu.Identifier..": Error in "..
self.Name..": Number of Festivals is negative")return true end;return false end
function b_Goal_Festivals:Reset()self.FestivalCounter=nil;self.FestivalStarted=nil end;function b_Goal_Festivals:GetIcon()return{4,15}end
Core:RegisterBehavior(b_Goal_Festivals)
function Goal_Capture(...)return b_Goal_Capture:new(...)end
b_Goal_Capture={Name="Goal_Capture",Description={en="Goal: Capture a cart.",de="Ziel: Ein Karren muss erobert werden."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}function b_Goal_Capture:GetGoalTable(rjp)
return{Objective.Capture,1,{self.ScriptName}}end
function b_Goal_Capture:AddParameter(cT2z,z)if
(cT2z==0)then self.ScriptName=z end end
function b_Goal_Capture:GetMsgKey()local ke1tWps=GetID(self.ScriptName)
if
Logic.IsEntityAlive(ke1tWps)then ke1tWps=Logic.GetEntityType(ke1tWps)
if ke1tWps and ke1tWps~=0 then
if
Logic.IsEntityTypeInCategory(ke1tWps,EntityCategories.AttackableMerchant)==1 then return"Quest_Capture_Cart"elseif
Logic.IsEntityTypeInCategory(ke1tWps,EntityCategories.SiegeEngine)==1 then return"Quest_Capture_SiegeEngine"elseif


Logic.IsEntityTypeInCategory(ke1tWps,EntityCategories.Worker)==1 or
Logic.IsEntityTypeInCategory(ke1tWps,EntityCategories.Spouse)==1 or
Logic.IsEntityTypeInCategory(ke1tWps,EntityCategories.Hero)==1 then return"Quest_Capture_VIPOfPlayer"end end end end;Core:RegisterBehavior(b_Goal_Capture)function Goal_CaptureType(...)return
b_Goal_CaptureType:new(...)end
b_Goal_CaptureType={Name="Goal_CaptureType",Description={en="Goal: Capture specified entity types",de="Ziel: Nimm bestimmte Entitätstypen gefangen"},Parameter={{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function b_Goal_CaptureType:GetGoalTable(gRFA)return
{Objective.Capture,2,Entities[self.EntityName],self.Amount,self.PlayerID}end
function b_Goal_CaptureType:AddParameter(jX9a0tJX,YFy4TGc)
if(jX9a0tJX==0)then self.EntityName=YFy4TGc elseif
(jX9a0tJX==1)then self.Amount=YFy4TGc*1 elseif(jX9a0tJX==2)then self.PlayerID=YFy4TGc*1 end end
function b_Goal_CaptureType:GetCustomData(YjpbYkCb)local L1p7luJ={}
if YjpbYkCb==0 then
for eH,WpOZ in pairs(Entities)do
if

string.find(eH,"^U_.+Cart")or
Logic.IsEntityTypeInCategory(WpOZ,EntityCategories.AttackableMerchant)==1 then table.insert(L1p7luJ,eH)end end;table.sort(L1p7luJ)elseif YjpbYkCb==2 then for fD2289=0,8 do
table.insert(L1p7luJ,fD2289)end else assert(false)end;return L1p7luJ end
function b_Goal_CaptureType:GetMsgKey()local folfO=self.EntityName
if
Logic.IsEntityTypeInCategory(folfO,EntityCategories.AttackableMerchant)==1 then return"Quest_Capture_Cart"elseif
Logic.IsEntityTypeInCategory(folfO,EntityCategories.SiegeEngine)==1 then return"Quest_Capture_SiegeEngine"elseif


Logic.IsEntityTypeInCategory(folfO,EntityCategories.Worker)==1 or
Logic.IsEntityTypeInCategory(folfO,EntityCategories.Spouse)==1 or
Logic.IsEntityTypeInCategory(folfO,EntityCategories.Hero)==1 then return"Quest_Capture_VIPOfPlayer"end end;Core:RegisterBehavior(b_Goal_CaptureType)function Goal_Protect(...)return
b_Goal_Protect:new(...)end
b_Goal_Protect={Name="Goal_Protect",Description={en="Goal: Protect an entity (entity needs a script name",de="Ziel: Beschuetze eine Entität (Entität benötigt einen Skriptnamen)"},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}function b_Goal_Protect:GetGoalTable()
return{Objective.Protect,{self.ScriptName}}end;function b_Goal_Protect:AddParameter(vtsK,E1p4Mv)if(vtsK==0)then
self.ScriptName=E1p4Mv end end
function b_Goal_Protect:GetMsgKey()
if
Logic.IsEntityAlive(self.ScriptName)then local IHap=GetID(self.ScriptName)
if IHap and IHap~=0 then
IHap=Logic.GetEntityType(IHap)
if IHap and IHap~=0 then
if
Logic.IsEntityTypeInCategory(IHap,EntityCategories.AttackableBuilding)==1 then return"Quest_Protect_Building"elseif
Logic.IsEntityTypeInCategory(IHap,EntityCategories.SpecialBuilding)==1 then
local rDvV={[PlayerCategories.City]="Quest_Protect_City",[PlayerCategories.Cloister]="Quest_Protect_Cloister",[PlayerCategories.Village]="Quest_Protect_Village"}
local RX1L2q=GetPlayerCategoryType(Logic.EntityGetPlayer(GetID(self.ScriptName)))
if RX1L2q then local bCBtWguf=rDvV[RX1L2q]if bCBtWguf then return bCBtWguf end end;return"Quest_Protect_Building"elseif
Logic.IsEntityTypeInCategory(IHap,EntityCategories.Hero)==1 then return"Quest_Protect_Knight"elseif
Logic.IsEntityTypeInCategory(IHap,EntityCategories.AttackableMerchant)==1 then return"Quest_Protect_Cart"end end end end;return"Quest_Protect"end;Core:RegisterBehavior(b_Goal_Protect)function Goal_Refill(...)return
b_Goal_Refill:new(...)end
b_Goal_Refill={Name="Goal_Refill",Description={en="Goal: Refill an object using a geologist",de="Ziel: Eine Mine soll durch einen Geologen wieder aufgefuellt werden."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}},RequiresExtraNo=1}function b_Goal_Refill:GetGoalTable()return
{Objective.Refill,{GetID(self.ScriptName)}}end;function b_Goal_Refill:GetIcon()return
{8,1,1}end;function b_Goal_Refill:AddParameter(q,e1sXUN4f)if(q==0)then
self.ScriptName=e1sXUN4f end end
Core:RegisterBehavior(b_Goal_Refill)
function Goal_ResourceAmount(...)return b_Goal_ResourceAmount:new(...)end
b_Goal_ResourceAmount={Name="Goal_ResourceAmount",Description={en="Goal: Reach a specified amount of resources in a doodad",de="Ziel: In einer Mine soll weniger oder mehr als eine angegebene Anzahl an Rohstoffen sein."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Amount",de="Menge"}}}
function b_Goal_ResourceAmount:GetGoalTable(x)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_ResourceAmount:AddParameter(VP,IQwqq)
if(VP==0)then self.ScriptName=IQwqq elseif(VP==1)then self.bRelSmallerThan=
IQwqq=="<"elseif(VP==2)then self.Amount=IQwqq*1 end end
function b_Goal_ResourceAmount:CustomFunction(Xcc4)local fqw5=GetID(self.ScriptName)
if
fqw5 and
fqw5 ~=0 and Logic.GetResourceDoodadGoodType(fqw5)~=0 then local qnVfOeRE=Logic.GetResourceDoodadGoodAmount(fqw5)
if(
self.bRelSmallerThan and qnVfOeRE<self.Amount)or
(not
self.bRelSmallerThan and qnVfOeRE>self.Amount)then return true end end;return nil end
function b_Goal_ResourceAmount:GetCustomData(YIiSKsxK)local Ua={}
if YIiSKsxK==1 then
table.insert(Ua,">")table.insert(Ua,"<")else assert(false)end;return Ua end
function b_Goal_ResourceAmount:DEBUG(qeJtG)
if not IsExisting(self.ScriptName)then
dbg(""..

qeJtG.Identifier.." "..self.Name..
": entity '"..self.ScriptName.."' does not exist!")return true elseif
tonumber(self.Amount)==nil or self.Amount<0 then
dbg(""..qeJtG.Identifier..
" "..self.Name..": error at amount! (nil or below 0)")return true end;return false end;Core:RegisterBehavior(b_Goal_ResourceAmount)function Goal_InstantFailure()return
b_Goal_InstantFailure:new()end
b_Goal_InstantFailure={Name="Goal_InstantFailure",Description={en="Instant failure, the goal returns false.",de="Direkter Misserfolg, das Goal sendet false."}}
function b_Goal_InstantFailure:GetGoalTable(pdpNgBcZ)return{Objective.DummyFail}end;Core:RegisterBehavior(b_Goal_InstantFailure)function Goal_InstantSuccess()return
b_Goal_InstantSuccess:new()end
b_Goal_InstantSuccess={Name="Goal_InstantSuccess",Description={en="Instant success, the goal returns true.",de="Direkter Erfolg, das Goal sendet true."}}
function b_Goal_InstantSuccess:GetGoalTable(wV)return{Objective.Dummy}end;Core:RegisterBehavior(b_Goal_InstantSuccess)function Goal_NoChange()return
b_Goal_NoChange:new()end
b_Goal_NoChange={Name="Goal_NoChange",Description={en="The quest state doesn't change. Use reward functions of other quests to change the state of this quest.",de="Der Questzustand wird nicht verändert. Ein Reward einer anderen Quest sollte den Zustand dieser Quest verändern."}}
function b_Goal_NoChange:GetGoalTable()return{Objective.NoChange}end;Core:RegisterBehavior(b_Goal_NoChange)function Goal_MapScriptFunction(...)return
b_Goal_MapScriptFunction:new(...)end
b_Goal_MapScriptFunction={Name="Goal_MapScriptFunction",Description={en="Goal: Calls a function within the global map script. Return 'true' means success, 'false' means failure and 'nil' doesn't change anything.",de="Ziel: Ruft eine Funktion im globalen Skript auf, die einen Wahrheitswert zurueckgibt. Rueckgabe 'true' gilt als erfuellt, 'false' als gescheitert und 'nil' ändert nichts."},Parameter={{ParameterType.Default,en="Function name",de="Funktionsname"}}}
function b_Goal_MapScriptFunction:GetGoalTable(rLd)return
{Objective.Custom2,{self,self.CustomFunction}}end;function b_Goal_MapScriptFunction:AddParameter(z8oF,DB6A7N)
if(z8oF==0)then self.FuncName=DB6A7N end end;function b_Goal_MapScriptFunction:CustomFunction(VhYX)return
_G[self.FuncName](self,VhYX)end
function b_Goal_MapScriptFunction:DEBUG(Ha7ErH)
if
not self.FuncName or not _G[self.FuncName]then
dbg(""..

Ha7ErH.Identifier.." "..
self.Name..": function '"..self.FuncName.."' does not exist!")return true end;return false end;Core:RegisterBehavior(b_Goal_MapScriptFunction)function Goal_CustomVariables(...)return
b_Goal_CustomVariables:new(...)end
b_Goal_CustomVariables={Name="Goal_CustomVariables",Description={en="Goal: A customised variable has to assume a certain value.",de="Ziel: Eine benutzerdefinierte Variable muss einen bestimmten Wert annehmen."},Parameter={{ParameterType.Default,en="Name of Variable",de="Variablenname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Default,en="Value or variable",de="Wert oder Variable"}}}
function b_Goal_CustomVariables:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_CustomVariables:AddParameter(rjU95v,sxBl)
if rjU95v==0 then self.VariableName=sxBl elseif rjU95v==1 then
self.Relation=sxBl elseif rjU95v==2 then local m=tonumber(sxBl)
m=(m~=nil and m)or tostring(sxBl)self.Value=m end end
function b_Goal_CustomVariables:CustomFunction()
if
_G["QSB_CustomVariables_"..self.VariableName]then
local nD4LhX6z=
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value]
if self.Relation=="=="then
if
_G["QSB_CustomVariables_"..self.VariableName]==nD4LhX6z then return true end elseif self.Relation=="~="then
if
_G["QSB_CustomVariables_"..self.VariableName]==nD4LhX6z then return true end elseif self.Relation=="<"then
if
_G["QSB_CustomVariables_"..self.VariableName]<nD4LhX6z then return true end elseif self.Relation=="<="then
if
_G["QSB_CustomVariables_"..self.VariableName]<=nD4LhX6z then return true end elseif self.Relation==">="then
if
_G["QSB_CustomVariables_"..self.VariableName]>=nD4LhX6z then return true end else if
_G["QSB_CustomVariables_"..self.VariableName]>nD4LhX6z then return true end end end;return nil end
function b_Goal_CustomVariables:GetCustomData(iN)return{"==","~=","<=","<",">",">="}end
function b_Goal_CustomVariables:DEBUG(Lq)local s9tW={"==","~=","<=","<",">",">="}
local R61K={true,false,nil}
if
not _G["QSB_CustomVariables_"..self.VariableName]then
dbg(Lq.Identifier.." "..self.Name..
": variable '"..self.VariableName.."' do not exist!")return true elseif not Inside(self.Relation,s9tW)then
dbg(Lq.Identifier.." "..
self.Name..": '"..
self.Relation.."' is an invalid relation!")return true end;return false end;Core:RegisterBehavior(b_Goal_CustomVariables)function Goal_InputDialog(...)return
b_Goal_InputDialog:new(...)end
b_Goal_InputDialog={Name="Goal_InputDialog",Description={en="Goal: Player must type in something. The passwords have to be seperated by ; and whitespaces will be ignored.",de="Ziel: Oeffnet einen Dialog, der Spieler muss Lösungswörter eingeben. Diese sind durch ; abzutrennen. Leerzeichen werden ignoriert."},Parameter={{ParameterType.Default,en="ReturnVariable",de="Name der Variable"},{ParameterType.Default,en="Message",de="Nachricht"},{ParameterType.Default,en="Passwords",de="Lösungswörter"},{ParameterType.Number,en="Trials Till Correct Password (0 = Forever)",de="Versuche (0 = unbegrenzt)"}}}
function b_Goal_InputDialog:GetGoalTable(Jf4os)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_InputDialog:AddParameter(a4xc,e)
if(a4xc==0)then self.Variable=e elseif(a4xc==1)then
self.Message=e elseif(a4xc==2)then local la5=e;self.Password={}la5=la5;la5=string.lower(la5)
la5=string.gsub(la5," ","")
while(string.len(la5)>0)do local i,R=string.find(la5,";")
if R then table.insert(self.Password,string.sub(la5,1,
R-1))la5=string.sub(la5,R+
1,string.len(la5))else
table.insert(self.Password,la5)la5=""end end elseif(a4xc==3)then
self.TryTillCorrect=(e==nil and-1)or(e*1)end end
function b_Goal_InputDialog:CustomFunction(xWVu)local function Yw8Yxix(i)
if not self.shown then
self:InitReturnVariable(i)self:ShowBox()self.shown=true end end
if not IsBriefingActive or
(
IsBriefingActive and IsBriefingActive()==false)then
if(not self.TryTillCorrect)or
(self.TryTillCorrect)==-1 then
Yw8Yxix(self.Variable,self.Message)elseif not self.shown then
self.TryCounter=self.TryCounter or self.TryTillCorrect;Yw8Yxix(self.Variable,"")
self.TryCounter=self.TryCounter-1 end
if _G[self.Variable]then
Logic.ExecuteInLuaLocalState([[
                GUI_Chat.Confirm = GUI_Chat.Confirm_Orig_Goal_InputDialog
                GUI_Chat.Confirm_Orig_Goal_InputDialog = nil
                GUI_Chat.Abort = GUI_Chat.Abort_Orig_Goal_InputDialog
                GUI_Chat.Abort_Orig_Goal_InputDialog = nil
            ]])
if self.Password then self.shown=nil
_G[self.Variable]=_G[self.Variable]
_G[self.Variable]=string.lower(_G[self.Variable])
_G[self.Variable]=string.gsub(_G[self.Variable]," ","")
if Inside(_G[self.Variable],self.Password)then return true elseif self.TryTillCorrect and
(
self.TryTillCorrect==-1 or self.TryCounter>0)then
Logic.DEBUG_AddNote(self.Message)_G[self.Variable]=nil;return else
Logic.DEBUG_AddNote(self.Message)_G[self.Variable]=nil;return false end end;return true end end end
function b_Goal_InputDialog:ShowBox()
Logic.ExecuteInLuaLocalState([[
        Input.ChatMode()
        XGUIEng.ShowWidget("/InGame/Root/Normal/ChatInput",1)
        XGUIEng.SetText("/InGame/Root/Normal/ChatInput/ChatInput", "")
        XGUIEng.SetFocus("/InGame/Root/Normal/ChatInput/ChatInput")
    ]])end
function b_Goal_InputDialog:InitReturnVariable(VoXG)
Logic.ExecuteInLuaLocalState(
[[
        GUI_Chat.Abort_Orig_Goal_InputDialog = GUI_Chat.Abort
        GUI_Chat.Confirm_Orig_Goal_InputDialog = GUI_Chat.Confirm

        GUI_Chat.Confirm = function()
            local _variable = "]]..
VoXG..
[["
            Input.GameMode()

            XGUIEng.ShowWidget("/InGame/Root/Normal/ChatInput",0)
            local ChatMessage = XGUIEng.GetText("/InGame/Root/Normal/ChatInput/ChatInput")
            g_Chat.JustClosed = 1
            GUI.SendScriptCommand("_G[ \"".._variable.."\" ] = \""..ChatMessage.."\"")
        end

        GUI_Chat.Abort = function() end
    ]])end
function b_Goal_InputDialog:DEBUG(JL0I04c)
if tonumber(self.TryTillCorrect)==nil or
self.TryTillCorrect==0 then
local En6r_K97=string.format("%s %s: TryTillCorrect is nil or 0!",JL0I04c.Identifier,self.Name)dbg(En6r_K97)return true elseif type(self.Message)~="string"then
local T4AA=string.format("%s %s: Message is not valid!",JL0I04c.Identifier,self.Name)dbg(T4AA)return true elseif type(self.Variable)~="string"then
local VnuCKTdu=string.format("%s %s: Variable is not valid!",JL0I04c.Identifier,self.Name)dbg(VnuCKTdu)return true end
for XnNgn,H1JD in pairs(self.Password)do
if type(H1JD)~="string"then
local gEEa9I=string.format("%s %s: at least 1 password is not valid!",JL0I04c.Identifier,self.Name)dbg(gEEa9I)return true end end;return false end;function b_Goal_InputDialog:GetIcon()return{12,2}end
function b_Goal_InputDialog:Reset()_G[self.Variable]=
nil;self.TryCounter=nil;self.shown=nil end;Core:RegisterBehavior(b_Goal_InputDialog)function Goal_Decide(...)return
b_Goal_Decide:new(...)end
b_Goal_Decide={Name="Goal_Decide",Description={en="Opens a Yes/No Dialog. Decision = Quest Result",de="Oeffnet einen Ja/Nein-Dialog. Die Entscheidung bestimmt das Quest-Ergebnis (ja=true, nein=false)."},Parameter={{ParameterType.Default,en="Text",de="Text"},{ParameterType.Default,en="Title",de="Titel"},{ParameterType.Custom,en="Button labels",de="Button Beschriftung"}}}function b_Goal_Decide:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_Decide:AddParameter(ULLLDUm,e4F3)
if(
ULLLDUm==0)then self.Text=e4F3 elseif(ULLLDUm==1)then self.Title=e4F3 elseif(ULLLDUm==2)then self.Buttons=(
e4F3 =="Ok/Cancel")end end
function b_Goal_Decide:CustomFunction(GsfNt7)
if
not IsBriefingActive or(IsBriefingActive and
IsBriefingActive()==false)then
if not self.LocalExecuted then if QSB.DialogActive then return end;QSB.DialogActive=true;local YWPfQKb2=(
self.Buttons and"true")or"nil"
self.LocalExecuted=true
local r=[[
                Game.GameTimeSetFactor( GUI.GetPlayerID(), 0 )
                OpenRequesterDialog(%q,
                                    %q,
                                    "Game.GameTimeSetFactor( GUI.GetPlayerID(), 1 ); GUI.SendScriptCommand( 'QSB.DecisionWindowResult = true ')",
                                    %s ,
                                    "Game.GameTimeSetFactor( GUI.GetPlayerID(), 1 ); GUI.SendScriptCommand( 'QSB.DecisionWindowResult = false ')")
            ]]
local r=string.format(r,self.Text,"{center} "..self.Title,YWPfQKb2)Logic.ExecuteInLuaLocalState(r)end;local fF0=QSB.DecisionWindowResult;if fF0 ~=nil then QSB.DecisionWindowResult=nil
QSB.DialogActive=false;return fF0 end end end;function b_Goal_Decide:Reset()self.LocalExecuted=nil end;function b_Goal_Decide:GetIcon()return
{4,12}end
function b_Goal_Decide:GetCustomData(OS0Zp3i)if OS0Zp3i==2 then return
{"Yes/No","Ok/Cancel"}end end;Core:RegisterBehavior(b_Goal_Decide)function Goal_TributeDiplomacy(...)return
b_Goal_TributeDiplomacy:new(...)end
b_Goal_TributeDiplomacy={Name="Goal_TributeDiplomacy",Description={en="Goal: AI requests periodical tribute for better Diplomacy",de="Ziel: Die KI fordert einen regelmässigen Tribut fuer bessere Diplomatie. Der Questgeber ist der fordernde Spieler."},Parameter={{ParameterType.Number,en="Amount",de="Menge"},{ParameterType.Custom,en="Length of Period in month",de="Monate bis zur nächsten Forderung"},{ParameterType.Number,en="Time to pay Tribut in seconds",de="Zeit bis zur Zahlung in Sekunden"},{ParameterType.Default,en="Start Message for TributQuest",de="Startnachricht der Tributquest"},{ParameterType.Default,en="Success Message for TributQuest",de="Erfolgsnachricht der Tributquest"},{ParameterType.Default,en="Failure Message for TributQuest",de="Niederlagenachricht der Tributquest"},{ParameterType.Custom,en="Restart if failed to pay",de="Nicht-bezahlen beendet die Quest"}}}
function b_Goal_TributeDiplomacy:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_TributeDiplomacy:AddParameter(BK,Idjbe70)
if(BK==0)then self.Amount=Idjbe70*1 elseif(BK==1)then self.PeriodLength=
Idjbe70*150 elseif(BK==2)then self.TributTime=Idjbe70*1 elseif(BK==3)then
self.StartMsg=Idjbe70 elseif(BK==4)then self.SuccessMsg=Idjbe70 elseif(BK==5)then self.FailureMsg=Idjbe70 elseif(BK==6)then
self.RestartAtFailure=AcceptAlternativeBoolean(Idjbe70)end end
function b_Goal_TributeDiplomacy:CustomFunction(B)
if not self.Time then if self.PeriodLength-150 <
self.TributTime then
Logic.DEBUG_AddNote("b_Goal_TributeDiplomacy: TributTime too long")end end
if not self.QuestStarted then
self.QuestStarted=QuestTemplate:New(B.Identifier.."TributeBanditQuest",B.SendingPlayer,B.ReceivingPlayer,{{Objective.Deliver,{Goods.G_Gold,self.Amount}}},{{Triggers.Time,0}},self.TributTime,
nil,nil,nil,nil,true,true,nil,self.StartMsg,self.SuccessMsg,self.FailureMsg)self.Time=Logic.GetTime()end;local nDjt=Quests[self.QuestStarted]
if
self.QuestStarted and
nDjt.State==QuestState.Over and not self.RestartQuest then
if nDjt.Result~=QuestResult.Success then
SetDiplomacyState(B.ReceivingPlayer,B.SendingPlayer,DiplomacyStates.Enemy)if not self.RestartAtFailure then return false end else
SetDiplomacyState(B.ReceivingPlayer,B.SendingPlayer,DiplomacyStates.TradeContact)end;self.RestartQuest=true end;local NVWt=Logic.GetStoreHouse(B.SendingPlayer)
if(NVWt==0 or
Logic.IsEntityDestroyed(NVWt))then if self.QuestStarted and
Quests[self.QuestStarted].State==QuestState.Active then
Quests[self.QuestStarted]:Interrupt()end;return true end
if
self.QuestStarted and self.RestartQuest and(
(Logic.GetTime()-self.Time)>=self.PeriodLength)then nDjt.Objectives[1].Completed=nil;nDjt.Objectives[1].Data[3]=
nil
nDjt.Objectives[1].Data[4]=nil;nDjt.Objectives[1].Data[5]=nil
nDjt.Result=nil;nDjt.State=QuestState.NotTriggered
Logic.ExecuteInLuaLocalState(
"LocalScriptCallback_OnQuestStatusChanged("..nDjt.Index..")")
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_SECOND,"",QuestTemplate.Loop,1,0,{nDjt.QueueID})self.Time=Logic.GetTime()self.RestartQuest=nil end end
function b_Goal_TributeDiplomacy:DEBUG(efuUGMh)if self.Amount<0 then
dbg(efuUGMh.Identifier.." "..
self.Name..": Amount is negative")return true end end;function b_Goal_TributeDiplomacy:Reset()self.Time=nil;self.QuestStarted=nil
self.RestartQuest=nil end
function b_Goal_TributeDiplomacy:Interrupt(p4nNp)
if
self.QuestStarted and Quests[self.QuestStarted]~=nil then if
Quests[self.QuestStarted].State==QuestState.Active then
Quests[self.QuestStarted]:Interrupt()end end end
function b_Goal_TributeDiplomacy:GetCustomData(VW)
if(VW==1)then return
{"1","2","3","4","5","6","7","8","9","10","11","12"}elseif(VW==6)then return{"true","false"}end end;Core:RegisterBehavior(b_Goal_TributeDiplomacy)function Goal_TributeClaim(...)return
b_Goal_TributeClaim:new(...)end
b_Goal_TributeClaim={Name="Goal_TributeClaim",Description={en="Goal: AI requests periodical tribute for a specified Territory",de="Ziel: Die KI fordert einen regelmässigen Tribut fuer ein Territorium. Der Questgeber ist der fordernde Spieler."},Parameter={{ParameterType.TerritoryName,en="Territory",de="Territorium"},{ParameterType.PlayerID,en="PlayerID",de="PlayerID"},{ParameterType.Number,en="Amount",de="Menge"},{ParameterType.Custom,en="Length of Period in month",de="Monate bis zur nächsten Forderung"},{ParameterType.Number,en="Time to pay Tribut in seconds",de="Zeit bis zur Zahlung in Sekunden"},{ParameterType.Default,en="Start Message for TributQuest",de="Startnachricht der Tributquest"},{ParameterType.Default,en="Success Message for TributQuest",de="Erfolgsnachricht der Tributquest"},{ParameterType.Default,en="Failure Message for TributQuest",de="Niederlagenachricht der Tributquest"},{ParameterType.Number,en="How often to pay (0 = forerver)",de="Anzahl der Tributquests (0 = unendlich)"},{ParameterType.Custom,en="Other Owner cancels the Quest",de="Anderer Spieler kann Quest beenden"},{ParameterType.Custom,en="About if a rate is not payed",de="Nicht-bezahlen beendet die Quest"}}}
function b_Goal_TributeClaim:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_TributeClaim:AddParameter(Zt,V)
if(Zt==0)then
self.TerritoryID=GetTerritoryIDByName(V)elseif(Zt==1)then self.PlayerID=V*1 elseif(Zt==2)then self.Amount=V*1 elseif(Zt==3)then
self.PeriodLength=V*150 elseif(Zt==4)then self.TributTime=V*1 elseif(Zt==5)then self.StartMsg=V elseif(Zt==6)then
self.SuccessMsg=V elseif(Zt==7)then self.FailureMsg=V elseif(Zt==8)then self.HowOften=V*1 elseif(Zt==9)then
self.OtherOwnerCancels=AcceptAlternativeBoolean(V)elseif(Zt==10)then self.DontPayCancels=AcceptAlternativeBoolean(V)end end
function b_Goal_TributeClaim:CustomFunction(mzeTI)
local s=Logic.GetTerritoryAcquiringBuildingID(self.TerritoryID)if IsExisting(s)and GetHealth(s)<25 then
while
(Logic.GetEntityHealth(s)>
Logic.GetEntityMaxHealth(s)*0.6)do Logic.HurtEntity(s,1)end end
if

Logic.GetTerritoryPlayerID(self.TerritoryID)==mzeTI.ReceivingPlayer or
Logic.GetTerritoryPlayerID(self.TerritoryID)==self.PlayerID then
if self.OtherOwner then self:RestartTributeQuest()self.OtherOwner=nil end;if
not self.Time and self.PeriodLength-20 <self.TributTime then
Logic.DEBUG_AddNote("b_Goal_TributeClaim: TributTime too long")end
if
not self.Quest then
local ztJhP_u8=QuestTemplate:New(mzeTI.Identifier.."TributeClaimQuest",self.PlayerID,mzeTI.ReceivingPlayer,{{Objective.Deliver,{Goods.G_Gold,self.Amount}}},{{Triggers.Time,0}},self.TributTime,
nil,nil,nil,nil,true,true,nil,self.StartMsg,self.SuccessMsg,self.FailureMsg)self.Quest=Quests[ztJhP_u8]self.Time=Logic.GetTime()else
if
self.Quest.State==QuestState.Over then
if
self.Quest.Result==QuestResult.Failure then if IsExisting(s)then
Logic.ChangeEntityPlayerID(s,self.PlayerID)end
Logic.SetTerritoryPlayerID(self.TerritoryID,self.PlayerID)self.Time=Logic.GetTime()self.Quest.State=false;if
self.DontPayCancels then mzeTI:Interrupt()end else
if self.Quest.Result==
QuestResult.Success then
if Logic.GetTerritoryPlayerID(self.TerritoryID)==
self.PlayerID then if IsExisting(s)then
Logic.ChangeEntityPlayerID(s,mzeTI.ReceivingPlayer)end
Logic.SetTerritoryPlayerID(self.TerritoryID,mzeTI.ReceivingPlayer)end end
if Logic.GetTime()>=self.Time+self.PeriodLength then
if
self.HowOften and self.HowOften~=0 then
self.TributeCounter=self.TributeCounter or 0;self.TributeCounter=self.TributeCounter+1;if
self.TributeCounter>=self.HowOften then return false end end;self:RestartTributeQuest()end end elseif self.Quest.State==false then
if Logic.GetTime()>=
self.Time+self.PeriodLength then self:RestartTributeQuest()end end end elseif Logic.GetTerritoryPlayerID(self.TerritoryID)==0 and
self.Quest then if
self.Quest.State==QuestState.Active then self.Quest:Interrupt()end elseif
Logic.GetTerritoryPlayerID(self.TerritoryID)~=self.PlayerID then if
self.Quest.State==QuestState.Active then self.Quest:Interrupt()end;if
self.OtherOwnerCancels then mzeTI:Interrupt()end;self.OtherOwner=true end;local y4J=Logic.GetStoreHouse(self.PlayerID)
if(y4J==0 or
Logic.IsEntityDestroyed(y4J))then
if self.Quest and
self.Quest.State==QuestState.Active then self.Quest:Interrupt()end;return true end end
function b_Goal_TributeClaim:DEBUG(D)
if self.TerritoryID==0 then
dbg(D.Identifier..": "..
self.Name..": Unknown Territory")return true elseif not self.Quest and
Logic.GetStoreHouse(self.PlayerID)==0 then
dbg(D.Identifier..
": "..self.Name..": Player "..
self.PlayerID.." is dead. :-(")return true elseif self.Amount<0 then
dbg(D.Identifier..
": "..self.Name..": Amount is negative")return true elseif self.PeriodLength<1 or self.PeriodLength>600 then
dbg(
D.Identifier..": "..self.Name..": Period Length is wrong")return true elseif self.HowOften<0 then
dbg(D.Identifier..
": "..self.Name..": HowOften is negative")return true end end
function b_Goal_TributeClaim:Reset()self.Quest=nil;self.Time=nil;self.OtherOwner=nil end
function b_Goal_TributeClaim:Interrupt(XIcl)if type(self.Quest)=="table"then
if self.Quest.State==
QuestState.Active then self.Quest:Interrupt()end end end
function b_Goal_TributeClaim:RestartTributeQuest()self.Time=Logic.GetTime()self.Quest.Objectives[1].Completed=
nil;self.Quest.Objectives[1].Data[3]=
nil;self.Quest.Objectives[1].Data[4]=
nil;self.Quest.Objectives[1].Data[5]=
nil;self.Quest.Result=nil
self.Quest.State=QuestState.NotTriggered
Logic.ExecuteInLuaLocalState("LocalScriptCallback_OnQuestStatusChanged("..self.Quest.Index..")")
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_SECOND,"",QuestTemplate.Loop,1,0,{self.Quest.QueueID})end
function b_Goal_TributeClaim:GetCustomData(ys)if(ys==3)then return
{"1","2","3","4","5","6","7","8","9","10","11","12"}elseif(ys==9)or(ys==10)then
return{"false","true"}end end;Core:RegisterBehavior(b_Goal_TributeClaim)function Reprisal_ObjectDeactivate(...)return
b_Reprisal_ObjectDeactivate:new(...)end
b_Reprisal_ObjectDeactivate={Name="Reprisal_ObjectDeactivate",Description={en="Reprisal: Deactivates an interactive object",de="Vergeltung: Deaktiviert ein interaktives Objekt"},Parameter={{ParameterType.ScriptName,en="Interactive object",de="Interaktives Objekt"}}}
function b_Reprisal_ObjectDeactivate:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_ObjectDeactivate:AddParameter(rMQ1um8,U2)
if(rMQ1um8 ==0)then self.ScriptName=U2 end end;function b_Reprisal_ObjectDeactivate:CustomFunction(X)
InteractiveObjectDeactivate(self.ScriptName)end
function b_Reprisal_ObjectDeactivate:DEBUG(zLtWO09)
if

not Logic.IsInteractiveObject(GetID(self.ScriptName))then
warn(""..zLtWO09.Identifier..
" "..self.Name..": '"..
self.ScriptName.."' is not a interactive object!")self.WarningPrinted=true end;local Z=GetID(self.ScriptName)
if QSB.InitalizedObjekts[Z]and
QSB.InitalizedObjekts[Z]==zLtWO09.Identifier then
dbg(""..

zLtWO09.Identifier.." "..
self.Name..": you can not deactivate in the same quest the object is initalized!")return true end;return false end
Core:RegisterBehavior(b_Reprisal_ObjectDeactivate)function Reprisal_ObjectActivate(...)
return b_Reprisal_ObjectActivate:new(...)end
b_Reprisal_ObjectActivate={Name="Reprisal_ObjectActivate",Description={en="Reprisal: Activates an interactive object",de="Vergeltung: Aktiviert ein interaktives Objekt"},Parameter={{ParameterType.ScriptName,en="Interactive object",de="Interaktives Objekt"},{ParameterType.Custom,en="Availability",de="Nutzbarkeit"}}}
function b_Reprisal_ObjectActivate:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_ObjectActivate:AddParameter(ZDICnKE,L)
if(ZDICnKE==0)then self.ScriptName=L elseif
(ZDICnKE==1)then local B58=0;if L=="Always"or 1 then B58=1 end;self.UsingState=B58 end end;function b_Reprisal_ObjectActivate:CustomFunction(PYVzrNl)
InteractiveObjectActivate(self.ScriptName,self.UsingState)end
function b_Reprisal_ObjectActivate:GetCustomData(KTVmRC)if
KTVmRC==1 then return{"Knight only","Always"}end end
function b_Reprisal_ObjectActivate:DEBUG(Pa)
if not
Logic.IsInteractiveObject(GetID(self.ScriptName))then
warn(""..Pa.Identifier..
" "..self.Name..": '"..
self.ScriptName.."' is not a interactive object!")self.WarningPrinted=true end;local bmK=GetID(self.ScriptName)
if QSB.InitalizedObjekts[bmK]and
QSB.InitalizedObjekts[bmK]==Pa.Identifier then
dbg(""..
Pa.Identifier..
" "..
self.Name..": you can not activate in the same quest the object is initalized!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_ObjectActivate)function Reprisal_DiplomacyDecrease()return
b_Reprisal_DiplomacyDecrease:new()end
b_Reprisal_DiplomacyDecrease={Name="Reprisal_DiplomacyDecrease",Description={en="Reprisal: Diplomacy decreases slightly to another player",de="Vergeltung: Der Diplomatiestatus zum Auftraggeber wird um eine Stufe verringert."}}
function b_Reprisal_DiplomacyDecrease:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_DiplomacyDecrease:CustomFunction(O)local JPc3R=O.SendingPlayer
local j=O.ReceivingPlayer;local vMgKnGj=GetDiplomacyState(j,JPc3R)if vMgKnGj>-2 then
SetDiplomacyState(j,JPc3R,vMgKnGj-1)end end;function b_Reprisal_DiplomacyDecrease:AddParameter(M9K,Zeu)
if(M9K==0)then self.PlayerID=Zeu*1 end end
Core:RegisterBehavior(b_Reprisal_DiplomacyDecrease)
function Reprisal_Diplomacy(...)return b_Reprisal_Diplomacy:new(...)end
b_Reprisal_Diplomacy={Name="Reprisal_Diplomacy",Description={en="Reprisal: Sets Diplomacy state of two Players to a stated value.",de="Vergeltung: Setzt den Diplomatiestatus zweier Spieler auf den angegebenen Wert."},Parameter={{ParameterType.PlayerID,en="PlayerID 1",de="Spieler 1"},{ParameterType.PlayerID,en="PlayerID 2",de="Spieler 2"},{ParameterType.DiplomacyState,en="Relation",de="Beziehung"}}}
function b_Reprisal_Diplomacy:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_Diplomacy:AddParameter(Q2_d,W0iTcMIt)
if(Q2_d==0)then self.PlayerID1=W0iTcMIt*1 elseif
(Q2_d==1)then self.PlayerID2=W0iTcMIt*1 elseif(Q2_d==2)then
self.Relation=DiplomacyStates[W0iTcMIt]end end;function b_Reprisal_Diplomacy:CustomFunction(N)
SetDiplomacyState(self.PlayerID1,self.PlayerID2,self.Relation)end
function b_Reprisal_Diplomacy:DEBUG(Hald6SO)
if

not tonumber(self.PlayerID1)or self.PlayerID1 <1 or self.PlayerID1 >8 then
dbg(Hald6SO.Identifier.." "..
self.Name..": PlayerID 1 is invalid!")return true elseif
not tonumber(self.PlayerID2)or self.PlayerID2 <1 or self.PlayerID2 >8 then
dbg(Hald6SO.Identifier.." "..self.Name..
": PlayerID 2 is invalid!")return true elseif
not tonumber(self.Relation)or self.Relation<-2 or self.Relation>2 then
dbg(Hald6SO.Identifier.." "..
self.Name..": '"..
self.Relation.."' is a invalid diplomacy state!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_Diplomacy)function Reprisal_DestroyEntity(...)return
b_Reprisal_DestroyEntity:new(...)end
b_Reprisal_DestroyEntity={Name="Reprisal_DestroyEntity",Description={en="Reprisal: Replaces an entity with an invisible script entity, which retains the entities name.",de="Vergeltung: Ersetzt eine Entity mit einer unsichtbaren Script-Entity, die den Namen übernimmt."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"}}}
function b_Reprisal_DestroyEntity:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_DestroyEntity:AddParameter(Dq,y3Ur)
if(Dq==0)then self.ScriptName=y3Ur end end;function b_Reprisal_DestroyEntity:CustomFunction(GL70F7uL)
ReplaceEntity(self.ScriptName,Entities.XD_ScriptEntity)end
function b_Reprisal_DestroyEntity:DEBUG(lqANrrJA)
if
not IsExisting(self.ScriptName)then
warn(lqANrrJA.Identifier.." "..
self.Name..": '"..
self.ScriptName.."' is already destroyed!")self.WarningPrinted=true end;return false end;Core:RegisterBehavior(b_Reprisal_DestroyEntity)function Reprisal_DestroyEffect(...)return
b_Reprisal_DestroyEffect:new(...)end
b_Reprisal_DestroyEffect={Name="Reprisal_DestroyEffect",Description={en="Reprisal: Destroys an effect",de="Vergeltung: Zerstört einen Effekt"},Parameter={{ParameterType.Default,en="Effect name",de="Effektname"}}}function b_Reprisal_DestroyEffect:AddParameter(WUFTXBy6,aEZf)
if WUFTXBy6 ==0 then self.EffectName=aEZf end end
function b_Reprisal_DestroyEffect:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_DestroyEffect:CustomFunction(QjQ_o)if

not QSB.EffectNameToID[self.EffectName]or not
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])then return end
Logic.DestroyEffect(QSB.EffectNameToID[self.EffectName])end
function b_Reprisal_DestroyEffect:DEBUG(w)if
not QSB.EffectNameToID[self.EffectName]then
dbg(w.Identifier.." "..self.Name..
": Effect "..self.EffectName.." never created")end;return false end;Core:RegisterBehavior(b_Reprisal_DestroyEffect)function Reprisal_Defeat()return
b_Reprisal_Defeat:new()end
b_Reprisal_Defeat={Name="Reprisal_Defeat",Description={en="Reprisal: The player loses the game.",de="Vergeltung: Der Spieler verliert das Spiel."}}
function b_Reprisal_Defeat:GetReprisalTable(Diq_)return{Reprisal.Defeat}end;Core:RegisterBehavior(b_Reprisal_Defeat)function Reprisal_FakeDefeat()return
b_Reprisal_FakeDefeat:new()end
b_Reprisal_FakeDefeat={Name="Reprisal_FakeDefeat",Description={en="Reprisal: Displays a defeat icon for a quest",de="Vergeltung: Zeigt ein Niederlage Icon fuer eine Quest an"}}
function b_Reprisal_FakeDefeat:GetReprisalTable()return{Reprisal.FakeDefeat}end;Core:RegisterBehavior(b_Reprisal_FakeDefeat)function Reprisal_ReplaceEntity(...)return
b_Reprisal_ReplaceEntity:new(...)end
b_Reprisal_ReplaceEntity={Name="Reprisal_ReplaceEntity",Description={en="Reprisal: Replaces an entity with a new one of a different type. The playerID can be changed too.",de="Vergeltung: Ersetzt eine Entity durch eine neue anderen Typs. Es kann auch die Spielerzugehörigkeit geändert werden."},Parameter={{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Custom,en="New Type",de="Neuer Typ"},{ParameterType.Custom,en="New playerID",de="Neue Spieler ID"}}}
function b_Reprisal_ReplaceEntity:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_ReplaceEntity:AddParameter(QYA5WJOY,yliV8)
if(QYA5WJOY==0)then self.ScriptName=yliV8 elseif
(QYA5WJOY==1)then self.NewType=yliV8 elseif(QYA5WJOY==2)then self.PlayerID=tonumber(yliV8)end end
function b_Reprisal_ReplaceEntity:CustomFunction(rjpKFl)local YUGQovw=GetID(self.ScriptName)
local XZt7GyF=self.PlayerID
if XZt7GyF==Logic.EntityGetPlayer(YUGQovw)then XZt7GyF=nil end
ReplaceEntity(self.ScriptName,Entities[self.NewType],XZt7GyF)end
function b_Reprisal_ReplaceEntity:GetCustomData(Zn3SC)local D4={}
if Zn3SC==1 then
for crA9EKx,IcsJ in pairs(Entities)do
local A={"^M_","^XS_","^X_","^XT_","^Z_","^XB_"}local Wp9xT=false
for P=1,#A do if crA9EKx:find(A[P])then Wp9xT=true;break end end;if not Wp9xT then table.insert(D4,crA9EKx)end end;table.sort(D4)elseif Zn3SC==2 then
D4={"-","0","1","2","3","4","5","6","7","8"}end;return D4 end
function b_Reprisal_ReplaceEntity:DEBUG(o0_XG8FI)
if not Entities[self.NewType]then
dbg(
o0_XG8FI.Identifier.." "..self.Name..": got an invalid entity type!")return true elseif self.PlayerID~=nil and
(self.PlayerID<1 or self.PlayerID>8)then
dbg(o0_XG8FI.Identifier.." "..
self.Name..": got an invalid playerID!")return true end
if not IsExisting(self.ScriptName)then self.WarningPrinted=true
warn(
o0_XG8FI.Identifier.." "..
self.Name..": '"..self.ScriptName.."' does not exist!")end;return false end;Core:RegisterBehavior(b_Reprisal_ReplaceEntity)function Reprisal_QuestRestart(...)return
b_Reprisal_QuestRestart(...)end
b_Reprisal_QuestRestart={Name="Reprisal_QuestRestart",Description={en="Reprisal: Restarts a (completed) quest so it can be triggered and completed again",de="Vergeltung: Startet eine (beendete) Quest neu, damit diese neu ausgelöst und beendet werden kann"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reprisal_QuestRestart:GetReprisalTable(jLsxpw)return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_QuestRestart:AddParameter(x,AXNfV)
if(x==0)then self.QuestName=AXNfV end end;function b_Reprisal_QuestRestart:CustomFunction(cX)
self:ResetQuest()end
function b_Reprisal_QuestRestart:DEBUG(iyx)
if not
Quests[GetQuestID(self.QuestName)]then
dbg(iyx.Identifier..
" "..self.Name..": quest "..
self.QuestName.." does not exist!")return true end end;function b_Reprisal_QuestRestart:ResetQuest()
RestartQuestByName(self.QuestName)end
Core:RegisterBehavior(b_Reprisal_QuestRestart)
function Reprisal_QuestFailure(...)return b_Reprisal_QuestFailure(...)end
b_Reprisal_QuestFailure={Name="Reprisal_QuestFailure",Description={en="Reprisal: Lets another active quest fail",de="Vergeltung: Lässt eine andere aktive Quest fehlschlagen"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reprisal_QuestFailure:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_QuestFailure:AddParameter(bxvn,mWYrzB)
if(bxvn==0)then self.QuestName=mWYrzB end end;function b_Reprisal_QuestFailure:CustomFunction(O7kX)
FailQuestByName(self.QuestName)end
function b_Reprisal_QuestFailure:DEBUG(Q4XSpdY)if not
Quests[GetQuestID(self.QuestName)]then
dbg(""..Q4XSpdY.Identifier..
" "..self.Name..": got an invalid quest!")return true end;return
false end;Core:RegisterBehavior(b_Reprisal_QuestFailure)function Reprisal_QuestSuccess(...)return
b_Reprisal_QuestSuccess(...)end
b_Reprisal_QuestSuccess={Name="Reprisal_QuestSuccess",Description={en="Reprisal: Completes another active quest successfully",de="Vergeltung: Beendet eine andere aktive Quest erfolgreich"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reprisal_QuestSuccess:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_QuestSuccess:AddParameter(fzTyrQ9F,fAumJ0i)
if(fzTyrQ9F==0)then self.QuestName=fAumJ0i end end;function b_Reprisal_QuestSuccess:CustomFunction(i0)
WinQuestByName(self.QuestName)end
function b_Reprisal_QuestSuccess:DEBUG(tZliF4)
if not
Quests[GetQuestID(self.QuestName)]then
dbg(tZliF4.Identifier..
" "..self.Name..": quest "..
self.QuestName.." does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_QuestSuccess)function Reprisal_QuestActivate(...)return
b_Reprisal_QuestActivate(...)end
b_Reprisal_QuestActivate={Name="Reprisal_QuestActivate",Description={en="Reprisal: Activates another quest that is not triggered yet.",de="Vergeltung: Aktiviert eine andere Quest die noch nicht ausgelöst wurde."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reprisal_QuestActivate:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_QuestActivate:AddParameter(jlmopoj,R)if(jlmopoj==0)then self.QuestName=R else
assert(false,"Error in "..
self.Name..": AddParameter: Index is invalid")end end;function b_Reprisal_QuestActivate:CustomFunction(u)
StartQuestByName(self.QuestName)end
function b_Reprisal_QuestActivate:DEBUG(S_N6)
if not
IsValidQuest(self.QuestName)then
dbg(S_N6.Identifier.." "..self.Name..
": Quest: "..self.QuestName.." does not exist")return true end end;Core:RegisterBehavior(b_Reprisal_QuestActivate)function Reprisal_QuestInterrupt(...)return
b_Reprisal_QuestInterrupt(...)end
b_Reprisal_QuestInterrupt={Name="Reprisal_QuestInterrupt",Description={en="Reprisal: Interrupts another active quest without success or failure",de="Vergeltung: Beendet eine andere aktive Quest ohne Erfolg oder Misserfolg"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reprisal_QuestInterrupt:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_QuestInterrupt:AddParameter(o5SLRA,ztwXaCR)
if(o5SLRA==0)then self.QuestName=ztwXaCR end end
function b_Reprisal_QuestInterrupt:CustomFunction(M2WtMgiq)
if(
GetQuestID(self.QuestName)~=nil)then
local FgfME=GetQuestID(self.QuestName)local y=Quests[FgfME]if y.State==QuestState.Active then
StopQuestByName(self.QuestName)end end end
function b_Reprisal_QuestInterrupt:DEBUG(lH9o)
if
not Quests[GetQuestID(self.QuestName)]then
dbg(lH9o.Identifier.." "..self.Name..
": quest "..self.QuestName.." does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_QuestInterrupt)function Reprisal_QuestForceInterrupt(...)return
b_Reprisal_QuestForceInterrupt(...)end
b_Reprisal_QuestForceInterrupt={Name="Reprisal_QuestForceInterrupt",Description={en="Reprisal: Interrupts another quest (even when it isn't active yet) without success or failure",de="Vergeltung: Beendet eine andere Quest, auch wenn diese noch nicht aktiv ist ohne Erfolg oder Misserfolg"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Custom,en="Ended quests",de="Beendete Quests"}}}
function b_Reprisal_QuestForceInterrupt:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_QuestForceInterrupt:AddParameter(CC4Kfjh,k)
if(CC4Kfjh==0)then self.QuestName=k elseif
(CC4Kfjh==1)then self.InterruptEnded=AcceptAlternativeBoolean(k)end end
function b_Reprisal_QuestForceInterrupt:GetCustomData(eUQ0x)local r0OR={}
if eUQ0x==1 then
table.insert(r0OR,"false")table.insert(r0OR,"true")else assert(false)end;return r0OR end
function b_Reprisal_QuestForceInterrupt:CustomFunction(pYHkv)
if
(GetQuestID(self.QuestName)~=nil)then local hxZHlgP=GetQuestID(self.QuestName)local zct=Quests[hxZHlgP]if
self.InterruptEnded or zct.State~=QuestState.Over then
zct:Interrupt()end end end
function b_Reprisal_QuestForceInterrupt:DEBUG(WQk6Wkd)
if not
Quests[GetQuestID(self.QuestName)]then
dbg(WQk6Wkd.Identifier..
" "..self.Name..": quest "..
self.QuestName.." does not exist!")return true end;return false end
Core:RegisterBehavior(b_Reprisal_QuestForceInterrupt)function Reprisal_MapScriptFunction(...)
return b_Reprisal_MapScriptFunction:new(...)end
b_Reprisal_MapScriptFunction={Name="Reprisal_MapScriptFunction",Description={en="Reprisal: Calls a function within the global map script if the quest has failed.",de="Vergeltung: Ruft eine Funktion im globalen Kartenskript auf, wenn die Quest fehlschlägt."},Parameter={{ParameterType.Default,en="Function name",de="Funktionsname"}}}
function b_Reprisal_MapScriptFunction:GetReprisalTable(t)return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_MapScriptFunction:AddParameter(pRCHPl,sCffg4HK)
if(pRCHPl==0)then self.FuncName=sCffg4HK end end;function b_Reprisal_MapScriptFunction:CustomFunction(E)return
_G[self.FuncName](self,E)end
function b_Reprisal_MapScriptFunction:DEBUG(yljhkFp)
if
not self.FuncName or not _G[self.FuncName]then
dbg(""..

yljhkFp.Identifier.." "..
self.Name..": function '"..self.FuncName.."' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Reprisal_MapScriptFunction)function Reprisal_CustomVariables(...)
return b_Reprisal_CustomVariables:new(...)end
b_Reprisal_CustomVariables={Name="Reprisal_CustomVariables",Description={en="Reprisal: Executes a mathematical operation with this variable. The other operand can be a number or another custom variable.",de="Vergeltung: Fuehrt eine mathematische Operation mit der Variable aus. Der andere Operand kann eine Zahl oder eine Custom-Varible sein."},Parameter={{ParameterType.Default,en="Name of variable",de="Variablenname"},{ParameterType.Custom,en="Operator",de="Operator"},{ParameterType.Default,en="Value or variable",de="Wert oder Variable"}}}
function b_Reprisal_CustomVariables:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_CustomVariables:AddParameter(uGDn542,DQ)
if uGDn542 ==0 then self.VariableName=DQ elseif uGDn542 ==1 then
self.Operator=DQ elseif uGDn542 ==2 then local s6Ahlni_=tonumber(DQ)s6Ahlni_=
(s6Ahlni_~=nil and s6Ahlni_)or tostring(DQ)
self.Value=s6Ahlni_ end end
function b_Reprisal_CustomVariables:CustomFunction()
_G["QSB_CustomVariables_"..self.VariableName]=_G[
"QSB_CustomVariables_"..self.VariableName]or 0
local T6dNu=_G["QSB_CustomVariables_"..self.VariableName]
if self.Operator=="="then
_G["QSB_CustomVariables_"..self.VariableName]=(
type(self.Value)~="string"and self.Value)or _G[
"QSB_CustomVariables_"..self.Value]elseif self.Operator=="+"then
_G["QSB_CustomVariables_"..self.VariableName]=
T6dNu+
(type(self.Value)~="string"and self.Value)or
_G["QSB_CustomVariables_"..self.Value]elseif self.Operator=="-"then
_G["QSB_CustomVariables_"..self.VariableName]=
T6dNu-
(type(self.Value)~="string"and self.Value)or
_G["QSB_CustomVariables_"..self.Value]elseif self.Operator=="*"then
_G["QSB_CustomVariables_"..self.VariableName]=
T6dNu*
(type(self.Value)~="string"and self.Value)or
_G["QSB_CustomVariables_"..self.Value]elseif self.Operator=="/"then
_G["QSB_CustomVariables_"..self.VariableName]=
T6dNu/
(type(self.Value)~="string"and self.Value)or
_G["QSB_CustomVariables_"..self.Value]elseif self.Operator=="^"then
_G["QSB_CustomVariables_"..self.VariableName]=
T6dNu^
(type(self.Value)~="string"and self.Value)or
_G["QSB_CustomVariables_"..self.Value]end end
function b_Reprisal_CustomVariables:GetCustomData(H)return{"=","+","-","*","/","^"}end
function b_Reprisal_CustomVariables:DEBUG(YlzZm)local v={"=","+","-","*","/","^"}
if not
Inside(self.Operator,v)then
dbg(YlzZm.Identifier..
" "..self.Name..": got an invalid operator!")return true elseif self.VariableName==""then
dbg(YlzZm.Identifier.." "..
self.Name..": missing name for variable!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_CustomVariables)function Reprisal_Technology(...)return
b_Reprisal_Technology:new(...)end
b_Reprisal_Technology={Name="Reprisal_Technology",Description={en="Reprisal: Locks or unlocks a technology for the given player",de="Vergeltung: Sperrt oder erlaubt eine Technolgie fuer den angegebenen Player"},Parameter={{ParameterType.PlayerID,en="PlayerID",de="SpielerID"},{ParameterType.Custom,en="Un / Lock",de="Sperren/Erlauben"},{ParameterType.Custom,en="Technology",de="Technologie"}}}
function b_Reprisal_Technology:GetReprisalTable(j9879b5)return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_Technology:AddParameter(cotcYZ1f,FRcmT)
if(cotcYZ1f==0)then self.PlayerID=FRcmT*1 elseif
(cotcYZ1f==1)then self.LockType=FRcmT=="Lock"elseif(cotcYZ1f==2)then self.Technology=FRcmT end end
function b_Reprisal_Technology:CustomFunction(zfl)
if
self.PlayerID and
Logic.GetStoreHouse(self.PlayerID)~=0 and Technologies[self.Technology]then
if self.LockType then
LockFeaturesForPlayer(self.PlayerID,Technologies[self.Technology])else
UnLockFeaturesForPlayer(self.PlayerID,Technologies[self.Technology])end else return false end end
function b_Reprisal_Technology:GetCustomData(itxD)local JPHs7A={}if(itxD==1)then JPHs7A[1]="Lock"
JPHs7A[2]="UnLock"elseif(itxD==2)then
for yzYgnMtr,o in pairs(Technologies)do table.insert(JPHs7A,yzYgnMtr)end end;return
JPHs7A end
function b_Reprisal_Technology:DEBUG(wmkJ)
if not Technologies[self.Technology]then
dbg(""..

wmkJ.Identifier.." "..self.Name..": got an invalid technology type!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
dbg(""..wmkJ.Identifier.." "..self.Name..
": got an invalid playerID!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_Technology)function Reward_ObjectDeactivate(...)return
b_Reward_ObjectDeactivate:new(...)end
b_Reward_ObjectDeactivate=API.InstanceTable(b_Reprisal_ObjectDeactivate)b_Reward_ObjectDeactivate.Name="Reward_ObjectDeactivate"
b_Reward_ObjectDeactivate.Description.de="Reward: Deactivates an interactive object"
b_Reward_ObjectDeactivate.Description.en="Lohn: Deaktiviert ein interaktives Objekt"b_Reward_ObjectDeactivate.GetReprisalTable=nil
b_Reward_ObjectDeactivate.GetRewardTable=function(I1,gXu5hG)return
{Reward.Custom,{I1,I1.CustomFunction}}end;Core:RegisterBehavior(b_Reward_ObjectDeactivate)function Reward_ObjectActivate(...)return
b_Reward_ObjectActivate:new(...)end
b_Reward_ObjectActivate=API.InstanceTable(b_Reprisal_ObjectActivate)b_Reward_ObjectActivate.Name="Reward_ObjectActivate"
b_Reward_ObjectActivate.Description.de="Reward: Activates an interactive object"
b_Reward_ObjectActivate.Description.en="Lohn: Aktiviert ein interaktives Objekt"b_Reward_ObjectActivate.GetReprisalTable=nil
b_Reward_ObjectActivate.GetRewardTable=function(R60Ru4bj,eQWRf)return
{Reward.Custom,{R60Ru4bj,R60Ru4bj.CustomFunction}}end;Core:RegisterBehavior(b_Reward_ObjectActivate)function Reward_ObjectInit(...)return
b_Reward_ObjectInit:new(...)end
b_Reward_ObjectInit={Name="Reward_ObjectInit",Description={en="Reward: Setup an interactive object with costs and rewards.",de="Lohn: Initialisiert ein interaktives Objekt mit seinen Kosten und Schätzen."},Parameter={{ParameterType.ScriptName,en="Interactive object",de="Interaktives Objekt"},{ParameterType.Number,en="Distance to use",de="Nutzungsentfernung"},{ParameterType.Number,en="Waittime",de="Wartezeit"},{ParameterType.Custom,en="Reward good",de="Belohnungsware"},{ParameterType.Number,en="Reward amount",de="Anzahl"},{ParameterType.Custom,en="Cost good 1",de="Kostenware 1"},{ParameterType.Number,en="Cost amount 1",de="Anzahl 1"},{ParameterType.Custom,en="Cost good 2",de="Kostenware 2"},{ParameterType.Number,en="Cost amount 2",de="Anzahl 2"},{ParameterType.Custom,en="Availability",de="Verfï¿½gbarkeit"}}}function b_Reward_ObjectInit:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_ObjectInit:AddParameter(WT2AX,_AvO)
if(
WT2AX==0)then self.ScriptName=_AvO elseif(WT2AX==1)then self.Distance=_AvO*1 elseif
(WT2AX==2)then self.Waittime=_AvO*1 elseif(WT2AX==3)then self.RewardType=_AvO elseif(WT2AX==4)then
self.RewardAmount=tonumber(_AvO)elseif(WT2AX==5)then self.FirstCostType=_AvO elseif(WT2AX==6)then
self.FirstCostAmount=tonumber(_AvO)elseif(WT2AX==7)then self.SecondCostType=_AvO elseif(WT2AX==8)then
self.SecondCostAmount=tonumber(_AvO)elseif(WT2AX==9)then local qEO=nil
if _AvO=="Always"or 1 then qEO=1 elseif _AvO=="Never"or 2 then qEO=2 elseif _AvO==
"Knight only"or 0 then qEO=0 end;self.UsingState=qEO end end
function b_Reward_ObjectInit:CustomFunction(q)local WUY7=GetID(self.ScriptName)if WUY7 ==0 then
return end;QSB.InitalizedObjekts[WUY7]=q.Identifier
Logic.InteractiveObjectClearCosts(WUY7)Logic.InteractiveObjectClearRewards(WUY7)
Logic.InteractiveObjectSetInteractionDistance(WUY7,self.Distance)
Logic.InteractiveObjectSetTimeToOpen(WUY7,self.Waittime)if self.RewardType and self.RewardType~="disabled"then
Logic.InteractiveObjectAddRewards(WUY7,Goods[self.RewardType],self.RewardAmount)end;if
self.FirstCostType and self.FirstCostType~="disabled"then
Logic.InteractiveObjectAddCosts(WUY7,Goods[self.FirstCostType],self.FirstCostAmount)end
if
self.SecondCostType and self.SecondCostType~="disabled"then
Logic.InteractiveObjectAddCosts(WUY7,Goods[self.SecondCostType],self.SecondCostAmount)end;Logic.InteractiveObjectSetAvailability(WUY7,true)
if
self.UsingState then for _puepou=1,8 do
Logic.InteractiveObjectSetPlayerState(WUY7,_puepou,self.UsingState)end end
Logic.InteractiveObjectSetRewardResourceCartType(WUY7,Entities.U_ResourceMerchant)
Logic.InteractiveObjectSetRewardGoldCartType(WUY7,Entities.U_GoldCart)
Logic.InteractiveObjectSetCostResourceCartType(WUY7,Entities.U_ResourceMerchant)
Logic.InteractiveObjectSetCostGoldCartType(WUY7,Entities.U_GoldCart)RemoveInteractiveObjectFromOpenedList(WUY7)
table.insert(HiddenTreasures,WUY7)end
function b_Reward_ObjectInit:GetCustomData(DYLeJ)
if DYLeJ==3 or DYLeJ==5 or DYLeJ==7 then
local udbF={"-","G_Beer","G_Bread","G_Broom","G_Carcass","G_Cheese","G_Clothes","G_Dye","G_Gold","G_Grain","G_Herb","G_Honeycomb","G_Iron","G_Leather","G_Medicine","G_Milk","G_RawFish","G_Salt","G_Sausage","G_SmokedFish","G_Soap","G_Stone","G_Water","G_Wood","G_Wool"}
if g_GameExtraNo>=1 then udbF[#udbF+1]="G_Gems"
udbF[#udbF+1]="G_MusicalInstrument"udbF[#udbF+1]="G_Olibanum"end;return udbF elseif DYLeJ==9 then return{"-","Knight only","Always","Never"}end end
function b_Reward_ObjectInit:DEBUG(dt1)
if
Logic.IsInteractiveObject(GetID(self.ScriptName))==false then
dbg(""..
dt1.Identifier.." "..
self.Name..": '"..self.ScriptName..
"' is not a interactive object!")return true end;if self.UsingState~=1 and self.Distance<50 then
warn(""..
dt1.Identifier.." "..
self.Name..": distance is maybe too short!")end;if
self.Waittime<0 then
dbg(""..dt1.Identifier..
" "..self.Name..": waittime must be equal or greater than 0!")return true end
if
self.RewardType and self.RewardType~="-"then
if
not Goods[self.RewardType]then
dbg(""..
dt1.Identifier.." "..self.Name..
": '"..self.RewardType.."' is invalid good type!")return true elseif self.RewardAmount<1 then
dbg(""..dt1.Identifier.." "..
self.Name..": amount can not be 0 or negative!")return true end end
if self.FirstCostType and self.FirstCostType~="-"then
if not
Goods[self.FirstCostType]then
dbg(""..dt1.Identifier..
" "..self.Name..": '"..
self.FirstCostType.."' is invalid good type!")return true elseif self.FirstCostAmount<1 then
dbg(""..dt1.Identifier.." "..
self.Name..": amount can not be 0 or negative!")return true end end
if self.SecondCostType and self.SecondCostType~="-"then
if not
Goods[self.SecondCostType]then
dbg(""..dt1.Identifier..
" "..self.Name..": '"..
self.SecondCostType.."' is invalid good type!")return true elseif self.SecondCostAmount<1 then
dbg(""..dt1.Identifier.." "..
self.Name..": amount can not be 0 or negative!")return true end end;return false end;Core:RegisterBehavior(b_Reward_ObjectInit)function Reward_ObjectSetCarts(...)return
b_Reward_ObjectSetCarts:new(...)end
b_Reward_ObjectSetCarts={Name="Reward_ObjectSetCarts",Description={en="Reward: Set the cart types of an interactive object.",de="Lohn: Setzt die Wagentypen eines interaktiven Objektes."},Parameter={{ParameterType.ScriptName,en="Interactive object",de="Interaktives Objekt"},{ParameterType.Default,en="Cost resource type",de="Rohstoffwagen Kosten"},{ParameterType.Default,en="Cost gold type",de="Goldwagen Kosten"},{ParameterType.Default,en="Reward resource type",de="Rohstoffwagen Schatz"},{ParameterType.Default,en="Reward gold type",de="Goldwagen Schatz"}}}function b_Reward_ObjectSetCarts:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_ObjectSetCarts:AddParameter(V7eMEiVW,Co1tUVas)
if
V7eMEiVW==0 then self.ScriptName=Co1tUVas elseif V7eMEiVW==1 then if
not Co1tUVas or Co1tUVas=="default"then Co1tUVas="U_ResourceMerchant"end
self.CostResourceCart=Co1tUVas elseif V7eMEiVW==2 then if not Co1tUVas or Co1tUVas=="default"then
Co1tUVas="U_GoldCart"end;self.CostGoldCart=Co1tUVas elseif V7eMEiVW==3 then
if
not Co1tUVas or Co1tUVas=="default"then Co1tUVas="U_ResourceMerchant"end;self.RewardResourceCart=Co1tUVas elseif V7eMEiVW==4 then if
not Co1tUVas or Co1tUVas=="default"then Co1tUVas="U_GoldCart"end
self.RewardGoldCart=Co1tUVas end end
function b_Reward_ObjectSetCarts:CustomFunction(B)local UjlBMb=GetID(self.ScriptName)
Logic.InteractiveObjectSetRewardResourceCartType(UjlBMb,Entities[self.RewardResourceCart])
Logic.InteractiveObjectSetRewardGoldCartType(UjlBMb,Entities[self.RewardGoldCart])
Logic.InteractiveObjectSetCostGoldCartType(UjlBMb,Entities[self.CostResourceCart])
Logic.InteractiveObjectSetCostResourceCartType(UjlBMb,Entities[self.CostGoldCart])end
function b_Reward_ObjectSetCarts:GetCustomData(PKWIJ9)
if PKWIJ9 ==2 or PKWIJ9 ==4 then return
{"U_GoldCart","U_GoldCart_Mission","U_Noblemen_Cart","U_RegaliaCart"}elseif PKWIJ9 ==1 or PKWIJ9 ==3 then
local rQYWEt={"U_ResourceMerchant","U_Medicus","U_Marketer"}if g_GameExtraNo>0 then
table.insert(rQYWEt,"U_NPC_Resource_Monk_AS")end;return rQYWEt end end
function b_Reward_ObjectSetCarts:DEBUG(nCwsa)
if



(not Entities[self.CostResourceCart])or(not Entities[self.CostGoldCart])or(not Entities[self.RewardResourceCart])or(not Entities[self.RewardGoldCart])then
dbg(""..
nCwsa.Identifier.." "..self.Name..": invalid cart type!")return true end;local IPPy=GetID(self.ScriptName)
if QSB.InitalizedObjekts[IPPy]and
QSB.InitalizedObjekts[IPPy]==nCwsa.Identifier then
dbg(""..

nCwsa.Identifier.." "..
self.Name..": you can not change carts in the same quest the object is initalized!")return true end;return false end;Core:RegisterBehavior(b_Reward_ObjectSetCarts)function Reward_Diplomacy(...)return
b_Reward_Diplomacy:new(...)end
b_Reward_Diplomacy=API.InstanceTable(b_Reprisal_Diplomacy)b_Reward_Diplomacy.Name="Reward_ObjectDeactivate"
b_Reward_Diplomacy.Description.de="Reward: Sets Diplomacy state of two Players to a stated value."
b_Reward_Diplomacy.Description.en="Lohn: Setzt den Diplomatiestatus zweier Spieler auf den angegebenen Wert."b_Reward_Diplomacy.GetReprisalTable=nil
b_Reward_Diplomacy.GetRewardTable=function(zYGA2q2,I9Mw)return
{Reward.Custom,{zYGA2q2,zYGA2q2.CustomFunction}}end;Core:RegisterBehavior(b_Reward_Diplomacy)function Reward_DiplomacyIncrease()return
b_Reward_DiplomacyIncrease:new()end
b_Reward_DiplomacyIncrease={Name="Reward_DiplomacyIncrease",Description={en="Reward: Diplomacy increases slightly to another player",de="Lohn: Verbesserug des Diplomatiestatus zu einem anderen Spieler"}}
function b_Reward_DiplomacyIncrease:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_DiplomacyIncrease:CustomFunction(e)local BUtIET=e.SendingPlayer
local NvAj=e.ReceivingPlayer;local Icg=GetDiplomacyState(NvAj,BUtIET)if Icg<2 then
SetDiplomacyState(NvAj,BUtIET,Icg+1)end end;function b_Reward_DiplomacyIncrease:AddParameter(PzMsk,axLuO)
if(PzMsk==0)then self.PlayerID=axLuO*1 end end
Core:RegisterBehavior(b_Reward_DiplomacyIncrease)
function Reward_TradeOffers(...)return b_Reward_TradeOffers:new(...)end
b_Reward_TradeOffers={Name="Reward_TradeOffers",Description={en="Reward: Deletes all existing offers for a merchant and sets new offers, if given",de="Lohn: Löscht alle Angebote eines Händlers und setzt neue, wenn angegeben"},Parameter={{ParameterType.Custom,en="PlayerID",de="PlayerID"},{ParameterType.Custom,en="Amount 1",de="Menge 1"},{ParameterType.Custom,en="Offer 1",de="Angebot 1"},{ParameterType.Custom,en="Amount 2",de="Menge 2"},{ParameterType.Custom,en="Offer 2",de="Angebot 2"},{ParameterType.Custom,en="Amount 3",de="Menge 3"},{ParameterType.Custom,en="Offer 3",de="Angebot 3"},{ParameterType.Custom,en="Amount 4",de="Menge 4"},{ParameterType.Custom,en="Offer 4",de="Angebot 4"}}}function b_Reward_TradeOffers:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_TradeOffers:AddParameter(j,As)
if(
j==0)then self.PlayerID=As elseif(j==1)then self.AmountOffer1=tonumber(As)elseif(j==2)then
self.Offer1=As elseif(j==3)then self.AmountOffer2=tonumber(As)elseif(j==4)then self.Offer2=As elseif(j==5)then
self.AmountOffer3=tonumber(As)elseif(j==6)then self.Offer3=As elseif(j==7)then self.AmountOffer4=tonumber(As)elseif(j==8)then
self.Offer4=As end end
function b_Reward_TradeOffers:CustomFunction()
if(self.PlayerID>1)and
(self.PlayerID<9)then
local JmCzKm=Logic.GetStoreHouse(self.PlayerID)Logic.RemoveAllOffers(JmCzKm)
for Mwhc=1,4 do
if self["Offer"..Mwhc]and self["Offer"..
Mwhc]~="-"then
if
Goods[self["Offer"..Mwhc]]then
AddOffer(JmCzKm,self["AmountOffer"..Mwhc],Goods[self["Offer"..Mwhc]])elseif
Logic.IsEntityTypeInCategory(Entities[self["Offer"..Mwhc]],EntityCategories.Military)==1 then
AddMercenaryOffer(JmCzKm,self["AmountOffer"..Mwhc],Entities[self[
"Offer"..Mwhc]])else
AddEntertainerOffer(JmCzKm,Entities[self["Offer"..Mwhc]])end end end end end
function b_Reward_TradeOffers:DEBUG(A6z)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
dbg(A6z.Identifier..": Error in "..self.Name..
": Player "..self.PlayerID.." is dead. :-(")return true end end
function b_Reward_TradeOffers:GetCustomData(_Mk)local PXrrrSid={"2","3","4","5","6","7","8"}
local L9={"1","2","3","4","5","6","7","8","9"}
local _={"-","G_Beer","G_Bow","G_Bread","G_Broom","G_Candle","G_Carcass","G_Cheese","G_Clothes","G_Cow","G_Grain","G_Herb","G_Honeycomb","G_Iron","G_Leather","G_Medicine","G_Milk","G_RawFish","G_Sausage","G_Sheep","G_SmokedFish","G_Soap","G_Stone","G_Sword","G_Wood","G_Wool","G_Salt","G_Dye","U_AmmunitionCart","U_BatteringRamCart","U_CatapultCart","U_SiegeTowerCart","U_MilitaryBandit_Melee_ME","U_MilitaryBandit_Melee_SE","U_MilitaryBandit_Melee_NA","U_MilitaryBandit_Melee_NE","U_MilitaryBandit_Ranged_ME","U_MilitaryBandit_Ranged_NA","U_MilitaryBandit_Ranged_NE","U_MilitaryBandit_Ranged_SE","U_MilitaryBow_RedPrince","U_MilitaryBow","U_MilitarySword_RedPrince","U_MilitarySword","U_Entertainer_NA_FireEater","U_Entertainer_NA_StiltWalker","U_Entertainer_NE_StrongestMan_Barrel","U_Entertainer_NE_StrongestMan_Stone"}
if g_GameExtraNo and g_GameExtraNo>=1 then
table.insert(_,"G_Gems")table.insert(_,"G_Olibanum")
table.insert(_,"G_MusicalInstrument")table.insert(_,"G_MilitaryBandit_Ranged_AS")
table.insert(_,"G_MilitaryBandit_Melee_AS")table.insert(_,"U_MilitarySword_Khana")
table.insert(_,"U_MilitaryBow_Khana")end
if(_Mk==0)then return PXrrrSid elseif(_Mk==1)or(_Mk==3)or(_Mk==5)or
(_Mk==7)then return L9 elseif(_Mk==2)or(_Mk==4)or(_Mk==6)or(
_Mk==8)then return _ end end;Core:RegisterBehavior(b_Reward_TradeOffers)function Reward_DestroyEntity(...)return
b_Reward_DestroyEntity:new(...)end
b_Reward_DestroyEntity=API.InstanceTable(b_Reprisal_DestroyEntity)b_Reward_DestroyEntity.Name="Reward_DestroyEntity"
b_Reward_DestroyEntity.Description.en="Reward: Replaces an entity with an invisible script entity, which retains the entities name."
b_Reward_DestroyEntity.Description.de="Lohn: Ersetzt eine Entity mit einer unsichtbaren Script-Entity, die den Namen übernimmt."b_Reward_DestroyEntity.GetReprisalTable=nil
b_Reward_DestroyEntity.GetRewardTable=function(KZPScl,dbTwy)return
{Reward.Custom,{KZPScl,KZPScl.CustomFunction}}end;Core:RegisterBehavior(b_Reward_DestroyEntity)function Reward_DestroyEffect(...)return
b_Reward_DestroyEffect:new(...)end
b_Reward_DestroyEffect=API.InstanceTable(b_Reprisal_DestroyEffect)b_Reward_DestroyEffect.Name="Reward_DestroyEffect"
b_Reward_DestroyEffect.Description.en="Reward: Destroys an effect."
b_Reward_DestroyEffect.Description.de="Lohn: Zerstört einen Effekt."b_Reward_DestroyEffect.GetReprisalTable=nil
b_Reward_DestroyEffect.GetRewardTable=function(R4f819q,Kj1I)return
{Reward.Custom,{R4f819q,R4f819q.CustomFunction}}end;Core:RegisterBehavior(b_Reward_DestroyEffect)function Reward_CreateBattalion(...)return
b_Reward_CreateBattalion:new(...)end
b_Reward_CreateBattalion={Name="Reward_CreateBattalion",Description={en="Reward: Replaces a script entity with a battalion, which retains the entities name",de="Lohn: Ersetzt eine Script-Entity durch ein Bataillon, welches den Namen der Script-Entity übernimmt"},Parameter={{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Number,en="Number of soldiers",de="Anzahl Soldaten"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}
function b_Reward_CreateBattalion:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_CreateBattalion:AddParameter(n,TUMgqomA)
if(n==0)then self.ScriptNameEntity=TUMgqomA elseif(n==1)then self.PlayerID=
TUMgqomA*1 elseif(n==2)then self.UnitKey=TUMgqomA elseif(n==3)then
self.Orientation=TUMgqomA*1 elseif(n==4)then self.SoldierCount=TUMgqomA*1 elseif(n==5)then
self.HideFromAI=AcceptAlternativeBoolean(TUMgqomA)end end
function b_Reward_CreateBattalion:CustomFunction(Id5sIM)if
not IsExisting(self.ScriptNameEntity)then return false end
local gZM2ANLt=GetPosition(self.ScriptNameEntity)
local aC72qEnu=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],gZM2ANLt.X,gZM2ANLt.Y,self.Orientation,self.PlayerID,self.SoldierCount)local B60J=GetID(self.ScriptNameEntity)if
Logic.IsBuilding(B60J)==0 then DestroyEntity(self.ScriptNameEntity)
Logic.SetEntityName(aC72qEnu,self.ScriptNameEntity)end;if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,aC72qEnu,true)end end
function b_Reward_CreateBattalion:GetCustomData(Y4)local f={}
if Y4 ==2 then for yeCnvcd6,Iq93c6cA in pairs(Entities)do
if
Logic.IsEntityTypeInCategory(Iq93c6cA,EntityCategories.Soldier)==1 then table.insert(f,yeCnvcd6)end end
table.sort(f)elseif Y4 ==5 then table.insert(f,"false")table.insert(f,"true")else
assert(false)end;return f end
function b_Reward_CreateBattalion:DEBUG(nsM0h)
if not Entities[self.UnitKey]then
dbg(nsM0h.Identifier..
" "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
dbg(nsM0h.Identifier.." "..
self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
dbg(nsM0h.Identifier.." "..self.Name..
": playerID is wrong!")return true elseif tonumber(self.Orientation)==nil then
dbg(nsM0h.Identifier.." "..self.Name..
": orientation must be a number!")return true elseif
tonumber(self.SoldierCount)==nil or self.SoldierCount<1 then
dbg(nsM0h.Identifier..
" "..self.Name..": you can not create a empty batallion!")return true end;return false end;Core:RegisterBehavior(b_Reward_CreateBattalion)function Reward_CreateSeveralBattalions(...)return
b_Reward_CreateSeveralBattalions:new(...)end
b_Reward_CreateSeveralBattalions={Name="Reward_CreateSeveralBattalions",Description={en="Reward: Creates a given amount of battalions",de="Lohn: Erstellt eine gegebene Anzahl Bataillone"},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Number,en="Number of soldiers",de="Anzahl Soldaten"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}
function b_Reward_CreateSeveralBattalions:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_CreateSeveralBattalions:AddParameter(Czi,IlxN)
if(Czi==0)then self.Amount=IlxN*1 elseif
(Czi==1)then self.ScriptNameEntity=IlxN elseif(Czi==2)then self.PlayerID=IlxN*1 elseif(Czi==3)then
self.UnitKey=IlxN elseif(Czi==4)then self.Orientation=IlxN*1 elseif(Czi==5)then self.SoldierCount=IlxN*1 elseif
(Czi==6)then self.HideFromAI=AcceptAlternativeBoolean(IlxN)end end
function b_Reward_CreateSeveralBattalions:CustomFunction(E)if
not IsExisting(self.ScriptNameEntity)then return false end
local A_3x01A=GetID(self.ScriptNameEntity)local m54tY2,WJWMdKI,AhbP=Logic.EntityGetPos(A_3x01A)if
Logic.IsBuilding(A_3x01A)==1 then
m54tY2,WJWMdKI=Logic.GetBuildingApproachPosition(A_3x01A)end
for QHFgYUN=1,self.Amount do
local RoEsr7So=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],m54tY2,WJWMdKI,self.Orientation,self.PlayerID,self.SoldierCount)
Logic.SetEntityName(RoEsr7So,self.ScriptNameEntity.."_"..QHFgYUN)if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,RoEsr7So,true)end end end
function b_Reward_CreateSeveralBattalions:GetCustomData(dX)local Rz={}
if dX==3 then for j177r,j in pairs(Entities)do
if
Logic.IsEntityTypeInCategory(j,EntityCategories.Soldier)==1 then table.insert(Rz,j177r)end end
table.sort(Rz)elseif dX==6 then table.insert(Rz,"false")
table.insert(Rz,"true")else assert(false)end;return Rz end
function b_Reward_CreateSeveralBattalions:DEBUG(qCaFw)
if not Entities[self.UnitKey]then
dbg(
qCaFw.Identifier.." "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
dbg(qCaFw.Identifier.." "..
self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
dbg(qCaFw.Identifier.." "..self.Name..
": playerDI is wrong!")return true elseif tonumber(self.Orientation)==nil then
dbg(qCaFw.Identifier.." "..self.Name..
": orientation must be a number!")return true elseif
tonumber(self.SoldierCount)==nil or self.SoldierCount<1 then
dbg(qCaFw.Identifier..
" "..self.Name..": you can not create a empty batallion!")return true elseif
tonumber(self.Amount)==nil or self.Amount<0 then
dbg(qCaFw.Identifier..
" "..self.Name..": amount can not be negative!")return true end;return false end
Core:RegisterBehavior(b_Reward_CreateSeveralBattalions)
function Reward_CreateEffect(...)return b_Reward_CreateEffect:new(...)end
b_Reward_CreateEffect={Name="Reward_CreateEffect",Description={en="Reward: Creates an effect at a specified position",de="Lohn: Erstellt einen Effekt an der angegebenen Position"},Parameter={{ParameterType.Default,en="Effect name",de="Effektname"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.ScriptName,en="Location",de="Ort"},{ParameterType.Number,en="Orientation (in degrees)(-1: from locating entity)",de="Ausrichtung (in Grad)(-1: von Positionseinheit)"}}}
function b_Reward_CreateEffect:AddParameter(syvPi,NrgSK2)
if syvPi==0 then self.EffectName=NrgSK2 elseif syvPi==1 then
self.Type=EGL_Effects[NrgSK2]elseif syvPi==2 then self.PlayerID=NrgSK2*1 elseif syvPi==3 then self.Location=NrgSK2 elseif syvPi==4 then self.Orientation=
NrgSK2*1 end end
function b_Reward_CreateEffect:GetRewardTable(wIH)return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_CreateEffect:CustomFunction(TYWkpc)
if Logic.IsEntityDestroyed(self.Location)then return end
local k=assert(GetID(self.Location),TYWkpc.Identifier.."Error in "..
self.Name..": CustomFunction: Entity is invalid")
if QSB.EffectNameToID[self.EffectName]and
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])then return end;local J,gtlO9=Logic.GetEntityPosition(k)
local Lun=tonumber(self.Orientation)
local beUJXhjw=Logic.CreateEffectWithOrientation(self.Type,J,gtlO9,Lun,self.PlayerID)if self.EffectName~=""then
QSB.EffectNameToID[self.EffectName]=beUJXhjw end end
function b_Reward_CreateEffect:DEBUG(zY7adu)
if QSB.EffectNameToID[self.EffectName]and
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])then
dbg(""..zY7adu.Identifier.." "..self.Name..
": effect already exists!")return true elseif not IsExisting(self.Location)then
sbg(""..zY7adu.Identifier.." "..
self.Name..
": location '"..self.Location.."' is missing!")return true elseif self.PlayerID and
(self.PlayerID<0 or self.PlayerID>8)then
dbg(""..zY7adu.Identifier.." "..
self.Name..": invalid playerID!")return true elseif tonumber(self.Orientation)==nil then
dbg(""..zY7adu.Identifier.." "..self.Name..
": invalid orientation!")return true end end
function b_Reward_CreateEffect:GetCustomData(Nlvw)
assert(Nlvw==1,"Error in "..
self.Name..": GetCustomData: Index is invalid.")local K55={}
for BJcMTdMi,f1MKKJ in pairs(EGL_Effects)do table.insert(K55,BJcMTdMi)end;table.sort(K55)return K55 end;Core:RegisterBehavior(b_Reward_CreateEffect)function Reward_CreateEntity(...)return
b_Reward_CreateEntity:new(...)end
b_Reward_CreateEntity={Name="Reward_CreateEntity",Description={en="Reward: Replaces an entity by a new one of a given type",de="Lohn: Ersetzt eine Entity durch eine neue gegebenen Typs"},Parameter={{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}function b_Reward_CreateEntity:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_CreateEntity:AddParameter(nFf,EIqL41)
if(
nFf==0)then self.ScriptNameEntity=EIqL41 elseif(nFf==1)then self.PlayerID=EIqL41*1 elseif(
nFf==2)then self.UnitKey=EIqL41 elseif(nFf==3)then self.Orientation=EIqL41*1 elseif
(nFf==4)then self.HideFromAI=AcceptAlternativeBoolean(EIqL41)end end
function b_Reward_CreateEntity:CustomFunction(iv)if
not IsExisting(self.ScriptNameEntity)then return false end
local rfmMR4=GetPosition(self.ScriptNameEntity)local Tq2I
if
Logic.IsEntityTypeInCategory(self.UnitKey,EntityCategories.Soldier)==1 then
Tq2I=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],rfmMR4.X,rfmMR4.Y,self.Orientation,self.PlayerID,1)
local e5x,QrONvWGq={Logic.GetSoldiersAttachedToLeader(Tq2I)}Logic.SetOrientation(QrONvWGq,self.Orientation)else
Tq2I=Logic.CreateEntityOnUnblockedLand(Entities[self.UnitKey],rfmMR4.X,rfmMR4.Y,self.Orientation,self.PlayerID)end;local GNo=GetID(self.ScriptNameEntity)if
Logic.IsBuilding(GNo)==0 then DestroyEntity(self.ScriptNameEntity)
Logic.SetEntityName(Tq2I,self.ScriptNameEntity)end;if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,Tq2I,true)end end
function b_Reward_CreateEntity:GetCustomData(D94fnZaa)local XI={}
if D94fnZaa==2 then
for FNi,pRW2nEmK in pairs(Entities)do
local OR={"^M_*","^XS_*","^X_*","^XT_*","^Z_*"}local Arww=false
for BYH=1,#OR do if FNi:find(OR[BYH])then Arww=true;break end end;if not Arww then table.insert(XI,FNi)end end;table.sort(XI)elseif D94fnZaa==4 or D94fnZaa==5 then
table.insert(XI,"false")table.insert(XI,"true")else assert(false)end;return XI end
function b_Reward_CreateEntity:DEBUG(o7E8TLH)
if not Entities[self.UnitKey]then
dbg(o7E8TLH.Identifier..
" "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
dbg(o7E8TLH.Identifier..
" "..self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<0 or self.PlayerID>8 then
dbg(o7E8TLH.Identifier.." "..self.Name..
": playerID is not valid!")return true elseif tonumber(self.Orientation)==nil then
dbg(o7E8TLH.Identifier.." "..self.Name..
": orientation must be a number!")return true end;return false end;Core:RegisterBehavior(b_Reward_CreateEntity)function Reward_CreateSeveralEntities(...)return
b_Reward_CreateSeveralEntities:new(...)end
b_Reward_CreateSeveralEntities={Name="Reward_CreateSeveralEntities",Description={en="Reward: Creating serveral battalions at the position of a entity. They retains the entities name and a _[index] suffix",de="Lohn: Erzeugt mehrere Entities an der Position der Entity. Sie übernimmt den Namen der Script Entity und den Suffix _[index]"},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}
function b_Reward_CreateSeveralEntities:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_CreateSeveralEntities:AddParameter(N5N27Jd,m)
if(N5N27Jd==0)then self.Amount=m*1 elseif
(N5N27Jd==1)then self.ScriptNameEntity=m elseif(N5N27Jd==2)then self.PlayerID=m*1 elseif(N5N27Jd==3)then
self.UnitKey=m elseif(N5N27Jd==4)then self.Orientation=m*1 elseif(N5N27Jd==5)then
self.HideFromAI=AcceptAlternativeBoolean(m)end end
function b_Reward_CreateSeveralEntities:CustomFunction(nK)if
not IsExisting(self.ScriptNameEntity)then return false end
local _zr=GetPosition(self.ScriptNameEntity)local f5
for UAc=1,self.Amount do
if
Logic.IsEntityTypeInCategory(self.UnitKey,EntityCategories.Soldier)==1 then
f5=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],_zr.X,_zr.Y,self.Orientation,self.PlayerID,1)
local E,f={Logic.GetSoldiersAttachedToLeader(f5)}Logic.SetOrientation(f,self.Orientation)else
f5=Logic.CreateEntityOnUnblockedLand(Entities[self.UnitKey],_zr.X,_zr.Y,self.Orientation,self.PlayerID)end
Logic.SetEntityName(f5,self.ScriptNameEntity.."_"..UAc)if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,f5,true)end end end
function b_Reward_CreateSeveralEntities:GetCustomData(P)local F4AWvI={}
if P==3 then
for GYVN,DNlB1V in pairs(Entities)do
local erb6G_E={"^M_*","^XS_*","^X_*","^XT_*","^Z_*"}local QFUU10K=false;for xNPDtul=1,#erb6G_E do
if GYVN:find(erb6G_E[xNPDtul])then QFUU10K=true;break end end;if not QFUU10K then
table.insert(F4AWvI,GYVN)end end;table.sort(F4AWvI)elseif P==5 or P==6 then
table.insert(F4AWvI,"false")table.insert(F4AWvI,"true")else assert(false)end;return F4AWvI end
function b_Reward_CreateSeveralEntities:DEBUG(k8)
if not Entities[self.UnitKey]then
dbg(
k8.Identifier.." "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
dbg(k8.Identifier.." "..
self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
dbg(k8.Identifier.." "..self.Name..
": spawnpoint does not exist!")return true elseif tonumber(self.Orientation)==nil then
dbg(k8.Identifier.." "..self.Name..
": orientation must be a number!")return true elseif
tonumber(self.Amount)==nil or self.Amount<0 then
dbg(k8.Identifier..
" "..self.Name..": amount can not be negative!")return true end;return false end
Core:RegisterBehavior(b_Reward_CreateSeveralEntities)
function Reward_MoveSettler(...)return b_Reward_MoveSettler:new(...)end
b_Reward_MoveSettler={Name="Reward_MoveSettler",Description={en="Reward: Moves a (NPC) settler to a destination. Must not be AI controlled, or it won't move",de="Lohn: Bewegt einen (NPC) Siedler zu einem Zielort. Darf keinem KI Spieler gehören, ansonsten wird sich der Siedler nicht bewegen"},Parameter={{ParameterType.ScriptName,en="Settler",de="Siedler"},{ParameterType.ScriptName,en="Destination",de="Ziel"}}}function b_Reward_MoveSettler:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_MoveSettler:AddParameter(HmgRk,UuCdpVi)if(
HmgRk==0)then self.ScriptNameUnit=UuCdpVi elseif(HmgRk==1)then
self.ScriptNameDest=UuCdpVi end end
function b_Reward_MoveSettler:CustomFunction(fghe)
if Logic.IsEntityDestroyed(self.ScriptNameUnit)or
Logic.IsEntityDestroyed(self.ScriptNameDest)then return false end;local vFXf=GetID(self.ScriptNameDest)
local CA0uX7n,ze5Vpc3=Logic.GetEntityPosition(vFXf)if Logic.IsBuilding(vFXf)==1 then
CA0uX7n,ze5Vpc3=Logic.GetBuildingApproachPosition(vFXf)end
Logic.MoveSettler(GetID(self.ScriptNameUnit),CA0uX7n,ze5Vpc3)end
function b_Reward_MoveSettler:DEBUG(vwK8)
if
not not IsExisting(self.ScriptNameUnit)then
dbg(vwK8.Identifier..
" "..self.Name..": mover entity does not exist!")return true elseif not IsExisting(self.ScriptNameDest)then
dbg(vwK8.Identifier.." "..
self.Name..": destination does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reward_MoveSettler)function Reward_Victory()return
b_Reward_Victory:new()end
b_Reward_Victory={Name="Reward_Victory",Description={en="Reward: The player wins the game.",de="Lohn: Der Spieler gewinnt das Spiel."}}
function b_Reward_Victory:GetRewardTable(Sk_SiC)return{Reward.Victory}end;Core:RegisterBehavior(b_Reward_Victory)function Reward_Defeat()return
b_Reward_Defeat:new()end
b_Reward_Defeat={Name="Reward_Defeat",Description={en="Reward: The player loses the game.",de="Lohn: Der Spieler verliert das Spiel."}}function b_Reward_Defeat:GetRewardTable(X0bgPvA)return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_Defeat:CustomFunction(M9CyqH)
M9CyqH:TerminateEventsAndStuff()
Logic.ExecuteInLuaLocalState("GUI_Window.MissionEndScreenSetVictoryReasonText("..
g_VictoryAndDefeatType.DefeatMissionFailed..")")Defeated(M9CyqH.ReceivingPlayer)end;Core:RegisterBehavior(b_Reward_Defeat)function Reward_FakeVictory()return
b_Reward_FakeVictory:new()end
b_Reward_FakeVictory={Name="Reward_FakeVictory",Description={en="Reward: Display a victory icon for a quest",de="Lohn: Zeigt ein Siegesicon fuer diese Quest"}}
function b_Reward_FakeVictory:GetRewardTable()return{Reward.FakeVictory}end;Core:RegisterBehavior(b_Reward_FakeVictory)
function Reward_AI_SpawnAndAttackTerritory(...)return
b_Reward_AI_SpawnAndAttackTerritory:new(...)end
b_Reward_AI_SpawnAndAttackTerritory={Name="Reward_AI_SpawnAndAttackTerritory",Description={en="Reward: Spawns AI troops and attacks a territory (Hint: Use for hidden quests as a surprise)",de="Lohn: Erstellt KI Truppen und greift ein Territorium an (Tipp: Fuer eine versteckte Quest als Ueberraschung verwenden)"},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.ScriptName,en="Spawn point",de="Erstellungsort"},{ParameterType.TerritoryName,en="Territory",de="Territorium"},{ParameterType.Number,en="Sword",de="Schwert"},{ParameterType.Number,en="Bow",de="Bogen"},{ParameterType.Number,en="Catapults",de="Katapulte"},{ParameterType.Number,en="Siege towers",de="Belagerungstuerme"},{ParameterType.Number,en="Rams",de="Rammen"},{ParameterType.Number,en="Ammo carts",de="Munitionswagen"},{ParameterType.Custom,en="Soldier type",de="Soldatentyp"},{ParameterType.Custom,en="Reuse troops",de="Verwende bestehende Truppen"}}}
function b_Reward_AI_SpawnAndAttackTerritory:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_SpawnAndAttackTerritory:AddParameter(z0x4qSAN,X0GTupeV)
if(z0x4qSAN==0)then
self.AIPlayerID=X0GTupeV*1 elseif(z0x4qSAN==1)then self.Spawnpoint=X0GTupeV elseif(z0x4qSAN==2)then
self.TerritoryID=tonumber(X0GTupeV)if not self.TerritoryID then
self.TerritoryID=GetTerritoryIDByName(X0GTupeV)end elseif(z0x4qSAN==3)then
self.NumSword=X0GTupeV*1 elseif(z0x4qSAN==4)then self.NumBow=X0GTupeV*1 elseif(z0x4qSAN==5)then self.NumCatapults=
X0GTupeV*1 elseif(z0x4qSAN==6)then self.NumSiegeTowers=X0GTupeV*1 elseif(
z0x4qSAN==7)then self.NumRams=X0GTupeV*1 elseif(z0x4qSAN==8)then
self.NumAmmoCarts=X0GTupeV*1 elseif(z0x4qSAN==9)then
if X0GTupeV=="Normal"or X0GTupeV==false then
self.TroopType=false elseif X0GTupeV=="RedPrince"or X0GTupeV==true then self.TroopType=true elseif
X0GTupeV=="Bandit"or X0GTupeV==2 then self.TroopType=2 elseif
X0GTupeV=="Cultist"or X0GTupeV==3 then self.TroopType=3 else assert(false)end elseif(z0x4qSAN==10)then
self.ReuseTroops=AcceptAlternativeBoolean(X0GTupeV)end end
function b_Reward_AI_SpawnAndAttackTerritory:GetCustomData(rQ)local k={}
if rQ==9 then
table.insert(k,"Normal")table.insert(k,"RedPrince")
table.insert(k,"Bandit")
if g_GameExtraNo>=1 then table.insert(k,"Cultist")end elseif rQ==10 then table.insert(k,"false")table.insert(k,"true")else
assert(false)end;return k end
function b_Reward_AI_SpawnAndAttackTerritory:CustomFunction(Oc)
local IHovU=Logic.GetTerritoryAcquiringBuildingID(self.TerritoryID)
if IHovU~=0 then
AIScript_SpawnAndAttackCity(self.AIPlayerID,IHovU,self.Spawnpoint,self.NumSword,self.NumBow,self.NumCatapults,self.NumSiegeTowers,self.NumRams,self.NumAmmoCarts,self.TroopType,self.ReuseTroops)end end
function b_Reward_AI_SpawnAndAttackTerritory:DEBUG(e_wDQjk)
if self.AIPlayerID<2 then
dbg(e_wDQjk.Identifier..
": Error in "..
self.Name..": Player "..self.AIPlayerID.." is wrong")return true elseif Logic.IsEntityDestroyed(self.Spawnpoint)then
dbg(e_wDQjk.Identifier.." "..
self.Name..
": Entity "..self.SpawnPoint.." is missing")return true elseif self.TerritoryID==0 then
dbg(e_wDQjk.Identifier.." "..
self.Name..": Territory unknown")return true elseif self.NumSword<0 then
dbg(e_wDQjk.Identifier.." "..
self.Name..": Number of Swords is negative")return true elseif self.NumBow<0 then
dbg(e_wDQjk.Identifier.." "..
self.Name..": Number of Bows is negative")return true elseif self.NumBow+self.NumSword<1 then
dbg(e_wDQjk.Identifier.." "..self.Name..
": No Soldiers?")return true elseif self.NumCatapults<0 then
dbg(e_wDQjk.Identifier.." "..
self.Name..": Catapults is negative")return true elseif self.NumSiegeTowers<0 then
dbg(e_wDQjk.Identifier.." "..
self.Name..": SiegeTowers is negative")return true elseif self.NumRams<0 then
dbg(e_wDQjk.Identifier..
" "..self.Name..": Rams is negative")return true elseif self.NumAmmoCarts<0 then
dbg(e_wDQjk.Identifier.." "..
self.Name..": AmmoCarts is negative")return true end;return false end
Core:RegisterBehavior(b_Reward_AI_SpawnAndAttackTerritory)function Reward_AI_SpawnAndAttackArea(...)
return b_Reward_AI_SpawnAndAttackArea:new(...)end
b_Reward_AI_SpawnAndAttackArea={Name="Reward_AI_SpawnAndAttackArea",Description={en="Reward: Spawns AI troops and attacks everything within the specified area, except the players main buildings",de="Lohn: Erstellt KI Truppen und greift ein angegebenes Gebiet an, aber nicht die Hauptgebauede eines Spielers"},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.ScriptName,en="Spawn point",de="Erstellungsort"},{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Number,en="Radius",de="Radius"},{ParameterType.Number,en="Sword",de="Schwert"},{ParameterType.Number,en="Bow",de="Bogen"},{ParameterType.Custom,en="Soldier type",de="Soldatentyp"},{ParameterType.Custom,en="Reuse troops",de="Verwende bestehende Truppen"}}}
function b_Reward_AI_SpawnAndAttackArea:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_SpawnAndAttackArea:AddParameter(ClglY,S)
if(ClglY==0)then self.AIPlayerID=S*1 elseif
(ClglY==1)then self.Spawnpoint=S elseif(ClglY==2)then self.TargetName=S elseif(ClglY==3)then
self.Radius=S*1 elseif(ClglY==4)then self.NumSword=S*1 elseif(ClglY==5)then self.NumBow=S*1 elseif(ClglY==6)then
if S==
"Normal"or S==false then self.TroopType=false elseif
S=="RedPrince"or S==true then self.TroopType=true elseif S=="Bandit"or S==2 then self.TroopType=2 elseif
S=="Cultist"or S==3 then self.TroopType=3 else assert(false)end elseif(ClglY==7)then self.ReuseTroops=AcceptAlternativeBoolean(S)end end
function b_Reward_AI_SpawnAndAttackArea:GetCustomData(NKetZhs)local EFLZ0N1={}
if NKetZhs==6 then
table.insert(EFLZ0N1,"Normal")table.insert(EFLZ0N1,"RedPrince")
table.insert(EFLZ0N1,"Bandit")
if g_GameExtraNo>=1 then table.insert(EFLZ0N1,"Cultist")end elseif NKetZhs==7 then table.insert(EFLZ0N1,"false")
table.insert(EFLZ0N1,"true")else assert(false)end;return EFLZ0N1 end
function b_Reward_AI_SpawnAndAttackArea:CustomFunction(gL)
if

Logic.IsEntityAlive(self.TargetName)and Logic.IsEntityAlive(self.Spawnpoint)then local m4=GetID(self.TargetName)
AIScript_SpawnAndRaidSettlement(self.AIPlayerID,m4,self.Spawnpoint,self.Radius,self.NumSword,self.NumBow,self.TroopType,self.ReuseTroops)end end
function b_Reward_AI_SpawnAndAttackArea:DEBUG(rNOL8G)
if self.AIPlayerID<2 then
dbg(rNOL8G.Identifier.." "..
self.Name..
": Player "..self.AIPlayerID.." is wrong")return true elseif Logic.IsEntityDestroyed(self.Spawnpoint)then
dbg(rNOL8G.Identifier.." "..
self.Name..
": Entity "..self.SpawnPoint.." is missing")return true elseif Logic.IsEntityDestroyed(self.TargetName)then
dbg(rNOL8G.Identifier.." "..
self.Name..
": Entity "..self.TargetName.." is missing")return true elseif self.Radius<1 then
dbg(rNOL8G.Identifier.." "..
self.Name..": Radius is to small or negative")return true elseif self.NumSword<0 then
dbg(rNOL8G.Identifier.." "..
self.Name..": Number of Swords is negative")return true elseif self.NumBow<0 then
dbg(rNOL8G.Identifier.." "..
self.Name..": Number of Bows is negative")return true elseif self.NumBow+self.NumSword<1 then
dbg(rNOL8G.Identifier..": Error in "..
self.Name..": No Soldiers?")return true end;return false end
Core:RegisterBehavior(b_Reward_AI_SpawnAndAttackArea)function Reward_AI_SpawnAndProtectArea(...)
return b_Reward_AI_SpawnAndProtectArea:new(...)end
b_Reward_AI_SpawnAndProtectArea={Name="Reward_AI_SpawnAndProtectArea",Description={en="Reward: Spawns AI troops and defends a specified area",de="Lohn: Erstellt KI Truppen und verteidigt ein angegebenes Gebiet"},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.ScriptName,en="Spawn point",de="Erstellungsort"},{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Number,en="Radius",de="Radius"},{ParameterType.Number,en="Time (-1 for infinite)",de="Zeit (-1 fuer unendlich)"},{ParameterType.Number,en="Sword",de="Schwert"},{ParameterType.Number,en="Bow",de="Bogen"},{ParameterType.Custom,en="Capture tradecarts",de="Handelskarren angreifen"},{ParameterType.Custom,en="Soldier type",de="Soldatentyp"},{ParameterType.Custom,en="Reuse troops",de="Verwende bestehende Truppen"}}}
function b_Reward_AI_SpawnAndProtectArea:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_SpawnAndProtectArea:AddParameter(q,lKO)
if(q==0)then self.AIPlayerID=lKO*1 elseif(q==1)then
self.Spawnpoint=lKO elseif(q==2)then self.TargetName=lKO elseif(q==3)then self.Radius=lKO*1 elseif(q==4)then
self.Time=lKO*1 elseif(q==5)then self.NumSword=lKO*1 elseif(q==6)then self.NumBow=lKO*1 elseif(q==7)then
self.CaptureTradeCarts=AcceptAlternativeBoolean(lKO)elseif(q==8)then
if lKO=="Normal"or lKO==true then self.TroopType=false elseif lKO=="RedPrince"or
lKO==false then self.TroopType=true elseif lKO=="Bandit"or lKO==2 then
self.TroopType=2 elseif lKO=="Cultist"or lKO==3 then self.TroopType=3 else assert(false)end elseif(q==9)then self.ReuseTroops=AcceptAlternativeBoolean(lKO)end end
function b_Reward_AI_SpawnAndProtectArea:GetCustomData(hcwgu)local omgCdqp8={}
if hcwgu==7 then
table.insert(omgCdqp8,"false")table.insert(omgCdqp8,"true")elseif hcwgu==8 then
table.insert(omgCdqp8,"Normal")table.insert(omgCdqp8,"RedPrince")
table.insert(omgCdqp8,"Bandit")
if g_GameExtraNo>=1 then table.insert(omgCdqp8,"Cultist")end elseif hcwgu==9 then table.insert(omgCdqp8,"false")
table.insert(omgCdqp8,"true")else assert(false)end;return omgCdqp8 end
function b_Reward_AI_SpawnAndProtectArea:CustomFunction(X17eHTx)
if

Logic.IsEntityAlive(self.TargetName)and Logic.IsEntityAlive(self.Spawnpoint)then local SGF=GetID(self.TargetName)
AIScript_SpawnAndProtectArea(self.AIPlayerID,SGF,self.Spawnpoint,self.Radius,self.NumSword,self.NumBow,self.Time,self.TroopType,self.ReuseTroops,self.CaptureTradeCarts)end end
function b_Reward_AI_SpawnAndProtectArea:DEBUG(myIHU)
if self.AIPlayerID<2 then
dbg(myIHU.Identifier.." "..
self.Name..
": Player "..self.AIPlayerID.." is wrong")return true elseif Logic.IsEntityDestroyed(self.Spawnpoint)then
dbg(myIHU.Identifier.." "..
self.Name..
": Entity "..self.SpawnPoint.." is missing")return true elseif Logic.IsEntityDestroyed(self.TargetName)then
dbg(myIHU.Identifier.." "..
self.Name..
": Entity "..self.TargetName.." is missing")return true elseif self.Radius<1 then
dbg(myIHU.Identifier.." "..
self.Name..": Radius is to small or negative")return true elseif self.Time<-1 then
dbg(myIHU.Identifier..
" "..self.Name..": Time is smaller than -1")return true elseif self.NumSword<0 then
dbg(myIHU.Identifier.." "..
self.Name..": Number of Swords is negative")return true elseif self.NumBow<0 then
dbg(myIHU.Identifier.." "..
self.Name..": Number of Bows is negative")return true elseif self.NumBow+self.NumSword<1 then
dbg(myIHU.Identifier.." "..self.Name..
": No Soldiers?")return true end;return false end
Core:RegisterBehavior(b_Reward_AI_SpawnAndProtectArea)function Reward_AI_SetNumericalFact(...)
return b_Reward_AI_SetNumericalFact:new(...)end
b_Reward_AI_SetNumericalFact={Name="Reward_AI_SetNumericalFact",Description={en="Reward: Sets a numerical fact for the AI player",de="Lohn: Setzt eine Verhaltensregel fuer den KI-Spieler. "},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.Custom,en="Numerical Fact",de="Verhaltensregel"},{ParameterType.Number,en="Value",de="Wert"}}}
function b_Reward_AI_SetNumericalFact:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_SetNumericalFact:AddParameter(xxNCdF,_)
if(xxNCdF==0)then self.AIPlayerID=_*1 elseif
(xxNCdF==1)then
local cl1b={["Courage"]="FEAR",["Reconstruction"]="BARB",["Build Order"]="BPMX",["Conquer Outposts"]="FCOP",["Mount Outposts"]="FMOP",["max. Bowmen"]="FMBM",["max. Swordmen"]="FMSM",["max. Rams"]="FMRA",["max. Catapults"]="FMCA",["max. Ammunition Carts"]="FMAC",["max. Siege Towers"]="FMST",["max. Wall Catapults"]="FMBA",["FEAR"]="FEAR",["BARB"]="BARB",["BPMX"]="BPMX",["FCOP"]="FCOP",["FMOP"]="FMOP",["FMBM"]="FMBM",["FMSM"]="FMSM",["FMRA"]="FMRA",["FMCA"]="FMCA",["FMAC"]="FMAC",["FMST"]="FMST",["FMBA"]="FMBA"}self.NumericalFact=cl1b[_]elseif(xxNCdF==2)then self.Value=_*1 end end;function b_Reward_AI_SetNumericalFact:CustomFunction(Xz18nk)
AICore.SetNumericalFact(self.AIPlayerID,self.NumericalFact,self.Value)end
function b_Reward_AI_SetNumericalFact:GetCustomData(P)
if(
P==1)then
return
{"Courage","Reconstruction","Build Order","Conquer Outposts","Mount Outposts","max. Bowmen","max. Swordmen","max. Rams","max. Catapults","max. Ammunition Carts","max. Siege Towers","max. Wall Catapults"}end end
function b_Reward_AI_SetNumericalFact:DEBUG(sTX4)
if
Logic.GetStoreHouse(self.AIPlayerID)==0 then
dbg(sTX4.Identifier.." "..self.Name..
": Player "..self.AIPlayerID.." is wrong or dead!")return true elseif not self.NumericalFact then
dbg(sTX4.Identifier.." "..
self.Name..": invalid numerical fact choosen!")return true else
if
self.NumericalFact=="BARB"or self.NumericalFact=="FCOP"or self.NumericalFact=="FMOP"then
if
self.Value~=0 and self.Value~=1 then
dbg(sTX4.Identifier.." "..self.Name..
": BARB, FCOP, FMOP: value must be 1 or 0!")return true end elseif self.NumericalFact=="FEAR"then if self.Value<=0 then
dbg(sTX4.Identifier.." "..self.Name..
": FEAR: value must greater than 0!")return true end else if
self.Value<0 then
dbg(sTX4.Identifier..
" "..self.Name..": value must always greater than or equal 0!")return true end end end;return false end
Core:RegisterBehavior(b_Reward_AI_SetNumericalFact)function Reward_AI_Aggressiveness(...)
return b_Reward_AI_Aggressiveness:new(...)end
b_Reward_AI_Aggressiveness={Name="Reward_AI_Aggressiveness",Description={en="Reward: Sets the AI player's aggressiveness.",de="Lohn: Setzt die Aggressivität des KI-Spielers fest."},Parameter={{ParameterType.PlayerID,en="AI player",de="KI-Spieler"},{ParameterType.Custom,en="Aggressiveness (1-3)",de="Aggressivität (1-3)"}}}
function b_Reward_AI_Aggressiveness:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_Aggressiveness:AddParameter(A0TJx,Nqdkw)if A0TJx==0 then self.AIPlayer=Nqdkw*1 elseif A0TJx==1 then
self.Aggressiveness=tonumber(Nqdkw)end end
function b_Reward_AI_Aggressiveness:CustomFunction()
local t=(PlayerAIs[self.AIPlayer]or
AIPlayerTable[self.AIPlayer]or
AIPlayer:new(self.AIPlayer,AIPlayerProfile_City))PlayerAIs[self.AIPlayer]=t
if self.Aggressiveness>=2 then
t.m_ProfileLoop=AIProfile_Skirmish;t.Skirmish=t.Skirmish or{}
t.Skirmish.Claim_MinTime=SkirmishDefault.Claim_MinTime+ (
self.Aggressiveness-2)*390;t.Skirmish.Claim_MaxTime=t.Skirmish.Claim_MinTime*2 else
t.m_ProfileLoop=AIPlayerProfile_City end end
function b_Reward_AI_Aggressiveness:DEBUG(QbMO)
if self.AIPlayer<2 or
Logic.GetStoreHouse(self.AIPlayer)==0 then
dbg(QbMO.Identifier..
": Error in "..self.Name..
": Player "..self.PlayerID.." is wrong")return true end end
function b_Reward_AI_Aggressiveness:GetCustomData(wYZ)
assert(wYZ==1,"Error in "..
self.Name..": GetCustomData: Index is invalid.")return{"1","2","3"}end;Core:RegisterBehavior(b_Reward_AI_Aggressiveness)function Reward_AI_SetEnemy(...)return
b_Reward_AI_SetEnemy:new(...)end
b_Reward_AI_SetEnemy={Name="Reward_AI_SetEnemy",Description={en="Reward:Sets the enemy of an AI player (the AI only handles one enemy properly).",de="Lohn: Legt den Feind eines KI-Spielers fest (die KI behandelt nur einen Feind korrekt)."},Parameter={{ParameterType.PlayerID,en="AI player",de="KI-Spieler"},{ParameterType.PlayerID,en="Enemy",de="Feind"}}}function b_Reward_AI_SetEnemy:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function b_Reward_AI_SetEnemy:AddParameter(aMd,o0pf)
if
aMd==0 then self.AIPlayer=o0pf*1 elseif aMd==1 then self.Enemy=o0pf*1 end end
function b_Reward_AI_SetEnemy:CustomFunction()
local tx1LD=PlayerAIs[self.AIPlayer]
if tx1LD and tx1LD.Skirmish then tx1LD.Skirmish.Enemy=self.Enemy end end
function b_Reward_AI_SetEnemy:DEBUG(N3ROeR)
if self.AIPlayer<=1 or self.AIPlayer>=8 or
Logic.PlayerGetIsHumanFlag(self.AIPlayer)then
dbg(N3ROeR.Identifier..
": Error in "..self.Name..": Player "..
self.AIPlayer.." is wrong")return true end end;Core:RegisterBehavior(b_Reward_AI_SetEnemy)function Reward_ReplaceEntity(...)return
b_Reward_ReplaceEntity:new(...)end
b_Reward_ReplaceEntity=API.InstanceTable(b_Reprisal_ReplaceEntity)b_Reward_ReplaceEntity.Name="Reward_ReplaceEntity"
b_Reward_ReplaceEntity.Description.en="Reward: Replaces an entity with a new one of a different type. The playerID can be changed too."
b_Reward_ReplaceEntity.Description.de="Lohn: Ersetzt eine Entity durch eine neue anderen Typs. Es kann auch die Spielerzugehörigkeit geändert werden."b_Reward_ReplaceEntity.GetReprisalTable=nil
b_Reward_ReplaceEntity.GetRewardTable=function(I1oQVnUd,oTX)return
{Reward.Custom,{I1oQVnUd,I1oQVnUd.CustomFunction}}end;Core:RegisterBehavior(b_Reward_ReplaceEntity)function Reward_SetResourceAmount(...)return
b_Reward_SetResourceAmount:new(...)end
b_Reward_SetResourceAmount={Name="Reward_SetResourceAmount",Description={en="Reward: Set the current and maximum amount of a resource doodad (the amount can also set to 0)",de="Lohn: Setzt die aktuellen sowie maximalen Resourcen in einem Doodad (auch 0 ist möglich)"},Parameter={{ParameterType.ScriptName,en="Ressource",de="Resource"},{ParameterType.Number,en="Amount",de="Menge"}}}
function b_Reward_SetResourceAmount:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_SetResourceAmount:AddParameter(WZlF4,IxqPDOWH)if(WZlF4 ==0)then self.ScriptName=IxqPDOWH elseif
(WZlF4 ==1)then self.Amount=IxqPDOWH*1 end end
function b_Reward_SetResourceAmount:CustomFunction(GZqV)if
Logic.IsEntityDestroyed(self.ScriptName)then return false end
local OVubrDw_=GetID(self.ScriptName)
if Logic.GetResourceDoodadGoodType(OVubrDw_)==0 then return false end
Logic.SetResourceDoodadGoodAmount(OVubrDw_,self.Amount)end
function b_Reward_SetResourceAmount:DEBUG(G2_TeR8)
if not IsExisting(self.ScriptName)then
dbg(
G2_TeR8.Identifier.." "..self.Name..": resource entity does not exist!")return true elseif
not type(self.Amount)=="number"or self.Amount<0 then
dbg(G2_TeR8.Identifier..
" "..self.Name..": resource amount can not be negative!")return true end;return false end;Core:RegisterBehavior(b_Reward_SetResourceAmount)function Reward_Resources(...)return
b_Reward_Resources:new(...)end
b_Reward_Resources={Name="Reward_Resources",Description={en="Reward: The player receives a given amount of Goods in his store.",de="Lohn: Legt der Partei die angegebenen Rohstoffe ins Lagerhaus."},Parameter={{ParameterType.RawGoods,en="Type of good",de="Resourcentyp"},{ParameterType.Number,en="Amount of good",de="Anzahl der Resource"}}}
function b_Reward_Resources:AddParameter(y,k)if(y==0)then self.GoodTypeName=k elseif(y==1)then
self.GoodAmount=k*1 end end
function b_Reward_Resources:GetRewardTable()
local OPSPMfr_=Logic.GetGoodTypeID(self.GoodTypeName)return{Reward.Resources,OPSPMfr_,self.GoodAmount}end;Core:RegisterBehavior(b_Reward_Resources)function Reward_SendCart(...)return
b_Reward_SendCart:new(...)end
b_Reward_SendCart={Name="Reward_SendCart",Description={en="Reward: Sends a cart to a player. It spawns at a building or by replacing an entity. The cart can replace the entity if it's not a building.",de="Lohn: Sendet einen Karren zu einem Spieler. Der Karren wird an einem Gebäude oder einer Entity erstellt. Er ersetzt die Entity, wenn diese kein Gebäude ist."},Parameter={{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Owning player",de="Besitzer"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Custom,en="Good type",de="Warentyp"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.Custom,en="Override target player",de="Anderer Zielspieler"},{ParameterType.Custom,en="Ignore reservations",de="Ignoriere Reservierungen"},{ParameterType.Custom,en="Replace entity",de="Entity ersetzen"}}}function b_Reward_SendCart:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_SendCart:AddParameter(QnNOl,aQs)
if(
QnNOl==0)then self.ScriptNameEntity=aQs elseif(QnNOl==1)then self.PlayerID=aQs*1 elseif
(QnNOl==2)then self.UnitKey=aQs elseif(QnNOl==3)then self.GoodType=aQs elseif(QnNOl==4)then
self.GoodAmount=aQs*1 elseif(QnNOl==5)then self.OverrideTargetPlayer=tonumber(aQs)elseif(QnNOl==6)then
self.IgnoreReservation=AcceptAlternativeBoolean(aQs)elseif(QnNOl==7)then self.ReplaceEntity=AcceptAlternativeBoolean(aQs)end end
function b_Reward_SendCart:CustomFunction(uow_0tb)if
not IsExisting(self.ScriptNameEntity)then return false end
local tykg=SendCart(self.ScriptNameEntity,self.PlayerID,Goods[self.GoodType],self.GoodAmount,Entities[self.UnitKey],self.IgnoreReservation)
if self.ReplaceEntity and
Logic.IsBuilding(GetID(self.ScriptNameEntity))==0 then
DestroyEntity(self.ScriptNameEntity)Logic.SetEntityName(tykg,self.ScriptNameEntity)end;if self.OverrideTargetPlayer then
Logic.ResourceMerchant_OverrideTargetPlayerID(tykg,self.OverrideTargetPlayer)end end
function b_Reward_SendCart:GetCustomData(C_pPyW)local mgb4b={}
if C_pPyW==2 then
mgb4b={"U_ResourceMerchant","U_Medicus","U_Marketer","U_ThiefCart","U_GoldCart","U_Noblemen_Cart","U_RegaliaCart"}elseif C_pPyW==3 then
for LOBqxO,m8 in pairs(Goods)do if string.find(LOBqxO,"^G_")then
table.insert(mgb4b,LOBqxO)end end;table.sort(mgb4b)elseif C_pPyW==5 then table.insert(mgb4b,"-")for mcoAHO=1,8 do
table.insert(mgb4b,mcoAHO)end elseif C_pPyW==6 then table.insert(mgb4b,"false")
table.insert(mgb4b,"true")elseif C_pPyW==7 then table.insert(mgb4b,"false")
table.insert(mgb4b,"true")end;return mgb4b end
function b_Reward_SendCart:DEBUG(d3gFWO)
if not IsExisting(self.ScriptNameEntity)then
dbg(
d3gFWO.Identifier.." "..self.Name..": spawnpoint does not exist!")return true elseif
not tonumber(self.PlayerID)or self.PlayerID<1 or self.PlayerID>8 then
dbg(d3gFWO.Identifier.." "..self.Name..
": got a invalid playerID!")return true elseif not Entities[self.UnitKey]then
dbg(d3gFWO.Identifier.." "..
self.Name..": entity type '"..
self.UnitKey.."' is invalid!")return true elseif not Goods[self.GoodType]then
dbg(d3gFWO.Identifier.." "..
self.Name..": good type '"..
self.GoodType.."' is invalid!")return true elseif
not tonumber(self.GoodAmount)or self.GoodAmount<1 then
dbg(d3gFWO.Identifier..
" "..self.Name..": good amount can not be below 1!")return true elseif
tonumber(self.OverrideTargetPlayer)and(self.OverrideTargetPlayer<1 or
self.OverrideTargetPlayer>8)then
dbg(d3gFWO.Identifier.." "..
self.Name..": overwrite target player with invalid playerID!")return true end;return false end;Core:RegisterBehavior(b_Reward_SendCart)function Reward_Units(...)return
b_Reward_Units:new(...)end
b_Reward_Units={Name="Reward_Units",Description={en="Reward: Units",de="Lohn: Einheiten"},Parameter={{ParameterType.Entity,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"}}}
function b_Reward_Units:AddParameter(D,obodPKnu)if(D==0)then self.EntityName=obodPKnu elseif(D==1)then
self.Amount=obodPKnu*1 end end
function b_Reward_Units:GetRewardTable()return
{Reward.Units,assert(Entities[self.EntityName]),self.Amount}end;Core:RegisterBehavior(b_Reward_Units)function Reward_QuestRestart(...)return
b_Reward_QuestRestart:new(...)end
b_Reward_QuestRestart=API.InstanceTable(b_Reprisal_QuestRestart)b_Reward_QuestRestart.Name="Reward_ReplaceEntity"
b_Reward_QuestRestart.Description.en="Reward: Restarts a (completed) quest so it can be triggered and completed again."
b_Reward_QuestRestart.Description.de="Lohn: Startet eine (beendete) Quest neu, damit diese neu ausgelöst und beendet werden kann."b_Reward_QuestRestart.GetReprisalTable=nil
b_Reward_QuestRestart.GetRewardTable=function(kgdzk,oVSp)return
{Reward.Custom,{kgdzk,kgdzk.CustomFunction}}end;Core:RegisterBehavior(b_Reward_QuestRestart)function Reward_QuestFailure(...)return
b_Reward_QuestFailure:new(...)end
b_Reward_QuestFailure=API.InstanceTable(b_Reprisal_ReplaceEntity)b_Reward_QuestFailure.Name="Reward_QuestFailure"
b_Reward_QuestFailure.Description.en="Reward: Lets another active quest fail."
b_Reward_QuestFailure.Description.de="Lohn: Lässt eine andere aktive Quest fehlschlagen."b_Reward_QuestFailure.GetReprisalTable=nil
b_Reward_QuestFailure.GetRewardTable=function(uBJ,A)return
{Reward.Custom,{uBJ,uBJ.CustomFunction}}end;Core:RegisterBehavior(b_Reward_QuestFailure)function Reward_QuestSuccess(...)return
b_Reward_QuestSuccess:new(...)end
b_Reward_QuestSuccess=API.InstanceTable(b_Reprisal_QuestSuccess)b_Reward_QuestSuccess.Name="Reward_QuestSuccess"
b_Reward_QuestSuccess.Description.en="Reward: Completes another active quest successfully."
b_Reward_QuestSuccess.Description.de="Lohn: Beendet eine andere aktive Quest erfolgreich."b_Reward_QuestSuccess.GetReprisalTable=nil
b_Reward_QuestSuccess.GetRewardTable=function(MP,jb)return
{Reward.Custom,{MP,MP.CustomFunction}}end;Core:RegisterBehavior(b_Reward_QuestSuccess)function Reward_QuestActivate(...)return
b_Reward_QuestActivate:new(...)end
b_Reward_QuestActivate=API.InstanceTable(b_Reprisal_QuestActivate)b_Reward_QuestActivate.Name="Reward_QuestActivate"
b_Reward_QuestActivate.Description.en="Reward: Activates another quest that is not triggered yet."
b_Reward_QuestActivate.Description.de="Lohn: Aktiviert eine andere Quest die noch nicht ausgelöst wurde."b_Reward_QuestActivate.GetReprisalTable=nil
b_Reward_QuestActivate.GetRewardTable=function(u,KSj)return
{Reward.Custom,{u,u.CustomFunction}}end;Core:RegisterBehavior(b_Reward_QuestActivate)function Reward_QuestInterrupt(...)return
b_Reward_QuestInterrupt:new(...)end
b_Reward_QuestInterrupt=API.InstanceTable(b_Reprisal_QuestInterrupt)b_Reward_QuestInterrupt.Name="Reward_QuestInterrupt"
b_Reward_QuestInterrupt.Description.en="Reward: Interrupts another active quest without success or failure."
b_Reward_QuestInterrupt.Description.de="Lohn: Beendet eine andere aktive Quest ohne Erfolg oder Misserfolg."b_Reward_QuestInterrupt.GetReprisalTable=nil
b_Reward_QuestInterrupt.GetRewardTable=function(YXgXQB,bvL1X4)return
{Reward.Custom,{YXgXQB,YXgXQB.CustomFunction}}end;Core:RegisterBehavior(b_Reward_QuestInterrupt)function Reward_QuestForceInterrupt(...)return
b_Reward_QuestForceInterrupt:new(...)end
b_Reward_QuestForceInterrupt=API.InstanceTable(b_Reprisal_QuestForceInterrupt)
b_Reward_QuestForceInterrupt.Name="Reward_QuestForceInterrupt"
b_Reward_QuestForceInterrupt.Description.en="Reward: Interrupts another quest (even when it isn't active yet) without success or failure."
b_Reward_QuestForceInterrupt.Description.de="Lohn: Beendet eine andere Quest, auch wenn diese noch nicht aktiv ist ohne Erfolg oder Misserfolg."b_Reward_QuestForceInterrupt.GetReprisalTable=nil
b_Reward_QuestForceInterrupt.GetRewardTable=function(PPNahh,z2g)return
{Reward.Custom,{PPNahh,PPNahh.CustomFunction}}end
Core:RegisterBehavior(b_Reward_QuestForceInterrupt)function Reward_MapScriptFunction(...)
return b_Reward_MapScriptFunction:new(...)end
b_Reward_MapScriptFunction=API.InstanceTable(b_Reprisal_MapScriptFunction)b_Reward_MapScriptFunction.Name="Reprisal_MapScriptFunction"
b_Reward_MapScriptFunction.Description.en="Reward: Calls a function within the global map script if the quest has failed."
b_Reward_MapScriptFunction.Description.de="Lohn: Ruft eine Funktion im globalen Kartenskript auf, wenn die Quest fehlschlägt."b_Reward_MapScriptFunction.GetReprisalTable=nil
b_Reward_MapScriptFunction.GetRewardTable=function(m9JTkVv6,Q)return
{Reward.Custom,{m9JTkVv6,m9JTkVv6.CustomFunction}}end;Core:RegisterBehavior(b_Reward_MapScriptFunction)function Reward_CustomVariables(...)return
b_Reward_CustomVariables:new(...)end
b_Reward_CustomVariables=API.InstanceTable(b_Reprisal_CustomVariables)b_Reward_CustomVariables.Name="Reward_CustomVariables"
b_Reward_CustomVariables.Description.en="Reward: Executes a mathematical operation with this variable. The other operand can be a number or another custom variable."
b_Reward_CustomVariables.Description.de="Lohn: Fuehrt eine mathematische Operation mit der Variable aus. Der andere Operand kann eine Zahl oder eine Custom-Varible sein."b_Reward_CustomVariables.GetReprisalTable=nil
b_Reward_CustomVariables.GetRewardTable=function(bWkP,JtFj)return
{Reward.Custom,{bWkP,bWkP.CustomFunction}}end;Core:RegisterBehavior(b_Reward_CustomVariables)function Reward_Technology(...)return
b_Reward_Technology:new(...)end
b_Reward_Technology=API.InstanceTable(b_Reprisal_Technology)b_Reward_Technology.Name="Reward_Technology"
b_Reward_Technology.Description.en="Reward: Locks or unlocks a technology for the given player."
b_Reward_Technology.Description.de="Lohn: Sperrt oder erlaubt eine Technolgie fuer den angegebenen Player."b_Reward_Technology.GetReprisalTable=nil
b_Reward_Technology.GetRewardTable=function(PQ3,_xCtN)return
{Reward.Custom,{PQ3,PQ3.CustomFunction}}end;Core:RegisterBehavior(b_Reward_Technology)function Reward_PrestigePoints(...)return
b_Reward_PrestigePoints:mew(...)end
b_Reward_PrestigePoints={Name="Reward_PrestigePoints",Description={en="Reward: Prestige",de="Lohn: Prestige"},Parameter={{ParameterType.Number,en="Points",de="Punkte"}}}function b_Reward_PrestigePoints:AddParameter(JVpe,nG36XmZC)
if(JVpe==0)then self.Points=nG36XmZC end end;function b_Reward_PrestigePoints:GetRewardTable()return
{Reward.PrestigePoints,self.Points}end
Core:RegisterBehavior(b_Reward_PrestigePoints)
function Reward_AI_MountOutpost(...)return b_Reward_AI_MountOutpost:new(...)end
b_Reward_AI_MountOutpost={Name="Reward_AI_MountOutpost",Description={en="Reward: Places a troop of soldiers on a named outpost.",de="Lohn: Platziert einen Trupp Soldaten auf einem Aussenposten der KI."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Soldiers type",de="Soldatentyp"}}}
function b_Reward_AI_MountOutpost:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_MountOutpost:AddParameter(Vf26,xUGt)if Vf26 ==0 then self.Scriptname=xUGt else
self.SoldiersType=xUGt end end
function b_Reward_AI_MountOutpost:CustomFunction(_U)
local hkI39=assert(not
Logic.IsEntityDestroyed(self.Scriptname)and GetID(self.Scriptname),
_U.Identifier..
": Error in "..self.Name..": CustomFunction: Outpost is invalid")local MwwN=Logic.EntityGetPlayer(hkI39)
local oZ9,OXlT0=Logic.GetBuildingApproachPosition(hkI39)
local V=Logic.CreateBattalionOnUnblockedLand(Entities[self.SoldiersType],oZ9,OXlT0,0,MwwN,0)AICore.HideEntityFromAI(MwwN,V,true)
Logic.CommandEntityToMountBuilding(V,hkI39)end
function b_Reward_AI_MountOutpost:GetCustomData(zIYNIXy1)
if zIYNIXy1 ==1 then local c={}
for mReHt4h,I7 in pairs(Entities)do
if


string.find(mReHt4h,"U_MilitaryBandit")or string.find(mReHt4h,"U_MilitarySword")or string.find(mReHt4h,"U_MilitaryBow")then c[#c+1]=mReHt4h end end;return c end end
function b_Reward_AI_MountOutpost:DEBUG(Upw)
if Logic.IsEntityDestroyed(self.Scriptname)then
dbg(
Upw.Identifier.." "..
self.Name..": Outpost "..self.Scriptname.." is missing")return true end end;Core:RegisterBehavior(b_Reward_AI_MountOutpost)function Reward_QuestRestartForceActive(...)return
b_Reward_QuestRestartForceActive:new(...)end
b_Reward_QuestRestartForceActive={Name="Reward_QuestRestartForceActive",Description={en="Reward: Restarts a (completed) quest and triggers it immediately.",de="Lohn: Startet eine (beendete) Quest neu und triggert sie sofort."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reward_QuestRestartForceActive:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_QuestRestartForceActive:AddParameter(nqBfKL,gs3a)
assert(nqBfKL==0,"Error in "..self.Name..
": AddParameter: Index is invalid.")self.QuestName=gs3a end
function b_Reward_QuestRestartForceActive:CustomFunction(AkKaBC)
local OmRH8,GY=self:ResetQuest(AkKaBC)if OmRH8 then GY:SetMsgKeyOverride()GY:SetIconOverride()
GY:Trigger()end end
b_Reward_QuestRestartForceActive.ResetQuest=b_Reward_QuestRestart.CustomFunction
function b_Reward_QuestRestartForceActive:DEBUG(oukM79R)
if not
Quests[GetQuestID(self.QuestName)]then
dbg(oukM79R.Identifier..
": Error in "..self.Name..": Quest: "..
self.QuestName.." does not exist")return true end end
Core:RegisterBehavior(b_Reward_QuestRestartForceActive)
function Reward_UpgradeBuilding(...)return b_Reward_UpgradeBuilding:new(...)end
b_Reward_UpgradeBuilding={Name="Reward_UpgradeBuilding",Description={en="Reward: Upgrades a building",de="Lohn: Baut ein Gebäude aus"},Parameter={{ParameterType.ScriptName,en="Building",de="Gebäude"}}}
function b_Reward_UpgradeBuilding:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function b_Reward_UpgradeBuilding:AddParameter(D_j,mZPe4w)
if D_j==0 then self.Building=mZPe4w end end
function b_Reward_UpgradeBuilding:CustomFunction(OvZ)
local cBOpf=GetID(self.Building)
if cBOpf~=0 and Logic.IsBuilding(cBOpf)==1 and
Logic.IsBuildingUpgradable(cBOpf,true)and
Logic.IsBuildingUpgradable(cBOpf,false)then
Logic.UpgradeBuilding(cBOpf)end end
function b_Reward_UpgradeBuilding:DEBUG(KZYA5y)local YoCAN7OU=GetID(self.Building)
if not
(
YoCAN7OU~=0 and Logic.IsBuilding(YoCAN7OU)==1 and
Logic.IsBuildingUpgradable(YoCAN7OU,true)and
Logic.IsBuildingUpgradable(YoCAN7OU,false))then
dbg(
KZYA5y.Identifier.." "..self.Name..": Building is wrong")return true end end;Core:RegisterBehavior(b_Reward_UpgradeBuilding)function Trigger_PlayerDiscovered(...)return
b_Trigger_PlayerDiscovered:new(...)end
b_Trigger_PlayerDiscovered={Name="Trigger_PlayerDiscovered",Description={en="Trigger: if a given player has been discovered",de="Auslöser: wenn ein angegebener Spieler entdeckt wurde"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function b_Trigger_PlayerDiscovered:GetTriggerTable(FoP)return
{Triggers.PlayerDiscovered,self.PlayerID}end;function b_Trigger_PlayerDiscovered:AddParameter(jqtWXY,XgRb)
if(jqtWXY==0)then self.PlayerID=XgRb*1 end end
Core:RegisterBehavior(b_Trigger_PlayerDiscovered)
function Trigger_OnDiplomacy(...)return b_Trigger_OnDiplomacy:new(...)end
b_Trigger_OnDiplomacy={Name="Trigger_OnDiplomacy",Description={en="Trigger: if diplomatic relations have been established with a player",de="Auslöser: wenn ein angegebener Diplomatie-Status mit einem Spieler erreicht wurde."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.DiplomacyState,en="Relation",de="Beziehung"}}}
function b_Trigger_OnDiplomacy:GetTriggerTable(G3e)return
{Triggers.Diplomacy,self.PlayerID,assert(DiplomacyStates[self.DiplState])}end
function b_Trigger_OnDiplomacy:AddParameter(GoP6,cZ_)if(GoP6 ==0)then self.PlayerID=cZ_*1 elseif(GoP6 ==1)then
self.DiplState=cZ_ end end;Core:RegisterBehavior(b_Trigger_OnDiplomacy)function Trigger_OnNeedUnsatisfied(...)return
b_Trigger_OnNeedUnsatisfied:new(...)end
b_Trigger_OnNeedUnsatisfied={Name="Trigger_OnNeedUnsatisfied",Description={en="Trigger: if a specified need is unsatisfied",de="Auslöser: wenn ein bestimmtes Beduerfnis nicht befriedigt ist."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Need,en="Need",de="Beduerfnis"},{ParameterType.Number,en="Workers on strike",de="Streikende Arbeiter"}}}
function b_Trigger_OnNeedUnsatisfied:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnNeedUnsatisfied:AddParameter(NYc8,Dff8)
if(NYc8 ==0)then self.PlayerID=Dff8*1 elseif
(NYc8 ==1)then self.Need=Dff8 elseif(NYc8 ==2)then self.WorkersOnStrike=Dff8*1 end end
function b_Trigger_OnNeedUnsatisfied:CustomFunction(lEYwsOG9)
return
Logic.GetNumberOfStrikingWorkersPerNeed(self.PlayerID,Needs[self.Need])>=self.WorkersOnStrike end
function b_Trigger_OnNeedUnsatisfied:DEBUG(M)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
dbg(M.Identifier.." "..
self.Name..": "..self.PlayerID.." does not exist.")return true elseif not Needs[self.Need]then
dbg(M.Identifier.." "..self.Name..": "..
self.Need.." does not exist.")return true elseif self.WorkersOnStrike<0 then
dbg(M.Identifier.." "..
self.Name..": WorkersOnStrike value negative")return true end;return false end
Core:RegisterBehavior(b_Trigger_OnNeedUnsatisfied)function Trigger_OnResourceDepleted(...)
return b_Trigger_OnResourceDepleted:new(...)end
b_Trigger_OnResourceDepleted={Name="Trigger_OnResourceDepleted",Description={en="Trigger: if a resource is (temporarily) depleted",de="Auslöser: wenn eine Ressource (zeitweilig) verbraucht ist"},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}
function b_Trigger_OnResourceDepleted:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function b_Trigger_OnResourceDepleted:AddParameter(Vt95q2G,jsPbwU)
if(Vt95q2G==0)then self.ScriptName=jsPbwU end end
function b_Trigger_OnResourceDepleted:CustomFunction(Wvs3rd6o)
local UdVlP=GetID(self.ScriptName)
return not UdVlP or UdVlP==0 or
Logic.GetResourceDoodadGoodType(UdVlP)==0 or
Logic.GetResourceDoodadGoodAmount(UdVlP)==0 end
Core:RegisterBehavior(b_Trigger_OnResourceDepleted)function Trigger_OnAmountOfGoods(...)
return b_Trigger_OnAmountOfGoods:new(...)end
b_Trigger_OnAmountOfGoods={Name="Trigger_OnAmountOfGoods",Description={en="Trigger: if the player has gathered a given amount of resources in his storehouse",de="Auslöser: wenn der Spieler eine bestimmte Menge einer Ressource in seinem Lagerhaus hat"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.RawGoods,en="Type of good",de="Resourcentyp"},{ParameterType.Number,en="Amount of good",de="Anzahl der Resource"}}}
function b_Trigger_OnAmountOfGoods:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnAmountOfGoods:AddParameter(N,v9mB_RUi)
if(N==0)then self.PlayerID=v9mB_RUi*1 elseif(N==1)then
self.GoodTypeName=v9mB_RUi elseif(N==2)then self.GoodAmount=v9mB_RUi*1 end end
function b_Trigger_OnAmountOfGoods:CustomFunction(hX)
local AVU=Logic.GetStoreHouse(self.PlayerID)if(AVU==0)then return false end
local I=Logic.GetGoodTypeID(self.GoodTypeName)local _x5O1=Logic.GetAmountOnOutStockByGoodType(AVU,I)if(_x5O1 >=
self.GoodAmount)then return true end;return false end
function b_Trigger_OnAmountOfGoods:DEBUG(eFI8dI3)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
dbg(eFI8dI3.Identifier.." "..self.Name..
": "..self.PlayerID.." does not exist.")return true elseif not Goods[self.GoodTypeName]then
dbg(eFI8dI3.Identifier.." "..self.Name..
": Good type is wrong.")return true elseif self.GoodAmount<0 then
dbg(eFI8dI3.Identifier.." "..
self.Name..": Good amount is negative.")return true end;return false end;Core:RegisterBehavior(b_Trigger_OnAmountOfGoods)function Trigger_OnQuestActive(...)return
b_Trigger_OnQuestActive:new(...)end
b_Trigger_OnQuestActive={Name="Trigger_OnQuestActive",Description={en="Trigger: if a given quest has been activated. Waiting time optional",de="Auslöser: wenn eine angegebene Quest aktiviert wurde. Optional mit Wartezeit"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function b_Trigger_OnQuestActive:GetTriggerTable(i)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnQuestActive:AddParameter(l6xUetCb,lOb_Sv)if(l6xUetCb==0)then self.QuestName=lOb_Sv elseif
(l6xUetCb==1)then
self.WaitTime=(lOb_Sv~=nil and tonumber(lOb_Sv))or 0 end end
function b_Trigger_OnQuestActive:CustomFunction(VspvGB9V)
local LrFLp5=GetQuestID(self.QuestName)
if LrFLp5 ~=nil then assert(type(LrFLp5)=="number")
if(
Quests[LrFLp5].State==QuestState.Active)then self.WasActivated=
self.WasActivated or true end
if self.WasActivated then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end end;return false end
function b_Trigger_OnQuestActive:DEBUG(GfB7)
if type(self.QuestName)~="string"then
dbg(""..

GfB7.Identifier.." "..self.Name..": invalid quest name!")return true elseif type(self.WaitTime)~="number"then
dbg(""..
GfB7.Identifier.." "..self.Name..
": waitTime must be a number!")return true end;return false end;function b_Trigger_OnQuestActive:Interrupt()end
function b_Trigger_OnQuestActive:Reset()self.WaitTimeTimer=
nil;self.WasActivated=nil end;Core:RegisterBehavior(b_Trigger_OnQuestActive)function Trigger_OnQuestFailure(...)return
b_Trigger_OnQuestFailure:new(...)end
b_Trigger_OnQuestFailure={Name="Trigger_OnQuestFailure",Description={en="Trigger: if a given quest has failed. Waiting time optional",de="Auslöser: wenn eine angegebene Quest fehlgeschlagen ist. Optional mit Wartezeit"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function b_Trigger_OnQuestFailure:GetTriggerTable(Iz_w1j)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnQuestFailure:AddParameter(G,X7YKzX)if(G==0)then self.QuestName=X7YKzX elseif(G==1)then
self.WaitTime=(
X7YKzX~=nil and tonumber(X7YKzX))or 0 end end
function b_Trigger_OnQuestFailure:CustomFunction(od0VOF)
if
(GetQuestID(self.QuestName)~=nil)then local oO6SbZ=GetQuestID(self.QuestName)
if(Quests[oO6SbZ].Result==
QuestResult.Failure)then
if
self.WaitTime and self.WaitTime>0 then
self.WaitTimeTimer=self.WaitTimeTimer or Logic.GetTime()if
Logic.GetTime()>=self.WaitTimeTimer+self.WaitTime then return true end else return true end end end;return false end
function b_Trigger_OnQuestFailure:DEBUG(UE_vrsNx)
if type(self.QuestName)~="string"then
dbg(""..

UE_vrsNx.Identifier.." "..self.Name..": invalid quest name!")return true elseif type(self.WaitTime)~="number"then
dbg(""..
UE_vrsNx.Identifier.." "..self.Name..
": waitTime must be a number!")return true end;return false end
function b_Trigger_OnQuestFailure:Interrupt()self.WaitTimeTimer=nil end
function b_Trigger_OnQuestFailure:Reset()self.WaitTimeTimer=nil end;Core:RegisterBehavior(b_Trigger_OnQuestFailure)function Trigger_OnQuestNotTriggered(...)return
b_Trigger_OnQuestNotTriggered:new(...)end
b_Trigger_OnQuestNotTriggered={Name="Trigger_OnQuestNotTriggered",Description={en="Trigger: if a given quest is not yet active. Should be used in combination with other triggers.",de="Auslöser: wenn eine angegebene Quest noch inaktiv ist. Sollte mit weiteren Triggern kombiniert werden."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Trigger_OnQuestNotTriggered:GetTriggerTable(kef2zBS)return
{Triggers.Custom2,{self,self.CustomFunction}}end;function b_Trigger_OnQuestNotTriggered:AddParameter(Z,ze0)
if(Z==0)then self.QuestName=ze0 end end
function b_Trigger_OnQuestNotTriggered:CustomFunction(y)
if(
GetQuestID(self.QuestName)~=nil)then
local lW3uC0=GetQuestID(self.QuestName)if
(Quests[lW3uC0].State==QuestState.NotTriggered)then return true end end;return false end
function b_Trigger_OnQuestNotTriggered:DEBUG(N_G1)if type(self.QuestName)~="string"then
dbg(""..

N_G1.Identifier.." "..self.Name..": invalid quest name!")return true end
return false end
Core:RegisterBehavior(b_Trigger_OnQuestNotTriggered)function Trigger_OnQuestInterrupted(...)
return b_Trigger_OnQuestInterrupted:new(...)end
b_Trigger_OnQuestInterrupted={Name="Trigger_OnQuestInterrupted",Description={en="Trigger: if a given quest has been interrupted. Should be used in combination with other triggers.",de="Auslöser: wenn eine angegebene Quest abgebrochen wurde. Sollte mit weiteren Triggern kombiniert werden."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function b_Trigger_OnQuestInterrupted:GetTriggerTable(wkGNE)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnQuestInterrupted:AddParameter(ccK,BV)if(ccK==0)then self.QuestName=BV elseif(ccK==1)then
self.WaitTime=(
BV~=nil and tonumber(BV))or 0 end end
function b_Trigger_OnQuestInterrupted:CustomFunction(HnLY)
if
(GetQuestID(self.QuestName)~=nil)then local cm51CH1n=GetQuestID(self.QuestName)
if
(Quests[cm51CH1n].State==
QuestState.Over and
Quests[cm51CH1n].Result==QuestResult.Interrupted)then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end end;return false end
function b_Trigger_OnQuestInterrupted:DEBUG(iWrSgT)
if type(self.QuestName)~="string"then
dbg(""..

iWrSgT.Identifier.." "..self.Name..": invalid quest name!")return true elseif type(self.WaitTime)~="number"then
dbg(""..
iWrSgT.Identifier.." "..self.Name..
": waitTime must be a number!")return true end;return false end
function b_Trigger_OnQuestInterrupted:Interrupt()self.WaitTimeTimer=nil end
function b_Trigger_OnQuestInterrupted:Reset()self.WaitTimeTimer=nil end
Core:RegisterBehavior(b_Trigger_OnQuestInterrupted)
function Trigger_OnQuestOver(...)return b_Trigger_OnQuestOver:new(...)end
b_Trigger_OnQuestOver={Name="Trigger_OnQuestOver",Description={en="Trigger: if a given quest has been finished, regardless of its result. Waiting time optional",de="Auslöser: wenn eine angegebene Quest beendet wurde, unabhängig von deren Ergebnis. Wartezeit optional"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function b_Trigger_OnQuestOver:GetTriggerTable(C)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnQuestOver:AddParameter(YK1,t96Qtz)if(YK1 ==0)then self.QuestName=t96Qtz elseif(YK1 ==1)then
self.WaitTime=(
t96Qtz~=nil and tonumber(t96Qtz))or 0 end end
function b_Trigger_OnQuestOver:CustomFunction(HjKNi)
if
(GetQuestID(self.QuestName)~=nil)then local Ub9iqg=GetQuestID(self.QuestName)
if
(Quests[Ub9iqg].State==
QuestState.Over and
Quests[Ub9iqg].Result~=QuestResult.Interrupted)then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end end;return false end
function b_Trigger_OnQuestOver:DEBUG(r_S8HFRo)
if type(self.QuestName)~="string"then
dbg(""..

r_S8HFRo.Identifier.." "..self.Name..": invalid quest name!")return true elseif type(self.WaitTime)~="number"then
dbg(""..
r_S8HFRo.Identifier.." "..self.Name..
": waitTime must be a number!")return true end;return false end
function b_Trigger_OnQuestOver:Interrupt()self.WaitTimeTimer=nil end
function b_Trigger_OnQuestOver:Reset()self.WaitTimeTimer=nil end;Core:RegisterBehavior(b_Trigger_OnQuestOver)function Trigger_OnQuestSuccess(...)return
b_Trigger_OnQuestSuccess:new(...)end
b_Trigger_OnQuestSuccess={Name="Trigger_OnQuestSuccess",Description={en="Trigger: if a given quest has been finished successfully. Waiting time optional",de="Auslöser: wenn eine angegebene Quest erfolgreich abgeschlossen wurde. Wartezeit optional"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function b_Trigger_OnQuestSuccess:GetTriggerTable(qIF4RFBv)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnQuestSuccess:AddParameter(wNbC65Ta,xOiPW)if(wNbC65Ta==0)then self.QuestName=xOiPW elseif
(wNbC65Ta==1)then
self.WaitTime=(xOiPW~=nil and tonumber(xOiPW))or 0 end end
function b_Trigger_OnQuestSuccess:CustomFunction()
if
(GetQuestID(self.QuestName)~=nil)then local Z9j=GetQuestID(self.QuestName)
if(Quests[Z9j].Result==
QuestResult.Success)then
if
self.WaitTime and self.WaitTime>0 then
self.WaitTimeTimer=self.WaitTimeTimer or Logic.GetTime()if
Logic.GetTime()>=self.WaitTimeTimer+self.WaitTime then return true end else return true end end end;return false end
function b_Trigger_OnQuestSuccess:DEBUG(r)
if type(self.QuestName)~="string"then
dbg(""..

r.Identifier.." "..self.Name..": invalid quest name!")return true elseif type(self.WaitTime)~="number"then
dbg(""..r.Identifier.." "..self.Name..
": waittime must be a number!")return true end;return false end
function b_Trigger_OnQuestSuccess:Interrupt()self.WaitTimeTimer=nil end
function b_Trigger_OnQuestSuccess:Reset()self.WaitTimeTimer=nil end;Core:RegisterBehavior(b_Trigger_OnQuestSuccess)function Trigger_CustomVariables(...)return
b_Trigger_CustomVariables:new(...)end
b_Trigger_CustomVariables={Name="Trigger_CustomVariables",Description={en="Trigger: if the variable has a certain value.",de="Auslöser: wenn die Variable einen bestimmen Wert eingenommen hat."},Parameter={{ParameterType.Default,en="Name of Variable",de="Variablennamen"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Default,en="Value",de="Wert"}}}
function b_Trigger_CustomVariables:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_CustomVariables:AddParameter(O,nJ1)
if O==0 then self.VariableName=nJ1 elseif O==1 then
self.Relation=nJ1 elseif O==2 then local KFU0=tonumber(nJ1)
KFU0=(KFU0 ~=nil and KFU0)or nJ1;self.Value=KFU0 end end
function b_Trigger_CustomVariables:CustomFunction()
if
_G["QSB_CustomVariables_"..self.VariableName]~=nil then
if self.Relation=="=="then
return
_G["QSB_CustomVariables_"..self.VariableName]==
(
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value])elseif self.Relation~="~="then
return
_G["QSB_CustomVariables_"..self.VariableName]~=
(
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value])elseif self.Relation==">"then
return
_G["QSB_CustomVariables_"..self.VariableName]>
(
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value])elseif self.Relation==">="then
return
_G["QSB_CustomVariables_"..self.VariableName]>=
(
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value])elseif self.Relation=="<="then
return
_G["QSB_CustomVariables_"..self.VariableName]<=
(
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value])else
return _G["QSB_CustomVariables_"..self.VariableName]<
((
type(self.Value)~="string"and self.Value)or _G[
"QSB_CustomVariables_"..self.Value])end end;return false end
function b_Trigger_CustomVariables:GetCustomData(Pvuq)if Pvuq==1 then
return{"==","~=","<=","<",">",">="}end end
function b_Trigger_CustomVariables:DEBUG(lOpDJ)local YLe={"==","~=","<=","<",">",">="}local lTH={true,false,
nil}
if not
_G["QSB_CustomVariables_"..self.VariableName]then
dbg(lOpDJ.Identifier..
" "..self.Name..": variable '"..
self.VariableName.."' do not exist!")return true elseif not Inside(self.Relation,YLe)then
dbg(lOpDJ.Identifier.." "..
self.Name..": '"..
self.Relation.."' is an invalid relation!")return true end;return false end;Core:RegisterBehavior(b_Trigger_CustomVariables)function Trigger_AlwaysActive()return
b_Trigger_AlwaysActive:new()end
b_Trigger_AlwaysActive={Name="Trigger_AlwaysActive",Description={en="Trigger: the map has been started.",de="Auslöser: Start der Karte."}}
function b_Trigger_AlwaysActive:GetTriggerTable(JL)return{Triggers.Time,0}end;Core:RegisterBehavior(b_Trigger_AlwaysActive)function Trigger_OnMonth(...)return
b_Trigger_OnMonth:new(...)end
b_Trigger_OnMonth={Name="Trigger_OnMonth",Description={en="Trigger: a specified month",de="Auslöser: ein bestimmter Monat"},Parameter={{ParameterType.Custom,en="Month",de="Monat"}}}
function b_Trigger_OnMonth:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function b_Trigger_OnMonth:AddParameter(FpU_E,JWtwnQ2t)
if(FpU_E==0)then self.Month=JWtwnQ2t*1 end end
function b_Trigger_OnMonth:CustomFunction(u)return
self.Month==Logic.GetCurrentMonth()end
function b_Trigger_OnMonth:GetCustomData(EKPPpj_)local aYO4NN={}
if EKPPpj_==0 then for CtG9nSQL=1,12 do
table.insert(aYO4NN,CtG9nSQL)end else assert(false)end;return aYO4NN end
function b_Trigger_OnMonth:DEBUG(uZtK5yX)if self.Month<1 or self.Month>12 then
dbg(
uZtK5yX.Identifier.." "..self.Name..": Month has the wrong value")return true end
return false end;Core:RegisterBehavior(b_Trigger_OnMonth)function Trigger_OnMonsoon()return
b_Trigger_OnMonsoon:new()end
b_Trigger_OnMonsoon={Name="Trigger_OnMonsoon",Description={en="Trigger: on monsoon.",de="Auslöser: wenn der Monsun beginnt."},RequiresExtraNo=1}
function b_Trigger_OnMonsoon:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnMonsoon:CustomFunction(kr2CYaS)if Logic.GetWeatherDoesShallowWaterFlood(0)then
return true end end;Core:RegisterBehavior(b_Trigger_OnMonsoon)function Trigger_Time(...)return
b_Trigger_Time:new(...)end
b_Trigger_Time={Name="Trigger_Time",Description={en="Trigger: a given amount of time since map start",de="Auslöser: eine gewisse Anzahl Sekunden nach Spielbeginn"},Parameter={{ParameterType.Number,en="Time (sec.)",de="Zeit (Sek.)"}}}
function b_Trigger_Time:GetTriggerTable(hXgSzEI)return{Triggers.Time,self.Time}end
function b_Trigger_Time:AddParameter(AUQ,B)if(AUQ==0)then self.Time=B*1 end end;Core:RegisterBehavior(b_Trigger_Time)function Trigger_OnWaterFreezes()return
b_Trigger_OnWaterFreezes:new()end
b_Trigger_OnWaterFreezes={Name="Trigger_OnWaterFreezes",Description={en="Trigger: if the water starts freezing",de="Auslöser: wenn die Gewässer gefrieren"}}
function b_Trigger_OnWaterFreezes:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function b_Trigger_OnWaterFreezes:CustomFunction(J)
if Logic.GetWeatherDoesWaterFreeze(0)then return true end end
Core:RegisterBehavior(b_Trigger_OnWaterFreezes)
function Trigger_NeverTriggered()return b_Trigger_NeverTriggered:new()end
b_Trigger_NeverTriggered={Name="Trigger_NeverTriggered",Description={en="Never triggers a Quest. The quest may be set active by Reward_QuestActivate or Reward_QuestRestartForceActive",de="Löst nie eine Quest aus. Die Quest kann von Reward_QuestActivate oder Reward_QuestRestartForceActive aktiviert werden."}}function b_Trigger_NeverTriggered:GetTriggerTable()return
{Triggers.Custom2,{self,function()end}}end
Core:RegisterBehavior(b_Trigger_NeverTriggered)function Trigger_OnAtLeastOneQuestFailure(...)
return b_Trigger_OnAtLeastOneQuestFailure:new(...)end
b_Trigger_OnAtLeastOneQuestFailure={Name="Trigger_OnAtLeastOneQuestFailure",Description={en="Trigger: if one or both of the given quests have failed.",de="Auslöser: wenn einer oder beide der angegebenen Aufträge fehlgeschlagen sind."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function b_Trigger_OnAtLeastOneQuestFailure:GetTriggerTable(coSiE)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnAtLeastOneQuestFailure:AddParameter(wm,_)self.QuestTable={}if(wm==0)then
self.Quest1=_ elseif(wm==1)then self.Quest2=_ end end
function b_Trigger_OnAtLeastOneQuestFailure:CustomFunction(O)
local smj=Quests[GetQuestID(self.Quest1)]local obBu=Quests[GetQuestID(self.Quest2)]
if
(smj.State==
QuestState.Over and smj.Result==QuestResult.Failure)or
(obBu.State==QuestState.Over and obBu.Result==QuestResult.Failure)then return true end;return false end
function b_Trigger_OnAtLeastOneQuestFailure:DEBUG(cbQlG)
if self.Quest1 ==self.Quest2 then
dbg(
cbQlG.Identifier..": "..self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
dbg(cbQlG.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
dbg(cbQlG.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Trigger_OnAtLeastOneQuestFailure)function Trigger_OnAtLeastOneQuestSuccess(...)
return b_Trigger_OnAtLeastOneQuestSuccess:new(...)end
b_Trigger_OnAtLeastOneQuestSuccess={Name="Trigger_OnAtLeastOneQuestSuccess",Description={en="Trigger: if one or both of the given quests are won.",de="Auslöser: wenn einer oder beide der angegebenen Aufträge gewonnen wurden."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function b_Trigger_OnAtLeastOneQuestSuccess:GetTriggerTable(YZQu1DR4)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnAtLeastOneQuestSuccess:AddParameter(kza,CvGDk_2)self.QuestTable={}if(kza==0)then
self.Quest1=CvGDk_2 elseif(kza==1)then self.Quest2=CvGDk_2 end end
function b_Trigger_OnAtLeastOneQuestSuccess:CustomFunction(EGpun)
local LNlhK=Quests[GetQuestID(self.Quest1)]local cnx_1g=Quests[GetQuestID(self.Quest2)]
if

(LNlhK.State==
QuestState.Over and LNlhK.Result==QuestResult.Success)or(cnx_1g.State==QuestState.Over and
cnx_1g.Result==QuestResult.Success)then return true end;return false end
function b_Trigger_OnAtLeastOneQuestSuccess:DEBUG(eV)
if self.Quest1 ==self.Quest2 then
dbg(eV.Identifier..
": "..self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
dbg(eV.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
dbg(eV.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Trigger_OnAtLeastOneQuestSuccess)
function Trigger_OnAtLeastXOfYQuestsSuccess(...)return
b_Trigger_OnAtLeastXOfYQuestsSuccess:new(...)end
b_Trigger_OnAtLeastXOfYQuestsSuccess={Name="Trigger_OnAtLeastXOfYQuestsSuccess",Description={en="Trigger: if at least X of Y given quests has been finished successfully.",de="Auslöser: wenn X von Y angegebener Quests erfolgreich abgeschlossen wurden."},Parameter={{ParameterType.Custom,en="Least Amount",de="Mindest Anzahl"},{ParameterType.Custom,en="Quest Amount",de="Quest Anzahl"},{ParameterType.QuestName,en="Quest name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest name 2",de="Questname 2"},{ParameterType.QuestName,en="Quest name 3",de="Questname 3"},{ParameterType.QuestName,en="Quest name 4",de="Questname 4"},{ParameterType.QuestName,en="Quest name 5",de="Questname 5"}}}
function b_Trigger_OnAtLeastXOfYQuestsSuccess:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnAtLeastXOfYQuestsSuccess:AddParameter(DGQnw,yLgHuF)
if(DGQnw==0)then
self.LeastAmount=tonumber(yLgHuF)elseif(DGQnw==1)then self.QuestAmount=tonumber(yLgHuF)elseif(DGQnw==2)then
self.QuestName1=yLgHuF elseif(DGQnw==3)then self.QuestName2=yLgHuF elseif(DGQnw==4)then self.QuestName3=yLgHuF elseif
(DGQnw==5)then self.QuestName4=yLgHuF elseif(DGQnw==6)then self.QuestName5=yLgHuF end end
function b_Trigger_OnAtLeastXOfYQuestsSuccess:CustomFunction()local fpL=0
for k6=1,self.QuestAmount do
local m=GetQuestID(self["QuestName"..k6])if IsValidQuest(m)then
if
(Quests[m].Result==QuestResult.Success)then fpL=fpL+1;if fpL>=self.LeastAmount then return true end end end end;return false end
function b_Trigger_OnAtLeastXOfYQuestsSuccess:DEBUG(rvNhq6v)local gC=self.LeastAmount
local QO=self.QuestAmount
if gC<=0 or gC>5 then
dbg(rvNhq6v.Identifier..
": Error in "..self.Name..": LeastAmount is wrong")return true elseif QO<=0 or QO>5 then
dbg(rvNhq6v.Identifier..": Error in "..
self.Name..": QuestAmount is wrong")return true elseif gC>QO then
dbg(rvNhq6v.Identifier..": Error in "..
self.Name..": LeastAmount is greater than QuestAmount")return true end
for VvzMQHj=1,QO do
if
not IsValidQuest(self["QuestName"..VvzMQHj])then
dbg(rvNhq6v.Identifier..
": Error in "..self.Name..": Quest "..
self["QuestName"..VvzMQHj].." not found")return true end end;return false end
function b_Trigger_OnAtLeastXOfYQuestsSuccess:GetCustomData(fSYJX)if
(fSYJX==0)or(fSYJX==1)then return{"1","2","3","4","5"}end end
Core:RegisterBehavior(b_Trigger_OnAtLeastXOfYQuestsSuccess)function Trigger_MapScriptFunction(...)
return b_Trigger_MapScriptFunction:new(...)end
b_Trigger_MapScriptFunction={Name="Trigger_MapScriptFunction",Description={en="Calls a function within the global map script. If the function returns true the quest will be started",de="Ruft eine Funktion im globalen Skript auf. Wenn sie true sendet, wird die Quest gestartet."},Parameter={{ParameterType.Default,en="Function name",de="Funktionsname"}}}
function b_Trigger_MapScriptFunction:GetTriggerTable(WV)return
{Triggers.Custom2,{self,self.CustomFunction}}end;function b_Trigger_MapScriptFunction:AddParameter(y,Uho4MXRx)
if(y==0)then self.FuncName=Uho4MXRx end end;function b_Trigger_MapScriptFunction:CustomFunction(J2)return
_G[self.FuncName](self,J2)end
function b_Trigger_MapScriptFunction:DEBUG(hgrBfz0w)
if
not self.FuncName or not _G[self.FuncName]then
local Gi=string.format("%s Trigger_MapScriptFunction: function '%s' does not exist!",hgrBfz0w.Identifier,tostring(self.FuncName))dbg(Gi)return true end;return false end
Core:RegisterBehavior(b_Trigger_MapScriptFunction)BundleClassicBehaviors={Global={},Local={}}function BundleClassicBehaviors.Global:Install()
end
function BundleClassicBehaviors.Local:Install()end;Core:RegisterBundle("BundleClassicBehaviors")
API=API or{}QSB=QSB or{}function Goal_MoveToPosition(...)
return b_Goal_MoveToPosition:new(...)end
b_Goal_MoveToPosition={Name="Goal_MoveToPosition",Description={en="Goal: A entity have to moved as close as the distance to another entity. The target can be marked with a static marker.",de="Ziel: Eine Entity muss sich einer anderen bis auf eine bestimmte Distanz nähern. Die Lupe wird angezeigt, das Ziel kann markiert werden."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Number,en="Distance",de="Entfernung"},{ParameterType.Custom,en="Marker",de="Ziel markieren"}}}
function b_Goal_MoveToPosition:GetGoalTable(wpv1)return
{Objective.Distance,self.Entity,self.Target,self.Distance,self.Marker}end
function b_Goal_MoveToPosition:AddParameter(I9IMuWm,a)
if(I9IMuWm==0)then self.Entity=a elseif(I9IMuWm==1)then
self.Target=a elseif(I9IMuWm==2)then self.Distance=a*1 elseif(I9IMuWm==3)then
self.Marker=AcceptAlternativeBoolean(a)end end
function b_Goal_MoveToPosition:GetCustomData(rZ)local VKTNfzUf={}
if rZ==3 then VKTNfzUf={"true","false"}end;return VKTNfzUf end;Core:RegisterBehavior(b_Goal_MoveToPosition)function Goal_WinQuest(...)return
b_Goal_WinQuest:new(...)end
b_Goal_WinQuest={Name="Goal_WinQuest",Description={en="Goal: The player has to win a given quest",de="Ziel: Der Spieler muss eine angegebene Quest erfolgreich abschliessen."},Parameter={{ParameterType.QuestName,en="Quest Name",de="Questname"}}}
function b_Goal_WinQuest:GetGoalTable(Oms4)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_WinQuest:AddParameter(JfA,CPu1)if(JfA==0)then self.Quest=CPu1 end end
function b_Goal_WinQuest:CustomFunction(pfyhF)
local pglFz82w=Quests[GetQuestID(self.Quest)]if pglFz82w then
if pglFz82w.Result==QuestResult.Failure then return false end
if pglFz82w.Result==QuestResult.Success then return true end end
return nil end
function b_Goal_WinQuest:DEBUG(RkeCL)
if
Quests[GetQuestID(self.Quest)]==nil then
dbg(RkeCL.Identifier..": "..self.Name..
": Quest '"..self.Quest.."' does not exist!")return true end;return false end;Core:RegisterBehavior(b_Goal_WinQuest)function Goal_StealGold(...)return
b_Goal_StealGold:new(...)end
b_Goal_StealGold={Name="Goal_StealGold",Description={en="Goal: Steal an explicit amount of gold from a players or any players city buildings.",de="Ziel: Diebe sollen eine bestimmte Menge Gold aus feindlichen Stadtgebäuden stehlen."},Parameter={{ParameterType.Number,en="Amount on Gold",de="Zu stehlende Menge"},{ParameterType.Custom,en="Print progress",de="Fortschritt ausgeben"}}}
function b_Goal_StealGold:GetGoalTable(LoW_7e)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_StealGold:AddParameter(mLgQ,ng)
if(mLgQ==0)then self.Amount=ng*1 elseif(mLgQ==1)then
ng=ng or"true"self.Printout=AcceptAlternativeBoolean(ng)end;self.StohlenGold=0 end;function b_Goal_StealGold:GetCustomData(Pp_NboV)
if Pp_NboV==1 then return{"true","false"}end end
function b_Goal_StealGold:SetDescriptionOverwrite(owAp3u2G)
local OH0C=(
Network.GetDesiredLanguage()=="de"and"de")or"en"local kmQkm9cr=self.Amount-self.StohlenGold;kmQkm9cr=
(kmQkm9cr>0 and kmQkm9cr)or 0
local IE97m={de="Gold stehlen {cr}{cr}Aus Stadtgebäuden zu stehlende Goldmenge: ",en="Steal gold {cr}{cr}Amount on gold to steal from city buildings: "}return"{center}"..IE97m[OH0C]..kmQkm9cr end
function b_Goal_StealGold:CustomFunction(wey)
Core:ChangeCustomQuestCaptionText(wey.Identifier,self:SetDescriptionOverwrite(wey))if self.StohlenGold>=self.Amount then return true end;return nil end;function b_Goal_StealGold:GetIcon()return{5,13}end
function b_Goal_StealGold:DEBUG(hThO6)
if
tonumber(self.Amount)==nil and self.Amount<0 then
dbg(hThO6.Identifier..": "..self.Name..
": amount can not be negative!")return true end;return false end;function b_Goal_StealGold:Reset()self.StohlenGold=0 end
Core:RegisterBehavior(b_Goal_StealGold)
function Goal_StealBuilding(...)return b_Goal_StealBuilding:new(...)end
b_Goal_StealBuilding={Name="Goal_StealBuilding",Description={en="Goal: The player has to steal from a building. Not a castle and not a village storehouse!",de="Ziel: Der Spieler muss ein bestimmtes Gebäude bestehlen. Dies darf keine Burg und kein Dorflagerhaus sein!"},Parameter={{ParameterType.ScriptName,en="Building",de="Gebäude"}}}
function b_Goal_StealBuilding:GetGoalTable(zXU)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_StealBuilding:AddParameter(HmJym2,Jjb7Am5)
if(HmJym2 ==0)then self.Building=Jjb7Am5 end;self.RobberList={}end;function b_Goal_StealBuilding:GetCustomData(UwqY7A)
if UwqY7A==1 then return{"true","false"}end end
function b_Goal_StealBuilding:SetDescriptionOverwrite(k)
local d7gPKcw=
Logic.IsEntityInCategory(GetID(self.Building),EntityCategories.Cathedrals)==1
local naeNp=Logic.GetEntityType(GetID(self.Building))==Entities.B_StoreHouse;local gA=
(Network.GetDesiredLanguage()=="de"and"de")or"en"local r
if d7gPKcw then
r={de="Sabotage {cr}{cr} Sabotiert die mit Pfeil markierte Kirche.",en="Sabotage {cr}{cr} Sabotage the Church of the opponent."}elseif naeNp then
r={de="Lagerhaus bestehlen {cr}{cr} Sendet einen Dieb in das markierte Lagerhaus.",en="Steal from storehouse {cr}{cr} Steal from the marked storehouse."}else
r={de="Geb�ude bestehlen {cr}{cr} Bestehlt das durch einen Pfeil markierte Gebäude.",en="Steal from building {cr}{cr} Steal from the building marked by an arrow."}end;return"{center}"..r[gA]end
function b_Goal_StealBuilding:CustomFunction(LWe)if not IsExisting(self.Building)then
if
self.Marker then Logic.DestroyEffect(self.Marker)end;return false end;if
not self.Marker then local _3Tq=GetPosition(self.Building)
self.Marker=Logic.CreateEffect(EGL_Effects.E_Questmarker,_3Tq.X,_3Tq.Y,0)end
if
self.SuccessfullyStohlen then Logic.DestroyEffect(self.Marker)return true end;return nil end;function b_Goal_StealBuilding:GetIcon()return{5,13}end
function b_Goal_StealBuilding:DEBUG(Rq1hByv)
local iFk=Logic.GetEntityTypeName(Logic.GetEntityType(GetID(self.Building)))
local sEFtmNgB=
Logic.IsEntityInCategory(GetID(self.Building),EntityCategories.Headquarters)==1
if Logic.IsBuilding(GetID(self.Building))==0 then
dbg(
Rq1hByv.Identifier..": "..self.Name..": target is not a building")return true elseif not IsExisting(self.Building)then
dbg(Rq1hByv.Identifier..": "..self.Name..
": target is destroyed :(")return true elseif
string.find(iFk,"B_NPC_BanditsHQ")or
string.find(iFk,"B_NPC_Cloister")or string.find(iFk,"B_NPC_StoreHouse")then
dbg(Rq1hByv.Identifier..
": "..self.Name..": village storehouses are not allowed!")return true elseif sEFtmNgB then
dbg(Rq1hByv.Identifier..": "..
self.Name..": use Goal_StealInformation for headquarters!")return true end;return false end;function b_Goal_StealBuilding:Reset()self.SuccessfullyStohlen=false;self.RobberList={}self.Marker=
nil end;function b_Goal_StealBuilding:Interrupt(qxiez0Cn)
Logic.DestroyEffect(self.Marker)end
Core:RegisterBehavior(b_Goal_StealBuilding)
function Goal_Infiltrate(...)return b_Goal_Infiltrate:new(...)end
b_Goal_Infiltrate={Name="Goal_Infiltrate",IconOverwrite={5,13},Description={en="Goal: Infiltrate a building with a thief. A thief must be able to steal from the target building.",de="Ziel: Infiltriere ein Gebäude mit einem Dieb. Nur mit Gebaueden moeglich, die bestohlen werden koennen."},Parameter={{ParameterType.ScriptName,en="Target Building",de="Zielgebäude"},{ParameterType.Custom,en="Destroy Thief",de="Dieb löschen"}}}
function b_Goal_Infiltrate:GetGoalTable(Ck_H)return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_Infiltrate:AddParameter(Sc,_QFw_It)
if(Sc==0)then self.Building=_QFw_It elseif(Sc==1)then
_QFw_It=_QFw_It or"true"self.Delete=AcceptAlternativeBoolean(_QFw_It)end end;function b_Goal_Infiltrate:GetCustomData(WLqHf)
if WLqHf==1 then return{"true","false"}end end
function b_Goal_Infiltrate:SetDescriptionOverwrite(vN)
if
not vN.QuestDescription then local BIwW6_=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
local Vdfc3={de="Gebäude infriltrieren {cr}{cr}Spioniere das markierte Gebäude mit einem Dieb aus!",en="Infiltrate building {cr}{cr}Spy on the highlighted buildings with a thief!"}return Vdfc3[BIwW6_]else return vN.QuestDescription end end
function b_Goal_Infiltrate:CustomFunction(CzM7PG)
if not IsExisting(self.Building)then if self.Marker then
Logic.DestroyEffect(self.Marker)end;return false end;if not self.Marker then local RKf6s5=GetPosition(self.Building)
self.Marker=Logic.CreateEffect(EGL_Effects.E_Questmarker,RKf6s5.X,RKf6s5.Y,0)end
if
self.Infiltrated then Logic.DestroyEffect(self.Marker)return true end;return nil end
function b_Goal_Infiltrate:GetIcon()return self.IconOverwrite end
function b_Goal_Infiltrate:DEBUG(tP9E_)
if
Logic.IsBuilding(GetID(self.Building))==0 then
dbg(tP9E_.Identifier..
": "..self.Name..": target is not a building")return true elseif not IsExisting(self.Building)then
dbg(tP9E_.Identifier..": "..self.Name..
": target is destroyed :(")return true end;return false end
function b_Goal_Infiltrate:Reset()self.Infiltrated=false;self.Marker=nil end
function b_Goal_Infiltrate:Interrupt(Y1WX)Logic.DestroyEffect(self.Marker)end;Core:RegisterBehavior(b_Goal_Infiltrate)function Goal_AmmunitionAmount(...)return
b_Goal_AmmunitionAmount:new(...)end
b_Goal_AmmunitionAmount={Name="Goal_AmmunitionAmount",Description={en="Goal: Reach a smaller or bigger value than the given amount of ammunition in a war machine.",de="Ziel: Ueber- oder unterschreite die angegebene Anzahl Munition in einem Kriegsgerät."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Amount",de="Menge"}}}
function b_Goal_AmmunitionAmount:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_AmmunitionAmount:AddParameter(G06Z2,K)
if(G06Z2 ==0)then self.Scriptname=K elseif(G06Z2 ==1)then self.bRelSmallerThan=
tostring(K)=="true"or K=="<"elseif(G06Z2 ==2)then self.Amount=
K*1 end end
function b_Goal_AmmunitionAmount:CustomFunction()local tQx9TV=GetID(self.Scriptname)if not
IsExisting(tQx9TV)then return false end
local FL7g2o=Logic.GetAmmunitionAmount(tQx9TV)
if
(self.bRelSmallerThan and FL7g2o<self.Amount)or
(not self.bRelSmallerThan and FL7g2o>=self.Amount)then return true end;return nil end
function b_Goal_AmmunitionAmount:DEBUG(dkh7Tt9)if self.Amount<0 then
dbg(dkh7Tt9.Identifier..": Error in "..self.Name..
": Amount is negative")return true end end
function b_Goal_AmmunitionAmount:GetCustomData(XiNd_H)if XiNd_H==1 then return{"<",">="}end end;Core:RegisterBehavior(b_Goal_AmmunitionAmount)function Reprisal_SetPosition(...)return
b_Reprisal_SetPosition:new(...)end
b_Reprisal_SetPosition={Name="Reprisal_SetPosition",Description={en="Reprisal: Places an entity relative to the position of another. The entity can look the target.",de="Vergeltung: Setzt eine Entity relativ zur Position einer anderen. Die Entity kann zum Ziel ausgerichtet werden."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.ScriptName,en="Target position",de="Zielposition"},{ParameterType.Custom,en="Face to face",de="Ziel ansehen"},{ParameterType.Number,en="Distance",de="Zielentfernung"}}}
function b_Reprisal_SetPosition:GetReprisalTable(Q_c4px86)return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_SetPosition:AddParameter(_F6VYt,ITv3PH1i)
if(_F6VYt==0)then self.Entity=ITv3PH1i elseif
(_F6VYt==1)then self.Target=ITv3PH1i elseif(_F6VYt==2)then
self.FaceToFace=AcceptAlternativeBoolean(ITv3PH1i)elseif(_F6VYt==3)then self.Distance=
(ITv3PH1i~=nil and tonumber(ITv3PH1i))or 100 end end
function b_Reprisal_SetPosition:CustomFunction(_5fF)
if not IsExisting(self.Entity)or not
IsExisting(self.Target)then return end;local OUQqQp=GetID(self.Entity)local OyOfzTWn=GetID(self.Target)
local rx,ijvSrZA1,STNuSN6=Logic.EntityGetPos(OyOfzTWn)if Logic.IsBuilding(OyOfzTWn)==1 then
rx,ijvSrZA1=Logic.GetBuildingApproachPosition(OyOfzTWn)end;local PYOeGnAZ=
Logic.GetEntityOrientation(OyOfzTWn)+90
if self.FaceToFace then rx=rx+self.Distance*
math.cos(math.rad(PYOeGnAZ))
ijvSrZA1=
ijvSrZA1+self.Distance*math.sin(math.rad(PYOeGnAZ))
Logic.DEBUG_SetSettlerPosition(OUQqQp,rx,ijvSrZA1)LookAt(self.Entity,self.Target)else if
Logic.IsBuilding(OyOfzTWn)==1 then
rx,ijvSrZA1=Logic.GetBuildingApproachPosition(OyOfzTWn)end
Logic.DEBUG_SetSettlerPosition(OUQqQp,rx,ijvSrZA1)end end;function b_Reprisal_SetPosition:GetCustomData(s10ar5XH)
if s10ar5XH==3 then return{"true","false"}end end
function b_Reprisal_SetPosition:DEBUG(YoKhvIs)
if
self.FaceToFace then
if
tonumber(self.Distance)==nil or self.Distance<50 then
dbg(YoKhvIs.Identifier..
" "..self.Name..": Distance is nil or to short!")return true end end
if
not IsExisting(self.Entity)or not IsExisting(self.Target)then
dbg(YoKhvIs.Identifier.." "..
self.Name..": Mover entity or target entity does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_SetPosition)function Reprisal_ChangePlayer(...)return
b_Reprisal_ChangePlayer:new(...)end
b_Reprisal_ChangePlayer={Name="Reprisal_ChangePlayer",Description={en="Reprisal: Changes the owner of the entity or a battalion.",de="Vergeltung: Aendert den Besitzer einer Entity oder eines Battalions."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Player",de="Spieler"}}}
function b_Reprisal_ChangePlayer:GetReprisalTable(I2ipE)return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_ChangePlayer:AddParameter(qS730I,PYEbnua)
if(qS730I==0)then self.Entity=PYEbnua elseif
(qS730I==1)then self.Player=tostring(PYEbnua)end end
function b_Reprisal_ChangePlayer:CustomFunction(Um4ZYiT)
if not IsExisting(self.Entity)then return end;local AF=GetID(self.Entity)
if Logic.IsLeader(AF)==1 then
Logic.ChangeSettlerPlayerID(AF,self.Player)else Logic.ChangeEntityPlayerID(AF,self.Player)end end
function b_Reprisal_ChangePlayer:GetCustomData(s)if s==1 then
return{"0","1","2","3","4","5","6","7","8"}end end
function b_Reprisal_ChangePlayer:DEBUG(hIHW)
if not IsExisting(self.Entity)then
dbg(hIHW.Identifier..
" "..
self.Name..": entity '"..self.Entity.."' does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_ChangePlayer)function Reprisal_SetVisible(...)return
b_Reprisal_SetVisible:new(...)end
b_Reprisal_SetVisible={Name="Reprisal_SetVisible",Description={en="Reprisal: Changes the visibility of an entity. If the entity is a spawner the spawned entities will be affected.",de="Strafe: Setzt die Sichtbarkeit einer Entity. Handelt es sich um einen Spawner werden auch die gespawnten Entities beeinflusst."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Visible",de="Sichtbar"}}}
function b_Reprisal_SetVisible:GetReprisalTable(H5)return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_SetVisible:AddParameter(HYY,C3)if(HYY==0)then self.Entity=C3 elseif(HYY==1)then
self.Visible=AcceptAlternativeBoolean(C3)end end
function b_Reprisal_SetVisible:CustomFunction(SkCMMH)
if not IsExisting(self.Entity)then return end;local kvvs=GetID(self.Entity)
local _yTx3S94=Logic.EntityGetPlayer(kvvs)local Mm=Logic.GetEntityType(kvvs)
local g524=Logic.GetEntityTypeName(Mm)
if

string.find(g524,"S_")or string.find(g524,"B_NPC_Bandits")or string.find(g524,"B_NPC_Barracks")then local WUdVeYc={Logic.GetSpawnedEntities(kvvs)}
for lHep6wo=1,#WUdVeYc
do
if Logic.IsLeader(WUdVeYc[lHep6wo])==1 then
local BKZsJ={Logic.GetSoldiersAttachedToLeader(WUdVeYc[lHep6wo])}
for Sw=2,#BKZsJ do Logic.SetVisible(BKZsJ[Sw],self.Visible)end else
Logic.SetVisible(WUdVeYc[lHep6wo],self.Visible)end end else
if Logic.IsLeader(kvvs)==1 then
local W67mm9p6={Logic.GetSoldiersAttachedToLeader(kvvs)}for oBxdTi6u=2,#W67mm9p6 do
Logic.SetVisible(W67mm9p6[oBxdTi6u],self.Visible)end else
Logic.SetVisible(kvvs,self.Visible)end end end;function b_Reprisal_SetVisible:GetCustomData(T7hLe5j)
if T7hLe5j==1 then return{"true","false"}end end
function b_Reprisal_SetVisible:DEBUG(I_)if not
IsExisting(self.Entity)then
dbg(I_.Identifier.." "..self.Name..
": entity '"..self.Entity.."' does not exist!")return true end;return
false end;Core:RegisterBehavior(b_Reprisal_SetVisible)function Reprisal_SetVulnerability(...)return
b_Reprisal_SetVulnerability:new(...)end
b_Reprisal_SetVulnerability={Name="Reprisal_SetVulnerability",Description={en="Reprisal: Changes the vulnerability of the entity. If the entity is a spawner the spawned entities will be affected.",de="Vergeltung: Macht eine Entity verwundbar oder unverwundbar. Handelt es sich um einen Spawner, sind die gespawnten Entities betroffen"},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Vulnerability",de="Verwundbar"}}}
function b_Reprisal_SetVulnerability:GetReprisalTable(J2Jin)return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_SetVulnerability:AddParameter(Rvg,HpdA)if(Rvg==0)then self.Entity=HpdA elseif(Rvg==1)then
self.Vulnerability=AcceptAlternativeBoolean(HpdA)end end
function b_Reprisal_SetVulnerability:CustomFunction(DsAJbW)
if not IsExisting(self.Entity)then return end;local AXfX=GetID(self.Entity)
local btcUUhB=Logic.GetEntityType(AXfX)local iw0S=Logic.GetEntityTypeName(btcUUhB)
if self.Vulnerability then
if
string.find(iw0S,"S_")or string.find(iw0S,"B_NPC_Bandits")or
string.find(iw0S,"B_NPC_Barracks")then
local Tjg={Logic.GetSpawnedEntities(AXfX)}
for n2srE7H=1,#Tjg do
if Logic.IsLeader(Tjg[n2srE7H])==1 then
local Rf={Logic.GetSoldiersAttachedToLeader(Tjg[n2srE7H])}for X9ZjrTz=2,#Rf do MakeVulnerable(Rf[X9ZjrTz])end end;MakeVulnerable(Tjg[n2srE7H])end else MakeVulnerable(self.Entity)end else
if

string.find(iw0S,"S_")or string.find(iw0S,"B_NPC_Bandits")or string.find(iw0S,"B_NPC_Barracks")then local tYFIuD={Logic.GetSpawnedEntities(AXfX)}
for Ht5Ge=1,#tYFIuD
do
if Logic.IsLeader(tYFIuD[Ht5Ge])==1 then
local l={Logic.GetSoldiersAttachedToLeader(tYFIuD[Ht5Ge])}for IO=2,#l do MakeInvulnerable(l[IO])end end;MakeInvulnerable(tYFIuD[Ht5Ge])end else MakeInvulnerable(self.Entity)end end end;function b_Reprisal_SetVulnerability:GetCustomData(YDJY)
if YDJY==1 then return{"true","false"}end end
function b_Reprisal_SetVulnerability:DEBUG(t)if
not IsExisting(self.Entity)then
dbg(t.Identifier..
" "..self.Name..": entity '"..self.Entity..
"' does not exist!")return true end;return
false end
Core:RegisterBehavior(b_Reprisal_SetVulnerability)
function Reprisal_SetModel(...)return b_Reprisal_SetModel:new(...)end
b_Reprisal_SetModel={Name="Reprisal_SetModel",Description={en="Reprisal: Changes the model of the entity. Be careful, some models crash the game.",de="Vergeltung: Aendert das Model einer Entity. Achtung: Einige Modelle fuehren zum Absturz."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Model",de="Model"}}}
function b_Reprisal_SetModel:GetReprisalTable(Rdi8NIft)return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_SetModel:AddParameter(J0uTkQ9,sd6k)if(J0uTkQ9 ==0)then self.Entity=sd6k elseif(J0uTkQ9 ==1)then
self.Model=sd6k end end
function b_Reprisal_SetModel:CustomFunction(a)
if not IsExisting(self.Entity)then return end;local lK7=GetID(self.Entity)
Logic.SetModel(lK7,Models[self.Model])end
function b_Reprisal_SetModel:GetCustomData(KWMxs7a)
if KWMxs7a==1 then local T={}
for LBIp4,A5 in pairs(Models)do
if










not
string.find(LBIp4,"Animals_")and not string.find(LBIp4,"Banners_")and not string.find(LBIp4,"Goods_")and not string.find(LBIp4,"goods_")and not string.find(LBIp4,"Heads_")and not string.find(LBIp4,"MissionMap_")and not string.find(LBIp4,"R_Fish")and not string.find(LBIp4,"Units_")and not string.find(LBIp4,"XD_")and not string.find(LBIp4,"XS_")and not string.find(LBIp4,"XT_")and not string.find(LBIp4,"Z_")then table.insert(T,LBIp4)end end;return T end end
function b_Reprisal_SetModel:DEBUG(PV168s0f)
if not IsExisting(self.Entity)then
dbg(PV168s0f.Identifier..
" "..
self.Name..": entity '"..self.Entity.."' does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_SetModel)function Reward_SetPosition(...)return
b_Reward_SetPosition:new(...)end
b_Reward_SetPosition=API.InstanceTable(b_Reprisal_SetPosition)b_Reward_SetPosition.Name="Reward_SetPosition"
b_Reward_SetPosition.Description.en="Reward: Places an entity relative to the position of another. The entity can look the target."
b_Reward_SetPosition.Description.de="Lohn: Setzt eine Entity relativ zur Position einer anderen. Die Entity kann zum Ziel ausgerichtet werden."b_Reward_SetPosition.GetReprisalTable=nil
b_Reward_SetPosition.GetRewardTable=function(bjK,Us1Xh)return
{Reward.Custom,{bjK,bjK.CustomFunction}}end;Core:RegisterBehavior(b_Reward_SetPosition)function Reward_ChangePlayer(...)return
b_Reprisal_ChangePlayer:new(...)end
b_Reward_ChangePlayer=API.InstanceTable(b_Reprisal_ChangePlayer)b_Reward_ChangePlayer.Name="Reward_ChangePlayer"
b_Reward_ChangePlayer.Description.en="Reward: Changes the owner of the entity or a battalion."
b_Reward_ChangePlayer.Description.de="Lohn: Aendert den Besitzer einer Entity oder eines Battalions."b_Reward_ChangePlayer.GetReprisalTable=nil
b_Reward_ChangePlayer.GetRewardTable=function(rs59,R)return
{Reward.Custom,{rs59,rs59.CustomFunction}}end;Core:RegisterBehavior(b_Reward_ChangePlayer)function Reward_MoveToPosition(...)return
b_Reward_MoveToPosition:new(...)end
b_Reward_MoveToPosition={Name="Reward_MoveToPosition",Description={en="Reward: Moves an entity relative to another entity. If angle is zero the entities will be standing directly face to face.",de="Lohn: Bewegt eine Entity relativ zur Position einer anderen. Wenn Winkel 0 ist, stehen sich die Entities direkt gegen�ber."},Parameter={{ParameterType.ScriptName,en="Settler",de="Siedler"},{ParameterType.ScriptName,en="Destination",de="Ziel"},{ParameterType.Number,en="Distance",de="Entfernung"},{ParameterType.Number,en="Angle",de="Winkel"}}}
function b_Reward_MoveToPosition:GetRewardTable(rGa2MaGH)return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_MoveToPosition:AddParameter(i6,u33wPQT)
if(i6 ==0)then self.Entity=u33wPQT elseif(i6 ==1)then
self.Target=u33wPQT elseif(i6 ==2)then self.Distance=u33wPQT*1 elseif(i6 ==3)then self.Angle=u33wPQT*1 end end
function b_Reward_MoveToPosition:CustomFunction(aNrMnPZ)
if not IsExisting(self.Entity)or not
IsExisting(self.Target)then return end;self.Angle=self.Angle or 0;local fC=GetID(self.Entity)
local Kl=GetID(self.Target)local E=Logic.GetEntityOrientation(Kl)
local mJGBwA,_E3,j3=Logic.EntityGetPos(Kl)if Logic.IsBuilding(Kl)==1 then
mJGBwA,_E3=Logic.GetBuildingApproachPosition(Kl)E=E-90 end
mJGBwA=mJGBwA+self.Distance*math.cos(math.rad(
E+self.Angle))_E3=_E3+
self.Distance*math.sin(math.rad(E+self.Angle))
Logic.MoveSettler(fC,mJGBwA,_E3)
StartSimpleJobEx(function(f,jy)
if Logic.IsEntityMoving(f)==false then LookAt(f,jy)return true end end,fC,Kl)end
function b_Reward_MoveToPosition:DEBUG(Ifev2bUE)
if tonumber(self.Distance)==nil or
self.Distance<50 then
dbg(Ifev2bUE.Identifier.." "..
self.Name..": Distance is nil or to short!")return true elseif not IsExisting(self.Entity)or
not IsExisting(self.Target)then
dbg(Ifev2bUE.Identifier.." "..self.Name..
": Mover entity or target entity does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reward_MoveToPosition)function Reward_VictoryWithParty()return
b_Reward_VictoryWithParty:new()end
b_Reward_VictoryWithParty={Name="Reward_VictoryWithParty",Description={en="Reward: The player wins the game with an animated festival on the market.",de="Lohn: Der Spieler gewinnt das Spiel mit einer animierten Siegesfeier."},Parameter={}}
function b_Reward_VictoryWithParty:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function b_Reward_VictoryWithParty:AddParameter(ZY,KCpJbzHT)end
function b_Reward_VictoryWithParty:CustomFunction(g)
Victory(g_VictoryAndDefeatType.VictoryMissionComplete)local dQl0xvy2=g.ReceivingPlayer
local hX=Logic.GetMarketplace(dQl0xvy2)
if IsExisting(hX)then local w=GetPosition(hX)
Logic.CreateEffect(EGL_Effects.FXFireworks01,w.X,w.Y,0)
Logic.CreateEffect(EGL_Effects.FXFireworks02,w.X,w.Y,0)
local YTrvPn={Entities.U_SmokeHouseWorker,Entities.U_Butcher,Entities.U_Carpenter,Entities.U_Tanner,Entities.U_Blacksmith,Entities.U_CandleMaker,Entities.U_Baker,Entities.U_DairyWorker,Entities.U_SpouseS01,Entities.U_SpouseS02,Entities.U_SpouseS02,Entities.U_SpouseS03,Entities.U_SpouseF01,Entities.U_SpouseF01,Entities.U_SpouseF02,Entities.U_SpouseF03}VictoryGenerateFestivalAtPlayer(dQl0xvy2,YTrvPn)
Logic.ExecuteInLuaLocalState(
[[
            if IsExisting(]]..
hX..
[[) then
                CameraAnimation.AllowAbort = false
                CameraAnimation.QueueAnimation( CameraAnimation.SetCameraToEntity, ]]..
hX..
[[)
                CameraAnimation.QueueAnimation( CameraAnimation.StartCameraRotation,  5 )
                CameraAnimation.QueueAnimation( CameraAnimation.Stay ,  9999 )
            end
            XGUIEng.ShowWidget("/InGame/InGame/MissionEndScreen/ContinuePlaying", 0);
        ]])end end;function b_Reward_VictoryWithParty:DEBUG(pB6K)return false end
Core:RegisterBehavior(b_Reward_VictoryWithParty)
function Reward_SetVisible(...)return b_Reward_SetVisible:new(...)end
b_Reward_SetVisible=API.InstanceTable(b_Reprisal_SetVisible)b_Reward_SetVisible.Name="Reward_ChangePlayer"
b_Reward_SetVisible.Description.en="Reward: Changes the visibility of an entity. If the entity is a spawner the spawned entities will be affected."
b_Reward_SetVisible.Description.de="Lohn: Setzt die Sichtbarkeit einer Entity. Handelt es sich um einen Spawner werden auch die gespawnten Entities beeinflusst."b_Reward_SetVisible.GetReprisalTable=nil
b_Reward_SetVisible.GetRewardTable=function(YV,zPm)return
{Reward.Custom,{YV,YV.CustomFunction}}end;Core:RegisterBehavior(b_Reward_SetVisible)function Reward_AI_SetEntityControlled(...)return
b_Reward_AI_SetEntityControlled:new(...)end
b_Reward_AI_SetEntityControlled={Name="Reward_AI_SetEntityControlled",Description={en="Reward: Bind or Unbind an entity or a battalion to/from an AI player. The AI player must be activated!",de="Lohn: Die KI kontrolliert die Entity oder der KI die Kontrolle entziehen. Die KI muss aktiv sein!"},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="AI control entity",de="KI kontrolliert Entity"}}}
function b_Reward_AI_SetEntityControlled:GetRewardTable(JmEyZ5)return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_SetEntityControlled:AddParameter(FGvy,KpnA)
if(FGvy==0)then self.Entity=KpnA elseif
(FGvy==1)then self.Hidden=AcceptAlternativeBoolean(KpnA)end end
function b_Reward_AI_SetEntityControlled:CustomFunction(j_F9c)if
not IsExisting(self.Entity)then return end;local q=GetID(self.Entity)
local b7G0ciz=Logic.EntityGetPlayer(q)local rF2te=Logic.GetEntityType(q)
local KG_EjN=Logic.GetEntityTypeName(rF2te)
if

string.find(KG_EjN,"S_")or string.find(KG_EjN,"B_NPC_Bandits")or string.find(KG_EjN,"B_NPC_Barracks")then local aIrjXeB={Logic.GetSpawnedEntities(q)}
for sZdri=1,#aIrjXeB do if
Logic.IsLeader(aIrjXeB[sZdri])==1 then
AICore.HideEntityFromAI(b7G0ciz,aIrjXeB[sZdri],not self.Hidden)end end else
AICore.HideEntityFromAI(b7G0ciz,q,not self.Hidden)end end;function b_Reward_AI_SetEntityControlled:GetCustomData(pT)
if pT==1 then return{"false","true"}end end
function b_Reward_AI_SetEntityControlled:DEBUG(XgkgIR9)
if
not IsExisting(self.Entity)then
dbg(XgkgIR9.Identifier..
" "..self.Name..": entity '"..self.Entity..
"' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Reward_AI_SetEntityControlled)function Reward_SetVulnerability(...)
return b_Reward_SetVulnerability:new(...)end
b_Reward_SetVulnerability=API.InstanceTable(b_Reprisal_SetVulnerability)b_Reward_SetVulnerability.Name="Reward_SetVulnerability"
b_Reward_SetVulnerability.Description.en="Reward: Changes the vulnerability of the entity. If the entity is a spawner the spawned entities will be affected."
b_Reward_SetVulnerability.Description.de="Lohn: Macht eine Entity verwundbar oder unverwundbar. Handelt es sich um einen Spawner, sind die gespawnten Entities betroffen."b_Reward_SetVulnerability.GetReprisalTable=nil
b_Reward_SetVulnerability.GetRewardTable=function(sm2,cz)return
{Reward.Custom,{sm2,sm2.CustomFunction}}end;Core:RegisterBehavior(b_Reward_SetVulnerability)function Reward_SetModel(...)return
b_Reward_SetModel:new(...)end
b_Reward_SetModel=API.InstanceTable(b_Reprisal_SetModel)b_Reward_SetModel.Name="Reward_SetModel"
b_Reward_SetModel.Description.en="Reward: Changes the model of the entity. Be careful, some models crash the game."
b_Reward_SetModel.Description.de="Lohn: Aendert das Model einer Entity. Achtung: Einige Modelle fuehren zum Absturz."b_Reward_SetModel.GetReprisalTable=nil
b_Reward_SetModel.GetRewardTable=function(pSL,ifrP9)return
{Reward.Custom,{pSL,pSL.CustomFunction}}end;Core:RegisterBehavior(b_Reward_SetModel)function Reward_RefillAmmunition(...)return
b_Reward_RefillAmmunition:new(...)end
b_Reward_RefillAmmunition={Name="Reward_RefillAmmunition",Description={en="Reward: Refills completely the ammunition of the entity.",de="Lohn: Fuellt die Munition der Entity vollständig auf."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}
function b_Reward_RefillAmmunition:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function b_Reward_RefillAmmunition:AddParameter(Iynmp,PFvHX)
if(Iynmp==0)then self.Scriptname=PFvHX end end
function b_Reward_RefillAmmunition:CustomFunction()
local sP=GetID(self.Scriptname)if not IsExisting(sP)then return end
local Y=Logic.GetAmmunitionAmount(sP)while(Y<10)do Logic.RefillAmmunitions(sP)
Y=Logic.GetAmmunitionAmount(sP)end end
function b_Reward_RefillAmmunition:DEBUG(QHxdp58D)
if not IsExisting(self.Scriptname)then
dbg(
QHxdp58D.Identifier..": Error in "..
self.Name..": '"..self.Scriptname.."' is destroyed!")return true end;return false end;Core:RegisterBehavior(b_Reward_RefillAmmunition)
function Trigger_OnAtLeastXOfYQuestsFailed(...)return
b_Trigger_OnAtLeastXOfYQuestsFailed:new(...)end
b_Trigger_OnAtLeastXOfYQuestsFailed={Name="Trigger_OnAtLeastXOfYQuestsFailed",Description={en="Trigger: if at least X of Y given quests has been finished successfully.",de="Ausloeser: wenn X von Y angegebener Quests fehlgeschlagen sind."},Parameter={{ParameterType.Custom,en="Least Amount",de="Mindest Anzahl"},{ParameterType.Custom,en="Quest Amount",de="Quest Anzahl"},{ParameterType.QuestName,en="Quest name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest name 2",de="Questname 2"},{ParameterType.QuestName,en="Quest name 3",de="Questname 3"},{ParameterType.QuestName,en="Quest name 4",de="Questname 4"},{ParameterType.QuestName,en="Quest name 5",de="Questname 5"}}}
function b_Trigger_OnAtLeastXOfYQuestsFailed:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnAtLeastXOfYQuestsFailed:AddParameter(efdknL,YUdva)
if(efdknL==0)then
self.LeastAmount=tonumber(YUdva)elseif(efdknL==1)then self.QuestAmount=tonumber(YUdva)elseif(efdknL==2)then
self.QuestName1=YUdva elseif(efdknL==3)then self.QuestName2=YUdva elseif(efdknL==4)then self.QuestName3=YUdva elseif(efdknL==
5)then self.QuestName4=YUdva elseif(efdknL==6)then self.QuestName5=YUdva end end
function b_Trigger_OnAtLeastXOfYQuestsFailed:CustomFunction()local x8FBS=0
for LGBr=1,self.QuestAmount do
local M=GetQuestID(self["QuestName"..LGBr])if IsValidQuest(M)then
if
(Quests[M].Result==QuestResult.Failure)then x8FBS=x8FBS+1;if x8FBS>=self.LeastAmount then return true end end end end;return false end
function b_Trigger_OnAtLeastXOfYQuestsFailed:DEBUG(I)local W=self.LeastAmount
local Dx5GC=self.QuestAmount
if W<=0 or W>5 then
dbg(I.Identifier..
": Error in "..self.Name..": LeastAmount is wrong")return true elseif Dx5GC<=0 or Dx5GC>5 then
dbg(I.Identifier..": Error in "..
self.Name..": QuestAmount is wrong")return true elseif W>Dx5GC then
dbg(I.Identifier..": Error in "..
self.Name..": LeastAmount is greater than QuestAmount")return true end
for kwZhI=1,Dx5GC do
if
not IsValidQuest(self["QuestName"..kwZhI])then
dbg(I.Identifier..
": Error in "..self.Name..": Quest "..
self["QuestName"..kwZhI].." not found")return true end end;return false end
function b_Trigger_OnAtLeastXOfYQuestsFailed:GetCustomData(T0h)if(T0h==0)or(T0h==1)then return
{"1","2","3","4","5"}end end
Core:RegisterBehavior(b_Trigger_OnAtLeastXOfYQuestsFailed)function Trigger_AmmunitionDepleted(...)
return b_Trigger_AmmunitionDepleted:new(...)end
b_Trigger_AmmunitionDepleted={Name="Trigger_AmmunitionDepleted",Description={en="Trigger: if the ammunition of the entity is depleted.",de="Ausloeser: wenn die Munition der Entity aufgebraucht ist."},Parameter={{ParameterType.Scriptname,en="Script name",de="Skriptname"}}}
function b_Trigger_AmmunitionDepleted:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function b_Trigger_AmmunitionDepleted:AddParameter(H0,Mrz66)
if(H0 ==0)then self.Scriptname=Mrz66 end end
function b_Trigger_AmmunitionDepleted:CustomFunction()
if
not IsExisting(self.Scriptname)then return false end;local A=GetID(self.Scriptname)if
Logic.GetAmmunitionAmount(A)>0 then return false end;return true end
function b_Trigger_AmmunitionDepleted:DEBUG(RR)
if not IsExisting(self.Scriptname)then
dbg(
RR.Identifier..": Error in "..
self.Name..": '"..self.Scriptname.."' is destroyed!")return true end;return false end
Core:RegisterBehavior(b_Trigger_AmmunitionDepleted)function Trigger_OnExactOneQuestIsWon(...)
return b_Trigger_OnExactOneQuestIsWon:new(...)end
b_Trigger_OnExactOneQuestIsWon={Name="Trigger_OnExactOneQuestIsWon",Description={en="Trigger: if one of two given quests has been finished successfully, but NOT both.",de="Ausloeser: wenn eine von zwei angegebenen Quests (aber NICHT beide) erfolgreich abgeschlossen wurde."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function b_Trigger_OnExactOneQuestIsWon:GetTriggerTable(Oj4B)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnExactOneQuestIsWon:AddParameter(aT,ZN0brC)self.QuestTable={}if(aT==0)then
self.Quest1=ZN0brC elseif(aT==1)then self.Quest2=ZN0brC end end
function b_Trigger_OnExactOneQuestIsWon:CustomFunction(g)
local iYIip_rt=Quests[GetQuestID(self.Quest1)]local WoJla=Quests[GetQuestID(self.Quest2)]
if
WoJla and iYIip_rt then
local jk=(iYIip_rt.State==QuestState.Over and
iYIip_rt.Result==QuestResult.Success)
local Y=(WoJla.State==QuestState.Over and WoJla.Result==QuestResult.Success)
if(jk and not Y)or(not jk and Y)then return true end end;return false end
function b_Trigger_OnExactOneQuestIsWon:DEBUG(sM)
if self.Quest1 ==self.Quest2 then
dbg(sM.Identifier..": "..
self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
dbg(sM.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
dbg(sM.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Trigger_OnExactOneQuestIsWon)function Trigger_OnExactOneQuestIsLost(...)
return b_Trigger_OnExactOneQuestIsLost:new(...)end
b_Trigger_OnExactOneQuestIsLost={Name="Trigger_OnExactOneQuestIsLost",Description={en="Trigger: If one of two given quests has been lost, but NOT both.",de="Ausloeser: Wenn einer von zwei angegebenen Quests (aber NICHT beide) fehlschlägt."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function b_Trigger_OnExactOneQuestIsLost:GetTriggerTable(MMJEx)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnExactOneQuestIsLost:AddParameter(EB,Qy)self.QuestTable={}if(EB==0)then
self.Quest1=Qy elseif(EB==1)then self.Quest2=Qy end end
function b_Trigger_OnExactOneQuestIsLost:CustomFunction(rCWKBim)
local i=Quests[GetQuestID(self.Quest1)]local wLI=Quests[GetQuestID(self.Quest2)]
if wLI and i then
local N7h=(i.State==
QuestState.Over and i.Result==QuestResult.Failure)
local jDOa=(wLI.State==QuestState.Over and wLI.Result==QuestResult.Failure)
if(N7h and not jDOa)or(not N7h and jDOa)then return true end end;return false end
function b_Trigger_OnExactOneQuestIsLost:DEBUG(DcVHvlcZ)
if self.Quest1 ==self.Quest2 then
dbg(
DcVHvlcZ.Identifier..": "..self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
dbg(DcVHvlcZ.Identifier..": "..
self.Name..
": Quest '"..self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
dbg(DcVHvlcZ.Identifier..": "..
self.Name..
": Quest '"..self.Quest2 .."' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Trigger_OnExactOneQuestIsWon)BundleSymfoniaBehaviors={Global={},Local={}}
function BundleSymfoniaBehaviors.Global:Install()
GameCallback_OnThiefDeliverEarnings_Orig_QSB_SymfoniaBehaviors=GameCallback_OnThiefDeliverEarnings
GameCallback_OnThiefDeliverEarnings=function(Z,Ke2eY9,mJU4,y)
GameCallback_OnThiefDeliverEarnings_Orig_QSB_SymfoniaBehaviors(Z,Ke2eY9,mJU4,y)
for wtz=1,Quests[0]do
if
Quests[wtz]and Quests[wtz].State==QuestState.Active then
for N7=1,Quests[wtz].Objectives[0]do
if
Quests[wtz].Objectives[N7].Type==Objective.Custom2 then
if
Quests[wtz].Objectives[N7].Data[1].Name=="Goal_StealBuilding"then local LLka3VWH
for B34=1,#
Quests[wtz].Objectives[N7].Data[1].RobberList do
local S9D=Quests[wtz].Objectives[N7].Data[1].RobberList[B34]if
S9D[1]==
GetID(Quests[wtz].Objectives[N7].Data[1].Building)and S9D[2]==Ke2eY9 then LLka3VWH=true;break end end;if LLka3VWH then
Quests[wtz].Objectives[N7].Data[1].SuccessfullyStohlen=true end elseif
Quests[wtz].Objectives[N7].Data[1].Name=="Goal_StealGold"then Quests[wtz].Objectives[N7].Data[1].StohlenGold=
Quests[wtz].Objectives[N7].Data[1].StohlenGold+y
if
Quests[wtz].Objectives[N7].Data[1].Printout then local JeqL=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
local RmN8={de="Talern gestohlen",en="gold stolen"}
local ePtDYbn=Quests[wtz].Objectives[N7].Data[1].StohlenGold
local dPm5lS=Quests[wtz].Objectives[N7].Data[1].Amount
API.Note(string.format("%d/%d %s",ePtDYbn,dPm5lS,RmN8[JeqL]))end end end end end end end
GameCallback_OnThiefStealBuilding_Orig_QSB_SymfoniaBehaviors=GameCallback_OnThiefStealBuilding
GameCallback_OnThiefStealBuilding=function(fNIe,y2R1,O,JyKiCqQo)
GameCallback_OnThiefStealBuilding_Orig_QSB_SymfoniaBehaviors(fNIe,y2R1,O,JyKiCqQo)
for wCXetPV=1,Quests[0]do
if Quests[wCXetPV]and
Quests[wCXetPV].State==QuestState.Active then
for RPo=1,Quests[wCXetPV].Objectives[0]do
if
Quests[wCXetPV].Objectives[RPo].Type==Objective.Custom2 then
if
Quests[wCXetPV].Objectives[RPo].Data[1].Name=="Goal_Infiltrate"then
if
GetID(Quests[wCXetPV].Objectives[RPo].Data[1].Building)==O and
Quests[wCXetPV].ReceivingPlayer==y2R1 then
Quests[wCXetPV].Objectives[RPo].Data[1].Infiltrated=true;if
Quests[wCXetPV].Objectives[RPo].Data[1].Delete then DestroyEntity(fNIe)end end elseif
Quests[wCXetPV].Objectives[RPo].Data[1].Name=="Goal_StealBuilding"then local k0Z;local kVpWe4Q=
Logic.IsEntityInCategory(O,EntityCategories.Cathedrals)==1;local ni=
Logic.GetEntityType(O)==Entities.B_StoreHouse
if
ni or kVpWe4Q then
Quests[wCXetPV].Objectives[RPo].Data[1].SuccessfullyStohlen=true else
for Jo1IX=1,#
Quests[wCXetPV].Objectives[RPo].Data[1].RobberList do
local Abdl=Quests[wCXetPV].Objectives[RPo].Data[1].RobberList[Jo1IX]
if Abdl[1]==O and Abdl[2]==fNIe then k0Z=true;break end end end;if not k0Z then
table.insert(Quests[wCXetPV].Objectives[RPo].Data[1].RobberList,{O,fNIe})end end end end end end end
QuestTemplate.IsObjectiveCompleted_Orig_QSB_SymfoniaBehaviors=QuestTemplate.IsObjectiveCompleted
QuestTemplate.IsObjectiveCompleted=function(I4LLjpL,vAK)local zx=vAK.Type;local hs=vAK.Data;if vAK.Completed~=nil then return
vAK.Completed end
if zx==Objective.Distance then
local v0yK_h=GetID(hs[1])local u=GetID(hs[2])hs[3]=hs[3]or 2500
if not
(
Logic.IsEntityDestroyed(v0yK_h)or Logic.IsEntityDestroyed(u))then if
Logic.GetDistanceBetweenEntities(v0yK_h,u)<=hs[3]then DestroyQuestMarker(u)
vAK.Completed=true end else
DestroyQuestMarker(u)vAK.Completed=false end else
return I4LLjpL:IsObjectiveCompleted_Orig_QSB_SymfoniaBehaviors(vAK)end end
function QuestTemplate:RemoveQuestMarkers()
for Ragi=1,self.Objectives[0]do
if
self.Objectives[Ragi].Type==Objective.Distance then if
self.Objectives[Ragi].Data[4]then
DestroyQuestMarker(self.Objectives[Ragi].Data[2])end end end end
function QuestTemplate:ShowQuestMarkers()
for N_cPM=1,self.Objectives[0]do
if
self.Objectives[N_cPM].Type==Objective.Distance then if
self.Objectives[N_cPM].Data[4]then
ShowQuestMarker(self.Objectives[N_cPM].Data[2])end end end end
function ShowQuestMarker(R)local lV=GetID(R)local eYLj,gC=Logic.GetEntityPosition(lV)
local hhkXHj=EGL_Effects.E_Questmarker_low
if Logic.IsBuilding(lV)==1 then hhkXHj=EGL_Effects.E_Questmarker end
Questmarkers[lV]=Logic.CreateEffect(hhkXHj,eYLj,gC,0)end
function DestroyQuestMarker(XXWAbp)local QzMjn=GetID(XXWAbp)
if Questmarkers[QzMjn]~=nil then
Logic.DestroyEffect(Questmarkers[QzMjn])Questmarkers[QzMjn]=nil end end end;function BundleSymfoniaBehaviors.Local:Install()end
Core:RegisterBundle("BundleSymfoniaBehaviors")API=API or{}QSB=QSB or{}
function API.AddQuest(TPgGG6_)if GUI then
API.Log("API.AddQuest: Could not execute in local script!")return end;return
BundleQuestGeneration.Global:NewQuest(TPgGG6_)end;AddQuest=API.AddQuest
function API.StartQuests()if GUI then
API.Brudge("API.StartQuests()")return end;return
BundleQuestGeneration.Global:StartQuests()end;StartQuests=API.StartQuests
function API.QuestMessage(_,PmnCOE8,wKi1TU,zmJGh,L,gK05I0EL)if GUI then
API.Log("API.QuestMessage: Could not execute in local script!")return end;return
BundleQuestGeneration.Global:QuestMessage(_,PmnCOE8,wKi1TU,zmJGh,L,gK05I0EL)end;QuestMessage=API.QuestMessage
function API.QuestDialog(hUY0OEu)if GUI then
API.Log("API.QuestDialog: Could not execute in local script!")return end;local sRd,Cu;local WbHkOLVO={}
for tRs=1,#hUY0OEu,1 do
if tRs>1 then hUY0OEu[tRs][4]=
hUY0OEu[tRs][4]or Cu.Identifier;hUY0OEu[tRs][5]=
hUY0OEu[tRs][5]or 12 end
sRd,Cu=API.QuestMessage(unpack(hUY0OEu[tRs]))table.insert(WbHkOLVO,{sRd,Cu})end;return WbHkOLVO end;QuestDialog=API.QuestDialog
BundleQuestGeneration={Global={Data={GenerationList={},QuestMessageID=0}},Local={Data={}}}
BundleQuestGeneration.Global.Data.QuestTemplate={MSGKeyOverwrite=nil,IconOverwrite=nil,Loop=nil,Callback=nil,SuggestionText=nil,SuccessText=nil,FailureText=nil,Description=nil,Identifier=
nil,OpenMessage=true,CloseMessage=true,Sender=1,Receiver=1,Time=0,Goals={},Reprisals={},Rewards={},Triggers={}}function BundleQuestGeneration.Global:Install()end
function BundleQuestGeneration.Global:QuestMessage(L,_,b,PGFeEoyz,nG9jWF,Au)self.Data.QuestMessageID=
self.Data.QuestMessageID+1
local rY5={Triggers.Custom2,{{QuestName=PGFeEoyz},function(wYc)if
not wYc.QuestName then return true end;local gL=GetQuestID(wYc.QuestName)if
(
Quests[gL].State==QuestState.Over and
Quests[gL].Result~=QuestResult.Interrupted)then return true end;return false end}}local LJqvVB2=
(Network.GetDesiredLanguage()=="de"and"de")or"en"if
type(L)=="table"then L=L[LJqvVB2]end
assert(type(L)=="string")
return
QuestTemplate:New("QSB_QuestMessage_"..self.Data.QuestMessageID,(_ or 1),(b or 1),{{Objective.NoChange}},{rY5},(
nG9jWF or 1),nil,nil,Au,nil,false,(L~=nil),nil,nil,L,nil)end
function BundleQuestGeneration.Global:NewQuest(FH5YFuU)
local VJ7LpW=(Network.GetDesiredLanguage()==
"de"and"de")or"en"
if not FH5YFuU.Name then QSB.AutomaticQuestNameCounter=
(QSB.AutomaticQuestNameCounter or 0)+1
FH5YFuU.Name=string.format("AutoNamed_Quest_%d",QSB.AutomaticQuestNameCounter)end
if not Core:CheckQuestName(FH5YFuU.Name)then
dbg("Quest '"..
tostring(FH5YFuU.Name).."': invalid questname! Contains forbidden characters!")return end
local AmrXlmse=API.InstanceTable(self.Data.QuestTemplate)AmrXlmse.Identifier=FH5YFuU.Name;AmrXlmse.MSGKeyOverwrite=nil;AmrXlmse.IconOverwrite=
nil;AmrXlmse.Loop=FH5YFuU.Loop
AmrXlmse.Callback=FH5YFuU.Callback
AmrXlmse.SuggestionText=(type(FH5YFuU.Suggestion)=="table"and
FH5YFuU.Suggestion[VJ7LpW])or
FH5YFuU.Suggestion
AmrXlmse.SuccessText=(type(FH5YFuU.Success)=="table"and
FH5YFuU.Success[VJ7LpW])or FH5YFuU.Success
AmrXlmse.FailureText=(type(FH5YFuU.Failure)=="table"and
FH5YFuU.Failure[VJ7LpW])or FH5YFuU.Failure
AmrXlmse.Description=(type(FH5YFuU.Description)=="table"and
FH5YFuU.Description[VJ7LpW])or
FH5YFuU.Description
AmrXlmse.OpenMessage=FH5YFuU.Visible==true or FH5YFuU.Suggestion~=nil
AmrXlmse.CloseMessage=FH5YFuU.EndMessage==true or(FH5YFuU.Failure~=nil or FH5YFuU.Success~=
nil)AmrXlmse.Sender=
(FH5YFuU.Sender~=nil and FH5YFuU.Sender)or 1
AmrXlmse.Receiver=(
FH5YFuU.Receiver~=nil and FH5YFuU.Receiver)or 1
AmrXlmse.Time=(FH5YFuU.Time~=nil and FH5YFuU.Time)or 0;if FH5YFuU.Arguments then
AmrXlmse.Arguments=API.InstanceTable(FH5YFuU.Arguments)end
table.insert(self.Data.GenerationList,AmrXlmse)local L=#self.Data.GenerationList
self:AttachBehavior(L,FH5YFuU)self:StartQuests()return Quests[0]end
function BundleQuestGeneration.Global:AttachBehavior(e,gNWih6)
local uwzJA0D=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
for NGfeE,Uh7tTLt in pairs(gNWih6)do
if

NGfeE~="Parameter"and type(Uh7tTLt)=="table"and Uh7tTLt.en and Uh7tTLt.de then gNWih6[NGfeE]=Uh7tTLt[uwzJA0D]end end
for uHLv,GNSwGhP in pairs(gNWih6)do
if tonumber(uHLv)~=nil then
if type(GNSwGhP)~="table"then
dbg(
self.Data.GenerationList[e].Identifier..": Some behavior entries aren't behavior!")else
if GNSwGhP.GetGoalTable then
table.insert(self.Data.GenerationList[e].Goals,GNSwGhP:GetGoalTable())
local MPsJa56=#self.Data.GenerationList[e].Goals
self.Data.GenerationList[e].Goals[MPsJa56].Context=GNSwGhP
self.Data.GenerationList[e].Goals[MPsJa56].FuncOverrideIcon=self.Data.GenerationList[e].Goals[MPsJa56].Context.GetIcon
self.Data.GenerationList[e].Goals[MPsJa56].FuncOverrideMsgKey=self.Data.GenerationList[e].Goals[MPsJa56].Context.GetMsgKey elseif GNSwGhP.GetReprisalTable then
table.insert(self.Data.GenerationList[e].Reprisals,GNSwGhP:GetReprisalTable())elseif GNSwGhP.GetRewardTable then
table.insert(self.Data.GenerationList[e].Rewards,GNSwGhP:GetRewardTable())elseif GNSwGhP.GetTriggerTable then
table.insert(self.Data.GenerationList[e].Triggers,GNSwGhP:GetTriggerTable())else
dbg(self.Data.GenerationList[e].Identifier..": Could not obtain behavior table!")end end end end end
function BundleQuestGeneration.Global:StartQuests()if
not self:ValidateQuests()then return end
while
(#self.Data.GenerationList>0)do local OR8kQwdZ=table.remove(self.Data.GenerationList,1)
if
self:DebugQuest(OR8kQwdZ)then
local bsS,teN1=QuestTemplate:New(OR8kQwdZ.Identifier,OR8kQwdZ.Sender,OR8kQwdZ.Receiver,OR8kQwdZ.Goals,OR8kQwdZ.Triggers,assert(tonumber(OR8kQwdZ.Time)),OR8kQwdZ.Rewards,OR8kQwdZ.Reprisals,OR8kQwdZ.Callback,OR8kQwdZ.Loop,OR8kQwdZ.OpenMessage,OR8kQwdZ.CloseMessage,OR8kQwdZ.Description,OR8kQwdZ.SuggestionText,OR8kQwdZ.SuccessText,OR8kQwdZ.FailureText)
if OR8kQwdZ.MSGKeyOverwrite then teN1.MsgTableOverride=self.MSGKeyOverwrite end
if OR8kQwdZ.IconOverwrite then teN1.IconOverride=self.IconOverwrite end;if OR8kQwdZ.Arguments then
teN1.Arguments=API.InstanceTable(OR8kQwdZ.Arguments)end end end end
function BundleQuestGeneration.Global:ValidateQuests()
for oTK9pYO,F_A in
pairs(self.Data.GenerationList)do if#F_A.Goals==0 then
table.insert(self.Data.GenerationList[oTK9pYO].Goals,Goal_InstantSuccess())end;if#F_A.Triggers==0 then
table.insert(self.Data.GenerationList[oTK9pYO].Triggers,Trigger_Time(0))end
if#F_A.Goals==0 and
#F_A.Triggers==0 then
local I8x=string.format("Quest '"..
F_A.Identifier.."' is missing a goal or a trigger!")return false end;local H=""
if not F_A then H=H.."quest table is invalid!"else
if F_A.Loop~=nil and
type(F_A.Loop)~="function"then H=H..
self.Identifier..": Loop must be a function!"end;if
F_A.Callback~=nil and type(F_A.Callback)~="function"then
H=H..self.Identifier..": Callback must be a function!"end;if
(F_A.Sender==nil or(
F_A.Sender<1 or F_A.Sender>8))then
H=H..F_A.Identifier..": Sender is nil or greater than 8 or lower than 1!"end;if
(F_A.Receiver==
nil or(F_A.Receiver<0 or F_A.Receiver>8))then
H=H..self.Identifier..": Receiver is nil or greater than 8 or lower than 0!"end;if
(
F_A.Time==nil or type(F_A.Time)~="number"or F_A.Time<0)then
H=H..F_A.Identifier..": Time is nil or not a number or lower than 0!"end;if
type(F_A.OpenMessage)~="boolean"then
H=H..F_A.Identifier..": Visible need to be a boolean!"end;if type(F_A.CloseMessage)~=
"boolean"then
H=H..F_A.Identifier..": EndMessage need to be a boolean!"end;if
(F_A.Description~=nil and
type(F_A.Description)~="string")then
H=H..F_A.Identifier..": Description is not a string!"end;if
(
F_A.SuggestionText~=nil and type(F_A.SuggestionText)~="string")then
H=H..F_A.Identifier..": Suggestion is not a string!"end;if
(
F_A.SuccessText~=nil and type(F_A.SuccessText)~="string")then
H=H..F_A.Identifier..": Success is not a string!"end;if
(
F_A.FailureText~=nil and type(F_A.FailureText)~="string")then
H=H..F_A.Identifier..": Failure is not a string!"end end;if H~=""then dbg(H)return false end end;return true end
function BundleQuestGeneration.Global:DebugQuest(ZMfC)return true end;function BundleQuestGeneration.Local:Install()end
Core:RegisterBundle("BundleQuestGeneration")API=API or{}QSB=QSB or{}
BundleNonPlayerCharacter={Global={NonPlayerCharacter={Data={}},NonPlayerCharacterObjects={},LastNpcEntityID=0,LastHeroEntityID=0},Local={}}
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:New(liJ)
assert(
self==BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used from instance!')
assert(IsExisting(liJ),'entity "'..liJ..'" does not exist!')local dfggtz5r=CopyTableRecursive(self)
dfggtz5r.Data.NpcName=liJ
BundleNonPlayerCharacter.Global.NonPlayerCharacterObjects[liJ]=dfggtz5r;return dfggtz5r end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:GetInstance(H)
assert(
self==BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used from instance!')local uVezg=GetID(H)local NQqlVm0=Logic.GetEntityName(uVezg)
if
Logic.IsEntityInCategory(uVezg,EntityCategories.Soldier)==1 then
local Wd=Logic.SoldierGetLeaderEntityID(uVezg)
if IsExisting(Wd)then NQqlVm0=Logic.GetEntityName(Wd)end end;return
BundleNonPlayerCharacter.Global.NonPlayerCharacterObjects[NQqlVm0]end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:GetNpcId()
assert(
self==BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used from instance!')
return BundleNonPlayerCharacter.Global.LastNpcEntityID end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:GetHeroId()
assert(
self==BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used from instance!')
return BundleNonPlayerCharacter.Global.LastHeroEntityID end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:GetID()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')local Z7Ssj_=GetID(self.Data.NpcName)
if
Logic.IsEntityInCategory(Z7Ssj_,EntityCategories.Leader)==1 then
local K={Logic.GetSoldiersAttachedToLeader(Z7Ssj_)}if K[1]>0 then return K[2]end end;return Z7Ssj_ end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:Dispose()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self:Deactivate()BundleNonPlayerCharacter.Global.NonPlayerCharacterObjects[self.Data.NpcName]=
nil end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:Activate()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')if IsExisting(self.Data.NpcName)then
Logic.SetOnScreenInformation(self:GetID(),1)end;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:Deactivate()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')if IsExisting(self.Data.NpcName)then
Logic.SetOnScreenInformation(self:GetID(),0)end;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:IsActive()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')return
Logic.GetEntityScriptingValue(self:GetID(),6)==1 end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:Reset()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')
if IsExisting(self.Data.NpcName)then
Logic.SetOnScreenInformation(self:GetID(),0)self.Data.TalkedTo=nil end;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:HasTalkedTo()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')if self.Data.HeroName then return
self.Data.TalkedTo==GetID(self.Data.HeroName)end;return
self.Data.TalkedTo~=nil end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetDialogPartner(rp)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self.Data.HeroName=rp;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetWrongPartnerCallback(aS)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self.Data.WrongHeroCallback=aS;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetFollowDestination(XhUJT)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self.Data.FollowDestination=XhUJT;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetFollowTarget(nyo)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self.Data.FollowTarget=nyo;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetFollowAction(iig)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self.Data.FollowAction=iig;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetGuideParams(MW,PD)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self.Data.GuideDestination=MW;self.Data.GuideTarget=PD;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetGuideAction(xWD2lww)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self.Data.GuideAction=xWD2lww;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetCallback(VjnLG4)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')
assert(type(VjnLG4)=="function",'callback must be a function!')self.Data.Callback=VjnLG4;return self end;function Goal_NPC(...)return b_Goal_NPC:new(...)end
b_Goal_NPC={Name="Goal_NPC",Description={en="Goal: The hero has to talk to a non-player character.",de="Ziel: Der Held muss einen Nichtspielercharakter ansprechen."},Parameter={{ParameterType.ScriptName,en="NPC",de="NPC"},{ParameterType.ScriptName,en="Hero",de="Held"}}}
function b_Goal_NPC:GetGoalTable(r2m)return
{Objective.Distance,-65565,self.Hero,self.NPC,self}end
function b_Goal_NPC:AddParameter(dwI6,TOIbK)
if(dwI6 ==0)then self.NPC=TOIbK elseif(dwI6 ==1)then self.Hero=TOIbK;if
self.Hero=="-"then self.Hero=nil end end end;function b_Goal_NPC:GetIcon()return{14,10}end
Core:RegisterBehavior(b_Goal_NPC)
function Trigger_NPC(...)return b_Trigger_NPC:new(...)end
b_Trigger_NPC={Name="Trigger_NPC",Description={en="Trigger: Starts the quest after the npc was spoken to.",de="Ausloeser: Startet den Quest, sobald der NPC angesprochen wurde."},Parameter={{ParameterType.ScriptName,en="NPC",de="NPC"},{ParameterType.ScriptName,en="Hero",de="Held"}}}function b_Trigger_NPC:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_NPC:AddParameter(JEC156,GC8)
if(
JEC156 ==0)then self.NPC=GC8 elseif(JEC156 ==1)then self.Hero=GC8;if self.Hero=="-"then self.Hero=
nil end end end
function b_Trigger_NPC:CustomFunction()
if not IsExisting(self.NPC)then return end
if not self.NpcInstance then
local P=NonPlayerCharacter:New(self.NPC)P:SetDialogPartner(self.Hero)self.NpcInstance=P end;local bJ=self.NpcInstance:HasTalkedTo(self.Hero)
if
not bJ then if not self.NpcInstance:IsActive()then
self.NpcInstance:Activate()end end;return bJ end;function b_Trigger_NPC:Reset(s4hK)
if self.NpcInstance then self.NpcInstance:Dispose()end end
function b_Trigger_NPC:DEBUG(H)return false end;Core:RegisterBehavior(b_Trigger_NPC)
function BundleNonPlayerCharacter.Global:Install()
NonPlayerCharacter=BundleNonPlayerCharacter.Global.NonPlayerCharacter
StartSimpleJobEx(function()
for CP,QJb in
pairs(BundleNonPlayerCharacter.Global.NonPlayerCharacterObjects)do NonPlayerCharacter:Control(CP)end end)
GameCallback_OnNPCInteraction_Orig_QSB_NPC_Rewrite=GameCallback_OnNPCInteraction
GameCallback_OnNPCInteraction=function(ows6K,yp6Si3X)
GameCallback_OnNPCInteraction_Orig_QSB_NPC_Rewrite(ows6K,yp6Si3X)Quest_OnNPCInteraction(ows6K,yp6Si3X)end
Quest_OnNPCInteraction=function(f,ZiKGn)local tDn={}Logic.GetKnights(ZiKGn,tDn)local NA=0
local jmLqyFaU=Logic.WorldGetSize()
for dpk87DtF=1,#tDn,1 do
local Vnx=Logic.GetDistanceBetweenEntities(tDn[dpk87DtF],f)if Vnx<jmLqyFaU then jmLqyFaU=Vnx;NA=tDn[dpk87DtF]end end
BundleNonPlayerCharacter.Global.LastHeroEntityID=NA;local REH=NonPlayerCharacter:GetInstance(f)
BundleNonPlayerCharacter.Global.LastNpcEntityID=REH:GetID()
if REH then
if REH.Data.FollowTarget~=nil then
if REH.Data.FollowDestination then
API.Note(Logic.GetDistanceBetweenEntities(f,GetID(REH.Data.FollowDestination)))
if
Logic.GetDistanceBetweenEntities(f,GetID(REH.Data.FollowDestination))>2000 then if REH.Data.FollowAction then
REH.Data.FollowAction(self)end;return end else
if REH.Data.FollowAction then REH.Data.FollowAction(self)end;return end end
if REH.Data.GuideTarget~=nil then
local MSsv5=GetID(REH.Data.GuideDestination)
if Logic.GetDistanceBetweenEntities(f,MSsv5)>2000 then if
REH.Data.GuideAction then REH.Data.GuideAction(REH)end;return end;Logic.SetTaskList(f,TaskLists.TL_NPC_IDLE)end;REH:RotateActors()REH.Data.TalkedTo=NA
if REH:HasTalkedTo()then
REH:Deactivate()
if REH.Data.Callback then REH.Data.Callback(REH,NA)end else
if REH.Data.WrongHeroCallback then REH.Data.WrongHeroCallback(REH,NA)end end end end
function QuestTemplate:RemoveQuestMarkers()
for pDUYq=1,self.Objectives[0]do
if
self.Objectives[pDUYq].Type==Objective.Distance then
if

(
(
type(self.Objectives[pDUYq].Data[1])=="number"and
self.Objectives[pDUYq].Data[1]>0)or(type(self.Objectives[pDUYq].Data[1])~=
"number"))and self.Objectives[pDUYq].Data[4]then
DestroyQuestMarker(self.Objectives[pDUYq].Data[2])end end end end
function QuestTemplate:ShowQuestMarkers()
for dt=1,self.Objectives[0]do
if self.Objectives[dt].Type==
Objective.Distance then
if

(
(
type(self.Objectives[dt].Data[1])=="number"and
self.Objectives[dt].Data[1]>0)or
(type(self.Objectives[dt].Data[1])~="number"))and self.Objectives[dt].Data[4]then
ShowQuestMarker(self.Objectives[dt].Data[2])end end end end
QuestTemplate.IsObjectiveCompleted_QSBU_NPC_Rewrite=QuestTemplate.IsObjectiveCompleted
QuestTemplate.IsObjectiveCompleted=function(Tx,xZ)local M=xZ.Type;local FprU1J=xZ.Data;if xZ.Completed~=nil then
return xZ.Completed end
if M~=Objective.Distance then return
Tx:IsObjectiveCompleted_QSBU_NPC_Rewrite(xZ)else
if FprU1J[1]==-65565 then
if
not IsExisting(FprU1J[3])then API.Dbg(FprU1J[3].." is dead! :(")
xZ.Completed=false else if not FprU1J[4].NpcInstance then
local a2W=NonPlayerCharacter:New(FprU1J[3])a2W:SetDialogPartner(FprU1J[2])
FprU1J[4].NpcInstance=a2W end;if
FprU1J[4].NpcInstance:HasTalkedTo(FprU1J[2])then xZ.Completed=true end
if not xZ.Completed then if not
FprU1J[4].NpcInstance:IsActive()then
FprU1J[4].NpcInstance:Activate()end end end else return Tx:IsObjectiveCompleted_QSBU_NPC_Rewrite(xZ)end end end end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:RotateActors()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')
local W6sFOn=Logic.EntityGetPlayer(BundleNonPlayerCharacter.Global.LastHeroEntityID)local JjyRs={}Logic.GetKnights(W6sFOn,JjyRs)
for jn1VT=1,#JjyRs,1 do
if
Logic.GetDistanceBetweenEntities(JjyRs[jn1VT],BundleNonPlayerCharacter.Global.LastNpcEntityID)<3000 then
local l6aapg,CvDYCml,XZAYA=Logic.EntityGetPos(JjyRs[jn1VT])if Logic.IsEntityMoving(JjyRs[jn1VT])then
Logic.MoveEntity(JjyRs[jn1VT],l6aapg,CvDYCml)end
LookAt(JjyRs[jn1VT],self.Data.NpcName)end end;local jl1YR7X=0;if Logic.IsKnight(GetID(self.Data.NpcName))then
jl1YR7X=15 end
LookAt(self.Data.NpcName,BundleNonPlayerCharacter.Global.LastHeroEntityID,jl1YR7X)
LookAt(BundleNonPlayerCharacter.Global.LastHeroEntityID,self.Data.NpcName,15)end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:Control(FU)
assert(
self==BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used from instance!')if not IsExisting(FU)then return end
local tjNz8eMg=NonPlayerCharacter:GetInstance(FU)if not tjNz8eMg then return end
if not tjNz8eMg:IsActive()then return end
if tjNz8eMg.Data.FollowTarget~=nil then local X=tjNz8eMg:GetID()
local Lxcxu8m1=GetID(tjNz8eMg.Data.FollowTarget)local fHLa=Logic.GetDistanceBetweenEntities(X,Lxcxu8m1)
local C3f=400;if
Logic.IsEntityInCategory(X,EntityCategories.Hero)==1 then C3f=800 end;if fHLa<C3f or fHLa>3500 then
Logic.SetTaskList(X,TaskLists.TL_NPC_IDLE)return end
if fHLa>=C3f then
local wHNlhIoT,we,uMBZO=Logic.EntityGetPos(Lxcxu8m1)Logic.MoveSettler(X,wHNlhIoT,we)return end end
if tjNz8eMg.Data.GuideTarget~=nil then local c8x=tjNz8eMg:GetID()
local E9C=GetID(tjNz8eMg.Data.GuideTarget)local Ta8E=GetID(tjNz8eMg.Data.GuideDestination)
local SKju4zT9=Logic.GetDistanceBetweenEntities(c8x,E9C)local Dw2=Logic.GetDistanceBetweenEntities(c8x,Ta8E)
if
Dw2 >2000 then
if
SKju4zT9 <1500 and not Logic.IsEntityMoving(c8x)then local sGI9IM7,zX_b,Cy=Logic.EntityGetPos(Ta8E)
Logic.MoveSettler(c8x,sGI9IM7,zX_b)elseif SKju4zT9 >3000 and Logic.IsEntityMoving(c8x)then
local ZzZ,e_w,RqZA1A9s=Logic.EntityGetPos(c8x)Logic.MoveSettler(c8x,ZzZ,e_w)end end end end
function BundleNonPlayerCharacter.Local:Install()g_CurrentDisplayedQuestID=0
GUI_Interaction.DisplayQuestObjective_Orig_QSBU_NPC_Rewrite=GUI_Interaction.DisplayQuestObjective
GUI_Interaction.DisplayQuestObjective=function(C,ptjB7)local bx=Network.GetDesiredLanguage()if
bx~="de"then bx="en"end;local KGas=tonumber(C)if KGas then C=KGas end
local m,S1f=GUI_Interaction.GetPotentialSubQuestAndType(C)local ZTs462="/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives"
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)local xJ8Jb;local NPMnBOO;local d_t=Quests[C]local KagsBWw;if
d_t~=nil and type(d_t)=="table"then KagsBWw=d_t.Identifier end;local BCBpF9={}
g_CurrentDisplayedQuestID=C
if S1f==Objective.Distance then xJ8Jb=ZTs462 .."/List"
NPMnBOO=Wrapped_GetStringTableText(C,"UI_Texts/QuestInteraction")local sH={}
if m.Objectives[1].Data[1]==-65565 then
xJ8Jb=ZTs462 .."/Distance"
NPMnBOO=Wrapped_GetStringTableText(C,"UI_Texts/QuestMoveHere")SetIcon(xJ8Jb.."/QuestTypeIcon",{7,10})
local uIcE5O=GetEntityId(m.Objectives[1].Data[2])local P=Logic.GetEntityType(uIcE5O)
local b3M3x=g_TexturePositions.Entities[P]if
m.Objectives[1].Data[1]==-65567 or not b3M3x then b3M3x={16,12}end
SetIcon(xJ8Jb.."/IconMover",b3M3x)
local Uwyi2=GetEntityId(m.Objectives[1].Data[3])local bD=Logic.GetEntityType(Uwyi2)
local JqKgkiH=g_TexturePositions.Entities[bD]if not JqKgkiH then JqKgkiH={14,10}end
local DQJpOw=xJ8Jb.."/IconTarget"local u=xJ8Jb.."/TargetPlayerColor"
SetIcon(DQJpOw,JqKgkiH)XGUIEng.SetMaterialColor(u,0,255,255,255,0)SetIcon(xJ8Jb..
"/QuestTypeIcon",{16,12})
local _r2G={de="Gespräch beginnen",en="Start conversation"}NPMnBOO=_r2G[bx]
XGUIEng.SetText(xJ8Jb.."/Caption","{center}"..NPMnBOO)XGUIEng.ShowWidget(xJ8Jb,1)else
GUI_Interaction.DisplayQuestObjective_Orig_QSBU_NPC_Rewrite(C,ptjB7)end else
GUI_Interaction.DisplayQuestObjective_Orig_QSBU_NPC_Rewrite(C,ptjB7)end end
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_QSBU_NPC_Rewrite=GUI_Interaction.GetEntitiesOrTerritoryListForQuest
GUI_Interaction.GetEntitiesOrTerritoryListForQuest=function(ydY6,e)local OX9Pjj={}local h1=true
if e==Objective.Distance then
if
ydY6.Objectives[1].Data[1]==-65565 then
local m1HC9s7=GetEntityId(ydY6.Objectives[1].Data[3])table.insert(OX9Pjj,m1HC9s7)else return
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_QSBU_NPC_Rewrite(ydY6,e)end else return
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_QSBU_NPC_Rewrite(ydY6,e)end;return OX9Pjj,h1 end end;Core:RegisterBundle("BundleNonPlayerCharacter")API=API or
{}QSB=QSB or{}QSB.RequirementTooltipTypes={}
QSB.ConsumedGoodsCounter={}BundleKnightTitleRequirements={Global={},Local={Data={}}}function BundleKnightTitleRequirements.Global:Install()
self:OverwriteConsumedGoods()end
function BundleKnightTitleRequirements.Global:RegisterConsumedGoods(WeyidY,vS1)QSB.ConsumedGoodsCounter[WeyidY]=
QSB.ConsumedGoodsCounter[WeyidY]or{}QSB.ConsumedGoodsCounter[WeyidY][vS1]=
QSB.ConsumedGoodsCounter[WeyidY][vS1]or 0;QSB.ConsumedGoodsCounter[WeyidY][vS1]=
QSB.ConsumedGoodsCounter[WeyidY][vS1]+1 end
function BundleKnightTitleRequirements.Global:OverwriteConsumedGoods()
GameCallback_ConsumeGood_Orig_QSB_Requirements=GameCallback_ConsumeGood
GameCallback_ConsumeGood=function(cQ,i0bPk,eeu)
GameCallback_ConsumeGood_Orig_QSB_Requirements(cQ,i0bPk,eeu)local RcM=Logic.EntityGetPlayer(cQ)
BundleKnightTitleRequirements.Global:RegisterConsumedGoods(RcM,i0bPk)
Logic.ExecuteInLuaLocalState([[
            BundleKnightTitleRequirements.Global:RegisterConsumedGoods(
                ]]..RcM..[[, ]]..i0bPk..
[[
            );
        ]])end end
function BundleKnightTitleRequirements.Local:Install()
self:OverwriteTooltips()self:InitTexturePositions()
self:OverwriteUpdateRequirements()self:OverwritePromotionCelebration()end
function BundleKnightTitleRequirements.Local:RegisterConsumedGoods(HVXI,dft6l_U)QSB.ConsumedGoodsCounter[HVXI]=
QSB.ConsumedGoodsCounter[HVXI]or{}QSB.ConsumedGoodsCounter[HVXI][dft6l_U]=
QSB.ConsumedGoodsCounter[HVXI][dft6l_U]or 0;QSB.ConsumedGoodsCounter[HVXI][dft6l_U]=
QSB.ConsumedGoodsCounter[HVXI][dft6l_U]+1 end
function BundleKnightTitleRequirements.Local:InitTexturePositions()
g_TexturePositions.EntityCategories[EntityCategories.GC_Food_Supplier]={1,1}
g_TexturePositions.EntityCategories[EntityCategories.GC_Clothes_Supplier]={1,2}
g_TexturePositions.EntityCategories[EntityCategories.GC_Hygiene_Supplier]={16,1}
g_TexturePositions.EntityCategories[EntityCategories.GC_Entertainment_Supplier]={1,4}
g_TexturePositions.EntityCategories[EntityCategories.GC_Luxury_Supplier]={16,3}
g_TexturePositions.EntityCategories[EntityCategories.GC_Weapon_Supplier]={1,7}
g_TexturePositions.EntityCategories[EntityCategories.GC_Medicine_Supplier]={2,10}
g_TexturePositions.EntityCategories[EntityCategories.Outpost]={12,3}
g_TexturePositions.EntityCategories[EntityCategories.Spouse]={5,15}
g_TexturePositions.EntityCategories[EntityCategories.CattlePasture]={3,16}
g_TexturePositions.EntityCategories[EntityCategories.SheepPasture]={4,1}
g_TexturePositions.EntityCategories[EntityCategories.Soldier]={7,12}
g_TexturePositions.EntityCategories[EntityCategories.GrainField]={14,2}
g_TexturePositions.EntityCategories[EntityCategories.OuterRimBuilding]={3,4}
g_TexturePositions.EntityCategories[EntityCategories.CityBuilding]={8,1}
g_TexturePositions.EntityCategories[EntityCategories.Range]={9,8}
g_TexturePositions.EntityCategories[EntityCategories.Melee]={9,7}
g_TexturePositions.EntityCategories[EntityCategories.SiegeEngine]={2,15}
g_TexturePositions.Entities[Entities.B_Outpost]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_AS]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_ME]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_NA]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_NE]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_SE]={12,3}
g_TexturePositions.Entities[Entities.B_Cathedral_Big]={3,12}
g_TexturePositions.Entities[Entities.U_MilitaryBallista]={10,5}
g_TexturePositions.Entities[Entities.U_Trebuchet]={9,1}
g_TexturePositions.Entities[Entities.U_SiegeEngineCart]={9,4}
g_TexturePositions.Needs[Needs.Medicine]={2,10}
g_TexturePositions.Technologies[Technologies.R_Castle_Upgrade_1]={4,7}
g_TexturePositions.Technologies[Technologies.R_Castle_Upgrade_2]={4,7}
g_TexturePositions.Technologies[Technologies.R_Castle_Upgrade_3]={4,7}
g_TexturePositions.Technologies[Technologies.R_Cathedral_Upgrade_1]={4,5}
g_TexturePositions.Technologies[Technologies.R_Cathedral_Upgrade_2]={4,5}
g_TexturePositions.Technologies[Technologies.R_Cathedral_Upgrade_3]={4,5}
g_TexturePositions.Technologies[Technologies.R_Storehouse_Upgrade_1]={4,6}
g_TexturePositions.Technologies[Technologies.R_Storehouse_Upgrade_2]={4,6}
g_TexturePositions.Technologies[Technologies.R_Storehouse_Upgrade_3]={4,6}
g_TexturePositions.Buffs=g_TexturePositions.Buffs or{}
g_TexturePositions.Buffs[Buffs.Buff_ClothesDiversity]={1,2}
g_TexturePositions.Buffs[Buffs.Buff_EntertainmentDiversity]={1,4}
g_TexturePositions.Buffs[Buffs.Buff_FoodDiversity]={1,1}
g_TexturePositions.Buffs[Buffs.Buff_HygieneDiversity]={1,3}
g_TexturePositions.Buffs[Buffs.Buff_Colour]={5,11}
g_TexturePositions.Buffs[Buffs.Buff_Entertainers]={5,12}
g_TexturePositions.Buffs[Buffs.Buff_ExtraPayment]={1,8}
g_TexturePositions.Buffs[Buffs.Buff_Sermon]={4,14}
g_TexturePositions.Buffs[Buffs.Buff_Spice]={5,10}
g_TexturePositions.Buffs[Buffs.Buff_NoTaxes]={1,6}
if Framework.GetGameExtraNo()~=0 then
g_TexturePositions.Buffs[Buffs.Buff_Gems]={1,1,1}
g_TexturePositions.Buffs[Buffs.Buff_MusicalInstrument]={1,3,1}
g_TexturePositions.Buffs[Buffs.Buff_Olibanum]={1,2,1}end
g_TexturePositions.GoodCategories=g_TexturePositions.GoodCategories or{}
g_TexturePositions.GoodCategories[GoodCategories.GC_Ammunition]={10,6}
g_TexturePositions.GoodCategories[GoodCategories.GC_Animal]={4,16}
g_TexturePositions.GoodCategories[GoodCategories.GC_Clothes]={1,2}
g_TexturePositions.GoodCategories[GoodCategories.GC_Document]={5,6}
g_TexturePositions.GoodCategories[GoodCategories.GC_Entertainment]={1,4}
g_TexturePositions.GoodCategories[GoodCategories.GC_Food]={1,1}
g_TexturePositions.GoodCategories[GoodCategories.GC_Gold]={1,8}
g_TexturePositions.GoodCategories[GoodCategories.GC_Hygiene]={16,1}
g_TexturePositions.GoodCategories[GoodCategories.GC_Luxury]={16,3}
g_TexturePositions.GoodCategories[GoodCategories.GC_Medicine]={2,10}
g_TexturePositions.GoodCategories[GoodCategories.GC_None]={15,16}
g_TexturePositions.GoodCategories[GoodCategories.GC_RawFood]={3,4}
g_TexturePositions.GoodCategories[GoodCategories.GC_RawMedicine]={2,2}
g_TexturePositions.GoodCategories[GoodCategories.GC_Research]={5,6}
g_TexturePositions.GoodCategories[GoodCategories.GC_Resource]={3,4}
g_TexturePositions.GoodCategories[GoodCategories.GC_Tools]={4,12}
g_TexturePositions.GoodCategories[GoodCategories.GC_Water]={1,16}
g_TexturePositions.GoodCategories[GoodCategories.GC_Weapon]={8,5}end
function BundleKnightTitleRequirements.Local:OverwriteUpdateRequirements()
GUI_Knight.UpdateRequirements=function()
local VZwV1w=BundleKnightTitleRequirements.Local.Data.RequirementWidgets;local IEdKtSVb=1;local bYNIMy6=GUI.GetPlayerID()
local Dq=Logic.GetKnightTitle(bYNIMy6)local OHKA9l=Dq+1;local uqE=Logic.GetKnightID(bYNIMy6)
local NTOa=Logic.GetEntityType(uqE)
XGUIEng.SetText("/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/NextKnightTitle","{center}"..
GUI_Knight.GetTitleNameByTitleID(NTOa,OHKA9l))
XGUIEng.SetText("/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/NextKnightTitleWhite","{center}"..
GUI_Knight.GetTitleNameByTitleID(NTOa,OHKA9l))
if KnightTitleRequirements[OHKA9l].Settlers~=nil then SetIcon(
VZwV1w[IEdKtSVb].."/Icon",{5,16})
local rRV,Fwg71O2,TKH=DoesNeededNumberOfSettlersForKnightTitleExist(bYNIMy6,OHKA9l)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..Fwg71O2 .."/"..TKH)if rRV then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)QSB.RequirementTooltipTypes[IEdKtSVb]="Settlers"
IEdKtSVb=IEdKtSVb+1 end
if
KnightTitleRequirements[OHKA9l].RichBuildings~=nil then
SetIcon(VZwV1w[IEdKtSVb].."/Icon",{8,4})
local EuFyU,ai3L78q,oxs30=DoNeededNumberOfRichBuildingsForKnightTitleExist(bYNIMy6,OHKA9l)if oxs30 ==-1 then
oxs30=Logic.GetNumberOfPlayerEntitiesInCategory(bYNIMy6,EntityCategories.CityBuilding)end
XGUIEng.SetText(
VZwV1w[IEdKtSVb].."/Amount","{center}"..ai3L78q.."/"..oxs30)if EuFyU then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)QSB.RequirementTooltipTypes[IEdKtSVb]="RichBuildings"IEdKtSVb=
IEdKtSVb+1 end
if
KnightTitleRequirements[OHKA9l].Headquarters~=nil then
SetIcon(VZwV1w[IEdKtSVb].."/Icon",{4,7})
local whe,OZHTkyI,U=DoNeededSpecialBuildingUpgradeForKnightTitleExist(bYNIMy6,OHKA9l,EntityCategories.Headquarters)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..
OZHTkyI+1 .."/"..U+1)if whe then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)QSB.RequirementTooltipTypes[IEdKtSVb]="Headquarters"IEdKtSVb=
IEdKtSVb+1 end
if
KnightTitleRequirements[OHKA9l].Storehouse~=nil then
SetIcon(VZwV1w[IEdKtSVb].."/Icon",{4,6})
local KIArgE,gQSGi,vM5wao42=DoNeededSpecialBuildingUpgradeForKnightTitleExist(bYNIMy6,OHKA9l,EntityCategories.Storehouse)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..
gQSGi+1 .."/"..vM5wao42+1)if KIArgE then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)QSB.RequirementTooltipTypes[IEdKtSVb]="Storehouse"IEdKtSVb=
IEdKtSVb+1 end
if
KnightTitleRequirements[OHKA9l].Cathedrals~=nil then
SetIcon(VZwV1w[IEdKtSVb].."/Icon",{4,5})
local JU,Zkt6jmp,hWNEb9E8=DoNeededSpecialBuildingUpgradeForKnightTitleExist(bYNIMy6,OHKA9l,EntityCategories.Cathedrals)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..Zkt6jmp+1 ..
"/"..hWNEb9E8+1)if JU then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)QSB.RequirementTooltipTypes[IEdKtSVb]="Cathedrals"IEdKtSVb=
IEdKtSVb+1 end
if
KnightTitleRequirements[OHKA9l].FullDecoratedBuildings~=nil then
local A3O8n,tCrogd,o=DoNeededNumberOfFullDecoratedBuildingsForKnightTitleExist(bYNIMy6,OHKA9l)
local MyM=KnightTitleRequirements[OHKA9l].FullDecoratedBuildings
SetIcon(VZwV1w[IEdKtSVb].."/Icon",g_TexturePositions.Needs[Needs.Wealth])
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..tCrogd.."/"..o)if A3O8n then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)
QSB.RequirementTooltipTypes[IEdKtSVb]="FullDecoratedBuildings"IEdKtSVb=IEdKtSVb+1 end
if
KnightTitleRequirements[OHKA9l].Reputation~=nil then
SetIcon(VZwV1w[IEdKtSVb].."/Icon",{5,14})
local x9j,J0Vv9NxA,nZ6q3=DoesNeededCityReputationForKnightTitleExist(bYNIMy6,OHKA9l)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..J0Vv9NxA.."/"..nZ6q3)if x9j then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)QSB.RequirementTooltipTypes[IEdKtSVb]="Reputation"IEdKtSVb=
IEdKtSVb+1 end
if KnightTitleRequirements[OHKA9l].Goods~=nil then
for yCPMWnq=1,#
KnightTitleRequirements[OHKA9l].Goods do
local q=KnightTitleRequirements[OHKA9l].Goods[yCPMWnq][1]
SetIcon(VZwV1w[IEdKtSVb].."/Icon",g_TexturePositions.Goods[q])
local v7H3oo3o,cuLNsH,_Aq3vAF5=DoesNeededNumberOfGoodTypesForKnightTitleExist(bYNIMy6,OHKA9l,yCPMWnq)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..cuLNsH.."/".._Aq3vAF5)if v7H3oo3o then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)
QSB.RequirementTooltipTypes[IEdKtSVb]="Goods"..yCPMWnq;IEdKtSVb=IEdKtSVb+1 end end
if KnightTitleRequirements[OHKA9l].Category~=nil then
for tz=1,#
KnightTitleRequirements[OHKA9l].Category do
local mb4gzO=KnightTitleRequirements[OHKA9l].Category[tz][1]
SetIcon(VZwV1w[IEdKtSVb].."/Icon",g_TexturePositions.EntityCategories[mb4gzO])
local wsM,sRC3w,Ww=DoesNeededNumberOfEntitiesInCategoryForKnightTitleExist(bYNIMy6,OHKA9l,tz)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..sRC3w.."/"..Ww)if wsM then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)
local W15={Logic.GetEntityTypesInCategory(mb4gzO)}
if
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.GC_Weapon_Supplier)==1 then QSB.RequirementTooltipTypes[IEdKtSVb]=
"Weapons"..tz elseif
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.SiegeEngine)==1 then QSB.RequirementTooltipTypes[IEdKtSVb]=
"HeavyWeapons"..tz elseif
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.Spouse)==1 then
QSB.RequirementTooltipTypes[IEdKtSVb]="Spouse"..tz elseif
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.Worker)==1 then QSB.RequirementTooltipTypes[IEdKtSVb]="Worker"..tz elseif
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.Soldier)==1 then QSB.RequirementTooltipTypes[IEdKtSVb]=
"Soldiers"..tz elseif
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.Outpost)==1 then QSB.RequirementTooltipTypes[IEdKtSVb]=
"Outposts"..tz elseif
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.CattlePasture)==1 then QSB.RequirementTooltipTypes[IEdKtSVb]=
"Cattle"..tz elseif
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.SheepPasture)==1 then QSB.RequirementTooltipTypes[IEdKtSVb]=
"Sheep"..tz elseif
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.CityBuilding)==1 then QSB.RequirementTooltipTypes[IEdKtSVb]=
"CityBuilding"..tz elseif
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.OuterRimBuilding)==1 then QSB.RequirementTooltipTypes[IEdKtSVb]=
"OuterRimBuilding"..tz elseif
Logic.IsEntityTypeInCategory(W15[1],EntityCategories.AttackableBuilding)==1 then QSB.RequirementTooltipTypes[IEdKtSVb]=
"Buildings"..tz else QSB.RequirementTooltipTypes[IEdKtSVb]=
"EntityCategoryDefault"..tz end;IEdKtSVb=IEdKtSVb+1 end end
if KnightTitleRequirements[OHKA9l].Entities~=nil then
for T=1,#
KnightTitleRequirements[OHKA9l].Entities do
local U=KnightTitleRequirements[OHKA9l].Entities[T][1]
SetIcon(VZwV1w[IEdKtSVb].."/Icon",g_TexturePositions.Entities[U])
local tzp,YexFk,GKdZ=DoesNeededNumberOfEntitiesOfTypeForKnightTitleExist(bYNIMy6,OHKA9l,T)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..YexFk.."/"..GKdZ)if tzp then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)QSB.RequirementTooltipTypes[IEdKtSVb]="Entities"..T;IEdKtSVb=
IEdKtSVb+1 end end
if KnightTitleRequirements[OHKA9l].Consume~=nil then
for zgxPd3=1,#
KnightTitleRequirements[OHKA9l].Consume do
local tSqhJw=KnightTitleRequirements[OHKA9l].Consume[zgxPd3][1]
SetIcon(VZwV1w[IEdKtSVb].."/Icon",g_TexturePositions.Goods[tSqhJw])
local hWI,_FyE8,kGD55u=DoNeededNumberOfConsumedGoodsForKnightTitleExist(bYNIMy6,OHKA9l,zgxPd3)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}".._FyE8 .."/"..kGD55u)if hWI then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)
QSB.RequirementTooltipTypes[IEdKtSVb]="Consume"..zgxPd3;IEdKtSVb=IEdKtSVb+1 end end
if KnightTitleRequirements[OHKA9l].Products~=nil then
for gAub_N=1,#
KnightTitleRequirements[OHKA9l].Products do
local ZlbS1=KnightTitleRequirements[OHKA9l].Products[gAub_N][1]
SetIcon(VZwV1w[IEdKtSVb].."/Icon",g_TexturePositions.GoodCategories[ZlbS1])
local DUHEU_Jk,xZ,qyMV=DoNumberOfProductsInCategoryExist(bYNIMy6,OHKA9l,gAub_N)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..xZ.."/"..qyMV)if DUHEU_Jk then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)
QSB.RequirementTooltipTypes[IEdKtSVb]="Products"..gAub_N;IEdKtSVb=IEdKtSVb+1 end end
if KnightTitleRequirements[OHKA9l].Buff~=nil then
for Q0=1,#
KnightTitleRequirements[OHKA9l].Buff do
local PvWYOp=KnightTitleRequirements[OHKA9l].Buff[Q0]
SetIcon(VZwV1w[IEdKtSVb].."/Icon",g_TexturePositions.Buffs[PvWYOp])
local pcyPdjNz=DoNeededDiversityBuffForKnightTitleExist(bYNIMy6,OHKA9l,Q0)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","")if pcyPdjNz then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)QSB.RequirementTooltipTypes[IEdKtSVb]="Buff"..Q0;IEdKtSVb=
IEdKtSVb+1 end end
if KnightTitleRequirements[OHKA9l].Custom~=nil then
for k9=1,#
KnightTitleRequirements[OHKA9l].Custom do
local J=KnightTitleRequirements[OHKA9l].Custom[k9][2]
BundleKnightTitleRequirements.Local:RequirementIcon(VZwV1w[IEdKtSVb]..
"/Icon",J)
local AkgIQ,QD,Q4v=DoCustomFunctionForKnightTitleSucceed(bYNIMy6,OHKA9l,k9)if QD and Q4v then
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..QD.."/"..Q4v)else
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","")end
if AkgIQ then XGUIEng.ShowWidget(
VZwV1w[IEdKtSVb].."/Done",1)else XGUIEng.ShowWidget(
VZwV1w[IEdKtSVb].."/Done",0)end;XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)QSB.RequirementTooltipTypes[IEdKtSVb]=
"Custom"..k9;IEdKtSVb=IEdKtSVb+1 end end
if
KnightTitleRequirements[OHKA9l].DecoratedBuildings~=nil then
for K44gmgP8=1,#KnightTitleRequirements[OHKA9l].DecoratedBuildings
do
local JVWtlQb=KnightTitleRequirements[OHKA9l].DecoratedBuildings[K44gmgP8][1]
SetIcon(VZwV1w[IEdKtSVb].."/Icon",g_TexturePositions.Goods[JVWtlQb])
local lN,GuL1gt1,nhKV=DoNeededNumberOfDecoratedBuildingsForKnightTitleExist(bYNIMy6,OHKA9l,K44gmgP8)
XGUIEng.SetText(VZwV1w[IEdKtSVb].."/Amount","{center}"..GuL1gt1 .."/"..nhKV)if lN then
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",1)else
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb].."/Done",0)end
XGUIEng.ShowWidget(VZwV1w[IEdKtSVb],1)
QSB.RequirementTooltipTypes[IEdKtSVb]="DecoratedBuildings"..K44gmgP8;IEdKtSVb=IEdKtSVb+1 end end
for wQ=IEdKtSVb,6 do XGUIEng.ShowWidget(VZwV1w[wQ],0)end end end
function BundleKnightTitleRequirements.Local:OverwritePromotionCelebration()
StartKnightsPromotionCelebration=function(LPZI6dP,CPD,bkF)if

LPZI6dP~=GUI.GetPlayerID()or Logic.GetTime()<5 then return end
local P=Logic.GetMarketplace(LPZI6dP)
if bkF==1 then local h4sBu8xR=Logic.GetKnightID(LPZI6dP)local UN64aE
repeat UN64aE=1+
XGUIEng.GetRandom(3)until UN64aE~=g_LastGotPromotionMessageRandom;g_LastGotPromotionMessageRandom=UN64aE
local sSG="Title_GotPromotion"..UN64aE
LocalScriptCallback_QueueVoiceMessage(LPZI6dP,sSG,false,LPZI6dP)GUI.StartFestival(LPZI6dP,1)end;local q=QSB.ConsumedGoodsCounter[LPZI6dP]QSB.ConsumedGoodsCounter[LPZI6dP]=
q or{}
for uqo,p in
pairs(QSB.ConsumedGoodsCounter[LPZI6dP])do QSB.ConsumedGoodsCounter[LPZI6dP][uqo]=0 end
GUI.SendScriptCommand([[
            local Consume = QSB.ConsumedGoodsCounter[]]..
LPZI6dP..
[[];
            QSB.ConsumedGoodsCounter[]]..
LPZI6dP..

[[] = Consume or {};
            for k,v in pairs(QSB.ConsumedGoodsCounter[]]..LPZI6dP..
[[]) do
                QSB.ConsumedGoodsCounter[]]..LPZI6dP..[[][k] = 0;
            end
        ]])
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopCenter/KnightTitleMenuBig",0)g_WantsPromotionMessageInterval=30;g_TimeOfPromotionPossible=nil end end
function BundleKnightTitleRequirements.Local:OverwriteTooltips()
GUI_Tooltip.SetNameAndDescription_Orig_QSB_Requirements=GUI_Tooltip.SetNameAndDescription
GUI_Tooltip.SetNameAndDescription=function(gIK41Kb,eZyNVj,UoWel1_,g,B)local qcuvjhEy=XGUIEng.GetCurrentWidgetID()
local MLW=GUI.GetSelectedEntity()local nuC7O=GUI.GetPlayerID()
for MdyAJV,_ in
pairs(BundleKnightTitleRequirements.Local.Data.RequirementWidgets)do
if _.."/Icon"==XGUIEng.GetWidgetPathByID(qcuvjhEy)then
local BI7w=QSB.RequirementTooltipTypes[MdyAJV]
local xDtU=tonumber(string.sub(BI7w,string.len(BI7w)))if xDtU~=nil then
BI7w=string.sub(BI7w,1,string.len(BI7w)-1)end
BundleKnightTitleRequirements.Local:RequirementTooltipWrapped(BI7w,xDtU)return end end
GUI_Tooltip.SetNameAndDescription_Orig_QSB_Requirements(gIK41Kb,eZyNVj,UoWel1_,g,B)end
GUI_Knight.RequiredGoodTooltip=function()local DloKju2I=QSB.RequirementTooltipTypes[2]
local zJCi6_s=tonumber(string.sub(DloKju2I,string.len(DloKju2I)))if zJCi6_s~=nil then
DloKju2I=string.sub(DloKju2I,1,string.len(DloKju2I)-1)end
BundleKnightTitleRequirements.Local:RequirementTooltipWrapped(DloKju2I,zJCi6_s)end
if Framework.GetGameExtraNo()~=0 then
BundleKnightTitleRequirements.Local.Data.BuffTypeNames[Buffs.Buff_Gems]={de="Edelsteine beschaffen",en="Obtain gems"}
BundleKnightTitleRequirements.Local.Data.BuffTypeNames[Buffs.Buff_Olibanum]={de="Weihrauch beschaffen",en="Obtain olibanum"}
BundleKnightTitleRequirements.Local.Data.BuffTypeNames[Buffs.Buff_MusicalInstrument]={de="Muskinstrumente beschaffen",en="Obtain instruments"}end end
function BundleKnightTitleRequirements.Local:RequirementIcon(Pd,AUXpi)
if
type(AUXpi)=="table"then
if type(AUXpi[3])=="string"then local A=1
if XGUIEng.IsButton(Pd)==1 then A=7 end;local jI8dau,nWm,BhsFPhR1,su;jI8dau=(AUXpi[1]-1)*64;BhsFPhR1=
(AUXpi[2]-1)*64;nWm=(AUXpi[1])*64
su=(AUXpi[2])*64;XGUIEng.SetMaterialAlpha(Pd,A,255)XGUIEng.SetMaterialTexture(Pd,A,
AUXpi[3].."big.png")
XGUIEng.SetMaterialUV(Pd,A,jI8dau,BhsFPhR1,nWm,su)else SetIcon(Pd,AUXpi)end else local WjCwOor={GUI.GetScreenSize()}local xl=330;if WjCwOor[2]>=800 then
xl=260 end;if WjCwOor[2]>=1000 then xl=210 end
XGUIEng.SetMaterialAlpha(Pd,1,255)XGUIEng.SetMaterialTexture(Pd,1,_file)
XGUIEng.SetMaterialUV(Pd,1,0,0,xl,xl)end end
function BundleKnightTitleRequirements.Local:RequirementTooltip(aLV1jBfR,Fct)
local NoLD="/InGame/Root/Normal/TooltipNormal"local fFfqpYo=XGUIEng.GetWidgetID(NoLD)
local YqXOJ=XGUIEng.GetWidgetID(NoLD.."/FadeIn/Name")
local DjTE=XGUIEng.GetWidgetID(NoLD.."/FadeIn/Text")
local _YHW_x=XGUIEng.GetWidgetID(NoLD.."/FadeIn/BG")local MK=XGUIEng.GetWidgetID(NoLD.."/FadeIn")
local fRlh=XGUIEng.GetCurrentWidgetID()GUI_Tooltip.ResizeBG(_YHW_x,DjTE)local jSmoKB9j={_YHW_x}
GUI_Tooltip.SetPosition(fFfqpYo,jSmoKB9j,fRlh)GUI_Tooltip.FadeInTooltip(MK)
XGUIEng.SetText(YqXOJ,"{center}"..aLV1jBfR)XGUIEng.SetText(DjTE,Fct)
local q_=XGUIEng.GetTextHeight(DjTE,true)local b50_fTY,lmAOU7iA=XGUIEng.GetWidgetSize(DjTE)
XGUIEng.SetWidgetSize(DjTE,b50_fTY,q_)end
function BundleKnightTitleRequirements.Local:RequirementTooltipWrapped(w3,wsT)
local u=(
Network.GetDesiredLanguage()=="de"and"de")or"en"local Ep=GUI.GetPlayerID()local G=Logic.GetKnightTitle(Ep)
local q=""local m7hp=""
if
w3 =="Consume"or w3 =="Goods"or w3 =="DecoratedBuildings"then
local Wt1=KnightTitleRequirements[G+1][w3][wsT][1]local M7qPU=Logic.GetGoodTypeName(Wt1)
local b9e=XGUIEng.GetStringTableText("UI_ObjectNames/"..M7qPU)if b9e==nil then b9e="Goods."..M7qPU end;q=b9e
m7hp=BundleKnightTitleRequirements.Local.Data.Description[w3].Text elseif w3 =="Products"then
local oiJzpt=BundleKnightTitleRequirements.Local.Data.GoodCategoryNames
local Hib8uK4=KnightTitleRequirements[G+1][w3][wsT][1]local I6eCb68=oiJzpt[Hib8uK4][u]if I6eCb68 ==nil then
I6eCb68="ERROR: Name missng!"end;q=I6eCb68
m7hp=BundleKnightTitleRequirements.Local.Data.Description[w3].Text elseif w3 =="Entities"then
local jI_=KnightTitleRequirements[G+1][w3][wsT][1]local HmxR=Logic.GetEntityTypeName(jI_)
local MXF=XGUIEng.GetStringTableText("Names/"..HmxR)if MXF==nil then MXF="Entities."..HmxR end;q=MXF
m7hp=BundleKnightTitleRequirements.Local.Data.Description[w3].Text elseif w3 =="Custom"then
local aydCLh1=KnightTitleRequirements[G+1].Custom[wsT]q=aydCLh1[3]m7hp=aydCLh1[4]elseif w3 =="Buff"then
local t0qew=BundleKnightTitleRequirements.Local.Data.BuffTypeNames
local gB=KnightTitleRequirements[G+1][w3][wsT]local ja_b0Jkx=t0qew[gB][u]
if ja_b0Jkx==nil then ja_b0Jkx="ERROR: Name missng!"end;q=ja_b0Jkx
m7hp=BundleKnightTitleRequirements.Local.Data.Description[w3].Text else
q=BundleKnightTitleRequirements.Local.Data.Description[w3].Title
m7hp=BundleKnightTitleRequirements.Local.Data.Description[w3].Text end
q=(type(q)=="table"and q[u])or q
m7hp=(type(m7hp)=="table"and m7hp[u])or m7hp;self:RequirementTooltip(q,m7hp)end
BundleKnightTitleRequirements.Local.Data.RequirementWidgets={[1]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Settlers",[2]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Goods",[3]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/RichBuildings",[4]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Castle",[5]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Storehouse",[6]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Cathedral"}
BundleKnightTitleRequirements.Local.Data.GoodCategoryNames={[GoodCategories.GC_Ammunition]={de="Munition",en="Ammunition"},[GoodCategories.GC_Animal]={de="Nutztiere",en="Livestock"},[GoodCategories.GC_Clothes]={de="Kleidung",en="Clothes"},[GoodCategories.GC_Document]={de="Dokumente",en="Documents"},[GoodCategories.GC_Entertainment]={de="Unterhaltung",en="Entertainment"},[GoodCategories.GC_Food]={de="Nahrungsmittel",en="Food"},[GoodCategories.GC_Gold]={de="Gold",en="Gold"},[GoodCategories.GC_Hygiene]={de="Hygieneartikel",en="Hygiene"},[GoodCategories.GC_Luxury]={de="Dekoration",en="Decoration"},[GoodCategories.GC_Medicine]={de="Medizin",en="Medicine"},[GoodCategories.GC_None]={de="Nichts",en="None"},[GoodCategories.GC_RawFood]={de="Nahrungsmittel",en="Food"},[GoodCategories.GC_RawMedicine]={de="Medizin",en="Medicine"},[GoodCategories.GC_Research]={de="Forschung",en="Research"},[GoodCategories.GC_Resource]={de="Rohstoffe",en="Resource"},[GoodCategories.GC_Tools]={de="Werkzeug",en="Tools"},[GoodCategories.GC_Water]={de="Wasser",en="Water"},[GoodCategories.GC_Weapon]={de="Waffen",en="Weapon"}}
BundleKnightTitleRequirements.Local.Data.BuffTypeNames={[Buffs.Buff_ClothesDiversity]={de="Abwechslungsreiche Kleidung",en="Clothes diversity"},[Buffs.Buff_Colour]={de="Farben beschaffen",en="Obtain color"},[Buffs.Buff_Entertainers]={de="Gaukler anheuern",en="Hire entertainer"},[Buffs.Buff_EntertainmentDiversity]={de="Abwechslungsreiche Unterhaltung",en="Entertainment diversity"},[Buffs.Buff_ExtraPayment]={de="Sonderzahlung",en="Extra payment"},[Buffs.Buff_Festival]={de="Fest veranstalten",en="Hold Festival"},[Buffs.Buff_FoodDiversity]={de="Abwechslungsreiche Nahrung",en="Food diversity"},[Buffs.Buff_HygieneDiversity]={de="Abwechslungsreiche Hygiene",en="Hygiene diversity"},[Buffs.Buff_NoTaxes]={de="Steuerbefreiung",en="No taxes"},[Buffs.Buff_Sermon]={de="Pregigt abhalten",en="Hold sermon"},[Buffs.Buff_Spice]={de="Salz beschaffen",en="Obtain salt"}}
BundleKnightTitleRequirements.Local.Data.Description={Settlers={Title={de="Benötigte Siedler",en="Needed settlers"},Text={de="- Benötigte Menge an Siedlern",en="- Needed number of settlers"}},RichBuildings={Title={de="Reiche Stadtgebäude",en="Rich city buildings"},Text={de="- Menge an reichen Stadtgebäuden",en="- Needed amount of rich city buildings"}},Goods={Title={de="Waren lagern",en="Store Goods"},Text={de="- Benötigte Menge",en="- Needed amount"}},FullDecoratedBuildings={Title={de="Dekorierte Stadtgebäude",en="Decorated City buildings"},Text={de="- Menge an voll dekorierten Gebäuden",en="- Amount of full decoraded city buildings"}},DecoratedBuildings={Title={de="Dekoration",en="Decoration"},Text={de="- Menge an Dekorationsgütern in der Siedlung",en="- Amount of decoration goods in settlement"}},Headquarters={Title={de="Burgstufe",en="Castle level"},Text={de="- Benötigte Ausbauten der Burg",en="- Needed castle upgrades"}},Storehouse={Title={de="Lagerhausstufe",en="Storehouse level"},Text={de="- Benötigte Ausbauten des Lagerhauses",en="- Needed storehouse upgrades"}},Cathedrals={Title={de="Kirchenstufe",en="Cathedral level"},Text={de="- Benötigte Ausbauten der Kirche",en="- Needed cathedral upgrades"}},Reputation={Title={de="Ruf der Stadt",en="City reputation"},Text={de="- Benötigter Ruf der Stadt",en="- Needed city reputation"}},EntityCategoryDefault={Title={de="",en=""},Text={de="- Benötigte Anzahl",en="- Needed amount"}},Cattle={Title={de="Kühe",en="Cattle"},Text={de="- Benötigte Menge an Kühen",en="- Needed amount of cattle"}},Sheep={Title={de="Schafe",en="Sheeps"},Text={de="- Benötigte Menge an Schafen",en="- Needed amount of sheeps"}},Outposts={Title={de="Territorien",en="Territories"},Text={de="- Zu erobernde Territorien",en="- Territories to claim"}},CityBuilding={Title={de="Stadtgebäude",en="City buildings"},Text={de="- Menge benötigter Stadtgebäude",en="- Needed amount of city buildings"}},OuterRimBuilding={Title={de="Rohstoffgebäude",en="Gatherer"},Text={de="- Menge benötigter Rohstoffgebäude",en="- Needed amount of gatherer"}},Consume={Title={de="",en=""},Text={de="- Durch Siedler zu konsumierende Menge",en="- Amount to be consumed by the settlers"}},Products={Title={de="",en=""},Text={de="- Benötigte Menge",en="- Needed amount"}},Buff={Title={de="Bonus aktivieren",en="Activate Buff"},Text={de="- Aktiviere diesen Bonus auf den Ruf der Stadt",en="- Raise the city reputatition with this buff"}},Soldiers={Title={de="Soldaten",en="Soldiers"},Text={de="- Menge an Streitkräften unterhalten",en="- Soldiers you need under your command"}},Worker={Title={de="Arbeiter",en="Workers"},Text={de="- Menge an arbeitender Bevölkerung",en="- Workers you need under your reign"}},Entities={Title={de="",en=""},Text={de="- Benötigte Menge",en="- Needed Amount"}},Buildings={Title={de="Gebäude",en="Buildings"},Text={de="- Gesamtmenge an Gebäuden",en="- Amount of buildings"}},Weapons={Title={de="Waffen",en="Weapons"},Text={de="- Benötigte Menge an Waffen",en="- Needed amount of weapons"}},HeavyWeapons={Title={de="Belagerungsgeräte",en="Siege Engines"},Text={de="- Benötigte Menge an Belagerungsgeräten",en="- Needed amount of siege engine"}},Spouse={Title={de="Ehefrauen",en="Spouses"},Text={de="- Benötigte Anzahl Ehefrauen in der Stadt",en="- Needed amount of spouses in your city"}}}
Core:RegisterBundle("BundleKnightTitleRequirements")
DoesNeededNumberOfEntitiesInCategoryForKnightTitleExist=function(J,QL1wnu,g)if
KnightTitleRequirements[QL1wnu].Category==nil then return end
if g then
local IddjU=KnightTitleRequirements[QL1wnu].Category[g][1]
local U=KnightTitleRequirements[QL1wnu].Category[g][2]local zMl=0
if IddjU==EntityCategories.Spouse then
zMl=Logic.GetNumberOfSpouses(J)else
local JV={Logic.GetPlayerEntitiesInCategory(J,IddjU)}
for Ua10n1=1,#JV do if Logic.IsBuilding(JV[Ua10n1])==1 then if
Logic.IsConstructionComplete(JV[Ua10n1])==1 then zMl=zMl+1 end else
zMl=zMl+1 end end end;if zMl>=U then return true,zMl,U end;return false,zMl,U else local i,k,c_
for _ef=1,#
KnightTitleRequirements[QL1wnu].Category do
i,k,c_=DoesNeededNumberOfEntitiesInCategoryForKnightTitleExist(J,QL1wnu,_ef)if i==false then return i,k,c_ end end;return i end end
DoesNeededNumberOfEntitiesOfTypeForKnightTitleExist=function(E,gY,uyD1h)if
KnightTitleRequirements[gY].Entities==nil then return end
if uyD1h then
local ixZdkZre=KnightTitleRequirements[gY].Entities[uyD1h][1]
local bPQeV=KnightTitleRequirements[gY].Entities[uyD1h][2]local axKU=GetPlayerEntities(E,ixZdkZre)local f27=0;for Vt6d=1,#axKU do
if
Logic.IsBuilding(axKU[Vt6d])==1 then if
Logic.IsConstructionComplete(axKU[Vt6d])==1 then f27=f27+1 end else f27=f27+1 end end;if
f27 >=bPQeV then return true,f27,bPQeV end;return false,f27,bPQeV else
local LZZLj,m5wX10r2,Bs4p9QC
for JLzCbfW=1,#KnightTitleRequirements[gY].Entities do
LZZLj,m5wX10r2,Bs4p9QC=DoesNeededNumberOfEntitiesOfTypeForKnightTitleExist(E,gY,JLzCbfW)if LZZLj==false then return LZZLj,m5wX10r2,Bs4p9QC end end;return LZZLj end end
DoesNeededNumberOfGoodTypesForKnightTitleExist=function(UC,V7MN2,az_DlK)if
KnightTitleRequirements[V7MN2].Goods==nil then return end
if az_DlK then
local WSk=KnightTitleRequirements[V7MN2].Goods[az_DlK][1]
local F7=KnightTitleRequirements[V7MN2].Goods[az_DlK][2]local r=GetPlayerGoodsInSettlement(WSk,UC,true)if r>=F7 then
return true,r,F7 end;return false,r,F7 else local FNE,bAPx,ys0Rp_
for gf8=1,#
KnightTitleRequirements[V7MN2].Goods do
FNE,bAPx,ys0Rp_=DoesNeededNumberOfGoodTypesForKnightTitleExist(UC,V7MN2,gf8)if FNE==false then return FNE,bAPx,ys0Rp_ end end;return FNE end end
DoNeededNumberOfConsumedGoodsForKnightTitleExist=function(z0OIkNLi,nbG,jSO9C3l)if
KnightTitleRequirements[nbG].Consume==nil then return end
if jSO9C3l then QSB.ConsumedGoodsCounter[z0OIkNLi]=
QSB.ConsumedGoodsCounter[z0OIkNLi]or{}
local _pROM=KnightTitleRequirements[nbG].Consume[jSO9C3l][1]
local sRbL=QSB.ConsumedGoodsCounter[z0OIkNLi][_pROM]or 0
local QwIBmq5=KnightTitleRequirements[nbG].Consume[jSO9C3l][2]
if sRbL>=QwIBmq5 then return true,sRbL,QwIBmq5 else return false,sRbL,QwIBmq5 end else local gsQtuSh,quRuY,iGWMf
for T7=1,#KnightTitleRequirements[nbG].Consume
do
gsQtuSh,quRuY,iGWMf=DoNeededNumberOfConsumedGoodsForKnightTitleExist(z0OIkNLi,nbG,T7)if gsQtuSh==false then return false,quRuY,iGWMf end end;return true,quRuY,iGWMf end end
DoNumberOfProductsInCategoryExist=function(YBFVDgJ8,C93rAu8s,W)if
KnightTitleRequirements[C93rAu8s].Products==nil then return end
if W then local A=0
local oCsS0bB=KnightTitleRequirements[C93rAu8s].Products[W][2]
local bCZUsux8=KnightTitleRequirements[C93rAu8s].Products[W][1]
local M5={Logic.GetGoodTypesInGoodCategory(bCZUsux8)}for N=1,#M5 do
A=A+GetPlayerGoodsInSettlement(M5[N],YBFVDgJ8,true)end;return(A>=oCsS0bB),A,oCsS0bB else
local XiCLp,ZdEKQ,jQym
for nAJt=1,#KnightTitleRequirements[C93rAu8s].Products do
XiCLp,ZdEKQ,jQym=DoNumberOfProductsInCategoryExist(YBFVDgJ8,C93rAu8s,nAJt)if XiCLp==false then return XiCLp,ZdEKQ,jQym end end;return XiCLp end end
DoNeededDiversityBuffForKnightTitleExist=function(zGnJBza,C,Kehy_OA2)if
KnightTitleRequirements[C].Buff==nil then return end
if Kehy_OA2 then
local Ck=KnightTitleRequirements[C].Buff[Kehy_OA2]if
Logic.GetBuff(zGnJBza,Ck)and Logic.GetBuff(zGnJBza,Ck)~=0 then return true end;return false else local xU,lt,z9zD
for AelHP=1,#
KnightTitleRequirements[C].Buff do
xU,lt,z9zD=DoNeededDiversityBuffForKnightTitleExist(zGnJBza,C,AelHP)if xU==false then return xU,lt,z9zD end end;return xU end end
DoCustomFunctionForKnightTitleSucceed=function(mt5,d,CHlyfc)if
KnightTitleRequirements[d].Custom==nil then return end
if CHlyfc then return
KnightTitleRequirements[d].Custom[CHlyfc][1]()else local T8SGU,p,wna1CP
for VZM7n=1,#
KnightTitleRequirements[d].Custom do
T8SGU,p,wna1CP=DoCustomFunctionForKnightTitleSucceed(mt5,d,VZM7n)if T8SGU==false then return T8SGU,p,wna1CP end end;return T8SGU end end
DoNeededNumberOfDecoratedBuildingsForKnightTitleExist=function(J5aNAL,cE9V0Ak,YsjtyXX)if
KnightTitleRequirements[cE9V0Ak].DecoratedBuildings==nil then return end
if YsjtyXX then
local scMn={Logic.GetPlayerEntitiesInCategory(J5aNAL,EntityCategories.CityBuilding)}
local Ike=KnightTitleRequirements[cE9V0Ak].DecoratedBuildings[YsjtyXX][1]
local YAtde=KnightTitleRequirements[cE9V0Ak].DecoratedBuildings[YsjtyXX][2]local ZyC2y=0
for wkVO=1,#scMn do local ShoAeW5=scMn[wkVO]
local xRFquX7=Logic.GetBuildingWealthGoodState(ShoAeW5,Ike)if xRFquX7 >0 then ZyC2y=ZyC2y+1 end end
if ZyC2y>=YAtde then return true,ZyC2y,YAtde else return false,ZyC2y,YAtde end else local lhOAIgu,_E,BNl8FF
for qdi=1,#KnightTitleRequirements[cE9V0Ak].DecoratedBuildings
do
lhOAIgu,_E,BNl8FF=DoNeededNumberOfDecoratedBuildingsForKnightTitleExist(J5aNAL,cE9V0Ak,qdi)if lhOAIgu==false then return lhOAIgu,_E,BNl8FF end end;return lhOAIgu end end
DoNeededSpecialBuildingUpgradeForKnightTitleExist=function(HVCvb,z,j3VsR)local Mlr;local N5F0y
if
j3VsR==EntityCategories.Headquarters then Mlr=Logic.GetHeadquarters(HVCvb)N5F0y="Headquarters"elseif j3VsR==
EntityCategories.Storehouse then Mlr=Logic.GetStoreHouse(HVCvb)
N5F0y="Storehouse"elseif j3VsR==EntityCategories.Cathedrals then
Mlr=Logic.GetCathedral(HVCvb)N5F0y="Cathedrals"else return end
if KnightTitleRequirements[z][N5F0y]==nil then return end;local Oz=KnightTitleRequirements[z][N5F0y]
if Mlr~=nil then
local pNF17=Logic.GetUpgradeLevel(Mlr)
if pNF17 >=Oz then return true,pNF17,Oz else return false,pNF17,Oz end else return false,0,Oz end end
DoesNeededCityReputationForKnightTitleExist=function(ta,Z)if
KnightTitleRequirements[Z].Reputation==nil then return end
local f=KnightTitleRequirements[Z].Reputation;if not f then return end
local ueZx6g=math.floor(
(Logic.GetCityReputation(ta)*100)+0.5)if ueZx6g>=f then return true,ueZx6g,f end;return false,ueZx6g,f end
DoNeededNumberOfFullDecoratedBuildingsForKnightTitleExist=function(JU5X,JmtYoAf6)
if
KnightTitleRequirements[JmtYoAf6].FullDecoratedBuildings==nil then return end
local Z37al={Logic.GetPlayerEntitiesInCategory(JU5X,EntityCategories.CityBuilding)}
local JBqNR2s=KnightTitleRequirements[JmtYoAf6].FullDecoratedBuildings;local fCYDw0i=0
for gVH94qh_=1,#Z37al do local da=Z37al[gVH94qh_]local hKRhfrQ=0
if
Logic.GetBuildingWealthGoodState(da,Goods.G_Banner)>0 then hKRhfrQ=hKRhfrQ+1 end;if
Logic.GetBuildingWealthGoodState(da,Goods.G_Sign)>0 then hKRhfrQ=hKRhfrQ+1 end
if
Logic.GetBuildingWealthGoodState(da,Goods.G_Candle)>0 then hKRhfrQ=hKRhfrQ+1 end;if
Logic.GetBuildingWealthGoodState(da,Goods.G_Ornament)>0 then hKRhfrQ=hKRhfrQ+1 end;if hKRhfrQ>=4 then fCYDw0i=
fCYDw0i+1 end end
if fCYDw0i>=JBqNR2s then return true,fCYDw0i,JBqNR2s else return false,fCYDw0i,JBqNR2s end end
CanKnightBePromoted=function(kat,I)
if I==nil then I=Logic.GetKnightTitle(kat)+1 end
if Logic.CanStartFestival(kat,1)==true then
if














KnightTitleRequirements[I]~=
nil and
DoesNeededNumberOfSettlersForKnightTitleExist(kat,I)~=false and
DoNeededNumberOfGoodsForKnightTitleExist(kat,I)~=false and
DoNeededSpecialBuildingUpgradeForKnightTitleExist(kat,I,EntityCategories.Headquarters)~=false and
DoNeededSpecialBuildingUpgradeForKnightTitleExist(kat,I,EntityCategories.Storehouse)~=false and
DoNeededSpecialBuildingUpgradeForKnightTitleExist(kat,I,EntityCategories.Cathedrals)~=false and
DoNeededNumberOfRichBuildingsForKnightTitleExist(kat,I)~=false and
DoNeededNumberOfFullDecoratedBuildingsForKnightTitleExist(kat,I)~=false and
DoNeededNumberOfDecoratedBuildingsForKnightTitleExist(kat,I)~=false and
DoesNeededCityReputationForKnightTitleExist(kat,I)~=false and
DoesNeededNumberOfEntitiesInCategoryForKnightTitleExist(kat,I)~=false and
DoesNeededNumberOfEntitiesOfTypeForKnightTitleExist(kat,I)~=false and
DoesNeededNumberOfGoodTypesForKnightTitleExist(kat,I)~=false and DoNeededDiversityBuffForKnightTitleExist(kat,I)~=false and DoCustomFunctionForKnightTitleSucceed(kat,I)~=false and
DoNeededNumberOfConsumedGoodsForKnightTitleExist(kat,I)~=false and DoNumberOfProductsInCategoryExist(kat,I)~=false then return true end end;return false end
VictroryBecauseOfTitle=function()QuestTemplate:TerminateEventsAndStuff()
Victory(g_VictoryAndDefeatType.VictoryMissionComplete)end
InitKnightTitleTables=function()KnightTitles={}KnightTitles.Knight=0
KnightTitles.Mayor=1;KnightTitles.Baron=2;KnightTitles.Earl=3
KnightTitles.Marquees=4;KnightTitles.Duke=5;KnightTitles.Archduke=6
NeedsAndRightsByKnightTitle={}
NeedsAndRightsByKnightTitle[KnightTitles.Knight]={ActivateNeedForPlayer,{Needs.Nutrition,Needs.Medicine},ActivateRightForPlayer,{Technologies.R_Gathering,Technologies.R_Woodcutter,Technologies.R_StoneQuarry,Technologies.R_HuntersHut,Technologies.R_FishingHut,Technologies.R_CattleFarm,Technologies.R_GrainFarm,Technologies.R_SheepFarm,Technologies.R_IronMine,Technologies.R_Beekeeper,Technologies.R_HerbGatherer,Technologies.R_Nutrition,Technologies.R_Bakery,Technologies.R_Dairy,Technologies.R_Butcher,Technologies.R_SmokeHouse,Technologies.R_Clothes,Technologies.R_Tanner,Technologies.R_Weaver,Technologies.R_Construction,Technologies.R_Wall,Technologies.R_Pallisade,Technologies.R_Trail,Technologies.R_KnockDown,Technologies.R_Sermon,Technologies.R_SpecialEdition,Technologies.R_SpecialEdition_Pavilion}}
NeedsAndRightsByKnightTitle[KnightTitles.Mayor]={ActivateNeedForPlayer,{Needs.Clothes},ActivateRightForPlayer,{Technologies.R_Hygiene,Technologies.R_Soapmaker,Technologies.R_BroomMaker,Technologies.R_Military,Technologies.R_SwordSmith,Technologies.R_Barracks,Technologies.R_Thieves,Technologies.R_SpecialEdition_StatueFamily},StartKnightsPromotionCelebration}
NeedsAndRightsByKnightTitle[KnightTitles.Baron]={ActivateNeedForPlayer,{Needs.Hygiene},ActivateRightForPlayer,{Technologies.R_Medicine,Technologies.R_BowMaker,Technologies.R_BarracksArchers,Technologies.R_Entertainment,Technologies.R_Tavern,Technologies.R_Festival,Technologies.R_Street,Technologies.R_SpecialEdition_Column},StartKnightsPromotionCelebration}
NeedsAndRightsByKnightTitle[KnightTitles.Earl]={ActivateNeedForPlayer,{Needs.Entertainment,Needs.Prosperity},ActivateRightForPlayer,{Technologies.R_SiegeEngineWorkshop,Technologies.R_BatteringRam,Technologies.R_Baths,Technologies.R_AmmunitionCart,Technologies.R_Prosperity,Technologies.R_Taxes,Technologies.R_Ballista,Technologies.R_SpecialEdition_StatueSettler},StartKnightsPromotionCelebration}
NeedsAndRightsByKnightTitle[KnightTitles.Marquees]={ActivateNeedForPlayer,{Needs.Wealth},ActivateRightForPlayer,{Technologies.R_Theater,Technologies.R_Wealth,Technologies.R_BannerMaker,Technologies.R_SiegeTower,Technologies.R_SpecialEdition_StatueProduction},StartKnightsPromotionCelebration}
NeedsAndRightsByKnightTitle[KnightTitles.Duke]={ActivateNeedForPlayer,nil,ActivateRightForPlayer,{Technologies.R_Catapult,Technologies.R_Carpenter,Technologies.R_CandleMaker,Technologies.R_Blacksmith,Technologies.R_SpecialEdition_StatueDario},StartKnightsPromotionCelebration}
NeedsAndRightsByKnightTitle[KnightTitles.Archduke]={ActivateNeedForPlayer,nil,ActivateRightForPlayer,{Technologies.R_Victory},StartKnightsPromotionCelebration}
if g_GameExtraNo>=1 then local ttp=4
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Mayor][ttp],Technologies.R_Cistern)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Mayor][ttp],Technologies.R_Beautification_Brazier)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Mayor][ttp],Technologies.R_Beautification_Shrine)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Baron][ttp],Technologies.R_Beautification_Pillar)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Earl][ttp],Technologies.R_Beautification_StoneBench)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Earl][ttp],Technologies.R_Beautification_Vase)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Marquees][ttp],Technologies.R_Beautification_Sundial)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Archduke][ttp],Technologies.R_Beautification_TriumphalArch)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Duke][ttp],Technologies.R_Beautification_VictoryColumn)end;KnightTitleRequirements={}
KnightTitleRequirements[KnightTitles.Mayor]={}
KnightTitleRequirements[KnightTitles.Mayor].Headquarters=1
KnightTitleRequirements[KnightTitles.Mayor].Settlers=10
KnightTitleRequirements[KnightTitles.Mayor].Products={{GoodCategories.GC_Clothes,6}}KnightTitleRequirements[KnightTitles.Baron]={}
KnightTitleRequirements[KnightTitles.Baron].Settlers=30
KnightTitleRequirements[KnightTitles.Baron].Headquarters=1
KnightTitleRequirements[KnightTitles.Baron].Storehouse=1
KnightTitleRequirements[KnightTitles.Baron].Cathedrals=1
KnightTitleRequirements[KnightTitles.Baron].Products={{GoodCategories.GC_Hygiene,12}}KnightTitleRequirements[KnightTitles.Earl]={}
KnightTitleRequirements[KnightTitles.Earl].Settlers=50
KnightTitleRequirements[KnightTitles.Earl].Headquarters=2
KnightTitleRequirements[KnightTitles.Earl].Products={{GoodCategories.GC_Entertainment,18}}
KnightTitleRequirements[KnightTitles.Marquees]={}
KnightTitleRequirements[KnightTitles.Marquees].Settlers=70
KnightTitleRequirements[KnightTitles.Marquees].Headquarters=2
KnightTitleRequirements[KnightTitles.Marquees].Storehouse=2
KnightTitleRequirements[KnightTitles.Marquees].Cathedrals=2
KnightTitleRequirements[KnightTitles.Marquees].RichBuildings=20;KnightTitleRequirements[KnightTitles.Duke]={}
KnightTitleRequirements[KnightTitles.Duke].Settlers=90
KnightTitleRequirements[KnightTitles.Duke].Storehouse=2
KnightTitleRequirements[KnightTitles.Duke].Cathedrals=2
KnightTitleRequirements[KnightTitles.Duke].Headquarters=3
KnightTitleRequirements[KnightTitles.Duke].DecoratedBuildings={{Goods.G_Banner,9}}
KnightTitleRequirements[KnightTitles.Archduke]={}
KnightTitleRequirements[KnightTitles.Archduke].Settlers=150
KnightTitleRequirements[KnightTitles.Archduke].Storehouse=3
KnightTitleRequirements[KnightTitles.Archduke].Cathedrals=3
KnightTitleRequirements[KnightTitles.Archduke].Headquarters=3
KnightTitleRequirements[KnightTitles.Archduke].RichBuildings=30
KnightTitleRequirements[KnightTitles.Archduke].FullDecoratedBuildings=30;CreateTechnologyKnightTitleTable()end;API=API or{}QSB=QSB or{}QSB.PlayerNames={}
function API.HideMinimap(xw)if not GUI then
Logic.ExecuteInLuaLocalState(
"API.HideMinimap("..tostring(xw)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/Minimap/MinimapOverlay",xw)
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/Minimap/MinimapTerrain",xw)end
function API.HideToggleMinimap(SqI5E)if not GUI then
Logic.ExecuteInLuaLocalState("API.HideToggleMinimap("..tostring(SqI5E)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/MinimapButton",SqI5E)end
function API.HideDiplomacyMenu(bSgeE5)if not GUI then
Logic.ExecuteInLuaLocalState("API.HideDiplomacyMenu("..tostring(bSgeE5)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/DiplomacyMenuButton",bSgeE5)end
function API.HideProductionMenu(wl0dKX)if not GUI then
Logic.ExecuteInLuaLocalState("API.HideProductionMenu("..tostring(wl0dKX)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/ProductionMenuButton",wl0dKX)end
function API.HideWeatherMenu(ZrMXm44)if not GUI then
Logic.ExecuteInLuaLocalState("API.HideWeatherMenu("..tostring(ZrMXm44)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/WeatherMenuButton",ZrMXm44)end
function API.HideBuyTerritory(lX)if not GUI then
Logic.ExecuteInLuaLocalState("API.HideBuyTerritory("..tostring(lX)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Knight/ClaimTerritory",lX)end
function API.HideKnightAbility(vcWpb8)if not GUI then
Logic.ExecuteInLuaLocalState("API.HideKnightAbility("..tostring(vcWpb8)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Knight/StartAbilityProgress",vcWpb8)
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Knight/StartAbility",vcWpb8)end
function API.HideKnightButton(GkzQuHdY)if not GUI then
Logic.ExecuteInLuaLocalState("API.HideKnightButton("..tostring(GkzQuHdY)..")")return end
local DBp=Logic.GetKnightID(GUI.GetPlayerID())
if GkzQuHdY==true then
GUI.SendScriptCommand("Logic.SetEntitySelectableFlag("..DBp..", 0)")GUI.DeselectEntity(DBp)else
GUI.SendScriptCommand("Logic.SetEntitySelectableFlag("..DBp..", 1)")end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/KnightButtonProgress",GkzQuHdY)
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/KnightButton",GkzQuHdY)end
function API.HideSelectionButton(kW)if not GUI then
Logic.ExecuteInLuaLocalState("API.HideSelectionButton("..tostring(kW)..")")return end
API.HideKnightButton(kW)GUI.ClearSelection()
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/BattalionButton",kW)end
function API.HideBuildMenu(U1WV)if not GUI then
Logic.ExecuteInLuaLocalState("API.HideBuildMenu("..tostring(U1WV)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/BuildMenu",U1WV)end;function API.SetTexture(es,BweVGqh)if not GUI then return end
BundleInterfaceApperance.Local:SetTexture(es,BweVGqh)end
UserSetTexture=API.SetTexture;function API.SetIcon(A,Li,yjmG0B7I,C)if not GUI then return end
BundleInterfaceApperance.Local:SetIcon(A,Li,yjmG0B7I,C)end
UserSetIcon=API.SetIcon;function API.SetTooltipNormal(tT6,fh,S)if not GUI then return end
BundleInterfaceApperance.Local:TextNormal(tT6,fh,S)end
UserSetTextNormal=API.SetTooltipNormal
function API.SetTooltipCosts(RBKUQt,Yag,bJcmH,IVom7n4,xOynA)if not GUI then return end
BundleInterfaceApperance.Local:TextCosts(RBKUQt,Yag,bJcmH,IVom7n4,xOynA)end;UserSetTextBuy=API.SetTooltipCosts
function API.GetTerritoryName(ro1k)
local ea4=Logic.GetTerritoryName(ro1k)local W_h=Framework.GetCurrentMapTypeAndCampaignName()if
W_h==1 or W_h==3 then return ea4 end
local yw1zD=Framework.GetCurrentMapName()local SWP="Map_"..yw1zD;local REfRorFU=string.gsub(ea4," ","")
REfRorFU=XGUIEng.GetStringTableText(
SWP.."/Territory_"..REfRorFU)if REfRorFU==""then REfRorFU=ea4 .."(key?)"end;return REfRorFU end;GetTerritoryName=API.GetTerritoryName
function API.GetPlayerName(n8oLLJS)
local KW7Dj=Logic.GetPlayerName(n8oLLJS)local X=QSB.PlayerNames[n8oLLJS]
if X~=nil and X~=""then KW7Dj=X end
local KJjjq=Framework.GetCurrentMapTypeAndCampaignName()
local leCk0=Framework.GetMultiplayerMapMode(Framework.GetCurrentMapName(),KJjjq)if leCk0 >0 then return KW7Dj end
if KJjjq==1 or KJjjq==3 then
local dUvpRX2,LEfAT,udQ=Framework.GetPlayerInfo(n8oLLJS)if KW7Dj~=""then return KW7Dj end;return dUvpRX2 end end;GetPlayerName_OrigName=GetPlayerName;GetPlayerName=API.GetPlayerName
function API.SetPlayerName(V,yhFYZc)assert(
type(V)=="number")
assert(type(yhFYZc)=="string")
if not GUI then
Logic.ExecuteInLuaLocalState("SetPlayerName("..V..",'"..yhFYZc.."')")else GUI_MissionStatistic.PlayerNames[V]=yhFYZc
GUI.SendScriptCommand(
"QSB.PlayerNames["..V.."] = '"..yhFYZc.."'")end;QSB.PlayerNames[V]=yhFYZc end;SetPlayerName=API.SetPlayerName
function API.SetPlayerColor(eCorPg,DaopEI,uLdXdV,K)if GUI then return end
local Zv0O2Z3M=type(DaopEI)local m8=
(type(DaopEI)=="string"and g_ColorIndex[DaopEI])or DaopEI
local BkdY=uLdXdV or-1;local Hf=K or-1;g_ColorIndex["ExtraColor1"]=16
g_ColorIndex["ExtraColor2"]=17
StartSimpleJobEx(function(m8,eCorPg,uLdXdV,K)
Logic.PlayerSetPlayerColor(eCorPg,m8,uLdXdV,K)return true end,m8,eCorPg,BkdY,Hf)end
BundleInterfaceApperance={Global={},Local={Data={HiddenWidgets={}}}}function BundleInterfaceApperance.Global:Install()
API.AddSaveGameAction(BundleInterfaceApperance.Global.RestoreAfterLoad)end
function BundleInterfaceApperance.Global.RestoreAfterLoad()
Logic.ExecuteInLuaLocalState([[
        BundleInterfaceApperance.Local:RestoreAfterLoad();
    ]])end
function BundleInterfaceApperance.Local:Install()
StartMissionGoodOrEntityCounter=function(LJR,oBXZsMdj)
if
type(LJR)=="string"then
BundleInterfaceApperance.Local:SetTexture("/InGame/Root/Normal/MissionGoodOrEntityCounter/Icon",LJR)else
if type(LJR[3])=="string"then
BundleInterfaceApperance.Local:SetIcon("/InGame/Root/Normal/MissionGoodOrEntityCounter/Icon",LJR,64,LJR[3])else
SetIcon("/InGame/Root/Normal/MissionGoodOrEntityCounter/Icon",LJR)end end;g_MissionGoodOrEntityCounterAmountToReach=oBXZsMdj
g_MissionGoodOrEntityCounterIcon=LJR
XGUIEng.ShowWidget("/InGame/Root/Normal/MissionGoodOrEntityCounter",1)end
GUI_Knight.ClaimTerritoryUpdate_Orig_QSB_InterfaceApperance=GUI_Knight.ClaimTerritoryUpdate
GUI_Knight.ClaimTerritoryUpdate=function()
local PcE0ge="/InGame/Root/Normal/AlignBottomRight/DialogButtons/Knight/ClaimTerritory"if
BundleInterfaceApperance.Local.Data.HiddenWidgets[PcE0ge]==true then
BundleInterfaceApperance.Local:HideInterfaceButton(PcE0ge,true)end
GUI_Knight.ClaimTerritoryUpdate_Orig_QSB_InterfaceApperance()end end
function BundleInterfaceApperance.Local:HideInterfaceButton(nMNJQTC,JQg)self.Data.HiddenWidgets[nMNJQTC]=
JQg==true
XGUIEng.ShowWidget(nMNJQTC,(JQg==true and 0)or 1)end
function BundleInterfaceApperance.Local:RestoreAfterLoad()
for oaL,S in
pairs(self.Data.HiddenWidgets)do if S then XGUIEng.ShowWidget(oaL,0)end end end
function BundleInterfaceApperance.Local:SetTexture(uvWDB,SOH2vam)
assert((type(uvWDB)=="string"or
type(uvWDB)=="number"))local o=
(type(uvWDB)=="string"and XGUIEng.GetWidgetID(uvWDB))or uvWDB
local SUKHqlHR={GUI.GetScreenSize()}local Scux_=1;if XGUIEng.IsButton(o)==1 then Scux_=7 end
local IkA=330;if SUKHqlHR[2]>=800 then IkA=260 end
if SUKHqlHR[2]>=1000 then IkA=210 end;XGUIEng.SetMaterialAlpha(o,Scux_,255)
XGUIEng.SetMaterialTexture(o,Scux_,SOH2vam)XGUIEng.SetMaterialUV(o,Scux_,0,0,IkA,IkA)end
function BundleInterfaceApperance.Local:SetIcon(NNCUhD3C,WwHwo,w8U7WX,N1Fj0rD)if N1Fj0rD==nil then
N1Fj0rD="usericons"end;if w8U7WX==nil then w8U7WX=64 end;if w8U7WX==44 then N1Fj0rD=N1Fj0rD..
".png"end;if w8U7WX==64 then
N1Fj0rD=N1Fj0rD.."big.png"end
if w8U7WX==128 then N1Fj0rD=N1Fj0rD.."verybig.png"end;local OSoKKStA,wa8xP,w_t,ZysHLoe;OSoKKStA=(WwHwo[1]-1)*w8U7WX;w_t=
(WwHwo[2]-1)*w8U7WX;wa8xP=(WwHwo[1])*w8U7WX;ZysHLoe=
(WwHwo[2])*w8U7WX;State=1;if XGUIEng.IsButton(NNCUhD3C)==1 then
State=7 end
XGUIEng.SetMaterialAlpha(NNCUhD3C,State,255)
XGUIEng.SetMaterialTexture(NNCUhD3C,State,N1Fj0rD)
XGUIEng.SetMaterialUV(NNCUhD3C,State,OSoKKStA,w_t,wa8xP,ZysHLoe)end
function BundleInterfaceApperance.Local:TextNormal(v6Ia2,HPl,Bc8Ie)
local vkqOw5y=Network.GetDesiredLanguage()if vkqOw5y~="de"then vkqOw5y="en"end;if type(v6Ia2)=="table"then
v6Ia2=v6Ia2[vkqOw5y]end
if type(HPl)=="table"then HPl=HPl[vkqOw5y]end;HPl=HPl or""
if type(Bc8Ie)=="table"then Bc8Ie=Bc8Ie[vkqOw5y]end;local SDra="/InGame/Root/Normal/TooltipNormal"
local hjL1zQaW=XGUIEng.GetWidgetID(SDra)
local FkstCfj=XGUIEng.GetWidgetID(SDra.."/FadeIn/Name")
local frN0k=XGUIEng.GetWidgetID(SDra.."/FadeIn/Text")
local sUEZLuWE=XGUIEng.GetWidgetID(SDra.."/FadeIn/BG")local VCKVC0=XGUIEng.GetWidgetID(SDra.."/FadeIn")
local X19LX=XGUIEng.GetCurrentWidgetID()GUI_Tooltip.ResizeBG(sUEZLuWE,frN0k)
local J7UyMyyQ={sUEZLuWE}
GUI_Tooltip.SetPosition(hjL1zQaW,J7UyMyyQ,X19LX)GUI_Tooltip.FadeInTooltip(VCKVC0)Bc8Ie=Bc8Ie or""
local KIBa=""if
XGUIEng.IsButtonDisabled(X19LX)==1 and Bc8Ie~=""and HPl~=""then
KIBa=KIBa.."{cr}{@color:255,32,32,255}"..Bc8Ie end;XGUIEng.SetText(FkstCfj,
"{center}"..v6Ia2)
XGUIEng.SetText(frN0k,HPl..KIBa)local CzeZVbkz=XGUIEng.GetTextHeight(frN0k,true)
local UUawT,QN7ateI=XGUIEng.GetWidgetSize(frN0k)XGUIEng.SetWidgetSize(frN0k,UUawT,CzeZVbkz)end
function BundleInterfaceApperance.Local:TextCosts(_IZCHdRg,rU3P3r2,Q,mtEzJq,p5IT4RDF)
local C4eY=Network.GetDesiredLanguage()if C4eY~="de"then C4eY="en"end;mtEzJq=mtEzJq or{}if
type(_IZCHdRg)=="table"then _IZCHdRg=_IZCHdRg[C4eY]end;if
type(rU3P3r2)=="table"then rU3P3r2=rU3P3r2[C4eY]end
rU3P3r2=rU3P3r2 or""if type(Q)=="table"then Q=Q[C4eY]end
local BS="/InGame/Root/Normal/TooltipBuy"local KTbH=XGUIEng.GetWidgetID(BS)
local TFnCJik=XGUIEng.GetWidgetID(BS.."/FadeIn/Name")local po=XGUIEng.GetWidgetID(BS.."/FadeIn/Text")local yhy=XGUIEng.GetWidgetID(
BS.."/FadeIn/BG")local XabKkHV=XGUIEng.GetWidgetID(BS..
"/FadeIn")
local EoB2=XGUIEng.GetWidgetID(BS.."/Costs")local iI=XGUIEng.GetCurrentWidgetID()
GUI_Tooltip.ResizeBG(yhy,po)GUI_Tooltip.SetCosts(EoB2,mtEzJq,p5IT4RDF)
local k={KTbH,EoB2,yhy}GUI_Tooltip.SetPosition(KTbH,k,iI,nil,true)
GUI_Tooltip.OrderTooltip(k,XabKkHV,EoB2,iI,yhy)GUI_Tooltip.FadeInTooltip(XabKkHV)Q=Q or""local KCkR6=""if

XGUIEng.IsButtonDisabled(iI)==1 and Q~=""and rU3P3r2 ~=""then
KCkR6=KCkR6 .."{cr}{@color:255,32,32,255}"..Q end;XGUIEng.SetText(TFnCJik,
"{center}".._IZCHdRg)XGUIEng.SetText(po,
rU3P3r2 ..KCkR6)
local Gt2=XGUIEng.GetTextHeight(po,true)local t,Z7TxGd9l=XGUIEng.GetWidgetSize(po)
XGUIEng.SetWidgetSize(po,t,Gt2)end;Core:RegisterBundle("BundleInterfaceApperance")API=API or
{}QSB=QSB or{}QSB.TravelingSalesman={Harbors={}}
QSB.TraderTypes={GoodTrader=1,MercenaryTrader=2,EntertainerTrader=3,Unknown=4}
function API.GetOfferInformation(jOYC)if GUI then
API.Log("Can not execute API.GetOfferInformation in local script!")return end;return
BundleTradingFunctions.Global:GetOfferInformation(jOYC)end
function API.GetOfferCount(ger)if GUI then
API.Log("Can not execute API.GetOfferCount in local script!")return end;return
BundleTradingFunctions.Global:GetOfferCount(ger)end
function API.GetOfferAndTrader(G0jBEog,H)if GUI then
API.Log("Can not execute API.GetOfferAndTrader in local script!")return end;return
BundleTradingFunctions.Global:GetOfferAndTrader(G0jBEog,H)end
function API.GetTraderType(wP2mU7o,Ki5XQ)if GUI then
API.Log("Can not execute API.GetTraderType in local script!")return end;return
BundleTradingFunctions.Global:GetTraderType(wP2mU7o,Ki5XQ)end
function API.GetTrader(ECnd,f7l)if GUI then
API.Log("Can not execute API.GetTrader in local script!")return end;return
BundleTradingFunctions.Global:GetTrader(ECnd,f7l)end
function API.RemoveOfferByIndex(G8ZUj,uI,M0L)if GUI then
API.Bridge("API.RemoveOfferByIndex("..G8ZUj..
", "..uI..", "..M0L..")")return end;return
BundleTradingFunctions.Global:RemoveOfferByIndex(G8ZUj,uI,M0L)end
function API.RemoveOffer(X1zoNh2N,pzt)if GUI then
API.Bridge("API.RemoveOffer("..X1zoNh2N..", "..pzt..")")return end;return
BundleTradingFunctions.Global:RemoveOffer(X1zoNh2N,pzt)end
function API.ModifyTraderOffer(nv5UE,N,Ld8ab,BbxNzlIJ)if GUI then
API.Bridge("API.ModifyTraderOffer("..
nv5UE..", "..N..", "..
Ld8ab..", "..BbxNzlIJ..")")return end;return
BundleTradingFunctions.Global:ModifyTraderOffer(nv5UE,N,Ld8ab,BbxNzlIJ)end
function API.ActivateTravelingSalesman(mIVqMY,vjd,GaxvRZ,B,Qe)if GUI then
API.Log("Can not execute API.ActivateTravelingSalesman in local script!")return end;return
BundleTradingFunctions.Global:TravelingSalesman_Create(mIVqMY,vjd,Qe,GaxvRZ,B)end
function API.DisbandTravelingSalesman(Q)if GUI then
API.Bridge("API.DisbandTravelingSalesman("..Q..")")return end;return
BundleTradingFunctions.Global:TravelingSalesman_Disband(Q)end;BundleTradingFunctions={Global={Data={}},Local={Data={}}}
function BundleTradingFunctions.Global:Install()
self.OverwriteOfferFunctions()self.OverwriteBasePricesAndRefreshRates()
TravelingSalesman_Control=BundleTradingFunctions.Global.TravelingSalesman_Control end
function BundleTradingFunctions.Global:OverwriteOfferFunctions()
AddOffer=function(Azvu,mJUIsy,A2mKO,w3LESxRS,mS9ak)
local kUsG=GetID(Azvu)
if type(A2mKO)=="string"then A2mKO=Goods[A2mKO]else A2mKO=A2mKO end;local ZCRLifP=Logic.EntityGetPlayer(kUsG)
AddGoodToTradeBlackList(ZCRLifP,A2mKO)local LL35AS8C=Entities.U_Marketer;if A2mKO==Goods.G_Medicine then
LL35AS8C=Entities.U_Medicus end
if w3LESxRS==nil then
w3LESxRS=MerchantSystem.RefreshRates[A2mKO]if w3LESxRS==nil then w3LESxRS=0 end end;if mS9ak==nil then mS9ak=1 end;local v=9;return
Logic.AddGoodTraderOffer(kUsG,mJUIsy,Goods.G_Gold,0,A2mKO,v,mS9ak,w3LESxRS,LL35AS8C,Entities.U_ResourceMerchant)end
AddMercenaryOffer=function(euz2FZps,C5,f,FZbyrOw,g)local LDLLUZm0=GetID(euz2FZps)if f==nil then
f=Entities.U_MilitaryBandit_Melee_ME end
if FZbyrOw==nil then
FZbyrOw=MerchantSystem.RefreshRates[f]if FZbyrOw==nil then FZbyrOw=0 end end;local s1E1q=3;local jfg=Logic.GetEntityTypeName(f)if
string.find(jfg,"MilitaryBow")or string.find(jfg,"MilitarySword")then s1E1q=6 elseif
string.find(jfg,"Cart")then s1E1q=0 end;if g==nil then
g=1 end;return
Logic.AddMercenaryTraderOffer(LDLLUZm0,C5,Goods.G_Gold,3,f,s1E1q,g,FZbyrOw)end
AddEntertainerOffer=function(E43QsB,MnH_PDE,BPcZ)local I10ha=GetID(E43QsB)local C9R=1;if MnH_PDE==nil then
MnH_PDE=Entities.U_Entertainer_NA_FireEater end;if BPcZ==nil then BPcZ=1 end;return
Logic.AddEntertainerTraderOffer(I10ha,C9R,Goods.G_Gold,0,MnH_PDE,BPcZ,0)end end
function BundleTradingFunctions.Global:OverwriteBasePricesAndRefreshRates()
MerchantSystem.BasePrices[Entities.U_CatapultCart]=
MerchantSystem.BasePrices[Entities.U_CatapultCart]or 1000
MerchantSystem.BasePrices[Entities.U_BatteringRamCart]=
MerchantSystem.BasePrices[Entities.U_BatteringRamCart]or 450
MerchantSystem.BasePrices[Entities.U_SiegeTowerCart]=
MerchantSystem.BasePrices[Entities.U_SiegeTowerCart]or 600
MerchantSystem.BasePrices[Entities.U_AmmunitionCart]=
MerchantSystem.BasePrices[Entities.U_AmmunitionCart]or 180
MerchantSystem.BasePrices[Entities.U_MilitarySword_RedPrince]=
MerchantSystem.BasePrices[Entities.U_MilitarySword_RedPrince]or 150
MerchantSystem.BasePrices[Entities.U_MilitarySword_Khana]=
MerchantSystem.BasePrices[Entities.U_MilitarySword_Khana]or 150
MerchantSystem.BasePrices[Entities.U_MilitarySword]=
MerchantSystem.BasePrices[Entities.U_MilitarySword]or 150
MerchantSystem.BasePrices[Entities.U_MilitaryBow_RedPrince]=
MerchantSystem.BasePrices[Entities.U_MilitaryBow_RedPrince]or 220
MerchantSystem.BasePrices[Entities.U_MilitaryBow]=
MerchantSystem.BasePrices[Entities.U_MilitaryBow]or 220
MerchantSystem.RefreshRates[Entities.U_CatapultCart]=
MerchantSystem.RefreshRates[Entities.U_CatapultCart]or 270
MerchantSystem.RefreshRates[Entities.U_BatteringRamCart]=
MerchantSystem.RefreshRates[Entities.U_BatteringRamCart]or 190
MerchantSystem.RefreshRates[Entities.U_SiegeTowerCart]=
MerchantSystem.RefreshRates[Entities.U_SiegeTowerCart]or 220
MerchantSystem.RefreshRates[Entities.U_AmmunitionCart]=
MerchantSystem.RefreshRates[Entities.U_AmmunitionCart]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_RedPrince]=
MerchantSystem.RefreshRates[Entities.U_MilitarySword_RedPrince]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_Khana]=
MerchantSystem.RefreshRates[Entities.U_MilitarySword_Khana]or 150
MerchantSystem.RefreshRates[Entities.U_MilitarySword]=
MerchantSystem.RefreshRates[Entities.U_MilitarySword]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_RedPrince]=
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_RedPrince]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow]=
MerchantSystem.RefreshRates[Entities.U_MilitaryBow]or 150
if g_GameExtraNo>=1 then
MerchantSystem.BasePrices[Entities.U_MilitaryBow_Khana]=
MerchantSystem.BasePrices[Entities.U_MilitaryBow_Khana]or 220
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_Khana]=
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_Khana]or 150 end end
function BundleTradingFunctions.Global:GetOfferInformation(Q)
local h3ckJGMR=Logic.GetStoreHouse(Q)if not IsExisting(h3ckJGMR)then return end
local MD={Player=Q,Storehouse=h3ckJGMR,OfferCount=0}local pgP=0;local Vrp0=Logic.GetNumberOfMerchants(h3ckJGMR)
for JjW89=0,Vrp0-1,1 do
local _={}
local _g3urPc3D={Logic.GetMerchantOfferIDs(h3ckJGMR,JjW89,Q)}
for SM=1,#_g3urPc3D do pgP=pgP+1;local cRR1,Bqw19,E6W1701,kxGV49HY
local AyUn=Module_TradingTools.Global.GetTraderType(JjW89)
if AyUn==QSB.TraderTypes.GoodTrader then
cRR1,Bqw19,E6W1701,kxGV49HY=Logic.GetGoodTraderOffer(h3ckJGMR,_g3urPc3D[SM],Q)elseif AyUn==QSB.TraderTypes.MercenaryTrader then
cRR1,Bqw19,E6W1701,kxGV49HY=Logic.GetMercenaryOffer(h3ckJGMR,_g3urPc3D[SM],Q)else
cRR1,Bqw19,E6W1701,kxGV49HY=Logic.GetEntertainerTraderOffer(h3ckJGMR,_g3urPc3D[SM],Q)end
table.insert(_,{TraderID=JjW89,OfferID=_g3urPc3D[SM],GoodType=cRR1,OfferGoodAmount=Bqw19,OfferAmount=E6W1701})end;table.insert(MD,_)end;MD.OfferCount=pgP;return MD end
function BundleTradingFunctions.Global:GetOfferCount(ef)
local _TqiEr=self:GetOfferInformation(ef)return _TqiEr.OfferCount end
function BundleTradingFunctions.Global:GetOfferAndTrader(XtH5tUhB,axx10_E)
local ZPS=self:GetOfferInformation(XtH5tUhB)
for z_1=1,#ZPS,1 do
for _Ku7c55H=1,#ZPS,1 do if ZPS[z_1][_Ku7c55H].GoodType==axx10_E then
return
ZPS[z_1][_Ku7c55H].OfferID,ZPS[z_1][_Ku7c55H].TraderID,ZPS.Storehouse end end end end
function BundleTradingFunctions.Global:GetTraderType(OxJrIIC,zS_sFFQ)
if
Logic.IsGoodTrader(BuildingID,zS_sFFQ)==true then return QSB.TraderTypes.GoodTrader elseif
Logic.IsMercenaryTrader(BuildingID,zS_sFFQ)==true then return QSB.TraderTypes.MercenaryTrader elseif
Logic.IsMercenaryTrader(BuildingID,zS_sFFQ)==true then return QSB.TraderTypes.EntertainerTrader else return
QSB.TraderTypes.Unknown end end
function BundleTradingFunctions.Global:GetTrader(Z2dF,jIQDRc)local YQKnxoK1
local paubo=Logic.GetNumberOfMerchants(BuildingID)for A=0,paubo-1,1 do
if self:GetTraderType(BuildingID)==jIQDRc then YQKnxoK1=A;break end end;return YQKnxoK1 end
function BundleTradingFunctions.Global:RemoveOfferByIndex(hB,I,Enz)
local N6upEtl=Logic.GetStoreHouse(hB)if not IsExisting(N6upEtl)then return end;Enz=Enz or 0
local JZ2=self:GetTrader(hB,I)
if JZ2 ~=nil then Logic.RemoveOffer(N6upEtl,JZ2,Enz)end end
function BundleTradingFunctions.Global:RemoveOffer(ru,PE8qH8Ae)
local KiN,oII,I=self:GetOfferAndTrader(ru,PE8qH8Ae)
if KiN and oII and I then Logic.RemoveOffer(I,oII,KiN)end end
function BundleTradingFunctions.Global:ModifyTraderOffer(iTIJNq,t9,gPhmURR,Ru)local CEnSB=GetID(iTIJNq)if not
IsExisting(CEnSB)then return end
Logic.ModifyTraderOffer(CEnSB,t9,gPhmURR,Ru)end
function BundleTradingFunctions.Global:TravelingSalesman_GetHumanPlayer()local vy8=1
for nW=1,8 do if
Logic.PlayerGetIsHumanFlag(1)==true then vy8=nW;break end end;return vy8 end
function BundleTradingFunctions.Global:TravelingSalesman_Create(RqtR,pnwh,Bx,qnz,dH)
assert(type(RqtR)=="number")assert(type(pnwh)=="table")
Bx=Bx or{{3,5},{8,10}}assert(type(Bx)=="table")
assert(type(qnz)=="table")
if not dH then dH={}for z=#qnz,1,-1 do dH[#qnz+1-z]=qnz[z]end end
if not QSB.TravelingSalesman.Harbors[RqtR]then
QSB.TravelingSalesman.Harbors[RqtR]={}
QSB.TravelingSalesman.Harbors[RqtR].Waypoints=qnz
QSB.TravelingSalesman.Harbors[RqtR].Reversed=dH
QSB.TravelingSalesman.Harbors[RqtR].SpawnPos=qnz[1]
QSB.TravelingSalesman.Harbors[RqtR].Destination=dH[1]
QSB.TravelingSalesman.Harbors[RqtR].Appearance=Bx
QSB.TravelingSalesman.Harbors[RqtR].Status=0
QSB.TravelingSalesman.Harbors[RqtR].Offer=pnwh
QSB.TravelingSalesman.Harbors[RqtR].LastOffer=0 end;math.randomseed(Logic.GetTimeMs())if not
QSB.TravelingSalesman.JobID then
QSB.TravelingSalesman.JobID=StartSimpleJob("TravelingSalesman_Control")end end
function BundleTradingFunctions.Global:TravelingSalesman_Disband(B6)
assert(type(B6)=="number")QSB.TravelingSalesman.Harbors[B6]=nil
Logic.RemoveAllOffers(Logic.GetStoreHouse(B6))
DestroyEntity("TravelingSalesmanShip_Player"..B6)end
function BundleTradingFunctions.Global:TravelingSalesman_AddOffer(h3a55v)
MerchantSystem.TradeBlackList[h3a55v]={}MerchantSystem.TradeBlackList[h3a55v][0]=#
MerchantSystem.TradeBlackList[3]
local XJw=Logic.GetStoreHouse(h3a55v)local _HqCsd=1
if#
QSB.TravelingSalesman.Harbors[h3a55v].Offer>1 then repeat
_HqCsd=math.random(1,#
QSB.TravelingSalesman.Harbors[h3a55v].Offer)until
(_HqCsd~=QSB.TravelingSalesman.Harbors[h3a55v].LastOffer)end
QSB.TravelingSalesman.Harbors[h3a55v].LastOffer=_HqCsd
local R9=QSB.TravelingSalesman.Harbors[h3a55v].Offer[_HqCsd]Logic.RemoveAllOffers(XJw)
if#R9 >0 then
for Wl5=1,#R9,1 do local E_m3=R9[Wl5][1]
local O=false;for Kb,tOJHD in pairs(Goods)do if Kb==E_m3 then O=true end end
if O then
local VY=R9[Wl5][2]AddOffer(XJw,VY,Goods[E_m3],9999)else
if
Logic.IsEntityTypeInCategory(Entities[E_m3],EntityCategories.Military)==0 then
AddEntertainerOffer(XJw,Entities[E_m3])else local KAthKTtZ=R9[Wl5][2]
AddMercenaryOffer(XJw,KAthKTtZ,Entities[E_m3],9999)end end end end
SetDiplomacyState(self:TravelingSalesman_GetHumanPlayer(),h3a55v,DiplomacyStates.TradeContact)
ActivateMerchantPermanentlyForPlayer(Logic.GetStoreHouse(h3a55v),self:TravelingSalesman_GetHumanPlayer())local xbYPhUk1=
(IsBriefingActive and not IsBriefingActive())or true
if xbYPhUk1 then
local V={de="Ein Schiff hat angelegt. Es bringt Güter von weit her.",en="A ship is at the pier. It deliver goods from far away."}local SoEK=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
QuestTemplate:New(
"TravelingSalesman_Info_P"..h3a55v,h3a55v,self:TravelingSalesman_GetHumanPlayer(),{{Objective.Dummy}},{{Triggers.Time,0}},0,
nil,nil,nil,nil,false,true,nil,nil,V[SoEK],nil)end end
function BundleTradingFunctions.Global.TravelingSalesman_Control()
for BC,gOX in
pairs(QSB.TravelingSalesman.Harbors)do
if QSB.TravelingSalesman.Harbors[BC]~=nil then
if
gOX.Status==0 then local blA=Logic.GetCurrentMonth()local M=false
for XCNzm=1,#gOX.Appearance,1 do if blA==
gOX.Appearance[XCNzm][1]then M=true end end
if M then
local W4yLXpub=Logic.GetEntityOrientation(GetID(gOX.SpawnPos))
local YTocq=CreateEntity(0,Entities.D_X_TradeShip,GetPosition(gOX.SpawnPos),"TravelingSalesmanShip_Player"..BC,W4yLXpub)
Path:new(YTocq,gOX.Waypoints,nil,nil,nil,nil,true,nil,nil,300)gOX.Status=1 end elseif gOX.Status==1 then
if
IsNear("TravelingSalesmanShip_Player"..BC,gOX.Destination,400)then
BundleTradingFunctions.Global:TravelingSalesman_AddOffer(BC)gOX.Status=2 end elseif gOX.Status==2 then local H=Logic.GetCurrentMonth()local rW_DDL=false;for S1p9l=1,#gOX.Appearance,1
do
if H==gOX.Appearance[S1p9l][2]then rW_DDL=true end end
if rW_DDL then
SetDiplomacyState(BundleTradingFunctions.Global:TravelingSalesman_GetHumanPlayer(),BC,DiplomacyStates.EstablishedContact)
Path:new(GetID("TravelingSalesmanShip_Player"..BC),gOX.Reversed,nil,nil,nil,nil,true,
nil,nil,300)
Logic.RemoveAllOffers(Logic.GetStoreHouse(BC))gOX.Status=3 end elseif gOX.Status==3 then
if
IsNear("TravelingSalesmanShip_Player"..BC,gOX.SpawnPos,400)then
DestroyEntity("TravelingSalesmanShip_Player"..BC)gOX.Status=0 end end end end end;function BundleTradingFunctions.Local:Install()end
Core:RegisterBundle("BundleTradingFunctions")API=API or{}QSB=QSB or{}
function API.StartMusic(XlKy3jRN)if GUI then
API.Log("Could not execute API.StartMusic in local script!")return end
BundleMusicTools.Global:StartSong(XlKy3jRN)end;StartMusic=API.StartMusic
function API.StartMusicSimple(X7,Na3Wmw,oK1ElTh,VjQQjk)if GUI then
API.Bridge("API.StartMusicSimple('"..X7 ..
"', "..Na3Wmw..", "..oK1ElTh..", "..VjQQjk..
")")return end
local H={File=X7,Volume=Na3Wmw,Length=oK1ElTh,Fadeout=VjQQjk*10,MuteAtmo=true,MuteUI=true}BundleMusicTools.Global:StartSong(H)end;StartMusicSimple=API.StartMusicSimple
function API.StartPlaylist(NA2LCmvR)if GUI then
API.Log("Could not execute API.StartPlaylist in local script!")return end
BundleMusicTools.Global:StartPlaylist(NA2LCmvR)end;StartPlaylist=API.StartPlaylist
function API.StartPlaylistTitle(wYCYzS)if GUI then
API.Log("Could not execute API.StartPlaylistTitle in local script!")return end
BundleMusicTools.Global:StartPlaylistTitle(wYCYzS)end;StartPlaylistTitle=API.StartPlaylistTitle;function API.StopSong()if GUI then
API.Bridge("API.StopSong()")return end
BundleMusicTools.Global:StopSong()end
StopSong=API.StopSong
function API.AbortMusic()
if GUI then API.Bridge("API.AbortMusic()")return end;BundleMusicTools.Global:AbortMusic()end;AbortSongOrPlaylist=API.AbortMusic
BundleMusicTools={Global={Data={StartSongData={},StartSongPlaylist={},StartSongQueue={}}},Local={Data={SoundBackup={}}}}function BundleMusicTools.Global:Install()end
function BundleMusicTools.Global:StartSong(ZF6g1)
if
self.Data.StartSongData.Running then table.insert(self.Data.StartSongQueue,ZF6g1)else assert(
type(ZF6g1.File)=="string")assert(type(ZF6g1.Volume)==
"number")assert(type(ZF6g1.Length)==
"number")
ZF6g1.Length=ZF6g1.Length*10
assert(type(ZF6g1.Fadeout)=="number")ZF6g1.MuteAtmo=ZF6g1.MuteAtmo==true
ZF6g1.MuteUI=ZF6g1.MuteUI==true;ZF6g1.CurrentVolume=ZF6g1.Volume;ZF6g1.Time=0
self.Data.StartSongData=ZF6g1;self.Data.StartSongData.Running=true
Logic.ExecuteInLuaLocalState(
[[
            BundleMusicTools.Local:BackupSound(
                ]]..
ZF6g1.Volume..
[[,
                "]]..ZF6g1.File..
[[",
                ]]..tostring(ZF6g1.MuteAtmo)..

[[,
                ]]..tostring(ZF6g1.MuteUI)..[[
            )
        ]])if not self.Data.StartSongJob then
self.Data.StartSongJob=StartSimpleHiResJob("StartSongControl")end end end
function BundleMusicTools.Global:StartPlaylist(ZeB)
for G=1,#ZeB,1 do
table.insert(self.Data.StartSongPlaylist,ZeB[G])self:StartSong(ZeB[G])end
self.Data.StartSongPlaylist.Repeat=ZeB.Repeat==true end
function BundleMusicTools.Global:StartPlaylistTitle(mSwrC)
local JsIicgS=self.Data.StartSongPlaylist;local aKpAgOBl=#length
if(aKpAgOBl>=mSwrC)then
self.Data.StartSongData.Running=false;self.Data.StartSongQueue={}self.Data.StartSongData={}
self:StopSong()EndJob(self.Data.StartSongJob)
self.Data.StartSongJob=nil;for f7=mSwrC,aKpAgOBl,1 do self:StartSong(JsIicgS)end end end
function BundleMusicTools.Global:StopSong()
local EZXcK4=#self.Data.StartSongQueue;local bBKWP8=self.Data.StartSongData
Logic.ExecuteInLuaLocalState(
[[
        BundleMusicTools.Local:ResetSound(
            "]]..

((bBKWP8.File~=nil and bBKWP8.File)or"")..[[",
            ]]..EZXcK4 ..[[
        )
    ]])end
function BundleMusicTools.Global:AbortMusic()self.Data.StartSongPlaylist={}
self.Data.StartSongQueue={}self:StopSong()self.Data.StartSongData={}
EndJob(self.Data.StartSongJob)self.Data.StartSongJob=nil end
function BundleMusicTools.Global.StartSongControl()
if not
BundleMusicTools.Global.Data.StartSongData.Running then
BundleMusicTools.Global.Data.StartSongData={}
BundleMusicTools.Global.Data.StartSongJob=nil
if
#BundleMusicTools.Global.Data.StartSongQueue>0 then
local U=table.remove(BundleMusicTools.Global.Data.StartSongQueue,1)BundleMusicTools.Global:StartSong(U)else if
BundleMusicTools.Global.Data.StartSongPlaylist.Repeat then
BundleMusicTools.Global:StartPlaylist(BundleMusicTools.Global.Data.StartSongPlaylist)end end;return true end
local Ozn2ob=BundleMusicTools.Global.Data.StartSongData;BundleMusicTools.Global.Data.StartSongData.Time=
Ozn2ob.Time+1
if Ozn2ob.Fadeout<5 then
if
Ozn2ob.Time>=Ozn2ob.Length then
BundleMusicTools.Global.Data.StartSongData.Running=false;BundleMusicTools.Global:StopSong()end else local nHXCWoK=Ozn2ob.Length-Ozn2ob.Fadeout+1
if
Ozn2ob.Time>=nHXCWoK then
if Ozn2ob.Time>=Ozn2ob.Length then
BundleMusicTools.Global.Data.StartSongData.Running=false;BundleMusicTools.Global:StopSong()else local Rk=
Ozn2ob.Volume/Ozn2ob.Fadeout;BundleMusicTools.Global.Data.StartSongData.CurrentVolume=
Ozn2ob.CurrentVolume-Rk
Logic.ExecuteInLuaLocalState(
[[
                    Sound.SetSpeechVolume(]]..Ozn2ob.CurrentVolume..[[)
                ]])end end end end
StartSongControl=BundleMusicTools.Global.StartSongControl;function BundleMusicTools.Local:Install()end
function BundleMusicTools.Local:BackupSound(X2L5kdSj,sv,qpVqVyu,Jch)
if
self.Data.SoundBackup.FXSP==nil then
self.Data.SoundBackup.FXSP=Sound.GetFXSoundpointVolume()
self.Data.SoundBackup.FXAtmo=Sound.GetFXAtmoVolume()self.Data.SoundBackup.FXVol=Sound.GetFXVolume()
self.Data.SoundBackup.Sound=Sound.GetGlobalVolume()
self.Data.SoundBackup.Music=Sound.GetMusicVolume()
self.Data.SoundBackup.Voice=Sound.GetSpeechVolume()self.Data.SoundBackup.UI=Sound.Get2DFXVolume()end;Sound.SetFXVolume(100)
Sound.SetSpeechVolume(X2L5kdSj)if qpVqVyu==true then Sound.SetFXSoundpointVolume(0)
Sound.SetFXAtmoVolume(0)end;if Jch==true then
Sound.Set2DFXVolume(0)Sound.SetFXVolume(0)end
Sound.SetMusicVolume(0)Sound.PlayVoice("ImportantStuff",sv)end
function BundleMusicTools.Local:ResetSound(yA3_MrG,XiL)if yA3_MrG~=nil then
Sound.StopVoice("ImportantStuff",yA3_MrG)end
if XiL<=0 then
if
self.Data.SoundBackup.FXSP~=nil then
Sound.SetFXSoundpointVolume(self.Data.SoundBackup.FXSP)
Sound.SetFXAtmoVolume(self.Data.SoundBackup.FXAtmo)
Sound.SetFXVolume(self.Data.SoundBackup.FXVol)
Sound.SetGlobalVolume(self.Data.SoundBackup.Sound)
Sound.SetMusicVolume(self.Data.SoundBackup.Music)
Sound.SetSpeechVolume(self.Data.SoundBackup.Voice)
Sound.Set2DFXVolume(self.Data.SoundBackup.UI)self.Data.SoundBackup={}end end end;Core:RegisterBundle("BundleMusicTools")API=API or{}QSB=
QSB or{}
function API.GetScale(br)if not IsExisting(br)then local e=
(type(br)=="string"and"'"..br.."'")or br;API.Dbg("API.GetScale: Target "..
e.." is invalid!")
return-1 end;return
BundleEntityScriptingValues:GetEntitySize(br)end;GetScale=API.GetScale
function API.GetPlayer(iot)
if not IsExisting(iot)then
local x4HMqofS=(type(iot)=="string"and
"'"..iot.."'")or iot
API.Dbg("API.GetPlayer: Target "..x4HMqofS.." is invalid!")return-1 end
return BundleEntityScriptingValues:GetPlayerID(_entity)end;AGetPlayer=API.GetPlayer
function API.GetMovingTarget(O8C)
if not IsExisting(O8C)then
local IcjWO7p=(
type(O8C)=="string"and"'"..O8C.."'")or O8C
API.Dbg("API.GetMovingTarget: Target "..IcjWO7p.." is invalid!")return nil end
return BundleEntityScriptingValues:GetMovingTargetPosition(O8C)end;GetMovingTarget=API.GetMovingTarget
function API.IsNpc(Vv4Mnuz)
if not IsExisting(Vv4Mnuz)then local L=
(
type(Vv4Mnuz)=="string"and"'"..Vv4Mnuz.."'")or Vv4Mnuz
API.Dbg(
"API.IsNpc: Target "..L.." is invalid!")return false end;return
BundleEntityScriptingValues:IsOnScreenInformationActive(Vv4Mnuz)end;IsNpc=API.IsNpc
function API.IsVisible(u51)
if not IsExisting(u51)then
local oNX=(type(u51)=="string"and"'"..
u51 .."'")or u51
API.Dbg("API.IsVisible: Target "..oNX.." is invalid!")return false end
return BundleEntityScriptingValues:IsEntityVisible(u51)end;IsVisible=API.IsVisible
function API.SetScale(wlr4z,FCKvK1)
if GUI or not IsExisting(wlr4z)then local Aj=(
type(wlr4z)=="string"and"'"..wlr4z.."'")or
wlr4z
API.Dbg("API.SetScale: Target "..Aj..
" is invalid!")return end;if type(FCKvK1)~="number"then
API.Dbg("API.SetScale: Scale must be a number!")return end;return
BundleEntityScriptingValues.Global:SetEntitySize(wlr4z,FCKvK1)end;SetScale=API.SetScale
function API.SetPlayer(YqjKv,iWixd2I0)
if GUI or not IsExisting(YqjKv)then local Xl1lLI=(
type(YqjKv)=="string"and"'"..YqjKv.."'")or
YqjKv
API.Dbg("API.SetPlayer: Target "..
Xl1lLI.." is invalid!")return end;if
type(iWixd2I0)~="number"or iWixd2I0 <=0 or iWixd2I0 >8 then
API.Dbg("API.SetPlayer: Player-ID must between 0 and 8!")return end;return
BundleEntityScriptingValues.Global:SetPlayerID(YqjKv,math.floor(iWixd2I0))end;ChangePlayer=API.SetPlayer
BundleEntityScriptingValues={Global={Data={}},Local={Data={}}}
function BundleEntityScriptingValues.Global:Install()end
function BundleEntityScriptingValues.Global:SetEntitySize(DMQ5HD,RLhK54E)
local eRTiz7g=GetID(DMQ5HD)
Logic.SetEntityScriptingValue(eRTiz7g,-45,BundleEntityScriptingValues:Float2Int(RLhK54E))if Logic.IsSettler(eRTiz7g)==1 then
Logic.SetSpeedFactor(eRTiz7g,RLhK54E)end end
function BundleEntityScriptingValues.Global:SetPlayerID(jXL,PkLOGsOP)local bFn=GetID(jXL)Logic.SetEntityScriptingValue(bFn,
-71,PkLOGsOP)end
function BundleEntityScriptingValues.Local:Install()end
function BundleEntityScriptingValues:GetEntitySize(oTpxIYi)local PR=GetID(oTpxIYi)local c=Logic.GetEntityScriptingValue(PR,
-45)return self.Int2Float(c)end
function BundleEntityScriptingValues:GetPlayerID(keW5h)local b6Txh=GetID(keW5h)return Logic.GetEntityScriptingValue(b6Txh,
-71)end
function BundleEntityScriptingValues:IsEntityVisible(SpoUBD7w)local ho1FzW=GetID(SpoUBD7w)
return Logic.GetEntityScriptingValue(ho1FzW,
-50)==801280 end
function BundleEntityScriptingValues:IsOnScreenInformationActive(GO9HlQ)local O7=GetID(GO9HlQ)if
Logic.IsSettler(O7)==0 then return false end;return
Logic.GetEntityScriptingValue(O7,6)==1 end
function BundleEntityScriptingValues:GetMovingTargetPosition(pQ)local CFLVvMz={}
CFLVvMz.X=self:GetValueAsFloat(pQ,19)CFLVvMz.Y=self:GetValueAsFloat(pQ,20)return CFLVvMz end
function BundleEntityScriptingValues:GetValueAsInteger(mPz,WlGwky)
local RtZZtr=Logic.GetEntityScriptingValue(GetID(mPz),WlGwky)return RtZZtr end
function BundleEntityScriptingValues:GetValueAsFloat(ePsw,rf2m)
local BiM=Logic.GetEntityScriptingValue(GetID(ePsw),rf2m)return SV.Int2Float(BiM)end;function BundleEntityScriptingValues:qmod(uOhNz2,sB3)return
uOhNz2-math.floor(uOhNz2/sB3)*sB3 end
function BundleEntityScriptingValues:Int2Float(EDVCd3v)if(
EDVCd3v==0)then return 0 end;local sFBE3=1;if(EDVCd3v<0)then
EDVCd3v=2147483648+EDVCd3v;sFBE3=-1 end
local DZyBzIT=self:qmod(EDVCd3v,8388608)local zrljL4=(EDVCd3v-DZyBzIT)/8388608
local m6=self:qmod(zrljL4,256)local aLSR=m6-127;local P3xSJvRy=1;local iQQ=0.5;local Y=4194304
for R1oor_ww=23,0,-1 do if(DZyBzIT-Y)>0 then
P3xSJvRy=P3xSJvRy+iQQ;DZyBzIT=DZyBzIT-Y end;Y=Y/2;iQQ=iQQ/2 end;return P3xSJvRy*math.pow(2,aLSR)*sFBE3 end
function BundleEntityScriptingValues:bitsInt(QKN)local oe_q={}while QKN>0 do rest=self:qmod(QKN,2)
table.insert(oe_q,1,rest)QKN=(QKN-rest)/2 end
table.remove(oe_q,1)return oe_q end
function BundleEntityScriptingValues:bitsFrac(KklVg,TWY9IDRT)
for EjuwR=1,48 do KklVg=KklVg*2
if(KklVg>=1)then
table.insert(TWY9IDRT,1)KklVg=KklVg-1 else table.insert(TWY9IDRT,0)end;if(KklVg==0)then return TWY9IDRT end end;return TWY9IDRT end
function BundleEntityScriptingValues:Float2Int(nqG_)if(nqG_==0)then return 0 end;local RL4Ijr=false;if
(nqG_<0)then RL4Ijr=true;nqG_=nqG_*-1 end;local km=0;local LnB;local Lto_pkw=0
if nqG_>=1 then
local JLPz9w=math.floor(nqG_)local i=nqG_-JLPz9w;LnB=self:bitsInt(JLPz9w)
Lto_pkw=table.getn(LnB)self:bitsFrac(i,LnB)else LnB={}self:bitsFrac(nqG_,LnB)
while(
LnB[1]==0)do Lto_pkw=Lto_pkw-1;table.remove(LnB,1)end;Lto_pkw=Lto_pkw-1;table.remove(LnB,1)end;local P=4194304;local zR=1;for E=zR,23 do local d6=LnB[E]if(not d6)then break end
if(d6 ==1)then km=km+P end;P=P/2 end;km=km+
(Lto_pkw+127)*8388608;if(RL4Ijr)then km=km-2147483648 end
return km end
Core:RegisterBundle("BundleEntityScriptingValues")API=API or{}QSB=QSB or{}
function API.AddEntity(Ozu1y)
if not GUI then
Logic.ExecuteInLuaLocalState([[
            API.AddEntity("]]..
Ozu1y..[[")
        ]])else if not
Inside(_enitry,BundleConstructionControl.Local.Data.Entities)then
table.insert(BundleConstructionControl.Local.Data.Entities,Ozu1y)end end end
function API.AddEntityType(QCp0)
if not GUI then
Logic.ExecuteInLuaLocalState([[
            API.AddEntityType(]]..QCp0 ..[[)
        ]])else if not
Inside(_enitry,BundleConstructionControl.Local.Data.EntityTypes)then
table.insert(BundleConstructionControl.Local.Data.EntityTypes,QCp0)end end end
function API.AddCategory(fYg9P7)
if not GUI then
Logic.ExecuteInLuaLocalState([[
            API.AddCategory(]]..fYg9P7 ..[[)
        ]])else
if not
Inside(_enitry,BundleConstructionControl.Local.Data.EntityCategories)then
table.insert(BundleConstructionControl.Local.Data.EntityCategories,fYg9P7)end end end
function API.AddTerritory(iYVq)
if not GUI then
Logic.ExecuteInLuaLocalState([[
            API.AddTerritory(]]..iYVq..[[)
        ]])else if not
Inside(_enitry,BundleConstructionControl.Local.Data.OnTerritory)then
table.insert(BundleConstructionControl.Local.Data.OnTerritory,iYVq)end end end
function API.RemoveEntity(wupYZnQr)
if not GUI then
Logic.ExecuteInLuaLocalState([[
            API.RemoveEntity("]]..wupYZnQr..[[")
        ]])else
for J0PG0o=1,#BundleConstructionControl.Local.Data.Entities
do
if
BundleConstructionControl.Local.Data.Entities[J0PG0o]==wupYZnQr then
table.remove(BundleConstructionControl.Local.Data.Entities,J0PG0o)return end end end end
function API.RemoveEntityType(tiVZj)
if not GUI then
Logic.ExecuteInLuaLocalState([[
            API.RemoveEntityType(]]..tiVZj..[[)
        ]])else
for _v6=1,#BundleConstructionControl.Local.Data.EntityTypes
do
if
BundleConstructionControl.Local.Data.EntityTypes[_v6]==tiVZj then
table.remove(BundleConstructionControl.Local.Data.EntityTypes,_v6)return end end end end
function API.RemoveCategory(vW)
if not GUI then
Logic.ExecuteInLuaLocalState([[
            API.RemoveCategory(]]..vW..[[)
        ]])else
for GoJOI=1,#BundleConstructionControl.Local.Data.EntityCategories
do
if
BundleConstructionControl.Local.Data.EntityCategories[GoJOI]==vW then
table.remove(BundleConstructionControl.Local.Data.EntityCategories,GoJOI)return end end end end
function API.RemoveTerritory(L5V5)
if not GUI then
Logic.ExecuteInLuaLocalState([[
            API.RemoveTerritory(]]..L5V5 ..[[)
        ]])else
for S=1,#BundleConstructionControl.Local.Data.OnTerritory
do if
BundleConstructionControl.Local.Data.OnTerritory[S]==L5V5 then
table.remove(BundleConstructionControl.Local.Data.OnTerritory,S)return end end end end
function API.BanTypeAtTerritory(cX4,vreHvTGT)
if GUI then local s0=
(type(_center)=="string"and"'"..vreHvTGT.."'")or vreHvTGT
GUI.SendScriptCommand(
"API.BanTypeAtTerritory("..cX4 ..", "..s0 ..")")return end;if type(vreHvTGT)=="string"then
vreHvTGT=GetTerritoryIDByName(vreHvTGT)end
BundleConstructionControl.Global.Data.TerritoryBlockEntities[cX4]=
BundleConstructionControl.Global.Data.TerritoryBlockEntities[cX4]or{}
if not
Inside(vreHvTGT,BundleConstructionControl.Global.Data.TerritoryBlockEntities[cX4])then
table.insert(BundleConstructionControl.Global.Data.TerritoryBlockEntities[cX4],vreHvTGT)end end
function API.BanCategoryAtTerritory(WJ,oib23Gb)
if GUI then local DQ=
(type(_center)=="string"and"'"..oib23Gb.."'")or oib23Gb
GUI.SendScriptCommand(
"API.BanTypeAtTerritory("..WJ..", "..DQ..")")return end;if type(oib23Gb)=="string"then
oib23Gb=GetTerritoryIDByName(oib23Gb)end
BundleConstructionControl.Global.Data.TerritoryBlockCategories[WJ]=
BundleConstructionControl.Global.Data.TerritoryBlockCategories[WJ]or{}
if not
Inside(oib23Gb,BundleConstructionControl.Global.Data.TerritoryBlockCategories[WJ])then
table.insert(BundleConstructionControl.Global.Data.TerritoryBlockCategories[WJ],oib23Gb)end end
function API.BanTypeInArea(K,X8Ziqc,fm)
if GUI then local QgS=
(type(X8Ziqc)=="string"and"'"..X8Ziqc.."'")or X8Ziqc
GUI.SendScriptCommand(
"API.BanTypeInArea("..K..", "..QgS..", "..fm..")")return end
BundleConstructionControl.Global.Data.AreaBlockEntities[X8Ziqc]=
BundleConstructionControl.Global.Data.AreaBlockEntities[X8Ziqc]or{}
if not
Inside(K,BundleConstructionControl.Global.Data.AreaBlockEntities[X8Ziqc],true)then
table.insert(BundleConstructionControl.Global.Data.AreaBlockEntities[X8Ziqc],{K,fm})end end
function API.BanCategoryInArea(DNuXOE,U,bnA)
if GUI then local qtpDOuy=
(type(U)=="string"and"'"..U.."'")or U
GUI.SendScriptCommand("API.BanCategoryInArea("..DNuXOE..", "..
qtpDOuy..", "..bnA..")")return end
BundleConstructionControl.Global.Data.AreaBlockCategories[U]=
BundleConstructionControl.Global.Data.AreaBlockCategories[U]or{}
if not
Inside(DNuXOE,BundleConstructionControl.Global.Data.AreaBlockCategories[U],true)then
table.insert(BundleConstructionControl.Global.Data.AreaBlockCategories[U],{DNuXOE,bnA})end end
function API.UnBanTypeAtTerritory(pJeOTrBz,oMEOx)
if GUI then local P1=
(type(_center)=="string"and"'"..oMEOx.."'")or oMEOx
GUI.SendScriptCommand(
"API.UnBanTypeAtTerritory("..pJeOTrBz..", "..P1 ..")")return end
if type(oMEOx)=="string"then oMEOx=GetTerritoryIDByName(oMEOx)end
if not
BundleConstructionControl.Global.Data.TerritoryBlockEntities[pJeOTrBz]then return end
for A=1,BundleConstructionControl.Global.Data.TerritoryBlockEntities[pJeOTrBz],1
do
if
BundleConstructionControl.Global.Data.TerritoryBlockEntities[pJeOTrBz][A]==pJeOTrBz then
table.remove(BundleConstructionControl.Global.Data.TerritoryBlockEntities[pJeOTrBz],A)break end end end
function API.UnBanCategoryAtTerritory(AJancK03,dpxx)
if GUI then local QmtHoP2=
(type(_center)=="string"and"'"..dpxx.."'")or dpxx
GUI.SendScriptCommand(
"API.UnBanTypeAtTerritory("..AJancK03 ..", "..QmtHoP2 ..")")return end
if type(dpxx)=="string"then dpxx=GetTerritoryIDByName(dpxx)end
if not
BundleConstructionControl.Global.Data.TerritoryBlockCategories[AJancK03]then return end
for n0=1,BundleConstructionControl.Global.Data.TerritoryBlockCategories[AJancK03],1
do
if
BundleConstructionControl.Global.Data.TerritoryBlockCategories[AJancK03][n0]==_type then
table.remove(BundleConstructionControl.Global.Data.TerritoryBlockCategories[AJancK03],n0)break end end end
function API.UnBanTypeInArea(pAi,rxo)
if GUI then local eCLz=
(type(rxo)=="string"and"'"..rxo.."'")or rxo
GUI.SendScriptCommand("API.UnBanTypeInArea("..
_eCat..", "..eCLz..")")return end
if not
BundleConstructionControl.Global.Data.AreaBlockEntities[rxo]then return end
for Ku=1,BundleConstructionControl.Global.Data.AreaBlockEntities[rxo],1
do
if
BundleConstructionControl.Global.Data.AreaBlockEntities[rxo][Ku][1]==pAi then
table.remove(BundleConstructionControl.Global.Data.AreaBlockEntities[rxo],Ku)break end end end
function API.UnBanCategoryInArea(sHlcIN,D6B)
if GUI then local DpGo7MYy=
(type(D6B)=="string"and"'"..D6B.."'")or D6B
GUI.SendScriptCommand(
"API.UnBanCategoryInArea(".._type..", "..DpGo7MYy..")")return end
if not
BundleConstructionControl.Global.Data.AreaBlockCategories[D6B]then return end
for pRFHMy9=1,BundleConstructionControl.Global.Data.AreaBlockCategories[D6B],1
do
if
BundleConstructionControl.Global.Data.AreaBlockCategories[D6B][pRFHMy9][1]==sHlcIN then
table.remove(BundleConstructionControl.Global.Data.AreaBlockCategories[D6B],pRFHMy9)break end end end
BundleConstructionControl={Global={Data={TerritoryBlockCategories={},TerritoryBlockEntities={},AreaBlockCategories={},AreaBlockEntities={}}},Local={Data={Entities={},EntityTypes={},EntityCategories={},OnTerritory={}}}}
function BundleConstructionControl.Global:Install()
Core:AppendFunction("GameCallback_CanPlayerPlaceBuilding",BundleConstructionControl.Global.CanPlayerPlaceBuilding)end
function BundleConstructionControl.Global.CanPlayerPlaceBuilding(htpqxO,OiNFrve,Ld4,G)
for mxb_8EG,N in
pairs(BundleConstructionControl.Global.Data.TerritoryBlockCategories)do
if N then
for mu,eHdzI in pairs(N)do
if
eHdzI and Logic.GetTerritoryAtPosition(Ld4,G)==eHdzI then if Logic.IsEntityTypeInCategory(OiNFrve,mxb_8EG)==1 then
return false end end end end end
for A,K4bQGe in
pairs(BundleConstructionControl.Global.Data.TerritoryBlockEntities)do
if K4bQGe then
for vi4K,GUFxXd in pairs(K4bQGe)do
GUI_Note(tostring(Logic.GetTerritoryAtPosition(Ld4,G)==GUFxXd))
if
GUFxXd and Logic.GetTerritoryAtPosition(Ld4,G)==GUFxXd then if OiNFrve==A then return false end end end end end
for hmJ,suyU in
pairs(BundleConstructionControl.Global.Data.AreaBlockCategories)do
if suyU then
for iG8VIx,XDL in pairs(suyU)do if
Logic.IsEntityTypeInCategory(OiNFrve,XDL[1])==1 then
if GetDistance(hmJ,{X=Ld4,Y=G})<XDL[2]then return false end end end end end
for aSI03F,So4V_ in
pairs(BundleConstructionControl.Global.Data.AreaBlockEntities)do
if So4V_ then for jfUOP,S1wxFpt in pairs(So4V_)do
if OiNFrve==S1wxFpt[1]then if GetDistance(aSI03F,{X=Ld4,Y=G})<
S1wxFpt[2]then return false end end end end end;return true end
function BundleConstructionControl.Local:Install()
Core:AppendFunction("GameCallback_GUI_DeleteEntityStateBuilding",BundleConstructionControl.Local.DeleteEntityStateBuilding)end
function BundleConstructionControl.Local.DeleteEntityStateBuilding(yd3vMT3M)
local n=Logic.GetEntityType(yd3vMT3M)local ufu5y=Logic.GetEntityName(yd3vMT3M)
local DPXsZ=GetTerritoryUnderEntity(yd3vMT3M)
if Logic.IsConstructionComplete(yd3vMT3M)==1 then
if
Inside(ufu5y,BundleConstructionControl.Local.Data.Entities)then GUI.CancelBuildingKnockDown(yd3vMT3M)return end
if
Inside(n,BundleConstructionControl.Local.Data.EntityTypes)then GUI.CancelBuildingKnockDown(yd3vMT3M)return end
if
Inside(DPXsZ,BundleConstructionControl.Local.Data.OnTerritory)then GUI.CancelBuildingKnockDown(yd3vMT3M)return end
for eA0S,Xf9rC in
pairs(BundleConstructionControl.Local.Data.EntityCategories)do if Logic.IsEntityInCategory(yd3vMT3M,Xf9rC)==1 then
GUI.CancelBuildingKnockDown(yd3vMT3M)return end end end end;Core:RegisterBundle("BundleConstructionControl")API=
API or{}QSB=QSB or{}
function API.DisableRefillTrebuchet(zc)if not GUI then
API.Bridge("API.DisableRefillTrebuchet("..
tostring(zc)..")")return end
API.Bridge(
"BundleEntitySelection.Local.Data.RefillTrebuchet = "..tostring(not zc))
BundleEntitySelection.Local.Data.RefillTrebuchet=not zc end
function API.DisableThiefRelease(bP)if not GUI then
API.Bridge("API.DisableThiefRelease("..tostring(bP)..")")return end;BundleEntitySelection.Local.Data.ThiefRelease=
bP==true end
function API.DisableSiegeEngineRelease(xc)if not GUI then
API.Bridge("API.DisableSiegeEngineRelease("..tostring(xc)..")")return end;BundleEntitySelection.Local.Data.SiegeEngineRelease=
xc==true end
function API.DisableMilitaryRelease(BKVNy5o_)if not GUI then
API.Bridge("API.DisableMilitaryRelease("..tostring(BKVNy5o_)..")")return end;BundleEntitySelection.Local.Data.MilitaryRelease=
BKVNy5o_==true end
BundleEntitySelection={Global={Data={RefillTrebuchet=true,AmmunitionUnderway={},TrebuchetIDToCart={}}},Local={Data={RefillTrebuchet=true,ThiefRelease=true,SiegeEngineRelease=true,MilitaryRelease=true,Tooltips={KnightButton={Title={de="Ritter selektieren",en="Select Knight"},Text={de="- Klick selektiert den Ritter {cr}- Doppelklick springt zum Ritter{cr}- STRG halten selektiert alle Ritter",en="- Click selects the knight {cr}- Double click jumps to knight{cr}- Press CTRL to select all knights"}},BattalionButton={Title={de="Militär selektieren",en="Select Units"},Text={de="- Selektiert alle Militäreinheiten {cr}- SHIFT halten um auch Munitionswagen und Trebuchets auszuwählen",en="- Selects all military units {cr}- Press SHIFT to additionally select ammunition carts and trebuchets"}},ReleaseSoldiers={Title={de="Militär entlassen",en="Release military unit"},Text={de="- Eine Militäreinheit entlassen {cr}- Soldaten werden nacheinander entlassen",en="- Dismiss a military unit {cr}- Soldiers will be dismissed each after another"},Disabled={de="Kann nicht entlassen werden!",en="Releasing is impossible!"}},TrebuchetCart={Title={de="Trebuchetwagen",en="Trebuchet cart"},Text={de="- Kann einmalig zum Trebuchet ausgebaut werden",en="- Can uniquely be transmuted into a trebuchet"}},Trebuchet={Title={de="Trebuchet",en="Trebuchet"},Text={de="- Kann über weite Strecken Gebäude angreifen {cr}- Kann Gebäude in Brand stecken {cr}- Kann nur durch Munitionsanforderung befüllt werden {cr}- Trebuchet kann manuell zurückgeschickt werden",en="- Can perform long range attacks on buildings {cr}- Can set buildings on fire {cr}- Can only be filled by ammunition request {cr}- The trebuchet can be manually send back to the city"}},TrebuchetRefiller={Title={de="Aufladen",en="Refill"},Text={de="- Läd das Trebuchet mit Karren aus dem Lagerhaus nach {cr}- Benötigt die Differenz an Steinen {cr}- Kann jeweils nur einen Wagen zu selben Zeit senden",en="- Refill the Trebuchet with a cart from the storehouse {cr}- Stones for missing ammunition required {cr}- Only one cart at the time allowed"}}}}}}function BundleEntitySelection.Global:Install()end
function BundleEntitySelection.Global:DeactivateRefillTrebuchet(yBEWVGM)self.Data.RefillTrebuchet=
not yBEWVGM
Logic.ExecuteInLuaLocalState(
[[
        function BundleEntitySelection.Local:DeactivateRefillTrebuchet(]]..tostring(yBEWVGM)..[[)
    ]])end
function BundleEntitySelection.Global:MilitaryDisambleTrebuchet(vBNGHh0S)
local gT,_u3A2Kdb,sBd3=Logic.EntityGetPos(vBNGHh0S)local VGgYPo=Logic.EntityGetPlayer(vBNGHh0S)if GameCallback_QSB_OnDisambleTrebuchet then
GameCallback_QSB_OnDisambleTrebuchet(vBNGHh0S,VGgYPo,gT,_u3A2Kdb,sBd3)return end
if
self.Data.AmmunitionUnderway[vBNGHh0S]then
API.Message{de="Eine Munitionslieferung ist auf dem Weg!",en="A ammunition card is on the way!"}return end
Logic.CreateEffect(EGL_Effects.E_Shockwave01,gT,_u3A2Kdb,0)Logic.SetEntityInvulnerabilityFlag(vBNGHh0S,1)
Logic.SetEntitySelectableFlag(vBNGHh0S,0)Logic.SetVisible(vBNGHh0S,false)
local MbaSv=self.Data.TrebuchetIDToCart[vBNGHh0S]
if MbaSv~=nil then Logic.SetEntityInvulnerabilityFlag(MbaSv,0)
Logic.SetEntitySelectableFlag(MbaSv,1)Logic.SetVisible(MbaSv,true)else
MbaSv=Logic.CreateEntity(Entities.U_SiegeEngineCart,gT,_u3A2Kdb,0,VGgYPo)self.Data.TrebuchetIDToCart[vBNGHh0S]=MbaSv end;Logic.DEBUG_SetSettlerPosition(MbaSv,gT,_u3A2Kdb)
Logic.SetTaskList(MbaSv,TaskLists.TL_NPC_IDLE)
Logic.ExecuteInLuaLocalState([[
        GUI.SelectEntity(]]..MbaSv..[[)
    ]])end
function BundleEntitySelection.Global:MilitaryErectTrebuchet(c486nrm8)
local K,i,cy=Logic.EntityGetPos(c486nrm8)local t=Logic.EntityGetPlayer(c486nrm8)if GameCallback_QSB_OnErectTrebuchet then
GameCallback_QSB_OnErectTrebuchet(c486nrm8,t,K,i,cy)return end
Logic.CreateEffect(EGL_Effects.E_Shockwave01,K,i,0)Logic.SetEntityInvulnerabilityFlag(c486nrm8,1)
Logic.SetEntitySelectableFlag(c486nrm8,0)Logic.SetVisible(c486nrm8,false)local vHp
for LU_7,xIgwR in
pairs(self.Data.TrebuchetIDToCart)do if xIgwR==c486nrm8 then vHp=tonumber(LU_7)end end
if vHp==nil then
vHp=Logic.CreateEntity(Entities.U_Trebuchet,K,i,0,t)self.Data.TrebuchetIDToCart[vHp]=c486nrm8 end;Logic.SetEntityInvulnerabilityFlag(vHp,0)
Logic.SetEntitySelectableFlag(vHp,1)Logic.SetVisible(vHp,true)
Logic.DEBUG_SetSettlerPosition(vHp,K,i)
Logic.ExecuteInLuaLocalState([[
        GUI.SelectEntity(]]..vHp..[[)
    ]])end
function BundleEntitySelection.Global:MilitaryCallForRefiller(r0C1)
local dD4=Logic.EntityGetPlayer(r0C1)local bnT=Logic.GetStoreHouse(dD4)
local dTa=Logic.GetAmmunitionAmount(r0C1)local iK0=GetPlayerResources(Goods.G_Stone,dD4)if
GameCallback_tHEA_OnRefillerCartCalled then
GameCallback_tHEA_OnRefillerCartCalled(r0C1,dD4,bnT,dTa,iK0)return end
if
self.Data.AmmunitionUnderway[r0C1]or bnT==0 then
API.Message{de="Eine Munitionslieferung ist auf dem Weg!",en="A ammunition card is on the way!"}return end
if dTa==10 or iK0 <10-dTa then
API.Message{de="Nicht genug Steine oder das Trebuchet ist voll!",en="Not enough stones or the trebuchet is full!"}return end;local kmgJ,Z5nmrSn=Logic.GetBuildingApproachPosition(bnT)
local d=Logic.CreateEntity(Entities.U_AmmunitionCart,kmgJ,Z5nmrSn,0,dD4)self.Data.AmmunitionUnderway[r0C1]={d,10-dTa}
Logic.SetEntityInvulnerabilityFlag(d,1)Logic.SetEntitySelectableFlag(d,0)AddGood(Goods.G_Stone,(10-dTa)*
(-1),dD4)
StartSimpleJobEx(function(u)
local d=self.Data.AmmunitionUnderway[r0C1][1]
local DRoZO=self.Data.AmmunitionUnderway[r0C1][2]
if not IsExisting(d)or not IsExisting(u)then self.Data.AmmunitionUnderway[r0C1]=
nil;return true end
if not Logic.IsEntityMoving(d)then
local kmgJ,Z5nmrSn,LDRZuC=Logic.EntityGetPos(u)Logic.MoveSettler(d,kmgJ,Z5nmrSn)end;if IsNear(d,u,500)then
for Ja=1,DRoZO,1 do Logic.RefillAmmunitions(u)end;DestroyEntity(d)end end,r0C1)end
function BundleEntitySelection.Local:Install()
self:OverwriteSelectAllUnits()self:OverwriteSelectKnight()
self:OverwriteNamesAndDescription()self:OverwriteThiefDeliver()
self:OverwriteMilitaryDismount()self:OverwriteMultiselectIcon()
self:OverwriteMilitaryDisamble()self:OverwriteMilitaryErect()
self:OverwriteMilitaryCommands()self:OverwriteGetStringTableText()
Core:AppendFunction("GameCallback_GUI_SelectionChanged",self.OnSelectionCanged)end;function BundleEntitySelection.Local:DeactivateRefillTrebuchet(U9tg3LeC)
self.Data.RefillTrebuchet=not U9tg3LeC end
function BundleEntitySelection.Local.OnSelectionCanged(MPu)
local zcV={GUI.GetSelectedEntities()}local Kfe=GUI.GetPlayerID()local ifa=GUI.GetSelectedEntity()
local oE=Logic.GetEntityType(ifa)
if ifa~=nil then
if oE==Entities.U_SiegeEngineCart then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/BGMilitary",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/DialogButtons",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/SiegeEngineCart",1)elseif oE==Entities.U_Trebuchet then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/BGMilitary",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/DialogButtons",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military",1)
if BundleEntitySelection.Local.Data.RefillTrebuchet then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military/Attack",1)else
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military/Attack",0)end;GUI_Military.StrengthUpdate()
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/SiegeEngine",1)end end end
function BundleEntitySelection.Local:OverwriteGetStringTableText()
GetStringTableText_Orig_BundleEntitySelection=XGUIEng.GetStringTableText
XGUIEng.GetStringTableText=function(mxYL)local k6k2N=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
if
mxYL=="UI_ObjectDescription/Attack"then local bgY=GUI.GetSelectedEntity()
if Logic.GetEntityType(bgY)==
Entities.U_Trebuchet then return
BundleEntitySelection.Local.Data.Tooltips.TrebuchetRefiller.Text[k6k2N]end end
if mxYL=="UI_ObjectNames/Attack"then local zCj2d=GUI.GetSelectedEntity()
if
Logic.GetEntityType(zCj2d)==Entities.U_Trebuchet then return
BundleEntitySelection.Local.Data.Tooltips.TrebuchetRefiller.Title[k6k2N]end end
return GetStringTableText_Orig_BundleEntitySelection(mxYL)end end
function BundleEntitySelection.Local:OverwriteMilitaryCommands()
GUI_Military.AttackClicked=function()
Sound.FXPlay2DSound("ui\\menu_click")local cIi2b={GUI.GetSelectedEntities()}
local D8JtB=Logic.GetEntityType(cIi2b[1])
if D8JtB==Entities.U_Trebuchet then
for QdzPj=1,#cIi2b,1 do
D8JtB=Logic.GetEntityType(cIi2b[QdzPj])
if D8JtB==Entities.U_Trebuchet then
GUI.SendScriptCommand(
[[
                        BundleEntitySelection.Global:MilitaryCallForRefiller(]]..cIi2b[QdzPj]..[[)
                    ]])end end else GUI.ActivateExplicitAttackCommandState()end end
GUI_Military.StandGroundClicked=function()
Sound.FXPlay2DSound("ui\\menu_click")local J={GUI.GetSelectedEntities()}
for _Bh=1,#J do local KO=J[_Bh]
local l0VzutJ=Logic.GetEntityType(KO)GUI.SendCommandStationaryDefend(KO)
if
l0VzutJ==Entities.U_Trebuchet then
GUI.SendScriptCommand([[
                    Logic.SetTaskList(]]..
KO..[[, TaskLists.TL_NPC_IDLE)
                ]])end end end
GUI_Military.StandGroundUpdate=function()
local Xy5="/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military/Attack"local DNjv9Ky={GUI.GetSelectedEntities()}
SetIcon(Xy5,{12,4})
if#DNjv9Ky==1 then local UmP3TiuM=DNjv9Ky[1]
local gYkgeX=Logic.GetEntityType(UmP3TiuM)
if gYkgeX==Entities.U_Trebuchet then if
Logic.GetAmmunitionAmount(UmP3TiuM)>0 then XGUIEng.ShowWidget(Xy5,0)else
XGUIEng.ShowWidget(Xy5,1)end
SetIcon(Xy5,{1,10})else XGUIEng.ShowWidget(Xy5,1)end end end end
function BundleEntitySelection.Local:OverwriteMilitaryErect()
GUI_Military.ErectClicked_Orig_BundleEntitySelection=GUI_Military.ErectClicked
GUI_Military.ErectClicked=function()
GUI_Military.ErectClicked_Orig_BundleEntitySelection()local OkoDYew1=GUI.GetPlayerID()
local z={GUI.GetSelectedEntities()}
for uXU8F5I=1,#z,1 do local TgkNMHt0=Logic.GetEntityType(z[uXU8F5I])
if TgkNMHt0 ==
Entities.U_SiegeEngineCart then
GUI.SendScriptCommand([[
                    BundleEntitySelection.Global:MilitaryErectTrebuchet(]]..
z[uXU8F5I]..[[)
                ]])end end end
GUI_Military.ErectUpdate_Orig_BundleEntitySelection=GUI_Military.ErectUpdate
GUI_Military.ErectUpdate=function()local xXE15kR0=XGUIEng.GetCurrentWidgetID()
local E_4i=GUI.GetSelectedEntity()local B1odRr=GUI.GetPlayerID()
local fe=Logic.GetEntityType(E_4i)
if fe==Entities.U_SiegeEngineCart then
XGUIEng.DisableButton(xXE15kR0,0)SetIcon(xXE15kR0,{12,6})else
GUI_Military.ErectUpdate_Orig_BundleEntitySelection()end end
GUI_Military.ErectMouseOver_Orig_BundleEntitySelection=GUI_Military.ErectMouseOver
GUI_Military.ErectMouseOver=function()local V1_9X_=GUI.GetSelectedEntity()local zP
if
Logic.GetEntityType(V1_9X_)==Entities.U_SiegeEngineCart then zP="ErectCatapult"else
GUI_Military.ErectMouseOver_Orig_BundleEntitySelection()return end;GUI_Tooltip.TooltipNormal(zP,"Erect")end end
function BundleEntitySelection.Local:OverwriteMilitaryDisamble()
GUI_Military.DisassembleClicked_Orig_BundleEntitySelection=GUI_Military.DisassembleClicked
GUI_Military.DisassembleClicked=function()
GUI_Military.DisassembleClicked_Orig_BundleEntitySelection()local c=GUI.GetPlayerID()
local RPRi={GUI.GetSelectedEntities()}
for iwACPW4_=1,#RPRi,1 do local ThG=Logic.GetEntityType(RPRi[iwACPW4_])
if ThG==
Entities.U_Trebuchet then
GUI.SendScriptCommand([[
                    BundleEntitySelection.Global:MilitaryDisambleTrebuchet(]]..
RPRi[iwACPW4_]..[[)
                ]])end end end
GUI_Military.DisassembleUpdate_Orig_BundleEntitySelection=GUI_Military.DisassembleUpdate
GUI_Military.DisassembleUpdate=function()local s=XGUIEng.GetCurrentWidgetID()
local m380zm=GUI.GetPlayerID()local DzC7FyQx=GUI.GetSelectedEntity()
local ISZGXXOA=Logic.GetEntityType(DzC7FyQx)if ISZGXXOA==Entities.U_Trebuchet then XGUIEng.DisableButton(s,0)
SetIcon(s,{12,9})else
GUI_Military.DisassembleUpdate_Orig_BundleEntitySelection()end end end
function BundleEntitySelection.Local:OverwriteMultiselectIcon()
GUI_MultiSelection.IconUpdate_Orig_BundleEntitySelection=GUI_MultiSelection.IconUpdate
GUI_MultiSelection.IconUpdate=function()local CbgC1=XGUIEng.GetCurrentWidgetID()
local u=XGUIEng.GetWidgetsMotherID(CbgC1)local jQeNH=XGUIEng.GetWidgetNameByID(u)local K=jQeNH+0
local yZY=XGUIEng.GetWidgetPathByID(u)local G=yZY.."/Health"
local SG=g_MultiSelection.EntityList[K]local wp1o=Logic.GetEntityType(SG)
local jRu=Logic.GetEntityHealth(SG)local cVyN=Logic.GetEntityMaxHealth(SG)if
wp1o~=Entities.U_SiegeEngineCart and wp1o~=Entities.U_Trebuchet then
GUI_MultiSelection.IconUpdate_Orig_BundleEntitySelection()return end;if
Logic.IsEntityAlive(SG)==false then XGUIEng.ShowWidget(u,0)
GUI_MultiSelection.CreateEX()return end
SetIcon(CbgC1,g_TexturePositions.Entities[wp1o])jRu=math.floor(jRu/cVyN*100)
if jRu<50 then local T=math.floor(2*255*
(jRu/100))
XGUIEng.SetMaterialColor(G,0,255,T,20,255)else
local Xeg2p=2*255-math.floor(2*255* (jRu/100))XGUIEng.SetMaterialColor(G,0,Xeg2p,255,20,255)end;XGUIEng.SetProgressBarValues(G,jRu,100)end
GUI_MultiSelection.IconMouseOver_Orig_BundleEntitySelection=GUI_MultiSelection.IconMouseOver
GUI_MultiSelection.IconMouseOver=function()local D2=XGUIEng.GetCurrentWidgetID()
local J6il=XGUIEng.GetWidgetsMotherID(D2)local O=XGUIEng.GetWidgetNameByID(J6il)local _4iwPl=tonumber(O)
local n=g_MultiSelection.EntityList[_4iwPl]local noV=Logic.GetEntityType(n)if noV~=Entities.U_SiegeEngineCart and noV~=
Entities.U_Trebuchet then
GUI_MultiSelection.IconMouseOver_Orig_BundleEntitySelection()return end
local Cx6TN=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
if noV==Entities.U_SiegeEngineCart then
local dj7y6V=BundleEntitySelection.Local.Data.Tooltips.TrebuchetCart
BundleEntitySelection.Local:SetTooltip(dj7y6V.Title[Cx6TN],dj7y6V.Text[Cx6TN])elseif noV==Entities.U_Trebuchet then
local V6ly=BundleEntitySelection.Local.Data.Tooltips.Trebuchet
BundleEntitySelection.Local:SetTooltip(V6ly.Title[Cx6TN],V6ly.Text[Cx6TN])end end end
function BundleEntitySelection.Local:OverwriteMilitaryDismount()
GUI_Military.DismountClicked_Orig_BundleEntitySelection=GUI_Military.DismountClicked
GUI_Military.DismountClicked=function()local vMe=GUI.GetSelectedEntity(Selected)
local jWsj0=Logic.GetEntityType(vMe)local _C=GUI.GetPlayerID()
if
Logic.GetGuardianEntityID(vMe)==0 and Logic.IsKnight(vMe)==false then
if

(





jWsj0 ==
Entities.U_SiegeEngineCart or jWsj0 ==Entities.U_MilitarySiegeTower or jWsj0 ==Entities.U_MilitaryCatapult or jWsj0 ==Entities.U_MilitaryBatteringRam or jWsj0 ==Entities.U_SiegeTowerCart or jWsj0 ==Entities.U_CatapultCart or jWsj0 ==Entities.U_BatteringRamCart or jWsj0 ==Entities.U_AmmunitionCart)and BundleEntitySelection.Local.Data.SiegeEngineRelease then Sound.FXPlay2DSound("ui\\menu_click")
GUI.SendScriptCommand(
[[DestroyEntity(]]..vMe..[[)]])return end
if
(Logic.IsLeader(vMe)==1 and
BundleEntitySelection.Local.Data.MilitaryRelease)then Sound.FXPlay2DSound("ui\\menu_click")
local XYX_rOr={Logic.GetSoldiersAttachedToLeader(vMe)}
GUI.SendScriptCommand([[DestroyEntity(]]..XYX_rOr[#XYX_rOr]..[[)]])return end else
GUI_Military.DismountClicked_Orig_BundleEntitySelection()end end
GUI_Military.DismountUpdate_Orig_BundleEntitySelection=GUI_Military.DismountUpdate
GUI_Military.DismountUpdate=function()local R=XGUIEng.GetCurrentWidgetID()
local nqBeV78J=GUI.GetSelectedEntity()local Dz8=Logic.GetEntityType(nqBeV78J)
if
(

Logic.GetGuardianEntityID(nqBeV78J)==0 and Logic.IsKnight(nqBeV78J)==false and
Logic.IsEntityInCategory(nqBeV78J,EntityCategories.AttackableMerchant)==0)then
if Logic.IsLeader(nqBeV78J)==1 and not
BundleEntitySelection.Local.Data.MilitaryRelease then
XGUIEng.DisableButton(R,1)elseif Logic.IsLeader(nqBeV78J)==0 then
if not
BundleEntitySelection.Local.Data.SiegeEngineRelease then XGUIEng.DisableButton(R,1)end
if Dz8 ==Entities.U_Trebuchet then XGUIEng.DisableButton(R,1)end else SetIcon(R,{12,1})XGUIEng.DisableButton(R,0)end;SetIcon(R,{14,12})else SetIcon(R,{12,1})
GUI_Military.DismountUpdate_Orig_BundleEntitySelection()end end end
function BundleEntitySelection.Local:OverwriteThiefDeliver()
GUI_Thief.ThiefDeliverClicked_Orig_BundleEntitySelection=GUI_Thief.ThiefDeliverClicked
GUI_Thief.ThiefDeliverClicked=function()if not self.Data.ThiefRelease then
GUI_Thief.ThiefDeliverClicked_Orig_BundleEntitySelection()return end
Sound.FXPlay2DSound("ui\\menu_click")local bfoxga=GUI.GetPlayerID()local R=GUI.GetSelectedEntity()if

R==nil or Logic.GetEntityType(R)~=Entities.U_Thief then return end
GUI.SendScriptCommand([[DestroyEntity(]]..R..[[)]])end
GUI_Thief.ThiefDeliverMouseOver_Orig_BundleEntitySelection=GUI_Thief.ThiefDeliverMouseOver
GUI_Thief.ThiefDeliverMouseOver=function()
if not
BundleEntitySelection.Local.Data.ThiefRelease then local Jtbsp=XGUIEng.GetCurrentWidgetID()
GUI_Thief.ThiefDeliverMouseOver_Orig_BundleEntitySelection()return end;local MV=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
BundleEntitySelection.Local:SetTooltip(BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Title[MV],BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Text[MV],BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Disabled[MV])end
GUI_Thief.ThiefDeliverUpdate_Orig_BundleEntitySelection=GUI_Thief.ThiefDeliverUpdate
GUI_Thief.ThiefDeliverUpdate=function()
if not
BundleEntitySelection.Local.Data.ThiefRelease then
GUI_Thief.ThiefDeliverUpdate_Orig_BundleEntitySelection()else local h9IOXT=XGUIEng.GetCurrentWidgetID()
local TZeZK=GUI.GetSelectedEntity()if
TZeZK==nil or Logic.GetEntityType(TZeZK)~=Entities.U_Thief then XGUIEng.DisableButton(h9IOXT,1)else
XGUIEng.DisableButton(h9IOXT,0)end
SetIcon(h9IOXT,{14,12})end end end
function BundleEntitySelection.Local:OverwriteNamesAndDescription()
GUI_Tooltip.SetNameAndDescription_Orig_QSB_EntitySelection=GUI_Tooltip.SetNameAndDescription
GUI_Tooltip.SetNameAndDescription=function(X,bblh2jUQ,mjrD,J,bQRIXOF6)local BHzRZg=XGUIEng.GetCurrentWidgetID()
local _=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
if
XGUIEng.GetWidgetID("/InGame/Root/Normal/AlignBottomRight/MapFrame/KnightButton")==BHzRZg then
BundleEntitySelection.Local:SetTooltip(BundleEntitySelection.Local.Data.Tooltips.KnightButton.Title[_],BundleEntitySelection.Local.Data.Tooltips.KnightButton.Text[_])return end
if
XGUIEng.GetWidgetID("/InGame/Root/Normal/AlignBottomRight/MapFrame/BattalionButton")==BHzRZg then
BundleEntitySelection.Local:SetTooltip(BundleEntitySelection.Local.Data.Tooltips.BattalionButton.Title[_],BundleEntitySelection.Local.Data.Tooltips.BattalionButton.Text[_])return end
if
XGUIEng.GetWidgetID("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military/Dismount")==BHzRZg then
local S8_x8n=GUI.GetSelectedEntity()
if S8_x8n~=0 then
if








Logic.IsEntityInCategory(S8_x8n,EntityCategories.Leader)==1 or
Logic.IsEntityInCategory(S8_x8n,EntityCategories.Thief)==1 or
Logic.GetEntityType(S8_x8n)==Entities.U_MilitaryCatapult or
Logic.GetEntityType(S8_x8n)==Entities.U_MilitarySiegeTower or
Logic.GetEntityType(S8_x8n)==Entities.U_MilitaryBatteringRam or Logic.GetEntityType(S8_x8n)==Entities.U_CatapultCart or Logic.GetEntityType(S8_x8n)==Entities.U_SiegeTowerCart or Logic.GetEntityType(S8_x8n)==Entities.U_BatteringRamCart or Logic.GetEntityType(S8_x8n)==Entities.U_SiegeEngineCart or Logic.GetEntityType(S8_x8n)==Entities.U_Trebuchet then local OJV3L=Logic.GetGuardianEntityID(S8_x8n)
if OJV3L==0 then
BundleEntitySelection.Local:SetTooltip(BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Title[_],BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Text[_],BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Disabled[_])return end end end end
GUI_Tooltip.SetNameAndDescription_Orig_QSB_EntitySelection(X,bblh2jUQ,mjrD,J,bQRIXOF6)end end
function BundleEntitySelection.Local:SetTooltip(HLV0hyF,r3ng7UL6,ApPCL)
local Ye="/InGame/Root/Normal/TooltipNormal"local lmpa=XGUIEng.GetWidgetID(Ye)
local U0tw=XGUIEng.GetWidgetID(Ye.."/FadeIn/Name")
local ugS5u9oe=XGUIEng.GetWidgetID(Ye.."/FadeIn/Text")local RNJV7Ms=XGUIEng.GetCurrentWidgetID()ApPCL=ApPCL or""
local FmaDG=""
if
XGUIEng.IsButtonDisabled(RNJV7Ms)==1 and _disabledText~=""and _text~=""then FmaDG=FmaDG..
"{cr}{@color:255,32,32,255}"..ApPCL end;XGUIEng.SetText(U0tw,"{center}"..HLV0hyF)XGUIEng.SetText(ugS5u9oe,
r3ng7UL6 ..FmaDG)
local w6gF6Ig=XGUIEng.GetTextHeight(ugS5u9oe,true)local e,H0msoK=XGUIEng.GetWidgetSize(ugS5u9oe)
XGUIEng.SetWidgetSize(ugS5u9oe,e,w6gF6Ig)end
function BundleEntitySelection.Local:OverwriteSelectKnight()
GUI_Knight.JumpToButtonClicked=function()
local gfWc=GUI.GetPlayerID()local uw26=Logic.GetKnightID(gfWc)
if uw26 >0 then
g_MultiSelection.EntityList={}g_MultiSelection.Highlighted={}GUI.ClearSelection()
if
XGUIEng.IsModifierPressed(Keys.ModifierControl)then local GIyY3={}Logic.GetKnights(gfWc,GIyY3)for VYC1x3=1,#GIyY3 do
GUI.SelectEntity(GIyY3[VYC1x3])end else
GUI.SelectEntity(Logic.GetKnightID(gfWc))
if
(
(Framework.GetTimeMs()-g_Selection.LastClickTime)<g_Selection.MaxDoubleClickTime)then local b=GetPosition(uw26)
Camera.RTS_SetLookAtPosition(b.X,b.Y)else Sound.FXPlay2DSound("ui\\mini_knight")end;g_Selection.LastClickTime=Framework.GetTimeMs()end
GUI_MultiSelection.CreateMultiSelection(g_SelectionChangedSource.User)else GUI.AddNote("Debug: You do not have a knight")end end end
function BundleEntitySelection.Local:OverwriteSelectAllUnits()
GUI_MultiSelection.SelectAllPlayerUnitsClicked=function()
if
XGUIEng.IsModifierPressed(Keys.ModifierShift)then
BundleEntitySelection.Local:ExtendedLeaderSortOrder()else
BundleEntitySelection.Local:NormalLeaderSortOrder()end;Sound.FXPlay2DSound("ui\\menu_click")
GUI.ClearSelection()local u_LrUR3v=GUI.GetPlayerID()
for Ko_5wHh=1,#LeaderSortOrder do
local erJtM=GetPlayerEntities(u_LrUR3v,LeaderSortOrder[Ko_5wHh])for H=1,#erJtM do GUI.SelectEntity(erJtM[H])end end;local TNyTHq={}Logic.GetKnights(u_LrUR3v,TNyTHq)for KN=1,#TNyTHq do
GUI.SelectEntity(TNyTHq[KN])end
GUI_MultiSelection.CreateMultiSelection(g_SelectionChangedSource.User)end end
function BundleEntitySelection.Local:NormalLeaderSortOrder()g_MultiSelection={}
g_MultiSelection.EntityList={}g_MultiSelection.Highlighted={}LeaderSortOrder={}
LeaderSortOrder[1]=Entities.U_MilitarySword;LeaderSortOrder[2]=Entities.U_MilitaryBow
LeaderSortOrder[3]=Entities.U_MilitarySword_RedPrince;LeaderSortOrder[4]=Entities.U_MilitaryBow_RedPrince
LeaderSortOrder[5]=Entities.U_MilitaryBandit_Melee_ME;LeaderSortOrder[6]=Entities.U_MilitaryBandit_Melee_NA
LeaderSortOrder[7]=Entities.U_MilitaryBandit_Melee_NE;LeaderSortOrder[8]=Entities.U_MilitaryBandit_Melee_SE
LeaderSortOrder[9]=Entities.U_MilitaryBandit_Ranged_ME;LeaderSortOrder[10]=Entities.U_MilitaryBandit_Ranged_NA
LeaderSortOrder[11]=Entities.U_MilitaryBandit_Ranged_NE;LeaderSortOrder[12]=Entities.U_MilitaryBandit_Ranged_SE
LeaderSortOrder[13]=Entities.U_MilitaryCatapult;LeaderSortOrder[14]=Entities.U_MilitarySiegeTower
LeaderSortOrder[15]=Entities.U_MilitaryBatteringRam;LeaderSortOrder[16]=Entities.U_CatapultCart
LeaderSortOrder[17]=Entities.U_SiegeTowerCart;LeaderSortOrder[18]=Entities.U_BatteringRamCart
LeaderSortOrder[19]=Entities.U_Thief
if g_GameExtraNo>=1 then
table.insert(LeaderSortOrder,4,Entities.U_MilitarySword_Khana)
table.insert(LeaderSortOrder,6,Entities.U_MilitaryBow_Khana)
table.insert(LeaderSortOrder,7,Entities.U_MilitaryBandit_Melee_AS)
table.insert(LeaderSortOrder,12,Entities.U_MilitaryBandit_Ranged_AS)end end
function BundleEntitySelection.Local:ExtendedLeaderSortOrder()g_MultiSelection={}
g_MultiSelection.EntityList={}g_MultiSelection.Highlighted={}LeaderSortOrder={}
LeaderSortOrder[1]=Entities.U_MilitarySword;LeaderSortOrder[2]=Entities.U_MilitaryBow
LeaderSortOrder[3]=Entities.U_MilitarySword_RedPrince;LeaderSortOrder[4]=Entities.U_MilitaryBow_RedPrince
LeaderSortOrder[5]=Entities.U_MilitaryBandit_Melee_ME;LeaderSortOrder[6]=Entities.U_MilitaryBandit_Melee_NA
LeaderSortOrder[7]=Entities.U_MilitaryBandit_Melee_NE;LeaderSortOrder[8]=Entities.U_MilitaryBandit_Melee_SE
LeaderSortOrder[9]=Entities.U_MilitaryBandit_Ranged_ME;LeaderSortOrder[10]=Entities.U_MilitaryBandit_Ranged_NA
LeaderSortOrder[11]=Entities.U_MilitaryBandit_Ranged_NE;LeaderSortOrder[12]=Entities.U_MilitaryBandit_Ranged_SE
LeaderSortOrder[13]=Entities.U_MilitaryCatapult;LeaderSortOrder[14]=Entities.U_Trebuchet
LeaderSortOrder[15]=Entities.U_MilitarySiegeTower;LeaderSortOrder[16]=Entities.U_MilitaryBatteringRam
LeaderSortOrder[17]=Entities.U_CatapultCart;LeaderSortOrder[18]=Entities.U_SiegeTowerCart
LeaderSortOrder[19]=Entities.U_BatteringRamCart;LeaderSortOrder[20]=Entities.U_AmmunitionCart
LeaderSortOrder[21]=Entities.U_Thief
if g_GameExtraNo>=1 then
table.insert(LeaderSortOrder,4,Entities.U_MilitarySword_Khana)
table.insert(LeaderSortOrder,6,Entities.U_MilitaryBow_Khana)
table.insert(LeaderSortOrder,7,Entities.U_MilitaryBandit_Melee_AS)
table.insert(LeaderSortOrder,12,Entities.U_MilitaryBandit_Ranged_AS)end end;Core:RegisterBundle("BundleEntitySelection")
API=API or{}QSB=QSB or{}
function API.AutoSaveGame(de)assert(de)if not GUI then
API.Bridge('API.AutoSaveGame("'..de..'")')return end
BundleSaveGameTools.Local:AutoSaveGame(de)end
function API.SaveGameToFolder(l,wMW)assert(l)assert(wMW)if not GUI then
API.Bridge('API.SaveGameToFolder("'..l..
'", "'..wMW..'")')return end
BundleSaveGameTools.Local:SaveGameToFolder(l,wMW)end
function API.LoadGameFromFolder(Zeat0o,XbW8,XG24)assert(Zeat0o)assert(XbW8)assert(XG24)if not GUI then
API.Bridge(
'API.LoadGameFromFolder("'..
Zeat0o..'", "'..XbW8 ..'", "'..XG24 ..'")')return end
BundleSaveGameTools.Local:LoadGameFromFolder(Zeat0o,XbW8,XG24)end
function API.StartMap(eGdCE5nz,bWC,LQnI,Mf2Ge3D)assert(eGdCE5nz)assert(bWC)assert(LQnI)
assert(Mf2Ge3D)if not GUI then
API.Bridge('API.StartMap("'..
eGdCE5nz..'", "'..bWC..
'", "'..Mf2Ge3D..'", "'..Mf2Ge3D..'")')return end
BundleSaveGameTools.Local:LoadGameFromFolder(eGdCE5nz,bWC,LQnI,Mf2Ge3D)end
BundleSaveGameTools={Global={Data={}},Local={Data={AutoSaveCounter=0}}}function BundleSaveGameTools.Global:Install()end;function BundleSaveGameTools.Local:Install()
end
function BundleSaveGameTools.Local:AutoSaveGame(aqsK)aqsK=aqsK or
Framework.GetCurrentMapName()local nuh0oo=
BundleSaveGameTools.Local.Data.AutoSaveCounter+1
BundleSaveGameTools.Local.Data.AutoSaveCounter=nuh0oo;local dtI=Network.GetDesiredLanguage()
if dtI~="de"then dtI="en"end
local Jra_K_Z=(dtI=="de"and"Spiel wird gespeichert...")or"Saving game..."
if self:CanGameBeSaved()then
OpenDialog(Jra_K_Z,XGUIEng.GetStringTableText("UI_Texts/MainMenuSaveGame_center"))XGUIEng.ShowWidget("/InGame/Dialog/Ok",0)
Framework.SaveGame(
"Autosave "..nuh0oo.." --- "..aqsK,"--")else
StartSimpleJobEx(function()
if BundleSaveGameTools.Local:CanGameBeSaved()then
OpenDialog(Jra_K_Z,XGUIEng.GetStringTableText("UI_Texts/MainMenuSaveGame_center"))XGUIEng.ShowWidget("/InGame/Dialog/Ok",0)
Framework.SaveGame(
"Autosave - "..nuh0oo.." --- "..aqsK,"--")return true end end)end end
function BundleSaveGameTools.Local:CanGameBeSaved()
if BundleGameHelperFunctions and
BundleGameHelperFunctions.Local.Data.ForbidSave then return false end
if IsBriefingActive and IsBriefingActive()then return false end;if
XGUIEng.IsWidgetShownEx("/LoadScreen/LoadScreen")~=0 then return false end;return true end;function BundleSaveGameTools.Local:SaveGameToFolder(RAL7,Evw6)Evw6=Evw6 or
Framework.GetCurrentMapName()
Framework.SaveGame(RAL7 .."/"..Evw6,"--")end
function BundleSaveGameTools.Local:LoadGameFromFolder(N3IGyI,f,v)v=
v or 0;assert(type(f)=="string")local e=N3IGyI.."/"..f..
GetSaveGameExtension()
local ZyT,P5t1NfP,KgUPpp=Framework.GetSaveGameMapNameAndTypeAndCampaign(e)InitLoadScreen(false,P5t1NfP,ZyT,KgUPpp,0)
Framework.ResetProgressBar()Framework.SetLoadScreenNeedButton(v)
Framework.LoadGame(e)end
function BundleSaveGameTools.Local:LoadGameFromFolder(zsY7,dQa6icK,cVT,Wp3)Wp3=Wp3 or 1
dQa6icK=dQa6icK or 0;cVT=cVT or 3
local oW,_dUUGf9d,L,i6=Framework.GetMapNameAndDescription(zsY7,cVT)
if oW~=nil and oW~=""then
XGUIEng.ShowAllSubWidgets("/InGame",0)Framework.SetLoadScreenNeedButton(Wp3)
InitLoadScreen(false,cVT,zsY7,0,dQa6icK)Framework.ResetProgressBar()
Framework.StartMap(zsY7,cVT,dQa6icK)else GUI.AddNote("ERROR: invalid mapfile!")end end;Core:RegisterBundle("BundleSaveGameTools")
API=API or{}QSB=QSB or{}
function API.GetEntitiesOfCategoriesInTerritories(i1AjOR2,q5,gbq6mM)return
BundleEntityHelperFunctions:GetEntitiesOfCategoriesInTerritories(i1AjOR2,q5,gbq6mM)end
GetEntitiesOfCategoriesInTerritories=API.GetEntitiesOfCategoriesInTerritories;EntitiesInCategories=API.GetEntitiesOfCategoriesInTerritories
function API.GetEntitiesByPrefix(xy9z)return
BundleEntityHelperFunctions:GetEntitiesByPrefix(xy9z)end;GetEntitiesNamedWith=API.GetEntitiesByPrefix
function API.SetResourceAmount(ONuQWd7g,emP73Ww,QDazjhiW)
if GUI then local q=(type(ONuQWd7g)~=
"string"and ONuQWd7g)or
"'"..ONuQWd7g.."'"
API.Bridge(
"API.SetResourceAmount("..
q..", "..emP73Ww..", "..QDazjhiW..")")return end
if not IsExisting(ONuQWd7g)then
local wxsw=
(type(ONuQWd7g)~="string"and ONuQWd7g)or"'"..ONuQWd7g.."'"
API.Dbg("API.SetResourceAmount: Entity "..wxsw.." does not exist!")return end;return
BundleEntityHelperFunctions.Global:SetResourceAmount(ONuQWd7g,emP73Ww,QDazjhiW)end;SetResourceAmount=API.SetResourceAmount
function API.GetRelativePos(Ue,INnqSjpO,Mptuc,AV)
if
not API.ValidatePosition(Ue)then if not IsExisting(Ue)then
API.Dbg("API.GetRelativePos: Target is invalid!")return end end
return BundleEntityHelperFunctions:GetRelativePos(Ue,INnqSjpO,Mptuc,AV)end;GetRelativePos=API.GetRelativePos
function API.SetPosition(sNCn4mi,yfn)
if GUI then
local paJ9=(type(sNCn4mi)~="string"and
sNCn4mi)or"'"..sNCn4mi.."'"local AxNEUFn=yfn;if type(AxNEUFn)=="table"then
AxNEUFn="{X= "..tostring(AxNEUFn.X)..", Y= "..
tostring(AxNEUFn.Y).."}"end
API.Bridge("API.SetPosition("..paJ9 ..", "..AxNEUFn..
")")return end
if not IsExisting(sNCn4mi)then
local MjNBO=
(type(sNCn4mi)~="string"and sNCn4mi)or"'"..sNCn4mi.."'"
API.Dbg("API.SetPosition: Entity "..MjNBO.." does not exist!")return end;local ksUkULF=API.LocateEntity(yfn)if
not API.ValidatePosition(ksUkULF)then API.Dbg("API.SetPosition: Position is invalid!")
return end;return
BundleEntityHelperFunctions.Global:SetPosition(sNCn4mi,ksUkULF)end;SetPosition=API.SetPosition
function API.MoveToPosition(_nbCjt,Bk,jJPO,e,K2a)if GUI then
API.Bridge("API.MoveToPosition("..GetID(_nbCjt)..
", "..
GetID(Bk)..", "..
jJPO..", "..e..", "..tostring(K2a)..")")return end
if not
IsExisting(_nbCjt)then
local Z6Awtv_1=(type(_nbCjt)~="string"and _nbCjt)or"'"..
_nbCjt.."'"
API.Dbg("API.MoveToPosition: Entity "..Z6Awtv_1 .." does not exist!")return end
if not IsExisting(Bk)then local vtak_XT=(type(Bk)~="string"and Bk)or"'"..
Bk.."'"
API.Dbg("API.MoveToPosition: Entity "..
vtak_XT.." does not exist!")return end;return
BundleEntityHelperFunctions.Global:MoveToPosition(_nbCjt,Bk,jJPO,e,K2a)end;MoveEntityToPositionToAnotherOne=API.MoveToPosition
function API.MoveAndLookAt(Gd076,I,NMn,U,O)if GUI then
API.Bridge(
"API.MoveAndLookAt("..GetID(Gd076)..
", "..GetID(I)..", "..NMn..
", "..U..", "..tostring(O)..")")return end
if not
IsExisting(Gd076)then local Eii=(type(Gd076)~="string"and Gd076)or"'"..
Gd076 .."'"
API.Dbg(
"API.MoveAndLookAt: Entity "..Eii.." does not exist!")return end
if not IsExisting(I)then
local YNW=(type(I)~="string"and I)or"'"..I.."'"
API.Dbg("API.MoveAndLookAt: Entity "..YNW.." does not exist!")return end;return
BundleEntityHelperFunctions.Global:MoveAndLookAt(Gd076,I,NMn,U,O)end;MoveEntityFaceToFaceToAnotherOne=API.MoveAndLookAt
MoveEx=API.MoveAndLookAt
function API.PlaceToPosition(OxvsR18,t8iwY,uVQatO2p,PY)if GUI then
API.Bridge("API.PlaceToPosition("..
GetID(OxvsR18)..", "..GetID(t8iwY)..", "..uVQatO2p..
", "..PY..")")return end
if not
IsExisting(OxvsR18)then
local K7RBg=
(type(OxvsR18)~="string"and OxvsR18)or"'"..OxvsR18 .."'"
API.Dbg("API.PlaceToPosition: Entity "..K7RBg.." does not exist!")return end
if not IsExisting(t8iwY)then local Yj=
(type(t8iwY)~="string"and t8iwY)or"'"..t8iwY.."'"
API.Dbg(
"API.PlaceToPosition: Entity "..Yj.." does not exist!")return end;local kwY=API.GetRelativePos(t8iwY,uVQatO2p,PY,true)
API.SetPosition(OxvsR18,kwY)end;PlaceEntityToPositionToAnotherOne=API.PlaceToPosition
SetPositionEx=API.PlaceToPosition
function API.PlaceAndLookAt(lpFAf_,R,at8fRO1,IAl6tS3)if GUI then
API.Bridge("API.PlaceAndLookAt("..GetID(lpFAf_)..
", "..GetID(R)..", "..at8fRO1 ..
", "..IAl6tS3 ..")")return end
API.PlaceToPosition(lpFAf_,R,at8fRO1,IAl6tS3)LookAt(lpFAf_,R)end;PlaceEntityFaceToFaceToAnotherOne=API.PlaceAndLookAt
function API.GiveEntityName(eigcO)if
IsExisting(_name)then
API.Dbg("API.GiveEntityName: Entity does not exist!")return end;if GUI then
API.Bridge("API.GiveEntityName("..
GetID(eigcO)..")")return end;return
BundleEntityHelperFunctions.Global:GiveEntityName(eigcO)end;GiveEntityName=API.GiveEntityName
function API.GetEntityName(Kaog)
if not IsExisting(Kaog)then
local ZaBF=(
type(Kaog)~="string"and Kaog)or"'"..Kaog.."'"
API.Warn("API.GetEntityName: Entity "..ZaBF.." does not exist!")return nil end;return Logic.GetEntityName(GetID(Kaog))end;GetEntityName=API.GetEntityName
function API.SetEntityName(qSP6XQR,Og)if GUI then
API.Bridge("API.SetEntityName("..GetID(_EntityID)..
", '"..Og.."')")return end;if IsExisting(Og)then
API.Dbg(
"API.SetEntityName: Entity '"..Og.."' already exists!")return end;return
Logic.SetEntityName(GetID(qSP6XQR),Og)end;SetEntityName=API.SetEntityName
function API.SetOrientation(Ym9SBy,ag)if GUI then
API.Bridge("API.SetOrientation("..GetID(Ym9SBy)..", "..
ag..")")return end
if not IsExisting(Ym9SBy)then
local OCzHa=(
type(Ym9SBy)~="string"and Ym9SBy)or"'"..Ym9SBy.."'"
API.Dbg("API.SetOrientation: Entity "..OCzHa.." does not exist!")return end;return Logic.SetOrientation(GetID(Ym9SBy),ag)end;SetOrientation=API.SetOrientation
function API.GetOrientation(TYZe7yj2)
if
not IsExisting(TYZe7yj2)then
local s60bp=(type(TYZe7yj2)~="string"and TYZe7yj2)or"'"..
TYZe7yj2 .."'"
API.Warn("API.GetOrientation: Entity "..s60bp.." does not exist!")return 0 end
return Logic.GetEntityOrientation(GetID(TYZe7yj2))end;GetOrientation=API.GetOrientation
function API.EntityAttack(TNRh,gr5Dh)if GUI then
API.Bridge("API.EntityAttack("..GetID(TNRh)..", "..
GetID(gr5Dh)..")")return end
if not IsExisting(TNRh)then
local wVvHw=(
type(TNRh)=="string"and"'"..TNRh.."'")or TNRh
API.Dbg("API.EntityAttack: Entity "..wVvHw.." does not exist!")return end
if not IsExisting(gr5Dh)then local jcS=
(type(gr5Dh)=="string"and"'"..gr5Dh.."'")or gr5Dh
API.Dbg(
"API.EntityAttack: Target "..jcS.." does not exist!")return end;return
BundleEntityHelperFunctions.Global:Attack(TNRh,gr5Dh)end;Attack=API.EntityAttack
function API.EntityAttackMove(Gb,I)if GUI then
API.Dbg("API.EntityAttackMove: Cannot be used from local script!")return end
if not IsExisting(Gb)then
local Eh=(
type(Gb)=="string"and"'"..Gb.."'")or Gb
API.Dbg("API.EntityAttackMove: Entity "..Eh.." does not exist!")return end;local C=API.LocateEntity(I)if not API.ValidatePosition(C)then
API.Dbg("API.EntityAttackMove: Position is invalid!")return end;return
BundleEntityHelperFunctions.Global:AttackMove(Gb,C)end;AttackMove=API.EntityAttackMove
function API.EntityMove(IWDJnc,j7VGta)if GUI then
API.Dbg("API.EntityMove: Cannot be used from local script!")return end
if not IsExisting(IWDJnc)then local Jd=
(
type(IWDJnc)=="string"and"'"..IWDJnc.."'")or IWDJnc
API.Dbg(
"API.EntityMove: Entity "..Jd.." does not exist!")return end;local _PzE54=API.LocateEntity(j7VGta)
if
not API.ValidatePosition(_PzE54)then API.Dbg("API.EntityMove: Position is invalid!")return end;return
BundleEntityHelperFunctions.Global:Move(IWDJnc,_PzE54)end;Move=API.EntityMove
function API.GetLeaderBySoldier(BY)
if not IsExisting(BY)then
local qKO=(type(BY)=="string"and
"'"..BY.."'")or _Entity
API.Dbg("API.GetLeaderBySoldier: Entity "..qKO.." does not exist!")return end;return Logic.SoldierGetLeaderEntityID(GetID(BY))end;GetLeaderBySoldier=API.GetLeaderBySoldier
function API.GetNearestKnight(CAkS9C5d,H4v)local _yPjiRy_={}
Logic.GetKnights(H4v,_yPjiRy_)return API.GetNearestEntity(CAkS9C5d,_yPjiRy_)end;GetClosestKnight=API.GetNearestKnight
function API.GetNearestEntity(AK,Cbd)
if not IsExisting(AK)then return end;if#Cbd==0 then
API.Dbg("API.GetNearestEntity: The target list is empty!")return end
for rTrYdgRW=1,#Cbd,1 do if not
IsExisting(Cbd[rTrYdgRW])then
API.Dbg("API.GetNearestEntity: At least one target entity is dead!")return end end
return BundleEntityHelperFunctions:GetNearestEntity(AK,Cbd)end;GetClosestEntity=API.GetNearestEntity
BundleEntityHelperFunctions={Global={Data={RefillAmounts={}}},Local={Data={}}}function BundleEntityHelperFunctions.Global:Install()
BundleEntityHelperFunctions.Global:OverwriteGeologistRefill()end
function BundleEntityHelperFunctions.Global:OverwriteGeologistRefill()
if
Framework.GetGameExtraNo()>=1 then
GameCallback_OnGeologistRefill_Orig_QSBPlusComforts1=GameCallback_OnGeologistRefill
GameCallback_OnGeologistRefill=function(rZ_gY_,e9OUW,oF_GhUWZ)
GameCallback_OnGeologistRefill_Orig_QSBPlusComforts1(rZ_gY_,e9OUW,oF_GhUWZ)
if
BundleEntityHelperFunctions.Global.Data.RefillAmounts[e9OUW]then
local oNOERbUT=BundleEntityHelperFunctions.Global.Data.RefillAmounts[e9OUW]local LBSrrQQ=oNOERbUT+
math.random(1,math.floor((oNOERbUT*0.2)+0.5))
Logic.SetResourceDoodadGoodAmount(e9OUW,LBSrrQQ)end end end end
function BundleEntityHelperFunctions.Global:SetResourceAmount(EPP0nUFh,KzCPNLi,wkL)assert(type(KzCPNLi)==
"number")
assert(type(wkL)=="number")local VgHEmz=GetID(EPP0nUFh)
if not IsExisting(VgHEmz)or
Logic.GetResourceDoodadGoodType(VgHEmz)==0 then
API.Dbg("SetResourceAmount: Resource entity is invalid!")return false end;if Logic.GetResourceDoodadGoodAmount(VgHEmz)==0 then
VgHEmz=ReplaceEntity(VgHEmz,Logic.GetEntityType(VgHEmz))end
Logic.SetResourceDoodadGoodAmount(VgHEmz,KzCPNLi)
if wkL then self.Data.RefillAmounts[VgHEmz]=wkL end;return true end
function BundleEntityHelperFunctions.Global:SetPosition(qxin3db,lQZU1Ee)if
not IsExisting(qxin3db)then return end;local Qxo7=GetEntityId(qxin3db)
Logic.DEBUG_SetSettlerPosition(Qxo7,lQZU1Ee.X,lQZU1Ee.Y)
if Logic.IsLeader(Qxo7)==1 then
local RH={Logic.GetSoldiersAttachedToLeader(Qxo7)}
if RH[1]>0 then for M3x_srX=1,#RH do
Logic.DEBUG_SetSettlerPosition(RH[M3x_srX],lQZU1Ee.X,lQZU1Ee.Y)end end end end
function BundleEntityHelperFunctions.Global:MoveToPosition(w1,J,e,gIT,VI39ihit)if
not IsExisting(w1)then return end;if not e then e=0 end;local lzSek5=GetID(w1)local GBk=GetID(J)
local seOf0=GetRelativePos(J,e)if type(gIT)=="number"then
seOf0=BundleEntityHelperFunctions:GetRelativePos(J,e,gIT)end
if VI39ihit then
Logic.MoveEntity(lzSek5,seOf0.X,seOf0.Y)else Logic.MoveSettler(lzSek5,seOf0.X,seOf0.Y)end
StartSimpleJobEx(function(DZVy,jjh)if not Logic.IsEntityMoving(DZVy)then LookAt(DZVy,jjh)
return true end end,lzSek5,GBk)end
function BundleEntityHelperFunctions.Global:MoveAndLookAt(JH,a7yVI7,n,DM_,RLDfKwYl)if
not IsExisting(JH)then return end;if not n then n=0 end
self:MoveToPosition(JH,a7yVI7,n,DM_,RLDfKwYl)
StartSimpleJobEx(function(fXIF7,VSH)if not Logic.IsEntityMoving(fXIF7)then
LookAt(fXIF7,VSH)return true end end,eID,tID)end
function BundleEntityHelperFunctions.Global:GiveEntityName(_c)
if type(_c)=="string"then return
_c else assert(type(_c)=="number")
local LaZ=Logic.GetEntityName(_c)
if(type(LaZ)~="string"or LaZ=="")then
QSB.GiveEntityNameCounter=(
QSB.GiveEntityNameCounter or 0)+1
LaZ="GiveEntityName_Entity_"..QSB.GiveEntityNameCounter;Logic.SetEntityName(_c,LaZ)end;return LaZ end end
function BundleEntityHelperFunctions.Global:Attack(GlscgdR1,KLM)
local v=GetID(GlscgdR1)local _S=GetID(KLM)Logic.GroupAttack(v,_S)end;function BundleEntityHelperFunctions.Global:AttackMove(Aj,t2p)local M6xZH=GetID(Aj)
Logic.GroupAttackMove(M6xZH,t2p.X,t2p.Y)end
function BundleEntityHelperFunctions.Global:Move(Wm,keNEZzBk)
local UdO=GetID(Wm)Logic.MoveSettler(UdO,keNEZzBk.X,keNEZzBk.Y)end
function BundleEntityHelperFunctions.Local:Install()end
function BundleEntityHelperFunctions:GetEntitiesOfCategoriesInTerritories(wCsr5EX,M6NKH,ite)
local Q4Mi=(type(wCsr5EX)=="table"and
wCsr5EX)or{wCsr5EX}
local S=(type(M6NKH)=="table"and M6NKH)or{M6NKH}
local cHSrNsX=(type(ite)=="table"and ite)or{ite}local jnhq={}
for U=1,#Q4Mi,1 do for n=1,#S,1 do
for qZ=1,#cHSrNsX,1 do
local IbliJ=API.GetEntitiesOfCategoryInTerritory(Q4Mi[U],S[n],cHSrNsX[qZ])jnhq=Array_Append(jnhq,IbliJ)end end end;return jnhq end
function BundleEntityHelperFunctions:GetEntitiesByPrefix(MbsRstZ2)local npLq7Y={}local EFP=1;local Jfo=true;while Jfo do
local tTVBjj1=GetID(MbsRstZ2 ..EFP)
if tTVBjj1 ~=0 then table.insert(npLq7Y,tTVBjj1)else Jfo=false end;EFP=EFP+1 end;return
npLq7Y end
function BundleEntityHelperFunctions:GetRelativePos(eokY,W80juLWr,Z,aGP23)if not type(eokY)=="table"and not
IsExisting(eokY)then return end;if Z==nil then
Z=0 end;local kdvb
if type(eokY)=="table"then local EM45=eokY;local du4t=0+Z
kdvb={X=EM45.X+W80juLWr*
math.cos(math.rad(du4t)),Y=EM45.Y+W80juLWr*
math.sin(math.rad(du4t))}else local VtEBvR_=GetID(eokY)local Id=GetPosition(VtEBvR_)local jmk=
Logic.GetEntityOrientation(VtEBvR_)+Z
if
Logic.IsBuilding(VtEBvR_)==1 and not aGP23 then
x,y=Logic.GetBuildingApproachPosition(VtEBvR_)Id={X=x,Y=y}jmk=jmk-90 end
kdvb={X=Id.X+W80juLWr*math.cos(math.rad(jmk)),Y=
Id.Y+W80juLWr*math.sin(math.rad(jmk))}end;return kdvb end
function BundleEntityHelperFunctions:GetNearestEntity(FW6Ln,mF2kWZ)local YnivKpOE=Logic.WorldGetSize()
local iScf5Iry=nil
for ZuLLXJ8o=1,#mF2kWZ do
local Ipefr=Logic.GetDistanceBetweenEntities(mF2kWZ[ZuLLXJ8o],FW6Ln)
if Ipefr<YnivKpOE and mF2kWZ[ZuLLXJ8o]~=FW6Ln then
YnivKpOE=Ipefr;iScf5Iry=mF2kWZ[ZuLLXJ8o]end end;return iScf5Iry end
Core:RegisterBundle("BundleEntityHelperFunctions")API=API or{}QSB=QSB or{}
function API.UndiscoverTerritory(FH,eBlBVcO)if GUI then
API.Bridge("API.UndiscoverTerritory("..FH..", "..
eBlBVcO..")")return end;return
BundleGameHelperFunctions.Global:UndiscoverTerritory(FH,eBlBVcO)end;UndiscoverTerritory=API.UndiscoverTerritory
function API.UndiscoverTerritories(QJtAht,lvWSxpXL)if GUI then
API.Bridge(
"API.UndiscoverTerritories("..QJtAht..", "..lvWSxpXL..")")return end;return
BundleGameHelperFunctions.Global:UndiscoverTerritories(QJtAht,lvWSxpXL)end;UndiscoverTerritories=API.UndiscoverTerritories
function API.SetNeedSatisfaction(U7kEO_p,cO,G4Mkp)if GUI then
API.Bridge(
"API.SetNeedSatisfaction("..U7kEO_p..", "..cO..", "..G4Mkp..")")return end;return
BundleGameHelperFunctions.Global:SetNeedSatisfactionLevel(U7kEO_p,cO,G4Mkp)end;SetNeedSatisfactionLevel=API.SetNeedSatisfaction
function API.UnlockTitleForPlayer(p,jlq)if GUI then
API.Bridge(
"API.UnlockTitleForPlayer("..p..", "..jlq..")")return end;return
BundleGameHelperFunctions.Global:UnlockTitleForPlayer(p,jlq)end;UnlockTitleForPlayer=API.UnlockTitleForPlayer
function API.FocusCameraOnKnight(SeM,T,jPy)if not GUI then
API.Bridge(
"API.SetCameraToPlayerKnight("..SeM..", "..T..", "..jPy..")")return end;return
BundleGameHelperFunctions.Local:SetCameraToPlayerKnight(SeM,T,jPy)end;SetCameraToPlayerKnight=API.FocusCameraOnKnight
function API.FocusCameraOnEntity(JoekICm,FNPW0,kTe9g3)
if not GUI then local PXlYVZey=(
type(JoekICm)~="string"and JoekICm)or
"'"..JoekICm.."'"
API.Bridge(
"API.FocusCameraOnEntity("..
PXlYVZey..", "..FNPW0 ..", "..kTe9g3 ..")")return end
if not IsExisting(JoekICm)then
local sHVG1rp=
(type(JoekICm)~="string"and JoekICm)or"'"..JoekICm.."'"
API.Dbg("API.FocusCameraOnEntity: Entity "..sHVG1rp.." does not exist!")return end;return
BundleGameHelperFunctions.Local:SetCameraToEntity(JoekICm,FNPW0,kTe9g3)end;SetCameraToEntity=API.FocusCameraOnEntity
function API.SetSpeedLimit(oSR3DE)
if not GUI then API.Bridge("API.SetSpeedLimit("..
oSR3DE..")")return end;return
BundleGameHelperFunctions.Local:SetSpeedLimit(oSR3DE)end;SetSpeedLimit=API.SetSpeedLimit
function API.ActivateSpeedLimit(yIR2c6Rc)if GUI then
API.Bridge("API.ActivateSpeedLimit("..
tostring(yIR2c6Rc)..")")return end;return
API.Bridge(
"BundleGameHelperFunctions.Local:ActivateSpeedLimit("..tostring(yIR2c6Rc)..")")end;ActivateSpeedLimit=API.ActivateSpeedLimit
function API.KillCheats()if GUI then
API.Bridge("API.KillCheats()")return end;return
BundleGameHelperFunctions.Global:KillCheats()end;KillCheats=API.KillCheats
function API.RessurectCheats()if GUI then
API.Bridge("API.RessurectCheats()")return end;return
BundleGameHelperFunctions.Global:RessurectCheats()end;RessurectCheats=API.RessurectCheats
function API.ForbidSaveGame(F_j7LU)if GUI then
API.Bridge("API.ForbidSaveGame("..
tostring(F_j7LU)..")")return end
API.Bridge(
[[
        BundleGameHelperFunctions.Local.Data.ForbidSave = ]]..
tostring(F_j7LU)..[[ == true
        BundleGameHelperFunctions.Local:DisplaySaveButtons(]]..
tostring(F_j7LU)..[[)
    ]])end;ForbidSaveGame=API.ForbidSaveGame
function API.AllowExtendedZoom(g)if GUI then
API.Bridge("API.AllowExtendedZoom("..
tostring(g)..")")return end;BundleGameHelperFunctions.Global.Data.ExtendedZoomAllowed=
g==true;if g==false then
BundleGameHelperFunctions.Global:DeactivateExtendedZoom()end end;AllowExtendedZoom=API.AllowExtendedZoom
function API.StartNormalFestival(LK)
if GUI then API.Bridge("API.StartNormalFestival("..LK..
")")return end
BundleGameHelperFunctions.Global:RestrictFestivalForPlayer(LK,0,false)Logic.StartFestival(LK,0)end;StartNormalFestival=API.StartNormalFestival
function API.StartCityUpgradeFestival(A12XW)if GUI then
API.Bridge(
"API.StartCityUpgradeFestival("..A12XW..")")return end
BundleGameHelperFunctions.Global:RestrictFestivalForPlayer(A12XW,1,false)Logic.StartFestival(A12XW,1)end;StartCityUpgradeFestival=API.StartCityUpgradeFestival
function API.ForbidFestival(vG)
if GUI then API.Bridge(
"API.ForbidFestival("..vG..")")return end;local nIT20_b=Logic.GetKnightTitle(vG)
local EEsqg=Technologies.R_Festival;local icMbUi=TechnologyStates.Locked
if

KnightTitleNeededForTechnology[EEsqg]==nil or nIT20_b>=KnightTitleNeededForTechnology[EEsqg]then icMbUi=TechnologyStates.Prohibited end;Logic.TechnologySetState(vG,EEsqg,icMbUi)
BundleGameHelperFunctions.Global:RestrictFestivalForPlayer(vG,0,true)
API.Bridge("BundleGameHelperFunctions.Local.Data.NormalFestivalLockedForPlayer["..vG.."] = true")end;ForbidFestival=API.ForbidFestival
function API.AllowFestival(RO5)if GUI then
API.Bridge("API.AllowFestival("..RO5 ..")")return end
BundleGameHelperFunctions.Global:RestrictFestivalForPlayer(RO5,0,false)local O7Td=Logic.GetKnightTitle(RO5)
local P=Technologies.R_Festival;local qUV=TechnologyStates.Unlocked
if

KnightTitleNeededForTechnology[P]==nil or O7Td>=KnightTitleNeededForTechnology[P]then qUV=TechnologyStates.Researched end;Logic.TechnologySetState(RO5,P,qUV)
API.Bridge(
"BundleGameHelperFunctions.Local.Data.NormalFestivalLockedForPlayer["..RO5 .."] = false")end;AllowFestival=API.AllowFestival
function API.SetControllingPlayer(HOCuSE7_,plYwsj,q,hADV)if GUI then
API.Bridge("API.SetControllingPlayer("..HOCuSE7_..", "..

plYwsj..", '"..q.."', "..tostring(hADV)..")")return end;return
BundleGameHelperFunctions.Global:SetControllingPlayer(HOCuSE7_,plYwsj,q,hADV)end;PlayerSetPlayerID=API.SetControllingPlayer;function API.GetControllingPlayer()
if not GUI then return
BundleGameHelperFunctions.Global:GetControllingPlayer()else return GUI.GetPlayerID()end end
PlayerGetPlayerID=API.GetControllingPlayer
function API.ThridPersonActivate(FiKB_BzO,Jt_Rub3)
if GUI then local ArK3=
(type(FiKB_BzO)=="string"and"'"..FiKB_BzO.."'")or FiKB_BzO
API.Bridge(
"API.ThridPersonActivate("..ArK3 ..", "..Jt_Rub3 ..")")return end;return
BundleGameHelperFunctions.Global:ThridPersonActivate(FiKB_BzO,Jt_Rub3)end;HeroCameraActivate=API.ThridPersonActivate
function API.ThridPersonDeactivate()if GUI then
API.Bridge("API.ThridPersonDeactivate()")return end;return
BundleGameHelperFunctions.Global:ThridPersonDeactivate()end;HeroCameraDeactivate=API.ThridPersonDeactivate
function API.ThridPersonIsRuning()
if not GUI then return
BundleGameHelperFunctions.Global:ThridPersonIsRuning()else return
BundleGameHelperFunctions.Local:ThridPersonIsRuning()end end;HeroCameraIsRuning=API.ThridPersonIsRuning
function API.AddFollowKnightSave(OBAhnX_P,ts1TuG,dofOBz,ok)
if GUI then
local aTIrG=(
type(OBAhnX_P)=="string"and"'"..OBAhnX_P.."'")or OBAhnX_P;local QNggzrn=
(type(ts1TuG)=="string"and"'"..ts1TuG.."'")or ts1TuG
API.Bridge(
"API.StopFollowKnightSave("..aTIrG..
", "..QNggzrn..", "..dofOBz..","..ok..")")return end;return
BundleGameHelperFunctions.Global:AddFollowKnightSave(OBAhnX_P,ts1TuG,dofOBz,ok)end;AddFollowKnightSave=API.AddFollowKnightSave
function API.StopFollowKnightSave(Ht)if GUI then API.Bridge(
"API.StopFollowKnightSave("..Ht..")")
return end;return
BundleGameHelperFunctions.Global:StopFollowKnightSave(Ht)end;StopFollowKnightSave=API.StopFollowKnightSave
function API.ChangeTerrainTypeInSquare(O0N,E6zvZw,VWJR)
if GUI then
local YiXM=(type(O0N)==
"string"and"'"..O0N.."'")or O0N
API.Bridge("API.ChangeTerrainTypeInSquare("..
YiXM..", "..E6zvZw..", "..VWJR..")")return end;if not IsExisting(O0N)then
API.Dbg("API.ChangeTerrainTypeInSquare: Central point does not exist!")return end;if E6zvZw<100 then
API.Warn("API.ChangeTerrainTypeInSquare: Check your offset! It seems to small!")end;return
BundleGameHelperFunctions.Global:ChangeTerrainTypeInSquare(O0N,E6zvZw,VWJR)end;TerrainType=API.ChangeTerrainTypeInSquare
function API.ChangeWaterHeightInSquare(XEWeum,hZ47ZL,_GaziPP0,PRKm)
if GUI then
local tF8XJ=(
type(XEWeum)=="string"and"'"..XEWeum.."'")or XEWeum
API.Bridge("API.ChangeWaterHeightInSquare("..tF8XJ..
", "..hZ47ZL..", "..
_GaziPP0 ..", "..tostring(PRKm)..")")return end;if not IsExisting(XEWeum)then
API.Dbg("API.ChangeWaterHeightInSquare: Central point does not exist!")return end;if hZ47ZL<100 then
API.Warn("API.ChangeWaterHeightInSquare: Check your offset! It seems to small!")end;return
BundleGameHelperFunctions.Global:ChangeWaterHeightInSquare(XEWeum,hZ47ZL,_GaziPP0,PRKm)end;WaterHeight=API.ChangeWaterHeightInSquare
function API.ChangeTerrainHeightInSquare(_vmurIq,CzMB,b,YJHr)
if GUI then local VuatYZ=
(type(_vmurIq)==
"string"and"'".._vmurIq.."'")or _vmurIq
API.Bridge(
"API.ChangeTerrainHeightInSquare("..VuatYZ..", "..CzMB..
", "..b..", "..tostring(YJHr)..")")return end;if not IsExisting(_vmurIq)then
API.Dbg("API.ChangeTerrainHeightInSquare: Central point does not exist!")return end;if CzMB<100 then
API.Warn("API.ChangeTerrainHeightInSquare: Check your offset! It seems to small!")end;return
BundleGameHelperFunctions.Global:ChangeTerrainHeightInSquare(_vmurIq,CzMB,b,YJHr)end;TerrainHeight=API.ChangeTerrainHeightInSquare
BundleGameHelperFunctions={Global={Data={HumanPlayerChangedOnce=false,HumanKnightType=0,HumanPlayerID=1,ExtendedZoomAllowed=true,FestivalBlacklist={},FollowKnightSave={}}},Local={Data={NormalFestivalLockedForPlayer={},SpeedLimit=32,ThirdPersonIsActive=false,ThirdPersonLastHero=
nil,ThirdPersonLastZoom=nil}},Shared={TimeLine={Data={TimeLineUniqueJobID=1,TimeLineJobs={}}}}}
function BundleGameHelperFunctions.Global:Install()
self:InitExtendedZoom()
API.AddSaveGameAction(BundleGameHelperFunctions.Global.OnSaveGameLoaded)
QSB.TimeLine=BundleGameHelperFunctions.Shared.TimeLine;TimeLine=QSB.TimeLine end
function BundleGameHelperFunctions.Global:UndiscoverTerritory(k,iEMx16D8)
if
DiscoveredTerritories[k]==nil then DiscoveredTerritories[k]={}end
for LNTQc=1,#DiscoveredTerritories[k],1 do if
DiscoveredTerritories[k][LNTQc]==iEMx16D8 then
table.remove(DiscoveredTerritories[k],LNTQc)break end end end
function BundleGameHelperFunctions.Global:UndiscoverTerritories(Q,aBY7)
if
DiscoveredTerritories[Q]==nil then DiscoveredTerritories[Q]={}end;local dryHpm8={}
for u6f1,pb3tO in pairs(DiscoveredTerritories[Q])do
local MFtjGje=Logic.GetTerritoryPlayerID(pb3tO)
if MFtjGje~=aBY7 then table.insert(dryHpm8,pb3tO)break end end;DiscoveredTerritories[Q][i]=dryHpm8 end
function BundleGameHelperFunctions.Global:SetNeedSatisfactionLevel(kofvXOKl,l,eor)
if not eor then for mOtS=1,8,1 do
self:SetNeedSatisfactionLevel(kofvXOKl,l,mOtS)end else
local QZymu0wx={Logic.GetPlayerEntitiesInCategory(eor,EntityCategories.CityBuilding)}
if
kofvXOKl==Needs.Nutrition or kofvXOKl==Needs.Medicine then
local yepeICvH={Logic.GetPlayerEntitiesInCategory(eor,EntityCategories.OuterRimBuilding)}QZymu0wx=Array_Append(QZymu0wx,yepeICvH)end
for i6z=1,#QZymu0wx,1 do if Logic.IsNeedActive(QZymu0wx[i6z],kofvXOKl)then
Logic.SetNeedState(QZymu0wx[i6z],kofvXOKl,l)end end end end
function BundleGameHelperFunctions.Global:UnlockTitleForPlayer(xK,Lf)
if
LockedKnightTitles[xK]==Lf then LockedKnightTitles[xK]=nil
for M1ygP0=Lf,#NeedsAndRightsByKnightTitle
do
local N04qlb=NeedsAndRightsByKnightTitle[M1ygP0][4]
if N04qlb~=nil then for xG=1,#N04qlb do local _QFI=N04qlb[xG]
Logic.TechnologySetState(xK,_QFI,TechnologyStates.Unlocked)end end end end end
function BundleGameHelperFunctions.Global:SetControllingPlayer(L1,DIlk,f,Go5boB)
assert(type(L1)=="number")assert(type(DIlk)=="number")f=f or""Go5boB=
(Go5boB and true)or false;local NJ3IE,hKz,g73
if Go5boB then
NJ3IE=Logic.GetKnightID(L1)hKz=Logic.GetEntityName(NJ3IE)
g73=Logic.GetEntityType(NJ3IE)Logic.ChangeEntityPlayerID(NJ3IE,DIlk)
Logic.SetPrimaryKnightID(DIlk,GetID(hKz))else NJ3IE=Logic.GetKnightID(DIlk)
hKz=Logic.GetEntityName(NJ3IE)g73=Logic.GetEntityType(NJ3IE)end;Logic.PlayerSetIsHumanFlag(L1,0)
Logic.PlayerSetIsHumanFlag(DIlk,1)Logic.PlayerSetGameStateToPlaying(DIlk)
self.Data.HumanKnightType=g73;self.Data.HumanPlayerID=DIlk
GameCallback_PlayerLost=function(i)if
i==self:GetControllingPlayer()then QuestTemplate:TerminateEventsAndStuff()
if
MissionCallback_Player1Lost then MissionCallback_Player1Lost()end end end
Logic.ExecuteInLuaLocalState([[
        GUI.ClearSelection()
        GUI.SetControlledPlayer(]]..
DIlk..

[[)

        for k,v in pairs(Buffs)do
            GUI_Buffs.UpdateBuffsInInterface(]]..
DIlk..

[[,v)
            GUI.ResetMiniMap()
        end

        if IsExisting(Logic.GetKnightID(GUI.GetPlayerID())) then
            local portrait = GetKnightActor(]]..
g73 ..
[[)
            g_PlayerPortrait[GUI.GetPlayerID()] = portrait
            LocalSetKnightPicture()
        end

        local newName = "]]..
f..

[["
        if newName ~= "" then
            GUI_MissionStatistic.PlayerNames[GUI.GetPlayerID()] = newName
        end
        HideOtherMenus()

        function GUI_Knight.GetTitleNameByTitleID(_KnightType, _TitleIndex)
            local KeyName = "Title_" .. GetNameOfKeyInTable(KnightTitles, _TitleIndex) .. "_" .. KnightGender[]]..
g73 ..
[[]
            local String = XGUIEng.GetStringTableText("UI_ObjectNames/" .. KeyName)
            if String == nil or String == "" then
                String = "Knight not in Gender Table? (localscript.lua)"
            end
            return String
        end
    ]])self.Data.HumanPlayerChangedOnce=true end
function BundleGameHelperFunctions.Global:GetControllingPlayer()local jt1wTgy=1
for LEJ=1,8 do if
Logic.PlayerGetIsHumanFlag(LEJ)==true then jt1wTgy=LEJ;break end end;return jt1wTgy end
function BundleGameHelperFunctions.Global:InitFestival()
if
not Logic.StartFestival_Orig_NothingToCelebrate then Logic.StartFestival_Orig_NothingToCelebrate=Logic.StartFestival end
Logic.StartFestival=function(EhuI3,X6)
if
BundleGameHelperFunctions.Global.Data.FestivalBlacklist[EhuI3]then if
BundleGameHelperFunctions.Global.Data.FestivalBlacklist[EhuI3][X6]then return end end
Logic.StartFestival_Orig_NothingToCelebrate(EhuI3,X6)end end
function BundleGameHelperFunctions.Global:RestrictFestivalForPlayer(IF2H,qOO620M,jtV6)
self:InitFestival()if not self.Data.FestivalBlacklist[IF2H]then
self.Data.FestivalBlacklist[IF2H]={}end;self.Data.FestivalBlacklist[IF2H][qOO620M]=
jtV6 ==true end
function BundleGameHelperFunctions.Global:ToggleExtendedZoom()
if self.Data.ExtendedZoomAllowed then if
self.Data.ExtendedZoomActive then self:DeactivateExtendedZoom()else
self:ActivateExtendedZoom()end end end
function BundleGameHelperFunctions.Global:ActivateExtendedZoom()
self.Data.ExtendedZoomActive=true
API.Bridge("BundleGameHelperFunctions.Local:ActivateExtendedZoom()")end
function BundleGameHelperFunctions.Global:DeactivateExtendedZoom()
self.Data.ExtendedZoomActive=false
API.Bridge("BundleGameHelperFunctions.Local:DeactivateExtendedZoom()")end
function BundleGameHelperFunctions.Global:InitExtendedZoom()
API.Bridge([[
        BundleGameHelperFunctions.Local:ActivateExtendedZoomHotkey()
        BundleGameHelperFunctions.Local:RegisterExtendedZoomHotkey()
    ]])end;function BundleGameHelperFunctions.Global:KillCheats()
self.Data.CheatsForbidden=true
API.Bridge("BundleGameHelperFunctions.Local:KillCheats()")end
function BundleGameHelperFunctions.Global:RessurectCheats()
self.Data.CheatsForbidden=false
API.Bridge("BundleGameHelperFunctions.Local:RessurectCheats()")end
function BundleGameHelperFunctions.Global:ThridPersonActivate(a8Yspa,Akk6ux)if BriefingSystem then
BundleGameHelperFunctions.Global:ThridPersonOverwriteStartAndEndBriefing()end;local VjdGqm=GetID(a8Yspa)
BundleGameHelperFunctions.Global.Data.ThridPersonIsActive=true
Logic.ExecuteInLuaLocalState([[
        BundleGameHelperFunctions.Local:ThridPersonActivate(]]..tostring(VjdGqm)..[[, ]]..
tostring(Akk6ux)..[[);
    ]])end
function BundleGameHelperFunctions.Global:ThridPersonDeactivate()
BundleGameHelperFunctions.Global.Data.ThridPersonIsActive=false
Logic.ExecuteInLuaLocalState([[
        BundleGameHelperFunctions.Local:ThridPersonDeactivate();
    ]])end;function BundleGameHelperFunctions.Global:ThridPersonIsRuning()return
self.Data.ThridPersonIsActive end
function BundleGameHelperFunctions.Global:ThridPersonOverwriteStartAndEndBriefing()
if
BriefingSystem then
if not BriefingSystem.StartBriefing_Orig_HeroCamera then
BriefingSystem.StartBriefing_Orig_HeroCamera=BriefingSystem.StartBriefing
BriefingSystem.StartBriefing=function(LdV,hbHc)
if
BundleGameHelperFunctions.Global:ThridPersonIsRuning()then
BundleGameHelperFunctions.Global:ThridPersonDeactivate()
BundleGameHelperFunctions.Global.Data.ThirdPersonStoppedByCode=true end
BriefingSystem.StartBriefing_Orig_HeroCamera(LdV,hbHc)end;StartBriefing=BriefingSystem.StartBriefing end
if not BriefingSystem.EndBriefing_Orig_HeroCamera then
BriefingSystem.EndBriefing_Orig_HeroCamera=BriefingSystem.EndBriefing
BriefingSystem.EndBriefing=function(k,XAYG3L)
BriefingSystem.EndBriefing_Orig_HeroCamera()
if
BundleGameHelperFunctions.Global.Data.ThridPersonStoppedByCode then
BundleGameHelperFunctions.Global:ThridPersonActivate(0)
BundleGameHelperFunctions.Global.Data.ThridPersonStoppedByCode=false end end end end end
function BundleGameHelperFunctions.Global:AddFollowKnightSave(v310,uzG,ngvL0wgx,a0kO)
local RnGTEUB8=GetID(v310)local tnp=GetID(uzG)a0kO=a0kO or 0
local x=Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,nil,"ControlFollowKnightSave",1,{},{RnGTEUB8,tnp,ngvL0wgx,a0kO})table.insert(self.Data.FollowKnightSave,x)return x end
function BundleGameHelperFunctions.Global:StopFollowKnightSave(H)for Wc,fxGSt in
pairs(self.Data.FollowKnightSave)do
if H==fxGSt then self.Data.FollowKnightSave[Wc]=nil;EndJob(H)end end end
function BundleGameHelperFunctions.Global.ControlFollowKnightSave(Rrfxi,oczl2,YwCVQ,SLXe)
if
not IsExisting(oczl2)or not IsExisting(Rrfxi)then return true end
if Logic.IsKnight(Rrfxi)and
Logic.KnightGetResurrectionProgress(Rrfxi)~=1 then return false end
if Logic.IsKnight(oczl2)and
Logic.KnightGetResurrectionProgress(oczl2)~=1 then return false end
if Logic.IsEntityMoving(Rrfxi)==false and
Logic.IsFighting(Rrfxi)==false and
IsNear(Rrfxi,oczl2,YwCVQ+300)==false then
local w,F,dFLo=Logic.EntityGetPos(oczl2)
local sFpL2IR=Logic.GetEntityOrientation(oczl2)- (180+SLXe)
local y5sHCE=w+YwCVQ*math.cos(math.rad(sFpL2IR))
local yJW=F+YwCVQ*math.sin(math.rad(sFpL2IR))
local itPfx=Logic.CreateEntityOnUnblockedLand(Entities.XD_ScriptEntity,y5sHCE,yJW,0,0)local w,F,dFLo=Logic.EntityGetPos(itPfx)
DestroyEntity(itPfx)Logic.MoveSettler(Rrfxi,w,F)end end
ControlFollowKnightSave=BundleGameHelperFunctions.Global.ControlFollowKnightSave
function BundleGameHelperFunctions.Global:ChangeTerrainTypeInSquare(AFqc,gu9,s162whv)
local UIArtqy,U,_fz,M,b3aPNs9F=self:GetSquareForWaterAndTerrain(AFqc,gu9)if UIArtqy==-1 or UIArtqy==-2 then return UIArtqy end;if
type(s162whv)=="number"then
for wT8i1YM9=UIArtqy,_fz do for FedVlsC=U,M do
Logic.SetTerrainNodeType(wT8i1YM9,FedVlsC,s162whv)end end end
Logic.UpdateBlocking(x11,y11,x12,y12)end
function BundleGameHelperFunctions.Global:ChangeWaterHeightInSquare(aTX,N,DzN,hV77)
local F,c30S1HE,JM3hcx9_,R1Lb,ti9Wt5=self:GetSquareForWaterAndTerrain(aTX,N)if F==-1 or F==-2 then return F end
if not hV77 then if DzN<0 then return-3 end
Logic.WaterSetAbsoluteHeight(F,c30S1HE,JM3hcx9_,R1Lb,DzN)else if ti9Wt5+DzN<0 then return-3 end
Logic.WaterSetAbsoluteHeight(F,c30S1HE,JM3hcx9_,R1Lb,ti9Wt5+DzN)end;Logic.UpdateBlocking(F,c30S1HE,JM3hcx9_,R1Lb)return 0 end
function BundleGameHelperFunctions.Global:ChangeTerrainHeightInSquare(GmTBm,DT,HQaqh,Nk)
local HE,I_aA,LD_ktC,VzGb7,H=self:GetSquareForWaterAndTerrain(GmTBm,DT)if HE==-1 or HE==-2 then return HE end;local qb5
if not Nk then
if HQaqh<0 then return-3 end;qb5=HQaqh else if H+HQaqh<0 then return-3 end;qb5=H+HQaqh end;for bT=HE,LD_ktC do
for wKpfb=I_aA,VzGb7 do Logic.SetTerrainNodeHeight(bT,wKpfb,qb5)end end
Logic.UpdateBlocking(HE,I_aA,LD_ktC,VzGb7)return 0 end
function BundleGameHelperFunctions.Global:GetSquareForWaterAndTerrain(X8x,Wl)
local i5RShK=type(X8x)
if(i5RShK~="string"and i5RShK~="number")or not
IsExisting(X8x)then return-1 end;local mlET3,snRTClV4,DL,yWHjK3u;local K=GetID(X8x)
local OQxSR,s,x373FiG=Logic.EntityGetPos(K)mlET3=math.floor((OQxSR-Wl)/100)snRTClV4=math.floor(
(s-Wl)/100)
DL=math.floor((OQxSR+Wl)/100)yWHjK3u=math.floor((s+Wl)/100)
if
IsValidPosition({X=mlET3,Y=snRTClV4})==false or
IsValidPosition({X=DL,Y=yWHjK3u})==false then return-2 end;return mlET3,snRTClV4,DL,yWHjK3u,x373FiG end
function BundleGameHelperFunctions.Global.OnSaveGameLoaded()Logic.StartFestival_Orig_NothingToCelebrate=
nil
BundleGameHelperFunctions.Global:InitFestival()if BundleGameHelperFunctions.Global.Data.ExtendedZoomActive then
BundleGameHelperFunctions.Global:ActivateExtendedZoom()end;if
BundleGameHelperFunctions.Global.Data.CheatsForbidden==true then
BundleGameHelperFunctions.Global:KillCheats()end
if
BundleGameHelperFunctions.Global.Data.HumanPlayerChangedOnce then
Logic.ExecuteInLuaLocalState([[
            GUI.SetControlledPlayer(]]..

BundleGameHelperFunctions.Global.Data.HumanPlayerID..
[[)
            for k,v in pairs(Buffs)do
                GUI_Buffs.UpdateBuffsInInterface(]]..

BundleGameHelperFunctions.Global.Data.HumanPlayerID..

[[,v)
                GUI.ResetMiniMap()
            end
            if IsExisting(Logic.GetKnightID(GUI.GetPlayerID())) then
                local portrait = GetKnightActor(]]..
BundleGameHelperFunctions.Global.Data.HumanKnightType..

[[)
                g_PlayerPortrait[]]..BundleGameHelperFunctions.Global.Data.HumanPlayerID..
[[] = portrait
                LocalSetKnightPicture()
            end
        ]])end end
function BundleGameHelperFunctions.Local:Install()
self:InitForbidSpeedUp()self:InitForbidSaveGame()
self:InitForbidFestival()
QSB.TimeLine=BundleGameHelperFunctions.Shared.TimeLine;TimeLine=QSB.TimeLine end
function BundleGameHelperFunctions.Local:SetCameraToPlayerKnight(YBMVrw0,k,Gpkgz)
BundleGameHelperFunctions.Local:SetCameraToEntity(Logic.GetKnightID(YBMVrw0),k,Gpkgz)end
function BundleGameHelperFunctions.Local:SetCameraToEntity(AeBaKw,y,J9iRF)
local ilESRrS=GetPosition(AeBaKw)local geCTE=(y or-45)local _GgGjVu=(J9iRF or 0.5)
Camera.RTS_SetLookAtPosition(ilESRrS.X,ilESRrS.Y)Camera.RTS_SetRotationAngle(geCTE)
Camera.RTS_SetZoomFactor(_GgGjVu)end;function BundleGameHelperFunctions.Local:SetSpeedLimit(EkBrp4ib)EkBrp4ib=
(EkBrp4ib<1 and 1)or math.floor(EkBrp4ib)
self.Data.SpeedLimit=EkBrp4ib end
function BundleGameHelperFunctions.Local:ActivateSpeedLimit(eVp)self.Data.UseSpeedLimit=
eVp==true;if
eVp and
Game.GameTimeGetFactor(GUI.GetPlayerID())>self.Data.SpeedLimit then
Game.GameTimeSetFactor(GUI.GetPlayerID(),self.Data.SpeedLimit)end end
function BundleGameHelperFunctions.Local:InitForbidSpeedUp()
GameCallback_GameSpeedChanged_Orig_Preferences_ForbidSpeedUp=GameCallback_GameSpeedChanged
GameCallback_GameSpeedChanged=function(eEzA)
GameCallback_GameSpeedChanged_Orig_Preferences_ForbidSpeedUp(eEzA)
if
BundleGameHelperFunctions.Local.Data.UseSpeedLimit==true then
if
eEzA>BundleGameHelperFunctions.Local.Data.SpeedLimit then
Game.GameTimeSetFactor(GUI.GetPlayerID(),BundleGameHelperFunctions.Local.Data.SpeedLimit)end end end end
function BundleGameHelperFunctions.Local:KillCheats()
Input.KeyBindDown(Keys.ModifierControl+
Keys.ModifierShift+Keys.Divide,"KeyBindings_EnableDebugMode(0)",2,false)end
function BundleGameHelperFunctions.Local:RessurectCheats()
Input.KeyBindDown(Keys.ModifierControl+
Keys.ModifierShift+Keys.Divide,"KeyBindings_EnableDebugMode(2)",2,false)end
function BundleGameHelperFunctions.Local:RegisterExtendedZoomHotkey()
API.AddHotKey({de="Strg + Umschalt + K",en="Ctrl + Shift + K"},{de="Alternativen Zoom ein/aus",en="Alternative zoom on/off"})end
function BundleGameHelperFunctions.Local:ActivateExtendedZoomHotkey()
Input.KeyBindDown(
Keys.ModifierControl+Keys.ModifierShift+Keys.K,"BundleGameHelperFunctions.Local:ToggleExtendedZoom()",2,false)end;function BundleGameHelperFunctions.Local:ToggleExtendedZoom()
API.Bridge("BundleGameHelperFunctions.Global:ToggleExtendedZoom()")end
function BundleGameHelperFunctions.Local:ActivateExtendedZoom()
Camera.RTS_SetZoomFactorMax(0.8701)Camera.RTS_SetZoomFactor(0.8700)
Camera.RTS_SetZoomFactorMin(0.0999)end
function BundleGameHelperFunctions.Local:DeactivateExtendedZoom()
Camera.RTS_SetZoomFactor(0.5000)Camera.RTS_SetZoomFactorMax(0.5001)
Camera.RTS_SetZoomFactorMin(0.0999)end
function BundleGameHelperFunctions.Local:InitForbidSaveGame()
KeyBindings_SaveGame_Orig_Preferences_SaveGame=KeyBindings_SaveGame
KeyBindings_SaveGame=function()if
BundleGameHelperFunctions.Local.Data.ForbidSave then return end
KeyBindings_SaveGame_Orig_Preferences_SaveGame()end end
function BundleGameHelperFunctions.Local:DisplaySaveButtons(eu)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/SaveGame",(
eu and 0)or 1)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/QuickSave",(eu and 0)or 1)end
function BundleGameHelperFunctions.Local:ThridPersonActivate(uy,XPhE)
uy=(uy~=0 and uy)or
self.Data.ThridPersonLastHero or Logic.GetKnightID(GUI.GetPlayerID())
XPhE=XPhE or self.Data.ThridPersonLastZoom or 0.5;if not uy then return end
if
not GameCallback_Camera_GetBorderscrollFactor_Orig_HeroCamera then self:ThridPersonOverwriteGetBorderScrollFactor()end;self.Data.ThridPersonLastHero=uy
self.Data.ThridPersonLastZoom=XPhE;self.Data.ThridPersonIsActive=true
local qY=Logic.GetEntityOrientation(uy)Camera.RTS_FollowEntity(uy)
Camera.RTS_SetRotationAngle(qY-90)Camera.RTS_SetZoomFactor(XPhE)
Camera.RTS_SetZoomFactorMax(XPhE+0.0001)end
function BundleGameHelperFunctions.Local:ThridPersonDeactivate()
self.Data.ThridPersonIsActive=false;Camera.RTS_SetZoomFactorMax(0.5)
Camera.RTS_SetZoomFactor(0.5)Camera.RTS_FollowEntity(0)end;function BundleGameHelperFunctions.Local:ThridPersonIsRuning()
return self.Data.ThridPersonIsActive end
function BundleGameHelperFunctions.Local:ThridPersonOverwriteGetBorderScrollFactor()
GameCallback_Camera_GetBorderscrollFactor_Orig_HeroCamera=GameCallback_Camera_GetBorderscrollFactor
GameCallback_Camera_GetBorderscrollFactor=function()
if not
BundleGameHelperFunctions.Local.Data.ThridPersonIsActive then return
GameCallback_Camera_GetBorderscrollFactor_Orig_HeroCamera()end;local Br5LVe=Camera.RTS_GetRotationAngle()
local RnweC1yT,W=GUI.GetScreenSize()local DgeRW,cg=GUI.GetMousePosition()local bbWOyt=DgeRW/RnweC1yT
if
bbWOyt<=0.02 then Br5LVe=Br5LVe+0.3 elseif bbWOyt>=0.98 then Br5LVe=Br5LVe-0.3 else return 0 end;if Br5LVe>=360 then Br5LVe=0 end
Camera.RTS_SetRotationAngle(Br5LVe)return 0 end end
function BundleGameHelperFunctions.Local:InitForbidFestival()
NewStartFestivalUpdate=function()
local E1y3xLZ=XGUIEng.GetCurrentWidgetID()local AAsaSz=GUI.GetPlayerID()
if
BundleGameHelperFunctions.Local.Data.NormalFestivalLockedForPlayer[AAsaSz]then XGUIEng.ShowWidget(E1y3xLZ,0)return true end end
Core:StackFunction("GUI_BuildingButtons.StartFestivalUpdate",NewStartFestivalUpdate)end
function BundleGameHelperFunctions.Shared.TimeLine:Start(nBMvNL)
local m=self.Data.TimeLineUniqueJobID;self.Data.TimeLineUniqueJobID=m+1;nBMvNL.Running=true
nBMvNL.StartTime=Logic.GetTime()nBMvNL.Iterator=1;local DmJnXc=0;for ak=1,#nBMvNL,1 do
if nBMvNL[ak].Time<DmJnXc then nBMvNL[ak].Time=
DmJnXc+1;DmJnXc=nBMvNL[ak].Time end end
self.Data.TimeLineJobs[m]=nBMvNL
if not self.Data.ControlerID then
local K=StartSimpleJobEx(BundleGameHelperFunctions.Shared.TimeLine.TimeLineControler)self.Data.ControlerID=K end;return m end
function BundleGameHelperFunctions.Shared.TimeLine:Restart(KZiKrG)if not
self.Data.TimeLineJobs[KZiKrG]then return end
self.Data.TimeLineJobs[KZiKrG].Running=true
self.Data.TimeLineJobs[KZiKrG].StartTime=Logic.GetTime()
self.Data.TimeLineJobs[KZiKrG].Iterator=1 end
function BundleGameHelperFunctions.Shared.TimeLine:IsRunning(_87BXC)if
self.Data.TimeLineJobs[_87BXC]then return
self.Data.TimeLineJobs[_87BXC].Running==true end
return false end
function BundleGameHelperFunctions.Shared.TimeLine:Yield(OhOc2n)if not
self.Data.TimeLineJobs[OhOc2n]then return end
self.Data.TimeLineJobs[OhOc2n].Running=false end;function BundleGameHelperFunctions.Shared.TimeLine:Resume(t)if not
self.Data.TimeLineJobs[t]then return end
self.Data.TimeLineJobs[t].Running=true end
function BundleGameHelperFunctions.Shared.TimeLine.TimeLineControler()
for y3wErvEm,CCs in
pairs(BundleGameHelperFunctions.Shared.TimeLine.Data.Jobs)do if CCs.Iterator>#CCs then
BundleGameHelperFunctions.Shared.TimeLine.Data.Jobs[y3wErvEm].Running=false end
if CCs.Running then
if
(
CCs[CCs.Iterator].Time+CCs.StartTime)<=Logic.GetTime()then
CCs[CCs.Iterator].Action(CCs[CCs.Iterator])BundleGameHelperFunctions.Shared.TimeLine.Data.Jobs[y3wErvEm].Iterator=
CCs.Iterator+1 end end end end;Core:RegisterBundle("BundleGameHelperFunctions")API=
API or{}QSB=QSB or{}
function API.OpenDialog(sdtih,z8QlkPC,N5lime92)if not GUI then
API.Dbg("API.OpenDialog: Can only be used in the local script!")return end
local b4xAHY=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if type(sdtih)=="table"then sdtih=sdtih[b4xAHY]end;if
type(z8QlkPC)=="table"then z8QlkPC=z8QlkPC[b4xAHY]end;return
BundleDialogWindows.Local:OpenDialog(sdtih,z8QlkPC,N5lime92)end
function API.OpenRequesterDialog(z,poDPM,E,Vap8A)if not GUI then
API.Dbg("API.OpenRequesterDialog: Can only be used in the local script!")return end
local qxEsDQp=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if type(z)=="table"then z=z[qxEsDQp]end;if
type(poDPM)=="table"then poDPM=poDPM[qxEsDQp]end;return
BundleDialogWindows.Local:OpenRequesterDialog(z,poDPM,E,Vap8A)end
function API.OpenSelectionDialog(Ue25a8v,gLXme,jpPyKze,VX)if not GUI then
API.Dbg("API.OpenSelectionDialog: Can only be used in the local script!")return end
local PWB=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
if type(Ue25a8v)=="table"then Ue25a8v=Ue25a8v[PWB]end;if type(gLXme)=="table"then gLXme=gLXme[PWB]end
gLXme=gLXme.."{cr}"return
BundleDialogWindows.Local:OpenSelectionDialog(Ue25a8v,gLXme,jpPyKze,VX)end
BundleDialogWindows={Global={Data={}},Local={Data={Requester={ActionFunction=nil,ActionRequester=nil,Next=nil,Queue={}}},TextWindow={Data={Shown=false,Caption="",Text="",ButtonText="",Picture=
nil,Action=nil,Callback=function()end}}}}function BundleDialogWindows.Global:Install()end
function BundleDialogWindows.Local:Install()
self:DialogOverwriteOriginal()TextWindow=self.TextWindow end
function BundleDialogWindows.Local:Callback()
if self.Data.Requester.ActionFunction then self.Data.Requester.ActionFunction(
CustomGame.Knight+1)end;self:OnDialogClosed()end
function BundleDialogWindows.Local:CallbackRequester(GtWEV)if
self.Data.Requester.ActionRequester then
self.Data.Requester.ActionRequester(GtWEV)end
self:OnDialogClosed()end
function BundleDialogWindows.Local:OnDialogClosed()
self:DialogQueueStartNext()self:RestoreSaveGame()end
function BundleDialogWindows.Local:DialogQueueStartNext()
self.Data.Requester.Next=table.remove(self.Data.Requester.Queue,1)
DialogQueueStartNext_HiResControl=function()
local nZay6Q=BundleDialogWindows.Local.Data.Requester.Next
if nZay6Q and nZay6Q[1]and nZay6Q[2]then local srojWa=nZay6Q[1]
BundleDialogWindows.Local[srojWa](BundleDialogWindows.Local,unpack(nZay6Q[2]))BundleDialogWindows.Local.Data.Requester.Next=
nil end;return true end
StartSimpleHiResJob("DialogQueueStartNext_HiResControl")end;function BundleDialogWindows.Local:DialogQueuePush(Yqo,h3544K)local OcDu={Yqo,h3544K}
table.insert(self.Data.Requester.Queue,OcDu)end
function BundleDialogWindows.Local:OpenDialog(YH,CcC2lTC,UBmbdH)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then assert(type(YH)=="string")assert(
type(CcC2lTC)=="string")YH="{center}"..YH;if
string.len(CcC2lTC)<35 then CcC2lTC=CcC2lTC.."{cr}"end;g_MapAndHeroPreview.SelectKnight=function()
end
XGUIEng.ShowAllSubWidgets("/InGame/Dialog/BG",1)XGUIEng.ShowWidget("/InGame/Dialog/Backdrop",0)
XGUIEng.ShowWidget(RequesterDialog,1)XGUIEng.ShowWidget(RequesterDialog_Yes,0)
XGUIEng.ShowWidget(RequesterDialog_No,0)XGUIEng.ShowWidget(RequesterDialog_Ok,1)
if type(UBmbdH)==
"function"then self.Data.Requester.ActionFunction=UBmbdH
local K3FZ="XGUIEng.ShowWidget(RequesterDialog, 0)"K3FZ=K3FZ.."; XGUIEng.PopPage()"K3FZ=K3FZ..
"; BundleDialogWindows.Local.Callback(BundleDialogWindows.Local)"
XGUIEng.SetActionFunction(RequesterDialog_Ok,K3FZ)else self.Data.Requester.ActionFunction=nil
local f="XGUIEng.ShowWidget(RequesterDialog, 0)"f=f.."; XGUIEng.PopPage()"
f=f.."; BundleDialogWindows.Local.Callback(BundleDialogWindows.Local)"XGUIEng.SetActionFunction(RequesterDialog_Ok,f)end
XGUIEng.SetText(RequesterDialog_Message,"{center}"..CcC2lTC)XGUIEng.SetText(RequesterDialog_Title,YH)XGUIEng.SetText(
RequesterDialog_Title.."White",YH)
XGUIEng.PushPage(RequesterDialog,false)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/QuickSave",0)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/SaveGame",0)
if not KeyBindings_SaveGame_Orig_QSB_Windows then
KeyBindings_SaveGame_Orig_QSB_Windows=KeyBindings_SaveGame;KeyBindings_SaveGame=function()end end else
self:DialogQueuePush("OpenDialog",{YH,CcC2lTC,UBmbdH})end end
function BundleDialogWindows.Local:OpenRequesterDialog(ykVOUrKV,xI,S,lVm)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then
assert(type(ykVOUrKV)=="string")assert(type(xI)=="string")
ykVOUrKV="{center}"..ykVOUrKV;self:OpenDialog(ykVOUrKV,xI,S)
XGUIEng.ShowWidget(RequesterDialog_Yes,1)XGUIEng.ShowWidget(RequesterDialog_No,1)
XGUIEng.ShowWidget(RequesterDialog_Ok,0)
if lVm~=nil then
XGUIEng.SetText(RequesterDialog_Yes,XGUIEng.GetStringTableText("UI_Texts/Ok_center"))
XGUIEng.SetText(RequesterDialog_No,XGUIEng.GetStringTableText("UI_Texts/Cancel_center"))else
XGUIEng.SetText(RequesterDialog_Yes,XGUIEng.GetStringTableText("UI_Texts/Yes_center"))
XGUIEng.SetText(RequesterDialog_No,XGUIEng.GetStringTableText("UI_Texts/No_center"))end;self.Data.Requester.ActionRequester=nil
if S then
assert(type(S)=="function")self.Data.Requester.ActionRequester=S end;local mgcN3Y="XGUIEng.ShowWidget(RequesterDialog, 0)"
mgcN3Y=mgcN3Y.."; XGUIEng.PopPage()"
mgcN3Y=mgcN3Y.."; BundleDialogWindows.Local.CallbackRequester(BundleDialogWindows.Local, true)"
XGUIEng.SetActionFunction(RequesterDialog_Yes,mgcN3Y)local mgcN3Y="XGUIEng.ShowWidget(RequesterDialog, 0)"
mgcN3Y=mgcN3Y.."; XGUIEng.PopPage()"
mgcN3Y=mgcN3Y.."; BundleDialogWindows.Local.CallbackRequester(BundleDialogWindows.Local, false)"
XGUIEng.SetActionFunction(RequesterDialog_No,mgcN3Y)else
self:DialogQueuePush("OpenRequesterDialog",{ykVOUrKV,xI,S,lVm})end end
function BundleDialogWindows.Local:OpenSelectionDialog(dLIiqar,Q,u,wtMEkjRL)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then self:OpenDialog(dLIiqar,Q,u)
local vU3I=XGUIEng.GetWidgetID(CustomGame.Widget.KnightsList)XGUIEng.ListBoxPopAll(vU3I)for fE=1,#wtMEkjRL do
XGUIEng.ListBoxPushItem(vU3I,wtMEkjRL[fE])end
XGUIEng.ListBoxSetSelectedIndex(vU3I,0)CustomGame.Knight=0;local huhxZB="XGUIEng.ShowWidget(RequesterDialog, 0)"huhxZB=
huhxZB.."; XGUIEng.PopPage()"
huhxZB=huhxZB.."; XGUIEng.PopPage()"huhxZB=huhxZB.."; XGUIEng.PopPage()"
huhxZB=huhxZB..
"; BundleDialogWindows.Local.Callback(BundleDialogWindows.Local)"
XGUIEng.SetActionFunction(RequesterDialog_Ok,huhxZB)local W5eI="/InGame/Singleplayer/CustomGame/ContainerSelection/"
XGUIEng.SetText(W5eI..
"HeroComboBoxMain/HeroComboBox","")if wtMEkjRL[1]then
XGUIEng.SetText(W5eI.."HeroComboBoxMain/HeroComboBox",wtMEkjRL[1])end
XGUIEng.PushPage(W5eI.."HeroComboBoxContainer",false)
XGUIEng.PushPage(W5eI.."HeroComboBoxMain",false)
XGUIEng.ShowWidget(W5eI.."HeroComboBoxContainer",0)local XS0l={GUI.GetScreenSize()}
local kRU7gz06,iEuu=XGUIEng.GetWidgetScreenPosition(RequesterDialog_Ok)
XGUIEng.SetWidgetScreenPosition(W5eI.."HeroComboBoxMain",kRU7gz06-25,iEuu-90)
XGUIEng.SetWidgetScreenPosition(W5eI.."HeroComboBoxContainer",kRU7gz06-25,iEuu-20)else
self:DialogQueuePush("OpenSelectionDialog",{dLIiqar,Q,u,wtMEkjRL})end end
function BundleDialogWindows.Local:RestoreSaveGame()
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/QuickSave",1)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/SaveGame",1)
if KeyBindings_SaveGame_Orig_QSB_Windows then
KeyBindings_SaveGame=KeyBindings_SaveGame_Orig_QSB_Windows;KeyBindings_SaveGame_Orig_QSB_Windows=nil end end
function BundleDialogWindows.Local:DialogOverwriteOriginal()
OpenDialog_Orig_Windows=OpenDialog
OpenDialog=function(CCb6csB3,RTTNb8e,cUj4EHLT)
if XGUIEng.IsWidgetShown(RequesterDialog)==0 then
local g161JmD="XGUIEng.ShowWidget(RequesterDialog, 0)"g161JmD=g161JmD.."; XGUIEng.PopPage()"
XGUIEng.SetActionFunction(RequesterDialog_Ok,g161JmD)OpenDialog_Orig_Windows(RTTNb8e,CCb6csB3)end end;OpenRequesterDialog_Orig_Windows=OpenRequesterDialog
OpenRequesterDialog=function(E8zU_n,b2Xs_blx,xh,v60G,hPkY9bO)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then local k2mlfc="XGUIEng.ShowWidget(RequesterDialog, 0)"k2mlfc=k2mlfc..
"; XGUIEng.PopPage()"
XGUIEng.SetActionFunction(RequesterDialog_Yes,k2mlfc)local k2mlfc="XGUIEng.ShowWidget(RequesterDialog, 0)"
k2mlfc=k2mlfc.."; XGUIEng.PopPage()"
XGUIEng.SetActionFunction(RequesterDialog_No,k2mlfc)
OpenRequesterDialog_Orig_Windows(E8zU_n,b2Xs_blx,xh,v60G,hPkY9bO)end end end
function BundleDialogWindows.Local.TextWindow:New(...)
assert(self==
BundleDialogWindows.Local.TextWindow,"Can not be used from instance!")local qYSV2=API.InstanceTable(self)qYSV2.Data.Caption=arg[1]or
qYSV2.Data.Caption
qYSV2.Data.Text=arg[2]or qYSV2.Data.Text;qYSV2.Data.Action=arg[3]
qYSV2.Data.ButtonText=arg[4]or qYSV2.Data.ButtonText
qYSV2.Data.Callback=arg[5]or qYSV2.Data.Callback;return qYSV2 end
function BundleDialogWindows.Local.TextWindow:AddParamater(g,hzfqfggM)
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")
assert(self.Data[g]~=nil,"Key '"..g.."' already exists!")self.Data[g]=hzfqfggM;return self end
function BundleDialogWindows.Local.TextWindow:SetCaption(M0lvbat)
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")assert(type(M0lvbat)=="string")
self.Data.Caption=M0lvbat;return self end
function BundleDialogWindows.Local.TextWindow:SetContent(wZUGT)
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")assert(type(wZUGT)=="string")
self.Data.Text=wZUGT;return self end
function BundleDialogWindows.Local.TextWindow:SetAction(yPbOWoG)
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")
assert(nil or type(yPbOWoG)=="function")self.Data.Callback=yPbOWoG;return self end
function BundleDialogWindows.Local.TextWindow:SetButton(g8q7j,RQpNQ)
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")
if g8q7j then assert(type(g8q7j)=="string")assert(type(RQpNQ)==
"function")end;self.Data.ButtonText=g8q7j;self.Data.Action=RQpNQ;return self end
function BundleDialogWindows.Local.TextWindow:Show()
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")
BundleDialogWindows.Local.TextWindow.Data.Shown=true;self.Data.Shown=true;self:Prepare()
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ToggleWhisperTarget",1)if not self.Data.Action then
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ToggleWhisperTarget",0)end
XGUIEng.SetText("/InGame/Root/Normal/MessageLog/Name",
"{center}"..self.Data.Caption)
XGUIEng.SetText("/InGame/Root/Normal/ChatOptions/ToggleWhisperTarget","{center}"..self.Data.ButtonText)GUI_Chat.ClearMessageLog()
GUI_Chat.ChatlogAddMessage(self.Data.Text)local Ib=string.len(self.Data.Text)local zZq8Mf=1;local QqAboSXb=0
while(true)do
local nxBnCeN,L=string.find(self.Data.Text,"{cr}",zZq8Mf)if not L then break end
if L-zZq8Mf<=58 then Ib=Ib+58- (L-zZq8Mf)end;zZq8Mf=L+1 end;if(Ib+ (QqAboSXb*55))>1000 then
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatLogSlider",1)end
Game.GameTimeSetFactor(GUI.GetPlayerID(),0)end
function BundleDialogWindows.Local.TextWindow:Prepare()
function GUI_Chat.CloseChatMenu()
BundleDialogWindows.Local.TextWindow.Data.Shown=false;self.Data.Shown=false;if self.Data.Callback then
self.Data.Callback(self)end
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/BG",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Close",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Slider",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Text",1)Game.GameTimeReset(GUI.GetPlayerID())end;function GUI_Chat.ToggleWhisperTargetUpdate()
Game.GameTimeSetFactor(GUI.GetPlayerID(),0)end;function GUI_Chat.CheckboxMessageTypeWhisperUpdate()
XGUIEng.SetText("/InGame/Root/Normal/ChatOptions/TextCheckbox",
"{center}"..self.Data.Caption)end
function GUI_Chat.ToggleWhisperTarget()if
self.Data.Action then self.Data.Action(self)end end;function GUI_Chat.ClearMessageLog()g_Chat.ChatHistory={}end
function GUI_Chat.ChatlogAddMessage(IkeMo2Tp)
table.insert(g_Chat.ChatHistory,IkeMo2Tp)local zxgE=""
for v_2mpHj4,l in ipairs(g_Chat.ChatHistory)do zxgE=zxgE..l.."{cr}"end
XGUIEng.SetText("/InGame/Root/Normal/ChatOptions/ChatLog",zxgE)end;local fO7=
(Network.GetDesiredLanguage()=="de"and"de")or"en"if
type(self.Data.Caption)=="table"then
self.Data.Caption=self.Data.Caption[fO7]end;if type(self.Data.ButtonText)==
"table"then
self.Data.ButtonText=self.Data.ButtonText[fO7]end
if type(self.Data.Text)==
"table"then self.Data.Text=self.Data.Text[fO7]end
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatModeAllPlayers",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatModeTeam",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatModeWhisper",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatChooseModeCaption",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/Background/TitleBig",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/Background/TitleBig/Info",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatLogCaption",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/BGChoose",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/BGChatLog",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatLogSlider",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/BG",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Close",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Slider",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Text",0)
XGUIEng.DisableButton("/InGame/Root/Normal/ChatOptions/ToggleWhisperTarget",0)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/MessageLog",0,95)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/MessageLog/Name",0,0)
XGUIEng.SetTextColor("/InGame/Root/Normal/MessageLog/Name",51,51,121,255)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/ChatOptions/ChatLog",140,150)
XGUIEng.SetWidgetSize("/InGame/Root/Normal/ChatOptions/Background/DialogBG/1 (2)/2",150,400)
XGUIEng.SetWidgetPositionAndSize("/InGame/Root/Normal/ChatOptions/Background/DialogBG/1 (2)/3",400,500,350,400)
XGUIEng.SetWidgetSize("/InGame/Root/Normal/ChatOptions/ChatLog",640,580)
XGUIEng.SetWidgetSize("/InGame/Root/Normal/ChatOptions/ChatLogSlider",46,660)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/ChatOptions/ChatLogSlider",780,130)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/ChatOptions/ToggleWhisperTarget",110,760)end;Core:RegisterBundle("BundleDialogWindows")
API=API or{}QSB=QSB or{}
function API.PauseQuestsDuringBriefings(Fbj_zc)if GUI then
API.Bridge("API.PauseQuestsDuringBriefings("..
tostring(Fbj_zc)..")")return end;return
BundleBriefingSystem.Global:PauseQuestsDuringBriefings(Fbj_zc)end;PauseQuestsDuringBriefings=API.PauseQuestsDuringBriefings
function API.IsBriefingFinished(sFG)if GUI then
API.Dbg("API.IsBriefingFinished: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:IsBriefingFinished(sFG)end;IsBriefingFinished=API.IsBriefingFinished
function API.MCGetSelectedAnswer(x)if GUI then
API.Dbg("API.MCGetSelectedAnswer: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:MCGetSelectedAnswer(x)end;MCGetSelectedAnswer=API.MCGetSelectedAnswer
function API.GetCurrentBriefingPage(H6nA)if GUI then
API.Dbg("API.GetCurrentBriefingPage: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:GetCurrentBriefingPage(H6nA)end;GetCurrentBriefingPage=API.GetCurrentBriefingPage
function API.GetCurrentBriefing()if GUI then
API.Dbg("API.GetCurrentBriefing: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:GetCurrentBriefing()end;GetCurrentBriefing=API.GetCurrentBriefing
function API.AddPages(rYid8CG)if GUI then
API.Dbg("API.AddPages: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:AddPages(rYid8CG)end;AddPages=API.AddPages
function API.AddBriefingNote(AO38Nlx0,CcFb)if type(AO38Nlx0)~="string"and type(AO38Nlx0)~=
"number"then
API.Dbg("API.BriefingNote: Text must be a string or a number!")return end;if not GUI then
API.Bridge(
[[API.BriefingNote("]]..AO38Nlx0 ..[[", ]]..tostring(CcFb)..[[)]])return end;return BriefingSystem.PushInformationText(AO38Nlx0,(
CcFb*10))end;BriefingMessage=API.AddBriefingNote;function AP(mfEc)
API.Dbg("AP: Please use the function provides by AddPages!")end;function ASP(YoJiNVRT,JLuV,VZm9,EBupkZi,RpmTiVXT)
API.Dbg("ASP: Please use the function provides by AddPages!")end;function ASMC(gImQiI,wi6FC5JA,Hz4UJ7T,aOBIrw3,...)
API.Dbg("ASMC: Please use the function provides by AddPages!")end
BundleBriefingSystem={Global={Data={PlayedBriefings={},QuestsPausedWhileBriefingActive=true,BriefingID=0}},Local={Data={}}}function BundleBriefingSystem.Global:Install()
self:InitalizeBriefingSystem()end
function BundleBriefingSystem.Global:PauseQuestsDuringBriefings(OaAYm)self.Data.QuestsPausedWhileBriefingActive=
OaAYm==true end
function BundleBriefingSystem.Global:IsBriefingFinished(lVhSaie2)return
self.Data.PlayedBriefings[lVhSaie2]==true end
function BundleBriefingSystem.Global:MCGetSelectedAnswer(sk)if sk.mc and sk.mc.given then return
sk.mc.given end;return 0 end;function BundleBriefingSystem.Global:GetCurrentBriefingPage(k1f)return
BriefingSystem.currBriefing[k1f]end;function BundleBriefingSystem.Global:GetCurrentBriefing()return
BriefingSystem.currBriefing end
function BundleBriefingSystem.Global:AddPages(CqoRoQ)
local MAEI=function(HLQAc2)
if
HLQAc2 and type(HLQAc2)=="table"then
local _eaXZVx0=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if type(HLQAc2.title)=="table"then
HLQAc2.title=HLQAc2.title[_eaXZVx0]end
HLQAc2.title=HLQAc2.title or""if type(HLQAc2.text)=="table"then
HLQAc2.text=HLQAc2.text[_eaXZVx0]end;HLQAc2.text=HLQAc2.text or""
if
HLQAc2.mc then
if HLQAc2.mc.answers then HLQAc2.mc.amount=#HLQAc2.mc.answers;assert(
HLQAc2.mc.amount>=1)HLQAc2.mc.current=1
for fEX=1,HLQAc2.mc.amount
do
if HLQAc2.mc.answers[fEX]then if
type(HLQAc2.mc.answers[fEX][1])=="table"then
HLQAc2.mc.answers[fEX][1]=HLQAc2.mc.answers[fEX][1][_eaXZVx0]end end end end;if type(HLQAc2.mc.title)=="table"then
HLQAc2.mc.title=HLQAc2.mc.title[_eaXZVx0]end
if
type(HLQAc2.mc.text)=="table"then HLQAc2.mc.text=HLQAc2.mc.text[_eaXZVx0]end end
if HLQAc2.view then HLQAc2.flyTime=HLQAc2.view.FlyTime or 0;HLQAc2.duration=
HLQAc2.view.Duration or 0 else
if
type(HLQAc2.position)=="table"then
if not HLQAc2.position.X then
HLQAc2.zOffset=HLQAc2.position[2]HLQAc2.position=HLQAc2.position[1]elseif HLQAc2.position.Z then
HLQAc2.zOffset=HLQAc2.position.Z end end
if HLQAc2.lookAt~=nil then local Hxrl2=HLQAc2.lookAt;if type(Hxrl2)=="table"then
HLQAc2.zOffset=Hxrl2[2]Hxrl2=Hxrl2[1]end
if type(Hxrl2)=="string"or
type(Hxrl2)=="number"then local dm_mIr=GetID(Hxrl2)
local U=Logic.GetEntityOrientation(dm_mIr)if Logic.IsBuilding(dm_mIr)==0 then U=U+90 end;local o9g2wCDc=0.085*
string.len(HLQAc2.text)HLQAc2.position=dm_mIr;HLQAc2.duration=
HLQAc2.duration or o9g2wCDc;HLQAc2.flyTime=HLQAc2.flyTime;HLQAc2.rotation=(
HLQAc2.rotation or 0)+U end end end;table.insert(CqoRoQ,HLQAc2)else table.insert(CqoRoQ,
(HLQAc2 ~=nil and HLQAc2)or-1)end;return HLQAc2 end
local K7=function(kxtGbniZ,e,xnkG,iCUi,NMeNK4x)local MwqB5f=Logic.GetEntityName(GetID(kxtGbniZ))assert(MwqB5f~=
nil and MwqB5f~="")local OSrJSV={}OSrJSV.zoom=(
iCUi==true and 2400)or 6250;OSrJSV.angle=(
iCUi==true and 40)or 47
OSrJSV.lookAt={MwqB5f,100}OSrJSV.title=e;OSrJSV.text=xnkG or""OSrJSV.action=NMeNK4x;return
MAEI(OSrJSV)end
local W=function(l75hVJx4,jZS3,y,i,...)local k=Logic.GetEntityName(GetID(l75hVJx4))assert(k~=nil and k~=
"")local q={}
q.zoom=(i==true and 2400)or 6250;q.angle=(i==true and 40)or 47;q.lookAt={k,100}
q.barStyle="big"q.mc={title=jZS3,text=y,answers={}}local _H={...}
for ka9=1,#_H-1,2 do q.mc.answers[
#q.mc.answers+1]={_H[ka9],_H[ka9+1]}end;return MAEI(q)end;return MAEI,K7,W end
function BundleBriefingSystem.Global:InitalizeBriefingSystem()
DBlau="{@color:70,70,255,255}"Blau="{@color:153,210,234,255}"Weiss="{@color:255,255,255,255}"
Rot="{@color:255,32,32,255}"Gelb="{@color:244,184,0,255}"Gruen="{@color:173,255,47,255}"
Orange="{@color:255,127,0,255}"Mint="{@color:0,255,255,255}"Grau="{@color:180,180,180,255}"
Trans="{@color:0,0,0,0}"
Quest_Loop=function(w)local oQlPB=JobQueue_GetParameter(w)if oQlPB.LoopCallback~=nil then
oQlPB:LoopCallback()end
if oQlPB.State==QuestState.NotTriggered then
local aJpBpxJA=true
for dGu7zk72=1,oQlPB.Triggers[0]do aJpBpxJA=aJpBpxJA and
oQlPB:IsTriggerActive(oQlPB.Triggers[dGu7zk72])end;if aJpBpxJA then oQlPB:SetMsgKeyOverride()
oQlPB:SetIconOverride()oQlPB:Trigger()end elseif oQlPB.State==
QuestState.Active then local aFojxj=true;local Gj=false
for a9sK=1,oQlPB.Objectives[0]do
local Dg=oQlPB:IsObjectiveCompleted(oQlPB.Objectives[a9sK])
if IsBriefingActive()then if
BundleBriefingSystem.Global.Data.QuestsPausedWhileBriefingActive==true then
oQlPB.StartTime=oQlPB.StartTime+1 end end
if oQlPB.Objectives[a9sK].Type==Objective.Deliver and Dg==
nil then if
oQlPB.Objectives[a9sK].Data[4]==nil then
oQlPB.Objectives[a9sK].Data[4]=0 end
if
oQlPB.Objectives[a9sK].Data[3]~=nil then oQlPB.Objectives[a9sK].Data[4]=
oQlPB.Objectives[a9sK].Data[4]+1 end;local s59bbDZx=oQlPB.StartTime;local bdnzXQJ7=oQlPB.Duration
local hF0tRNr=oQlPB.Objectives[a9sK].Data[4]local ha0Zu9=oQlPB.StartTime+oQlPB.Duration-
oQlPB.Objectives[a9sK].Data[4]
if
oQlPB.Duration>0 and
oQlPB.StartTime+oQlPB.Duration+
oQlPB.Objectives[a9sK].Data[4]<Logic.GetTime()then Dg=false end else
if oQlPB.Duration>0 and
oQlPB.StartTime+oQlPB.Duration<Logic.GetTime()then
if
Dg==nil and
(
oQlPB.Objectives[a9sK].Type==Objective.Protect or oQlPB.Objectives[a9sK].Type==
Objective.Dummy or
oQlPB.Objectives[a9sK].Type==Objective.NoChange)then Dg=true elseif Dg==nil or
oQlPB.Objectives[a9sK].Type==Objective.DummyFail then Dg=false end end end;aFojxj=(Dg==true)and aFojxj;Gj=Dg==false or Gj end
if aFojxj then oQlPB:Success()elseif Gj then oQlPB:Fail()end else if oQlPB.IsEventQuest==true then
Logic.ExecuteInLuaLocalState("StopEventMusic(nil, "..
oQlPB.ReceivingPlayer..")")end
if oQlPB.Result==
QuestResult.Success then for SvQa=1,oQlPB.Rewards[0]do
oQlPB:AddReward(oQlPB.Rewards[SvQa])end elseif oQlPB.Result==QuestResult.Failure then for Th9qws=1,oQlPB.Reprisals[0]
do
oQlPB:AddReprisal(oQlPB.Reprisals[Th9qws])end end
if oQlPB.EndCallback~=nil then oQlPB:EndCallback()end;return true end;BundleBriefingSystem:OverwriteGetPosition()end
BriefingSystem={isActive=false,waitList={},isInitialized=false,maxMarkerListEntry=0,currBriefingIndex=0,loadScreenHidden=false}BriefingSystem.BRIEFING_CAMERA_ANGLEDEFAULT=43;BriefingSystem.BRIEFING_CAMERA_ROTATIONDEFAULT=
-45
BriefingSystem.BRIEFING_CAMERA_ZOOMDEFAULT=6250;BriefingSystem.BRIEFING_CAMERA_FOVDEFAULT=42
BriefingSystem.BRIEFING_DLGCAMERA_ANGLEDEFAULT=29;BriefingSystem.BRIEFING_DLGCAMERA_ROTATIONDEFAULT=-45
BriefingSystem.BRIEFING_DLGCAMERA_ZOOMDEFAULT=3400;BriefingSystem.BRIEFING_DLGCAMERA_FOVDEFAULT=25
BriefingSystem.STANDARDTIME_PER_PAGE=1;BriefingSystem.SECONDS_PER_CHAR=0.05
BriefingSystem.COLOR1="{@color:255,250,0,255}"BriefingSystem.COLOR2="{@color:255,255,255,255}"
BriefingSystem.COLOR3="{@color:250,255,0,255}"BriefingSystem.BRIEFING_FLYTIME=0
BriefingSystem.POINTER_HORIZONTAL=1;BriefingSystem.POINTER_VERTICAL=4
BriefingSystem.POINTER_VERTICAL_LOW=5;BriefingSystem.POINTER_VERTICAL_HIGH=6
BriefingSystem.ANIMATED_MARKER=1;BriefingSystem.STATIC_MARKER=2
BriefingSystem.POINTER_PERMANENT_MARKER=6;BriefingSystem.ENTITY_PERMANENT_MARKER=8
BriefingSystem.SIGNAL_MARKER=0;BriefingSystem.ATTACK_MARKER=3;BriefingSystem.CRASH_MARKER=4
BriefingSystem.POINTER_MARKER=5;BriefingSystem.ENTITY_MARKER=7
BriefingSystem.BRIEFING_EXPLORATION_RANGE=6000;BriefingSystem.SKIPMODE_ALL=1;BriefingSystem.SKIPMODE_PERPAGE=2
BriefingSystem.DEFAULT_EXPLORE_ENTITY="XD_Camera"
function API.StartCutscene(h8sS)h8sS.skipPerPage=false
for sAZ9ovaF=1,#h8sS,1 do if h8sS[sAZ9ovaF].mc then
API.Dbg(
"API.StartCutscene: Unallowed multiple choice at page "..sAZ9ovaF.." found!")return end;if
h8sS[sAZ9ovaF].marker then
API.Dbg("API.StartCutscene: Unallowed marker at page "..sAZ9ovaF.." found!")return end;if
h8sS[sAZ9ovaF].pointer then
API.Dbg("API.StartCutscene: Unallowed pointer at page "..sAZ9ovaF.." found!")return end;if
h8sS[sAZ9ovaF].explore then
API.Dbg("API.StartCutscene: Unallowed explore at page "..sAZ9ovaF.." found!")return end end;return BriefingSystem.StartBriefing(h8sS,true)end;BriefingSystem.StartCutscene=API.StartCutscene
StartCutscene=API.StartCutscene
function API.StartBriefing(Mu0szy,NDirmy)NDirmy=NDirmy or false
Logic.ExecuteInLuaLocalState(
[[
            BriefingSystem.Flight.systemEnabled = ]]..tostring(not NDirmy)..[[
        ]])BundleBriefingSystem.Global.Data.BriefingID=
BundleBriefingSystem.Global.Data.BriefingID+1
Mu0szy.UniqueBriefingID=BundleBriefingSystem.Global.Data.BriefingID;if#Mu0szy>0 then
Mu0szy[1].duration=(Mu0szy[1].duration or 0)+0.1 end;if Mu0szy.hideBorderPins then
Logic.ExecuteInLuaLocalState([[Display.SetRenderBorderPins(0)]])end;if Mu0szy.showSky then
Logic.ExecuteInLuaLocalState([[Display.SetRenderSky(1)]])end
Logic.ExecuteInLuaLocalState([[
            Display.SetUserOptionOcclusionEffect(0)
        ]])Mu0szy.finished_Orig_QSB_Briefing=Mu0szy.finished
Mu0szy.finished=function(cDg)if
Mu0szy.hideBorderPins then
Logic.ExecuteInLuaLocalState([[Display.SetRenderBorderPins(1)]])end;if Mu0szy.showSky then
Logic.ExecuteInLuaLocalState([[Display.SetRenderSky(0)]])end
Logic.ExecuteInLuaLocalState([[
                if Options.GetIntValue("Display", "Occlusion", 0) > 0 then
                    Display.SetUserOptionOcclusionEffect(1)
                end
            ]])Mu0szy.finished_Orig_QSB_Briefing(cDg)
BundleBriefingSystem.Global.Data.PlayedBriefings[Mu0szy.UniqueBriefingID]=true end
if BriefingSystem.isActive then
table.insert(BriefingSystem.waitList,Mu0szy)if not BriefingSystem.waitList.Job then
BriefingSystem.waitList.Job=StartSimpleJob("BriefingSystem_WaitForBriefingEnd")end else
BriefingSystem.ExecuteBriefing(Mu0szy)end
return BundleBriefingSystem.Global.Data.BriefingID end;BriefingSystem.StartBriefing=API.StartBriefing
StartBriefing=API.StartBriefing
function BriefingSystem.EndBriefing()BriefingSystem.isActive=false
Logic.SetGlobalInvulnerability(0)local lC=BriefingSystem.currBriefing
BriefingSystem.currBriefing=nil
BriefingSystem[BriefingSystem.currBriefingIndex]=nil
Logic.ExecuteInLuaLocalState("BriefingSystem.EndBriefing()")EndJob(BriefingSystem.job)
if lC.finished then lC:finished()end end
function BriefingSystem_WaitForBriefingEnd()
if
not BriefingSystem.isActive and BriefingSystem.loadScreenHidden then
BriefingSystem.ExecuteBriefing(table.remove(BriefingSystem.waitList),1)if#BriefingSystem.waitList==0 then BriefingSystem.waitList.Job=
nil;return true end end end
function BriefingSystem.ExecuteBriefing(xHEKFkR6)
if not BriefingSystem.isInitialized then
Logic.ExecuteInLuaLocalState("BriefingSystem.InitializeBriefingSystem()")BriefingSystem.isInitialized=true end;BriefingSystem.isActive=true
BriefingSystem.currBriefing=xHEKFkR6
BriefingSystem.currBriefingIndex=BriefingSystem.currBriefingIndex+1
BriefingSystem[BriefingSystem.currBriefingIndex]=xHEKFkR6;BriefingSystem.timer=0;BriefingSystem.page=0
BriefingSystem.skipPlayers={}
BriefingSystem.disableSkipping=BriefingSystem.currBriefing.disableSkipping
BriefingSystem.skipAll=BriefingSystem.currBriefing.skipAll
BriefingSystem.skipPerPage=not BriefingSystem.skipAll and
BriefingSystem.currBriefing.skipPerPage;if not xHEKFkR6.disableGlobalInvulnerability then
Logic.SetGlobalInvulnerability(1)end
Logic.ExecuteInLuaLocalState("BriefingSystem.PrepareBriefing()")
BriefingSystem.currBriefing=BriefingSystem.RemoveObsolateAnswers(BriefingSystem.currBriefing)
BriefingSystem.job=Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,"BriefingSystem_Condition_Briefing","BriefingSystem_Action_Briefing",1)
if not BriefingSystem.loadScreenHidden then
Logic.ExecuteInLuaLocalState("BriefingSystem.Briefing(true)")elseif BriefingSystem_Action_Briefing()then
EndJob(BriefingSystem.job)end end
function BriefingSystem.RemoveObsolateAnswers(dhXuZ)
if dhXuZ then local R=1
while
(dhXuZ[R]~=nil and#dhXuZ>=R)do
if type(dhXuZ[R])=="table"and dhXuZ[R].mc and
dhXuZ[R].mc.answers then local fFZJEmA=1;local H=1
while(
dhXuZ[R].mc.answers[H]~=nil)do if not
dhXuZ[R].mc.answers[H].ID then
dhXuZ[R].mc.answers[H].ID=fFZJEmA end
if
type(dhXuZ[R].mc.answers[H][3])=="function"and
dhXuZ[R].mc.answers[H][3](dhXuZ[R].mc.answers[H])then
Logic.ExecuteInLuaLocalState(
[[
                                local b = BriefingSystem.currBriefing
                                if b and b[]]..
R..
[[] and b[]]..
R..
[[].mc then
                                    table.remove(BriefingSystem.currBriefing[]]..R..
[[].mc.answers, ]]..H..
[[)
                                end
                            ]])table.remove(dhXuZ[R].mc.answers,H)H=H-1 end;fFZJEmA=fFZJEmA+1;H=H+1 end
if#dhXuZ[R].mc.answers==0 then
local dAO1ON3q=Network.GetDesiredLanguage()dhXuZ[R].mc.answers[1]={(dAO1ON3q=="de"and"ENDE")or
"END",999999}end end;R=R+1 end end;return dhXuZ end
function BriefingSystem.IsBriefingActive()return BriefingSystem.isActive end;IsBriefingActive=BriefingSystem.IsBriefingActive
function BriefingSystem_Condition_Briefing()if not
BriefingSystem.loadScreenHidden then return false end;BriefingSystem.timer=
BriefingSystem.timer-0.1
return BriefingSystem.timer<=0 end
function BriefingSystem_Action_Briefing()
BriefingSystem.page=BriefingSystem.page+1;local yruL;if BriefingSystem.currBriefing then
yruL=BriefingSystem.currBriefing[BriefingSystem.page]end
if
not BriefingSystem.skipAll and not BriefingSystem.disableSkipping then
for _h=1,8 do
if
BriefingSystem.skipPlayers[_h]~=BriefingSystem.SKIPMODE_ALL then BriefingSystem.skipPlayers[_h]=
nil
if
type(yruL)=="table"and yruL.skipping==false then
Logic.ExecuteInLuaLocalState("BriefingSystem.EnableBriefingSkipButton(".._h..", false)")else
Logic.ExecuteInLuaLocalState("BriefingSystem.EnableBriefingSkipButton(".._h..", true)")end end end end
if not yruL or yruL==-1 then BriefingSystem.EndBriefing()
return true elseif type(yruL)=="number"and yruL>0 then BriefingSystem.timer=0;BriefingSystem.page=
yruL-1;return end
if yruL.mc then
Logic.ExecuteInLuaLocalState('XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip", 0)')
BriefingSystem.currBriefing[BriefingSystem.page].duration=99999999 else
local wdiG=BriefingSystem.currBriefing[BriefingSystem.page+1]if not BriefingSystem.disableSkipping then
Logic.ExecuteInLuaLocalState('XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip", 1)')end end
BriefingSystem.timer=yruL.duration or BriefingSystem.STANDARDTIME_PER_PAGE
if yruL.explore then yruL.exploreEntities={}
if type(yruL.explore)=="table"then
if#
yruL.explore>0 or yruL.explore.default then
for NozvB4=1,8 do local EsWo=
yruL.explore[player]or yruL.explore.default
if EsWo then
if
type(EsWo)=="table"then
BriefingSystem.CreateExploreEntity(yruL,EsWo.exploration,EsWo.type or
Entities[BriefingSystem.DEFAULT_EXPLORE_ENTITY],NozvB4,EsWo.position)else
BriefingSystem.CreateExploreEntity(yruL,EsWo,Entities[BriefingSystem.DEFAULT_EXPLORE_ENTITY],NozvB4)end end end else
BriefingSystem.CreateExploreEntity(yruL,yruL.explore.exploration,yruL.explore.type or
Entities[BriefingSystem.DEFAULT_EXPLORE_ENTITY],1,yruL.explore.position)end else
BriefingSystem.CreateExploreEntity(yruL,yruL.explore,Entities[BriefingSystem.DEFAULT_EXPLORE_ENTITY],1)end end
if yruL.pointer then local asFvUnHl=yruL.pointer;yruL.pointerList={}
if
type(asFvUnHl)=="table"then if#asFvUnHl>0 then for KlrAY=1,#asFvUnHl do
BriefingSystem.CreatePointer(yruL,asFvUnHl[KlrAY])end else
BriefingSystem.CreatePointer(yruL,asFvUnHl)end else
BriefingSystem.CreatePointer(yruL,{type=asFvUnHl,position=
yruL.position or yruL.followEntity})end end
if yruL.marker then
BriefingSystem.maxMarkerListEntry=BriefingSystem.maxMarkerListEntry+1;yruL.markerList=BriefingSystem.maxMarkerListEntry end
Logic.ExecuteInLuaLocalState("BriefingSystem.Briefing()")
if yruL.action then if yruL.actionArg and#yruL.actionArg>0 then
yruL:action(unpack(yruL.actionArg))else yruL:action()end end end
function BriefingSystem.SkipBriefing(vjAZVaE)
if not BriefingSystem.disableSkipping then
if
BriefingSystem.skipPerPage then BriefingSystem.SkipBriefingPage(vjAZVaE)return end
BriefingSystem.skipPlayers[vjAZVaE]=BriefingSystem.SKIPMODE_ALL
for U=1,8,1 do
if
Logic.PlayerGetIsHumanFlag(U)and BriefingSystem.skipPlayers[U]~=
BriefingSystem.SKIPMODE_ALL then
Logic.ExecuteInLuaLocalState("BriefingSystem.EnableBriefingSkipButton("..vjAZVaE..", false)")return end end;EndJob(BriefingSystem.job)
BriefingSystem.EndBriefing()end end
function BriefingSystem.SkipBriefingPage(be)
if not BriefingSystem.disableSkipping then
if not
BriefingSystem.LastSkipTimeStemp or Logic.GetTimeMs()>
BriefingSystem.LastSkipTimeStemp+500 then
BriefingSystem.LastSkipTimeStemp=Logic.GetTimeMs()if not BriefingSystem.skipPlayers[be]then
BriefingSystem.skipPlayers[be]=BriefingSystem.SKIPMODE_PERPAGE end
for iQ=1,8,1 do
if

Logic.PlayerGetIsHumanFlag(be)and not BriefingSystem.skipPlayers[be]then if BriefingSystem.skipPerPage then
Logic.ExecuteInLuaLocalState("BriefingSystem.EnableBriefingSkipButton("..be..", false)")end;return end end
if BriefingSystem.skipAll then BriefingSystem.SkipBriefing(be)elseif
BriefingSystem_Action_Briefing()then EndJob(BriefingSystem.job)end end end end
function BriefingSystem.CreateExploreEntity(N,l1ntUN,s8KnRD,oV8WT0,I5)local JoujQ=I5 or N.position
if JoujQ then if
type(JoujQ)=="table"and
(JoujQ[oV8WT0]or JoujQ.default or JoujQ.playerPositions)then
JoujQ=JoujQ[oV8WT0]or JoujQ.default end;if JoujQ then
local Yo=type(JoujQ)
if Yo=="string"or Yo=="number"then JoujQ=GetPosition(JoujQ)end end end
if not JoujQ then local MSeJ0yrg=N.followEntity
if type(MSeJ0yrg)=="table"then MSeJ0yrg=
MSeJ0yrg[oV8WT0]or MSeJ0yrg.default end;if MSeJ0yrg then JoujQ=GetPosition(MSeJ0yrg)end end;assert(JoujQ)
local yse=Logic.CreateEntity(s8KnRD,JoujQ.X,JoujQ.Y,0,oV8WT0)assert(yse~=0)
Logic.SetEntityExplorationRange(yse,l1ntUN/100)table.insert(N.exploreEntities,yse)end
function BriefingSystem.CreatePointer(OkS4lXR,qfEPJE)
local hzDd5=qfEPJE.type or BriefingSystem.POINTER_VERTICAL;local h4=qfEPJE.position;assert(h4)
if
hzDd5/BriefingSystem.POINTER_VERTICAL>=1 then local bA6Uh=h4
if type(h4)=="table"then local Nxb
Nxb,bA6Uh=Logic.GetEntitiesInArea(0,h4.X,h4.Y,50,1)else h4=GetPosition(h4)end;local rrP=EGL_Effects.E_Questmarker_low
if
hzDd5 ==BriefingSystem.POINTER_VERTICAL_HIGH then rrP=EGL_Effects.E_Questmarker elseif
hzDd5 ~=BriefingSystem.POINTER_VERTICAL_LOW then
if bA6Uh~=0 then if Logic.IsBuilding(bA6Uh)==1 then
hzDd5=EGL_Effects.E_Questmarker end end end
table.insert(OkS4lXR.pointerList,{id=Logic.CreateEffect(rrP,h4.X,h4.Y,qfEPJE.player or 0),type=hzDd5})else
assert(hzDd5 ==BriefingSystem.POINTER_HORIZONTAL)if type(h4)~="table"then h4=GetPosition(h4)end
table.insert(OkS4lXR.pointerList,{id=Logic.CreateEntityOnUnblockedLand(Entities.E_DirectionMarker,h4.X,h4.Y,
qfEPJE.orientation or 0,qfEPJE.player or 0),type=hzDd5})end end
function BriefingSystem.DestroyPageMarker(Vq,TlC)if Vq.marker then
Logic.ExecuteInLuaLocalState("BriefingSystem.DestroyPageMarker("..Vq.markerList..", "..
TlC..")")end end
function BriefingSystem.RedeployPageMarkers(J5E,e7Kx1)
if J5E.marker then if type(e7Kx1)~="table"then
e7Kx1=GetPosition(e7Kx1)end
Logic.ExecuteInLuaLocalState("BriefingSystem.RedeployMarkerList("..
J5E.markerList..", "..
e7Kx1.X..", "..e7Kx1.Y..")")end end
function BriefingSystem.RedeployPageMarker(SQO,BaaU2A,N83_B)
if SQO.marker then if type(N83_B)~="table"then
N83_B=GetPosition(N83_B)end
Logic.ExecuteInLuaLocalState("BriefingSystem.RedeployMarkerOfList("..SQO.markerList..", "..

BaaU2A..", "..N83_B.X..", "..N83_B.Y..")")end end
function BriefingSystem.RefreshPageMarkers(m)if m.marker then
Logic.ExecuteInLuaLocalState("BriefingSystem.RefreshMarkerList("..
m.markerList..")")end end
function BriefingSystem.RefreshPageMarker(nqL,S_bM)if nqL.marker then
Logic.ExecuteInLuaLocalState("BriefingSystem.RefreshMarkerOfList("..nqL.markerList..", "..
S_bM..")")end end
function BriefingSystem.ResolveBriefingPage(UHC1H)
if UHC1H.explore and UHC1H.exploreEntities then
for M3S,QESegOCr in
ipairs(UHC1H.exploreEntities)do Logic.DestroyEntity(QESegOCr)end;UHC1H.exploreEntities=nil end
if UHC1H.pointer and UHC1H.pointerList then
for qlr,uv_wjj1z in ipairs(UHC1H.pointerList)do
if uv_wjj1z.type~=
BriefingSystem.POINTER_HORIZONTAL then
Logic.DestroyEffect(uv_wjj1z.id)else Logic.DestroyEntity(uv_wjj1z.id)end end;UHC1H.pointerList=nil end
if UHC1H.marker and UHC1H.markerList then
Logic.ExecuteInLuaLocalState("BriefingSystem.DestroyMarkerList("..
UHC1H.markerList..")")UHC1H.markerList=nil end end;ResolveBriefingPage=BriefingSystem.ResolveBriefingPage
function BriefingSystem.OnConfirmed(I,RCiLFzLF,gfMk)
BriefingSystem.timer=0
local QUZel6wC=BriefingSystem.currBriefing[BriefingSystem.page]local h7Bzdymx=BriefingSystem.page;local qJ=RCiLFzLF
local f0T=QUZel6wC.mc.answers[qJ][2]
BriefingSystem.currBriefing[h7Bzdymx].mc.given=I;if type(f0T)=="function"then BriefingSystem.page=
f0T(QUZel6wC.mc.answers[gfMk])-1 else
BriefingSystem.page=f0T-1 end
if

QUZel6wC.mc.answers[qJ]and QUZel6wC.mc.answers[qJ].remove then
table.remove(BriefingSystem.currBriefing[h7Bzdymx].mc.answers,gfMk)
if#
BriefingSystem.currBriefing[h7Bzdymx].mc.answers<gfMk then
BriefingSystem.currBriefing[h7Bzdymx].mc.current=
#
BriefingSystem.currBriefing[h7Bzdymx].mc.answers end
Logic.ExecuteInLuaLocalState([[
                table.remove(BriefingSystem.currBriefing[]]..
h7Bzdymx..
[[].mc.answers, ]]..
gfMk..

[[)
                if #BriefingSystem.currBriefing[]]..
h7Bzdymx..
[[].mc.answers < ]]..
gfMk..
[[ then
                    BriefingSystem.currBriefing[]]..h7Bzdymx..
[[].mc.current = #BriefingSystem.currBriefing[]]..
h7Bzdymx..[[].mc.answers
                end
            ]])end
BriefingSystem.currBriefing=BriefingSystem.RemoveObsolateAnswers(BriefingSystem.currBriefing)end end;function BundleBriefingSystem.Local:Install()
self:InitalizeBriefingSystem()end
function BundleBriefingSystem.Local:InitalizeBriefingSystem()
GameCallback_GUI_SelectionChanged_Orig_QSB_Briefing=GameCallback_GUI_SelectionChanged
GameCallback_GUI_SelectionChanged=function(toGAOHR)
GameCallback_GUI_SelectionChanged_Orig_QSB_Briefing(toGAOHR)if IsBriefingActive()then GUI.ClearSelection()end end;DBlau="{@color:70,70,255,255}"Blau="{@color:153,210,234,255}"
Weiss="{@color:255,255,255,255}"Rot="{@color:255,32,32,255}"Gelb="{@color:244,184,0,255}"
Gruen="{@color:173,255,47,255}"Orange="{@color:255,127,0,255}"Mint="{@color:0,255,255,255}"
Grau="{@color:180,180,180,255}"Trans="{@color:0,0,0,0}"if not InitializeFader then
Script.Load("Script\\MainMenu\\Fader.lua")end
BriefingSystem={listOfMarkers={},markerUniqueID=2^10,Flight={systemEnabled=true},InformationTextQueue={}}
function BriefingSystem.InitializeBriefingSystem()
BriefingSystem.GlobalSystem=Logic.CreateReferenceToTableInGlobaLuaState("BriefingSystem")assert(BriefingSystem.GlobalSystem)if not
BriefingSystem.GlobalSystem.loadScreenHidden then
BriefingSystem.StartLoadScreenSupervising()end
BriefingSystem.GameCallback_Escape=GameCallback_Escape
GameCallback_Escape=function()if not BriefingSystem.IsBriefingActive()then
BriefingSystem.GameCallback_Escape()end end
BriefingSystem.Flight.Job=Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,nil,"ThroneRoomCameraControl",0)end
function BriefingSystem.StartLoadScreenSupervising()
if
not BriefingSystem_LoadScreenSupervising()then
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,nil,"BriefingSystem_LoadScreenSupervising",1)end end
function BriefingSystem_LoadScreenSupervising()
if
XGUIEng.IsWidgetShownEx("/LoadScreen/LoadScreen")==0 then
GUI.SendScriptCommand("BriefingSystem.loadScreenHidden = true;")return true end end
function BriefingSystem.PrepareBriefing()BriefingSystem.barType=nil
BriefingSystem.InformationTextQueue={}
BriefingSystem.currBriefing=BriefingSystem.GlobalSystem[BriefingSystem.GlobalSystem.currBriefingIndex]
Trigger.EnableTrigger(BriefingSystem.Flight.Job)
local Dymt7=XGUIEng.IsWidgetShownEx("/LoadScreen/LoadScreen")==1;if Dymt7 then XGUIEng.PopPage()end
XGUIEng.ShowWidget("/InGame/Root/3dOnScreenDisplay",0)XGUIEng.ShowWidget("/InGame/Root/Normal",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip",
BriefingSystem.GlobalSystem.disableSkipping and 0 or 1)
BriefingSystem.EnableBriefingSkipButton(nil,true)XGUIEng.PushPage("/InGame/ThroneRoomBars",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_2",false)
XGUIEng.PushPage("/InGame/ThroneRoom/Main",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_Dodge",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_2_Dodge",false)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/Frame",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/DialogBG",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/FrameEdges",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogBottomRight3pcs",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/KnightInfoButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Briefing",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/BackButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/TitleContainer",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/StartButton",0)
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Text"," ")
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Title"," ")
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Objectives"," ")local O_={GUI.GetScreenSize()}
local YobIV=350* (O_[2]/1080)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo",1)
XGUIEng.ShowAllSubWidgets("/InGame/ThroneRoom/KnightInfo",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/Text",1)
XGUIEng.PushPage("/InGame/ThroneRoom/KnightInfo",false)
XGUIEng.SetText("/InGame/ThroneRoom/KnightInfo/Text","Horst Hackebeil")
XGUIEng.SetTextColor("/InGame/ThroneRoom/KnightInfo/Text",255,255,255,255)
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/KnightInfo/Text",100,YobIV)local qubB3=BriefingSystem.currBriefing[1]
BriefingSystem.SetBriefingPageOrSplashscreen(qubB3)
BriefingSystem.SetBriefingPageTextPosition(qubB3)if not Framework.IsNetworkGame()and
Game.GameTimeGetFactor()~=0 then
Game.GameTimeSetFactor(GUI.GetPlayerID(),1)end;if
BriefingSystem.currBriefing.restoreCamera then
BriefingSystem.cameraRestore={Camera.RTS_GetLookAtPosition()}end
BriefingSystem.selectedEntities={GUI.GetSelectedEntities()}GUI.ClearSelection()
GUI.ForbidContextSensitiveCommandsInSelectionState()GUI.ActivateCutSceneState()
GUI.SetFeedbackSoundOutputState(0)GUI.EnableBattleSignals(false)Mouse.CursorHide()
Camera.SwitchCameraBehaviour(5)Input.CutsceneMode()InitializeFader()g_Fade.To=0
SetFaderAlpha(0)if Dymt7 then
XGUIEng.PushPage("/LoadScreen/LoadScreen",false)end
if BriefingSystem.currBriefing.hideFoW then
Display.SetRenderFogOfWar(0)GUI.MiniMap_SetRenderFogOfWar(0)end end
function BriefingSystem.EndBriefing()
if BriefingSystem.faderJob then
Trigger.UnrequestTrigger(BriefingSystem.faderJob)BriefingSystem.faderJob=nil end
if BriefingSystem.currBriefing.hideFoW then
Display.SetRenderFogOfWar(1)GUI.MiniMap_SetRenderFogOfWar(1)end;g_Fade.To=0;SetFaderAlpha(0)XGUIEng.PopPage()
Display.UseStandardSettings()Input.GameMode()
local gei0,lO6cBt=Camera.ThroneRoom_GetPosition()Camera.SwitchCameraBehaviour(0)
Camera.RTS_SetLookAtPosition(gei0,lO6cBt)Mouse.CursorShow()GUI.EnableBattleSignals(true)
GUI.SetFeedbackSoundOutputState(1)GUI.ActivateSelectionState()
GUI.PermitContextSensitiveCommandsInSelectionState()
for F9,AGE in ipairs(BriefingSystem.selectedEntities)do if
not Logic.IsEntityDestroyed(AGE)then GUI.SelectEntity(AGE)end end;if BriefingSystem.currBriefing.restoreCamera then
Camera.RTS_SetLookAtPosition(unpack(BriefingSystem.cameraRestore))end;if not
Framework.IsNetworkGame()then
Game.GameTimeSetFactor(GUI.GetPlayerID(),1)end;XGUIEng.PopPage()
XGUIEng.PopPage()XGUIEng.PopPage()XGUIEng.PopPage()
XGUIEng.PopPage()XGUIEng.ShowWidget("/InGame/ThroneRoom",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars",0)XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",0)XGUIEng.ShowWidget("/InGame/Root/Normal",1)
XGUIEng.ShowWidget("/InGame/Root/3dOnScreenDisplay",1)
Trigger.DisableTrigger(BriefingSystem.Flight.Job)BriefingSystem.ConvertInformationToNote()end
function BriefingSystem.Briefing(NlH77co)if not NlH77co then
if BriefingSystem.faderJob then
Trigger.UnrequestTrigger(BriefingSystem.faderJob)BriefingSystem.faderJob=nil end end
local N6XLN=BriefingSystem.currBriefing[
NlH77co and 1 or BriefingSystem.GlobalSystem.page]if not N6XLN then return end;local fBriuMK=N6XLN.barStyle;if fBriuMK==nil then
fBriuMK=BriefingSystem.currBriefing.barStyle end
BriefingSystem.SetBriefingPageOrSplashscreen(N6XLN,fBriuMK)
BriefingSystem.SetBriefingPageTextPosition(N6XLN)local ciY2xwYv=GUI.GetPlayerID()
if N6XLN.text then
local sS6A=N6XLN.duration~=nil
local bzROmd3=(
(fBriuMK=="small"or fBriuMK=="transsmall")and not N6XLN.splashscreen)
if type(N6XLN.text)=="string"then
BriefingSystem.ShowBriefingText(N6XLN.text,sS6A,bzROmd3)elseif N6XLN.text[ciY2xwYv]or N6XLN.text.default then for Pu=1,ciY2xwYv do
if
N6XLN.text[Pu]and Logic.GetIsHumanFlag(Pu)then sS6A=true end end
BriefingSystem.ShowBriefingText(
N6XLN.text[ciY2xwYv]or N6XLN.text.default,sS6A,bzROmd3)end end
if N6XLN.title then
if type(N6XLN.title)=="string"then
BriefingSystem.ShowBriefingTitle(N6XLN.title)elseif N6XLN.title[ciY2xwYv]or N6XLN.title.default then
BriefingSystem.ShowBriefingTitle(
N6XLN.title[ciY2xwYv]or N6XLN.title.default)end end
if N6XLN.mc then BriefingSystem.Briefing_MultipleChoice()end;local vVP3Z4qc,VYx
if type(N6XLN.splashscreen)=="table"then if
N6XLN.splashscreen.uv then
vVP3Z4qc={N6XLN.splashscreen.uv[1],N6XLN.splashscreen.uv[2]}
VYx={N6XLN.splashscreen.uv[3],N6XLN.splashscreen.uv[4]}end end
if not NlH77co then
if N6XLN.faderAlpha then
if type(N6XLN.faderAlpha)=="table"then
g_Fade.To=
N6XLN.faderAlpha[ciY2xwYv]or N6XLN.faderAlpha.default or 0 else g_Fade.To=N6XLN.faderAlpha end;g_Fade.Duration=0 end
if N6XLN.fadeIn then local TWz1hOn=N6XLN.fadeIn
if type(TWz1hOn)=="table"then TWz1hOn=
TWz1hOn[ciY2xwYv]or TWz1hOn.default end
if type(TWz1hOn)~="number"then TWz1hOn=N6XLN.duration;if not TWz1hOn then
TWz1hOn=BriefingSystem.timer end end
if TWz1hOn<0 then
BriefingSystem.faderJob=Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,nil,"BriefingSystem_CheckFader",1,{},{1,math.abs(fadeOut)})else FadeIn(TWz1hOn)end end
if N6XLN.fadeOut then local O4p95NnC=N6XLN.fadeOut
if type(O4p95NnC)=="table"then O4p95NnC=
O4p95NnC[ciY2xwYv]or O4p95NnC.default end
if type(O4p95NnC)~="number"then O4p95NnC=N6XLN.duration;if not O4p95NnC then
O4p95NnC=BriefingSystem.timer end end
if O4p95NnC<0 then
BriefingSystem.faderJob=Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,nil,"BriefingSystem_CheckFader",1,{},{0,math.abs(O4p95NnC)})else FadeOut(O4p95NnC)end end else
local yuuiHp=
(N6XLN.fadeOut and 0)or(N6XLN.fadeIn and 1)or N6XLN.faderValue;if yuuiHp then g_Fade.To=yuuiHp;g_Fade.Duration=0 end end;local hpICYhx=N6XLN.dialogCamera;if type(hpICYhx)=="table"then
hpICYhx=hpICYhx[ciY2xwYv]
if hpICYhx==nil then hpICYhx=N6XLN.dialogCamera.default end end;hpICYhx=
hpICYhx and"DLG"or""
local Zh4ky=N6XLN.rotation or
BriefingSystem.GlobalSystem["BRIEFING_"..hpICYhx..
"CAMERA_ROTATIONDEFAULT"]if type(Zh4ky)=="table"then
Zh4ky=Zh4ky[ciY2xwYv]or Zh4ky.default end
local i=N6XLN.angle or BriefingSystem.GlobalSystem["BRIEFING_"..hpICYhx..
"CAMERA_ANGLEDEFAULT"]
if type(i)=="table"then i=i[ciY2xwYv]or i.default end
local y8iv=N6XLN.zoom or
BriefingSystem.GlobalSystem["BRIEFING_"..hpICYhx.."CAMERA_ZOOMDEFAULT"]if type(y8iv)=="table"then
y8iv=y8iv[ciY2xwYv]or y8iv.default end
local YTQ_=N6XLN.FOV or BriefingSystem.GlobalSystem["BRIEFING_"..hpICYhx..
"CAMERA_FOVDEFAULT"]BriefingSystem.CutsceneStopFlight()
BriefingSystem.StopFlight()
if N6XLN.view then if BriefingSystem.GlobalSystem.page==1 then
BriefingSystem.CutsceneSaveFlight(N6XLN.view.Position,N6XLN.view.LookAt,YTQ_)end
BriefingSystem.CutsceneFlyTo(N6XLN.view.Position,N6XLN.view.LookAt,YTQ_,
N6XLN.flyTime or 0)elseif N6XLN.position then local p=N6XLN.position
if
type(p)=="table"and(p[ciY2xwYv]or p.default or
p.playerPositions)then p=p[ciY2xwYv]or p.default end
if p then local DHwTC=type(p)
if DHwTC=="string"or DHwTC=="number"then
p=GetPosition(p)elseif DHwTC=="table"then p={X=p.X,Y=p.Y,Z=p.Z}end
local D=p.Z or Display.GetTerrainHeight(p.X,p.Y)if N6XLN.zOffset then D=D+N6XLN.zOffset end;p.Z=D
Display.SetCameraLookAtEntity(0)if BriefingSystem.GlobalSystem.page==1 then
BriefingSystem.SaveFlight(p,Zh4ky,i,y8iv,YTQ_,vVP3Z4qc,VYx)end
BriefingSystem.FlyTo(p,Zh4ky,i,y8iv,YTQ_,
N6XLN.flyTime or BriefingSystem.GlobalSystem.BRIEFING_FLYTIME,vVP3Z4qc,VYx)end elseif N6XLN.followEntity then local R=N6XLN.followEntity;if type(R)=="table"then
R=R[ciY2xwYv]or R.default end;R=GetEntityId(R)
Display.SetCameraLookAtEntity(R)local k3=GetPosition(R)k3.Z=k3.Z or nil
local x=Display.GetTerrainHeight(k3.X,k3.Y)if N6XLN.zOffset then x=x+N6XLN.zOffset end;k3.Z=x;if
BriefingSystem.GlobalSystem.page==1 then
BriefingSystem.SaveFlight(k3,Zh4ky,i,y8iv,YTQ_,vVP3Z4qc,VYx)end
BriefingSystem.FollowFlight(R,Zh4ky,i,y8iv,YTQ_,
N6XLN.flyTime or 0,x,vVP3Z4qc,VYx)end
if not NlH77co then
if N6XLN.marker then local fYsm=N6XLN.marker
if type(fYsm)=="table"then
if#fYsm>0 then
for c,Co6Pnt in
ipairs(fYsm)do
if
not Co6Pnt.player or Co6Pnt.player==GUI.GetPlayerID()then
BriefingSystem.CreateMarker(Co6Pnt,Co6Pnt.type,N6XLN.markerList,Co6Pnt.display,Co6Pnt.R,Co6Pnt.G,Co6Pnt.B,Co6Pnt.Alpha)else
table.insert(BriefingSystem.listOfMarkers[N6XLN.markerList],{})end end else
if not v.player or v.player==GUI.GetPlayerID()then
BriefingSystem.CreateMarker(fYsm,fYsm.type,N6XLN.markerList,fYsm.display,fYsm.R,fYsm.G,fYsm.B,fYsm.Alpha)else
table.insert(BriefingSystem.listOfMarkers[N6XLN.markerList],{})end end else
BriefingSystem.CreateMarker(N6XLN,fYsm,N6XLN.markerList)end end end end
function OnSkipButtonPressed()local sxBUAww=BriefingSystem.GlobalSystem.page
if
BriefingSystem.currBriefing[sxBUAww]and
not BriefingSystem.currBriefing[sxBUAww].mc then
GUI.SendScriptCommand("BriefingSystem.SkipBriefing("..
GUI.GetPlayerID()..")")end end
function BriefingSystem.SkipBriefingPage()
local CyyGa=BriefingSystem.GlobalSystem.page
if BriefingSystem.currBriefing[CyyGa]and not
BriefingSystem.currBriefing[CyyGa].mc then
GUI.SendScriptCommand(
"BriefingSystem.SkipBriefingPage("..GUI.GetPlayerID()..")")end end
function BriefingSystem.ShowBriefingBar(Z)Z=Z or"big"if Z==nil then
Z=BriefingSystem.currBriefing.barStyle end
assert(
Z=='big'or Z=='small'or Z=='nobar'or Z=='transbig'or Z=='transsmall')
local si=(Z=="big"or Z=="transbig")and 1 or 0
local vVn4vww=(Z=="small"or Z=="transsmall")and 1 or 0;local lGSMU=
(Z=="transsmall"or Z=="transbig")and 100 or 255;if Z=='nobar'then vVn4vww=0
si=0 end
XGUIEng.ShowWidget("/InGame/ThroneRoomBars",si)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",vVn4vww)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",si)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",vVn4vww)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars/BarBottom",1,lGSMU)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars/BarTop",1,lGSMU)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars_2/BarBottom",1,lGSMU)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars_2/BarTop",1,lGSMU)BriefingSystem.barType=Z end
function BriefingSystem.ShowBriefingText(vDYDgya,I71BEfil,t6BK)
local laNN7pb=XGUIEng.GetStringTableText(vDYDgya)if laNN7pb==""then laNN7pb=vDYDgya end
if not I71BEfil then
GUI.SendScriptCommand(
"BriefingSystem.timer = "..
(BriefingSystem.GlobalSystem.STANDARDTIME_PER_PAGE+
BriefingSystem.GlobalSystem.SECONDS_PER_CHAR*string.len(laNN7pb))..";")end;if t6BK then laNN7pb="{cr}{cr}{cr}"..laNN7pb end
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/MissionBriefing/Text",1)
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Text","{center}"..laNN7pb)end
function BriefingSystem.ShowBriefingTitle(EoHp)
local hReWRM3q=XGUIEng.GetStringTableText(EoHp)if hReWRM3q==""then hReWRM3q=EoHp end
if BriefingSystem.GlobalSystem and
string.sub(hReWRM3q,1,1)~="{"then
hReWRM3q=
BriefingSystem.GlobalSystem.COLOR1 .."{center}{darkshadow}"..hReWRM3q end
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",1)
XGUIEng.SetText("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",hReWRM3q)end
function BriefingSystem.SchowBriefingAnswers(B7WIX)local nkgL={GUI.GetScreenSize()}
local J="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"
BriefingSystem.OriginalBoxPosition={XGUIEng.GetWidgetScreenPosition(J)}local lkr=XGUIEng.GetWidgetID(J.."/ListBox")
XGUIEng.ListBoxPopAll(lkr)
for YwRtEabC=1,B7WIX.mc.amount,1 do if B7WIX.mc.answers[YwRtEabC]then
XGUIEng.ListBoxPushItem(lkr,B7WIX.mc.answers[YwRtEabC][1])end end;XGUIEng.ListBoxSetSelectedIndex(lkr,0)
local JWhvws={XGUIEng.GetWidgetScreenSize(J)}local DxgC=(nkgL[1]/1920)local O=math.ceil((nkgL[1]/2)-
(JWhvws[1]/2))local x=math.ceil(nkgL[2]- (JWhvws[2]-
20))
XGUIEng.SetWidgetScreenPosition(J,O,x)XGUIEng.PushPage(J,false)
XGUIEng.ShowWidget(J,1)BriefingSystem.MCSelectionIsShown=true end
function BriefingSystem.ShowInformationText()
XGUIEng.SetText("/InGame/ThroneRoom/KnightInfo/Text","")local hjX7=""for v9rW=1,#BriefingSystem.InformationTextQueue do
hjX7=hjX7 ..
BriefingSystem.InformationTextQueue[v9rW][1].."{cr}"end
XGUIEng.SetText("/InGame/ThroneRoom/KnightInfo/Text",hjX7)end
function BriefingSystem.ConvertInformationToNote()for ha9Bwjaj=1,#BriefingSystem.InformationTextQueue do
GUI.AddNote(BriefingSystem.InformationTextQueue[ha9Bwjaj][1])end end
function BriefingSystem.PushInformationText(kanlP,x)
local P2iXC=x or(string.len(kanlP)*5)
table.insert(BriefingSystem.InformationTextQueue,{kanlP,P2iXC})end
function BriefingSystem.UnqueueInformationText(ILREJu)if
#BriefingSystem.InformationTextQueue>=ILREJu then
table.remove(BriefingSystem.InformationTextQueue,ILREJu)end end
function BriefingSystem.ControlInformationText()local E={}
for V0bDjtn,J in
pairs(BriefingSystem.InformationTextQueue)do BriefingSystem.InformationTextQueue[V0bDjtn][2]=
J[2]-1
if J[2]<=0 then table.insert(E,V0bDjtn)end end;for w,p0x2pj in pairs(E)do
BriefingSystem.UnqueueInformationText(p0x2pj)end
BriefingSystem.ShowInformationText()end
function BriefingSystem.Briefing_MultipleChoice()
local X7iiGlpy=BriefingSystem.currBriefing[BriefingSystem.GlobalSystem.page]
if X7iiGlpy and X7iiGlpy.mc then if X7iiGlpy.mc.title then
BriefingSystem.ShowBriefingTitle(X7iiGlpy.mc.title)end;if X7iiGlpy.mc.text then
BriefingSystem.ShowBriefingText(X7iiGlpy.mc.text,true)end;if X7iiGlpy.mc.answers then
BriefingSystem.SchowBriefingAnswers(X7iiGlpy)end
GUI.SendScriptCommand("BriefingSystem.currBriefing[BriefingSystem.page].dusation = 999999")end end
function BriefingSystem.OnConfirmed()
local YuuBu="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"local JInBq=BriefingSystem.OriginalBoxPosition
XGUIEng.SetWidgetScreenPosition(YuuBu,JInBq[1],JInBq[2])XGUIEng.ShowWidget(YuuBu,0)XGUIEng.PopPage()
local xoopiLqU=BriefingSystem.currBriefing[BriefingSystem.GlobalSystem.page]
if xoopiLqU.mc then local c01CiT6=BriefingSystem.GlobalSystem.page
local TEaUp=XGUIEng.ListBoxGetSelectedIndex(
YuuBu.."/ListBox")+1
BriefingSystem.currBriefing[c01CiT6].mc.current=TEaUp
local T2fzd=BriefingSystem.currBriefing[c01CiT6].mc.current
local Wo=BriefingSystem.currBriefing[c01CiT6].mc.answers[T2fzd].ID
GUI.SendScriptCommand([[BriefingSystem.OnConfirmed(]]..Wo..[[,]]..
xoopiLqU.mc.current..[[,]]..T2fzd..[[)]])end end
function BriefingSystem.CreateMarker(vUtGN4,KaX,U,z0,nWf3lxy,NGIM,XXYvnZ)local Ofeq9l=vUtGN4.position
if Ofeq9l then
if type(Ofeq9l)=="table"then if

Ofeq9l[GUI.GetPlayerID()]or Ofeq9l.default or Ofeq9l.playerPositions then
Ofeq9l=Ofeq9l[GUI.GetPlayerID()]or Ofeq9l.default end end end;if not Ofeq9l then Ofeq9l=vUtGN4.followEntity
if type(Ofeq9l)=="table"then Ofeq9l=
Ofeq9l[GUI.GetPlayerID()]or Ofeq9l.default end end
assert(Ofeq9l)
if type(Ofeq9l)~="table"then Ofeq9l=GetPosition(Ofeq9l)end
if
U and not BriefingSystem.listOfMarkers[U]then BriefingSystem.listOfMarkers[U]={}end;while
GUI.IsMinimapSignalExisting(BriefingSystem.markerUniqueID)==1 do
BriefingSystem.markerUniqueID=BriefingSystem.markerUniqueID+1 end;assert(
type(KaX)=="number"and KaX>0)
z0=z0 or 32;nWf3lxy=nWf3lxy or 245;NGIM=NGIM or 110;XXYvnZ=XXYvnZ or 255
GUI.CreateMinimapSignalRGBA(BriefingSystem.markerUniqueID,Ofeq9l.X,Ofeq9l.Y,z0,nWf3lxy,NGIM,XXYvnZ,KaX)
if U then
table.insert(BriefingSystem.listOfMarkers[U],{ID=BriefingSystem.markerUniqueID,X=Ofeq9l.X,Y=Ofeq9l.Y,R=z0,G=nWf3lxy,B=NGIM,Alpha=XXYvnZ,type=KaX})end
BriefingSystem.markerUniqueID=BriefingSystem.markerUniqueID+1 end
function BriefingSystem.DestroyMarkerList(Mbrvptw)
if BriefingSystem.listOfMarkers[Mbrvptw]then
for N,OioSf8pX in
ipairs(BriefingSystem.listOfMarkers[Mbrvptw])do if OioSf8pX.ID and
GUI.IsMinimapSignalExisting(OioSf8pX.ID)==1 then
GUI.DestroyMinimapSignal(OioSf8pX.ID)end end;BriefingSystem.listOfMarkers[Mbrvptw]=nil end end
function BriefingSystem.DestroyMarkerOfList(HUU7Kn,yFlLsq)
if BriefingSystem.listOfMarkers[HUU7Kn]then
local TD=BriefingSystem.listOfMarkers[HUU7Kn][yFlLsq]
if
TD and TD.ID and GUI.IsMinimapSignalExisting(TD.ID)==1 then GUI.DestroyMinimapSignal(TD.ID)TD.ID=nil end end end
function BriefingSystem.RedeployMarkerList(ohUzbR,FG4,HGlwCdN)
if BriefingSystem.listOfMarkers[ohUzbR]then
for u0Cs,tN0zoS in
ipairs(BriefingSystem.listOfMarkers[ohUzbR])do
if tN0zoS.ID then tN0zoS.X=FG4;tN0zoS.Y=HGlwCdN
if
GUI.IsMinimapSignalExisting(tN0zoS.ID)==1 then
GUI.RedeployMinimapSignal(tN0zoS.ID,FG4,HGlwCdN)else
GUI.CreateMinimapSignalRGBA(tN0zoS.ID,FG4,HGlwCdN,tN0zoS.R,tN0zoS.G,tN0zoS.B,tN0zoS.Alpha,tN0zoS.type)end end end end end
function BriefingSystem.RedeployMarkerOfList(Zn,MloA5bTF,tbQ,oNJ7)
if BriefingSystem.listOfMarkers[Zn]then
local Zg7GW=BriefingSystem.listOfMarkers[Zn][MloA5bTF]
if Zg7GW and Zg7GW.ID then Zg7GW.X=tbQ;Zg7GW.Y=oNJ7
if
GUI.IsMinimapSignalExisting(Zg7GW.ID)==1 then
GUI.RedeployMinimapSignal(Zg7GW.ID,tbQ,oNJ7)else
GUI.CreateMinimapSignalRGBA(Zg7GW.ID,tbQ,oNJ7,Zg7GW.R,Zg7GW.G,Zg7GW.B,Zg7GW.Alpha,Zg7GW.type)end end end end
function BriefingSystem.RefreshMarkerList(blUXv5ns)
if BriefingSystem.listOfMarkers[blUXv5ns]then
for q1M,IhaFMz22 in
ipairs(BriefingSystem.listOfMarkers[blUXv5ns])do
if IhaFMz22.ID then
if
GUI.IsMinimapSignalExisting(IhaFMz22.ID)==1 then
GUI.RedeployMinimapSignal(IhaFMz22.ID,IhaFMz22.X,IhaFMz22.Y)else
GUI.CreateMinimapSignalRGBA(IhaFMz22.ID,IhaFMz22.X,IhaFMz22.Y,IhaFMz22.R,IhaFMz22.G,IhaFMz22.B,IhaFMz22.Alpha,IhaFMz22.type)end end end end end
function BriefingSystem.RefreshMarkerOfList(Yn,Mwq8rV)
if BriefingSystem.listOfMarkers[Yn]then
local v=BriefingSystem.listOfMarkers[Yn][Mwq8rV]
if v and v.ID then
if GUI.IsMinimapSignalExisting(v.ID)==1 then
GUI.RedeployMinimapSignal(v.ID,v.X,v.Y)else
GUI.CreateMinimapSignalRGBA(v.ID,v.X,v.Y,v.R,v.G,v.B,v.Alpha,v.type)end end end end
function BriefingSystem.EnableBriefingSkipButton(Nm,Z)if
Nm==nil or Nm==GUI.GetPlayerID()then
XGUIEng.DisableButton("/InGame/ThroneRoom/Main/Skip",Z and 0 or 1)end end
function BriefingSystem_CheckFader(wMVKiK4,DL8BA)
if BriefingSystem.GlobalSystem.timer<DL8BA then if wMVKiK4 ==
1 then FadeIn(DL8BA)else FadeOut(DL8BA)end;BriefingSystem.faderJob=
nil;return true end end
function ThroneRoomCameraControl()
if Camera.GetCameraBehaviour(5)==5 then
local R9iF=BriefingSystem.Flight
if R9iF.systemEnabled then local CS3ZU6vC=R9iF.StartTime;local hN=R9iF.FlyTime
local G=R9iF.StartPosition or R9iF.EndPosition;local fKZ5Ao=R9iF.EndPosition
local Cyvh=R9iF.StartRotation or R9iF.EndRotation;local rjU=R9iF.EndRotation
local q=R9iF.StartZoomAngle or R9iF.EndZoomAngle;local R4Bv_P=R9iF.EndZoomAngle
local YLt1L=R9iF.StartZoomDistance or R9iF.EndZoomDistance;local GllN=R9iF.EndZoomDistance
local hb=R9iF.StartFOV or R9iF.EndFOV;local Ap_D1w=R9iF.EndFOV;local JeB=R9iF.StartUV0 or R9iF.EndUV0
local Qcb=R9iF.EndUV0;local P3cFBkug=R9iF.StartUV1 or R9iF.EndUV1;local R=R9iF.EndUV1;local SmVH=
Logic.GetTimeMs()/1000;local Wm1DfLu0=math
if R9iF.Follow then
local sW9j=GetPosition(R9iF.Follow)if fKZ5Ao.X~=sW9j.X and fKZ5Ao.Y~=sW9j.Y then
R9iF.StartPosition=fKZ5Ao;R9iF.EndPosition=sW9j end
if

R9iF.StartPosition and Logic.IsEntityMoving(GetEntityId(R9iF.Follow))then
local Hnpk=Wm1DfLu0.rad(Logic.GetEntityOrientation(GetEntityId(R9iF.Follow)))
local z,MQ,Z3J,N75e=R9iF.StartPosition.X,R9iF.StartPosition.Y,sW9j.X,sW9j.Y;z=z-Z3J;MQ=MQ-N75e
local JJay=Wm1DfLu0.sqrt(z*z+MQ*MQ)*10;local ZXn_LqI=JJay* (hN-SmVH+CS3ZU6vC)local pd=JJay*
(SmVH+CS3ZU6vC)
fKZ5Ao={X=sW9j.X+Wm1DfLu0.cos(Hnpk)*JJay,Y=
sW9j.Y+Wm1DfLu0.sin(Hnpk)*JJay}R9iF.FollowTemp=R9iF.FollowTemp or{}
local GkKzIokN=BriefingSystem.InterpolationFactor(SmVH,SmVH,1,R9iF.FollowTemp)
z,MQ,z1=BriefingSystem.GetCameraPosition(sW9j,fKZ5Ao,GkKzIokN)G={X=z,Y=MQ,Z=z1}else G=sW9j end;fKZ5Ao=G end
local hQUgbKod=BriefingSystem.InterpolationFactor(CS3ZU6vC,SmVH,hN,R9iF)
local WRhJsaV,vA,GDJG=BriefingSystem.GetCameraPosition(G,fKZ5Ao,hQUgbKod)local E3C9=YLt1L+ (GllN-YLt1L)*hQUgbKod;local x=q+
(R4Bv_P-q)*hQUgbKod
local zSudeRVt=Cyvh+ (rjU-Cyvh)*hQUgbKod
local sUYU=E3C9*Wm1DfLu0.cos(Wm1DfLu0.rad(x))Camera.ThroneRoom_SetLookAt(WRhJsaV,vA,GDJG)
Camera.ThroneRoom_SetPosition(
WRhJsaV+
Wm1DfLu0.cos(Wm1DfLu0.rad(zSudeRVt-90))*sUYU,vA+
Wm1DfLu0.sin(Wm1DfLu0.rad(zSudeRVt-90))*sUYU,GDJG+ (E3C9)*
Wm1DfLu0.sin(Wm1DfLu0.rad(x)))
Camera.ThroneRoom_SetFOV(hb+ (Ap_D1w-hb)*hQUgbKod)
BriefingSystem.SetBriefingSplashscreenUV(JeB,Qcb,P3cFBkug,R,hQUgbKod)else local QC6wgXaV=BriefingSystem.Flight.Cutscene
if QC6wgXaV then local s=QC6wgXaV.StartPosition or
QC6wgXaV.EndPosition
local O2=QC6wgXaV.EndPosition;local _KUY=QC6wgXaV.StartLookAt or QC6wgXaV.EndLookAt
local qVltI1D=QC6wgXaV.EndLookAt;local Dbhq=QC6wgXaV.StartFOV or QC6wgXaV.EndFOV
local gCDkf47y=QC6wgXaV.EndFOV;local n=QC6wgXaV.StartTime;local iUTUFAj=QC6wgXaV.FlyTime
local _SrhE=Logic.GetTimeMs()/1000;local pery2Ge=QC6wgXaV.StartUV0 or QC6wgXaV.EndUV0
local SR3C=QC6wgXaV.EndUV0;local QLI=QC6wgXaV.StartUV1 or QC6wgXaV.EndUV1
local Q=QC6wgXaV.EndUV1
local S=BriefingSystem.InterpolationFactor(n,_SrhE,iUTUFAj,QC6wgXaV)
if not _KUY.X then
local Jmwk=GetPosition(_KUY[1],(_KUY[2]or 0))
if _KUY[3]then Jmwk.X=Jmwk.X+
_KUY[3]*math.cos(math.rad(_KUY[4]))Jmwk.Y=Jmwk.Y+_KUY[3]*
math.sin(math.rad(_KUY[4]))end;_KUY=Jmwk end
if not qVltI1D.X then
local cWOtw3=GetPosition(qVltI1D[1],(qVltI1D[2]or 0))
if qVltI1D[3]then
cWOtw3.X=cWOtw3.X+qVltI1D[3]*
math.cos(math.rad(qVltI1D[4]))cWOtw3.Y=cWOtw3.Y+
qVltI1D[3]*math.sin(math.rad(qVltI1D[4]))end;qVltI1D=cWOtw3 end
local SG_q,g,cRpJ=BriefingSystem.CutsceneGetPosition(_KUY,qVltI1D,S)Camera.ThroneRoom_SetLookAt(SG_q,g,cRpJ)
if not s.X then local qKp=GetPosition(s[1],(
s[2]or 0))
if s[3]then qKp.X=qKp.X+s[3]*
math.cos(math.rad(s[4]))qKp.Y=qKp.Y+s[3]*
math.sin(math.rad(s[4]))end;s=qKp end
if not O2.X then local cR5Lq=GetPosition(O2[1],(O2[2]or 0))if O2[3]then
cR5Lq.X=
cR5Lq.X+O2[3]*math.cos(math.rad(O2[4]))
cR5Lq.Y=cR5Lq.Y+O2[3]*math.sin(math.rad(O2[4]))end;O2=cR5Lq end
local q,gHF,tJeWJm=BriefingSystem.CutsceneGetPosition(s,O2,S)Camera.ThroneRoom_SetPosition(q,gHF,tJeWJm)
Camera.ThroneRoom_SetFOV(
Dbhq+ (gCDkf47y-Dbhq)*S)
BriefingSystem.SetBriefingSplashscreenUV(pery2Ge,SR3C,QLI,Q,factor)end end;BriefingSystem.ControlInformationText()
if
BriefingSystem.MCSelectionIsShown then
local OQ1ve="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"
if XGUIEng.IsWidgetShown(OQ1ve)==0 then
BriefingSystem.MCSelectionIsShown=false;BriefingSystem.OnConfirmed()end end end end;function ThroneRoomLeftClick()end
function BriefingSystem.CutsceneGetPosition(x,Gq,TW9LRI)local fQKm=x.X+
(Gq.X-x.X)*TW9LRI
local Ha_4jOX=x.Y+ (Gq.Y-x.Y)*TW9LRI;local fXhqvy=x.Z+ (Gq.Z-x.Z)*TW9LRI
return fQKm,Ha_4jOX,fXhqvy end
function BriefingSystem.CutsceneSaveFlight(N,kOC5Ih9G,CGsL,w0Cqj,MMITWi)BriefingSystem.Flight.Cutscene=
BriefingSystem.Flight.Cutscene or{}
BriefingSystem.Flight.Cutscene.StartPosition=N
BriefingSystem.Flight.Cutscene.StartLookAt=kOC5Ih9G
BriefingSystem.Flight.Cutscene.StartFOV=CGsL
BriefingSystem.Flight.Cutscene.StartTime=Logic.GetTimeMs()/1000;BriefingSystem.Flight.Cutscene.FlyTime=0
BriefingSystem.Flight.Cutscene.StartUV0=w0Cqj
BriefingSystem.Flight.Cutscene.StartUV1=MMITWi end
function BriefingSystem.CutsceneFlyTo(a04G3,WnPDv,XGhZi,IutJO8Q,e,Tj6Uj)BriefingSystem.Flight.Cutscene=
BriefingSystem.Flight.Cutscene or{}BriefingSystem.Flight.Cutscene.StartTime=
Logic.GetTimeMs()/1000
BriefingSystem.Flight.Cutscene.FlyTime=IutJO8Q
BriefingSystem.Flight.Cutscene.EndPosition=a04G3
BriefingSystem.Flight.Cutscene.EndLookAt=WnPDv;BriefingSystem.Flight.Cutscene.EndFOV=XGhZi
BriefingSystem.Flight.Cutscene.EndUV0=e;BriefingSystem.Flight.Cutscene.EndUV1=Tj6Uj end
function BriefingSystem.CutsceneStopFlight()BriefingSystem.Flight.Cutscene=
BriefingSystem.Flight.Cutscene or{}
BriefingSystem.Flight.Cutscene.StartPosition=BriefingSystem.Flight.Cutscene.EndPosition
BriefingSystem.Flight.Cutscene.StartLookAt=BriefingSystem.Flight.Cutscene.EndLookAt
BriefingSystem.Flight.Cutscene.StartFOV=BriefingSystem.Flight.Cutscene.EndFOV end
function BriefingSystem.InterpolationFactor(sy1,vQU,TzXQ,WP2BgOu)local uR=1
if sy1+TzXQ>vQU then uR=(vQU-sy1)/TzXQ
if
WP2BgOu and vQU==WP2BgOu.TempLastLogicTime then
uR=uR+
(
Framework.GetTimeMs()-WP2BgOu.TempLastFrameworkTime)/TzXQ/1000*
Game.GameTimeGetFactor(GUI.GetPlayerID())else WP2BgOu.TempLastLogicTime=vQU
WP2BgOu.TempLastFrameworkTime=Framework.GetTimeMs()end end;if uR>1 then uR=1 end;return uR end
function BriefingSystem.GetCameraPosition(lj,Jz,vRq_8x1T)
local sn=lj.X+ (Jz.X-lj.X)*vRq_8x1T;local I_9=lj.Y+ (Jz.Y-lj.Y)*vRq_8x1T;local CCEm1g
if lj.Z or
Jz.Z then
CCEm1g=
(lj.Z or Display.GetTerrainHeight(lj.X,lj.Y))+
(
(Jz.Z or Display.GetTerrainHeight(Jz.X,Jz.Y))-
(lj.Z or Display.GetTerrainHeight(lj.X,lj.Y)))*vRq_8x1T else
CCEm1g=
Display.GetTerrainHeight(sn,I_9)* ((lj.ZRelative or 1)+
(
(Jz.ZRelative or 1)- (lj.ZRelative or 1))*vRq_8x1T)+
((lj.ZAdd or 0)+
((Jz.ZAdd or 0)- (lj.ZAdd or 0)))*vRq_8x1T end;return sn,I_9,CCEm1g end
function BriefingSystem.SaveFlight(mCSugCGp,K0A,FQXoHI,l7d4,i,n2kq,fjLl8iOL)
BriefingSystem.Flight.StartZoomAngle=FQXoHI;BriefingSystem.Flight.StartZoomDistance=l7d4
BriefingSystem.Flight.StartRotation=K0A;BriefingSystem.Flight.StartPosition=mCSugCGp
BriefingSystem.Flight.StartFOV=i;BriefingSystem.Flight.StartUV0=n2kq
BriefingSystem.Flight.StartUV1=fjLl8iOL end
function BriefingSystem.FlyTo(se,TrMqziU,SvII,f,tf0qkj,jl,F2T,BPZ)local fzyYm=BriefingSystem.Flight;fzyYm.StartTime=
Logic.GetTimeMs()/1000;fzyYm.FlyTime=jl;fzyYm.EndPosition=se
fzyYm.EndRotation=TrMqziU;fzyYm.EndZoomAngle=SvII;fzyYm.EndZoomDistance=f;fzyYm.EndFOV=tf0qkj
fzyYm.EndUV0=F2T;fzyYm.EndUV1=BPZ end
function BriefingSystem.StopFlight()local jk_dB=BriefingSystem.Flight
jk_dB.StartZoomAngle=jk_dB.EndZoomAngle;jk_dB.StartZoomDistance=jk_dB.EndZoomDistance
jk_dB.StartRotation=jk_dB.EndRotation;jk_dB.StartPosition=jk_dB.EndPosition;jk_dB.StartFOV=jk_dB.EndFOV
jk_dB.StartUV0=jk_dB.EndUV0;jk_dB.StartUV1=jk_dB.EndUV1;if jk_dB.Follow then
jk_dB.StartPosition=GetPosition(jk_dB.Follow)jk_dB.Follow=nil end end
function BriefingSystem.FollowFlight(cW,te,OSCwwfL,q,uMMGO4,Jj2oei5V,f6WMU3lw,J,TuSFS)local yMxua=GetPosition(cW)
yMxua.Z=f6WMU3lw or 0
BriefingSystem.FlyTo(yMxua,te,OSCwwfL,q,uMMGO4,Jj2oei5V,J,TuSFS)BriefingSystem.Flight.StartPosition=nil
BriefingSystem.Flight.Follow=cW end;function BriefingSystem.IsBriefingActive()
return BriefingSystem.GlobalSystem~=nil and
BriefingSystem.GlobalSystem.isActive end
IsBriefingActive=BriefingSystem.IsBriefingActive
function BriefingSystem.SetBriefingPageTextPosition(ll)local DUP73={GUI.GetScreenSize()}
local Y5y9bTM,Y=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight")
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",Y5y9bTM,65)
if not ll.mc then
if BriefingSystem.BriefingTextPositionBackup then
local qks5vL=BriefingSystem.BriefingTextPositionBackup
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text",qks5vL[1],qks5vL[2])end
if ll.splashscreen then
if ll.centered then local eW=0
if ll.text then local EaAe7cpY=string.len(ll.text)eW=eW+math.ceil((
EaAe7cpY/80))local kSlV=0
local lPv7H,a7wO=string.find(ll.text,"{cr}")while(a7wO)do kSlV=kSlV+1
lPv7H,a7wO=string.find(ll.text,"{cr}",a7wO+1)end
eW=eW+math.floor((kSlV/2))local zq={GUI.GetScreenSize()}
eW=(zq[2]/2)- (eW*10)end
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",Y5y9bTM,0+eW)
local Y5y9bTM,Y=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text")if not BriefingSystem.BriefingTextPositionBackup then
BriefingSystem.BriefingTextPositionBackup={Y5y9bTM,Y}end
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text",Y5y9bTM,
38+eW)end end;return end
local Y5y9bTM,Y=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight")if ll.mc.text and ll.mc.text~=""then
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",Y5y9bTM,5)end
local Y5y9bTM,Y=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text")if not BriefingSystem.BriefingTextPositionBackup then
BriefingSystem.BriefingTextPositionBackup={Y5y9bTM,Y}end
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text",Y5y9bTM,42)end
function BriefingSystem.SetBriefingSplashscreenUV(CewK,OzYBK,P,jgY,EG)if
not CewK or not OzYBK or not P or not jgY then return end;local st="/InGame/ThroneRoomBars_2/BarTop"
local pqUzL="/InGame/ThroneRoomBars_2/BarBottom"local Ks={GUI.GetScreenSize()}local jO0cx=
math.floor((Ks[1]/Ks[2])*10)==13;local kI0WSxN=CewK[1]+
(OzYBK[1]-CewK[1])*EG;local seWRJAo=CewK[2]+
(OzYBK[2]-CewK[2])*EG;local b9EtJBg=P[1]+
(jgY[1]-P[1])*EG
local n=P[2]+ (jgY[2]-P[2])*EG;if jO0cx then kI0WSxN=kI0WSxN+ (kI0WSxN*0.125)b9EtJBg=b9EtJBg-
(b9EtJBg*0.125)end
XGUIEng.SetMaterialUV(st,1,kI0WSxN,seWRJAo,b9EtJBg,n)end
function BriefingSystem.SetBriefingPageOrSplashscreen(D,Rmb_6b2I)local w7C="/InGame/ThroneRoomBars_2/BarTop"
local kM9I7435="/InGame/ThroneRoomBars_2/BarBottom"local bAZ={GUI.GetScreenSize()}
if not D.splashscreen then
XGUIEng.SetMaterialTexture(w7C,1,"")XGUIEng.SetMaterialTexture(kM9I7435,1,"")
XGUIEng.SetMaterialColor(w7C,1,0,0,0,255)XGUIEng.SetMaterialColor(kM9I7435,1,0,0,0,255)
if
BriefingSystem.BriefingBarSizeBackup then local m=BriefingSystem.BriefingBarSizeBackup
XGUIEng.SetWidgetSize(w7C,m[1],m[2])BriefingSystem.BriefingBarSizeBackup=nil end;BriefingSystem.ShowBriefingBar(Rmb_6b2I)return end
if D.splashscreen==true then XGUIEng.SetMaterialTexture(w7C,1,"")
XGUIEng.SetMaterialColor(w7C,1,0,0,0,255)XGUIEng.SetMaterialUV(w7C,1,0,0,1,1)else
XGUIEng.SetMaterialColor(kM9I7435,1,0,0,0,0)
if D.splashscreen.color then
XGUIEng.SetMaterialColor(w7C,1,unpack(D.splashscreen.color))else XGUIEng.SetMaterialColor(w7C,1,255,255,255,255)end
XGUIEng.SetMaterialTexture(w7C,1,D.splashscreen.image)end
if not BriefingSystem.BriefingBarSizeBackup then
local v,rW=XGUIEng.GetWidgetSize(w7C)BriefingSystem.BriefingBarSizeBackup={v,rW}end;local _CD=BriefingSystem.BriefingBarSizeBackup[1]
local MW,F=XGUIEng.GetWidgetSize("/InGame/ThroneRoomBars")XGUIEng.SetWidgetSize(w7C,_CD,F)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars",0)XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",1)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",0)XGUIEng.ShowWidget(w7C,1)end;BundleBriefingSystem:OverwriteGetPosition()end
function BundleBriefingSystem:OverwriteGetPosition()
GetPosition=function(c0Z1IHx0,OVX0Cw)OVX0Cw=OVX0Cw or 0
if
type(c0Z1IHx0)=="table"then return c0Z1IHx0 else
if not IsExisting(c0Z1IHx0)then return{X=0,Y=0,Z=0+OVX0Cw}else
local Xg2nd=GetID(c0Z1IHx0)local UhAbzx8,h_x7s1,A1CI=Logic.EntityGetPos(Xg2nd)return
{X=UhAbzx8,Y=h_x7s1,Z=A1CI+OVX0Cw}end end end end;Core:RegisterBundle("BundleBriefingSystem")function Reward_Briefing(...)return
b_Reward_Briefing:new(...)end
b_Reward_Briefing={Name="Reward_Briefing",Description={en="Reward: Calls a function that creates a briefing and saves the returned briefing ID into the quest.",de="Lohn: Ruft eine Funktion auf, die ein Briefing erzeugt und die zurueckgegebene ID in der Quest speichert."},Parameter={{ParameterType.Default,en="Briefing function",de="Funktion mit Briefing"}}}function b_Reward_Briefing:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_Briefing:AddParameter(AIoUuI,g6qy)if(
AIoUuI==0)then self.Function=g6qy end end
function b_Reward_Briefing:CustomFunction(f)
local lvqou=_G[self.Function](self,f)local RJQT=GetQuestID(f.Identifier)
Quests[RJQT].EmbeddedBriefing=lvqou
if not lvqou and QSB.DEBUG_CheckWhileRuntime then
local Yy=f.Identifier..": "..
self.Name..": '"..self.Function..
"' has not returned anything!"if IsBriefingActive()then GUI_Note(Yy)end;dbg(Yy)end end
function b_Reward_Briefing:DEBUG(nhPDx)
if
not type(_G[self.Function])=="function"then
dbg(nhPDx.Identifier..": "..self.Name..
": '"..self.Function.."' was not found!")return true end;return false end
function b_Reward_Briefing:Reset(lHm)local RxtOio=GetQuestID(lHm.Identifier)Quests[RxtOio].EmbeddedBriefing=
nil end;Core:RegisterBehavior(b_Reward_Briefing)function Reprisal_Briefing(...)return
b_Reprisal_Briefing:new(...)end
b_Reprisal_Briefing={Name="Reprisal_Briefing",Description={en="Reprisal: Calls a function that creates a briefing and saves the returned briefing ID into the quest.",de="Vergeltung: Ruft eine Funktion auf, die ein Briefing erzeugt und die zurueckgegebene ID in der Quest speichert."},Parameter={{ParameterType.Default,en="Briefing function",de="Funktion mit Briefing"}}}
function b_Reprisal_Briefing:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_Briefing:AddParameter(s,Kf)if(s==0)then self.Function=Kf end end
function b_Reprisal_Briefing:CustomFunction(aEU)
local H=_G[self.Function](self,aEU)local SjAQ=GetQuestID(aEU.Identifier)
Quests[SjAQ].EmbeddedBriefing=H
if not H and QSB.DEBUG_CheckWhileRuntime then
local DF9=aEU.Identifier..": "..
self.Name..": '"..self.Function..
"' has not returned anything!"if IsBriefingActive()then GUI_Note(DF9)end;dbg(DF9)end end
function b_Reprisal_Briefing:DEBUG(WF_l1)
if
not type(_G[self.Function])=="function"then
dbg(WF_l1.Identifier..": "..self.Name..
": '"..self.Function.."' was not found!")return true end;return false end;function b_Reprisal_Briefing:Reset(t)local _=GetQuestID(t.Identifier)Quests[_].EmbeddedBriefing=
nil end
Core:RegisterBehavior(b_Reprisal_Briefing)
function Trigger_Briefing(...)return b_Trigger_Briefing:new(...)end
b_Trigger_Briefing={Name="Trigger_Briefing",Description={en="Trigger: after an embedded briefing of another quest has finished.",de="Ausloeser: wenn das eingebettete Briefing der angegebenen Quest beendet ist."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Wait time",de="Wartezeit"}}}
function b_Trigger_Briefing:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_Briefing:AddParameter(uF7E2bX,chQIUjLI)
if(uF7E2bX==0)then self.Quest=chQIUjLI elseif(uF7E2bX==1)then self.WaitTime=
tonumber(chQIUjLI)or 0 end end
function b_Trigger_Briefing:CustomFunction(aXmg1)local Ww3E=GetQuestID(self.Quest)
if
IsBriefingFinished(Quests[Ww3E].EmbeddedBriefing)then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end;return false end
function b_Trigger_Briefing:Interrupt(qPIdVRz)local SRIxdI1=GetQuestID(self.Quest)Quests[SRIxdI1].EmbeddedBriefing=
nil;self.WaitTimeTimer=nil end
function b_Trigger_Briefing:Reset(fO4lcG)local XYq2=GetQuestID(self.Quest)Quests[XYq2].EmbeddedBriefing=
nil;self.WaitTimeTimer=nil end
function b_Trigger_Briefing:DEBUG(w4Q)
if tonumber(self.WaitTime)==nil or
self.WaitTime<0 then
dbg(w4Q.Identifier.." "..
self.Name..": waittime is nil or below 0!")return true elseif not IsValidQuest(self.Quest)then
dbg(w4Q.Identifier..
" "..self.Name..": '"..self.Quest..
"' is not a valid quest!")return true end;return false end;Core:RegisterBehavior(b_Trigger_Briefing)
API=API or{}QSB=QSB or{}
BundleCastleStore={Global={Data={UpdateCastleStore=false,CastleStoreObjects={}},CastleStore={Data={CapacityBase=75,Goods={[Goods.G_Wood]={0,true,false,35},[Goods.G_Stone]={0,true,false,35},[Goods.G_Iron]={0,true,false,35},[Goods.G_Carcass]={0,true,false,15},[Goods.G_Grain]={0,true,false,15},[Goods.G_RawFish]={0,true,false,15},[Goods.G_Milk]={0,true,false,15},[Goods.G_Herb]={0,true,false,15},[Goods.G_Wool]={0,true,false,15},[Goods.G_Honeycomb]={0,true,false,15}}}}},Local={Data={},CastleStore={Data={}},Description={ShowCastle={Text={de="Finanzansicht",en="Financial view"}},ShowCastleStore={Text={de="Lageransicht",en="Storeage view"}},GoodButtonDisabled={Text={de="Diese Ware wird nicht angenommen.",en="This good will not be stored."}},CityTab={Title={de="Güter verwaren",en="Keep goods"},Text={de="- Lagert Waren im Burglager ein {cr}- Waren verbleiben auch im Lager, wenn Platz vorhanden ist",en="- Stores goods inside the store {cr}- Goods also remain in the warehouse when space is available"}},StorehouseTab={Title={de="Güter zwischenlagern",en="Store goods temporarily"},Text={de="- Lagert Waren im Burglager ein {cr}- Lagert waren wieder aus, sobald Platz frei wird",en="- Stores goods inside the store {cr}- Allows to extrac goods as soon as space becomes available"}},MultiTab={Title={de="Lager räumen",en="Clear store"},Text={de="- Lagert alle Waren aus {cr}- Benötigt Platz im Lagerhaus",en="- Removes all goods {cr}- Requires space in the storehouse"}}}}}
function BundleCastleStore.Global:Install()
QSB.CastleStore=BundleCastleStore.Global.CastleStore;self:OverwriteGameFunctions()
API.AddSaveGameAction(BundleCastleStore.Global.OnSaveGameLoaded)end
function BundleCastleStore.Global.CastleStore:New(O)
assert(self==
BundleCastleStore.Global.CastleStore,"Can not be used from instance!")local UMSpjWj=API.InstanceTable(self)UMSpjWj.Data.PlayerID=O
BundleCastleStore.Global.Data.CastleStoreObjects[O]=UMSpjWj;if not self.Data.UpdateCastleStore then self.Data.UpdateCastleStore=true
StartSimpleJobEx(BundleCastleStore.Global.CastleStore.UpdateStores)end
Logic.ExecuteInLuaLocalState(
[[
        QSB.CastleStore:CreateStore(]]..UMSpjWj.Data.PlayerID..[[);
    ]])return UMSpjWj end
function BundleCastleStore.Global.CastleStore:GetInstance(jK1jRlc)
assert(self==
BundleCastleStore.Global.CastleStore,"Can not be used from instance!")return
BundleCastleStore.Global.Data.CastleStoreObjects[jK1jRlc]end
function BundleCastleStore.Global.CastleStore:GetGoodAmountWithCastleStore(ny,P4J7c)
assert(
self==BundleCastleStore.Global.CastleStore,"Can not be used from instance!")local ff=self:GetInstance(P4J7c)
local fa5H=GetPlayerGoodsInSettlement(ny,P4J7c,true)
if
ff~=nil and ny~=Goods.G_Gold and Logic.GetGoodCategoryForGoodType(ny)==
GoodCategories.GC_Resource then fa5H=fa5H+ff:GetAmount(ny)end;return fa5H end
function BundleCastleStore.Global.CastleStore:Dispose()
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLuaLocalState([[
        QSB.CastleStore:DeleteStore(]]..self.Data.PlayerID..[[);
    ]])BundleCastleStore.Global.Data.CastleStoreObjects[self.Data.PlayerID]=
nil end
function BundleCastleStore.Global.CastleStore:SetUperLimitInStorehouseForGoodType(Y,sUqw2a)
assert(
self~=BundleCastleStore.Global.CastleStore,"Can not be used in static context!")self.Data.Goods[Y][4]=sUqw2a
Logic.ExecuteInLuaLocalState(
[[
        BundleCastleStore.Local.Data.CastleStore[]]..self.Data.PlayerID..
[[].Goods[]]..Y..[[][4] = ]]..sUqw2a..[[
    ]])return self end
function BundleCastleStore.Global.CastleStore:SetStorageLimit(Hv2H)
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")self.Data.CapacityBase=math.floor(Hv2H/2)
Logic.ExecuteInLuaLocalState(
[[
        BundleCastleStore.Local.Data.CastleStore[]]..self.Data.PlayerID..
[[].CapacityBase = ]]..math.floor(Hv2H/2)..[[
    ]])return self end
function BundleCastleStore.Global.CastleStore:GetAmount(j)
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")
if self.Data.Goods[j]then return self.Data.Goods[j][1]end;return 0 end
function BundleCastleStore.Global.CastleStore:GetTotalAmount()
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")local hogStN8z=0
for EOcgN1,jp in pairs(self.Data.Goods)do hogStN8z=hogStN8z+jp[1]end;return hogStN8z end
function BundleCastleStore.Global.CastleStore:GetLimit()
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")local aQaXL=0
local A=Logic.GetHeadquarters(self.Data.PlayerID)if A~=0 then aQaXL=Logic.GetUpgradeLevel(A)end
local OmAS=self.Data.CapacityBase;for jm4DF1=1,(aQaXL+1),1 do OmAS=OmAS*2 end;return OmAS end
function BundleCastleStore.Global.CastleStore:IsGoodAccepted(bkR)
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")return self.Data.Goods[bkR][2]==true end
function BundleCastleStore.Global.CastleStore:SetGoodAccepted(Qe,zgqnJquk)
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")self.Data.Goods[Qe][2]=zgqnJquk==true
Logic.ExecuteInLuaLocalState(
[[
        QSB.CastleStore:SetAccepted(
            ]]..self.Data.PlayerID..
[[, ]]..Qe..[[, ]]..
tostring(zgqnJquk==true)..[[
        )
    ]])return self end
function BundleCastleStore.Global.CastleStore:IsGoodLocked(js3OuR)
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")
return self.Data.Goods[js3OuR][3]==true end
function BundleCastleStore.Global.CastleStore:SetGoodLocked(Jv,I9)
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")self.Data.Goods[Jv][3]=I9 ==true
Logic.ExecuteInLuaLocalState(
[[
        QSB.CastleStore:SetLocked(
            ]]..
self.Data.PlayerID..[[, ]]..Jv..
[[, ]]..tostring(I9 ==true)..[[
        )
    ]])return self end
function BundleCastleStore.Global.CastleStore:ActivateTemporaryMode()
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLocalLuaState([[
        QSB.CastleStore.OnStorehouseTabClicked(QSB.CastleStore, ]]..
self.Data.PlayerID..[[)
    ]])return self end
function BundleCastleStore.Global.CastleStore:ActivateStockMode()
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLocalLuaState([[
        QSB.CastleStore.OnCityTabClicked(QSB.CastleStore, ]]..
self.Data.PlayerID..[[)
    ]])return self end
function BundleCastleStore.Global.CastleStore:ActivateOutsourceMode()
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLocalLuaState([[
        QSB.CastleStore.OnMultiTabClicked(QSB.CastleStore, ]]..
self.Data.PlayerID..[[)
    ]])return self end
function BundleCastleStore.Global.CastleStore:Store(L5jl9h_q,MR4jXXI)
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")
if self:IsGoodAccepted(L5jl9h_q)then
if self:GetLimit()>=
self:GetTotalAmount()+MR4jXXI then
local b=Logic.GetUpgradeLevel(Logic.GetHeadquarters(self.Data.PlayerID))
if
GetPlayerResources(L5jl9h_q,self.Data.PlayerID)> (
self.Data.Goods[L5jl9h_q][4]* (b+1))then
AddGood(L5jl9h_q,MR4jXXI* (-1),self.Data.PlayerID)self.Data.Goods[L5jl9h_q][1]=
self.Data.Goods[L5jl9h_q][1]+MR4jXXI
Logic.ExecuteInLuaLocalState(
[[
                    QSB.CastleStore:SetAmount(
                        ]]..self.Data.PlayerID..
[[, ]]..L5jl9h_q..
[[, ]]..self.Data.Goods[L5jl9h_q][1]..
[[
                    )
                ]])end end end;return self end
function BundleCastleStore.Global.CastleStore:Outsource(a69P0L,Xwixbug)
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")
local C=Logic.GetUpgradeLevel(Logic.GetHeadquarters(self.Data.PlayerID))
if
Logic.GetPlayerUnreservedStorehouseSpace(self.Data.PlayerID)>=Xwixbug then
if self:GetAmount(a69P0L)>=Xwixbug then
AddGood(a69P0L,Xwixbug,self.Data.PlayerID)self.Data.Goods[a69P0L][1]=
self.Data.Goods[a69P0L][1]-Xwixbug
Logic.ExecuteInLuaLocalState(
[[
                QSB.CastleStore:SetAmount(
                    ]]..
self.Data.PlayerID..[[, ]]..
a69P0L..[[, ]]..self.Data.Goods[a69P0L][1]..
[[
                )
            ]])end end;return self end
function BundleCastleStore.Global.CastleStore:Add(u,b)
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")
if self:IsGoodAccepted(u)then
for qUMCqx=1,b,1 do if
self:GetLimit()>self:GetTotalAmount()then
self.Data.Goods[u][1]=self.Data.Goods[u][1]+1 end end
Logic.ExecuteInLuaLocalState([[
            QSB.CastleStore:SetAmount(
                ]]..
self.Data.PlayerID..[[, ]]..
u..[[, ]]..
self.Data.Goods[u][1]..[[
            )
        ]])end;return self end
function BundleCastleStore.Global.CastleStore:Remove(NbZ,_KOapu)
assert(self~=
BundleCastleStore.Global.CastleStore,"Can not be used in static context!")
if self:GetAmount(NbZ)>0 then
local N=
(_KOapu<=self:GetAmount(NbZ)and _KOapu)or self:GetAmount(NbZ)self.Data.Goods[NbZ][1]=self.Data.Goods[NbZ][1]-
N
Logic.ExecuteInLuaLocalState(
[[
            QSB.CastleStore:SetAmount(
                ]]..self.Data.PlayerID..
[[, ]]..NbZ..[[, ]]..
self.Data.Goods[NbZ][1]..[[
            )
        ]])end;return self end
function BundleCastleStore.Global.CastleStore.UpdateStores()
assert(self==nil,"This method is only procedural!")
for Eb,tSsrDhy in
pairs(BundleCastleStore.Global.Data.CastleStoreObjects)do
if tSsrDhy~=nil then
local kjI=Logic.GetUpgradeLevel(Logic.GetHeadquarters(tSsrDhy.Data.PlayerID))
for k,aN in pairs(tSsrDhy.Data.Goods)do
if aN~=nil then
if aN[2]==true then
local iBCc=GetPlayerResources(k,tSsrDhy.Data.PlayerID)local w=tSsrDhy:GetAmount(k)
if iBCc< (
tSsrDhy.Data.Goods[k][4]* (kjI+1))then
if
aN[3]==false then local J=
(tSsrDhy.Data.Goods[k][4]* (kjI+1))-iBCc
J=(J>10 and 10)or J;for qYa=1,J,1 do tSsrDhy:Outsource(k,1)end end else local YpKVWt=(iBCc>10 and 10)or iBCc;for mDCOZ=1,YpKVWt,1 do
tSsrDhy:Store(k,1)end end else local EA=(tSsrDhy:GetAmount(k)>=10 and 10)or
tSsrDhy:GetAmount(k)for Sbs7O=1,EA,1 do
tSsrDhy:Outsource(k,1)end end end end end end end;function BundleCastleStore.Global.OnSaveGameLoaded()
API.Bridge("BundleCastleStore.Local:OverwriteGetStringTableText()")end
function BundleCastleStore.Global:OverwriteGameFunctions()
QuestTemplate.IsObjectiveCompleted_Orig_QSB_CastleStore=QuestTemplate.IsObjectiveCompleted
QuestTemplate.IsObjectiveCompleted=function(BAcy,p)local ySH6=p.Type;local N88ly=p.Data;if p.Completed~=nil then
return p.Completed end
if ySH6 ==Objective.Produce then
local Ogr8mgSN=GetPlayerGoodsInSettlement(N88ly[1],BAcy.ReceivingPlayer,true)
local VXpZbxT=QSB.CastleStore:GetInstance(BAcy.ReceivingPlayer)
if VXpZbxT and
Logic.GetGoodCategoryForGoodType(N88ly[1])==GoodCategories.GC_Resource then Ogr8mgSN=Ogr8mgSN+
VXpZbxT:GetAmount(N88ly[1])end;if
(not N88ly[3]and Ogr8mgSN>=N88ly[2])or(N88ly[3]and
Ogr8mgSN<N88ly[2])then p.Completed=true end else return
QuestTemplate.IsObjectiveCompleted_Orig_QSB_CastleStore(BAcy,p)end end
QuestTemplate.SendGoods=function(GP2b)
for K=1,GP2b.Objectives[0]do
if GP2b.Objectives[K].Type==
Objective.Deliver then
if
GP2b.Objectives[K].Data[3]==nil then local kzsvLS6=GP2b.Objectives[K].Data[1]
local SMSfEVE=GP2b.Objectives[K].Data[2]
local MV=QSB.CastleStore:GetGoodAmountWithCastleStore(kzsvLS6,GP2b.ReceivingPlayer,true)
if MV>=SMSfEVE then local WOvkq=GP2b.ReceivingPlayer
local PK8TNd=
GP2b.Objectives[K].Data[6]and GP2b.Objectives[K].Data[6]or
GP2b.SendingPlayer;local x={}x.Good=kzsvLS6;x.Amount=SMSfEVE;x.PlayerID=PK8TNd;x.ID=nil
GP2b.Objectives[K].Data[5]=x;GP2b.Objectives[K].Data[3]=1;QuestMerchants[
#QuestMerchants+1]=x
if kzsvLS6 ==Goods.G_Gold then
local LMolhB=Logic.GetHeadquarters(WOvkq)
if LMolhB==0 then LMolhB=Logic.GetStoreHouse(WOvkq)end
GP2b.Objectives[K].Data[3]=Logic.CreateEntityAtBuilding(Entities.U_GoldCart,LMolhB,0,PK8TNd)
Logic.HireMerchant(GP2b.Objectives[K].Data[3],PK8TNd,kzsvLS6,SMSfEVE,GP2b.ReceivingPlayer)Logic.RemoveGoodFromStock(LMolhB,kzsvLS6,SMSfEVE)if
MapCallback_DeliverCartSpawned then
MapCallback_DeliverCartSpawned(GP2b,GP2b.Objectives[K].Data[3],kzsvLS6)end elseif
kzsvLS6 ==Goods.G_Water then local mWWARyN=Logic.GetMarketplace(WOvkq)
GP2b.Objectives[K].Data[3]=Logic.CreateEntityAtBuilding(Entities.U_Marketer,mWWARyN,0,PK8TNd)
Logic.HireMerchant(GP2b.Objectives[K].Data[3],PK8TNd,kzsvLS6,SMSfEVE,GP2b.ReceivingPlayer)
Logic.RemoveGoodFromStock(mWWARyN,kzsvLS6,SMSfEVE)if MapCallback_DeliverCartSpawned then
MapCallback_DeliverCartSpawned(GP2b,GP2b.Objectives[K].Data[3],kzsvLS6)end else
if
Logic.GetGoodCategoryForGoodType(kzsvLS6)==GoodCategories.GC_Resource then
local V5pLu=Logic.GetStoreHouse(PK8TNd)local mHHq=Logic.GetNumberOfGoodTypesOnOutStock(V5pLu)
if
mHHq~=nil then
for j6I3=0,mHHq-1 do
local B=Logic.GetGoodTypeOnOutStockByIndex(V5pLu,j6I3)local BiMFbf=Logic.GetAmountOnOutStockByIndex(V5pLu,j6I3)if
BiMFbf>=SMSfEVE then
Logic.RemoveGoodFromStock(V5pLu,B,SMSfEVE,false)end end end;local KUFxe2=Logic.GetStoreHouse(WOvkq)
local IwvBqpMw=GetPlayerResources(kzsvLS6,WOvkq)
if IwvBqpMw<SMSfEVE then local o=SMSfEVE-IwvBqpMw
AddGood(kzsvLS6,IwvBqpMw* (-1),WOvkq)
QSB.CastleStore:GetInstance(GP2b.ReceivingPlayer):Remove(kzsvLS6,o)else AddGood(kzsvLS6,SMSfEVE* (-1),WOvkq)end
GP2b.Objectives[K].Data[3]=Logic.CreateEntityAtBuilding(Entities.U_ResourceMerchant,KUFxe2,0,PK8TNd)
Logic.HireMerchant(GP2b.Objectives[K].Data[3],PK8TNd,kzsvLS6,SMSfEVE,GP2b.ReceivingPlayer)else
Logic.StartTradeGoodGathering(WOvkq,PK8TNd,kzsvLS6,SMSfEVE,0)end end end end end end end end
function BundleCastleStore.Local:Install()
QSB.CastleStore=BundleCastleStore.Local.CastleStore;self:OverwriteGameFunctions()
self:OverwriteGetStringTableText()end
function BundleCastleStore.Local.CastleStore:CreateStore(HXWDDA)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")
local A6lEy9={StoreMode=1,CapacityBase=75,Goods={[Goods.G_Wood]={0,true,false,35},[Goods.G_Stone]={0,true,false,35},[Goods.G_Iron]={0,true,false,35},[Goods.G_Carcass]={0,true,false,15},[Goods.G_Grain]={0,true,false,15},[Goods.G_RawFish]={0,true,false,15},[Goods.G_Milk]={0,true,false,15},[Goods.G_Herb]={0,true,false,15},[Goods.G_Wool]={0,true,false,15},[Goods.G_Honeycomb]={0,true,false,15}}}self.Data[HXWDDA]=A6lEy9 end
function BundleCastleStore.Local.CastleStore:DeleteStore(Mw)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")self.Data[Mw]=nil end
function BundleCastleStore.Local.CastleStore:GetAmount(CX1,Xk5Sma_)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(CX1)then return 0 end;return
self.Data[CX1].Goods[Xk5Sma_][1]end
function BundleCastleStore.Local.CastleStore:GetGoodAmountWithCastleStore(NIFAPqV,K9JDW)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")local gy=GetPlayerGoodsInSettlement(NIFAPqV,K9JDW,true)
if
self:HasCastleStore(K9JDW)then
if
NIFAPqV~=Goods.G_Gold and Logic.GetGoodCategoryForGoodType(NIFAPqV)==
GoodCategories.GC_Resource then gy=gy+self:GetAmount(K9JDW,NIFAPqV)end end;return gy end
function BundleCastleStore.Local.CastleStore:GetTotalAmount(Q4V7x)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(Q4V7x)then return 0 end
local hCf3AB=0;for jD11V0,GX3slY in pairs(self.Data[Q4V7x].Goods)do
hCf3AB=hCf3AB+GX3slY[1]end;return hCf3AB end
function BundleCastleStore.Local.CastleStore:SetAmount(jJF,ZIz_1roD,UVyP)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(jJF)then return end
self.Data[jJF].Goods[ZIz_1roD][1]=UVyP;return self end
function BundleCastleStore.Local.CastleStore:IsAccepted(_0_R0U,g0r)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")
if not self:HasCastleStore(_0_R0U)then return false end
if not self.Data[_0_R0U].Goods[g0r]then return false end;return
self.Data[_0_R0U].Goods[g0r][2]==true end
function BundleCastleStore.Local.CastleStore:SetAccepted(c,PCM,uu)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")
if self:HasCastleStore(c)then if self.Data[c].Goods[PCM]then self.Data[c].Goods[PCM][2]=
uu==true end end;return self end
function BundleCastleStore.Local.CastleStore:IsLocked(K,Zjp6E6q)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(K)then return false end;if not
self.Data[K].Goods[Zjp6E6q]then return false end;return
self.Data[K].Goods[Zjp6E6q][3]==true end
function BundleCastleStore.Local.CastleStore:SetLocked(PIScAA17,MMB5lhJ,_y)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")
if self:HasCastleStore(PIScAA17)then if
self.Data[PIScAA17].Goods[MMB5lhJ]then
self.Data[PIScAA17].Goods[MMB5lhJ][3]=_y==true end end;return self end
function BundleCastleStore.Local.CastleStore:HasCastleStore(qp2NS)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")return self.Data[qp2NS]~=nil end
function BundleCastleStore.Local.CastleStore:GetStore(BFV)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")return self.Data[BFV]end
function BundleCastleStore.Local.CastleStore:GetLimit(jK1l)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")local W=0;local h8FxVlg7=Logic.GetHeadquarters(jK1l)if h8FxVlg7 ~=0 then
W=Logic.GetUpgradeLevel(h8FxVlg7)end
local S6eMwE9Z=self.Data[jK1l].CapacityBase;for Vx=1,(W+1),1 do S6eMwE9Z=S6eMwE9Z*2 end;return S6eMwE9Z end
function BundleCastleStore.Local.CastleStore:OnStorehouseTabClicked(jUrb)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")self.Data[jUrb].StoreMode=1
self:UpdateBehaviorTabs(jUrb)
GUI.SendScriptCommand([[
        local Store = QSB.CastleStore:GetInstance(]]..
jUrb..
[[);
        for k, v in pairs(Store.Data.Goods) do
            Store:SetGoodAccepted(k, true);
            Store:SetGoodLocked(k, false);
        end
    ]])end
function BundleCastleStore.Local.CastleStore:OnCityTabClicked(XVq)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")self.Data[XVq].StoreMode=2
self:UpdateBehaviorTabs(XVq)
GUI.SendScriptCommand([[
        local Store = QSB.CastleStore:GetInstance(]]..
XVq..
[[);
        for k, v in pairs(Store.Data.Goods) do
            Store:SetGoodAccepted(k, true);
            Store:SetGoodLocked(k, true);
        end
    ]])end
function BundleCastleStore.Local.CastleStore:OnMultiTabClicked(K)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")self.Data[K].StoreMode=3
self:UpdateBehaviorTabs(K)
GUI.SendScriptCommand([[
        local Store = QSB.CastleStore:GetInstance(]]..K..
[[);
        for k, v in pairs(Store.Data.Goods) do
            Store:SetGoodAccepted(k, false);
        end
    ]])end
function BundleCastleStore.Local.CastleStore:GoodClicked(JXE,psjIkopQ)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")
if self:HasCastleStore(JXE)then
local _0KWP=XGUIEng.GetCurrentWidgetID()
GUI.SendScriptCommand([[
            local Store = QSB.CastleStore:GetInstance(]]..
JXE..
[[);
            local Accepted = not Store:IsGoodAccepted(]]..
psjIkopQ..
[[)
            Store:SetGoodAccepted(]]..psjIkopQ..[[, Accepted);
        ]])end end
function BundleCastleStore.Local.CastleStore:DestroyGoodsClicked(WiIFZyi)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")if self:HasCastleStore(WiIFZyi)then
QSB.CastleStore.ToggleStore()end end
function BundleCastleStore.Local.CastleStore:SelectionChanged(p3bFAUJ_)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")
if self:HasCastleStore(p3bFAUJ_)then local QeIo0sp9=GUI.GetSelectedEntity()if
Logic.GetHeadquarters(p3bFAUJ_)==QeIo0sp9 then self:ShowCastleMenu()else
self:RestoreStorehouseMenu()end end end
function BundleCastleStore.Local.CastleStore:UpdateBehaviorTabs(HJZaK)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")if
not QSB.CastleStore:HasCastleStore(GUI.GetPlayerID())then return end
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons",0)
if self.Data[HJZaK].StoreMode==1 then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/StorehouseTabButtonUp",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/CityTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/Tab03Down",1)elseif self.Data[HJZaK].StoreMode==2 then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/StorehouseTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/CityTabButtonUp",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/Tab03Down",1)else
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/StorehouseTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/CityTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/Tab03Up",1)end end
function BundleCastleStore.Local.CastleStore:UpdateGoodsDisplay(RN,G4mFn)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(RN)then return end
local lW2YKsYF="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InStorehouse/Goods"local Iv=""if self:GetLimit(RN)==self:GetTotalAmount(RN)then
Iv="{@color:255,32,32,255}"end
for IXUS2Byl,onE1C in
pairs(self.Data[RN].Goods)do local boxCiv=Logic.GetGoodTypeName(IXUS2Byl)local SE4aJ=lW2YKsYF.."/"..
boxCiv.."/Amount"local EWSmVLQF=lW2YKsYF..
"/"..boxCiv.."/Button"
local pnZTk=lW2YKsYF.."/"..boxCiv.."/BG"
XGUIEng.SetText(SE4aJ,"{center}"..Iv..onE1C[1])XGUIEng.DisableButton(EWSmVLQF,0)
if
self:IsAccepted(RN,IXUS2Byl)then
XGUIEng.SetMaterialColor(EWSmVLQF,0,255,255,255,255)
XGUIEng.SetMaterialColor(EWSmVLQF,1,255,255,255,255)
XGUIEng.SetMaterialColor(EWSmVLQF,7,255,255,255,255)else XGUIEng.SetMaterialColor(EWSmVLQF,0,190,90,90,255)
XGUIEng.SetMaterialColor(EWSmVLQF,1,190,90,90,255)XGUIEng.SetMaterialColor(EWSmVLQF,7,190,90,90,255)end end end
function BundleCastleStore.Local.CastleStore:UpdateStorageLimit(L6KlrW6Q)
assert(self==
BundleCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(L6KlrW6Q)then return end
local fh=XGUIEng.GetCurrentWidgetID()local s=GUI.GetPlayerID()
local K=QSB.CastleStore:GetTotalAmount(s)local TI=QSB.CastleStore:GetLimit(s)
local G=XGUIEng.GetStringTableText("UI_Texts/StorageLimit_colon")local NTsGl="{center}"..G.." "..K.."/"..TI
XGUIEng.SetText(fh,NTsGl)end
function BundleCastleStore.Local.CastleStore:ToggleStore()
assert(self==nil,"This function is procedural!")
if QSB.CastleStore:HasCastleStore(GUI.GetPlayerID())then
if
Logic.GetHeadquarters(GUI.GetPlayerID())==GUI.GetSelectedEntity()then
if
XGUIEng.IsWidgetShown("/InGame/Root/Normal/AlignBottomRight/Selection/Castle")==1 then
QSB.CastleStore.ShowCastleStoreMenu(QSB.CastleStore)else
QSB.CastleStore.ShowCastleMenu(QSB.CastleStore)end end end end
function BundleCastleStore.Local.CastleStore:RestoreStorehouseMenu()
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InCity/Goods",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InCity",0)
SetIcon("/InGame/Root/Normal/AlignBottomRight/DialogButtons/PlayerButtons/DestroyGoods",{16,8})
local MfT3l="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/"
SetIcon(MfT3l.."StorehouseTabButtonUp/up/B_StoreHouse",{3,13})
SetIcon(MfT3l.."StorehouseTabButtonDown/down/B_StoreHouse",{3,13})
SetIcon(MfT3l.."CityTabButtonUp/up/CityBuildingsNumber",{8,1})
SetIcon(MfT3l.."TabButtons/CityTabButtonDown/down/CityBuildingsNumber",{8,1})
SetIcon(MfT3l.."TabButtons/Tab03Up/up/B_Castle_ME",{3,14})
SetIcon(MfT3l.."Tab03Down/down/B_Castle_ME",{3,14})
for QA,NY in
ipairs{"G_Carcass","G_Grain","G_Milk","G_RawFish","G_Iron","G_Wood","G_Stone","G_Honeycomb","G_Herb","G_Wool"}do
local MfT3l="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InStorehouse/Goods/"
XGUIEng.SetMaterialColor(MfT3l..NY.."/Button",0,255,255,255,255)
XGUIEng.SetMaterialColor(MfT3l..NY.."/Button",1,255,255,255,255)
XGUIEng.SetMaterialColor(MfT3l..NY.."/Button",7,255,255,255,255)end end
function BundleCastleStore.Local.CastleStore:ShowCastleMenu()
local MGUnKw4B="/InGame/Root/Normal/AlignBottomRight/"
XGUIEng.ShowWidget(MGUnKw4B.."Selection/BGBig",0)
XGUIEng.ShowWidget(MGUnKw4B.."Selection/Storehouse",0)
XGUIEng.ShowWidget(MGUnKw4B.."Selection/BGSmall",1)
XGUIEng.ShowWidget(MGUnKw4B.."Selection/Castle",1)
if g_HideSoldierPayment~=nil then
XGUIEng.ShowWidget(MGUnKw4B.."Selection/Castle/Treasury/Payment",0)
XGUIEng.ShowWidget(MGUnKw4B.."Selection/Castle/LimitSoldiers",0)end;GUI_BuildingInfo.PaymentLevelSliderUpdate()
GUI_BuildingInfo.TaxationLevelSliderUpdate()GUI_Trade.StorehouseSelected()
local l,itDmAq=XGUIEng.GetWidgetLocalPosition(MGUnKw4B..
"Selection/AnchorInfoForSmall")
XGUIEng.SetWidgetLocalPosition(MGUnKw4B.."Selection/Info",l,itDmAq)
XGUIEng.ShowWidget(MGUnKw4B.."DialogButtons/PlayerButtons",1)
XGUIEng.ShowWidget(MGUnKw4B.."DialogButtons/PlayerButtons/DestroyGoods",1)
XGUIEng.DisableButton(MGUnKw4B.."DialogButtons/PlayerButtons/DestroyGoods",0)
SetIcon(MGUnKw4B.."DialogButtons/PlayerButtons/DestroyGoods",{10,9})end
function BundleCastleStore.Local.CastleStore:ShowCastleStoreMenu()
local X8Rz_h="/InGame/Root/Normal/AlignBottomRight/"
XGUIEng.ShowWidget(X8Rz_h.."Selection/Selection/BGSmall",0)
XGUIEng.ShowWidget(X8Rz_h.."Selection/Castle",0)
XGUIEng.ShowWidget(X8Rz_h.."Selection/BGSmall",0)
XGUIEng.ShowWidget(X8Rz_h.."Selection/BGBig",1)
XGUIEng.ShowWidget(X8Rz_h.."Selection/Storehouse",1)
XGUIEng.ShowWidget(X8Rz_h.."Selection/Storehouse/AmountContainer",0)
XGUIEng.ShowAllSubWidgets(X8Rz_h.."Selection/Storehouse/TabButtons",1)GUI_Trade.StorehouseSelected()
local j,fD=XGUIEng.GetWidgetLocalPosition(X8Rz_h..
"Selection/AnchorInfoForBig")
XGUIEng.SetWidgetLocalPosition(X8Rz_h.."Selection/Info",j,fD)
XGUIEng.ShowWidget(X8Rz_h.."DialogButtons/PlayerButtons",1)
XGUIEng.ShowWidget(X8Rz_h.."DialogButtons/PlayerButtons/DestroyGoods",1)
XGUIEng.ShowWidget(X8Rz_h.."Selection/Storehouse/InStorehouse",1)
XGUIEng.ShowWidget(X8Rz_h.."Selection/Storehouse/InMulti",0)
XGUIEng.ShowWidget(X8Rz_h.."Selection/Storehouse/InCity",1)
XGUIEng.ShowAllSubWidgets(X8Rz_h.."Selection/Storehouse/InCity/Goods",0)
XGUIEng.ShowWidget(X8Rz_h.."Selection/Storehouse/InCity/Goods/G_Beer",1)
XGUIEng.DisableButton(X8Rz_h.."DialogButtons/PlayerButtons/DestroyGoods",0)local xAUv9N=X8Rz_h.."DialogButtons/PlayerButtons/"local Ac33NhV=X8Rz_h..
"Selection/Storehouse/TabButtons/"
SetIcon(xAUv9N.."DestroyGoods",{3,14})
SetIcon(Ac33NhV.."StorehouseTabButtonUp/up/B_StoreHouse",{10,9})
SetIcon(Ac33NhV.."StorehouseTabButtonDown/down/B_StoreHouse",{10,9})
SetIcon(Ac33NhV.."CityTabButtonUp/up/CityBuildingsNumber",{15,6})
SetIcon(Ac33NhV.."CityTabButtonDown/down/CityBuildingsNumber",{15,6})
SetIcon(Ac33NhV.."Tab03Up/up/B_Castle_ME",{7,1})
SetIcon(Ac33NhV.."Tab03Down/down/B_Castle_ME",{7,1})self:UpdateBehaviorTabs(GUI.GetPlayerID())end
function BundleCastleStore.Local:OverwriteGetStringTableText()
GetStringTableText_Orig_QSB_CatsleStore=XGUIEng.GetStringTableText
XGUIEng.GetStringTableText=function(yiQ1)local P44nujnL=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
local dSrAKHOd=GUI.GetSelectedEntity()local B=GUI.GetPlayerID()
local V4n=XGUIEng.GetCurrentWidgetID()
if yiQ1 =="UI_ObjectNames/DestroyGoods"then
if
XGUIEng.IsWidgetShown("/InGame/Root/Normal/AlignBottomRight/Selection/Castle")==1 then return
BundleCastleStore.Local.Description.ShowCastleStore.Text[P44nujnL]else return
BundleCastleStore.Local.Description.ShowCastle.Text[P44nujnL]end end
if yiQ1 =="UI_ObjectDescription/DestroyGoods"then return""end
if yiQ1 =="UI_ObjectNames/CityBuildingsNumber"then
if
Logic.GetHeadquarters(B)==dSrAKHOd then return
BundleCastleStore.Local.Description.CityTab.Title[P44nujnL]end end
if yiQ1 =="UI_ObjectDescription/CityBuildingsNumber"then
if Logic.GetHeadquarters(B)==
dSrAKHOd then return
BundleCastleStore.Local.Description.CityTab.Text[P44nujnL]end end
if yiQ1 =="UI_ObjectNames/B_StoreHouse"then
if
Logic.GetHeadquarters(B)==dSrAKHOd then return
BundleCastleStore.Local.Description.StorehouseTab.Title[P44nujnL]end end
if yiQ1 =="UI_ObjectDescription/B_StoreHouse"then
if
Logic.GetHeadquarters(B)==dSrAKHOd then return
BundleCastleStore.Local.Description.StorehouseTab.Text[P44nujnL]end end
if yiQ1 =="UI_ObjectNames/B_Castle_ME"then
local nNM="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/"local fH8B=nNM.."Tab03Down/down/B_Castle_ME"
local IAge97J=nNM.."Tab03Up/up/B_Castle_ME"
if XGUIEng.GetWidgetPathByID(V4n)==fH8B or
XGUIEng.GetWidgetPathByID(V4n)==IAge97J then
if
Logic.GetHeadquarters(B)==dSrAKHOd then return
BundleCastleStore.Local.Description.MultiTab.Title[P44nujnL]end end end
if yiQ1 =="UI_ObjectDescription/B_Castle_ME"then
if
Logic.GetHeadquarters(B)==dSrAKHOd then return
BundleCastleStore.Local.Description.MultiTab.Text[P44nujnL]end end
if yiQ1 =="UI_ButtonDisabled/NotEnoughGoods"then
if
Logic.GetHeadquarters(B)==dSrAKHOd then return
BundleCastleStore.Local.Description.GoodButtonDisabled.Text[P44nujnL]end end;return GetStringTableText_Orig_QSB_CatsleStore(yiQ1)end end
function BundleCastleStore.Local:OverwriteGameFunctions()
GameCallback_GUI_SelectionChanged_Orig_QSB_CastleStore=GameCallback_GUI_SelectionChanged
GameCallback_GUI_SelectionChanged=function(mx)
GameCallback_GUI_SelectionChanged_Orig_QSB_CastleStore(mx)
QSB.CastleStore:SelectionChanged(GUI.GetPlayerID())end;GUI_Trade.GoodClicked_Orig_QSB_CastleStore=GUI_Trade.GoodClicked
GUI_Trade.GoodClicked=function()
local U9KT=Goods[XGUIEng.GetWidgetNameByID(XGUIEng.GetWidgetsMotherID(XGUIEng.GetCurrentWidgetID()))]local Vyx=GUI.GetSelectedEntity()local Psw=GUI.GetPlayerID()if
Logic.IsEntityInCategory(Vyx,EntityCategories.Storehouse)==1 then
GUI_Trade.GoodClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:GoodClicked(Psw,U9KT)end
GUI_Trade.DestroyGoodsClicked_Orig_QSB_CastleStore=GUI_Trade.DestroyGoodsClicked
GUI_Trade.DestroyGoodsClicked=function()local l=GUI.GetSelectedEntity()
local S=GUI.GetPlayerID()if
Logic.IsEntityInCategory(l,EntityCategories.Storehouse)==1 then
GUI_Trade.DestroyGoodsClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:DestroyGoodsClicked(S)end;GUI_Trade.SellUpdate_Orig_QSB_CastleStore=GUI_Trade.SellUpdate
GUI_Trade.SellUpdate=function()
local Ke=GUI.GetSelectedEntity()local N=GUI.GetPlayerID()if
Logic.IsEntityInCategory(Ke,EntityCategories.Storehouse)==1 then
GUI_Trade.SellUpdate_Orig_QSB_CastleStore()return end
QSB.CastleStore:UpdateGoodsDisplay(N)end
GUI_Trade.CityTabButtonClicked_Orig_QSB_CastleStore=GUI_Trade.CityTabButtonClicked
GUI_Trade.CityTabButtonClicked=function()local i=GUI.GetSelectedEntity()
local NTxpD=GUI.GetPlayerID()if
Logic.IsEntityInCategory(i,EntityCategories.Storehouse)==1 then
GUI_Trade.CityTabButtonClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:OnCityTabClicked(NTxpD)end
GUI_Trade.StorehouseTabButtonClicked_Orig_QSB_CastleStore=GUI_Trade.StorehouseTabButtonClicked
GUI_Trade.StorehouseTabButtonClicked=function()local Nje9s2=GUI.GetSelectedEntity()
local Fj=GUI.GetPlayerID()if
Logic.IsEntityInCategory(Nje9s2,EntityCategories.Storehouse)==1 then
GUI_Trade.StorehouseTabButtonClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:OnStorehouseTabClicked(Fj)end
GUI_Trade.MultiTabButtonClicked_Orig_QSB_CastleStore=GUI_Trade.MultiTabButtonClicked
GUI_Trade.MultiTabButtonClicked=function()local VL1A=GUI.GetSelectedEntity()
local X=GUI.GetPlayerID()if
Logic.IsEntityInCategory(VL1A,EntityCategories.Storehouse)==1 then
GUI_Trade.MultiTabButtonClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:OnMultiTabClicked(X)end
GUI_BuildingInfo.StorageLimitUpdate_Orig_QSB_CastleStore=GUI_BuildingInfo.StorageLimitUpdate
GUI_BuildingInfo.StorageLimitUpdate=function()local FGzDGV=GUI.GetSelectedEntity()
local J7Bwul=GUI.GetPlayerID()if
Logic.IsEntityInCategory(FGzDGV,EntityCategories.Storehouse)==1 then
GUI_BuildingInfo.StorageLimitUpdate_Orig_QSB_CastleStore()return end
QSB.CastleStore:UpdateStorageLimit(J7Bwul)end
GUI_Interaction.SendGoodsClicked=function()
local cS,L2=GUI_Interaction.GetPotentialSubQuestAndType(g_Interaction.CurrentMessageQuestIndex)if not cS then return end
local SRm2=GUI_Interaction.GetPotentialSubQuestIndex(g_Interaction.CurrentMessageQuestIndex)local e=cS.Objectives[1].Data[1]
local kyb9GQ=cS.Objectives[1].Data[2]local lHEx={e,kyb9GQ}local nINusLz2,ix1VnfFX=AreCostsAffordable(lHEx,true)
local fEKaQyzs=GUI.GetPlayerID()
if
Logic.GetGoodCategoryForGoodType(e)==GoodCategories.GC_Resource then
ix1VnfFX=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_NotEnough_Resources")nINusLz2=false
if QSB.CastleStore:IsLocked(fEKaQyzs,e)then nINusLz2=
GetPlayerResources(e,fEKaQyzs)>=kyb9GQ else
nINusLz2=
(
GetPlayerResources(e,fEKaQyzs)+QSB.CastleStore:GetAmount(fEKaQyzs,e))>=kyb9GQ end end
local bxf5zvLH=cS.Objectives[1].Data[6]and
cS.Objectives[1].Data[6]or cS.SendingPlayer;local N8XF3=PlayerSectorTypes.Thief
local R=CanEntityReachTarget(bxf5zvLH,Logic.GetStoreHouse(GUI.GetPlayerID()),Logic.GetStoreHouse(bxf5zvLH),
nil,N8XF3)
if R==false then
local DzeDyBG=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_GenericUnreachable")Message(DzeDyBG)return end
if nINusLz2 ==true then Sound.FXPlay2DSound("ui\\menu_click")
GUI.QuestTemplate_SendGoods(SRm2)
GUI_FeedbackSpeech.Add("SpeechOnly_CartsSent",g_FeedbackSpeech.Categories.CartsUnderway,nil,nil)else Message(ix1VnfFX)end end
GUI_Tooltip.SetCosts=function(f,Dn6,Sf2dNg8)local i=XGUIEng.GetWidgetPathByID(f)
local eqxty=i.."/1Good"local dVuApQ=i.."/2Goods"local ebhWRw7=0;local Gj;local IQvmg2C;for fePNjzNA=2,#Dn6,2 do if Dn6[fePNjzNA]~=0 then
ebhWRw7=ebhWRw7+1 end end
if ebhWRw7 ==0 then
XGUIEng.ShowWidget(eqxty,0)XGUIEng.ShowWidget(dVuApQ,0)return elseif ebhWRw7 ==1 then
XGUIEng.ShowWidget(eqxty,1)XGUIEng.ShowWidget(dVuApQ,0)Gj=eqxty.."/Good1Of1"elseif
ebhWRw7 ==2 then XGUIEng.ShowWidget(eqxty,0)
XGUIEng.ShowWidget(dVuApQ,1)Gj=dVuApQ.."/Good1Of2"IQvmg2C=dVuApQ.."/Good2Of2"elseif ebhWRw7 >2 then
GUI.AddNote("Debug: Invalid Costs table. Not more than 2 GoodTypes allowed.")end;local DYz=1
for qb=1,#Dn6,2 do
if Dn6[qb+1]~=0 then local wG=Dn6[qb]local NqYh=Dn6[qb+1]local H;local C;if DYz==1 then H=Gj..
"/Icon"C=Gj.."/Amount"else H=IQvmg2C.."/Icon"
C=IQvmg2C.."/Amount"end
SetIcon(H,g_TexturePositions.Goods[wG],44)local je9=GUI.GetPlayerID()local raVMP
if Sf2dNg8 ==true then
raVMP=GetPlayerGoodsInSettlement(wG,je9,true)
if
Logic.GetGoodCategoryForGoodType(wG)==GoodCategories.GC_Resource then
if not QSB.CastleStore:IsLocked(je9,wG)then raVMP=raVMP+
QSB.CastleStore:GetAmount(je9,wG)end end else local jk7;local j
if wG==Goods.G_Gold then j=Logic.GetHeadquarters(je9)
jk7=Logic.GetIndexOnOutStockByGoodType(j,wG)else j=Logic.GetStoreHouse(je9)
jk7=Logic.GetIndexOnOutStockByGoodType(j,wG)end
if jk7 ~=-1 then raVMP=Logic.GetAmountOnOutStockByGoodType(j,wG)else
j=GUI.GetSelectedEntity()
if j~=nil then if Logic.GetIndexOnOutStockByGoodType(j,wG)==nil then
j=Logic.GetRefillerID(GUI.GetSelectedEntity())end
raVMP=Logic.GetAmountOnOutStockByGoodType(j,wG)else raVMP=0 end end end;local wvGS6zV=""if raVMP<NqYh then wvGS6zV="{@script:ColorRed}"end
if
NqYh>0 then
XGUIEng.SetText(C,"{center}"..wvGS6zV..NqYh)else XGUIEng.SetText(C,"")end;DYz=DYz+1 end end end end;Core:RegisterBundle("BundleCastleStore")API=API or{}QSB=
QSB or{}
function API.ActivateSingleStop()if not GUI then
API.Bridge("API.ActivateSingleStop()")return end
BundleBuildingButtons.Local:AddOptionalButton(2,BundleBuildingButtons.Local.ButtonDefaultSingleStop_Action,BundleBuildingButtons.Local.ButtonDefaultSingleStop_Tooltip,BundleBuildingButtons.Local.ButtonDefaultSingleStop_Update)end;ActivateSingleStop=API.ActivateSingleStop
function API.DeactivateSingleStop()if not GUI then
API.Bridge("API.DeactivateSingleStop()")return end
BundleBuildingButtons.Local:DeleteOptionalButton(2)end;DeactivateSingleStop=API.DeactivateSingleStop
function API.UseDowngrade(Zzf4Och)if not GUI then
API.Bridge(
"API.UseDowngrade("..tostring(Zzf4Och)..")")return end;BundleBuildingButtons.Local.Data.Downgrade=
Zzf4Och==true end;UseDowngrade=API.UseDowngrade
function API.UseBreedSheeps(Cj)if not GUI then API.Bridge("API.UseBreedSheeps("..
tostring(Cj)..")")
return end;BundleBuildingButtons.Local.Data.BreedSheeps=
Cj==true
if Cj==true then
local mZXPr1=MerchantSystem.BasePricesOrigBundleBuildingButtons[Goods.G_Sheep]MerchantSystem.BasePrices[Goods.G_Sheep]=mZXPr1
API.Bridge(
"MerchantSystem.BasePrices[Goods.G_Sheep] = "..mZXPr1)else
local bT=BundleBuildingButtons.Local.Data.SheepMoneyCost;MerchantSystem.BasePrices[Goods.G_Sheep]=bT
API.Bridge(
"MerchantSystem.BasePrices[Goods.G_Sheep] = "..bT)end end;UseBreedSheeps=API.UseBreedSheeps
function API.UseBreedCattle(Un)if not GUI then
API.Bridge("API.UseBreedCattle("..
tostring(Un)..")")return end;BundleBuildingButtons.Local.Data.BreedCattle=
Un==true
if Un==true then
local qRY1vSFl=MerchantSystem.BasePricesOrigBundleBuildingButtons[Goods.G_Cow]MerchantSystem.BasePrices[Goods.G_Cow]=qRY1vSFl
API.Bridge(
"MerchantSystem.BasePrices[Goods.G_Cow] = "..qRY1vSFl)else
local vrEhUe_a=BundleBuildingButtons.Local.Data.CattleMoneyCost;MerchantSystem.BasePrices[Goods.G_Cow]=vrEhUe_a
API.Bridge(
"MerchantSystem.BasePrices[Goods.G_Cow] = "..vrEhUe_a)end end;UseBreedCattle=API.UseBreedCattle
function API.SetSheepGrainCost(VQcat)
if not GUI then API.Bridge("API.SetSheepGrainCost("..
VQcat..")")return end
BundleBuildingButtons.Local.Data.SheepCosts=VQcat end;SetSheepGrainCost=API.SetSheepGrainCost
function API.SetCattleGrainCost(yxfb5r)if not GUI then
API.Bridge(
"API.SetCattleGrainCost("..yxfb5r..")")return end
BundleBuildingButtons.Local.Data.CattleCosts=yxfb5r end;SetCattleGrainCost=API.SetCattleGrainCost
function API.SetSheepNeeded(GuBfKo3)if not GUI then
API.Bridge("API.SetSheepNeeded("..
GuBfKo3 ..")")return end;if type(GuBfKo3)~="number"or
GuBfKo3 <0 or GuBfKo3 >5 then
API.Dbg("API.SetSheepNeeded: Needed amount is invalid!")end
BundleBuildingButtons.Local.Data.SheepNeeded=GuBfKo3 end;SetSheepNeeded=API.SetSheepNeeded
function API.SetCattleNeeded(zcXy)
if not GUI then API.Bridge("API.SetCattleNeeded("..
zcXy..")")return end;if type(zcXy)~="number"or zcXy<0 or zcXy>5 then
API.Dbg("API.SetCattleNeeded: Needed amount is invalid!")end
BundleBuildingButtons.Local.Data.CattleNeeded=zcXy end;SetCattleNeeded=API.SetCattleNeeded
function API.AddCustomBuildingButton(X7GI,ZOIyhzA,L7J1,D)
if not GUI then
API.Bridge(
"API.AddCustomBuildingButton("..tostring(X7GI)..
","..tostring(ZOIyhzA)..","..tostring(L7J1)..
","..tostring(D)..",)")return end;if
(type(X7GI)~="number"or(X7GI<1 or X7GI>2))then
API.Dbg("API.AddCustomBuildingButton: Index must be 1 or 2!")return end
if
(
type(ZOIyhzA)~="function"or type(L7J1)~="function"or type(D)~=
"function")then
API.Dbg("API.AddCustomBuildingButton: Action, tooltip and update must be functions!")return end;return
BundleBuildingButtons.Local:AddOptionalButton(X7GI,ZOIyhzA,L7J1,D)end;AddBuildingButton=API.AddCustomBuildingButton
function API.RemoveCustomBuildingButton(LxgPj)if not GUI then
API.Dbg(
"API.RemoveCustomBuildingButton("..tostring(LxgPj)..")")return end;if
(type(LxgPj)~="number"or(
LxgPj<1 or LxgPj>2))then
API.Dbg("API.RemoveCustomBuildingButton: Index must be 1 or 2!")return end;return
BundleBuildingButtons.Local:DeleteOptionalButton(LxgPj)end;DeleteBuildingButton=API.RemoveCustomBuildingButton
BundleBuildingButtons={Global={Data={}},Local={Data={OptionalButton1={UseButton=false},OptionalButton2={UseButton=false},StoppedBuildings={},Downgrade=true,BreedCattle=true,CattleCosts=10,CattleNeeded=3,CattleKnightTitle=0,CattleMoneyCost=300,BreedSheeps=true,SheepCosts=10,SheepNeeded=3,SheepKnightTitle=0,SheepMoneyCost=300},Description={Downgrade={Title={de="Rückbau",en="Downgrade"},Text={de="- Reißt eine Stufe des Geb?udes ein {cr}- Der überschüssige Arbeiter wird entlassen",en="- Destroy one level of this building {cr}- The surplus worker will be dismissed"},Disabled={de="Kann nicht zurückgebaut werden!",en="Can not be downgraded yet!"}},BuyCattle={Title={de="Nutztier kaufen",en="Buy Farm animal"},Text={de="- Kauft ein Nutztier {cr}- Nutztiere produzieren Rohstoffe",en="- Buy a farm animal {cr}- Farm animals produce resources"},Disabled={de="Kauf ist nicht möglich!",en="Buy not possible!"}},SingleStop={Title={de="Arbeit anhalten/aufnehmen",en="Start/Stop Work"},Text={de="- Startet oder stoppe die Arbeit in diesem Betrieb",en="- Continue or stop work for this building"}}}}}function BundleBuildingButtons.Global:Install()end
function BundleBuildingButtons.Local:Install()
MerchantSystem.BasePricesOrigBundleBuildingButtons={}
MerchantSystem.BasePricesOrigBundleBuildingButtons[Goods.G_Sheep]=MerchantSystem.BasePrices[Goods.G_Sheep]
MerchantSystem.BasePricesOrigBundleBuildingButtons[Goods.G_Cow]=MerchantSystem.BasePrices[Goods.G_Cow]
MerchantSystem.BasePrices[Goods.G_Sheep]=BundleBuildingButtons.Local.Data.SheepMoneyCost
MerchantSystem.BasePrices[Goods.G_Cow]=BundleBuildingButtons.Local.Data.CattleMoneyCost;self:OverwriteHouseMenuButtons()
self:OverwriteBuySiegeEngine()self:OverwriteToggleTrap()
self:OverwriteGateOpenClose()self:OverwriteAutoToggle()
Core:AppendFunction("GameCallback_GUI_SelectionChanged",self.OnSelectionChanged)end
function BundleBuildingButtons.Local:BuyAnimal(MBmUv)
Sound.FXPlay2DSound("ui\\menu_click")local D=Logic.GetEntityType(MBmUv)
if D==Entities.B_CattlePasture then local _wv=
BundleBuildingButtons.Local.Data.CattleCosts* (-1)
GUI.SendScriptCommand(
[[
            local pID = Logic.EntityGetPlayer(]]..
MBmUv..
[[)
            local x, y = Logic.GetBuildingApproachPosition(]]..MBmUv..

[[)
            Logic.CreateEntity(Entities.A_X_Cow01, x, y, 0, pID)
            AddGood(Goods.G_Grain, ]].._wv..[[, pID)
        ]])elseif D==Entities.B_SheepPasture then local MKUKw=
BundleBuildingButtons.Local.Data.SheepCosts* (-1)
GUI.SendScriptCommand(
[[
            local pID = Logic.EntityGetPlayer(]]..
MBmUv..
[[)
            local x, y = Logic.GetBuildingApproachPosition(]]..MBmUv..

[[)
            Logic.CreateEntity(Entities.A_X_Sheep01, x, y, 0, pID)
            AddGood(Goods.G_Grain, ]]..MKUKw..[[, pID)
        ]])end end
function BundleBuildingButtons.Local:DowngradeBuilding()
Sound.FXPlay2DSound("ui\\menu_click")local NNzyhb=GUI.GetSelectedEntity()
GUI.DeselectEntity(NNzyhb)
if Logic.GetUpgradeLevel(NNzyhb)>0 then local zu=math.ceil(
Logic.GetEntityMaxHealth(NNzyhb)/2)if
Logic.GetEntityHealth(NNzyhb)>=zu then
GUI.SendScriptCommand([[Logic.HurtEntity(]]..
NNzyhb..[[, ]]..zu..[[)]])end else
local MO9=Logic.GetEntityMaxHealth(NNzyhb)
GUI.SendScriptCommand([[Logic.HurtEntity(]]..NNzyhb..[[, ]]..MO9 ..[[)]])end end
function BundleBuildingButtons.Local:AddOptionalButton(mbYJW,IBl,WOZ8qcM,RO)
assert(mbYJW==1 or mbYJW==2)
local t5q0w5V={XGUIEng.GetWidgetID("/InGame/Root/Normal/BuildingButtons/GateAutoToggle"),XGUIEng.GetWidgetID("/InGame/Root/Normal/BuildingButtons/GateOpenClose")}
BundleBuildingButtons.Local.Data["OptionalButton"..mbYJW].WidgetID=t5q0w5V[mbYJW]
BundleBuildingButtons.Local.Data["OptionalButton"..mbYJW].UseButton=true
BundleBuildingButtons.Local.Data["OptionalButton"..mbYJW].ActionFunction=IBl
BundleBuildingButtons.Local.Data["OptionalButton"..mbYJW].TooltipFunction=WOZ8qcM
BundleBuildingButtons.Local.Data["OptionalButton"..mbYJW].UpdateFunction=RO end
function BundleBuildingButtons.Local:DeleteOptionalButton(rCTdwCsl)
assert(rCTdwCsl==1 or rCTdwCsl==2)
local y={XGUIEng.GetWidgetID("/InGame/Root/Normal/BuildingButtons/GateAutoToggle"),XGUIEng.GetWidgetID("/InGame/Root/Normal/BuildingButtons/GateOpenClose")}
BundleBuildingButtons.Local.Data["OptionalButton"..rCTdwCsl].WidgetID=y[rCTdwCsl]
BundleBuildingButtons.Local.Data["OptionalButton"..rCTdwCsl].UseButton=false;BundleBuildingButtons.Local.Data["OptionalButton"..rCTdwCsl].ActionFunction=
nil;BundleBuildingButtons.Local.Data[
"OptionalButton"..rCTdwCsl].TooltipFunction=
nil;BundleBuildingButtons.Local.Data[
"OptionalButton"..rCTdwCsl].UpdateFunction=
nil end
function BundleBuildingButtons.Local:OverwriteAutoToggle()
GUI_BuildingButtons.GateAutoToggleClicked=function()
local O5L62=XGUIEng.GetCurrentWidgetID()local kKb1MV=GUI.GetSelectedEntity()
if not
BundleBuildingButtons.Local.Data.OptionalButton1.ActionFunction then return end
BundleBuildingButtons.Local.Data.OptionalButton1.ActionFunction(O5L62,kKb1MV)end
GUI_BuildingButtons.GateAutoToggleMouseOver=function()
local uvj=XGUIEng.GetCurrentWidgetID()local h9ZpZN=GUI.GetSelectedEntity()
if not
BundleBuildingButtons.Local.Data.OptionalButton1.TooltipFunction then return end
BundleBuildingButtons.Local.Data.OptionalButton1.TooltipFunction(uvj,h9ZpZN)end
GUI_BuildingButtons.GateAutoToggleUpdate=function()
local Dz6XX9=XGUIEng.GetCurrentWidgetID()local M4b3cylW=GUI.GetSelectedEntity()
local GwhW=Logic.GetEntityMaxHealth(M4b3cylW)local hgyT=Logic.GetEntityHealth(M4b3cylW)
SetIcon(Dz6XX9,{8,16})
if



M4b3cylW==nil or Logic.IsBuilding(M4b3cylW)==0 or not
BundleBuildingButtons.Local.Data.OptionalButton1.UpdateFunction or not
BundleBuildingButtons.Local.Data.OptionalButton1.UseButton or Logic.IsConstructionComplete(M4b3cylW)==0 then XGUIEng.ShowWidget(Dz6XX9,0)return end
if


Logic.BuildingDoWorkersStrike(M4b3cylW)==true or
Logic.IsBuildingBeingUpgraded(M4b3cylW)==true or
Logic.IsBuildingBeingKnockedDown(M4b3cylW)==true or Logic.IsBurning(M4b3cylW)==true or GwhW-hgyT>0 then XGUIEng.ShowWidget(Dz6XX9,0)return end
BundleBuildingButtons.Local.Data.OptionalButton1.UpdateFunction(Dz6XX9,M4b3cylW)end end
function BundleBuildingButtons.Local:OverwriteGateOpenClose()
GUI_BuildingButtons.GateOpenCloseClicked=function()
local uh5F2f7=XGUIEng.GetCurrentWidgetID()local fJvrDfHT=GUI.GetSelectedEntity()
if not
BundleBuildingButtons.Local.Data.OptionalButton2.ActionFunction then return end
BundleBuildingButtons.Local.Data.OptionalButton2.ActionFunction(uh5F2f7,fJvrDfHT)end
GUI_BuildingButtons.GateOpenCloseMouseOver=function()
local CgwWT2=XGUIEng.GetCurrentWidgetID()local o=GUI.GetSelectedEntity()
if not
BundleBuildingButtons.Local.Data.OptionalButton2.TooltipFunction then return end
BundleBuildingButtons.Local.Data.OptionalButton2.TooltipFunction(CgwWT2,o)end
GUI_BuildingButtons.GateOpenCloseUpdate=function()
local i=XGUIEng.GetCurrentWidgetID()local jI=GUI.GetSelectedEntity()
local KcJAj5UN=Logic.GetEntityMaxHealth(jI)local cPV=Logic.GetEntityHealth(jI)SetIcon(i,{8,16})
if




jI==nil or Logic.IsBuilding(jI)==0 or not
BundleBuildingButtons.Local.Data.OptionalButton2.UpdateFunction or not
BundleBuildingButtons.Local.Data.OptionalButton2.UseButton or Logic.IsConstructionComplete(jI)==0 or Logic.IsBuilding(jI)==0 then XGUIEng.ShowWidget(i,0)return end
if


Logic.BuildingDoWorkersStrike(jI)==true or
Logic.IsBuildingBeingUpgraded(jI)==true or
Logic.IsBuildingBeingKnockedDown(jI)==true or Logic.IsBurning(jI)==true or KcJAj5UN-cPV>0 then XGUIEng.ShowWidget(i,0)return end
BundleBuildingButtons.Local.Data.OptionalButton2.UpdateFunction(i,jI)end end
function BundleBuildingButtons.Local:OverwriteToggleTrap()
GUI_BuildingButtons.TrapToggleClicked=function()
BundleBuildingButtons.Local:DowngradeBuilding()end
GUI_BuildingButtons.TrapToggleMouseOver=function()
local rjhFCKf=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
BundleBuildingButtons.Local:TextNormal(BundleBuildingButtons.Local.Description.Downgrade.Title[rjhFCKf],BundleBuildingButtons.Local.Description.Downgrade.Text[rjhFCKf],BundleBuildingButtons.Local.Description.Downgrade.Disabled[rjhFCKf])end
GUI_BuildingButtons.TrapToggleUpdate=function()
local ZiQ=XGUIEng.GetCurrentWidgetID()local BR=GUI.GetSelectedEntity()
local PAu=Logic.GetEntityName(BR)local DvNist5k=Logic.GetEntityType(BR)
local a=GetTerritoryUnderEntity(BR)local n3pW=Logic.GetEntityMaxHealth(BR)
local YZcKfKLY=Logic.GetEntityHealth(BR)local VJa=Logic.GetUpgradeLevel(BR)
local w6woX8G,dmf8vR_C=XGUIEng.GetWidgetLocalPosition("/InGame/Root/Normal/BuildingButtons/Upgrade")SetIcon(ZiQ,{3,15})
XGUIEng.SetWidgetLocalPosition(ZiQ,w6woX8G+64,dmf8vR_C)if BR==nil or Logic.IsBuilding(BR)==0 then
XGUIEng.ShowWidget(ZiQ,0)return end
if BundleConstructionControl then
if
Inside(PAu,BundleConstructionControl.Local.Data.Entities)then XGUIEng.ShowWidget(ZiQ,0)return end
if
Inside(DvNist5k,BundleConstructionControl.Local.Data.EntityTypes)then XGUIEng.ShowWidget(ZiQ,0)return end
if
Inside(a,BundleConstructionControl.Local.Data.OnTerritory)then XGUIEng.ShowWidget(ZiQ,0)return end
for RHNsiE9_,USNU in
pairs(BundleConstructionControl.Local.Data.EntityCategories)do if Logic.IsEntityInCategory(_BuildingID,USNU)==1 then
XGUIEng.ShowWidget(ZiQ,0)return end end end
if


Logic.IsConstructionComplete(BR)==0 or
(
Logic.IsEntityInCategory(BR,EntityCategories.OuterRimBuilding)==0 and
Logic.IsEntityInCategory(BR,EntityCategories.CityBuilding)==0)or
not BundleBuildingButtons.Local.Data.Downgrade or VJa==0 then XGUIEng.ShowWidget(ZiQ,0)return end
if


Logic.BuildingDoWorkersStrike(BR)==true or
Logic.IsBuildingBeingUpgraded(BR)==true or
Logic.IsBuildingBeingKnockedDown(BR)==true or Logic.IsBurning(BR)==true or n3pW-YZcKfKLY>0 then XGUIEng.DisableButton(ZiQ,1)else
XGUIEng.DisableButton(ZiQ,0)end end end
function BundleBuildingButtons.Local:OverwriteBuySiegeEngine()
GUI_BuildingButtons.BuySiegeEngineCartMouseOver=function(lE,UVY6A9)
local h6i3v27=(
Network.GetDesiredLanguage()=="de"and"de")or"en"local k=XGUIEng.GetCurrentWidgetID()
local KfVB=GUI.GetSelectedEntity()local Mbf3=Logic.GetEntityType(KfVB)
if
Mbf3 ~=Entities.B_SiegeEngineWorkshop and Mbf3 ~=Entities.B_CattlePasture and Mbf3 ~=
Entities.B_SheepPasture then return end;local cE6={Logic.GetUnitCost(KfVB,lE)}
if Mbf3 ==
Entities.B_CattlePasture then
BundleBuildingButtons.Local:TextCosts(BundleBuildingButtons.Local.Description.BuyCattle.Title[h6i3v27],BundleBuildingButtons.Local.Description.BuyCattle.Text[h6i3v27],BundleBuildingButtons.Local.Description.BuyCattle.Disabled[h6i3v27],{Goods.G_Grain,BundleBuildingButtons.Local.Data.CattleCosts},false)elseif Mbf3 ==Entities.B_SheepPasture then
BundleBuildingButtons.Local:TextCosts(BundleBuildingButtons.Local.Description.BuyCattle.Title[h6i3v27],BundleBuildingButtons.Local.Description.BuyCattle.Text[h6i3v27],BundleBuildingButtons.Local.Description.BuyCattle.Disabled[h6i3v27],{Goods.G_Grain,BundleBuildingButtons.Local.Data.SheepCosts},false)else GUI_Tooltip.TooltipBuy(cE6,nil,nil,UVY6A9)end end
GUI_BuildingButtons.BuySiegeEngineCartClicked_OrigTHEA_Buildings=GUI_BuildingButtons.BuySiegeEngineCartClicked
GUI_BuildingButtons.BuySiegeEngineCartClicked=function(MLldrp)local Vt8=GUI.GetSelectedEntity()
local O_=GUI.GetPlayerID()local U8eVjmxU=Logic.GetEntityType(Vt8)
if
U8eVjmxU==Entities.B_CattlePasture or U8eVjmxU==Entities.B_SheepPasture then
BundleBuildingButtons.Local:BuyAnimal(Vt8)else
GUI_BuildingButtons.BuySiegeEngineCartClicked_OrigTHEA_Buildings(MLldrp)end end
GUI_BuildingButtons.BuySiegeEngineCartUpdate=function(HvSMI)local Sj8=GUI.GetPlayerID()
local uh=Logic.GetKnightTitle(Sj8)local TRBGQi=XGUIEng.GetCurrentWidgetID()
local MfwnUbM=GUI.GetSelectedEntity()local vuDEK=Logic.GetEntityType(MfwnUbM)
local XNkc=GetPlayerResources(Goods.G_Grain,Sj8)local QBDSr=GetPosition(MfwnUbM)
if vuDEK==Entities.B_SiegeEngineWorkshop then
XGUIEng.ShowWidget(TRBGQi,1)
if HvSMI==Technologies.R_BatteringRam then SetIcon(TRBGQi,{9,5})elseif HvSMI==
Technologies.R_SiegeTower then SetIcon(TRBGQi,{9,6})elseif
HvSMI==Technologies.R_Catapult then SetIcon(TRBGQi,{9,4})end elseif vuDEK==Entities.B_CattlePasture then
local b_=GetPlayerEntities(Sj8,Entities.B_CattlePasture)
local PB={Logic.GetPlayerEntitiesInArea(Sj8,Entities.A_X_Cow01,QBDSr.X,QBDSr.Y,800,16)}
local o=Logic.GetNumberOfPlayerEntitiesInCategory(Sj8,EntityCategories.CattlePasture)local W=#b_*5;SetIcon(TRBGQi,{3,16})
if
HvSMI==Technologies.R_Catapult then
if BundleBuildingButtons.Local.Data.BreedCattle then
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/BuyCatapultCart",1)
if o>=W then XGUIEng.DisableButton(TRBGQi,1)elseif XNkc<
BundleBuildingButtons.Local.Data.CattleCosts then XGUIEng.DisableButton(TRBGQi,1)elseif uh<
BundleBuildingButtons.Local.Data.CattleKnightTitle then
XGUIEng.DisableButton(TRBGQi,1)elseif
PB[1]<BundleBuildingButtons.Local.Data.CattleNeeded then XGUIEng.DisableButton(TRBGQi,1)else
XGUIEng.DisableButton(TRBGQi,0)end end else XGUIEng.ShowWidget(TRBGQi,0)end elseif vuDEK==Entities.B_SheepPasture then
local x=GetPlayerEntities(Sj8,Entities.B_SheepPasture)
local xWN={Logic.GetPlayerEntitiesInArea(Sj8,Entities.A_X_Sheep01,QBDSr.X,QBDSr.Y,800,16)}table.remove(xWN,1)
local dq={Logic.GetPlayerEntitiesInArea(Sj8,Entities.A_X_Sheep02,QBDSr.X,QBDSr.Y,800,16)}table.remove(dq,1)
local R2rDj=Logic.GetNumberOfPlayerEntitiesInCategory(Sj8,EntityCategories.SheepPasture)local N0f6ekP=#x*5;xWN=Array_Append(xWN,dq)
SetIcon(TRBGQi,{4,1})
if HvSMI==Technologies.R_Catapult then
if
BundleBuildingButtons.Local.Data.BreedSheeps then
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/BuyCatapultCart",1)
if R2rDj>=N0f6ekP then XGUIEng.DisableButton(TRBGQi,1)elseif XNkc<
BundleBuildingButtons.Local.Data.SheepCosts then XGUIEng.DisableButton(TRBGQi,1)elseif

#xWN<BundleBuildingButtons.Local.Data.SheepKnightTitle then XGUIEng.DisableButton(TRBGQi,1)elseif#xWN<
BundleBuildingButtons.Local.Data.SheepNeeded then XGUIEng.DisableButton(TRBGQi,1)else
XGUIEng.DisableButton(TRBGQi,0)end end else XGUIEng.ShowWidget(TRBGQi,0)end else XGUIEng.ShowWidget(TRBGQi,0)return end
if
Logic.IsConstructionComplete(GUI.GetSelectedEntity())==0 then XGUIEng.ShowWidget(TRBGQi,0)return end
if
vuDEK~=Entities.B_SheepPasture and vuDEK~=Entities.B_CattlePasture then local HMfwtsu=Logic.TechnologyGetState(Sj8,HvSMI)if
EnableRights==nil or EnableRights==false then
XGUIEng.DisableButton(TRBGQi,0)return end;if
HMfwtsu==TechnologyStates.Researched then XGUIEng.DisableButton(TRBGQi,0)else
XGUIEng.DisableButton(TRBGQi,1)end end end end
function BundleBuildingButtons.Local:OverwriteHouseMenuButtons()
HouseMenuStopProductionClicked_Orig_tHEA_SingleStop=HouseMenuStopProductionClicked
HouseMenuStopProductionClicked=function()
HouseMenuStopProductionClicked_Orig_tHEA_SingleStop()local ZNfmbrR=HouseMenu.Widget.CurrentBuilding
local SfT02=Entities[ZNfmbrR]local ljsI=GUI.GetPlayerID()
local ez=GetPlayerEntities(ljsI,SfT02)
for kyUU=1,#ez,1 do
if
BundleBuildingButtons.Local.Data.StoppedBuildings[ez[kyUU]]~=HouseMenu.StopProductionBool then
BundleBuildingButtons.Local.Data.StoppedBuildings[ez[kyUU]]=HouseMenu.StopProductionBool
GUI.SetStoppedState(ez[kyUU],HouseMenu.StopProductionBool)end end end end
function BundleBuildingButtons.Local:HouseMenuIcon(bbe8l,aMhYr)
if type(aMhYr)=="table"then
if
type(aMhYr[3])=="string"then local aI5j0=1
if XGUIEng.IsButton(bbe8l)==1 then aI5j0=7 end;local y,uDP,B12w89Bo,hyCfIcL;y=(_Coordinates[1]-1)*64;B12w89Bo=(
_Coordinates[2]-1)*64
uDP=(_Coordinates[1])*64;hyCfIcL=(_Coordinates[2])*64
XGUIEng.SetMaterialAlpha(bbe8l,aI5j0,255)
XGUIEng.SetMaterialTexture(bbe8l,aI5j0,aMhYr[3].."big.png")
XGUIEng.SetMaterialUV(bbe8l,aI5j0,y,B12w89Bo,uDP,hyCfIcL)else SetIcon(bbe8l,aMhYr)end else local AO={GUI.GetScreenSize()}local sRw=330
if AO[2]>=800 then sRw=260 end;if AO[2]>=1000 then sRw=210 end
XGUIEng.SetMaterialAlpha(bbe8l,1,255)XGUIEng.SetMaterialTexture(bbe8l,1,_file)
XGUIEng.SetMaterialUV(bbe8l,1,0,0,sRw,sRw)end end
function BundleBuildingButtons.Local:TextNormal(Ku67aT,X6JT3G,B9J6)
local JETGHKBR="/InGame/Root/Normal/TooltipNormal"local uy6Y=XGUIEng.GetWidgetID(JETGHKBR)local QEa7qV2=XGUIEng.GetWidgetID(JETGHKBR..
"/FadeIn/Name")local px42=XGUIEng.GetWidgetID(
JETGHKBR.."/FadeIn/Text")local OIYDRIKK=XGUIEng.GetWidgetID(
JETGHKBR.."/FadeIn/BG")local ZgwAT=XGUIEng.GetWidgetID(
JETGHKBR.."/FadeIn")
local b=XGUIEng.GetCurrentWidgetID()GUI_Tooltip.ResizeBG(OIYDRIKK,px42)
local O8Dg4j0v={OIYDRIKK}GUI_Tooltip.SetPosition(uy6Y,O8Dg4j0v,b)
GUI_Tooltip.FadeInTooltip(ZgwAT)B9J6=B9J6 or""local HyDK=""
if XGUIEng.IsButtonDisabled(b)==1 and
B9J6 ~=""and X6JT3G~=""then HyDK=HyDK..
"{cr}{@color:255,32,32,255}"..B9J6 end;XGUIEng.SetText(QEa7qV2,"{center}"..Ku67aT)XGUIEng.SetText(px42,
X6JT3G..HyDK)
local p=XGUIEng.GetTextHeight(px42,true)local CKr3oxH,YdJr=XGUIEng.GetWidgetSize(px42)
XGUIEng.SetWidgetSize(px42,CKr3oxH,p)end
function BundleBuildingButtons.Local:TextCosts(uhi,KSGwA0z,y52A,_5K,h_tE63z)
local AXp="/InGame/Root/Normal/TooltipBuy"local m3bEUGF=XGUIEng.GetWidgetID(AXp)
local Ynl2dx28=XGUIEng.GetWidgetID(AXp.."/FadeIn/Name")
local oa=XGUIEng.GetWidgetID(AXp.."/FadeIn/Text")local BSt5TDUq=XGUIEng.GetWidgetID(AXp.."/FadeIn/BG")local wNNoSq=XGUIEng.GetWidgetID(
AXp.."/FadeIn")
local ogcV=XGUIEng.GetWidgetID(AXp.."/Costs")local BGI=XGUIEng.GetCurrentWidgetID()
GUI_Tooltip.ResizeBG(BSt5TDUq,oa)GUI_Tooltip.SetCosts(ogcV,_5K,h_tE63z)
local T={m3bEUGF,ogcV,BSt5TDUq}GUI_Tooltip.SetPosition(m3bEUGF,T,BGI,nil,true)
GUI_Tooltip.OrderTooltip(T,wNNoSq,ogcV,BGI,BSt5TDUq)GUI_Tooltip.FadeInTooltip(wNNoSq)y52A=y52A or""
local THbSG8=""
if
XGUIEng.IsButtonDisabled(BGI)==1 and y52A~=""and KSGwA0z~=""then THbSG8=THbSG8 ..
"{cr}{@color:255,32,32,255}"..y52A end;XGUIEng.SetText(Ynl2dx28,"{center}"..uhi)XGUIEng.SetText(oa,
KSGwA0z..THbSG8)
local oE=XGUIEng.GetTextHeight(oa,true)local ae,Z1ceWAUw=XGUIEng.GetWidgetSize(oa)
XGUIEng.SetWidgetSize(oa,ae,oE)end
function BundleBuildingButtons.Local.ButtonDefaultSingleStop_Action(dnHSEBJ,I0NG)local PD_cG=
BundleBuildingButtons.Local.Data.StoppedBuildings[I0NG]==true;GUI.SetStoppedState(I0NG,
not PD_cG)BundleBuildingButtons.Local.Data.StoppedBuildings[I0NG]=
not PD_cG end
function BundleBuildingButtons.Local.ButtonDefaultSingleStop_Tooltip(psE3ibXp,mQvK)
local d=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
BundleBuildingButtons.Local:TextNormal(BundleBuildingButtons.Local.Description.SingleStop.Title[d],BundleBuildingButtons.Local.Description.SingleStop.Text[d])end
function BundleBuildingButtons.Local.ButtonDefaultSingleStop_Update(NMz01zB,T0KzcuMx)
local AhxH=
Logic.IsEntityInCategory(T0KzcuMx,EntityCategories.OuterRimBuilding)==1
local nFN=Logic.IsEntityInCategory(T0KzcuMx,EntityCategories.CityBuilding)==1;if AhxH==false and nFN==false then
XGUIEng.ShowWidget(NMz01zB,0)end;if
BundleBuildingButtons.Local.Data.StoppedBuildings[T0KzcuMx]==true then SetIcon(NMz01zB,{4,12})else
SetIcon(NMz01zB,{4,13})end end
function BundleBuildingButtons.Local.OnSelectionChanged(JfIQI8q1)
local bpX=GUI.GetSelectedEntity()local LZgD=Logic.GetEntityType(bpX)
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/GateAutoToggle",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/GateOpenClose",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/TrapToggle",1)end;Core:RegisterBundle("BundleBuildingButtons")
API=API or{}QSB=QSB or{}QSB.IOList={}
function API.SetupInteractiveObject(Rk,dEq)if GUI then
API.Dbg("API.SetupInteractiveObject: Can not be used from local enviorment!")return end;if not IsExisting(Rk)then
API.Dbg(
"API.SetupInteractiveObject: Entity \""..Rk.."\" is invalid!")return end;dEq.Name=Rk;return
BundleInteractiveObjects.Global:CreateObject(dEq)end;SetupInteractiveObject=API.SetupInteractiveObject
function API.CreateObject(TBN)if GUI then
API.Dbg("API.CreateObject: Can not be used from local enviorment!")return end;return
BundleInteractiveObjects.Global:CreateObject(TBN)end;CreateObject=API.CreateObject
function API.RemoveInteractiveObject(qstqnyi)if GUI then
API.Bridge("API.RemoveInteractiveObject('"..
qstqnyi.."')")return end;if not IsExisting(qstqnyi)then
API.Warn(
"API.RemoveInteractiveObject: Entity \""..qstqnyi.."\" is invalid!")return end;return
BundleInteractiveObjects.Global:RemoveInteractiveObject(qstqnyi)end;RemoveInteractiveObject=API.RemoveInteractiveObject
function API.InteractiveObjectActivate(gNaS8Woq,Lj)if GUI then
API.Bridge(
"API.InteractiveObjectActivate('"..gNaS8Woq.."', "..tostring(Lj)..")")return end;if
not IsExisting(gNaS8Woq)then
API.Warn("API.InteractiveObjectActivate: Entity \""..gNaS8Woq.."\" is invalid!")return end
if not
Logic.IsInteractiveObject(GetID(gNaS8Woq))then if IO[gNaS8Woq]then IO[gNaS8Woq].Inactive=false
IO[gNaS8Woq].Used=false end else
API.ActivateIO(gNaS8Woq,Lj)end end;InteractiveObjectActivate=API.InteractiveObjectActivate
function API.InteractiveObjectDeactivate(CFD)if GUI then
API.Bridge(
"API.InteractiveObjectDeactivate('"..CFD.."')")return end;if not IsExisting(CFD)then
API.Warn(
"API.InteractiveObjectDeactivate: Entity \""..CFD.."\" is invalid!")return end;if not
Logic.IsInteractiveObject(GetID(CFD))then if IO[CFD]then IO[CFD].Inactive=true end else
API.DeactivateIO(CFD)end end;InteractiveObjectDeactivate=API.InteractiveObjectDeactivate
function API.AddCustomIOName(pjv,ePWz1yOf)
if type(
ePWz1yOf=="table")then
local _q5TOY=(Network.GetDesiredLanguage()=="de"and
"de")or"en"ePWz1yOf=ePWz1yOf[_q5TOY]end;if GUI then
API.Bridge("API.AddCustomIOName('"..pjv.."', '"..ePWz1yOf.."')")return end;return
BundleInteractiveObjects.Global:AddCustomIOName(pjv,ePWz1yOf)end;AddCustomIOName=API.AddCustomIOName
BundleInteractiveObjects={Global={Data={}},Local={Data={IOCustomNames={},IOCustomNamesByEntityName={}}}}
function BundleInteractiveObjects.Global:Install()IO={}end
function BundleInteractiveObjects.Global:CreateObject(Qh)
local BnR4=Network.GetDesiredLanguage()self:HackOnInteractionEvent()
self:RemoveInteractiveObject(Qh.Name)
if type(Qh.Title)=="table"then Qh.Title=Qh.Title[BnR4]end
if not Qh.Title or Qh.Title==""then Qh.Title=
(BnR4 =="de"and"Interaktion")or"Interaction"end
if type(Qh.Text)=="table"then Qh.Text=Qh.Text[BnR4]end;if not Qh.Text then Qh.Text=""end;if type(Qh.WrongKnight)=="table"then
Qh.WrongKnight=Qh.WrongKnight[BnR4]end
Qh.WrongKnight=Qh.WrongKnight or""if type(Qh.ConditionUnfulfilled)=="table"then
Qh.ConditionUnfulfilled=Qh.ConditionUnfulfilled[BnR4]end;Qh.ConditionUnfulfilled=
Qh.ConditionUnfulfilled or""Qh.Condition=Qh.Condition or
function()return true end
Qh.Callback=Qh.Callback or function()end;Qh.Distance=Qh.Distance or 1200
Qh.Waittime=Qh.Waittime or 15;Qh.Texture=Qh.Texture or{14,10}Qh.Reward=Qh.Reward or{}Qh.Costs=
Qh.Costs or{}Qh.State=Qh.State or 0
Logic.ExecuteInLuaLocalState(
[[
        QSB.IOList[#QSB.IOList+1] = "]]..
Qh.Name..
[["
        if not BundleInteractiveObjects.Local.Data.InteractionHackStarted then
            BundleInteractiveObjects.Local:ActivateInteractiveObjectControl()
            BundleInteractiveObjects.Local.Data.InteractionHackStarted = true;
        end
    ]])IO[Qh.Name]=API.InstanceTable(Qh)local IYm=GetID(Qh.Name)
if
Logic.IsInteractiveObject(IYm)==true then
Logic.InteractiveObjectClearCosts(IYm)Logic.InteractiveObjectClearRewards(IYm)
Logic.InteractiveObjectSetInteractionDistance(IYm,Qh.Distance)
Logic.InteractiveObjectSetTimeToOpen(IYm,Qh.Waittime)
Logic.InteractiveObjectAddRewards(IYm,Qh.Reward[1],Qh.Reward[2])
Logic.InteractiveObjectAddCosts(IYm,Qh.Costs[1],Qh.Costs[2])
Logic.InteractiveObjectAddCosts(IYm,Qh.Costs[3],Qh.Costs[4])Logic.InteractiveObjectSetAvailability(IYm,true)
Logic.InteractiveObjectSetPlayerState(IYm,
Qh.PlayerID or 1,Qh.State)
Logic.InteractiveObjectSetRewardResourceCartType(IYm,Entities.U_ResourceMerchant)
Logic.InteractiveObjectSetRewardGoldCartType(IYm,Entities.U_GoldCart)
Logic.InteractiveObjectSetCostGoldCartType(IYm,Entities.U_GoldCart)
Logic.InteractiveObjectSetCostResourceCartType(IYm,Entities.U_ResourceMerchant)table.insert(HiddenTreasures,IYm)end end
function BundleInteractiveObjects.Global:RemoveInteractiveObject(qlEsxT)
for ClpHl,DtLnlX in pairs(IO)do
if ClpHl==qlEsxT then
Logic.ExecuteInLuaLocalState(
[[
                IO["]]..qlEsxT..[["] = nil;
            ]])IO[qlEsxT]=nil end end end
function BundleInteractiveObjects.Global:AddCustomIOName(nc,B)
if type(B)=="table"then
local dAR=B.de;local BpOojmKs=B.en
Logic.ExecuteInLuaLocalState([[
            BundleInteractiveObjects.Local.Data.IOCustomNames["]]..nc..

[["] = {
                de = "]]..dAR..
[[",
                en = "]]..BpOojmKs..[["
            }
        ]])else
Logic.ExecuteInLuaLocalState([[
            BundleInteractiveObjects.Local.Data.IOCustomNames["]]..nc..
[["] = "]]..B..[["
        ]])end end
function BundleInteractiveObjects.Global:HackOnInteractionEvent()
if not
BundleInteractiveObjects.Global.Data.InteractionEventHacked then
StartSimpleJobEx(BundleInteractiveObjects.Global.ControlInteractiveObjects)
BundleInteractiveObjects.Global.Data.InteractionEventHacked=true
OnTreasureFound=function(DJnI_Wb,Kk5)
for oOM0P=1,#HiddenTreasures do local AZJ=HiddenTreasures[oOM0P]
if AZJ==DJnI_Wb then
Logic.InteractiveObjectSetAvailability(DJnI_Wb,false)for mNvYGn2p=1,8 do
Logic.InteractiveObjectSetPlayerState(DJnI_Wb,mNvYGn2p,2)end
table.remove(HiddenTreasures,oOM0P)HiddenTreasures[0]=#HiddenTreasures;local g_5="menu_left_prestige"
local sxUI=Logic.GetEntityName(DJnI_Wb)if IO[sxUI]and IO[sxUI].ActivationSound then
g_5=IO[sxUI].ActivationSound end
Logic.ExecuteInLuaLocalState("Play2DSound("..Kk5 ..
",'"..g_5 .."')")end end end
GameCallback_OnObjectInteraction=function(UrvQ,y0)OnInteractiveObjectOpened(UrvQ,y0)
OnTreasureFound(UrvQ,y0)local hXRf=Logic.GetEntityName(UrvQ)
for YtQ,PxKEaHwr in pairs(IO)do if YtQ==hXRf then
if
not PxKEaHwr.Used then IO[YtQ].Used=true;PxKEaHwr.Callback(PxKEaHwr,y0)end end end end
GameCallback_ExecuteCustomObjectReward=function(KJFFNd,ld,GfW,jYBYw1Yj)
if
not Logic.IsInteractiveObject(GetID(ld))then local f4_uPJ9=GetPosition(ld)
local MHsOhBmb=Logic.GetGoodCategoryForGoodType(GfW)local E
if MHsOhBmb==GoodCategories.GC_Resource then
E=Logic.CreateEntityOnUnblockedLand(Entities.U_ResourceMerchant,f4_uPJ9.X,f4_uPJ9.Y,0,KJFFNd)elseif GfW==Goods.G_Medicine then
E=Logic.CreateEntityOnUnblockedLand(Entities.U_Medicus,f4_uPJ9.X,f4_uPJ9.Y,0,KJFFNd)elseif GfW==Goods.G_Gold then
E=Logic.CreateEntityOnUnblockedLand(Entities.U_GoldCart,f4_uPJ9.X,f4_uPJ9.Y,0,KJFFNd)else
E=Logic.CreateEntityOnUnblockedLand(Entities.U_Marketer,f4_uPJ9.X,f4_uPJ9.Y,0,KJFFNd)end;Logic.HireMerchant(E,KJFFNd,GfW,jYBYw1Yj,KJFFNd)end end
function QuestTemplate:AreObjectsActivated(UO_sFF)
for fT2K1s=1,UO_sFF[0]do if not UO_sFF[-fT2K1s]then
UO_sFF[-fT2K1s]=GetEntityId(UO_sFF[fT2K1s])end
local OFZ6Sn=Logic.GetEntityName(UO_sFF[-fT2K1s])local zy0R=IO[OFZ6Sn]
if Logic.IsInteractiveObject(UO_sFF[-fT2K1s])then
if not IsInteractiveObjectOpen(UO_sFF[
-fT2K1s])then return false end else if not zy0R then return false end
if zy0R.Used~=true then return false end end end;return true end end end
function BundleInteractiveObjects.Global.ControlInteractiveObjects()for z_557jE,fJ0 in pairs(IO)do
if
not fJ0.Used==true then fJ0.ConditionFullfilled=fJ0.Condition(fJ0)end end end;function BundleInteractiveObjects.Local:Install()
IO=Logic.CreateReferenceToTableInGlobaLuaState("IO")end
function BundleInteractiveObjects.Local:CanBeBought(TR8S4gVl,zyErVr,mu_)
local OxT=GetPlayerGoodsInSettlement(zyErVr,TR8S4gVl,true)if OxT<mu_ then return false end;return true end
function BundleInteractiveObjects.Local:BuyObject(HIT,pRc,H)
if

Logic.GetGoodCategoryForGoodType(pRc)~=GoodCategories.GC_Resource and pRc~=Goods.G_Gold then local kWV_=GetPlayerEntities(HIT,0)local yy=H
for Y8e=1,#kWV_ do
if
Logic.IsBuilding(kWV_[Y8e])==1 and yy>0 then
if
Logic.GetBuildingProduct(kWV_[Y8e])==pRc then
local jnHv9kuE=Logic.GetAmountOnOutStockByIndex(kWV_[Y8e],0)for cP8iiWL=1,jnHv9kuE do
API.Bridge("Logic.RemoveGoodFromStock("..kWV_[Y8e]..","..pRc..",1)")yy=yy-1 end end end end else
API.Bridge("AddGood("..
pRc..",".. (H* (-1))..","..HIT..")")end end
function BundleInteractiveObjects.Local:ActivateInteractiveObjectControl()g_Interaction.ActiveObjectsOnScreen=
g_Interaction.ActiveObjectsOnScreen or{}g_Interaction.ActiveObjects=
g_Interaction.ActiveObjects or{}
GUI_Interaction.InteractiveObjectUpdate=function()
local sQ=GUI.GetPlayerID()if g_Interaction.ActiveObjects==nil then return end
for HV=1,#
g_Interaction.ActiveObjects do local Ylj1_p=g_Interaction.ActiveObjects[HV]
local HyUmK,TbIZ=GUI.GetEntityInfoScreenPosition(Ylj1_p)local pKD,dtj=GUI.GetScreenSize()
if

HyUmK~=0 and TbIZ~=0 and HyUmK>-50 and TbIZ>-50 and HyUmK< (pKD+50)and TbIZ< (dtj+50)then if
Inside(Ylj1_p,g_Interaction.ActiveObjectsOnScreen)==false then
table.insert(g_Interaction.ActiveObjectsOnScreen,Ylj1_p)end else
for HV=1,#
g_Interaction.ActiveObjectsOnScreen do if
g_Interaction.ActiveObjectsOnScreen[HV]==Ylj1_p then
table.remove(g_Interaction.ActiveObjectsOnScreen,HV)end end end end
for B4k2=1,#g_Interaction.ActiveObjectsOnScreen do
local Qwj="/InGame/Root/Normal/InteractiveObjects/"..B4k2
if XGUIEng.IsWidgetExisting(Qwj)==1 then
local ASt=g_Interaction.ActiveObjectsOnScreen[B4k2]local akg8dT=Logic.GetEntityType(ASt)
local hBMTgj3,n=GUI.GetEntityInfoScreenPosition(ASt)local qkN0={XGUIEng.GetWidgetScreenSize(Qwj)}
local BC3W={Logic.InteractiveObjectGetCosts(ASt)}
local wF={Logic.InteractiveObjectGetEffectiveCosts(ASt,sQ)}local Q4jh1Kak=Logic.InteractiveObjectGetAvailability(ASt)
local R=Logic.GetEntityType(ASt)local Qz=Logic.GetEntityName(ASt)
local u=Logic.GetEntityTypeName(R)local pyRL4R=false
XGUIEng.SetWidgetScreenPosition(Qwj,hBMTgj3- (qkN0[1]/2),n-
(qkN0[2]/2))if BC3W[1]~=nil and wF[1]==nil and Q4jh1Kak==true then
pyRL4R=true end
local hNh=Logic.InteractiveObjectHasPlayerEnoughSpaceForRewards(ASt,sQ)if hNh==false then pyRL4R=true end
if pyRL4R==true then
XGUIEng.DisableButton(Qwj,1)else XGUIEng.DisableButton(Qwj,0)end;if GUI_Interaction.InteractiveObjectUpdateEx1 ~=nil then
GUI_Interaction.InteractiveObjectUpdateEx1(Qwj,akg8dT)end;if IO[Qz]then
BundleInteractiveObjects.Local:SetIcon(Qwj,IO[Qz].Texture)end
XGUIEng.ShowWidget(Qwj,1)end end
for Lbo6veiM,JU53A5W in pairs(QSB.IOList)do local cWpGi=GUI.GetPlayerID()
local uwdKc=Logic.GetEntityType(GetID(JU53A5W))local RY9dg5wU=Logic.GetEntityTypeName(uwdKc)
if
RY9dg5wU and JU53A5W~=""then
if
not(string.find(RY9dg5wU,"I_X_"))and not
(string.find(RY9dg5wU,"Mine"))and not
(string.find(RY9dg5wU,"B_Wel"))and not
(string.find(RY9dg5wU,"B_Cis"))then
if
IO[JU53A5W].State==0 and IO[JU53A5W].Distance~=nil and IO[JU53A5W].Distance>0 then
local BMJ6ZOU={}Logic.GetKnights(cWpGi,BMJ6ZOU)local D0=false
for go=1,#BMJ6ZOU do if
IsNear(BMJ6ZOU[go],JU53A5W,IO[JU53A5W].Distance)then D0=true;break end end
if
not IO[JU53A5W].Used and not IO[JU53A5W].Inactive then if D0 then
ScriptCallback_ObjectInteraction(cWpGi,GetID(JU53A5W))else
ScriptCallback_CloseObjectInteraction(cWpGi,GetID(JU53A5W))end else
ScriptCallback_CloseObjectInteraction(cWpGi,GetID(JU53A5W))end else
if
not IO[JU53A5W].Used and not IO[JU53A5W].Inactive then
ScriptCallback_ObjectInteraction(cWpGi,GetID(JU53A5W))else
ScriptCallback_CloseObjectInteraction(cWpGi,GetID(JU53A5W))end end end end end
for _AuA1b=#g_Interaction.ActiveObjectsOnScreen+1,2 do local vsQ3Bfbn=
"/InGame/Root/Normal/InteractiveObjects/".._AuA1b
XGUIEng.ShowWidget(vsQ3Bfbn,0)end end
GUI_Interaction.InteractiveObjectMouseOver=function()local hg=GUI.GetPlayerID()
local Olrh=tonumber(XGUIEng.GetWidgetNameByID(XGUIEng.GetCurrentWidgetID()))local lbsr8G=g_Interaction.ActiveObjectsOnScreen[Olrh]
local BM81Jc=Logic.GetEntityType(lbsr8G)local gw=XGUIEng.GetCurrentWidgetID()
local f={Logic.InteractiveObjectGetEffectiveCosts(lbsr8G,hg)}
local d_jS=Logic.InteractiveObjectGetAvailability(lbsr8G)local RCp;local aSii9F0;local bwh2=Logic.GetEntityName(lbsr8G)
if d_jS==true then
RCp="InteractiveObjectAvailable"else RCp="InteractiveObjectNotAvailable"end
if
Logic.InteractiveObjectHasPlayerEnoughSpaceForRewards(lbsr8G,hg)==false then aSii9F0="InteractiveObjectAvailableReward"end;local XIPH
if f and f[1]and
Logic.GetGoodCategoryForGoodType(f[1])~=GoodCategories.GC_Resource then XIPH=true end
if IO[bwh2]and IO[bwh2].Used~=true then local HWCNe;local PhHJ9mUn;if IO[bwh2].Title or
IO[bwh2].Text then HWCNe=IO[bwh2].Title or""
PhHJ9mUn=IO[bwh2].Text or""end
if
Logic.IsInteractiveObject(lbsr8G)==false then f=IO[bwh2].Costs;if
f and f[1]and
Logic.GetGoodCategoryForGoodType(f[1])~=GoodCategories.GC_Resource then XIPH=true end end
BundleInteractiveObjects.Local:TextCosts(HWCNe,PhHJ9mUn,nil,{f[1],f[2],f[3],f[4]},XIPH)return end;GUI_Tooltip.TooltipBuy(f,RCp,aSii9F0,nil,XIPH)end
GUI_Interaction.InteractiveObjectClicked_Orig_QSB_IO=GUI_Interaction.InteractiveObjectClicked
GUI_Interaction.InteractiveObjectClicked=function()
local QX91Z5=tonumber(XGUIEng.GetWidgetNameByID(XGUIEng.GetCurrentWidgetID()))local HiPOQK=Network.GetDesiredLanguage()
local Gp2=g_Interaction.ActiveObjectsOnScreen[QX91Z5]local GHxTHBZy=GUI.GetPlayerID()
for Lk,IG in pairs(IO)do
if Gp2 ==GetID(Lk)then
local N="menu_left_prestige"if IG.ActivationSound then N=IG.ActivationSound end;local RQVyouh={}
if
IO[Lk].Reward and IO[Lk].Reward[1]~=nil then
table.insert(RQVyouh,IO[Lk].Reward[1])table.insert(RQVyouh,IO[Lk].Reward[2])end;local r5mVvUH=true
if

RQVyouh[2]and type(RQVyouh[2])=="number"and RQVyouh[1]~=Goods.G_Gold and
Logic.GetGoodCategoryForGoodType(RQVyouh[1])==GoodCategories.GC_Resource then
local gs4=Logic.GetPlayerUnreservedStorehouseSpace(GHxTHBZy)if gs4 <RQVyouh[2]then r5mVvUH=false end end;local QXJDgco
if IO[Lk].Costs and IO[Lk].Costs[1]then
if
Logic.GetGoodCategoryForGoodType(IO[Lk].Costs[1])~=GoodCategories.GC_Resource then QXJDgco=true end
if r5mVvUH==false then
local DY3xhgUZ=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_MerchantStorehouseSpace")Message(DY3xhgUZ)return end;local t0=IO[Lk].Costs
local iQ0MouEI=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_NotEnough_Resources")local J7faE5z3=true;if t0[1]then
J7faE5z3=J7faE5z3 and
BundleInteractiveObjects.Local:CanBeBought(GHxTHBZy,t0[1],t0[2])end;if t0[3]then
J7faE5z3=J7faE5z3 and
BundleInteractiveObjects.Local:CanBeBought(GHxTHBZy,t0[3],t0[4])end
if
not IO[Lk].ConditionFullfilled then
if
IO[Lk].ConditionUnfulfilled and IO[Lk].ConditionUnfulfilled~=""then Message(IO[Lk].ConditionUnfulfilled)end;return end
if IO[Lk].Opener then
if
Logic.GetDistanceBetweenEntities(GetID(IO[Lk].Opener),GetID(Lk))>IO[Lk].Distance then if IO[Lk].WrongKnight and
IO[Lk].WrongKnight~=""then
Message(IO[Lk].WrongKnight)end;return end end
if J7faE5z3 ==true then if
t0[1]~=nil and not Logic.IsInteractiveObject(Gp2)then
BundleInteractiveObjects.Local:BuyObject(GHxTHBZy,t0[1],t0[2])end;if t0[3]~=nil and not
Logic.IsInteractiveObject(Gp2)then
BundleInteractiveObjects.Local:BuyObject(GHxTHBZy,t0[3],t0[4])end;if#RQVyouh>0 then
GUI.SendScriptCommand(
"GameCallback_ExecuteCustomObjectReward("..
GHxTHBZy..",'"..Lk..
"',"..RQVyouh[1]..","..RQVyouh[2]..")")end
if
Logic.IsInteractiveObject(Gp2)~=true then Play2DSound(GHxTHBZy,N)
GUI.SendScriptCommand(
"GameCallback_OnObjectInteraction("..Gp2 ..","..GHxTHBZy..")")end else Message(iQ0MouEI)end else
if r5mVvUH==false then
local eeiZVi=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_MerchantStorehouseSpace")Message(eeiZVi)return end
if not IO[Lk].ConditionFullfilled then if IO[Lk].ConditionUnfulfilled and
IO[Lk].ConditionUnfulfilled~=""then
Message(IO[Lk].ConditionUnfulfilled)end;return end
if IO[Lk].Opener then
if
Logic.GetDistanceBetweenEntities(GetID(IO[Lk].Opener),GetID(Lk))>IO[Lk].Distance then if IO[Lk].WrongKnight and
IO[Lk].WrongKnight~=""then
Message(IO[Lk].WrongKnight)end;return end end;if#RQVyouh>0 then
GUI.SendScriptCommand("GameCallback_ExecuteCustomObjectReward("..GHxTHBZy..",'"..
Lk.."',"..RQVyouh[1]..","..RQVyouh[2]..
")")end
if
Logic.IsInteractiveObject(Gp2)~=true then Play2DSound(GHxTHBZy,N)
GUI.SendScriptCommand(
"GameCallback_OnObjectInteraction("..Gp2 ..","..GHxTHBZy..")")end end end end
GUI_Interaction.InteractiveObjectClicked_Orig_QSB_IO()end
GUI_Interaction.DisplayQuestObjective_Orig_QSB_IO=GUI_Interaction.DisplayQuestObjective
GUI_Interaction.DisplayQuestObjective=function(JY_bDOz,IwSzAR8)local O1=Network.GetDesiredLanguage()if
O1 ~="de"then O1="en"end;local cy0UEdp=tonumber(JY_bDOz)if cy0UEdp then
JY_bDOz=cy0UEdp end
local t5ULdSIe,XSi=GUI_Interaction.GetPotentialSubQuestAndType(JY_bDOz)local Rabnvc="/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives"
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)local nj2aU2nO;local esu;local Gn706MB=Quests[JY_bDOz]local A5JGj
if Gn706MB~=nil and
type(Gn706MB)=="table"then A5JGj=Gn706MB.Identifier end;local E={}g_CurrentDisplayedQuestID=JY_bDOz
if XSi==Objective.Object then
nj2aU2nO=Rabnvc.."/List"
esu=Wrapped_GetStringTableText(JY_bDOz,"UI_Texts/QuestInteraction")local X9Lq1Qu={}
for kgGACce=1,t5ULdSIe.Objectives[1].Data[0]do local INOtn
if
Logic.IsEntityDestroyed(t5ULdSIe.Objectives[1].Data[kgGACce])then
INOtn=g_Interaction.SavedQuestEntityTypes[JY_bDOz][kgGACce]else
INOtn=Logic.GetEntityType(GetEntityId(t5ULdSIe.Objectives[1].Data[kgGACce]))end
local wNq7jW=Logic.GetEntityName(t5ULdSIe.Objectives[1].Data[kgGACce])local _MnhaG=""
if INOtn~=0 then local NxAiBM=Logic.GetEntityTypeName(INOtn)_MnhaG=Wrapped_GetStringTableText(JY_bDOz,
"Names/"..NxAiBM)if
_MnhaG==""then
_MnhaG=Wrapped_GetStringTableText(JY_bDOz,"UI_ObjectNames/"..NxAiBM)end
if _MnhaG==""then
_MnhaG=BundleInteractiveObjects.Local.Data.IOCustomNames[NxAiBM]if type(_MnhaG)=="table"then local O1=Network.GetDesiredLanguage()O1=(
O1 =="de"and"de")or"en"
_MnhaG=_MnhaG[O1]end end
if _MnhaG==""then
_MnhaG=BundleInteractiveObjects.Local.Data.IOCustomNames[wNq7jW]if type(_MnhaG)=="table"then local O1=Network.GetDesiredLanguage()O1=(
O1 =="de"and"de")or"en"
_MnhaG=_MnhaG[O1]end end
if _MnhaG==""then _MnhaG="Debug: ObjectName missing for "..NxAiBM end end;table.insert(X9Lq1Qu,_MnhaG)end;for kPP2ao=1,4 do local _C=X9Lq1Qu[kPP2ao]if _C==nil then _C=""end
XGUIEng.SetText(nj2aU2nO..
"/Entry"..kPP2ao,"{center}".._C)end;SetIcon(nj2aU2nO..
"/QuestTypeIcon",{14,10})
XGUIEng.SetText(
nj2aU2nO.."/Caption","{center}"..esu)XGUIEng.ShowWidget(nj2aU2nO,1)else
GUI_Interaction.DisplayQuestObjective_Orig_QSB_IO(JY_bDOz,IwSzAR8)end end end
function BundleInteractiveObjects.Local:TextCosts(qx6_V7_Q,ZhT2Ub,yX9,p,lAoiaix)
local R="/InGame/Root/Normal/TooltipBuy"local u8eA5KA=XGUIEng.GetWidgetID(R)
local GbCv4OVA=XGUIEng.GetWidgetID(R.."/FadeIn/Name")local N_t=XGUIEng.GetWidgetID(R.."/FadeIn/Text")local QgpDVU=XGUIEng.GetWidgetID(
R.."/FadeIn/BG")local bOpF=XGUIEng.GetWidgetID(R..
"/FadeIn")
local Y=XGUIEng.GetWidgetID(R.."/Costs")local X=XGUIEng.GetCurrentWidgetID()
GUI_Tooltip.ResizeBG(QgpDVU,N_t)GUI_Tooltip.SetCosts(Y,p,lAoiaix)
local GKDCh={u8eA5KA,Y,QgpDVU}
GUI_Tooltip.SetPosition(u8eA5KA,GKDCh,X,nil,true)GUI_Tooltip.OrderTooltip(GKDCh,bOpF,Y,X,QgpDVU)
GUI_Tooltip.FadeInTooltip(bOpF)yX9=yX9 or""local nv=""if
XGUIEng.IsButtonDisabled(X)==1 and yX9 ~=""and ZhT2Ub~=""then
nv=nv.."{cr}{@color:255,32,32,255}"..yX9 end;XGUIEng.SetText(GbCv4OVA,"{center}"..
qx6_V7_Q)
XGUIEng.SetText(N_t,ZhT2Ub..nv)local KGfF=XGUIEng.GetTextHeight(N_t,true)
local k3VGYa,K=XGUIEng.GetWidgetSize(N_t)XGUIEng.SetWidgetSize(N_t,k3VGYa,KGfF)end
function BundleInteractiveObjects.Local:SetIcon(UlVp,yp3K1T)
if type(yp3K1T)=="table"then
if
type(yp3K1T[3])=="string"then local uW_J=1
if XGUIEng.IsButton(UlVp)==1 then uW_J=7 end;local Lt,QDdX,rqJGwNsW,hj;Lt=(yp3K1T[1]-1)*64;rqJGwNsW=
(yp3K1T[2]-1)*64;QDdX=(yp3K1T[1])*64
hj=(yp3K1T[2])*64;XGUIEng.SetMaterialAlpha(UlVp,uW_J,255)XGUIEng.SetMaterialTexture(UlVp,uW_J,
yp3K1T[3].."big.png")
XGUIEng.SetMaterialUV(UlVp,uW_J,Lt,rqJGwNsW,QDdX,hj)else SetIcon(UlVp,yp3K1T)end else local MtcdpVP={GUI.GetScreenSize()}local yM=330;if MtcdpVP[2]>=800 then
yM=260 end;if MtcdpVP[2]>=1000 then yM=210 end
XGUIEng.SetMaterialAlpha(UlVp,1,255)XGUIEng.SetMaterialTexture(UlVp,1,_file)
XGUIEng.SetMaterialUV(UlVp,1,0,0,yM,yM)end end;Core:RegisterBundle("BundleInteractiveObjects")function API.GetHealth(b472)return
BundleEntityHealth:GetHealth(b472)end
GetHealth=API.GetHealth
function API.SetHealth(TDguj,vRZqTR)if GUI then local pitSKP=
(type(TDguj)=="string"and"'"..TDguj.."'")or TDguj
API.Bridge("API.SetHealth("..
pitSKP..", "..vRZqTR..")")return end
if not
IsExisting(TDguj)then local jZX1zJ=
(type(TDguj)=="string"and"'"..TDguj.."'")or TDguj
API.Dbg("_Entity "..jZX1zJ..
" does not exist!")return end;if type(vRZqTR)~="number"then
API.Dbg("_Percentage must be a number!")return end
vRZqTR=(vRZqTR<0 and 0)or vRZqTR;if vRZqTR>100 then
API.Warn("_Percentage is larger than 100%. This could cause problems!")end
BundleEntityHealth.Global:SetEntityHealth(TDguj,vRZqTR)end;SetHealth=API.SetHealth
function API.SetOnFire(GDOan,KZ7)if GUI then
local F=(type(GDOan)=="string"and
"'"..GDOan.."'")or GDOan
API.Bridge("API.SetOnFire("..F..", "..KZ7 ..")")return end
if not
IsExisting(GDOan)then local _rRjO=
(type(GDOan)=="string"and"'"..GDOan.."'")or GDOan
API.Dbg("Entity ".._rRjO..
" does not exist!")return end;if Logic.IsBuilding(GetID(GDOan))==0 then
API.Dbg("Only buildings can be set on fire!")return end;if type(KZ7)~="number"then
API.Dbg("_Strength must be a number!")return end
KZ7=(KZ7 <0 and 0)or KZ7
Logic.DEBUG_SetBuildingOnFile(GetID(GDOan),KZ7)end;SetOnFire=API.SetOnFire
function API.AddOnEntityHurtAction(hh)if GUI then
API.Dbg("API.AddOnEntityHurtAction: Can not be used in local script!")return end;if type(hh)~="function"then
API.Dbg("_Function must be a function!")return end
BundleEntityHealth.Global.AddOnEntityHurtAction(hh)end;AddOnEntityHurtAction=API.AddOnEntityHurtAction
BundleEntityHealth={Global={Data={OnEntityHurtAction={}}},Local={Data={}}}
function BundleEntityHealth.Global:Install()
BundleEntityHealth_EntityHurtEntityController=BundleEntityHealth.Global.EntityHurtEntityController
Trigger.RequestTrigger(Events.LOGIC_EVENT_ENTITY_HURT_ENTITY,"","BundleEntityHealth_EntityHurtEntityController",1)
BundleEntityHealth_EntityDestroyedController=BundleEntityHealth.Global.EntityDestroyedController
Trigger.RequestTrigger(Events.LOGIC_EVENT_ENTITY_DESTROYED,"","BundleEntityHealth_EntityDestroyedController",1)end
function BundleEntityHealth.Global:SetEntityHealth(bbfR,Y4mGAwwZ)
if not IsExisting(bbfR)then return end;local Ig=GetID(bbfR)local qlckp=Logic.GetEntityMaxHealth(Ig)
local J=Logic.GetEntityHealth(Ig)
local iFBY_Zyh=math.floor((qlckp* (Y4mGAwwZ/100))+0.5)Logic.HealEntity(Ig,qlckp-J)
Logic.HurtEntity(Ig,qlckp-iFBY_Zyh)end;function BundleEntityHealth.Global.AddOnEntityHurtAction(mz7ro)
table.insert(BundleEntityHealth.Global.Data.OnEntityHurtAction,mz7ro)end
function BundleEntityHealth.Global.EntityHurtEntityController()
local P9j7I1={Event.GetEntityID1()}local tNPB0={Event.GetEntityID2()}
for jRVhJx=1,#P9j7I1,1 do
for k=1,#tNPB0,1 do
local Ex=P9j7I1[jRVhJx]local Qe7GQI2=tNPB0[k]
if IsExisting(Ex)and IsExisting(Qe7GQI2)then
for _mUlNz,mY8Jv in
pairs(BundleEntityHealth.Global.Data.OnEntityHurtAction)do if mY8Jv then mY8Jv(Ex,Qe7GQI2)end end end end end end;function BundleEntityHealth.Local:Install()end
function BundleEntityHealth:GetHealth(QNKVU)if
not IsExisting(QNKVU)then return 0 end;local XZIM=GetID(QNKVU)
local RCZlr=Logic.GetEntityMaxHealth(XZIM)local PD0db=Logic.GetEntityHealth(XZIM)
return(PD0db/RCZlr)*100 end;Core:RegisterBundle("BundleEntityHealth")function Reprisal_SetHealth(...)return
b_Reprisal_SetHealth:new(...)end
b_Reprisal_SetHealth={Name="Reprisal_SetHealth",Description={en="Reprisal: Changes the health of an entity.",de="Vergeltung: Setzt die Gesundheit eines Entity."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Number,en="Percentage",de="Prozentsatz"}}}
function b_Reprisal_SetHealth:GetRewardTable(Zc5t)return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_SetHealth:AddParameter(kH,jgQPxNo)if(kH==0)then self.Entity=jgQPxNo elseif(kH==1)then
self.Percentage=jgQPxNo end end;function b_Reprisal_SetHealth:CustomFunction(E7IYK)
SetHealth(self.Entity,self.Percentage)end
function b_Reprisal_SetHealth:DEBUG(VckH8l)if not
IsExisting(self.Entity)then
dbg(VckH8l.Identifier..
" "..self.Name..": Entity is dead! :(")end
if self.Percentage<0 or
self.Percentage>100 then
dbg(VckH8l.Identifier.." "..
self.Name..": Percentage must be between 0 and 100!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_SetHealth)function Reward_SetHealth(...)return
b_Reward_SetHealth:new(...)end
b_Reward_SetHealth=API.InstanceTable(b_Reprisal_SetHealth)b_Reward_SetHealth.Name="Reward_SetHealth"
b_Reward_SetHealth.Description.en="Reward: Changes the health of an entity."
b_Reward_SetHealth.Description.de="Lohn: Setzt die Gesundheit eines Entity."b_Reward_SetHealth.GetReprisalTable=nil
b_Reward_SetHealth.GetRewardTable=function(v8Zt3n,A)return
{Reward.Custom,{v8Zt3n,v8Zt3n.CustomFunction}}end
function b_Reward_SetHealth:DEBUG(E1s5QwZo)if not IsExisting(self.Entity)then
dbg(E1s5QwZo.Identifier.." "..
self.Name..": Entity is dead! :(")return true end
if
self.Percentage<0 or self.Percentage>100 then
dbg(E1s5QwZo.Identifier.." "..self.Name..
": Percentage must be between 0 and 100!")return true end;return false end;Core:RegisterBehavior(b_Reward_SetHealth)function Trigger_EntityHealth(...)return
b_Trigger_EntityHealth:new(...)end
b_Trigger_EntityHealth={Name="Trigger_EntityHealth",Description={en="Trigger: The health of a unit must reach a certain point.",de="Auslöser: Die Gesundheit eines Entity muss einen bestimmten Wert erreichen."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Percentage",de="Prozentwert"}}}
function b_Trigger_EntityHealth:GetTriggerTable(Mtk5vQl)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_EntityHealth:AddParameter(wmtDx,SR)
if(wmtDx==0)then self.ScriptName=SR elseif(wmtDx==1)then self.BeSmalerThan=
SR=="<"elseif(wmtDx==2)then self.Percentage=SR end end
function b_Trigger_EntityHealth:GetCustomData(k)if k==1 then return{"<",">="}end end
function b_Trigger_EntityHealth:CustomFunction(zY5m7kx7)
if self.BeSmalerThan then return GetHealth(self.ScriptName)<
self.Percentage else return GetHealth(self.ScriptName)>=
self.Percentage end end
function b_Trigger_EntityHealth:DEBUG(E)if not IsExisting(self.ScriptName)then
dbg(
E.Identifier.." "..self.Name..": Entity is dead! :(")return true end
if
self.Percentage<0 or self.Percentage>100 then
dbg(E.Identifier.." "..self.Name..
": Percentage must be between 0 and 100!")return true end;return false end;Core:RegisterBehavior(b_Trigger_EntityHealth)
API=API or{}QSB=QSB or{}AddOnQuestDebug={Global={Data={}},Local={Data={}}}
function API.ActivateDebugMode(q29Uv,h,LzA,h59T9dU_)
if
GUI then
API.Bridge("API.DisbandTravelingSalesman("..
tostring(q29Uv)..", "..tostring(h)..
", "..tostring(LzA)..", "..
tostring(h59T9dU_)..")")return end
AddOnQuestDebug.Global:ActivateDebug(q29Uv,h,LzA,h59T9dU_)end;ActivateDebugMode=API.ActivateDebugMode;function Reward_DEBUG(...)
return b_Reward_DEBUG:new(...)end
b_Reward_DEBUG={Name="Reward_DEBUG",Description={en="Reward: Start the debug mode. See documentation for more information.",de="Lohn: Startet den Debug-Modus. Für mehr Informationen siehe Dokumentation."},Parameter={{ParameterType.Custom,en="Check quests beforehand",de="Quest vor Start prüfen"},{ParameterType.Custom,en="Check quest while runtime",de="Quests zur Laufzeit prüfen"},{ParameterType.Custom,en="Use quest trace",de="Questverfolgung"},{ParameterType.Custom,en="Activate developing mode",de="Testmodus aktivieren"}}}function b_Reward_DEBUG:GetRewardTable(tx)return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_DEBUG:AddParameter(XC,U)
if(
XC==0)then self.CheckAtStart=AcceptAlternativeBoolean(U)elseif(XC==1)then
self.CheckWhileRuntime=AcceptAlternativeBoolean(U)elseif(XC==2)then self.UseQuestTrace=AcceptAlternativeBoolean(U)elseif(XC==3)then
self.DelepoingMode=AcceptAlternativeBoolean(U)end end;function b_Reward_DEBUG:CustomFunction(Xp)
API.ActivateDebugMode(self.CheckAtStart,self.CheckWhileRuntime,self.UseQuestTrace,self.DelepoingMode)end;function b_Reward_DEBUG:GetCustomData(c)return
{"true","false"}end
Core:RegisterBehavior(b_Reward_DEBUG)
function AddOnQuestDebug.Global:Install()
AddOnQuestDebug.Global.Data.DebugCommands={{"clear",AddOnQuestDebug.Global.Clear},{"diplomacy",AddOnQuestDebug.Global.Diplomacy},{"restartmap",AddOnQuestDebug.Global.RestartMap},{"shareview",AddOnQuestDebug.Global.ShareView},{"setposition",AddOnQuestDebug.Global.SetPosition},{"unfreeze",AddOnQuestDebug.Global.Unfreeze},{"win",AddOnQuestDebug.Global.QuestSuccess,true},{"winall",AddOnQuestDebug.Global.QuestSuccess,false},{"fail",AddOnQuestDebug.Global.QuestFailure,true},{"failall",AddOnQuestDebug.Global.QuestFailure,false},{"stop",AddOnQuestDebug.Global.QuestInterrupt,true},{"stopall",AddOnQuestDebug.Global.QuestInterrupt,false},{"start",AddOnQuestDebug.Global.QuestTrigger,true},{"startall",AddOnQuestDebug.Global.QuestTrigger,false},{"restart",AddOnQuestDebug.Global.QuestReset,true},{"restartall",AddOnQuestDebug.Global.QuestReset,false},{"printequal",AddOnQuestDebug.Global.PrintQuests,1},{"printactive",AddOnQuestDebug.Global.PrintQuests,2},{"printdetail",AddOnQuestDebug.Global.PrintQuests,3},{"lload",AddOnQuestDebug.Global.LoadScript,true},{"gload",AddOnQuestDebug.Global.LoadScript,false},{"lexec",AddOnQuestDebug.Global.ExecuteCommand,true},{"gexec",AddOnQuestDebug.Global.ExecuteCommand,false},{"collectgarbage",AddOnQuestDebug.Global.CollectGarbage},{"dumpmemory",AddOnQuestDebug.Global.CountLuaLoad}}
for e,sOA in pairs(_G)do
if

type(sOA)=="table"and sOA.Name and e=="b_"..sOA.Name and sOA.CustomFunction and not sOA.CustomFunction2 then sOA.CustomFunction2=sOA.CustomFunction
sOA.CustomFunction=function(rCZvJK1,D7RiOn5J)
if
AddOnQuestDebug.Global.Data.CheckAtRun then
if rCZvJK1.DEBUG and not rCZvJK1.FOUND_ERROR and
rCZvJK1:DEBUG(D7RiOn5J)then rCZvJK1.FOUND_ERROR=true end end;if not rCZvJK1.FOUND_ERROR then
return rCZvJK1:CustomFunction2(D7RiOn5J)end end end end;if BundleQuestGeneration then
BundleQuestGeneration.Global.DebugQuest=AddOnQuestDebug.Global.DebugQuest end
self:OverwriteCreateQuests()API.AddSaveGameAction(self.OnSaveGameLoad)end
function AddOnQuestDebug.Global:ActivateDebug(I,KG4MJ,BYzo,FMk)
if self.Data.DebugModeIsActive then return end;self.Data.DebugModeIsActive=true
self.Data.CheckAtStart=I==true;QSB.DEBUG_CheckAtStart=I==true
self.Data.CheckAtRun=KG4MJ==true;QSB.DEBUG_CheckAtRun=KG4MJ==true
self.Data.TraceQuests=BYzo==true;QSB.DEBUG_TraceQuests=BYzo==true
self.Data.DevelopingMode=FMk==true;QSB.DEBUG_DevelopingMode=FMk==true
self:ActivateQuestTrace()self:ActivateDevelopingMode()end
function AddOnQuestDebug.Global:ActivateQuestTrace()if self.Data.TraceQuests then
DEBUG_EnableQuestDebugKeys()DEBUG_QuestTrace(true)end end
function AddOnQuestDebug.Global:ActivateDevelopingMode()if self.Data.DevelopingMode then
Logic.ExecuteInLuaLocalState("AddOnQuestDebug.Local:ActivateDevelopingMode()")end end
function AddOnQuestDebug.Global:Parser(t1)local z=self:Tokenize(t1)
for T9OCU6H,Z in
pairs(self.Data.DebugCommands)do
if Z[1]==z[1]then for Hlul0b=1,#z do local Q2x8=tonumber(z[Hlul0b])
if Q2x8 then z[Hlul0b]=Q2x8 end end
Z[2](AddOnQuestDebug.Global,z,Z[3])return end end end
function AddOnQuestDebug.Global:Tokenize(U)local Zjolrl={}local oob=U
while
(oob and oob:len()>0)do local uz1QbP,kdK=string.find(oob," ")if kdK then
Zjolrl[#Zjolrl+1]=oob:sub(1,kdK-1)oob=oob:sub(kdK+1,oob:len())else
Zjolrl[#Zjolrl+1]=oob;oob=nil end end;return Zjolrl end;function AddOnQuestDebug.Global:CollectGarbage()collectgarbage()
Logic.ExecuteInLuaLocalState("AddOnQuestDebug.Local:CollectGarbage()")end
function AddOnQuestDebug.Global:CountLuaLoad()
Logic.ExecuteInLuaLocalState("AddOnQuestDebug.Local:CountLuaLoad()")local LLcX=collectgarbage("count")
API.StaticNote("Global Lua Size: "..LLcX)end
function AddOnQuestDebug.Global:PrintQuests(EeTTSd,uOSMMxD)local Q52N=""local k=0;local Y=function(kMAd,Oa37)
return kMAd.State==Oa37 end;if uOSMMxD==3 then
self:PrintDetail(EeTTSd)return end
if uOSMMxD==1 then
Y=function(fOep3lxK,_rQ2)return
string.find(fOep3lxK.Identifier,_rQ2)end elseif uOSMMxD==2 then EeTTSd[2]=QuestState.Active end
for XJY4VPk=1,Quests[0]do
if Quests[XJY4VPk]then if Y(Quests[XJY4VPk],EeTTSd[2])then k=k+1
if k<=15 then
Q52N=Q52N.. ((
Q52N:len()>0 and"{cr}")or"")Q52N=Q52N..Quests[XJY4VPk].Identifier end end end end
if k>=15 then Q52N=Q52N..
"{cr}{cr}(".. (k-15).." weitere Ergebnis(se) gefunden!)"end
Logic.ExecuteInLuaLocalState([[
        GUI.ClearNotes()
        GUI.AddStaticNote("]]..Q52N..[[")
    ]])end
function AddOnQuestDebug.Global:PrintDetail(jcMzJ)local YD4oC=""
local K=GetQuestID(string.gsub(jcMzJ[2]," ",""))
if Quests[K]then
local S1y5X85S=
(Quests[K].State==QuestState.NotTriggered and"not triggered")or
(Quests[K].State==QuestState.Active and"active")or"over"
local LwesnkL=

(Quests[K].Result==QuestResult.Success and"success")or
(Quests[K].Result==QuestResult.Failure and"failure")or
(Quests[K].Result==
QuestResult.Interrupted and"interrupted")or"undecided"
YD4oC=YD4oC.."Name: "..Quests[K].Identifier.."{cr}"YD4oC=YD4oC.."State: "..S1y5X85S.."{cr}"YD4oC=
YD4oC.."Result: "..LwesnkL.."{cr}"
YD4oC=
YD4oC.."Sender: "..Quests[K].SendingPlayer.."{cr}"
YD4oC=YD4oC.."Receiver: "..Quests[K].ReceivingPlayer.."{cr}"
YD4oC=YD4oC.."Duration: "..Quests[K].Duration.."{cr}"
YD4oC=YD4oC.."Start Text: "..
tostring(Quests[K].QuestStartMsg).."{cr}"
YD4oC=YD4oC.."Failure Text: "..
tostring(Quests[K].QuestFailureMsg).."{cr}"
YD4oC=YD4oC.."Success Text: "..
tostring(Quests[K].QuestSuccessMsg).."{cr}"
YD4oC=YD4oC.."Description: "..
tostring(Quests[K].QuestDescription).."{cr}"YD4oC=YD4oC..
"Objectives: "..#Quests[K].Objectives.."{cr}"
YD4oC=YD4oC.."Reprisals: "..#
Quests[K].Reprisals.."{cr}"
YD4oC=YD4oC.."Rewards: "..#Quests[K].Rewards.."{cr}"
YD4oC=YD4oC.."Triggers: "..#Quests[K].Triggers.."{cr}"else
YD4oC=YD4oC..tostring(jcMzJ[2]).." not found!"end
Logic.ExecuteInLuaLocalState([[
        GUI.ClearNotes()
        GUI.AddStaticNote("]]..YD4oC..[[")
    ]])end
function AddOnQuestDebug.Global:LoadScript(wR,vZWtu5E1)
if wR[2]then
if vZWtu5E1 ==true then
Logic.ExecuteInLuaLocalState(
[[Script.Load("]]..wR[2]..[[")]])elseif vZWtu5E1 ==false then Script.Load(wR[2])end;if not self.Data.SurpassMessages then
Logic.DEBUG_AddNote("load script "..wR[2])end end end
function AddOnQuestDebug.Global:ExecuteCommand(FR,P)
if FR[2]then local r=""for LQi3b=2,#FR do
r=r.." "..FR[LQi3b]end
if P==true then FR[2]=string.gsub(r,"'","\'")Logic.ExecuteInLuaLocalState(
[[]]..r..[[]])elseif P==false then
Logic.ExecuteInLuaLocalState(
[[GUI.SendScriptCommand("]]..r..[[")]])end end end;function AddOnQuestDebug.Global:Clear()
Logic.ExecuteInLuaLocalState("GUI.ClearNotes()")end;function AddOnQuestDebug.Global:Diplomacy(mtv)
SetDiplomacyState(mtv[2],mtv[3],mtv[4])end;function AddOnQuestDebug.Global:RestartMap()
Logic.ExecuteInLuaLocalState("Framework.RestartMap()")end;function AddOnQuestDebug.Global:ShareView(vLTmF7I)
Logic.SetShareExplorationWithPlayerFlag(vLTmF7I[2],vLTmF7I[3],vLTmF7I[4])end
function AddOnQuestDebug.Global:SetPosition(DhAt)
local Ngik=GetID(DhAt[2])local p=GetID(DhAt[3])local l,yortib,msx=Logic.EntityGetPos(p)if
Logic.IsBuilding(p)==1 then
l,yortib=Logic.GetBuildingApproachPosition(p)end
Logic.DEBUG_SetSettlerPosition(Ngik,l,yortib)end
function AddOnQuestDebug.Global:QuestSuccess(yomadRP,Hg)
local gLLH8V=FindQuestsByName(yomadRP[2],Hg)if#gLLH8V==0 then return end
API.WinAllQuests(unpack(gLLH8V))end
function AddOnQuestDebug.Global:QuestFailure(b8juqURD,R3b)
local nCvVQ_=FindQuestsByName(b8juqURD[2],R3b)if#nCvVQ_==0 then return end
API.FailAllQuests(unpack(nCvVQ_))end
function AddOnQuestDebug.Global:QuestInterrupt(qRO,RwV7Nz)
local zdt=FindQuestsByName(qRO[2],RwV7Nz)if#zdt==0 then return end;API.StopAllQuests(unpack(zdt))end
function AddOnQuestDebug.Global:QuestTrigger(x,tKhKAqHm)
local g=FindQuestsByName(x[2],tKhKAqHm)if#g==0 then return end;API.StartAllQuests(unpack(g))end
function AddOnQuestDebug.Global:QuestReset(O1dT5mO,ut)
local eFM93=FindQuestsByName(O1dT5mO[2],ut)if#eFM93 ==0 then return end
API.RestartAllQuests(unpack(eFM93))end
function AddOnQuestDebug.Global:OverwriteCreateQuests()
self.Data.CreateQuestsOriginal=CreateQuests
CreateQuests=function()if
not AddOnQuestDebug.Global.Data.CheckAtStart then
AddOnQuestDebug.Global.Data.CreateQuestsOriginal()return end
local c8rvHYR=Logic.Quest_GetQuestNames()
for VZGKX=1,#c8rvHYR,1 do local X=c8rvHYR[VZGKX]
local P={Logic.Quest_GetQuestParamter(X)}local U={}local xa=Logic.Quest_GetQuestNumberOfBehaviors(X)
for YHx7fa=0,xa-1,1
do local spbQC=Logic.Quest_GetQuestBehaviorName(X,YHx7fa)
local W=GetBehaviorTemplateByName(spbQC)assert(W~=nil)
local Chad=Logic.Quest_GetQuestBehaviorParameter(X,YHx7fa)API.DumpTable(Chad)
table.insert(U,W:new(unpack(Chad)))end
API.AddQuest{Name=X,Sender=P[1],Receiver=P[2],Time=P[4],Description=P[5],Suggestion=P[6],Failure=P[7],Success=P[8],unpack(U)}end;API.StartQuests()end end
function AddOnQuestDebug.Global.OnSaveGameLoad(c,RDORLQZ0)
AddOnQuestDebug.Global:ActivateDevelopingMode()
AddOnQuestDebug.Global:ActivateQuestTrace()end
function AddOnQuestDebug.Global.DebugQuest(U,D04pnwO)
if
AddOnQuestDebug.Global.Data.CheckAtStart then
if D04pnwO.Goals then
for yrho=1,#D04pnwO.Goals,1 do
if
type(D04pnwO.Goals[yrho][2])=="table"and
type(D04pnwO.Goals[yrho][2][1])=="table"then
if
D04pnwO.Goals[yrho][2][1].DEBUG and
D04pnwO.Goals[yrho][2][1]:DEBUG(D04pnwO)then return false end end end end
if D04pnwO.Reprisals then
for z=1,#D04pnwO.Reprisals,1 do
if
type(D04pnwO.Reprisals[z][2])=="table"and
type(D04pnwO.Reprisals[z][2][1])=="table"then
if
D04pnwO.Reprisals[z][2][1].DEBUG and
D04pnwO.Reprisals[z][2][1]:DEBUG(D04pnwO)then return false end end end end
if D04pnwO.Rewards then
for PcTlm=1,#D04pnwO.Rewards,1 do
if
type(D04pnwO.Rewards[PcTlm][2])=="table"and
type(D04pnwO.Rewards[PcTlm][2][1])=="table"then
if
D04pnwO.Rewards[PcTlm][2][1].DEBUG and
D04pnwO.Rewards[PcTlm][2][1]:DEBUG(D04pnwO)then return false end end end end
if D04pnwO.Triggers then
for Q7TY8NY=1,#D04pnwO.Triggers,1 do
if
type(D04pnwO.Triggers[Q7TY8NY][2])=="table"and
type(D04pnwO.Triggers[Q7TY8NY][2][1])=="table"then
if
D04pnwO.Triggers[Q7TY8NY][2][1].DEBUG and
D04pnwO.Triggers[Q7TY8NY][2][1]:DEBUG(D04pnwO)then return false end end end end end;return true end;function AddOnQuestDebug.Local:Install()end;function AddOnQuestDebug.Local:CollectGarbage()
collectgarbage()end
function AddOnQuestDebug.Local:CountLuaLoad()
local RX6M=collectgarbage("count")API.StaticNote("Local Lua Size: "..RX6M)end
function AddOnQuestDebug.Local:ActivateDevelopingMode()
KeyBindings_EnableDebugMode(1)KeyBindings_EnableDebugMode(2)
KeyBindings_EnableDebugMode(3)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/GameClock",1)GUI_Chat.Abort=function()end
GUI_Chat.Confirm=function()Input.GameMode()
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatInput",0)
AddOnQuestDebug.Local.Data.ChatBoxInput=XGUIEng.GetText("/InGame/Root/Normal/ChatInput/ChatInput")g_Chat.JustClosed=1
Game.GameTimeSetFactor(GUI.GetPlayerID(),1)end
QSB_DEBUG_InputBoxJob=function()
if
not AddOnQuestDebug.Local.Data.BoxShown then Input.ChatMode()
Game.GameTimeSetFactor(GUI.GetPlayerID(),0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatInput",1)
XGUIEng.SetText("/InGame/Root/Normal/ChatInput/ChatInput","")
XGUIEng.SetFocus("/InGame/Root/Normal/ChatInput/ChatInput")AddOnQuestDebug.Local.Data.BoxShown=true elseif
AddOnQuestDebug.Local.Data.ChatBoxInput then
AddOnQuestDebug.Local.Data.ChatBoxInput=string.gsub(AddOnQuestDebug.Local.Data.ChatBoxInput,"'","\'")
GUI.SendScriptCommand("AddOnQuestDebug.Global:Parser('"..
AddOnQuestDebug.Local.Data.ChatBoxInput.."')")AddOnQuestDebug.Local.Data.BoxShown=nil
return true end end
Input.KeyBindDown(Keys.ModifierShift+Keys.OemPipe,"StartSimpleJob('QSB_DEBUG_InputBoxJob')",2,true)end;Core:RegisterBundle("AddOnQuestDebug")API=API or{}QSB=QSB or
{}
function API.CreateIOMine(SFfj,d,Tf7u,aJ4UY,vE090BRT,d0Fk,MJUH)if GUI then
API.Dbg("API.CreateIOMine: Can not be used from local script!")return end
AddOnInteractiveObjectTemplates.Global:CreateIOMine(SFfj,d,Tf7u,aJ4UY,vE090BRT,d0Fk,MJUH)end;CreateIOMine=API.CreateIOMine
function API.CreateIOIronMine(Zd,ED,xebxis,uskpT,o3WjYh,T3DvJ)if GUI then
API.Dbg("API.CreateIOIronMine: Can not be used from local script!")return end
AddOnInteractiveObjectTemplates.Global:CreateIOIronMine(Zd,ED,xebxis,uskpT,o3WjYh,T3DvJ)end;CreateIOIronMine=API.CreateIOIronMine
function API.CreateIOStoneMine(ZLyg,PU,ngftFCT,fzML,h,XU5)if GUI then
API.Dbg("API.CreateIOStoneMine: Can not be used from local script!")return end
AddOnInteractiveObjectTemplates.Global:CreateIOStoneMine(ZLyg,PU,ngftFCT,fzML,h,XU5)end;CreateIOStoneMine=API.CreateIOStoneMine
function API.CreateIOBuildingSite(Fsu,pm,P0Z47Ai,yx7xuV,NfF6ElE8,sgC,QPSlOyr,R0dXxj,R9u)if GUI then
API.Dbg("API.CreateIOBuildingSite: Can not be used from local script!")return end
AddOnInteractiveObjectTemplates.Global:CreateIOBuildingSite(Fsu,pm,P0Z47Ai,yx7xuV,NfF6ElE8,sgC,QPSlOyr,R0dXxj,R9u)end;CreateIOBuildingSite=API.CreateIOBuildingSite
function API.CreateRandomChest(PzIdLA,iu,GiTj,kxFUm3,YD1Y)if GUI then
API.Dbg("API.CreateRandomChest: Can not be used from local script!")return end
AddOnInteractiveObjectTemplates.Global:CreateRandomChest(PzIdLA,iu,GiTj,kxFUm3,YD1Y)end;CreateRandomChest=API.CreateRandomChest
function API.CreateRandomGoldChest(F)if GUI then API.Dbg("API.CreateRandomGoldChest('"..
F.."')")
return end
AddOnInteractiveObjectTemplates.Global:CreateRandomChest(F,Goods.G_Gold,300,600)end;CreateRandomGoldChest=API.CreateRandomGoldChest
function API.CreateRandomResourceChest(RLauqBm)if GUI then
API.Bridge(
"API.CreateRandomResourceChest('"..RLauqBm.."')")return end
AddOnInteractiveObjectTemplates.Global:CreateRandomResourceChest(RLauqBm)end;CreateRandomResourceChest=API.CreateRandomResourceChest
function API.CreateRandomLuxuryChest(t)if GUI then
API.Bridge(
"API.CreateRandomLuxuryChest('"..t.."')")return end
AddOnInteractiveObjectTemplates.Global:CreateRandomLuxuryChest(t)end;CreateRandomLuxuryChest=API.CreateRandomLuxuryChest
function API.CreateTrebuchetConstructionSite(b,HhVQ,KxoUpqFE)if GUI then
API.Bridge(
"API.CreateTrebuchetConstructionSite('"..b.."', "..HhVQ..", "..KxoUpqFE..")")return end
AddOnInteractiveObjectTemplates.Global:CreateTrebuchetConstructionSite(b,HhVQ,KxoUpqFE)end;CreateTrebuchetConstructionSite=API.CreateTrebuchetConstructionSite
function API.DestroyTrebuchetConstructionSite(u)if
GUI then
API.Bridge("API.DestroyTrebuchetConstructionSite('"..u.."')")return end
AddOnInteractiveObjectTemplates.Global:DestroyTrebuchetConstructionSite(u)end;DestroyTrebuchetConstructionSite=API.DestroyTrebuchetConstructionSite
function API.GetTrebuchetByTrebuchetConstructionSite(IADfr4S3)if
GUI then
API.Dbg("API.GetTrebuchetByTrebuchetConstructionSite: Can only be used in global script!")return end
if not
self.Data.Trebuchet.Sites[IADfr4S3]then
API.Warn("API.GetTrebuchetByTrebuchetConstructionSite: Site '"..tostring(IADfr4S3)..
"' does not exist!")return 0 end;return
self.Data.Trebuchet.Sites[IADfr4S3].ConstructedTrebuchet end;GetTrebuchet=API.GetTrebuchetByTrebuchetConstructionSite
function API.GetReturningCartByTrebuchetConstructionSite(GrL6olXS)if
GUI then
API.Dbg("API.GetReturningCartByTrebuchetConstructionSite: Can only be used in global script!")return end
if not
self.Data.Trebuchet.Sites[GrL6olXS]then
API.Warn("API.GetReturningCartByTrebuchetConstructionSite: Site '"..tostring(GrL6olXS)..
"' does not exist!")return 0 end
return self.Data.Trebuchet.Sites[GrL6olXS].ReturningCart end;GetReturningCart=API.GetReturningCartByTrebuchetConstructionSite
function API.GetConstructionCartByTrebuchetConstructionSite(bu6)if
GUI then
API.Dbg("API.GetConstructionCartByTrebuchetConstructionSite: Can only be used in global script!")return end
if not
self.Data.Trebuchet.Sites[bu6]then
API.Warn("API.GetConstructionCartByTrebuchetConstructionSite: Site '"..
tostring(bu6).."' does not exist!")return 0 end
return self.Data.Trebuchet.Sites[bu6].ConstructionCart end;GetConstructionCart=API.GetConstructionCartByTrebuchetConstructionSite
AddOnInteractiveObjectTemplates={Global={Data={ConstructionSite={Sites={},Description={Title={de="Gebäude bauen",en="Create building"},Text={de=
"Beauftragt den Bau eines Gebäudes. Ein Siedler wird aus".." dem Lagerhaus kommen und mit dem Bau beginnen.",en=
"Order a building. A worker will come out of the".." storehouse and erect it."},Unfulfilled={de="Das Gebäude kann derzeit nicht gebaut werden.",en="The building can not be built at the moment."}}},Mines={Description={Title={de="Mine errichten",en="Build pit"},Text={de="An diesem Ort könnt Ihr eine Mine errichten!",en="You're able to create a pit at this location!"}}},Chests={Description={Title={de="Schatztruhe",en="Treasure Chest"},Text={de="Diese Truhe enthält einen geheimen Schatz. Öffnet sie um den Schatz zu bergen.",en="This chest contains a secred treasure. Open it to salvage the treasure."}}},Trebuchet={Error={de="Euer Ritter benötigt einen höheren Titel!",en="Your knight need a higher title to use this site!"},Description={Title={de="Trebuchet anfordern",en="Order trebuchet"},Text={de="- Fordert ein Trebuchet aus der Stadt an {cr}- Trebuchet wird gebaut, wenn Wagen Baustelle erreicht {cr}- Fährt zurück, wenn Munition aufgebraucht {cr}- Trebuchet kann manuell zurückgeschickt werden",en="- Order a trebuchet from your city {cr}- The trebuchet is build after the cart has arrived {cr}- Returns after ammunition is depleted {cr}- The trebuchet can be manually send back to the city"}},Sites={},NeededKnightTitle=0,IsActive=false}}},Local={Data={}}}
function AddOnInteractiveObjectTemplates.Global:Install()end
function AddOnInteractiveObjectTemplates.Global:TrebuchetActivate()
if not
self.Data.Trebuchet.IsActive then
GameCallback_QSB_OnDisambleTrebuchet=AddOnInteractiveObjectTemplates.Global.OnTrebuchetDisambled;GameCallback_QSB_OnErectTrebuchet=function()end
StartSimpleJobEx(self.WatchTrebuchetsAndCarts)API.DisableRefillTrebuchet(true)
self.Data.Trebuchet.IsActive=true end end
function AddOnInteractiveObjectTemplates.Global.TrebuchetHasSufficentTitle()local R=1
for EtJdUZ=1,8 do if
Logic.PlayerGetIsHumanFlag(EtJdUZ)==1 then R=EtJdUZ;break end end
return Logic.GetKnightTitle(R)>=
AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.NeededKnightTitle end;function AddOnInteractiveObjectTemplates.Global:TrebuchetSetNeededKnightTitle(dtQg85m1)
self.Data.Trebuchet.NeededKnightTitle=dtQg85m1 end
function AddOnInteractiveObjectTemplates.Global:CreateTrebuchetConstructionSite(PZrx2RR,WNo6rk8Y,Tc)
self:TrebuchetActivate()WNo6rk8Y=WNo6rk8Y or 4500;Tc=Tc or 35;local PpPWp=GetID(PZrx2RR)
Logic.SetModel(PpPWp,Models.Buildings_B_BuildingPlot_8x8)Logic.SetVisible(PpPWp,true)
self.Data.Trebuchet.Sites[PZrx2RR]={ConstructedTrebuchet=0,ConstructionCart=0,ReturningCart=0}
CreateObject{Name=PZrx2RR,Title=self.Data.Trebuchet.Description.Title,Text=self.Data.Trebuchet.Description.Text,Costs={Goods.G_Gold,WNo6rk8Y,Goods.G_Wood,Tc},Distance=1000,State=0,Condition=self.TrebuchetHasSufficentTitle,ConditionUnfulfilled=self.Data.Trebuchet.Error,Callback=function(drh_fwOO,P)
AddOnInteractiveObjectTemplates.Global:SpawnTrebuchetCart(P,drh_fwOO.Name)end}end
function AddOnInteractiveObjectTemplates.Global:DestroyTrebuchetConstructionSite(PE)
local PlUYS=self.Data.Trebuchet.Sites[PE].ConstructionCart;DestroyEntity(PlUYS)
local RJ=self.Data.Trebuchet.Sites[PE].ConstructedTrebuchet;DestroyEntity(RJ)
local Hw_tk1RM=self.Data.Trebuchet.Sites[PE].ReturningCart;DestroyEntity(Hw_tk1RM)self.Data.Trebuchet.Sites[PE]=
nil;Logic.SetVisible(GetID(PE),false)
RemoveInteractiveObject(PE)end
function AddOnInteractiveObjectTemplates.Global:SpawnTrebuchetCart(aEdSr,sgm)
local q1sywblh=Logic.GetStoreHouse(aEdSr)
local a4OdC8A,bGCfcNC=Logic.GetBuildingApproachPosition(q1sywblh)
local bPJy9vB=Logic.CreateEntity(Entities.U_SiegeEngineCart,a4OdC8A,bGCfcNC,0,aEdSr)Logic.SetEntitySelectableFlag(bPJy9vB,0)
self.Data.Trebuchet.Sites[sgm].ConstructionCart=bPJy9vB end
function AddOnInteractiveObjectTemplates.Global:SpawnTrebuchet(s2JH,NYDbF3OS)
local E=GetPosition(NYDbF3OS)
local _qg=Logic.CreateEntity(Entities.U_Trebuchet,E.X,E.Y,0,s2JH)
self.Data.Trebuchet.Sites[NYDbF3OS].ConstructedTrebuchet=_qg end
function AddOnInteractiveObjectTemplates.Global:ReturnTrebuchetToStorehouse(W09fPHP,U)
local wtMFz1In,RW7ED0IS,G_ZC_=Logic.EntityGetPos(U)
local G=Logic.CreateEntity(Entities.U_SiegeEngineCart,wtMFz1In,RW7ED0IS,0,W09fPHP)Logic.SetEntitySelectableFlag(G,0)local mPYod
for W,Tx in
pairs(self.Data.Trebuchet.Sites)do if Tx.ConstructedTrebuchet==U then mPYod=W end end
if mPYod then
self.Data.Trebuchet.Sites[mPYod].ReturningCart=G
self.Data.Trebuchet.Sites[mPYod].ConstructedTrebuchet=0;Logic.SetVisible(GetID(mPYod),true)
DestroyEntity(U)else DestroyEntity(G)end end
function AddOnInteractiveObjectTemplates.Global.OnTrebuchetDisambled(bo0,F6Lv6,CD8byLjb,HZed1,U2F8jO)
AddOnInteractiveObjectTemplates.Global:ReturnTrebuchetToStorehouse(F6Lv6,bo0)end
function AddOnInteractiveObjectTemplates.Global.WatchTrebuchetsAndCarts()
for JO,tR3r0L in
pairs(AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.Sites)do local VH=GetID(JO)
if tR3r0L.ConstructionCart~=0 then
if not
IsExisting(tR3r0L.ConstructionCart)then
AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.Sites[JO].ConstructionCart=0;API.InteractiveObjectActivate(JO)end
if not Logic.IsEntityMoving(tR3r0L.ConstructionCart)then
local VH=GetID(JO)local So_t_q,fUg,VuhcIvT=Logic.EntityGetPos(VH)
Logic.MoveSettler(tR3r0L.ConstructionCart,So_t_q,fUg)end
if IsNear(tR3r0L.ConstructionCart,JO,500)then
local Fg98ue7m,xR,Tk5LwCY=Logic.EntityGetPos(VH)
local jxOG=Logic.EntityGetPlayer(tR3r0L.ConstructionCart)
AddOnInteractiveObjectTemplates.Global:SpawnTrebuchet(jxOG,JO)DestroyEntity(tR3r0L.ConstructionCart)
AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.Sites[JO].ConstructionCart=0;Logic.SetVisible(VH,false)
Logic.CreateEffect(EGL_Effects.E_Shockwave01,Fg98ue7m,xR,0)end end
if tR3r0L.ConstructedTrebuchet~=0 then
if
not IsExisting(tR3r0L.ConstructedTrebuchet)then
AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.Sites[JO].ConstructedTrebuchet=0;Logic.SetVisible(VH,true)
API.InteractiveObjectActivate(JO)end
if
Logic.GetAmmunitionAmount(tR3r0L.ConstructedTrebuchet)==0 and
BundleEntitySelection.Local.Data.RefillTrebuchet==false then
local D0ViThw=Logic.EntityGetPlayer(tR3r0L.ConstructedTrebuchet)
AddOnInteractiveObjectTemplates.Global:ReturnTrebuchetToStorehouse(D0ViThw,tR3r0L.ConstructedTrebuchet)end end
if tR3r0L.ReturningCart~=0 then
if
not IsExisting(tR3r0L.ReturningCart)then
AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.Sites[JO].ReturningCart=0;API.InteractiveObjectActivate(JO)end;local jNHEX=Logic.EntityGetPlayer(tR3r0L.ReturningCart)
local EeI0Ja5p=Logic.GetStoreHouse(jNHEX)
if not Logic.IsEntityMoving(tR3r0L.ReturningCart)then
local If,zNQ5hv=Logic.GetBuildingApproachPosition(EeI0Ja5p)
Logic.MoveSettler(tR3r0L.ReturningCart,If,zNQ5hv)end
if IsNear(tR3r0L.ReturningCart,EeI0Ja5p,1100)then
local jNHEX=Logic.EntityGetPlayer(tR3r0L.ConstructionCart)DestroyEntity(tR3r0L.ReturningCart)end end end end
function AddOnInteractiveObjectTemplates.Global:CreateRandomChest(vL9jxaDI,bw,_4,YA,s)_4=(
_4 ~=nil and _4 >0 and _4)or 1;YA=(
YA~=nil and YA>1 and YA)or 2;if not s then
s=function(CnN3b)end end
assert(bw~=nil,"CreateRandomChest: Good does not exist!")
assert(_4 <YA,"CreateRandomChest: min amount must be smaller than max amount!")
local jLNm9vm3=ReplaceEntity(vL9jxaDI,Entities.XD_ScriptEntity,0)
Logic.SetModel(jLNm9vm3,Models.Doodads_D_X_ChestClose)Logic.SetVisible(jLNm9vm3,true)
CreateObject{Name=vL9jxaDI,Title=self.Data.Chests.Description.Title,Text=self.Data.Chests.Description.Text,Reward={bw,math.random(_4,YA)},Texture={1,6},Distance=650,State=0,CallbackOpened=s,Callback=function(QtFxq)
ReplaceEntity(QtFxq.Name,Entities.D_X_ChestOpenEmpty)QtFxq.CallbackOpened(QtFxq)end}end
function AddOnInteractiveObjectTemplates.Global:CreateRandomGoldChest(Nq)
AddOnInteractiveObjectTemplates.Global:CreateRandomChest(Nq,Goods.G_Gold,300,600)end
function AddOnInteractiveObjectTemplates.Global:CreateRandomResourceChest(u)
local eGVm7ZI={Goods.G_Iron,Goods.G_Stone,Goods.G_Wood,Goods.G_Wool,Goods.G_Carcass,Goods.G_Herb,Goods.G_Honeycomb,Goods.G_Milk,Goods.G_RawFish,Goods.G_Grain}local KY=eGVm7ZI[math.random(1,#eGVm7ZI)]
AddOnInteractiveObjectTemplates.Global:CreateRandomChest(u,KY,30,60)end
function AddOnInteractiveObjectTemplates.Global:CreateRandomLuxuryChest(Y9uov5wo)
local v={Goods.G_Salt,Goods.G_Dye}
if g_GameExtraNo>=1 then table.insert(v,Goods.G_Gems)
table.insert(v,Goods.G_MusicalInstrument)table.insert(v,Goods.G_Olibanum)end;local Wb=v[math.random(1,#v)]
AddOnInteractiveObjectTemplates.Global:CreateRandomChest(Y9uov5wo,Wb,50,100)end
function AddOnInteractiveObjectTemplates.Global:CreateIOMine(N83DW,CHcvDT4i,AfA8AazY,IQD,J9,g7g68E,cn)
local p3p8=ReplaceEntity(N83DW,Entities.XD_ScriptEntity)local TjHtv=Models.Doodads_D_SE_ResourceIron_Wrecked;if
CHcvDT4i==Entities.R_StoneMine then TjHtv=Models.R_SE_ResorceStone_10 end
Logic.SetVisible(p3p8,true)Logic.SetModel(p3p8,TjHtv)
local n2,Y2Ln,Qpx=Logic.EntityGetPos(p3p8)
local Sd=Logic.CreateEntity(Entities.D_ME_Rock_Set01_B_07,n2,Y2Ln,0,0)Logic.SetVisible(Sd,false)
CreateObject{Name=N83DW,Title=self.Data.Mines.Description.Title,Text=self.Data.Mines.Description.Text,Type=CHcvDT4i,Special=IQD,Costs=AfA8AazY,InvisibleBlocker=Sd,Distance=1500,Condition=self.ConditionBuildIOMine,CustomCondition=J9,ConditionUnfulfilled="Not implemented yet!",CallbackCreate=g7g68E,CallbackDepleted=cn,Callback=self.ActionBuildIOMine}end
function AddOnInteractiveObjectTemplates.Global:CreateIOIronMine(Pl,C,F6nvQCB,FPGRQXo,xV345,i)
assert(IsExisting(Pl))
if C then assert(API.TraverseTable(C,Goods))assert(
type(F6nvQCB)=="number")end
if FPGRQXo then
assert(API.TraverseTable(FPGRQXo,Goods))assert(type(xV345)=="number")end
self:CreateIOMine(Pl,Entities.R_IronMine,{C,F6nvQCB,FPGRQXo,xV345},i)end
function AddOnInteractiveObjectTemplates.Global:CreateIOStoneMine(UZV,xqIuC6,HKf,i,dAmAzsn,Ra0Dm)
assert(IsExisting(UZV))
if xqIuC6 then
assert(API.TraverseTable(xqIuC6,Goods))assert(type(HKf)=="number")end
if i then assert(API.TraverseTable(i,Goods))assert(
type(dAmAzsn)=="number")end
self:CreateIOMine(UZV,Entities.R_StoneMine,{xqIuC6,HKf,i,dAmAzsn},Ra0Dm)end
function AddOnInteractiveObjectTemplates.Global.ConditionBuildIOMine(YOrB_)
if
YOrB_.CustomCondition then return YOrB_.CustomCondition(YOrB_)==true end;return true end
function AddOnInteractiveObjectTemplates.Global.ActionBuildIOMine(xVFwg)
ReplaceEntity(xVFwg.Name,xVFwg.Type)DestroyEntity(xVFwg.InvisibleBlocker)
if
type(xVFwg.CallbackCreate)=="function"then xVFwg.CallbackCreate(xVFwg)end
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_SECOND,"","ControlIOMine",1,{},{xVFwg.Name})end
function AddOnInteractiveObjectTemplates.Global.ControlIOMine(tZD_IR)if
not IO[tZD_IR]then return true end
if not IsExisting(tZD_IR)then return true end;local QFzjWbSz=GetID(tZD_IR)
if
Logic.GetResourceDoodadGoodAmount(QFzjWbSz)==0 then
if IO[tZD_IR].Special==true then
local fo33=Models.Doodads_D_SE_ResourceIron_Wrecked;if IO[tZD_IR].Type==Entities.R_StoneMine then
fo33=Models.R_ResorceStone_Scaffold_Destroyed end
QFzjWbSz=ReplaceEntity(QFzjWbSz,Entities.XD_ScriptEntity)Logic.SetVisible(QFzjWbSz,true)
Logic.SetModel(QFzjWbSz,fo33)end;if type(IO[tZD_IR].CallbackDepleted)=="function"then
IO[tZD_IR].CallbackDepleted(IO[tZD_IR])end;return true end end
function AddOnInteractiveObjectTemplates.Global:ConstructionSiteActivate()if
self.Data.ConstructionSiteActivated then return end
self.Data.ConstructionSiteActivated=true
Core:AppendFunction("GameCallback_OnBuildingConstructionComplete",self.OnConstructionComplete)end
function AddOnInteractiveObjectTemplates.Global.OnConstructionComplete(pJu,S2wDuQ5)
local sc=AddOnInteractiveObjectTemplates.Global.Data.ConstructionSite.Sites[S2wDuQ5]if sc~=nil and sc.CompletedCallback then
sc.CompletedCallback(sc,S2wDuQ5)end end
function AddOnInteractiveObjectTemplates.Global:CreateIOBuildingSite(bc2,MtyJ,pE,E56wJS7,Nm5PX6TP,IUMp84E,BZIh,LN,G)
AddOnInteractiveObjectTemplates.Global:ConstructionSiteActivate()
local sJv0F=E56wJS7 or{Logic.GetEntityTypeFullCost(pE)}
local tV5mqR8G=BZIh or self.Data.ConstructionSite.Description.Title
local OnI=Text or self.Data.ConstructionSite.Description.Text;local FlfPsKy=GetID(bc2)
Logic.SetModel(FlfPsKy,Models.Buildings_B_BuildingPlot_10x10)Logic.SetVisible(FlfPsKy,true)
CreateObject{Name=bc2,Title=tV5mqR8G,Text=OnI,Texture=IUMp84E or{14,10},Distance=
Nm5PX6TP or 1500,Type=pE,Costs=sJv0F,Condition=AddOnInteractiveObjectTemplates.Global.ConditionConstructionSite,ConditionUnfulfilled=AddOnInteractiveObjectTemplates.Global.Data.ConstructionSite.Description.Unfulfilled,PlayerID=MtyJ,CompletedCallback=G,Callback=AddOnInteractiveObjectTemplates.Global.CallbackIOConstructionSite}end
function AddOnInteractiveObjectTemplates.Global.CallbackIOConstructionSite(ac6tKD)
local FM_=GetPosition(ac6tKD.Name)local Px0Dn8q=GetID(ac6tKD.Name)
local nGY=Logic.GetEntityOrientation(Px0Dn8q)
local t=Logic.CreateConstructionSite(FM_.X,FM_.Y,nGY,ac6tKD.Type,ac6tKD.PlayerID)Logic.SetVisible(Px0Dn8q,false)if(t==nil)then
API.Dbg('AddOnInteractiveObjectTemplates.Global:CreateIOBuildingSite: Failed to place construction site!')return end
AddOnInteractiveObjectTemplates.Global.Data.ConstructionSite.Sites[t]=ac6tKD
StartSimpleJobEx(AddOnInteractiveObjectTemplates.Global.ControlConstructionSite,t)end
function AddOnInteractiveObjectTemplates.Global.ConditionConstructionSite(oF)
local LaDDr=GetID(oF.Name)local UcX6Wx=GetTerritoryUnderEntity(LaDDr)
local gy=Logic.GetTerritoryPlayerID(UcX6Wx)
if Logic.GetStoreHouse(oF.PlayerID)==0 then return false end;if oF.PlayerID~=UcX6Wx then return false end;return true end
function AddOnInteractiveObjectTemplates.Global.ControlConstructionSite(qs)
if
AddOnInteractiveObjectTemplates.Global.Data.ConstructionSite.Sites[qs]==nil then return true end
if not IsExisting(qs)then
local HI=AddOnInteractiveObjectTemplates.Global.Data.ConstructionSite.Sites[qs].Name;Logic.SetVisible(GetID(HI),true)
API.InteractiveObjectActivate(HI)return true end end
function AddOnInteractiveObjectTemplates.Local:Install()end
Core:RegisterAddOn("AddOnInteractiveObjectTemplates")