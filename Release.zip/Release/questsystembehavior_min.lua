API=API or{}QSB=QSB or{}QSB.Version="RE 1.1.11 6/1/2019"
QSB.RealTime_SecondsSinceGameStart=0;ParameterType=ParameterType or{}g_QuestBehaviorVersion=1
g_QuestBehaviorTypes={}g_GameExtraNo=0
if Framework then g_GameExtraNo=Framework.GetGameExtraNo()elseif
MapEditor then g_GameExtraNo=MapEditor.GetGameExtraNo()end;function API.Install()Core:InitalizeBundles()end;function API.InstanceTable(QDnlt,LmcA2auZ)return
copy(QDnlt,LmcA2auZ)end
CopyTableRecursive=API.InstanceTable;function API.TraverseTable(Q,ZA)
for _IQQ,XpkjA in pairs(ZA)do if XpkjA==Q then return true end end;return false end
Inside=API.TraverseTable
function API.DumpTable(pVRj,fuZ3z86)local er="{"
if fuZ3z86 then er=fuZ3z86 .." = \n"..er end;Framework.WriteToLog(er)
for DFb100j,XL_ in pairs(pVRj)do
if type(XL_)=="table"then Framework.WriteToLog(
"["..DFb100j.."] = ")
API.DumpTable(XL_)elseif type(XL_)=="string"then Framework.WriteToLog("["..
DFb100j.."] = \""..XL_.."\"")else
Framework.WriteToLog(
"["..DFb100j.."] = "..tostring(XL_))end end;Framework.WriteToLog("}")end
function API.ConvertTableToString(WYdR)assert(type(WYdR)=="table")
local QKKks_zt="{"
for Are7xU,yxjl in pairs(WYdR)do local ZG;if(tonumber(Are7xU))then ZG=""..Are7xU else
ZG="\""..Are7xU.."\""end
if type(yxjl)=="table"then QKKks_zt=QKKks_zt..
"["..ZG.."] = "..
API.ConvertTableToString(yxjl)..", "elseif
type(yxjl)=="number"then
QKKks_zt=QKKks_zt.."["..ZG.."] = "..yxjl..", "elseif type(yxjl)=="string"then QKKks_zt=QKKks_zt..
"["..ZG.."] = \""..yxjl.."\", "elseif type(yxjl)=="boolean"or
type(yxjl)=="nil"then
QKKks_zt=QKKks_zt.."["..ZG..
"] = \""..tostring(yxjl).."\", "else
QKKks_zt=QKKks_zt.."["..
ZG.."] = \""..tostring(yxjl).."\", "end end;QKKks_zt=QKKks_zt.."}"return QKKks_zt end
function API.GetQuestID(Vu0cCAf)if type(Vu0cCAf)=="number"then return Vu0cCAf end;for q,kP7O5 in
pairs(Quests)do
if kP7O5 and q>0 then if kP7O5.Identifier==Vu0cCAf then return q end end end end;GetQuestID=API.GetQuestID
function API.IsValidateQuest(lqT)return Quests[lqT]~=nil or
Quests[API.GetQuestID(lqT)]~=nil end;IsValidQuest=API.IsValidateQuest;function API.FailAllQuests(...)for mP3mlD=1,#arg,1 do
API.FailQuest(arg[mP3mlD])end end
FailQuestsByName=API.FailAllQuests
function API.FailQuest(PrPyxMK,tczrIB)local a=Quests[GetQuestID(PrPyxMK)]
if a then
if not tczrIB then API.Info(
"fail quest "..PrPyxMK)end;a:RemoveQuestMarkers()a:Fail()end end;FailQuestByName=API.FailQuest;function API.RestartAllQuests(...)for wqU76o=1,#arg,1 do
API.RestartQuest(arg[wqU76o])end end
RestartQuestsByName=API.RestartAllQuests
function API.RestartQuest(LB1Z,N9L)local hDc_M=GetQuestID(LB1Z)local qW0lRiD1=Quests[hDc_M]
if qW0lRiD1 then if not N9L then API.Info(
"restart quest "..LB1Z)end
if
qW0lRiD1.Objectives then local hPQ=qW0lRiD1.Objectives
for R1FIoQI=1,hPQ[0]do local NsoTwDs=hPQ[R1FIoQI]
NsoTwDs.Completed=nil;local HGli=NsoTwDs.Type
if HGli==Objective.Deliver then local iy=NsoTwDs.Data
iy[3]=nil;iy[4]=nil;iy[5]=nil elseif g_GameExtraNo and g_GameExtraNo>=1 and
HGli==Objective.Refill then NsoTwDs.Data[2]=nil elseif
HGli==Objective.Protect or HGli==Objective.Object then local m6SCS0=NsoTwDs.Data;for NUhYw6R4=1,m6SCS0[0],1
do m6SCS0[-NUhYw6R4]=nil end elseif HGli==
Objective.DestroyEntities and NsoTwDs.Data[1]~=1 and
NsoTwDs.DestroyTypeAmount then
NsoTwDs.Data[3]=NsoTwDs.DestroyTypeAmount elseif HGli==Objective.Distance then if NsoTwDs.Data[1]==-65565 then NsoTwDs.Data[4].NpcInstance=
nil end elseif
HGli==Objective.Custom2 and NsoTwDs.Data[1].Reset then
NsoTwDs.Data[1]:Reset(qW0lRiD1,R1FIoQI)end end end
local function iD1IUx(Hv,Ch)local qW0lRiD1=qW0lRiD1;local urkh=qW0lRiD1[Hv]
if urkh then
for zhzpBSx=1,urkh[0]do local rHSjalVy=urkh[zhzpBSx]
if
rHSjalVy.Type==Ch then local TjhsnP=rHSjalVy.Data[1]if TjhsnP and TjhsnP.Reset then
TjhsnP:Reset(qW0lRiD1,zhzpBSx)end end end end end;iD1IUx("Triggers",Triggers.Custom2)
iD1IUx("Rewards",Reward.Custom)iD1IUx("Reprisals",Reprisal.Custom)
qW0lRiD1.Result=nil;local JLCOx_ak=qW0lRiD1.State;qW0lRiD1.State=QuestState.NotTriggered
Logic.ExecuteInLuaLocalState(
"LocalScriptCallback_OnQuestStatusChanged("..qW0lRiD1.Index..")")if JLCOx_ak==QuestState.Over then
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_SECOND,"",QuestTemplate.Loop,1,0,{qW0lRiD1.QueueID})end
return hDc_M,qW0lRiD1 end end;RestartQuestByName=API.RestartQuest;function API.StartAllQuests(...)for t5jzEd9=1,#arg,1 do
API.StartQuest(arg[t5jzEd9])end end
StartQuestsByName=API.StartAllQuests
function API.StartQuest(JZAU2,zPXTTg)local seMLr=Quests[GetQuestID(JZAU2)]
if seMLr then if not zPXTTg then API.Info(
"start quest "..JZAU2)end
seMLr:SetMsgKeyOverride()seMLr:SetIconOverride()seMLr:Trigger()end end;StartQuestByName=API.StartQuest;function API.StopAllQuests(...)for qX=1,#arg,1 do
API.StopQuest(arg[qX])end end
StopQuestsByName=API.StopAllQuests
function API.StopQuest(h_8,xL7OTb)local w8T3f=Quests[GetQuestID(h_8)]
if w8T3f then
if not xL7OTb then API.Info(
"interrupt quest "..h_8)end;w8T3f:RemoveQuestMarkers()w8T3f:Interrupt(-1)end end;StopQuestByName=API.StopQuest;function API.WinAllQuests(...)for K=1,#arg,1 do
API.WinQuest(arg[K])end end
WinQuestsByName=API.WinAllQuests
function API.WinQuest(qL,vfIyB)local quNsijN=Quests[GetQuestID(qL)]
if quNsijN then if not vfIyB then API.Info("win quest "..
qL)end
quNsijN:RemoveQuestMarkers()quNsijN:Success()end end;WinQuestByName=API.WinQuest;function API.Note(QUh2tc)
QUh2tc=API.EnsureMessage(QUh2tc)local qboV=Logic.DEBUG_AddNote;if GUI then qboV=GUI.AddNote end
qboV(QUh2tc)end
GUI_Note=API.Note
function API.StaticNote(nSBOx7)nSBOx7=API.EnsureMessage(nSBOx7)if not GUI then
Logic.ExecuteInLuaLocalState(
'GUI.AddStaticNote("'..nSBOx7 ..'")')return end
GUI.AddStaticNote(nSBOx7)end
function API.ClearNotes()if not GUI then
Logic.ExecuteInLuaLocalState('GUI.ClearNotes()')return end;GUI.ClearNotes()end;function API.Log(u)local K=(GUI and"Local")or"Global"
local i1=Logic.GetTimeMs()
Framework.WriteToLog(K..":"..i1 ..": "..u)end
function API.Message(zz1QI)
zz1QI=API.EnsureMessage(zz1QI)if not GUI then
Logic.ExecuteInLuaLocalState('Message("'..zz1QI..'")')return end;Message(zz1QI)end;GUI_NoteDown=API.Message
function API.EnsureMessage(kFTAh)
local LBf=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if type(kFTAh)=="table"then kFTAh=kFTAh[LBf]end;return
tostring(kFTAh)end
function API.Fatal(dijn4Ph)
if QSB.Log.CurrentLevel<=QSB.Log.Level.FATAL then API.StaticNote(
"FATAL: "..dijn4Ph)end;API.Log("FATAL: "..dijn4Ph)end;API.Dbg=API.Fatal;dbg=API.Fatal;function API.Warn(CO1)if QSB.Log.CurrentLevel<=
QSB.Log.Level.WARNING then
API.StaticNote("WARNING: "..CO1)end
API.Log("WARNING: "..CO1)end
warn=API.Warn;function API.Info(RlZo)if QSB.Log.CurrentLevel<=QSB.Log.Level.INFO then
API.Note("INFO: "..RlZo)end
API.Log("INFO: "..RlZo)end
info=API.Info;function API.Trace(SUn)if QSB.Log.CurrentLevel<=QSB.Log.Level.TRACE then
API.Note("TRACE: "..SUn)end
API.Log("TRACE: "..SUn)end
trace=API.Trace
QSB.Log={Level={OFF=90000,FATAL=4000,WARNING=3000,INFO=2000,TRACE=1000,ALL=0}}QSB.Log.CurrentLevel=QSB.Log.Level.FATAL
function API.SetLogLevel(Ib4)assert(
type(Ib4)=="number")QSB.Log.CurrentLevel=Ib4 end
function API.SendCart(fjV1G2,Do,_,TqYJ4,DI,b)local E=GetID(fjV1G2)if not IsExisting(E)then return end
local KMw7_i1s;local CQi,nHlJ,lw4Q7kbl=Logic.EntityGetPos(E)
local IN=Logic.GetGoodCategoryForGoodType(_)local QYf1=0
if Logic.IsBuilding(E)==1 then
CQi,nHlJ=Logic.GetBuildingApproachPosition(E)QYf1=Logic.GetEntityOrientation(E)-90 end
if IN==GoodCategories.GC_Resource then
KMw7_i1s=Logic.CreateEntityOnUnblockedLand(Entities.U_ResourceMerchant,CQi,nHlJ,QYf1,Do)elseif _==Goods.G_Medicine then
KMw7_i1s=Logic.CreateEntityOnUnblockedLand(Entities.U_Medicus,CQi,nHlJ,QYf1,Do)elseif _==Goods.G_Gold then
if DI then
KMw7_i1s=Logic.CreateEntityOnUnblockedLand(DI,CQi,nHlJ,QYf1,Do)else
KMw7_i1s=Logic.CreateEntityOnUnblockedLand(Entities.U_GoldCart,CQi,nHlJ,QYf1,Do)end else
KMw7_i1s=Logic.CreateEntityOnUnblockedLand(Entities.U_Marketer,CQi,nHlJ,QYf1,Do)end;Logic.HireMerchant(KMw7_i1s,Do,_,TqYJ4,Do,b)
return KMw7_i1s end;SendCart=API.SendCart
function API.ReplaceEntity(RfsnisO,lvW2ga,T7RKP)local _L6Bs=GetID(RfsnisO)
if _L6Bs==0 then return end;local SH=GetPosition(_L6Bs)
local wU4wYbA9=T7RKP or Logic.EntityGetPlayer(_L6Bs)local fFeQcIM=Logic.GetEntityOrientation(_L6Bs)
local JEHSHPh3=Logic.GetEntityName(_L6Bs)DestroyEntity(_L6Bs)
if
Logic.IsEntityTypeInCategory(lvW2ga,EntityCategories.Soldier)==1 then return
CreateBattalion(wU4wYbA9,lvW2ga,SH.X,SH.Y,1,JEHSHPh3,fFeQcIM)else return
CreateEntity(wU4wYbA9,lvW2ga,SH,JEHSHPh3,fFeQcIM)end end;ReplaceEntity=API.ReplaceEntity
function API.LookAt(bb,o5e6fP,iq7ol)local eMV=GetEntityId(bb)
local WDTNkTD=GetEntityId(o5e6fP)if
not IsExisting(eMV)or not IsExisting(WDTNkTD)then
API.Warn("API.LookAt: One entity is invalid or dead!")return end
local Oejsws,CkD73N0=Logic.GetEntityPosition(eMV)local PlwhaRKJ,Caz4NM4Z=Logic.GetEntityPosition(WDTNkTD)
local XVxxx=math.deg(math.atan2((
Caz4NM4Z-CkD73N0),(PlwhaRKJ-Oejsws)))
if Logic.IsBuilding(eMV)==1 then XVxxx=XVxxx-90 end;iq7ol=iq7ol or 0
Logic.SetOrientation(eMV,XVxxx+iq7ol)end;LookAt=API.LookAt;function API.Confront(hD,G5BuU5)API.LookAt(hD,G5BuU5)
API.LookAt(G5BuU5,hD)end
function API.GetDistance(AfwsY,T)if
(type(AfwsY)=="string")or(type(AfwsY)=="number")then
AfwsY=GetPosition(AfwsY)end
if(type(T)=="string")or(
type(T)=="number")then T=GetPosition(T)end
if type(AfwsY)~="table"or type(T)~="table"then return{X=1,Y=1}end;local WZs=(AfwsY.X-T.X)local ITdz=(AfwsY.Y-T.Y)return math.sqrt(
(WZs^2)+ (ITdz^2))end;GetDistance=API.GetDistance
function API.ValidatePosition(AjfoUo)
if type(AjfoUo)=="table"then
if
(
AjfoUo.X~=nil and type(AjfoUo.X)=="number")and
(AjfoUo.Y~=nil and type(AjfoUo.Y)=="number")then
local Er9zidsB={Logic.WorldGetSize()}if
AjfoUo.X<=Er9zidsB[1]and AjfoUo.X>=0 and AjfoUo.Y<=
Er9zidsB[2]and AjfoUo.Y>=0 then return true end end end;return false end;IsValidPosition=API.ValidatePosition
function API.LocateEntity(X)if(type(X)=="table")then
return X end
if(not IsExisting(X))then return{X=0,Y=0,Z=0}end;local dR,JFXtQwy,uMV17h0=Logic.EntityGetPos(GetID(X))return
{X=dR,Y=JFXtQwy,Z=uMV17h0}end;GetPosition=API.LocateEntity
function API.ActivateIO(E2NZK,WNWWe)State=State or 0;if GUI then
GUI.SendScriptCommand(
'API.ActivateIO("'..E2NZK..'", '..State..')')return end;if not IsExisting(E2NZK)then
return end
Logic.InteractiveObjectSetAvailability(GetID(E2NZK),true)for zMzjn3lk=1,8 do
Logic.InteractiveObjectSetPlayerState(GetID(E2NZK),zMzjn3lk,State)end end;InteractiveObjectActivate=API.ActivateIO
function API.DeactivateIO(Trkkpmd)if GUI then
GUI.SendScriptCommand('API.DeactivateIO("'..
Trkkpmd..'")')return end;if not IsExisting(Trkkpmd)then
return end
Logic.InteractiveObjectSetAvailability(GetID(Trkkpmd),false)for L=1,8 do
Logic.InteractiveObjectSetPlayerState(GetID(Trkkpmd),L,2)end end;InteractiveObjectDeactivate=API.DeactivateIO
function API.GetEntitiesOfCategoryInTerritory(GGv,ZIzh4Si,c8D4n81)local cSjJHx={}
local fa={}
if(GGv==-1)then
for M=0,8 do local dIZlrvD=0
repeat
fa={Logic.GetEntitiesOfCategoryInTerritory(c8D4n81,M,ZIzh4Si,dIZlrvD)}cSjJHx=Array_Append(cSjJHx,fa)dIZlrvD=dIZlrvD+#fa until#fa==0 end else local jQgsATKd=0
repeat
fa={Logic.GetEntitiesOfCategoryInTerritory(c8D4n81,GGv,ZIzh4Si,jQgsATKd)}cSjJHx=Array_Append(cSjJHx,fa)jQgsATKd=jQgsATKd+#fa until#fa==0 end;return cSjJHx end;GetEntitiesOfCategoryInTerritory=API.GetEntitiesOfCategoryInTerritory
function API.EnsureScriptName(aBbGg)
if
type(aBbGg)=="string"then return aBbGg else
assert(type(aBbGg)=="number")local D9=Logic.GetEntityName(aBbGg)
if
(type(D9)~="string"or D9 =="")then
QSB.GiveEntityNameCounter=(QSB.GiveEntityNameCounter or 0)+1
D9="EnsureScriptName_Name_"..QSB.GiveEntityNameCounter;Logic.SetEntityName(aBbGg,D9)end;return D9 end end;GiveEntityName=API.EnsureScriptName;function API.Bridge(G,gE)
if not GUI then
Logic.ExecuteInLuaLocalState(G)else GUI.SendScriptCommand(G,gE)end end;function API.ToBoolean(QgC)return
Core:ToBoolean(QgC)end
AcceptAlternativeBoolean=API.ToBoolean
function API.AddSaveGameAction(CYoa)if GUI then
API.Fatal("API.AddSaveGameAction: Can not be used from the local script!")return end;return
Core:AppendFunction("Mission_OnSaveGameLoaded",CYoa)end;AddOnSaveGameLoadedAction=API.AddSaveGameAction
function API.AddHotKey(K3ipRr,F2tY)if not GUI then
API.Fatal("API.AddHotKey: Can not be used from the global script!")return end;g_KeyBindingsOptions.Descriptions=
nil
table.insert(Core.Data.HotkeyDescriptions,{K3ipRr,F2tY})return#Core.Data.HotkeyDescriptions end
function API.RemoveHotKey(rb21L2)if not GUI then
API.Fatal("API.RemoveHotKey: Can not be used from the global script!")return end
if

type(rb21L2)~="number"or rb21L2 >#Core.Data.HotkeyDescriptions then
API.Fatal("API.RemoveHotKey: No candidate found or Index is nil!")return end;Core.Data.HotkeyDescriptions[rb21L2]=nil end
function API.RealTimeGetSecondsPassedSinceGameStart()return QSB.RealTime_SecondsSinceGameStart end
function API.RealTimeWait(o_v255,wUVm,...)
StartSimpleJobEx(function(VQ,oTYNsnP,I,L)
if
(QSB.RealTime_SecondsSinceGameStart>=VQ+oTYNsnP)then if#L>0 then I(unpack(L))else I()end;return true end end,QSB.RealTime_SecondsSinceGameStart,o_v255,wUVm,{...})end
function copy(mR5gwW,DfbW)DfbW=DfbW or{}
assert(type(mR5gwW)=="table")assert(type(DfbW)=="table")
for sh,rrFLbCtj in pairs(mR5gwW)do
if
type(rrFLbCtj)=="table"then DfbW[sh]=DfbW[sh]or{}
for YcPea0vg,usLpLoaH in pairs(copy(rrFLbCtj))do DfbW[sh][YcPea0vg]=
DfbW[sh][YcPea0vg]or usLpLoaH end else DfbW[sh]=DfbW[sh]or rrFLbCtj end end;return DfbW end
function class(e7dv)
for inx0,A5k5yt in pairs(_G)do if A5k5yt==e7dv then e7dv.className=inx0 end end;e7dv.construct=e7dv.construct or function(B7SHDx7h)end
e7dv.clone=
e7dv.clone or function(EEpoeR)return copy(EEpoeR)end
e7dv.toString=e7dv.toString or
function(_k)local Ef=""
for KfM,Vd in pairs(_k)do Ef=Ef..tostring(KfM)..
":"..tostring(Vd)..";"end;return"{"..Ef.."}"end
e7dv.equals=e7dv.equals or
function(Oynw,QBO)if type(QBO)~="table"then return false end
for s4ggux,hrVI4meU in pairs(Oynw)do if
hrVI4meU~=QBO[s4ggux]then return false end end;return true end;return e7dv end;function inherit(xEq6TAF,UIjls)local jdLnB0vD=copy(UIjls,xEq6TAF)jdLnB0vD.parent=UIjls;return
class(jdLnB0vD)end;function new(PSlD,...)
local nN=copy(PSlD)if nN.parent then nN.parent=new(nN.parent,...)end
nN:construct(...)return nN end
Core={Data={Overwrite={StackedFunctions={},AppendedFunctions={},Fields={}},HotkeyDescriptions={},BundleInitializerList={},InitalizedBundles={}}}
function Core:InitalizeBundles()
if not GUI then self:SetupGobal_HackCreateQuest()
self:SetupGlobal_HackQuestSystem()
StartSimpleJobEx(CoreJob_CalculateRealTimeSinceGameStart)else self:SetupLocal_HackRegisterHotkey()
StartSimpleJobEx(CoreJob_CalculateRealTimeSinceGameStart)end
for J,A in pairs(self.Data.BundleInitializerList)do local g3Qeqnr=_G[A]
if not GUI then if
g3Qeqnr.Global~=nil and g3Qeqnr.Global.Install~=nil then
g3Qeqnr.Global:Install()g3Qeqnr.Local=nil end else if
g3Qeqnr.Local~=nil and g3Qeqnr.Local.Install~=nil then
g3Qeqnr.Local:Install()g3Qeqnr.Global=nil end end;self.Data.InitalizedBundles[A]=true
collectgarbage()end end
function Core:SetupGobal_HackCreateQuest()
CreateQuest=function(qHpY64,z,qccJ5b,ARuba,Wo53nZ,XRfQ,gFPRdEC,lw9gLt3,T)local I5={}local JmE={}local s4={}local FFG={}
local a31jEAS=Logic.Quest_GetQuestNumberOfBehaviors(qHpY64)
for LS4h=0,a31jEAS-1,1 do
local eux092_P=Logic.Quest_GetQuestBehaviorName(qHpY64,LS4h)local ZA9=GetBehaviorTemplateByName(eux092_P)
assert(ZA9,"No template for name: "..
eux092_P.." - using an invalid QuestSystemBehavior.lua?!")local hWgmxm={}Table_Copy(hWgmxm,ZA9)
local UBg54E=Logic.Quest_GetQuestBehaviorParameter(qHpY64,LS4h)for gQGq=1,#UBg54E do
hWgmxm:AddParameter(gQGq-1,UBg54E[gQGq])end
if(hWgmxm.GetGoalTable~=nil)then JmE[
#JmE+1]=hWgmxm:GetGoalTable()
JmE[#JmE].Context=hWgmxm;JmE[#JmE].FuncOverrideIcon=hWgmxm.GetIcon
JmE[#JmE].FuncOverrideMsgKey=hWgmxm.GetMsgKey end;if(hWgmxm.GetTriggerTable~=nil)then
I5[#I5+1]=hWgmxm:GetTriggerTable()end
if
(hWgmxm.GetReprisalTable~=nil)then FFG[#FFG+1]=hWgmxm:GetReprisalTable()end;if(hWgmxm.GetRewardTable~=nil)then
s4[#s4+1]=hWgmxm:GetRewardTable()end end;if(#I5 ==0)or(#JmE==0)then return end
if
Core:CheckQuestName(qHpY64)then
local OyHc5FEv=QuestTemplate:New(qHpY64,z or 1,qccJ5b or 1,JmE,I5,tonumber(Wo53nZ)or 0,s4,FFG,nil,nil,(not ARuba or(gFPRdEC and
gFPRdEC~="")),(
not ARuba or(lw9gLt3 and lw9gLt3 ~="")or(T and T~="")),XRfQ,gFPRdEC,lw9gLt3,T)g_QuestNameToID[qHpY64]=OyHc5FEv else
dbg("Quest '"..tostring(questName)..
"': invalid questname! Contains forbidden characters!")end end end
function Core:SetupGlobal_HackQuestSystem()
QuestTemplate.Trigger_Orig_QSB_Core=QuestTemplate.Trigger
QuestTemplate.Trigger=function(Dn1Xi)
QuestTemplate.Trigger_Orig_QSB_Core(Dn1Xi)
for _gGmBBE=1,Dn1Xi.Objectives[0]do
if Dn1Xi.Objectives[_gGmBBE].Type==
Objective.Custom2 and
Dn1Xi.Objectives[_gGmBBE].Data[1].SetDescriptionOverwrite then
local rIX4=Dn1Xi.Objectives[_gGmBBE].Data[1]:SetDescriptionOverwrite(Dn1Xi)Core:ChangeCustomQuestCaptionText(rIX4,Dn1Xi)break end end end;QuestTemplate.Interrupt_Orig_QSB_Core=QuestTemplate.Interrupt
QuestTemplate.Interrupt=function(AI14eFhp)
QuestTemplate.Interrupt_Orig_QSB_Core(AI14eFhp)
for iW2O=1,AI14eFhp.Objectives[0]do
if AI14eFhp.Objectives[iW2O].Type==
Objective.Custom2 and
AI14eFhp.Objectives[iW2O].Data[1].Interrupt then
AI14eFhp.Objectives[iW2O].Data[1]:Interrupt(AI14eFhp,iW2O)end end
for Gdp=1,AI14eFhp.Triggers[0]do
if

AI14eFhp.Triggers[Gdp].Type==Triggers.Custom2 and AI14eFhp.Triggers[Gdp].Data[1].Interrupt then
AI14eFhp.Triggers[Gdp].Data[1]:Interrupt(AI14eFhp,Gdp)end end end end
function Core:SetupLocal_HackRegisterHotkey()
function g_KeyBindingsOptions:OnShow()
local nbqmx=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if Game~=nil then
XGUIEng.ShowWidget("/InGame/KeyBindingsMain/Backdrop",1)else
XGUIEng.ShowWidget("/InGame/KeyBindingsMain/Backdrop",0)end
if
g_KeyBindingsOptions.Descriptions==nil then g_KeyBindingsOptions.Descriptions={}
DescRegister("MenuInGame")DescRegister("MenuDiplomacy")
DescRegister("MenuProduction")DescRegister("MenuPromotion")
DescRegister("MenuWeather")DescRegister("ToggleOutstockInformations")
DescRegister("JumpMarketplace")DescRegister("JumpMinimapEvent")
DescRegister("BuildingUpgrade")DescRegister("BuildLastPlaced")
DescRegister("BuildStreet")DescRegister("BuildTrail")DescRegister("KnockDown")
DescRegister("MilitaryAttack")DescRegister("MilitaryStandGround")
DescRegister("MilitaryGroupAdd")DescRegister("MilitaryGroupSelect")
DescRegister("MilitaryGroupStore")DescRegister("MilitaryToggleUnits")
DescRegister("UnitSelect")DescRegister("UnitSelectToggle")
DescRegister("UnitSelectSameType")DescRegister("StartChat")DescRegister("StopChat")
DescRegister("QuickSave")DescRegister("QuickLoad")
DescRegister("TogglePause")DescRegister("RotateBuilding")
DescRegister("ExitGame")DescRegister("Screenshot")
DescRegister("ResetCamera")DescRegister("CameraMove")
DescRegister("CameraMoveMouse")DescRegister("CameraZoom")
DescRegister("CameraZoomMouse")DescRegister("CameraRotate")
for IWQcC,cvRh in
pairs(Core.Data.HotkeyDescriptions)do
if cvRh then cvRh[1]=
(type(cvRh[1])=="table"and cvRh[1][nbqmx])or cvRh[1]cvRh[2]=(
type(cvRh[2])=="table"and cvRh[2][nbqmx])or
cvRh[2]
table.insert(g_KeyBindingsOptions.Descriptions,1,cvRh)end end end
XGUIEng.ListBoxPopAll(g_KeyBindingsOptions.Widget.ShortcutList)
XGUIEng.ListBoxPopAll(g_KeyBindingsOptions.Widget.ActionList)
for W9yaJm,oJ1ec in ipairs(g_KeyBindingsOptions.Descriptions)do
XGUIEng.ListBoxPushItem(g_KeyBindingsOptions.Widget.ShortcutList,oJ1ec[1])
XGUIEng.ListBoxPushItem(g_KeyBindingsOptions.Widget.ActionList,oJ1ec[2])end end end;function Core:RegisterBundle(L)
return self.Data.InitalizedBundles[Bundle]==true end
function Core:RegisterBundle(MMNWLk)
local x6Ni=string.format("Error while initialize bundle '%s': does not exist!",tostring(MMNWLk))assert(_G[MMNWLk]~=nil,x6Ni)
table.insert(self.Data.BundleInitializerList,MMNWLk)end
function Core:RegisterAddOn(Q2waXkyp)
local EG72=string.format("Error while initialize addon '%s': does not exist!",tostring(Q2waXkyp))assert(_G[Q2waXkyp]~=nil,EG72)
table.insert(self.Data.BundleInitializerList,Q2waXkyp)end
function Core:RegisterBehavior(mlTMZ)if GUI then return end;if mlTMZ.RequiresExtraNo and
mlTMZ.RequiresExtraNo>g_GameExtraNo then return end
if not _G[
"b_"..mlTMZ.Name]then
dbg("AddQuestBehavior: can not find "..mlTMZ.Name.."!")else
if not _G["b_"..mlTMZ.Name].new then
_G["b_"..mlTMZ.Name].new=function(q,...)
local xb6=API.InstanceTable(q)
if q.Parameter then for yK=1,table.getn(q.Parameter)do
xb6:AddParameter(yK-1,arg[yK])end end;return xb6 end end
for rHLz2GD=1,#g_QuestBehaviorTypes,1 do if
g_QuestBehaviorTypes[rHLz2GD].Name==mlTMZ.Name then return end end;table.insert(g_QuestBehaviorTypes,mlTMZ)end end;function Core:CheckQuestName(BlW0RhJA)return
string.find(BlW0RhJA,"^[A-Za-z0-9_]+$")~=nil end
function Core:ChangeCustomQuestCaptionText(Uy,n)
n.QuestDescription=Uy
Logic.ExecuteInLuaLocalState(
[[
        XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives/Custom/BGDeco",0)
        local identifier = "]]..
n.Identifier..

[["
        for i=1, Quests[0] do
            if Quests[i].Identifier == identifier then
                local text = Quests[i].QuestDescription
                XGUIEng.SetText("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives/Custom/Text", "]]..Uy..[[")
                break
            end
        end
    ]])end
function Core:StackFunction(TKu,M6kL,M7o_)
if
not self.Data.Overwrite.StackedFunctions[TKu]then
self.Data.Overwrite.StackedFunctions[TKu]={Original=self:GetFunctionInString(TKu),Attachments={}}
local dk2X7J7=function(...)local jv
for MW,E2OQ in
pairs(self.Data.Overwrite.StackedFunctions[TKu].Attachments)do jv=E2OQ(unpack(arg))if jv~=nil then return jv end end
jv=self.Data.Overwrite.StackedFunctions[TKu].Original(unpack(arg))return jv end;self:ReplaceFunction(TKu,dk2X7J7)end
M7o_=M7o_ or#
self.Data.Overwrite.StackedFunctions[TKu].Attachments
table.insert(self.Data.Overwrite.StackedFunctions[TKu].Attachments,M7o_,M6kL)end
function Core:AppendFunction(SnbfLb6,ay,W)
if
not self.Data.Overwrite.AppendedFunctions[SnbfLb6]then
self.Data.Overwrite.AppendedFunctions[SnbfLb6]={Original=self:GetFunctionInString(SnbfLb6),Attachments={}}
local WzM=function(...)
local PSx=self.Data.Overwrite.AppendedFunctions[SnbfLb6].Original(unpack(arg))
for I,wnA in
pairs(self.Data.Overwrite.AppendedFunctions[SnbfLb6].Attachments)do PSx=wnA(unpack(arg))end;return PSx end;self:ReplaceFunction(SnbfLb6,WzM)end
W=W or#
self.Data.Overwrite.AppendedFunctions[SnbfLb6].Attachments
table.insert(self.Data.Overwrite.AppendedFunctions[SnbfLb6].Attachments,W,ay)end
function Core:ReplaceFunction(cW,PHpCof2)assert(type(cW)=="string")local bUPpn4T2=_G
local sode,G9zkKODk=cW:find("%.")
while(sode~=nil)do local ld9GuG4t=cW:sub(1,G9zkKODk-1)ld9GuG4t=
(
tonumber(ld9GuG4t)~=nil and tonumber(ld9GuG4t))or ld9GuG4t
bUPpn4T2=bUPpn4T2[ld9GuG4t]cW=cW:sub(G9zkKODk+1)sode,G9zkKODk=cW:find("%.")end
local MGt=(tonumber(cW)~=nil and tonumber(cW))or cW;bUPpn4T2[MGt]=PHpCof2 end
function Core:GetFunctionInString(KpCCA,H6)
if not H6 then local hgsKvTz,zEt=KpCCA:find("%.")
if hgsKvTz then
local Wjojpvg=KpCCA:sub(1,hgsKvTz-1)local l2PqbWw=KpCCA:sub(zEt+1,KpCCA:len())return
self:GetFunctionInString(l2PqbWw,_G[Wjojpvg])else return _G[KpCCA]end end
if type(H6)=="table"then local EJTH9,qTB82=KpCCA:find("%.")
if EJTH9 then
local KL=KpCCA:sub(1,EJTH9-1)local EATFLbgY=KpCCA:sub(qTB82+1,KpCCA:len())return
self:GetFunctionInString(EATFLbgY,H6[KL])else return H6[KpCCA]end end end
function Core:ToBoolean(FF)if type(FF)=="boolean"then return FF end;if
string.find(string.lower(tostring(FF)),"^[tjy\\+].*$")then return true end;return false end
function CoreJob_CalculateRealTimeSinceGameStart()
if not QSB.RealTime_LastTimeStamp then
if GUI then
QSB.RealTime_LastTimeStamp=XGUIEng.GetSystemTime()else QSB.RealTime_LastTimeStamp=Framework.TimeGetTime()end end;local rh;if GUI then rh=XGUIEng.GetSystemTime()else
rh=Framework.TimeGetTime()end;if
QSB.RealTime_LastTimeStamp+1 <=rh then QSB.RealTime_LastTimeStamp=rh
QSB.RealTime_SecondsSinceGameStart=QSB.RealTime_SecondsSinceGameStart+1 end end;BundleBriefingSystem={}API=API or{}QSB=QSB or{}
function API.PauseQuestsDuringBriefings(YcCR)if GUI then
API.Bridge(
"API.PauseQuestsDuringBriefings("..tostring(YcCR)..")")return end;return
BundleBriefingSystem.Global:PauseQuestsDuringBriefings(YcCR)end;PauseQuestsDuringBriefings=API.PauseQuestsDuringBriefings
function API.IsBriefingFinished(G3p2Yn)if GUI then
API.Fatal("API.IsBriefingFinished: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:IsBriefingFinished(G3p2Yn)end;IsBriefingFinished=API.IsBriefingFinished
function API.GetSelectedAnswerFromMCPage(_jkkD9)if GUI then
API.Fatal("API.GetSelectedAnswerFromMCPage: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:MCGetSelectedAnswer(_jkkD9)end;MCGetSelectedAnswer=API.GetSelectedAnswerFromMCPage
function API.GetCurrentBriefingPage(D)if GUI then
API.Fatal("API.GetCurrentBriefingPage: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:GetCurrentBriefingPage(D)end;GetCurrentBriefingPage=API.GetCurrentBriefingPage
function API.GetCurrentBriefing()if GUI then
API.Fatal("API.GetCurrentBriefing: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:GetCurrentBriefing()end;GetCurrentBriefing=API.GetCurrentBriefing
function API.AddPages(DMn)if GUI then
API.Fatal("API.AddPages: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:AddPages(DMn)end;AddPages=API.AddPages
function API.AddFlights(GBzFRjVV)if GUI then
API.Fatal("API.AddFlights: Can only be used in the global script!")return end;return
BundleBriefingSystem.Global:AddFlights(GBzFRjVV)end;AddFlights=API.AddFlights;function AP(pG4C8fDK)
API.Fatal("AP: Please use the function provides by AddPages!")end;function AF(LLFUU)
API.Fatal("AF: Please use the function provides by AddFlights!")end;function ASF(kdmQtj6,Hc35_,ubP,eN0UMW,...)
API.Fatal("ASF: Please use the function provides by AddFlights!")end;function ASP(lAG,AvEtR8Y,rl3MMqfm,nQj,Eq8jDq)
API.Fatal("ASP: Please use the function provides by AddPages!")end;function ASMC(LnQUN,Gm1,Jp,NwBqNl3C,...)
API.Fatal("ASMC: Please use the function provides by AddPages!")end
BundleBriefingSystem={Global={Data={PlayedBriefings={},QuestsPausedWhileBriefingActive=true,BriefingID=0}},Local={Data={}}}function BundleBriefingSystem.Global:Install()
self:InitalizeBriefingSystem()end
function BundleBriefingSystem.Global:PauseQuestsDuringBriefings(XuqjvYPF)self.Data.QuestsPausedWhileBriefingActive=
XuqjvYPF==true end
function BundleBriefingSystem.Global:IsBriefingFinished(Trh)return
self.Data.PlayedBriefings[Trh]==true end
function BundleBriefingSystem.Global:MCGetSelectedAnswer(K)if K.mc and K.mc.given then
return K.mc.given end;return 0 end;function BundleBriefingSystem.Global:GetCurrentBriefingPage(uK)return
BriefingSystem.currBriefing[uK]end;function BundleBriefingSystem.Global:GetCurrentBriefing()return
BriefingSystem.currBriefing end
function BundleBriefingSystem.Global:AddFlights(s0FU)
local wQl=function(m4u)
local StZ=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
assert(type(m4u)=="table"and#m4u>0)local C1NqzxY=m4u.Duration/ (#m4u-1)local T1gVrYq=0
for T1gVrYq=1,#m4u,1 do local P5G=
m4u[T1gVrYq].Title or""
if type(P5G)=="table"then P5G=P5G[StZ]end;local JC=m4u[T1gVrYq].Text or""if type(JC)=="table"then
JC=JC[StZ]end
local PDA={cutscene={Position=m4u[T1gVrYq].Position,LookAt=m4u[T1gVrYq].LookAt},title=P5G,text=JC,action=m4u[T1gVrYq].Action,faderAlpha=(
T1gVrYq==1 and m4u.FadeIn and 1)or nil,fadeIn=(
T1gVrYq==1 and m4u.FadeIn)or nil,fadeOut=
(T1gVrYq==#m4u and
m4u.FadeOut and(-m4u.FadeOut))or nil,duration=(T1gVrYq==1 and 0)or C1NqzxY,flyTime=(
T1gVrYq>1 and C1NqzxY)or nil,splashscreen=m4u.Splashscreen}table.insert(s0FU,PDA)end end
local g=function(K,qne5Stra,FKLmmhnQ,F82,...)local wJ6tY_={}
for TNg=1,#arg,6 do
local wO9T=(TNg==1 and FKLmmhnQ)or nil
table.insert(wJ6tY_,{Position={X=arg[TNg],Y=arg[TNg+1],Z=arg[TNg+2]},LookAt={X=arg[TNg+3],Y=arg[TNg+4],Z=arg[
TNg+5]},Text=K,Action=wO9T})end;wJ6tY_.FadeIn=(F82 ==true and 0.5)or 0;wJ6tY_.FadeOut=(
F82 ==true and 0.5)or 0
wJ6tY_.Duration=qne5Stra;wQl(wJ6tY_)end;return wQl,g end
function BundleBriefingSystem.Global:AddPages(QMcSUqdi)
local sKy2P9i=function(AkxLdb66)
if
AkxLdb66 and type(AkxLdb66)=="table"then local aUR=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
if
type(AkxLdb66.title)=="table"then AkxLdb66.title=AkxLdb66.title[aUR]end;AkxLdb66.title=AkxLdb66.title or""
if
type(AkxLdb66.text)=="table"then AkxLdb66.text=AkxLdb66.text[aUR]end;AkxLdb66.text=AkxLdb66.text or""
if AkxLdb66.mc then
if
AkxLdb66.mc.answers then AkxLdb66.mc.amount=#AkxLdb66.mc.answers;assert(
AkxLdb66.mc.amount>=1)AkxLdb66.mc.current=1
for c4=1,AkxLdb66.mc.amount
do
if AkxLdb66.mc.answers[c4]then if
type(AkxLdb66.mc.answers[c4][1])=="table"then
AkxLdb66.mc.answers[c4][1]=AkxLdb66.mc.answers[c4][1][aUR]end end end end;if type(AkxLdb66.mc.title)=="table"then
AkxLdb66.mc.title=AkxLdb66.mc.title[aUR]end;if type(AkxLdb66.mc.text)==
"table"then
AkxLdb66.mc.text=AkxLdb66.mc.text[aUR]end end
AkxLdb66.cutscene=AkxLdb66.cutscene or AkxLdb66.view
if AkxLdb66.cutscene then
AkxLdb66.flyTime=AkxLdb66.cutscene.FlyTime or 0
AkxLdb66.duration=AkxLdb66.cutscene.Duration or 0 else
if type(AkxLdb66.position)=="table"then
if
not AkxLdb66.position.X then AkxLdb66.zOffset=AkxLdb66.position[2]
AkxLdb66.position=AkxLdb66.position[1]elseif AkxLdb66.position.Z then AkxLdb66.zOffset=AkxLdb66.position.Z end end
if AkxLdb66.lookAt~=nil then local ZNXs3Bwd=AkxLdb66.lookAt
if
type(ZNXs3Bwd)=="table"then AkxLdb66.zOffset=ZNXs3Bwd[2]ZNXs3Bwd=ZNXs3Bwd[1]end
if
type(ZNXs3Bwd)=="string"or type(ZNXs3Bwd)=="number"then local Ginn=GetID(ZNXs3Bwd)
local h_pK=Logic.GetEntityOrientation(Ginn)
if Logic.IsBuilding(Ginn)==0 then h_pK=h_pK+90 end;local L=0.085*string.len(AkxLdb66.text)
AkxLdb66.position=Ginn;AkxLdb66.duration=AkxLdb66.duration or L
AkxLdb66.flyTime=AkxLdb66.flyTime
AkxLdb66.rotation=(AkxLdb66.rotation or 0)+h_pK end end end;table.insert(QMcSUqdi,AkxLdb66)else
table.insert(QMcSUqdi,(AkxLdb66 ~=nil and
AkxLdb66)or-1)end;return AkxLdb66 end
local S=function(vBKFXR3,FP3j,fe,ggnA,KaD2ExEO)local TpiFT=Logic.GetEntityName(GetID(vBKFXR3))assert(
TpiFT~=nil and TpiFT~="")local J={}J.zoom=
(ggnA==true and 2400)or 6250
J.angle=(ggnA==true and 40)or 47;J.lookAt={TpiFT,100}J.title=FP3j;J.text=fe or""J.action=KaD2ExEO;return
sKy2P9i(J)end
local AD=function(CH,sJ05I,HrLCim,w,...)local sUu7z=Logic.GetEntityName(GetID(CH))assert(sUu7z~=nil and
sUu7z~="")local M5oB={}M5oB.zoom=
(w==true and 2400)or 6250
M5oB.angle=(w==true and 40)or 47;M5oB.lookAt={sUu7z,100}M5oB.barStyle="big"
M5oB.mc={title=sJ05I,text=HrLCim,answers={}}local xIyIKo={...}
for f2x=1,#xIyIKo-1,2 do M5oB.mc.answers[#M5oB.mc.answers+1]={xIyIKo[f2x],xIyIKo[
f2x+1]}end;return sKy2P9i(M5oB)end;return sKy2P9i,S,AD end
function BundleBriefingSystem.Global:InitalizeBriefingSystem()
DBlau="{@color:70,70,255,255}"Blau="{@color:153,210,234,255}"Weiss="{@color:255,255,255,255}"
Rot="{@color:255,32,32,255}"Gelb="{@color:244,184,0,255}"Gruen="{@color:173,255,47,255}"
Orange="{@color:255,127,0,255}"Mint="{@color:0,255,255,255}"Grau="{@color:180,180,180,255}"
Trans="{@color:0,0,0,0}"
Quest_Loop=function(Nwl)local Xpt_SQ=JobQueue_GetParameter(Nwl)if
Xpt_SQ.LoopCallback~=nil then Xpt_SQ:LoopCallback()end
if Xpt_SQ.State==
QuestState.NotTriggered then local Y=true
for SMa=1,Xpt_SQ.Triggers[0]do Y=Y and
Xpt_SQ:IsTriggerActive(Xpt_SQ.Triggers[SMa])end;if Y then Xpt_SQ:SetMsgKeyOverride()
Xpt_SQ:SetIconOverride()Xpt_SQ:Trigger()end elseif Xpt_SQ.State==
QuestState.Active then local Bo=true;local zF6ZPjQ=false
for nNQG3=1,Xpt_SQ.Objectives[0]do
local yW=Xpt_SQ:IsObjectiveCompleted(Xpt_SQ.Objectives[nNQG3])
if IsBriefingActive()then if
BundleBriefingSystem.Global.Data.QuestsPausedWhileBriefingActive==true then
Xpt_SQ.StartTime=Xpt_SQ.StartTime+1 end end
if
Xpt_SQ.Objectives[nNQG3].Type==Objective.Deliver and yW==nil then if
Xpt_SQ.Objectives[nNQG3].Data[4]==nil then
Xpt_SQ.Objectives[nNQG3].Data[4]=0 end
if
Xpt_SQ.Objectives[nNQG3].Data[3]~=nil then Xpt_SQ.Objectives[nNQG3].Data[4]=
Xpt_SQ.Objectives[nNQG3].Data[4]+1 end;local efGM8UMy=Xpt_SQ.StartTime;local KhH=Xpt_SQ.Duration
local H4tXd=Xpt_SQ.Objectives[nNQG3].Data[4]local Nq6If=Xpt_SQ.StartTime+Xpt_SQ.Duration-
Xpt_SQ.Objectives[nNQG3].Data[4]
if
Xpt_SQ.Duration>0 and
Xpt_SQ.StartTime+Xpt_SQ.Duration+
Xpt_SQ.Objectives[nNQG3].Data[4]<Logic.GetTime()then yW=false end else
if Xpt_SQ.Duration>0 and
Xpt_SQ.StartTime+Xpt_SQ.Duration<Logic.GetTime()then
if
yW==nil and
(

Xpt_SQ.Objectives[nNQG3].Type==Objective.Protect or
Xpt_SQ.Objectives[nNQG3].Type==Objective.Dummy or
Xpt_SQ.Objectives[nNQG3].Type==Objective.NoChange)then yW=true elseif yW==nil or
Xpt_SQ.Objectives[nNQG3].Type==Objective.DummyFail then yW=false end end end;Bo=(yW==true)and Bo;zF6ZPjQ=yW==false or zF6ZPjQ end
if Bo then Xpt_SQ:Success()elseif zF6ZPjQ then Xpt_SQ:Fail()end else if Xpt_SQ.IsEventQuest==true then
Logic.ExecuteInLuaLocalState("StopEventMusic(nil, "..
Xpt_SQ.ReceivingPlayer..")")end
if Xpt_SQ.Result==
QuestResult.Success then for II=1,Xpt_SQ.Rewards[0]do
Xpt_SQ:AddReward(Xpt_SQ.Rewards[II])end elseif
Xpt_SQ.Result==QuestResult.Failure then for Y_tefq=1,Xpt_SQ.Reprisals[0]do
Xpt_SQ:AddReprisal(Xpt_SQ.Reprisals[Y_tefq])end end
if Xpt_SQ.EndCallback~=nil then Xpt_SQ:EndCallback()end;return true end;BundleBriefingSystem:OverwriteGetPosition()end
BriefingSystem={isActive=false,waitList={},isInitialized=false,maxMarkerListEntry=0,currBriefingIndex=0,loadScreenHidden=false}BriefingSystem.BRIEFING_CAMERA_ANGLEDEFAULT=43;BriefingSystem.BRIEFING_CAMERA_ROTATIONDEFAULT=
-45
BriefingSystem.BRIEFING_CAMERA_ZOOMDEFAULT=6250;BriefingSystem.BRIEFING_CAMERA_FOVDEFAULT=42
BriefingSystem.BRIEFING_DLGCAMERA_ANGLEDEFAULT=29;BriefingSystem.BRIEFING_DLGCAMERA_ROTATIONDEFAULT=-45
BriefingSystem.BRIEFING_DLGCAMERA_ZOOMDEFAULT=3400;BriefingSystem.BRIEFING_DLGCAMERA_FOVDEFAULT=25
BriefingSystem.STANDARDTIME_PER_PAGE=1;BriefingSystem.SECONDS_PER_CHAR=0.05
BriefingSystem.COLOR1="{@color:255,250,0,255}"BriefingSystem.COLOR2="{@color:255,255,255,255}"
BriefingSystem.COLOR3="{@color:250,255,0,255}"BriefingSystem.BRIEFING_FLYTIME=0
BriefingSystem.POINTER_HORIZONTAL=1;BriefingSystem.POINTER_VERTICAL=4
BriefingSystem.POINTER_VERTICAL_LOW=5;BriefingSystem.POINTER_VERTICAL_HIGH=6
BriefingSystem.ANIMATED_MARKER=1;BriefingSystem.STATIC_MARKER=2
BriefingSystem.POINTER_PERMANENT_MARKER=6;BriefingSystem.ENTITY_PERMANENT_MARKER=8
BriefingSystem.SIGNAL_MARKER=0;BriefingSystem.ATTACK_MARKER=3;BriefingSystem.CRASH_MARKER=4
BriefingSystem.POINTER_MARKER=5;BriefingSystem.ENTITY_MARKER=7
BriefingSystem.BRIEFING_EXPLORATION_RANGE=6000;BriefingSystem.SKIPMODE_ALL=1;BriefingSystem.SKIPMODE_PERPAGE=2
BriefingSystem.DEFAULT_EXPLORE_ENTITY="XD_Camera"
function API.StartCutscene(i)i.skipPerPage=false
for a3u=1,#i,1 do if i[a3u].mc then
API.Fatal("API.StartCutscene: Unallowed multiple choice at page "..
a3u.." found!")return end;if i[a3u].marker then
API.Fatal(
"API.StartCutscene: Unallowed marker at page "..a3u.." found!")return end;if i[a3u].pointer then
API.Fatal(
"API.StartCutscene: Unallowed pointer at page "..a3u.." found!")return end;if i[a3u].explore then
API.Fatal(
"API.StartCutscene: Unallowed explore at page "..a3u.." found!")return end end;return BriefingSystem.StartBriefing(i,true)end;BriefingSystem.StartCutscene=API.StartCutscene
StartCutscene=API.StartCutscene
function API.StartBriefing(mzhB,sTxVGmb)sTxVGmb=sTxVGmb or false
Logic.ExecuteInLuaLocalState(
[[
            BriefingSystem.Flight.systemEnabled = ]]..tostring(not sTxVGmb)..[[
        ]])BundleBriefingSystem.Global.Data.BriefingID=
BundleBriefingSystem.Global.Data.BriefingID+1
mzhB.UniqueBriefingID=BundleBriefingSystem.Global.Data.BriefingID;if#mzhB>0 then
mzhB[1].duration=(mzhB[1].duration or 0)+0.1 end;if mzhB.hideBorderPins then
Logic.ExecuteInLuaLocalState([[Display.SetRenderBorderPins(0)]])end;if mzhB.showSky then
Logic.ExecuteInLuaLocalState([[Display.SetRenderSky(1)]])end
Logic.ExecuteInLuaLocalState([[
            Display.SetUserOptionOcclusionEffect(0)
        ]])mzhB.finished_Orig_QSB_Briefing=mzhB.finished
mzhB.finished=function(GSIcq)if mzhB.hideBorderPins then
Logic.ExecuteInLuaLocalState([[Display.SetRenderBorderPins(1)]])end;if mzhB.showSky then
Logic.ExecuteInLuaLocalState([[Display.SetRenderSky(0)]])end
Logic.ExecuteInLuaLocalState([[
                if Options.GetIntValue("Display", "Occlusion", 0) > 0 then
                    Display.SetUserOptionOcclusionEffect(1)
                end
            ]])mzhB.finished_Orig_QSB_Briefing(GSIcq)
BundleBriefingSystem.Global.Data.PlayedBriefings[mzhB.UniqueBriefingID]=true end
if BriefingSystem.isActive then
table.insert(BriefingSystem.waitList,mzhB)if not BriefingSystem.waitList.Job then
BriefingSystem.waitList.Job=StartSimpleJob("BriefingSystem_WaitForBriefingEnd")end else
BriefingSystem.ExecuteBriefing(mzhB)end
return BundleBriefingSystem.Global.Data.BriefingID end;BriefingSystem.StartBriefing=API.StartBriefing
StartBriefing=API.StartBriefing
function BriefingSystem.EndBriefing()BriefingSystem.isActive=false
Logic.SetGlobalInvulnerability(0)local Go=BriefingSystem.currBriefing
BriefingSystem.currBriefing=nil
BriefingSystem[BriefingSystem.currBriefingIndex]=nil
Logic.ExecuteInLuaLocalState("BriefingSystem.EndBriefing()")EndJob(BriefingSystem.job)
if Go.finished then Go:finished()end end
function BriefingSystem_WaitForBriefingEnd()
if
not BriefingSystem.isActive and BriefingSystem.loadScreenHidden then
BriefingSystem.ExecuteBriefing(table.remove(BriefingSystem.waitList),1)if#BriefingSystem.waitList==0 then BriefingSystem.waitList.Job=
nil;return true end end end
function BriefingSystem.ExecuteBriefing(DGf)
if not BriefingSystem.isInitialized then
Logic.ExecuteInLuaLocalState("BriefingSystem.InitializeBriefingSystem()")BriefingSystem.isInitialized=true end;BriefingSystem.isActive=true;BriefingSystem.currBriefing=DGf;BriefingSystem.currBriefingIndex=
BriefingSystem.currBriefingIndex+1
BriefingSystem[BriefingSystem.currBriefingIndex]=DGf;BriefingSystem.timer=0;BriefingSystem.page=0
BriefingSystem.skipPlayers={}
BriefingSystem.disableSkipping=BriefingSystem.currBriefing.disableSkipping
BriefingSystem.activate3dOnScreenDisplay=BriefingSystem.currBriefing.activate3dOnScreenDisplay
BriefingSystem.skipAll=BriefingSystem.currBriefing.skipAll
BriefingSystem.skipPerPage=not BriefingSystem.skipAll and
BriefingSystem.currBriefing.skipPerPage;if not DGf.disableGlobalInvulnerability then
Logic.SetGlobalInvulnerability(1)end
Logic.ExecuteInLuaLocalState("BriefingSystem.PrepareBriefing()")
BriefingSystem.currBriefing=BriefingSystem.UpdateMCAnswers(BriefingSystem.currBriefing)
BriefingSystem.job=Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,"BriefingSystem_Condition_Briefing","BriefingSystem_Action_Briefing",1)
if not BriefingSystem.loadScreenHidden then
Logic.ExecuteInLuaLocalState("BriefingSystem.Briefing(true)")elseif BriefingSystem_Action_Briefing()then
EndJob(BriefingSystem.job)end end
function BriefingSystem.UpdateMCAnswers(kgRX7X)
if kgRX7X then local JB=1
while
(kgRX7X[JB]~=nil and#kgRX7X>=JB)do
if type(kgRX7X[JB])=="table"and kgRX7X[JB].mc and
kgRX7X[JB].mc.answers then local GGJhclKa=1;local KWahIz=1
while(
kgRX7X[JB].mc.answers[KWahIz]~=nil)do if not
kgRX7X[JB].mc.answers[KWahIz].ID then
kgRX7X[JB].mc.answers[KWahIz].ID=GGJhclKa end
if
kgRX7X[JB].mc.answers[KWahIz].remove then
table.remove(BriefingSystem.currBriefing[JB].mc.answers,KWahIz)if
#BriefingSystem.currBriefing[JB].mc.answers<KWahIz then
BriefingSystem.currBriefing[JB].mc.current=
#BriefingSystem.currBriefing[JB].mc.answers end
Logic.ExecuteInLuaLocalState(
[[
                                table.remove(BriefingSystem.currBriefing[]]..
JB..
[[].mc.answers, ]]..
KWahIz..
[[)
                                if #BriefingSystem.currBriefing[]]..
JB..
[[].mc.answers < ]]..
KWahIz..

[[ then
                                    BriefingSystem.currBriefing[]]..
JB..[[].mc.current = #BriefingSystem.currBriefing[]]..
JB..[[].mc.answers
                                end
                            ]])end;GGJhclKa=GGJhclKa+1;KWahIz=KWahIz+1 end;if#kgRX7X[JB].mc.answers==0 then
local X2kyW=Network.GetDesiredLanguage()
kgRX7X[JB].mc.answers[1]={(X2kyW=="de"and"ENDE")or"END",999999}end end;JB=JB+1 end end;return kgRX7X end
function BriefingSystem.IsBriefingActive()return BriefingSystem.isActive end;IsBriefingActive=BriefingSystem.IsBriefingActive
function BriefingSystem_Condition_Briefing()if not
BriefingSystem.loadScreenHidden then return false end;BriefingSystem.timer=
BriefingSystem.timer-0.1
return BriefingSystem.timer<=0 end
function BriefingSystem_Action_Briefing()
BriefingSystem.page=BriefingSystem.page+1;local pVlvW;if BriefingSystem.currBriefing then
pVlvW=BriefingSystem.currBriefing[BriefingSystem.page]end
if
not BriefingSystem.skipAll and not BriefingSystem.disableSkipping then
for QcKn_=1,8 do
if
BriefingSystem.skipPlayers[QcKn_]~=BriefingSystem.SKIPMODE_ALL then BriefingSystem.skipPlayers[QcKn_]=
nil
if
type(pVlvW)=="table"and pVlvW.skipping==false then
Logic.ExecuteInLuaLocalState("BriefingSystem.EnableBriefingSkipButton("..QcKn_..", false)")else
Logic.ExecuteInLuaLocalState("BriefingSystem.EnableBriefingSkipButton("..QcKn_..", true)")end end end end
if not pVlvW or pVlvW==-1 then BriefingSystem.EndBriefing()return
true elseif type(pVlvW)=="number"and pVlvW>0 then
BriefingSystem.timer=0;BriefingSystem.page=pVlvW-1;return end
if pVlvW.mc then
Logic.ExecuteInLuaLocalState('XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip", 0)')
BriefingSystem.currBriefing[BriefingSystem.page].duration=99999999 else
local jiM=BriefingSystem.currBriefing[BriefingSystem.page+1]if not BriefingSystem.disableSkipping then
Logic.ExecuteInLuaLocalState('XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip", 1)')end end
BriefingSystem.timer=pVlvW.duration or BriefingSystem.STANDARDTIME_PER_PAGE
if pVlvW.explore then pVlvW.exploreEntities={}
if type(pVlvW.explore)=="table"then
if#
pVlvW.explore>0 or pVlvW.explore.default then
for YUdA=1,8 do local lx3cpJ=
pVlvW.explore[player]or pVlvW.explore.default
if lx3cpJ then
if
type(lx3cpJ)=="table"then
BriefingSystem.CreateExploreEntity(pVlvW,lx3cpJ.exploration,lx3cpJ.type or
Entities[BriefingSystem.DEFAULT_EXPLORE_ENTITY],YUdA,lx3cpJ.position)else
BriefingSystem.CreateExploreEntity(pVlvW,lx3cpJ,Entities[BriefingSystem.DEFAULT_EXPLORE_ENTITY],YUdA)end end end else
BriefingSystem.CreateExploreEntity(pVlvW,pVlvW.explore.exploration,pVlvW.explore.type or
Entities[BriefingSystem.DEFAULT_EXPLORE_ENTITY],1,pVlvW.explore.position)end else
BriefingSystem.CreateExploreEntity(pVlvW,pVlvW.explore,Entities[BriefingSystem.DEFAULT_EXPLORE_ENTITY],1)end end
if pVlvW.pointer then local Yx9=pVlvW.pointer;pVlvW.pointerList={}
if type(Yx9)=="table"then if
#Yx9 >0 then for Mn=1,#Yx9 do
BriefingSystem.CreatePointer(pVlvW,Yx9[Mn])end else
BriefingSystem.CreatePointer(pVlvW,Yx9)end else
BriefingSystem.CreatePointer(pVlvW,{type=Yx9,position=
pVlvW.position or pVlvW.followEntity})end end
if pVlvW.marker then
BriefingSystem.maxMarkerListEntry=BriefingSystem.maxMarkerListEntry+1;pVlvW.markerList=BriefingSystem.maxMarkerListEntry end
Logic.ExecuteInLuaLocalState("BriefingSystem.Briefing()")if pVlvW.action then pVlvW:action()end end
function BriefingSystem.SkipBriefing(ut0)
if not BriefingSystem.disableSkipping then
if
BriefingSystem.skipPerPage then BriefingSystem.SkipBriefingPage(ut0)return end
BriefingSystem.skipPlayers[ut0]=BriefingSystem.SKIPMODE_ALL
for ZFhlP6eg=1,8,1 do
if
Logic.PlayerGetIsHumanFlag(ZFhlP6eg)and
BriefingSystem.skipPlayers[ZFhlP6eg]~=BriefingSystem.SKIPMODE_ALL then
Logic.ExecuteInLuaLocalState("BriefingSystem.EnableBriefingSkipButton("..ut0 ..", false)")return end end;EndJob(BriefingSystem.job)
BriefingSystem.EndBriefing()end end
function BriefingSystem.SkipBriefingPage(ExUgDG)
if not BriefingSystem.disableSkipping then
if not
BriefingSystem.LastSkipTimeStemp or Logic.GetTimeMs()>
BriefingSystem.LastSkipTimeStemp+500 then
BriefingSystem.LastSkipTimeStemp=Logic.GetTimeMs()if not BriefingSystem.skipPlayers[ExUgDG]then
BriefingSystem.skipPlayers[ExUgDG]=BriefingSystem.SKIPMODE_PERPAGE end
for jc4o42jz=1,8,1 do
if

Logic.PlayerGetIsHumanFlag(ExUgDG)and not BriefingSystem.skipPlayers[ExUgDG]then if BriefingSystem.skipPerPage then
Logic.ExecuteInLuaLocalState("BriefingSystem.EnableBriefingSkipButton("..ExUgDG..", false)")end;return end end;if BriefingSystem.skipAll then
BriefingSystem.SkipBriefing(ExUgDG)elseif BriefingSystem_Action_Briefing()then
EndJob(BriefingSystem.job)end end end end
function BriefingSystem.CreateExploreEntity(jc,Ojz_,x,Xtecl,KVcYU)local _=KVcYU or jc.position
if _ then
if
type(_)=="table"and(
_[Xtecl]or _.default or _.playerPositions)then _=_[Xtecl]or _.default end;if _ then local CJeG=type(_)if CJeG=="string"or CJeG=="number"then
_=GetPosition(_)end end end
if not _ then local F43eMG=jc.followEntity;if type(F43eMG)=="table"then F43eMG=F43eMG[Xtecl]or
F43eMG.default end;if F43eMG then
_=GetPosition(F43eMG)end end;assert(_)local C=Logic.CreateEntity(x,_.X,_.Y,0,Xtecl)assert(
C~=0)
Logic.SetEntityExplorationRange(C,Ojz_/100)table.insert(jc.exploreEntities,C)end
function BriefingSystem.CreatePointer(mCzjh4,lU)
local epQue9=lU.type or BriefingSystem.POINTER_VERTICAL;local cHUJrj=lU.position;assert(cHUJrj)
if
epQue9/BriefingSystem.POINTER_VERTICAL>=1 then local EI0x=cHUJrj
if type(cHUJrj)=="table"then local lacOdjf9
lacOdjf9,EI0x=Logic.GetEntitiesInArea(0,cHUJrj.X,cHUJrj.Y,50,1)else cHUJrj=GetPosition(cHUJrj)end;local E=EGL_Effects.E_Questmarker_low
if
epQue9 ==BriefingSystem.POINTER_VERTICAL_HIGH then E=EGL_Effects.E_Questmarker elseif
epQue9 ~=BriefingSystem.POINTER_VERTICAL_LOW then
if EI0x~=0 then if Logic.IsBuilding(EI0x)==1 then
epQue9=EGL_Effects.E_Questmarker end end end
table.insert(mCzjh4.pointerList,{id=Logic.CreateEffect(E,cHUJrj.X,cHUJrj.Y,lU.player or 0),type=epQue9})else
assert(epQue9 ==BriefingSystem.POINTER_HORIZONTAL)
if type(cHUJrj)~="table"then cHUJrj=GetPosition(cHUJrj)end
table.insert(mCzjh4.pointerList,{id=Logic.CreateEntityOnUnblockedLand(Entities.E_DirectionMarker,cHUJrj.X,cHUJrj.Y,
lU.orientation or 0,lU.player or 0),type=epQue9})end end
function BriefingSystem.DestroyPageMarker(R2h4lP4l,Fh)if R2h4lP4l.marker then
Logic.ExecuteInLuaLocalState("BriefingSystem.DestroyPageMarker("..
R2h4lP4l.markerList..", "..Fh..")")end end
function BriefingSystem.RedeployPageMarkers(a2e9fa,Rc9_ZID)
if a2e9fa.marker then if type(Rc9_ZID)~="table"then
Rc9_ZID=GetPosition(Rc9_ZID)end
Logic.ExecuteInLuaLocalState("BriefingSystem.RedeployMarkerList("..

a2e9fa.markerList..", "..Rc9_ZID.X..", "..Rc9_ZID.Y..")")end end
function BriefingSystem.RedeployPageMarker(H1HF2wD6,hBph,bxNo9h)
if H1HF2wD6.marker then if type(bxNo9h)~="table"then
bxNo9h=GetPosition(bxNo9h)end
Logic.ExecuteInLuaLocalState("BriefingSystem.RedeployMarkerOfList("..
H1HF2wD6.markerList..", "..
hBph..", "..bxNo9h.X..", "..bxNo9h.Y..")")end end
function BriefingSystem.RefreshPageMarkers(Khst)if Khst.marker then
Logic.ExecuteInLuaLocalState("BriefingSystem.RefreshMarkerList("..Khst.markerList..
")")end end
function BriefingSystem.RefreshPageMarker(pUT,ISg1)if pUT.marker then
Logic.ExecuteInLuaLocalState("BriefingSystem.RefreshMarkerOfList("..pUT.markerList..", "..
ISg1 ..")")end end
function BriefingSystem.ResolveBriefingPage(Gh5UJya)
if Gh5UJya.explore and Gh5UJya.exploreEntities then
for k,Z8Ue in
ipairs(Gh5UJya.exploreEntities)do Logic.DestroyEntity(Z8Ue)end;Gh5UJya.exploreEntities=nil end
if Gh5UJya.pointer and Gh5UJya.pointerList then
for TXbmx,r in ipairs(Gh5UJya.pointerList)do
if
r.type~=BriefingSystem.POINTER_HORIZONTAL then
Logic.DestroyEffect(r.id)else Logic.DestroyEntity(r.id)end end;Gh5UJya.pointerList=nil end
if Gh5UJya.marker and Gh5UJya.markerList then
Logic.ExecuteInLuaLocalState(
"BriefingSystem.DestroyMarkerList("..Gh5UJya.markerList..")")Gh5UJya.markerList=nil end end;ResolveBriefingPage=BriefingSystem.ResolveBriefingPage
function BriefingSystem.OnConfirmed(Pqgz415t,McNxKV,WcwGYJh)
BriefingSystem.timer=0
local gJt=BriefingSystem.currBriefing[BriefingSystem.page]local hCs8M=BriefingSystem.page;local GkjCn_mq=McNxKV
local T9sySp=gJt.mc.answers[GkjCn_mq][2]
BriefingSystem.currBriefing[hCs8M].mc.given=Pqgz415t;if type(T9sySp)=="function"then BriefingSystem.page=
T9sySp(gJt.mc.answers[WcwGYJh])-1 else
BriefingSystem.page=T9sySp-1 end
BriefingSystem.currBriefing=BriefingSystem.UpdateMCAnswers(BriefingSystem.currBriefing)end
function BriefingSystem.LeftClickOnEntity(DL0mMXM)if DL0mMXM==nil then return end;if BriefingSystem.IsBriefingActive==
false then return end
local o4Kvi75g=BriefingSystem.currBriefing[BriefingSystem.page]
if o4Kvi75g.entityClicked then o4Kvi75g:entityClicked(DL0mMXM)end end
function BriefingSystem.LeftClickOnPosition(ELb,FV5)if ELb==nil or FV5 ==nil then return end;if
BriefingSystem.IsBriefingActive==false then return end
local sX=BriefingSystem.currBriefing[BriefingSystem.page]
if sX.positionClicked then sX:positionClicked(ELb,FV5)end end
function BriefingSystem.LeftClickOnScreen(DH6mUlGB,A4ZRczp)
if DH6mUlGB==nil or A4ZRczp==nil then return end
if BriefingSystem.IsBriefingActive==false then return end
local rUT=BriefingSystem.currBriefing[BriefingSystem.page]
if rUT.screenClicked then rUT:screenClicked(DH6mUlGB,A4ZRczp)end end end;function BundleBriefingSystem.Local:Install()
self:InitalizeBriefingSystem()end
function BundleBriefingSystem.Local:InitalizeBriefingSystem()
GameCallback_GUI_SelectionChanged_Orig_QSB_Briefing=GameCallback_GUI_SelectionChanged
GameCallback_GUI_SelectionChanged=function(g)
GameCallback_GUI_SelectionChanged_Orig_QSB_Briefing(g)if IsBriefingActive()then GUI.ClearSelection()end end;DBlau="{@color:70,70,255,255}"Blau="{@color:153,210,234,255}"
Weiss="{@color:255,255,255,255}"Rot="{@color:255,32,32,255}"Gelb="{@color:244,184,0,255}"
Gruen="{@color:173,255,47,255}"Orange="{@color:255,127,0,255}"Mint="{@color:0,255,255,255}"
Grau="{@color:180,180,180,255}"Trans="{@color:0,0,0,0}"if not InitializeFader then
Script.Load("Script\\MainMenu\\Fader.lua")end
BriefingSystem={listOfMarkers={},markerUniqueID=2^10,Flight={systemEnabled=true}}
function BriefingSystem.InitializeBriefingSystem()
BriefingSystem.GlobalSystem=Logic.CreateReferenceToTableInGlobaLuaState("BriefingSystem")assert(BriefingSystem.GlobalSystem)if not
BriefingSystem.GlobalSystem.loadScreenHidden then
BriefingSystem.StartLoadScreenSupervising()end
BriefingSystem.GameCallback_Escape=GameCallback_Escape
GameCallback_Escape=function()if not BriefingSystem.IsBriefingActive()then
BriefingSystem.GameCallback_Escape()end end
BriefingSystem.Flight.Job=Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,nil,"ThroneRoomCameraControl",0)end
function BriefingSystem.StartLoadScreenSupervising()
if
not BriefingSystem_LoadScreenSupervising()then
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,nil,"BriefingSystem_LoadScreenSupervising",1)end end
function BriefingSystem_LoadScreenSupervising()
if
XGUIEng.IsWidgetShownEx("/LoadScreen/LoadScreen")==0 then
GUI.SendScriptCommand("BriefingSystem.loadScreenHidden = true;")return true end end
function BriefingSystem.PrepareBriefing()BriefingSystem.barType=nil
BriefingSystem.currBriefing=BriefingSystem.GlobalSystem[BriefingSystem.GlobalSystem.currBriefingIndex]
Trigger.EnableTrigger(BriefingSystem.Flight.Job)
local JPi=XGUIEng.IsWidgetShownEx("/LoadScreen/LoadScreen")==1;if JPi then XGUIEng.PopPage()end;if
BriefingSystem.GlobalSystem.activate3dOnScreenDisplay~=true then
XGUIEng.ShowWidget("/InGame/Root/3dOnScreenDisplay",0)end
XGUIEng.ShowWidget("/InGame/Root/Normal",0)XGUIEng.ShowWidget("/InGame/ThroneRoom",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip",
BriefingSystem.GlobalSystem.disableSkipping and 0 or 1)
BriefingSystem.EnableBriefingSkipButton(nil,true)XGUIEng.PushPage("/InGame/ThroneRoomBars",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_2",false)
XGUIEng.PushPage("/InGame/ThroneRoom/Main",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_Dodge",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_2_Dodge",false)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/Frame",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/DialogBG",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/FrameEdges",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogBottomRight3pcs",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/KnightInfoButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Briefing",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/BackButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/TitleContainer",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/StartButton",0)
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Text"," ")
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Title"," ")
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Objectives"," ")
XGUIEng.PushPage("/InGame/ThroneRoom/KnightInfo",false)
XGUIEng.ShowAllSubWidgets("/InGame/ThroneRoom/KnightInfo",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/LeftFrame",1)
XGUIEng.ShowAllSubWidgets("/InGame/ThroneRoom/KnightInfo/LeftFrame",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/KnightBG",1)
XGUIEng.SetWidgetPositionAndSize("/InGame/ThroneRoom/KnightInfo/KnightBG",0,4000,400,600)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/KnightBG",0,0)local Kkl6fa=BriefingSystem.currBriefing[1]
BriefingSystem.SetBriefingPagePortrait(Kkl6fa)
BriefingSystem.SetBriefingPageOrSplashscreen(Kkl6fa)
BriefingSystem.SetBriefingPageTextPosition(Kkl6fa)
if not Framework.IsNetworkGame()and
Game.GameTimeGetFactor()~=0 then
if BriefingSystem.currBriefing.restoreGameSpeed and not
BriefingSystem.currBriefing.gameSpeedBackup then
BriefingSystem.currBriefing.gameSpeedBackup=Game.GameTimeGetFactor()end;Game.GameTimeSetFactor(GUI.GetPlayerID(),1)end;if BriefingSystem.currBriefing.restoreCamera then
BriefingSystem.cameraRestore={Camera.RTS_GetLookAtPosition()}end
BriefingSystem.selectedEntities={GUI.GetSelectedEntities()}GUI.ClearSelection()
GUI.ForbidContextSensitiveCommandsInSelectionState()GUI.ActivateCutSceneState()
GUI.SetFeedbackSoundOutputState(0)GUI.EnableBattleSignals(false)Mouse.CursorHide()
Camera.SwitchCameraBehaviour(5)Input.CutsceneMode()InitializeFader()g_Fade.To=0
SetFaderAlpha(0)if JPi then
XGUIEng.PushPage("/LoadScreen/LoadScreen",false)end
if BriefingSystem.currBriefing.hideFoW then
Display.SetRenderFogOfWar(0)GUI.MiniMap_SetRenderFogOfWar(0)end end
function BriefingSystem.EndBriefing()
if BriefingSystem.faderJob then
Trigger.UnrequestTrigger(BriefingSystem.faderJob)BriefingSystem.faderJob=nil end
if BriefingSystem.currBriefing.hideFoW then
Display.SetRenderFogOfWar(1)GUI.MiniMap_SetRenderFogOfWar(1)end;g_Fade.To=0;SetFaderAlpha(0)XGUIEng.PopPage()
Display.UseStandardSettings()Input.GameMode()
local t,H=Camera.ThroneRoom_GetPosition()Camera.SwitchCameraBehaviour(0)
Camera.RTS_SetLookAtPosition(t,H)Mouse.CursorShow()GUI.EnableBattleSignals(true)
GUI.SetFeedbackSoundOutputState(1)GUI.ActivateSelectionState()
GUI.PermitContextSensitiveCommandsInSelectionState()for glZrOuSo,Zdzaj in ipairs(BriefingSystem.selectedEntities)do
if not
Logic.IsEntityDestroyed(Zdzaj)then GUI.SelectEntity(Zdzaj)end end;if
BriefingSystem.currBriefing.restoreCamera then
Camera.RTS_SetLookAtPosition(unpack(BriefingSystem.cameraRestore))end
if not
Framework.IsNetworkGame()then
local UxRGyO9e=(BriefingSystem.currBriefing.gameSpeedBackup or 1)
Game.GameTimeSetFactor(GUI.GetPlayerID(),UxRGyO9e)end;XGUIEng.PopPage()XGUIEng.PopPage()
XGUIEng.PopPage()XGUIEng.PopPage()XGUIEng.PopPage()
XGUIEng.PopPage()XGUIEng.ShowWidget("/InGame/ThroneRoom",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars",0)XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",0)XGUIEng.ShowWidget("/InGame/Root/Normal",1)
XGUIEng.ShowWidget("/InGame/Root/3dOnScreenDisplay",1)
Trigger.DisableTrigger(BriefingSystem.Flight.Job)end
function BriefingSystem.Briefing(fvj_L)if not fvj_L then
if BriefingSystem.faderJob then
Trigger.UnrequestTrigger(BriefingSystem.faderJob)BriefingSystem.faderJob=nil end end
local _CPU89l=BriefingSystem.currBriefing[
fvj_L and 1 or BriefingSystem.GlobalSystem.page]if not _CPU89l then return end;local U=_CPU89l.barStyle;if U==nil then
U=BriefingSystem.currBriefing.barStyle end
BriefingSystem.SetBriefingPagePortrait(_CPU89l)
BriefingSystem.SetBriefingPageOrSplashscreen(_CPU89l,U)
BriefingSystem.SetBriefingPageTextPosition(_CPU89l)local Kwxn=GUI.GetPlayerID()
if _CPU89l.text then
local x=_CPU89l.duration~=nil
local m=((U=="small"or U=="transsmall")and
not _CPU89l.splashscreen)
if type(_CPU89l.text)=="string"then
BriefingSystem.ShowBriefingText(_CPU89l.text,x,m)elseif _CPU89l.text[Kwxn]or _CPU89l.text.default then for VVQ=1,Kwxn do
if
_CPU89l.text[VVQ]and Logic.GetIsHumanFlag(VVQ)then x=true end end
BriefingSystem.ShowBriefingText(
_CPU89l.text[Kwxn]or _CPU89l.text.default,x,m)end end
if _CPU89l.title then
if type(_CPU89l.title)=="string"then
BriefingSystem.ShowBriefingTitle(_CPU89l.title)elseif _CPU89l.title[Kwxn]or _CPU89l.title.default then
BriefingSystem.ShowBriefingTitle(
_CPU89l.title[Kwxn]or _CPU89l.title.default)end end
if _CPU89l.mc then BriefingSystem.Briefing_MultipleChoice()end;local yp5DGSwX,Sb1Mw7R
if type(_CPU89l.splashscreen)=="table"then
if
_CPU89l.splashscreen.uv then
yp5DGSwX={_CPU89l.splashscreen.uv[1],_CPU89l.splashscreen.uv[2]}
Sb1Mw7R={_CPU89l.splashscreen.uv[3],_CPU89l.splashscreen.uv[4]}end end
if not fvj_L then
if _CPU89l.faderAlpha then
if type(_CPU89l.faderAlpha)=="table"then
g_Fade.To=
_CPU89l.faderAlpha[Kwxn]or _CPU89l.faderAlpha.default or 0 else g_Fade.To=_CPU89l.faderAlpha end;g_Fade.Duration=0 end
if _CPU89l.fadeIn then local Jb=_CPU89l.fadeIn;if type(Jb)=="table"then
Jb=Jb[Kwxn]or Jb.default end;if type(Jb)~="number"then Jb=_CPU89l.duration;if not Jb then
Jb=BriefingSystem.timer end end
if Jb<0 then
BriefingSystem.faderJob=Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,
nil,"BriefingSystem_CheckFader",1,{},{1,math.abs(fadeOut)})else FadeIn(Jb)end end
if _CPU89l.fadeOut then local q=_CPU89l.fadeOut;if type(q)=="table"then
q=q[Kwxn]or q.default end;if type(q)~="number"then q=_CPU89l.duration;if not q then
q=BriefingSystem.timer end end
if q<0 then
BriefingSystem.faderJob=Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,
nil,"BriefingSystem_CheckFader",1,{},{0,math.abs(q)})else FadeOut(q)end end else
local cpea=
(_CPU89l.fadeOut and 0)or(_CPU89l.fadeIn and 1)or _CPU89l.faderValue;if cpea then g_Fade.To=cpea;g_Fade.Duration=0 end end;local fuF=_CPU89l.dialogCamera;if type(fuF)=="table"then fuF=fuF[Kwxn]if fuF==nil then
fuF=_CPU89l.dialogCamera.default end end;fuF=
fuF and"DLG"or""
local pA2=_CPU89l.rotation or BriefingSystem.GlobalSystem["BRIEFING_"..fuF..
"CAMERA_ROTATIONDEFAULT"]
if type(pA2)=="table"then pA2=pA2[Kwxn]or pA2.default end
local M5lAedm=_CPU89l.angle or
BriefingSystem.GlobalSystem["BRIEFING_"..fuF.."CAMERA_ANGLEDEFAULT"]if type(M5lAedm)=="table"then
M5lAedm=M5lAedm[Kwxn]or M5lAedm.default end
local _uYRl2kj=_CPU89l.zoom or BriefingSystem.GlobalSystem["BRIEFING_"..fuF..
"CAMERA_ZOOMDEFAULT"]if type(_uYRl2kj)=="table"then
_uYRl2kj=_uYRl2kj[Kwxn]or _uYRl2kj.default end
local tbN=_CPU89l.FOV or BriefingSystem.GlobalSystem["BRIEFING_"..fuF..
"CAMERA_FOVDEFAULT"]BriefingSystem.CutsceneStopFlight()
BriefingSystem.StopFlight()
if _CPU89l.cutscene then if BriefingSystem.GlobalSystem.page==1 then
BriefingSystem.CutsceneSaveFlight(_CPU89l.cutscene.Position,_CPU89l.cutscene.LookAt,tbN)end
BriefingSystem.CutsceneFlyTo(_CPU89l.cutscene.Position,_CPU89l.cutscene.LookAt,tbN,
_CPU89l.flyTime or 0)elseif _CPU89l.position then local tjDBv=_CPU89l.position;if type(tjDBv)=="table"and
(tjDBv[Kwxn]or
tjDBv.default or tjDBv.playerPositions)then
tjDBv=tjDBv[Kwxn]or tjDBv.default end
if tjDBv then
local vmn7v=type(tjDBv)
if vmn7v=="string"or vmn7v=="number"then
tjDBv=GetPosition(tjDBv)elseif vmn7v=="table"then tjDBv={X=tjDBv.X,Y=tjDBv.Y,Z=tjDBv.Z}end
local Au1mzs=tjDBv.Z or Display.GetTerrainHeight(tjDBv.X,tjDBv.Y)
if _CPU89l.zOffset then Au1mzs=Au1mzs+_CPU89l.zOffset end;tjDBv.Z=Au1mzs;Display.SetCameraLookAtEntity(0)if
BriefingSystem.GlobalSystem.page==1 then
BriefingSystem.SaveFlight(tjDBv,pA2,M5lAedm,_uYRl2kj,tbN,yp5DGSwX,Sb1Mw7R)end
BriefingSystem.FlyTo(tjDBv,pA2,M5lAedm,_uYRl2kj,tbN,
_CPU89l.flyTime or BriefingSystem.GlobalSystem.BRIEFING_FLYTIME,yp5DGSwX,Sb1Mw7R)end elseif _CPU89l.followEntity then local u39i=_CPU89l.followEntity;if type(u39i)=="table"then u39i=
u39i[Kwxn]or u39i.default end
u39i=GetEntityId(u39i)Display.SetCameraLookAtEntity(u39i)
local Fdg7p=GetPosition(u39i)Fdg7p.Z=Fdg7p.Z or nil
local GD3AP=Display.GetTerrainHeight(Fdg7p.X,Fdg7p.Y)
if _CPU89l.zOffset then GD3AP=GD3AP+_CPU89l.zOffset end;Fdg7p.Z=GD3AP;if BriefingSystem.GlobalSystem.page==1 then
BriefingSystem.SaveFlight(Fdg7p,pA2,M5lAedm,_uYRl2kj,tbN,yp5DGSwX,Sb1Mw7R)end
BriefingSystem.FollowFlight(u39i,pA2,M5lAedm,_uYRl2kj,tbN,
_CPU89l.flyTime or 0,GD3AP,yp5DGSwX,Sb1Mw7R)end
if not fvj_L then
if _CPU89l.marker then local jph00k=_CPU89l.marker
if type(jph00k)=="table"then
if
#jph00k>0 then
for wE_4o,F in ipairs(jph00k)do
if
not F.player or F.player==GUI.GetPlayerID()then
BriefingSystem.CreateMarker(F,F.type,_CPU89l.markerList,F.display,F.R,F.G,F.B,F.Alpha)else
table.insert(BriefingSystem.listOfMarkers[_CPU89l.markerList],{})end end else
if not v.player or v.player==GUI.GetPlayerID()then
BriefingSystem.CreateMarker(jph00k,jph00k.type,_CPU89l.markerList,jph00k.display,jph00k.R,jph00k.G,jph00k.B,jph00k.Alpha)else
table.insert(BriefingSystem.listOfMarkers[_CPU89l.markerList],{})end end else
BriefingSystem.CreateMarker(_CPU89l,jph00k,_CPU89l.markerList)end end end end
function OnSkipButtonPressed()local bUO1NvT=BriefingSystem.GlobalSystem.page
if
BriefingSystem.currBriefing[bUO1NvT]and
not BriefingSystem.currBriefing[bUO1NvT].mc then
GUI.SendScriptCommand("BriefingSystem.SkipBriefing("..
GUI.GetPlayerID()..")")end end
function BriefingSystem.SkipBriefingPage()
local K=BriefingSystem.GlobalSystem.page
if BriefingSystem.currBriefing[K]and not
BriefingSystem.currBriefing[K].mc then
GUI.SendScriptCommand(
"BriefingSystem.SkipBriefingPage("..GUI.GetPlayerID()..")")end end
function BriefingSystem.ShowBriefingBar(RQG)RQG=RQG or"big"if RQG==nil then
RQG=BriefingSystem.currBriefing.barStyle end
assert(RQG=='big'or RQG=='small'or
RQG=='nobar'or RQG=='transbig'or
RQG=='transsmall')
local tVwI_N=(RQG=="big"or RQG=="transbig")and 1 or 0;local Jkp2lGXG=
(RQG=="small"or RQG=="transsmall")and 1 or 0
local ifcyuS=(RQG=="transsmall"or RQG==
"transbig")and 100 or 255;if RQG=='nobar'then Jkp2lGXG=0;tVwI_N=0 end
XGUIEng.ShowWidget("/InGame/ThroneRoomBars",tVwI_N)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",Jkp2lGXG)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",tVwI_N)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",Jkp2lGXG)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars/BarBottom",1,ifcyuS)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars/BarTop",1,ifcyuS)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars_2/BarBottom",1,ifcyuS)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars_2/BarTop",1,ifcyuS)BriefingSystem.barType=RQG end
function BriefingSystem.ShowBriefingText(V03W,R,X6_)
local tN5u=XGUIEng.GetStringTableText(V03W)if tN5u==""then tN5u=V03W end
if not R then
GUI.SendScriptCommand("BriefingSystem.timer = "..
(
BriefingSystem.GlobalSystem.STANDARDTIME_PER_PAGE+
BriefingSystem.GlobalSystem.SECONDS_PER_CHAR*string.len(tN5u))..";")end;if X6_ then tN5u="{cr}{cr}{cr}"..tN5u end
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/MissionBriefing/Text",1)
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Text","{center}"..tN5u)end
function BriefingSystem.ShowBriefingTitle(Yqc0GWr)
local UC7=XGUIEng.GetStringTableText(Yqc0GWr)if UC7 ==""then UC7=Yqc0GWr end;if BriefingSystem.GlobalSystem and
string.sub(UC7,1,1)~="{"then
UC7=BriefingSystem.GlobalSystem.COLOR1 ..
"{center}{darkshadow}"..UC7 end
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",1)
XGUIEng.SetText("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",UC7)end
function BriefingSystem.SchowBriefingOptionDialog(WbvvcjER)local rOLxXC={GUI.GetScreenSize()}
local w762p7sZ="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"
BriefingSystem.OriginalBoxPosition={XGUIEng.GetWidgetScreenPosition(w762p7sZ)}
local _7jt=XGUIEng.GetWidgetID(w762p7sZ.."/ListBox")XGUIEng.ListBoxPopAll(_7jt)
for dN=1,WbvvcjER.mc.amount,1 do if
WbvvcjER.mc.answers[dN]then
XGUIEng.ListBoxPushItem(_7jt,WbvvcjER.mc.answers[dN][1])end end;XGUIEng.ListBoxSetSelectedIndex(_7jt,0)
local ORXyFQ={XGUIEng.GetWidgetScreenSize(w762p7sZ)}local OL1oV=(rOLxXC[1]/1920)local Q=math.ceil((rOLxXC[1]/2)-
(ORXyFQ[1]/2))local HQvT5=math.ceil(rOLxXC[2]- (
ORXyFQ[2]-20))
XGUIEng.SetWidgetScreenPosition(w762p7sZ,Q,HQvT5)XGUIEng.PushPage(w762p7sZ,false)
XGUIEng.ShowWidget(w762p7sZ,1)BriefingSystem.MCSelectionIsShown=true end
function BriefingSystem.Briefing_MultipleChoice()
local B35igHj=BriefingSystem.currBriefing[BriefingSystem.GlobalSystem.page]
if B35igHj and B35igHj.mc then if B35igHj.mc.title then
BriefingSystem.ShowBriefingTitle(B35igHj.mc.title)end;if B35igHj.mc.text then
BriefingSystem.ShowBriefingText(B35igHj.mc.text,true)end;if B35igHj.mc.answers then
BriefingSystem.SchowBriefingOptionDialog(B35igHj)end
GUI.SendScriptCommand("BriefingSystem.currBriefing[BriefingSystem.page].dusation = 999999")end end
function BriefingSystem.OnConfirmed()
local o8pPC2="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"local f7nUIW=BriefingSystem.OriginalBoxPosition
XGUIEng.SetWidgetScreenPosition(o8pPC2,f7nUIW[1],f7nUIW[2])XGUIEng.ShowWidget(o8pPC2,0)XGUIEng.PopPage()
local bDgD=BriefingSystem.currBriefing[BriefingSystem.GlobalSystem.page]
if bDgD.mc then local Kg8PhSq=BriefingSystem.GlobalSystem.page
local Tcv_=XGUIEng.ListBoxGetSelectedIndex(
o8pPC2 .."/ListBox")+1
BriefingSystem.currBriefing[Kg8PhSq].mc.current=Tcv_
local lygY=BriefingSystem.currBriefing[Kg8PhSq].mc.current
local HG=BriefingSystem.currBriefing[Kg8PhSq].mc.answers[lygY].ID
GUI.SendScriptCommand([[BriefingSystem.OnConfirmed(]]..HG..[[,]]..
bDgD.mc.current..[[,]]..lygY..[[)]])end end
function BriefingSystem.CreateMarker(u,m9i,EqPMP,JR,G1Cl6,h,fYUikw)local W9qTCm=u.position
if W9qTCm then
if type(W9qTCm)=="table"then if

W9qTCm[GUI.GetPlayerID()]or W9qTCm.default or W9qTCm.playerPositions then
W9qTCm=W9qTCm[GUI.GetPlayerID()]or W9qTCm.default end end end;if not W9qTCm then W9qTCm=u.followEntity
if type(W9qTCm)=="table"then W9qTCm=
W9qTCm[GUI.GetPlayerID()]or W9qTCm.default end end
assert(W9qTCm)
if type(W9qTCm)~="table"then W9qTCm=GetPosition(W9qTCm)end
if
EqPMP and not BriefingSystem.listOfMarkers[EqPMP]then BriefingSystem.listOfMarkers[EqPMP]={}end;while
GUI.IsMinimapSignalExisting(BriefingSystem.markerUniqueID)==1 do
BriefingSystem.markerUniqueID=BriefingSystem.markerUniqueID+1 end;assert(
type(m9i)=="number"and m9i>0)
JR=JR or 32;G1Cl6=G1Cl6 or 245;h=h or 110;fYUikw=fYUikw or 255
GUI.CreateMinimapSignalRGBA(BriefingSystem.markerUniqueID,W9qTCm.X,W9qTCm.Y,JR,G1Cl6,h,fYUikw,m9i)
if EqPMP then
table.insert(BriefingSystem.listOfMarkers[EqPMP],{ID=BriefingSystem.markerUniqueID,X=W9qTCm.X,Y=W9qTCm.Y,R=JR,G=G1Cl6,B=h,Alpha=fYUikw,type=m9i})end
BriefingSystem.markerUniqueID=BriefingSystem.markerUniqueID+1 end
function BriefingSystem.DestroyMarkerList(YlaSjEKp)
if BriefingSystem.listOfMarkers[YlaSjEKp]then
for u_ogp8,K in
ipairs(BriefingSystem.listOfMarkers[YlaSjEKp])do
if
K.ID and GUI.IsMinimapSignalExisting(K.ID)==1 then GUI.DestroyMinimapSignal(K.ID)end end;BriefingSystem.listOfMarkers[YlaSjEKp]=nil end end
function BriefingSystem.DestroyMarkerOfList(ob,a3)
if BriefingSystem.listOfMarkers[ob]then
local MvWxr=BriefingSystem.listOfMarkers[ob][a3]if MvWxr and MvWxr.ID and
GUI.IsMinimapSignalExisting(MvWxr.ID)==1 then
GUI.DestroyMinimapSignal(MvWxr.ID)MvWxr.ID=nil end end end
function BriefingSystem.RedeployMarkerList(HgY6,Wc,eQ5)
if BriefingSystem.listOfMarkers[HgY6]then
for kvR,So in
ipairs(BriefingSystem.listOfMarkers[HgY6])do
if So.ID then So.X=Wc;So.Y=eQ5
if GUI.IsMinimapSignalExisting(So.ID)==1 then
GUI.RedeployMinimapSignal(So.ID,Wc,eQ5)else
GUI.CreateMinimapSignalRGBA(So.ID,Wc,eQ5,So.R,So.G,So.B,So.Alpha,So.type)end end end end end
function BriefingSystem.RedeployMarkerOfList(Wi,X1WM,OVBAVy,Joa)
if BriefingSystem.listOfMarkers[Wi]then
local NF0=BriefingSystem.listOfMarkers[Wi][X1WM]
if NF0 and NF0.ID then NF0.X=OVBAVy;NF0.Y=Joa
if
GUI.IsMinimapSignalExisting(NF0.ID)==1 then GUI.RedeployMinimapSignal(NF0.ID,OVBAVy,Joa)else
GUI.CreateMinimapSignalRGBA(NF0.ID,OVBAVy,Joa,NF0.R,NF0.G,NF0.B,NF0.Alpha,NF0.type)end end end end
function BriefingSystem.RefreshMarkerList(OeF)
if BriefingSystem.listOfMarkers[OeF]then
for sawaLtSr,KWeL in
ipairs(BriefingSystem.listOfMarkers[OeF])do
if KWeL.ID then
if GUI.IsMinimapSignalExisting(KWeL.ID)==1 then
GUI.RedeployMinimapSignal(KWeL.ID,KWeL.X,KWeL.Y)else
GUI.CreateMinimapSignalRGBA(KWeL.ID,KWeL.X,KWeL.Y,KWeL.R,KWeL.G,KWeL.B,KWeL.Alpha,KWeL.type)end end end end end
function BriefingSystem.RefreshMarkerOfList(K,rvhod9t)
if BriefingSystem.listOfMarkers[K]then
local bfx5oN=BriefingSystem.listOfMarkers[K][rvhod9t]
if bfx5oN and bfx5oN.ID then
if
GUI.IsMinimapSignalExisting(bfx5oN.ID)==1 then
GUI.RedeployMinimapSignal(bfx5oN.ID,bfx5oN.X,bfx5oN.Y)else
GUI.CreateMinimapSignalRGBA(bfx5oN.ID,bfx5oN.X,bfx5oN.Y,bfx5oN.R,bfx5oN.G,bfx5oN.B,bfx5oN.Alpha,bfx5oN.type)end end end end
function BriefingSystem.EnableBriefingSkipButton(XDKTNXw,RyTb)if
XDKTNXw==nil or XDKTNXw==GUI.GetPlayerID()then
XGUIEng.DisableButton("/InGame/ThroneRoom/Main/Skip",RyTb and 0 or 1)end end
function BriefingSystem_CheckFader(ImqF1v,K)if BriefingSystem.GlobalSystem.timer<K then if
ImqF1v==1 then FadeIn(K)else FadeOut(K)end
BriefingSystem.faderJob=nil;return true end end
function ThroneRoomCameraControl()
if Camera.GetCameraBehaviour(5)==5 and
BriefingSystem.GlobalSystem.isActive==true then
local Ru=BriefingSystem.Flight
if Ru.systemEnabled then local Vy5qF=Ru.StartTime;local rokDhenZ=Ru.FlyTime
local td8OL=Ru.StartPosition or Ru.EndPosition;local W=Ru.EndPosition;local CSi=Ru.StartRotation or Ru.EndRotation
local v2VylMn=Ru.EndRotation;local Oi=Ru.StartZoomAngle or Ru.EndZoomAngle
local KwcrRu=Ru.EndZoomAngle;local bgFJ=Ru.StartZoomDistance or Ru.EndZoomDistance
local fqGD1rfW=Ru.EndZoomDistance;local K0=Ru.StartFOV or Ru.EndFOV;local _1To2=Ru.EndFOV
local lkzs=Ru.StartUV0 or Ru.EndUV0;local Hhwf3oO=Ru.EndUV0;local Oh5=Ru.StartUV1 or Ru.EndUV1;local LgQF=Ru.EndUV1;local emGbhJGH=
Logic.GetTimeMs()/1000;local e_Ev8OQ=math
if Ru.Follow then
local KIQCH=GetPosition(Ru.Follow)if W.X~=KIQCH.X and W.Y~=KIQCH.Y then Ru.StartPosition=W
Ru.EndPosition=KIQCH end
if Ru.StartPosition and
Logic.IsEntityMoving(GetEntityId(Ru.Follow))then
local L4bw=e_Ev8OQ.rad(Logic.GetEntityOrientation(GetEntityId(Ru.Follow)))
local XhBEPD,Uq,RmyiI_D,w_2iiJwx=Ru.StartPosition.X,Ru.StartPosition.Y,KIQCH.X,KIQCH.Y;XhBEPD=XhBEPD-RmyiI_D;Uq=Uq-w_2iiJwx;local RRESd=
e_Ev8OQ.sqrt(XhBEPD*XhBEPD+Uq*Uq)*10;local S1qoVmFR=RRESd*
(rokDhenZ-emGbhJGH+Vy5qF)
local f2=RRESd* (emGbhJGH+Vy5qF)
W={X=KIQCH.X+e_Ev8OQ.cos(L4bw)*RRESd,Y=KIQCH.Y+
e_Ev8OQ.sin(L4bw)*RRESd}Ru.FollowTemp=Ru.FollowTemp or{}
local O3rHR=BriefingSystem.InterpolationFactor(emGbhJGH,emGbhJGH,1,Ru.FollowTemp)
XhBEPD,Uq,z1=BriefingSystem.GetCameraPosition(KIQCH,W,O3rHR)td8OL={X=XhBEPD,Y=Uq,Z=z1}else td8OL=KIQCH end;W=td8OL end
local zBMvU6=BriefingSystem.InterpolationFactor(Vy5qF,emGbhJGH,rokDhenZ,Ru)
local ZmbDgbg,hMxy,hj3=BriefingSystem.GetCameraPosition(td8OL,W,zBMvU6)local M7q3pa8=bgFJ+ (fqGD1rfW-bgFJ)*zBMvU6;local guEhw=Oi+ (KwcrRu-
Oi)*zBMvU6;local sll=CSi+
(v2VylMn-CSi)*zBMvU6;local BzNBgGvD=M7q3pa8*
e_Ev8OQ.cos(e_Ev8OQ.rad(guEhw))
Camera.ThroneRoom_SetLookAt(ZmbDgbg,hMxy,hj3)
Camera.ThroneRoom_SetPosition(ZmbDgbg+
e_Ev8OQ.cos(e_Ev8OQ.rad(sll-90))*BzNBgGvD,hMxy+
e_Ev8OQ.sin(e_Ev8OQ.rad(sll-90))*BzNBgGvD,hj3+ (M7q3pa8)*
e_Ev8OQ.sin(e_Ev8OQ.rad(guEhw)))
Camera.ThroneRoom_SetFOV(K0+ (_1To2-K0)*zBMvU6)
BriefingSystem.SetBriefingSplashscreenUV(lkzs,Hhwf3oO,Oh5,LgQF,zBMvU6)else local YU80=BriefingSystem.Flight.Cutscene
if YU80 then local ARnO_0E=YU80.StartPosition or
YU80.EndPosition;local Qh=YU80.EndPosition;local lqxbMC=
YU80.StartLookAt or YU80.EndLookAt;local qOk5Jm=YU80.EndLookAt;local tpSe2fs=
YU80.StartFOV or YU80.EndFOV;local AuVgc7=YU80.EndFOV
local vxnB=YU80.StartTime;local ZQOXXXd=YU80.FlyTime;local cyBmTv=Logic.GetTimeMs()/1000;local _TKd0F=
YU80.StartUV0 or YU80.EndUV0;local Z=YU80.EndUV0;local Dw=YU80.StartUV1 or
YU80.EndUV1;local bsFpM=YU80.EndUV1
local h=BriefingSystem.InterpolationFactor(vxnB,cyBmTv,ZQOXXXd,YU80)
if not lqxbMC.X then
local PDewNmM=GetPosition(lqxbMC[1],(lqxbMC[2]or 0))if lqxbMC[3]then PDewNmM.X=PDewNmM.X+lqxbMC[3]*
math.cos(math.rad(lqxbMC[4]))
PDewNmM.Y=
PDewNmM.Y+lqxbMC[3]*math.sin(math.rad(lqxbMC[4]))end
lqxbMC=PDewNmM end
if not qOk5Jm.X then
local GFlD=GetPosition(qOk5Jm[1],(qOk5Jm[2]or 0))
if qOk5Jm[3]then GFlD.X=GFlD.X+
qOk5Jm[3]*math.cos(math.rad(qOk5Jm[4]))GFlD.Y=GFlD.Y+qOk5Jm[3]*
math.sin(math.rad(qOk5Jm[4]))end;qOk5Jm=GFlD end
local doBTofya,rNP,TL=BriefingSystem.CutsceneGetPosition(lqxbMC,qOk5Jm,h)Camera.ThroneRoom_SetLookAt(doBTofya,rNP,TL)
if
not ARnO_0E.X then
local y3owm5E=GetPosition(ARnO_0E[1],(ARnO_0E[2]or 0))
if ARnO_0E[3]then
y3owm5E.X=y3owm5E.X+ARnO_0E[3]*
math.cos(math.rad(ARnO_0E[4]))y3owm5E.Y=y3owm5E.Y+
ARnO_0E[3]*math.sin(math.rad(ARnO_0E[4]))end;ARnO_0E=y3owm5E end
if not Qh.X then local psHOEe2=GetPosition(Qh[1],(Qh[2]or 0))if Qh[3]then
psHOEe2.X=
psHOEe2.X+Qh[3]*math.cos(math.rad(Qh[4]))
psHOEe2.Y=psHOEe2.Y+Qh[3]*math.sin(math.rad(Qh[4]))end;Qh=psHOEe2 end
local Tzgj_W,g0AS39,t2=BriefingSystem.CutsceneGetPosition(ARnO_0E,Qh,h)Camera.ThroneRoom_SetPosition(Tzgj_W,g0AS39,t2)
Camera.ThroneRoom_SetFOV(
tpSe2fs+ (AuVgc7-tpSe2fs)*h)
BriefingSystem.SetBriefingSplashscreenUV(_TKd0F,Z,Dw,bsFpM,factor)end end
if BriefingSystem.MCSelectionIsShown then
local R1zT="/InGame/SoundOptionsMain/RightContainer/SoundProviderComboBoxContainer"
if XGUIEng.IsWidgetShown(R1zT)==0 then
BriefingSystem.MCSelectionIsShown=false;BriefingSystem.OnConfirmed()end end end end
function ThroneRoomLeftClick()local J2Df=GUI.GetMouseOverEntity()
API.Bridge(
"BriefingSystem.LeftClickOnEntity("..tostring(J2Df)..")")local YyS,o=GUI.Debug_GetMapPositionUnderMouse()
API.Bridge(
"BriefingSystem.LeftClickOnPosition("..tostring(YyS)..", "..tostring(o)..")")local YyS,o=GUI.GetMousePosition()
API.Bridge("BriefingSystem.LeftClickOnScreen("..
tostring(YyS)..", "..tostring(o)..")")end
function BriefingSystem.CutsceneGetPosition(MY16y,ZBUghmX,ncK)
local Deq=MY16y.X+ (ZBUghmX.X-MY16y.X)*ncK
local GH3wE=MY16y.Y+ (ZBUghmX.Y-MY16y.Y)*ncK
local xZFv=MY16y.Z+ (ZBUghmX.Z-MY16y.Z)*ncK;return Deq,GH3wE,xZFv end
function BriefingSystem.CutsceneSaveFlight(bc0w4j,OGMxal0,QlewVjkq,Q,yI)BriefingSystem.Flight.Cutscene=
BriefingSystem.Flight.Cutscene or{}
BriefingSystem.Flight.Cutscene.StartPosition=bc0w4j
BriefingSystem.Flight.Cutscene.StartLookAt=OGMxal0
BriefingSystem.Flight.Cutscene.StartFOV=QlewVjkq
BriefingSystem.Flight.Cutscene.StartTime=Logic.GetTimeMs()/1000;BriefingSystem.Flight.Cutscene.FlyTime=0
BriefingSystem.Flight.Cutscene.StartUV0=Q;BriefingSystem.Flight.Cutscene.StartUV1=yI end
function BriefingSystem.CutsceneFlyTo(EDE3,FpWG11U,kRY46C,MvOaiq,DUic_1K,rVj9z4)BriefingSystem.Flight.Cutscene=
BriefingSystem.Flight.Cutscene or{}BriefingSystem.Flight.Cutscene.StartTime=
Logic.GetTimeMs()/1000
BriefingSystem.Flight.Cutscene.FlyTime=MvOaiq
BriefingSystem.Flight.Cutscene.EndPosition=EDE3
BriefingSystem.Flight.Cutscene.EndLookAt=FpWG11U
BriefingSystem.Flight.Cutscene.EndFOV=kRY46C
BriefingSystem.Flight.Cutscene.EndUV0=DUic_1K
BriefingSystem.Flight.Cutscene.EndUV1=rVj9z4 end
function BriefingSystem.CutsceneStopFlight()BriefingSystem.Flight.Cutscene=
BriefingSystem.Flight.Cutscene or{}
BriefingSystem.Flight.Cutscene.StartPosition=BriefingSystem.Flight.Cutscene.EndPosition
BriefingSystem.Flight.Cutscene.StartLookAt=BriefingSystem.Flight.Cutscene.EndLookAt
BriefingSystem.Flight.Cutscene.StartFOV=BriefingSystem.Flight.Cutscene.EndFOV end
function BriefingSystem.InterpolationFactor(mWkmCx,qQpo,qXKzBXo0,cJ)local HI4G3oH=1
if mWkmCx+qXKzBXo0 >qQpo then HI4G3oH=
(qQpo-mWkmCx)/qXKzBXo0
if cJ and qQpo==cJ.TempLastLogicTime then
HI4G3oH=
HI4G3oH+
(Framework.GetTimeMs()-cJ.TempLastFrameworkTime)/qXKzBXo0/1000*
Game.GameTimeGetFactor(GUI.GetPlayerID())else cJ.TempLastLogicTime=qQpo
cJ.TempLastFrameworkTime=Framework.GetTimeMs()end end;if HI4G3oH>1 then HI4G3oH=1 end;return HI4G3oH end
function BriefingSystem.GetCameraPosition(ncWw,kdS,OS60)
local dl=ncWw.X+ (kdS.X-ncWw.X)*OS60;local b2UK=ncWw.Y+ (kdS.Y-ncWw.Y)*OS60
local FC0yhp
if ncWw.Z or kdS.Z then
FC0yhp=
(ncWw.Z or Display.GetTerrainHeight(ncWw.X,ncWw.Y))+
(
(kdS.Z or Display.GetTerrainHeight(kdS.X,kdS.Y))-
(ncWw.Z or Display.GetTerrainHeight(ncWw.X,ncWw.Y)))*OS60 else
FC0yhp=Display.GetTerrainHeight(dl,b2UK)*
((ncWw.ZRelative or 1)+
((
kdS.ZRelative or 1)- (ncWw.ZRelative or 1))*OS60)+
(
(ncWw.ZAdd or 0)+
((kdS.ZAdd or 0)- (ncWw.ZAdd or 0)))*OS60 end;return dl,b2UK,FC0yhp end
function BriefingSystem.SaveFlight(lL30T,zt,Ofgm3g,z6WE21dc,rJg9H,sNyznm3W,UU)
BriefingSystem.Flight.StartZoomAngle=Ofgm3g;BriefingSystem.Flight.StartZoomDistance=z6WE21dc
BriefingSystem.Flight.StartRotation=zt;BriefingSystem.Flight.StartPosition=lL30T
BriefingSystem.Flight.StartFOV=rJg9H;BriefingSystem.Flight.StartUV0=sNyznm3W
BriefingSystem.Flight.StartUV1=UU end
function BriefingSystem.FlyTo(YBciOAz2,wJvNH,dOvZoN,IP01vP,DIoX3,sjXYan,KxB8fW,M)local JmyAd=BriefingSystem.Flight;JmyAd.StartTime=
Logic.GetTimeMs()/1000;JmyAd.FlyTime=sjXYan
JmyAd.EndPosition=YBciOAz2;JmyAd.EndRotation=wJvNH;JmyAd.EndZoomAngle=dOvZoN
JmyAd.EndZoomDistance=IP01vP;JmyAd.EndFOV=DIoX3;JmyAd.EndUV0=KxB8fW;JmyAd.EndUV1=M end
function BriefingSystem.StopFlight()local L=BriefingSystem.Flight
L.StartZoomAngle=L.EndZoomAngle;L.StartZoomDistance=L.EndZoomDistance;L.StartRotation=L.EndRotation
L.StartPosition=L.EndPosition;L.StartFOV=L.EndFOV;L.StartUV0=L.EndUV0;L.StartUV1=L.EndUV1;if L.Follow then
L.StartPosition=GetPosition(L.Follow)L.Follow=nil end end
function BriefingSystem.FollowFlight(U,uAbuU,EF205E,YFR5myC,K1Lgio,KMu,PPqE,sOE,hf9m_U8)local dTQ=GetPosition(U)dTQ.Z=PPqE or 0
BriefingSystem.FlyTo(dTQ,uAbuU,EF205E,YFR5myC,K1Lgio,KMu,sOE,hf9m_U8)BriefingSystem.Flight.StartPosition=nil
BriefingSystem.Flight.Follow=U end;function BriefingSystem.IsBriefingActive()
return BriefingSystem.GlobalSystem~=nil and
BriefingSystem.GlobalSystem.isActive end
IsBriefingActive=BriefingSystem.IsBriefingActive
function BriefingSystem.SetBriefingPageTextPosition(k29Z4)local a={GUI.GetScreenSize()}
local i,t=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight")
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",i,65)
if not k29Z4.mc then
if BriefingSystem.BriefingTextPositionBackup then
local TmE=BriefingSystem.BriefingTextPositionBackup
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text",TmE[1],TmE[2])end
if k29Z4.splashscreen then
if k29Z4.centered then local xR=0
if k29Z4.text then
local LJ3E=string.len(k29Z4.text)xR=xR+math.ceil((LJ3E/80))local Vjx=0
local curjMDD,gBS9Zk=string.find(k29Z4.text,"{cr}")while(gBS9Zk)do Vjx=Vjx+1
curjMDD,gBS9Zk=string.find(k29Z4.text,"{cr}",gBS9Zk+1)end
xR=xR+math.floor((Vjx/2))local Xr={GUI.GetScreenSize()}
xR=(Xr[2]/2)- (xR*15)end
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",i,0+xR)
local i,t=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text")if not BriefingSystem.BriefingTextPositionBackup then
BriefingSystem.BriefingTextPositionBackup={i,t}end
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text",i,
38+xR)end end;return end
local i,t=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight")if k29Z4.mc.text and k29Z4.mc.text~=""then
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",i,5)end
local i,t=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text")if not BriefingSystem.BriefingTextPositionBackup then
BriefingSystem.BriefingTextPositionBackup={i,t}end
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text",i,42)end
function BriefingSystem.SetBriefingSplashscreenUV(UPp,hWpZC,bFF8,RXM,Ieb1cGC)if not UPp or not hWpZC or not bFF8 or
not RXM then return end
local Bf="/InGame/ThroneRoomBars_2/BarTop"local hKJi2="/InGame/ThroneRoomBars_2/BarBottom"
local jW={GUI.GetScreenSize()}
local JkVK=math.floor((jW[1]/jW[2])*10)==13
local oXM7=UPp[1]+ (hWpZC[1]-UPp[1])*Ieb1cGC
local z__Va=UPp[2]+ (hWpZC[2]-UPp[2])*Ieb1cGC
local uGbp=bFF8[1]+ (RXM[1]-bFF8[1])*Ieb1cGC
local OXK0=bFF8[2]+ (RXM[2]-bFF8[2])*Ieb1cGC;if JkVK then oXM7=oXM7+ (oXM7*0.125)
uGbp=uGbp- (uGbp*0.125)end
XGUIEng.SetMaterialUV(Bf,1,oXM7,z__Va,uGbp,OXK0)end
function BriefingSystem.SetBriefingPagePortrait(Ek3QueoD)
if Ek3QueoD.portrait then
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/KnightBG",1,255)
XGUIEng.SetMaterialTexture("/InGame/ThroneRoom/KnightInfo/KnightBG",1,Ek3QueoD.portrait)
XGUIEng.SetMaterialUV("/InGame/ThroneRoom/KnightInfo/KnightBG",1,0,0,1,1)else
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoom/KnightInfo/KnightBG",1,0)end end
function BriefingSystem.SetBriefingPageOrSplashscreen(g,m_l)local L="/InGame/ThroneRoomBars_2/BarTop"
local XmcB="/InGame/ThroneRoomBars_2/BarBottom"local l5Nd={GUI.GetScreenSize()}
if not g.splashscreen then
XGUIEng.SetMaterialTexture(L,1,"")XGUIEng.SetMaterialTexture(XmcB,1,"")
XGUIEng.SetMaterialColor(L,1,0,0,0,255)XGUIEng.SetMaterialColor(XmcB,1,0,0,0,255)
if
BriefingSystem.BriefingBarSizeBackup then local VGJdue=BriefingSystem.BriefingBarSizeBackup
XGUIEng.SetWidgetSize(L,VGJdue[1],VGJdue[2])BriefingSystem.BriefingBarSizeBackup=nil end;BriefingSystem.ShowBriefingBar(m_l)return end
if g.splashscreen==true then XGUIEng.SetMaterialTexture(L,1,"")
XGUIEng.SetMaterialColor(L,1,0,0,0,255)XGUIEng.SetMaterialUV(L,1,0,0,1,1)else
XGUIEng.SetMaterialColor(XmcB,1,0,0,0,0)
if g.splashscreen.color then
XGUIEng.SetMaterialColor(L,1,unpack(g.splashscreen.color))else XGUIEng.SetMaterialColor(L,1,255,255,255,255)end
XGUIEng.SetMaterialTexture(L,1,g.splashscreen.image)end
if not BriefingSystem.BriefingBarSizeBackup then
local ztMtdy,rA=XGUIEng.GetWidgetSize(L)BriefingSystem.BriefingBarSizeBackup={ztMtdy,rA}end;local sEMv=BriefingSystem.BriefingBarSizeBackup[1]
local VPX,c=XGUIEng.GetWidgetSize("/InGame/ThroneRoomBars")XGUIEng.SetWidgetSize(L,sEMv,c)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars",0)XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",1)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",0)XGUIEng.ShowWidget(L,1)end;BundleBriefingSystem:OverwriteGetPosition()end
function BundleBriefingSystem:OverwriteGetPosition()
GetPosition=function(zHapMi,Jmsve1Q)Jmsve1Q=Jmsve1Q or 0
if
type(zHapMi)=="table"then return zHapMi else
if not IsExisting(zHapMi)then return{X=0,Y=0,Z=0+Jmsve1Q}else
local _B8W1YL=GetID(zHapMi)local F,FN7,cpNryuPy=Logic.EntityGetPos(_B8W1YL)return
{X=F,Y=FN7,Z=cpNryuPy+Jmsve1Q}end end end end;Core:RegisterBundle("BundleBriefingSystem")function Reward_Briefing(...)return
b_Reward_Briefing:new(...)end
b_Reward_Briefing={Name="Reward_Briefing",Description={en="Reward: Calls a function that creates a briefing and saves the returned briefing ID into the quest.",de="Lohn: Ruft eine Funktion auf, die ein Briefing erzeugt und die zurueckgegebene ID in der Quest speichert."},Parameter={{ParameterType.Default,en="Briefing function",de="Funktion mit Briefing"}}}function b_Reward_Briefing:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_Briefing:AddParameter(mVKRd8,TBV0052)if(
mVKRd8 ==0)then self.Function=TBV0052 end end
function b_Reward_Briefing:CustomFunction(cGBeq)
local PRXb=_G[self.Function](self,cGBeq)local t=GetQuestID(cGBeq.Identifier)
Quests[t].EmbeddedBriefing=PRXb
if not PRXb and QSB.DEBUG_CheckWhileRuntime then
local Jk3TbYo=cGBeq.Identifier..": "..
self.Name..": '"..self.Function..
"' has not returned anything!"if IsBriefingActive()then GUI_Note(Jk3TbYo)end
dbg(Jk3TbYo)end end
function b_Reward_Briefing:DEBUG(Nm61D3Il)
if
not type(_G[self.Function])=="function"then
dbg(Nm61D3Il.Identifier..": "..self.Name..
": '"..self.Function.."' was not found!")return true end;return false end
function b_Reward_Briefing:Reset(Qjx7nk)local ZfqIP=GetQuestID(Qjx7nk.Identifier)Quests[ZfqIP].EmbeddedBriefing=
nil end;Core:RegisterBehavior(b_Reward_Briefing)function Reprisal_Briefing(...)return
b_Reprisal_Briefing:new(...)end
b_Reprisal_Briefing={Name="Reprisal_Briefing",Description={en="Reprisal: Calls a function that creates a briefing and saves the returned briefing ID into the quest.",de="Vergeltung: Ruft eine Funktion auf, die ein Briefing erzeugt und die zurueckgegebene ID in der Quest speichert."},Parameter={{ParameterType.Default,en="Briefing function",de="Funktion mit Briefing"}}}
function b_Reprisal_Briefing:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_Briefing:AddParameter(p4ZD2RW,o)
if(p4ZD2RW==0)then self.Function=o end end
function b_Reprisal_Briefing:CustomFunction(QK5cr)
local e575=_G[self.Function](self,QK5cr)local OP=GetQuestID(QK5cr.Identifier)
Quests[OP].EmbeddedBriefing=e575
if not e575 and QSB.DEBUG_CheckWhileRuntime then
local HxUqj4B=QK5cr.Identifier..": "..
self.Name..": '"..self.Function..
"' has not returned anything!"if IsBriefingActive()then GUI_Note(HxUqj4B)end
dbg(HxUqj4B)end end
function b_Reprisal_Briefing:DEBUG(dryo7a)
if
not type(_G[self.Function])=="function"then
dbg(dryo7a.Identifier..": "..self.Name..
": '"..self.Function.."' was not found!")return true end;return false end
function b_Reprisal_Briefing:Reset(Vvmt)local z1jKKH=GetQuestID(Vvmt.Identifier)Quests[z1jKKH].EmbeddedBriefing=
nil end;Core:RegisterBehavior(b_Reprisal_Briefing)function Trigger_Briefing(...)return
b_Trigger_Briefing:new(...)end
b_Trigger_Briefing={Name="Trigger_Briefing",Description={en="Trigger: after an embedded briefing of another quest has finished.",de="Ausloeser: wenn das eingebettete Briefing der angegebenen Quest beendet ist."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Wait time",de="Wartezeit"}}}
function b_Trigger_Briefing:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_Briefing:AddParameter(A,i)if(A==0)then self.Quest=i elseif(A==1)then
self.WaitTime=tonumber(i)or 0 end end
function b_Trigger_Briefing:CustomFunction(_ASR7X)local lneZ2=GetQuestID(self.Quest)
if
IsBriefingFinished(Quests[lneZ2].EmbeddedBriefing)then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end;return false end
function b_Trigger_Briefing:Interrupt(wZLxwQr)local Z=GetQuestID(self.Quest)Quests[Z].EmbeddedBriefing=
nil;self.WaitTimeTimer=nil end
function b_Trigger_Briefing:Reset(b3h1)local AGn=GetQuestID(self.Quest)Quests[AGn].EmbeddedBriefing=
nil;self.WaitTimeTimer=nil end
function b_Trigger_Briefing:DEBUG(EQVz)
if
(self.WaitTime and(type(self.WaitTime)~="number"or
self.WaitTime<0))then
dbg(EQVz.Identifier..
" "..self.Name..": waittime is nil or below 0!")return true elseif not IsValidQuest(self.Quest)then
dbg(EQVz.Identifier..
" "..self.Name..": '"..self.Quest..
"' is not a valid quest!")return true end;return false end;Core:RegisterBehavior(b_Trigger_Briefing)
BundleClassicBehaviors={}API=API or{}QSB=QSB or{}
QSB.EffectNameToID=QSB.EffectNameToID or{}QSB.InitalizedObjekts=QSB.InitalizedObjekts or{}QSB.DestroyedSoldiers=
QSB.DestroyedSoldiers or{}
function API.GetInputStringFromQuest(pYXX)if GUI then
API.Fatal("API.GetInputStringFromQuest: Quests can not be checked from local script!")return end
local GvHSsw=Quests[GetQuestID(pYXX)]if not GvHSsw then
API.Fatal("API.GetInputStringFromQuest: Quest '"..tostring(pYXX).."' not found!")return end;return
BundleClassicBehaviors.Global:GetInputFromQuest(pYXX)end;function API.GetInputNumberFromQuest(XvK5)
return tonumber(API.GetInputStringFromQuest(XvK5))end;function Goal_ActivateObject(...)return
b_Goal_ActivateObject:new(...)end
b_Goal_ActivateObject={Name="Goal_ActivateObject",Description={en="Goal: Activate an interactive object",de="Ziel: Aktiviere ein interaktives Objekt"},Parameter={{ParameterType.ScriptName,en="Object name",de="Skriptname"}}}function b_Goal_ActivateObject:GetGoalTable()return
{Objective.Object,{self.ScriptName}}end
function b_Goal_ActivateObject:AddParameter(bK2,U)if
bK2 ==0 then self.ScriptName=U end end
function b_Goal_ActivateObject:GetMsgKey()return"Quest_Object_Activate"end;Core:RegisterBehavior(b_Goal_ActivateObject)function Goal_Deliver(...)return
b_Goal_Deliver:new(...)end
b_Goal_Deliver={Name="Goal_Deliver",Description={en="Goal: Deliver goods to quest giver or to another player.",de="Ziel: Liefere Waren zum Auftraggeber oder zu einem anderen Spieler."},Parameter={{ParameterType.Custom,en="Type of good",de="Ressourcentyp"},{ParameterType.Number,en="Amount of good",de="Ressourcenmenge"},{ParameterType.Custom,en="To different player",de="Anderer Empfänger"},{ParameterType.Custom,en="Ignore capture",de="Abfangen ignorieren"}}}
function b_Goal_Deliver:GetGoalTable()
local FVkHUl7=Logic.GetGoodTypeID(self.GoodTypeName)return
{Objective.Deliver,FVkHUl7,self.GoodAmount,self.OverrideTarget,self.IgnoreCapture}end
function b_Goal_Deliver:AddParameter(FOA,eF0tAUG)
if(FOA==0)then self.GoodTypeName=eF0tAUG elseif(FOA==1)then self.GoodAmount=
eF0tAUG*1 elseif(FOA==2)then self.OverrideTarget=tonumber(eF0tAUG)elseif(FOA==
3)then
self.IgnoreCapture=AcceptAlternativeBoolean(eF0tAUG)end end
function b_Goal_Deliver:GetCustomData(_x)local J2o6d={}
if _x==0 then for r,PKiW0 in pairs(Goods)do if string.find(r,"^G_")then
table.insert(J2o6d,r)end end
table.sort(J2o6d)elseif _x==2 then table.insert(J2o6d,"-")for odc5tp=1,8 do
table.insert(J2o6d,odc5tp)end elseif _x==3 then table.insert(J2o6d,"true")
table.insert(J2o6d,"false")else assert(false)end;return J2o6d end
function b_Goal_Deliver:GetMsgKey()
local t3yD=Logic.GetGoodTypeID(self.GoodTypeName)local _nofE2=Logic.GetGoodCategoryForGoodType(t3yD)
local kPOaEej={[GoodCategories.GC_Clothes]="Quest_Deliver_GC_Clothes",[GoodCategories.GC_Entertainment]="Quest_Deliver_GC_Entertainment",[GoodCategories.GC_Food]="Quest_Deliver_GC_Food",[GoodCategories.GC_Gold]="Quest_Deliver_GC_Gold",[GoodCategories.GC_Hygiene]="Quest_Deliver_GC_Hygiene",[GoodCategories.GC_Medicine]="Quest_Deliver_GC_Medicine",[GoodCategories.GC_Water]="Quest_Deliver_GC_Water",[GoodCategories.GC_Weapon]="Quest_Deliver_GC_Weapon",[GoodCategories.GC_Resource]="Quest_Deliver_Resources"}
if _nofE2 then local XrKR=kPOaEej[_nofE2]if XrKR then return XrKR end end;return"Quest_Deliver_Goods"end;Core:RegisterBehavior(b_Goal_Deliver)function Goal_Diplomacy(...)return
b_Goal_Diplomacy:new(...)end
b_Goal_Diplomacy={Name="Goal_Diplomacy",Description={en="Goal: A diplomatic state must b reached. Can be lower than current state or higher.",de="Ziel: Die Beziehungen zu einem Spieler müssen entweder verbessert oder verschlechtert werden."},Parameter={{ParameterType.PlayerID,en="Party",de="Partei"},{ParameterType.Custom,en="Diplomacy state",de="Diplomatische Beziehung"},{ParameterType.Custom,en="Relation",de="Relation"}},DiploNameMap={[DiplomacyStates.Allied]={de="Verbündeter",en="Allied"},[DiplomacyStates.TradeContact]={de="Handelspartner",en="Trade Contact"},[DiplomacyStates.EstablishedContact]={de="Bekannt",en="Established Contact"},[DiplomacyStates.Undecided]={de="Unbekannt",en="Undecided"},[DiplomacyStates.Enemy]={de="Feind",en="Enemy"}},TextPattern={de="DIPLOMATIESTATUS ERREICHEN {cr}{cr}Status: %s{cr}Zur Partei: %s",en="DIPLOMATIC STATE {cr}{cr}State: %s{cr}To player: %s"}}function b_Goal_Diplomacy:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_Diplomacy:ChangeCaption(EZSc2rAA)local r0aOmY=
GetPlayerName(self.PlayerID)or""
local YzL3P1=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
local a2=string.format(self.TextPattern[YzL3P1],self.DiploNameMap[self.DiplState][YzL3P1],r0aOmY)Core:ChangeCustomQuestCaptionText(a2,EZSc2rAA)end
function b_Goal_Diplomacy:CustomFunction(hrEWj)self:ChangeCaption(hrEWj)
if self.BeSmallerThan then
if
GetDiplomacyState(hrEWj.ReceivingPlayer,self.PlayerID)<self.DiplState then return true end else if
GetDiplomacyState(hrEWj.ReceivingPlayer,self.PlayerID)>=self.DiplState then return true end end end
function b_Goal_Diplomacy:AddParameter(Qgeq,ay_Dm)
if(Qgeq==0)then self.PlayerID=ay_Dm*1 elseif(Qgeq==1)then
self.DiplState=DiplomacyStates[ay_Dm]elseif(Qgeq==2)then self.BeSmallerThan=ay_Dm=="<"end end;function b_Goal_Diplomacy:GetIcon()return{6,3}end
function b_Goal_Diplomacy:GetCustomData(z8K0j)
if
z8K0j==1 then
return{"Allied","TradeContact","EstablishedContact","Undecided","Enemy"}elseif z8K0j==2 then return{">=","<"}end end;Core:RegisterBehavior(b_Goal_Diplomacy)function Goal_DiscoverPlayer(...)return
b_Goal_DiscoverPlayer:new(...)end
b_Goal_DiscoverPlayer={Name="Goal_DiscoverPlayer",Description={en="Goal: Discover the home territory of another player.",de="Ziel: Entdecke das Heimatterritorium eines Spielers."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}function b_Goal_DiscoverPlayer:GetGoalTable()return
{Objective.Discover,2,{self.PlayerID}}end
function b_Goal_DiscoverPlayer:AddParameter(yh,Yo)if(
yh==0)then self.PlayerID=Yo*1 end end
function b_Goal_DiscoverPlayer:GetMsgKey()
local nkWKbF={[PlayerCategories.BanditsCamp]="Quest_Discover",[PlayerCategories.City]="Quest_Discover_City",[PlayerCategories.Cloister]="Quest_Discover_Cloister",[PlayerCategories.Harbour]="Quest_Discover",[PlayerCategories.Village]="Quest_Discover_Village"}local M9=GetPlayerCategoryType(self.PlayerID)if M9 then
local cVvE=nkWKbF[M9]if cVvE then return cVvE end end;return"Quest_Discover"end;Core:RegisterBehavior(b_Goal_DiscoverPlayer)function Goal_DiscoverTerritory(...)return
b_Goal_DiscoverTerritory:new(...)end
b_Goal_DiscoverTerritory={Name="Goal_DiscoverTerritory",Description={en="Goal: Discover a territory",de="Ziel: Entdecke ein Territorium"},Parameter={{ParameterType.TerritoryName,en="Territory",de="Territorium"}}}function b_Goal_DiscoverTerritory:GetGoalTable()return
{Objective.Discover,1,{self.TerritoryID}}end
function b_Goal_DiscoverTerritory:AddParameter(R8,CsDz)
if(
R8 ==0)then self.TerritoryID=tonumber(CsDz)if not self.TerritoryID then
self.TerritoryID=GetTerritoryIDByName(CsDz)end
assert(self.TerritoryID>0)end end
function b_Goal_DiscoverTerritory:GetMsgKey()return"Quest_Discover_Territory"end;Core:RegisterBehavior(b_Goal_DiscoverTerritory)function Goal_DestroyPlayer(...)return
b_Goal_DestroyPlayer:new(...)end
b_Goal_DestroyPlayer={Name="Goal_DestroyPlayer",Description={en="Goal: Destroy a player (destroy a main building)",de="Ziel: Zerstöre einen Spieler (ein Hauptgebäude muss zerstört werden)."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function b_Goal_DestroyPlayer:GetGoalTable()
assert(self.PlayerID<=8 and self.PlayerID>=1,
"Error in "..self.Name..": GetGoalTable: PlayerID is invalid")return{Objective.DestroyPlayers,self.PlayerID}end
function b_Goal_DestroyPlayer:AddParameter(u,Ru8E)if(u==0)then self.PlayerID=Ru8E*1 end end
function b_Goal_DestroyPlayer:GetMsgKey()
local nK={[PlayerCategories.BanditsCamp]="Quest_DestroyPlayers_Bandits",[PlayerCategories.City]="Quest_DestroyPlayers_City",[PlayerCategories.Cloister]="Quest_DestroyPlayers_Cloister",[PlayerCategories.Harbour]="Quest_DestroyEntities_Building",[PlayerCategories.Village]="Quest_DestroyPlayers_Village"}local m5STS=GetPlayerCategoryType(self.PlayerID)if m5STS then
local CJ4gk6Xx=nK[m5STS]if CJ4gk6Xx then return CJ4gk6Xx end end;return
"Quest_DestroyEntities_Building"end;Core:RegisterBehavior(b_Goal_DestroyPlayer)function Goal_StealInformation(...)return
b_Goal_StealInformation:new(...)end
b_Goal_StealInformation={Name="Goal_StealInformation",Description={en="Goal: Steal information from another players castle",de="Ziel: Stehle Informationen aus der Burg eines Spielers"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function b_Goal_StealInformation:GetGoalTable()
local WwPLCA3t=Logic.GetHeadquarters(self.PlayerID)if not WwPLCA3t or WwPLCA3t==0 then
WwPLCA3t=Logic.GetStoreHouse(self.PlayerID)end
assert(WwPLCA3t and WwPLCA3t~=0)return{Objective.Steal,1,{WwPLCA3t}}end;function b_Goal_StealInformation:AddParameter(YAwrq,VHZ4I)
if(YAwrq==0)then self.PlayerID=VHZ4I*1 end end;function b_Goal_StealInformation:GetMsgKey()return
"Quest_Steal_Info"end
Core:RegisterBehavior(b_Goal_StealInformation)function Goal_DestroyAllPlayerUnits(...)
return b_Goal_DestroyAllPlayerUnits:new(...)end
b_Goal_DestroyAllPlayerUnits={Name="Goal_DestroyAllPlayerUnits",Description={en="Goal: Destroy all units owned by player (be careful with script entities)",de="Ziel: Zerstöre alle Einheiten eines Spielers (vorsicht mit Script-Entities)"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function b_Goal_DestroyAllPlayerUnits:GetGoalTable()return
{Objective.DestroyAllPlayerUnits,self.PlayerID}end;function b_Goal_DestroyAllPlayerUnits:AddParameter(JTS,zRbXf)
if(JTS==0)then self.PlayerID=zRbXf*1 end end
function b_Goal_DestroyAllPlayerUnits:GetMsgKey()
local caDLM={[PlayerCategories.BanditsCamp]="Quest_DestroyPlayers_Bandits",[PlayerCategories.City]="Quest_DestroyPlayers_City",[PlayerCategories.Cloister]="Quest_DestroyPlayers_Cloister",[PlayerCategories.Harbour]="Quest_DestroyEntities_Building",[PlayerCategories.Village]="Quest_DestroyPlayers_Village"}local Pj=GetPlayerCategoryType(self.PlayerID)if Pj then
local xm=caDLM[Pj]if xm then return xm end end;return"Quest_DestroyEntities"end
Core:RegisterBehavior(b_Goal_DestroyAllPlayerUnits)function Goal_DestroyScriptEntity(...)
return b_Goal_DestroyScriptEntity:new(...)end
b_Goal_DestroyScriptEntity={Name="Goal_DestroyScriptEntity",Description={en="Goal: Destroy an entity",de="Ziel: Zerstöre eine Entität"},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}
function b_Goal_DestroyScriptEntity:GetGoalTable()return
{Objective.DestroyEntities,1,{self.ScriptName}}end;function b_Goal_DestroyScriptEntity:AddParameter(we,uv)
if(we==0)then self.ScriptName=uv end end
function b_Goal_DestroyScriptEntity:GetMsgKey()
if
Logic.IsEntityAlive(self.ScriptName)then local eu=GetID(self.ScriptName)
if eu and eu~=0 then
eu=Logic.GetEntityType(eu)
if eu and eu~=0 then
if
Logic.IsEntityTypeInCategory(eu,EntityCategories.AttackableBuilding)==1 then return"Quest_DestroyEntities_Building"elseif
Logic.IsEntityTypeInCategory(eu,EntityCategories.AttackableAnimal)==1 then return"Quest_DestroyEntities_Predators"elseif
Logic.IsEntityTypeInCategory(eu,EntityCategories.Hero)==1 then return"Quest_Destroy_Leader"elseif


Logic.IsEntityTypeInCategory(eu,EntityCategories.Military)==1 or
Logic.IsEntityTypeInCategory(eu,EntityCategories.AttackableSettler)==1 or
Logic.IsEntityTypeInCategory(eu,EntityCategories.AttackableMerchant)==1 then return"Quest_DestroyEntities_Unit"end end end end;return"Quest_DestroyEntities"end;Core:RegisterBehavior(b_Goal_DestroyScriptEntity)function Goal_DestroyType(...)return
b_Goal_DestroyType:new(...)end
b_Goal_DestroyType={Name="Goal_DestroyType",Description={en="Goal: Destroy entity types",de="Ziel: Zerstöre Entitätstypen"},Parameter={{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.Custom,en="Player",de="Spieler"}}}
function b_Goal_DestroyType:GetGoalTable()return
{Objective.DestroyEntities,2,Entities[self.EntityName],self.Amount,self.PlayerID}end
function b_Goal_DestroyType:AddParameter(j7Zsjoj,VDXpXH)
if(j7Zsjoj==0)then self.EntityName=VDXpXH elseif
(j7Zsjoj==1)then self.Amount=VDXpXH*1;self.DestroyTypeAmount=self.Amount elseif
(j7Zsjoj==2)then self.PlayerID=VDXpXH*1 end end
function b_Goal_DestroyType:GetCustomData(NT23H)local N8WCvTtk={}
if NT23H==0 then
for vk7,aaOq in pairs(Entities)do if
string.find(vk7,"^[ABU]_")then table.insert(N8WCvTtk,vk7)end end;table.sort(N8WCvTtk)elseif NT23H==2 then for F7JMSq_H=0,8 do
table.insert(N8WCvTtk,F7JMSq_H)end else assert(false)end;return N8WCvTtk end
function b_Goal_DestroyType:GetMsgKey()local BNZ09E=self.EntityName
if
Logic.IsEntityTypeInCategory(BNZ09E,EntityCategories.AttackableBuilding)==1 then return"Quest_DestroyEntities_Building"elseif
Logic.IsEntityTypeInCategory(BNZ09E,EntityCategories.AttackableAnimal)==1 then return"Quest_DestroyEntities_Predators"elseif
Logic.IsEntityTypeInCategory(BNZ09E,EntityCategories.Hero)==1 then return"Quest_Destroy_Leader"elseif


Logic.IsEntityTypeInCategory(BNZ09E,EntityCategories.Military)==1 or
Logic.IsEntityTypeInCategory(BNZ09E,EntityCategories.AttackableSettler)==1 or
Logic.IsEntityTypeInCategory(BNZ09E,EntityCategories.AttackableMerchant)==1 then return"Quest_DestroyEntities_Unit"end;return"Quest_DestroyEntities"end;Core:RegisterBehavior(b_Goal_DestroyType)
do
GameCallback_EntityKilled_Orig_QSB_Goal_DestroySoldiers=GameCallback_EntityKilled
GameCallback_EntityKilled=function(mcJGlQD6,AcM1nG,mMJQWw,sC,RE,mPRxk)
if AcM1nG~=0 and sC~=0 then QSB.DestroyedSoldiers[sC]=
QSB.DestroyedSoldiers[sC]or{}QSB.DestroyedSoldiers[sC][AcM1nG]=
QSB.DestroyedSoldiers[sC][AcM1nG]or 0
if

Logic.IsEntityTypeInCategory(RE,EntityCategories.Military)==1 and
Logic.IsEntityInCategory(mcJGlQD6,EntityCategories.HeavyWeapon)==0 then QSB.DestroyedSoldiers[sC][AcM1nG]=
QSB.DestroyedSoldiers[sC][AcM1nG]+1 end end
GameCallback_EntityKilled_Orig_QSB_Goal_DestroySoldiers(mcJGlQD6,AcM1nG,mMJQWw,sC,RE,mPRxk)end end
function Goal_DestroySoldiers(...)return b_Goal_DestroySoldiers:new(...)end
b_Goal_DestroySoldiers={Name="Goal_DestroySoldiers",Description={en="Goal: Destroy a given amount of enemy soldiers",de="Ziel: Zerstöre eine Anzahl gegnerischer Soldaten"},Parameter={{ParameterType.PlayerID,en="Attacking Player",de="Angreifer"},{ParameterType.PlayerID,en="Defending Player",de="Verteidiger"},{ParameterType.Number,en="Amount",de="Anzahl"}}}
function b_Goal_DestroySoldiers:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_DestroySoldiers:AddParameter(iVO,S5PgiAbz)if(iVO==0)then self.AttackingPlayer=S5PgiAbz*1 elseif(
iVO==1)then self.AttackedPlayer=S5PgiAbz*1 elseif(iVO==2)then
self.KillsNeeded=S5PgiAbz*1 end end
function b_Goal_DestroySoldiers:CustomFunction(jj1oYjc)
if not jj1oYjc.QuestDescription or jj1oYjc.QuestDescription==
""then
local sERpty=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
local R9WhkbR=
(sERpty=="de"and"SOLDATEN ZERSTÖREN {cr}{cr}von der Partei: ")or"DESTROY SOLDIERS {cr}{cr}from faction: "
local Wjj=(sERpty=="de"and"Anzahl: ")or"Amount: "
local X9n9mro=GetPlayerName(self.AttackedPlayer)or""
local Uj6hK="{center}"..R9WhkbR..
X9n9mro.."{cr}{cr}"..Wjj.." "..self.KillsNeeded;Core:ChangeCustomQuestCaptionText(Uj6hK,jj1oYjc)end;local YVjxMh=0
if QSB.DestroyedSoldiers[self.AttackingPlayer]and
QSB.DestroyedSoldiers[self.AttackingPlayer][self.AttackedPlayer]then
YVjxMh=QSB.DestroyedSoldiers[self.AttackingPlayer][self.AttackedPlayer]end;self.SaveAmount=self.SaveAmount or YVjxMh
return self.KillsNeeded<=YVjxMh-
self.SaveAmount or nil end
function b_Goal_DestroySoldiers:DEBUG(qk3r)
if
Logic.GetStoreHouse(self.AttackingPlayer)==0 then
dbg(qk3r.Identifier.." "..self.Name..
": Player "..self.AttackinPlayer.." is dead :-(")return true elseif Logic.GetStoreHouse(self.AttackedPlayer)==0 then
dbg(
qk3r.Identifier.." "..
self.Name..": Player "..self.AttackedPlayer.." is dead :-(")return true elseif self.KillsNeeded<0 then
dbg(qk3r.Identifier..
" "..self.Name..": Amount negative")return true end end;function b_Goal_DestroySoldiers:GetIcon()return{7,12}end;function b_Goal_DestroySoldiers:Reset()self.SaveAmount=
nil end
Core:RegisterBehavior(b_Goal_DestroySoldiers)
function Goal_EntityDistance(...)return b_Goal_EntityDistance:new(...)end
b_Goal_EntityDistance={Name="Goal_EntityDistance",Description={en="Goal: Distance between two entities",de="Ziel: Zwei Entities sollen zueinander eine Entfernung über- oder unterschreiten."},Parameter={{ParameterType.ScriptName,en="Entity 1",de="Entity 1"},{ParameterType.ScriptName,en="Entity 2",de="Entity 2"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Distance",de="Entfernung"}}}
function b_Goal_EntityDistance:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_EntityDistance:AddParameter(Otbx_3g,XRg)
if(Otbx_3g==0)then self.Entity1=XRg elseif(Otbx_3g==1)then
self.Entity2=XRg elseif(Otbx_3g==2)then self.bRelSmallerThan=XRg=="<"elseif(Otbx_3g==3)then
self.Distance=XRg*1 end end
function b_Goal_EntityDistance:CustomFunction(Q7c8C2T)
if Logic.IsEntityDestroyed(self.Entity1)or
Logic.IsEntityDestroyed(self.Entity2)then return false end;local Gz=GetID(self.Entity1)local XfMQy=GetID(self.Entity2)
local mu_2r=Logic.CheckEntitiesDistance(Gz,XfMQy,self.Distance)if
(self.bRelSmallerThan and mu_2r)or(not self.bRelSmallerThan and
not mu_2r)then return true end end
function b_Goal_EntityDistance:GetCustomData(Es)local c={}if Es==2 then table.insert(c,">")
table.insert(c,"<")else assert(false)end;return c end
function b_Goal_EntityDistance:DEBUG(C)
if not IsExisting(self.Entity1)or not
IsExisting(self.Entity2)then
dbg(""..C.Identifier..
" "..self.Name..
": At least 1 of the entities for distance check don't exist!")return true end;return false end;Core:RegisterBehavior(b_Goal_EntityDistance)function Goal_KnightDistance(...)return
b_Goal_KnightDistance:new(...)end
b_Goal_KnightDistance={Name="Goal_KnightDistance",Description={en="Goal: Bring the knight close to a given entity",de="Ziel: Bringe den Ritter nah an eine bestimmte Entität"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.ScriptName,en="Target",de="Ziel"}}}
function b_Goal_KnightDistance:GetGoalTable()return
{Objective.Distance,Logic.GetKnightID(self.PlayerID),self.Target,2500,true}end
function b_Goal_KnightDistance:AddParameter(o0Xe6nHM,ulAVnjc)
if(o0Xe6nHM==0)then self.PlayerID=ulAVnjc*1 elseif(
o0Xe6nHM==1)then self.Target=ulAVnjc end end;Core:RegisterBehavior(b_Goal_KnightDistance)function Goal_UnitsOnTerritory(...)return
b_Goal_UnitsOnTerritory:new(...)end
b_Goal_UnitsOnTerritory={Name="Goal_UnitsOnTerritory",Description={en="Goal: Place a certain amount of units on a territory",de="Ziel: Platziere eine bestimmte Anzahl Einheiten auf einem Gebiet"},Parameter={{ParameterType.TerritoryNameWithUnknown,en="Territory",de="Territorium"},{ParameterType.Custom,en="Player",de="Spieler"},{ParameterType.Custom,en="Category",de="Kategorie"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Number of units",de="Anzahl Einheiten"}}}
function b_Goal_UnitsOnTerritory:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_UnitsOnTerritory:AddParameter(zF6Bw,zuKqH)
if(zF6Bw==0)then
self.TerritoryID=tonumber(zuKqH)if self.TerritoryID==nil then
self.TerritoryID=GetTerritoryIDByName(zuKqH)end elseif(zF6Bw==1)then
self.PlayerID=tonumber(zuKqH)*1 elseif(zF6Bw==2)then self.Category=zuKqH elseif(zF6Bw==3)then
self.bRelSmallerThan=(
tostring(zuKqH)=="true"or tostring(zuKqH)=="<")elseif(zF6Bw==4)then self.NumberOfUnits=zuKqH*1 end end
function b_Goal_UnitsOnTerritory:CustomFunction(litdqp)
local r=GetEntitiesOfCategoryInTerritory(self.PlayerID,EntityCategories[self.Category],self.TerritoryID)
if
self.bRelSmallerThan==false and#r>=self.NumberOfUnits then return true elseif
self.bRelSmallerThan==true and#r<self.NumberOfUnits then return true end end
function b_Goal_UnitsOnTerritory:GetCustomData(n)local uSzWLeSi={}
if n==1 then
table.insert(uSzWLeSi,-1)
for phUBXWJ9=1,8 do table.insert(uSzWLeSi,phUBXWJ9)end elseif n==2 then for Qgtt7,yTthTeWK in pairs(EntityCategories)do
if not string.find(Qgtt7,"^G_")and
Qgtt7 ~="SheepPasture"then table.insert(uSzWLeSi,Qgtt7)end end
table.sort(uSzWLeSi)elseif n==3 then table.insert(uSzWLeSi,">=")
table.insert(uSzWLeSi,"<")else assert(false)end;return uSzWLeSi end
function b_Goal_UnitsOnTerritory:DEBUG(pG)
local um_kO={Logic.GetTerritories()}
if

tonumber(self.TerritoryID)==nil or self.TerritoryID<0 or not Inside(self.TerritoryID,um_kO)then
dbg(""..pG.Identifier..
" "..self.Name..": got an invalid territoryID!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<0 or self.PlayerID>8 then
dbg(""..pG.Identifier.." "..self.Name..
": got an invalid playerID!")return true elseif not EntityCategories[self.Category]then
dbg(""..
pG.Identifier.." "..self.Name..
": got an invalid entity category!")return true elseif tonumber(self.NumberOfUnits)==nil or
self.NumberOfUnits<0 then
dbg(""..pG.Identifier.." "..
self.Name..": amount is negative or nil!")return true end;return false end;Core:RegisterBehavior(b_Goal_UnitsOnTerritory)function Goal_ActivateBuff(...)return
b_Goal_ActivateBuff:new(...)end
b_Goal_ActivateBuff={Name="Goal_ActivateBuff",Description={en="Goal: Activate a buff",de="Ziel: Aktiviere einen Buff"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Buff",de="Buff"}}}
function b_Goal_ActivateBuff:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_ActivateBuff:AddParameter(ngCGBaF,A8TTTd8)
if(ngCGBaF==0)then self.PlayerID=A8TTTd8*1 elseif
(ngCGBaF==1)then self.BuffName=A8TTTd8;self.Buff=Buffs[A8TTTd8]end end
function b_Goal_ActivateBuff:CustomFunction(yGa)
if
not yGa.QuestDescription or yGa.QuestDescription==""then local f8jh=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
local OLzzUp=(f8jh=="de"and
"BONUS AKTIVIEREN{cr}{cr}")or"ACTIVATE BUFF{cr}{cr}"
local VlN={["Buff_Spice"]={de="Salz",en="Salt"},["Buff_Colour"]={de="Farben",en="Color"},["Buff_Entertainers"]={de="Entertainer",en="Entertainer"},["Buff_FoodDiversity"]={de="Vielfältige Nahrung",en="Food diversity"},["Buff_ClothesDiversity"]={de="Vielfältige Kleidung",en="Clothes diversity"},["Buff_HygieneDiversity"]={de="Vielfältige Reinigung",en="Hygiene diversity"},["Buff_EntertainmentDiversity"]={de="Vielfältige Unterhaltung",en="Entertainment diversity"},["Buff_Sermon"]={de="Predigt",en="Sermon"},["Buff_Festival"]={de="Fest",en="Festival"},["Buff_ExtraPayment"]={de="Sonderzahlung",en="Extra payment"},["Buff_HighTaxes"]={de="Hohe Steuern",en="High taxes"},["Buff_NoPayment"]={de="Kein Sold",en="No payment"},["Buff_NoTaxes"]={de="Keine Steuern",en="No taxes"}}
if g_GameExtraNo>=1 then VlN["Buff_Gems"]={de="Edelsteine",en="Gems"}
VlN["Buff_MusicalInstrument"]={de="Musikinstrumente",en="Musical instruments"}VlN["Buff_Olibanum"]={de="Weihrauch",en="Olibanum"}end
local r="{center}"..OLzzUp..VlN[self.BuffName][f8jh]Core:ChangeCustomQuestCaptionText(r,yGa)end;local j4bdRB6o=Logic.GetBuff(self.PlayerID,self.Buff)if j4bdRB6o and
j4bdRB6o~=0 then return true end end
function b_Goal_ActivateBuff:GetCustomData(mhEYg)local rUJN6={}
if mhEYg==1 then
rUJN6={"Buff_Spice","Buff_Colour","Buff_Entertainers","Buff_FoodDiversity","Buff_ClothesDiversity","Buff_HygieneDiversity","Buff_EntertainmentDiversity","Buff_Sermon","Buff_Festival","Buff_ExtraPayment","Buff_HighTaxes","Buff_NoPayment","Buff_NoTaxes"}
if g_GameExtraNo>=1 then table.insert(rUJN6,"Buff_Gems")
table.insert(rUJN6,"Buff_MusicalInstrument")table.insert(rUJN6,"Buff_Olibanum")end;table.sort(rUJN6)else assert(false)end;return rUJN6 end
function b_Goal_ActivateBuff:GetIcon()
local cYH30J={[Buffs.Buff_Spice]="Goods.G_Salt",[Buffs.Buff_Colour]="Goods.G_Dye",[Buffs.Buff_Entertainers]="Entities.U_Entertainer_NA_FireEater",[Buffs.Buff_FoodDiversity]="Needs.Nutrition",[Buffs.Buff_ClothesDiversity]="Needs.Clothes",[Buffs.Buff_HygieneDiversity]="Needs.Hygiene",[Buffs.Buff_EntertainmentDiversity]="Needs.Entertainment",[Buffs.Buff_Sermon]="Technologies.R_Sermon",[Buffs.Buff_Festival]="Technologies.R_Festival",[Buffs.Buff_ExtraPayment]={1,8},[Buffs.Buff_HighTaxes]={1,6},[Buffs.Buff_NoPayment]={1,8},[Buffs.Buff_NoTaxes]={1,6}}
if g_GameExtraNo and g_GameExtraNo>=1 then
cYH30J[Buffs.Buff_Gems]="Goods.G_Gems"
cYH30J[Buffs.Buff_MusicalInstrument]="Goods.G_MusicalInstrument"cYH30J[Buffs.Buff_Olibanum]="Goods.G_Olibanum"end;return cYH30J[self.Buff]end
function b_Goal_ActivateBuff:DEBUG(VR)
if not self.Buff then
dbg(""..VR.Identifier..
" "..self.Name..": buff '"..self.BuffName..
"' does not exist!")return true elseif
not tonumber(self.PlayerID)or self.PlayerID<1 or self.PlayerID>8 then
dbg(""..VR.Identifier.." "..self.Name..
": got an invalid playerID!")return true end;return false end;Core:RegisterBehavior(b_Goal_ActivateBuff)function Goal_BuildRoad(...)return
b_Goal_BuildRoad:new(...)end
b_Goal_BuildRoad={Name="Goal_BuildRoad",Description={en="Goal: Connect two points with a street or a road",de="Ziel: Verbinde zwei Punkte mit einer Strasse oder einem Weg."},Parameter={{ParameterType.ScriptName,en="Entity 1",de="Entity 1"},{ParameterType.ScriptName,en="Entity 2",de="Entity 2"},{ParameterType.Custom,en="Only roads",de="Nur Strassen"}}}
function b_Goal_BuildRoad:GetGoalTable()return
{Objective.BuildRoad,{GetID(self.Entity1),GetID(self.Entity2),false,0,self.bRoadsOnly}}end
function b_Goal_BuildRoad:AddParameter(pyzkzd,ksDuO71)
if(pyzkzd==0)then self.Entity1=ksDuO71 elseif(pyzkzd==1)then
self.Entity2=ksDuO71 elseif(pyzkzd==2)then
self.bRoadsOnly=AcceptAlternativeBoolean(ksDuO71)end end;function b_Goal_BuildRoad:GetCustomData(BAy)local tTCbo2
if BAy==2 then tTCbo2={"true","false"}end;return tTCbo2 end
function b_Goal_BuildRoad:DEBUG(p)
if
not IsExisting(self.Entity1)or
not IsExisting(self.Entity2)then
dbg(""..p.Identifier.." "..
self.Name..": first or second entity does not exist!")return true end;return false end;Core:RegisterBehavior(b_Goal_BuildRoad)function Goal_BuildWall(...)return
b_Goal_BuildWall:new(...)end
b_Goal_BuildWall={Name="Goal_BuildWall",Description={en="Goal: Build a wall between 2 positions bo stop the movement of an (hostile) player.",de="Ziel: Baue eine Mauer zwischen 2 Punkten, die die Bewegung eines (feindlichen) Spielers zwischen den Punkten verhindert."},Parameter={{ParameterType.PlayerID,en="Enemy",de="Feind"},{ParameterType.ScriptName,en="Entity 1",de="Entity 1"},{ParameterType.ScriptName,en="Entity 2",de="Entity 2"}}}function b_Goal_BuildWall:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_BuildWall:AddParameter(UNyk,cG0)if(
UNyk==0)then self.PlayerID=cG0*1 elseif(UNyk==1)then self.EntityName1=cG0 elseif(UNyk==2)then
self.EntityName2=cG0 end end
function b_Goal_BuildWall:CustomFunction(kzTZ7)local f8SnhE4T=GetID(self.EntityName1)
local aascxP=GetID(self.EntityName2)if not IsExisting(f8SnhE4T)then return false end;if not
IsExisting(aascxP)then return false end
local eSG8f8ru,w2yJAi,lH1c=Logic.EntityGetPos(f8SnhE4T)if Logic.IsBuilding(f8SnhE4T)==1 then
eSG8f8ru,w2yJAi=Logic.GetBuildingApproachPosition(f8SnhE4T)end
local CHS=Logic.GetPlayerSectorAtPosition(self.PlayerID,eSG8f8ru,w2yJAi)local eSG8f8ru,w2yJAi,lH1c=Logic.EntityGetPos(aascxP)if
Logic.IsBuilding(aascxP)==1 then
eSG8f8ru,w2yJAi=Logic.GetBuildingApproachPosition(aascxP)end
local fQdTWIXs=Logic.GetPlayerSectorAtPosition(self.PlayerID,eSG8f8ru,w2yJAi)if CHS~=fQdTWIXs then return true end;return nil end
function b_Goal_BuildWall:GetMsgKey()return"Quest_Create_Wall"end;function b_Goal_BuildWall:GetIcon()return{3,9}end
function b_Goal_BuildWall:DEBUG(QG)
if
not
IsExisting(self.EntityName1)or not IsExisting(self.EntityName2)then
dbg(""..QG.Identifier..
" "..self.Name..": first or second entity does not exist!")return true elseif
not tonumber(self.PlayerID)or self.PlayerID<1 or self.PlayerID>8 then
dbg(""..QG.Identifier.." "..self.Name..
": got an invalid playerID!")return true end
if
GetDiplomacyState(QG.ReceivingPlayer,self.PlayerID)>-1 and not self.WarningPrinted then
warn(""..QG.Identifier..

" "..self.Name..": player %d is neighter enemy or unknown to quest receiver!")self.WarningPrinted=true end;return false end;Core:RegisterBehavior(b_Goal_BuildWall)function Goal_Claim(...)return
b_Goal_Claim:new(...)end
b_Goal_Claim={Name="Goal_Claim",Description={en="Goal: Claim a territory",de="Ziel: Erobere ein Territorium"},Parameter={{ParameterType.TerritoryName,en="Territory",de="Territorium"}}}function b_Goal_Claim:GetGoalTable()
return{Objective.Claim,1,self.TerritoryID}end
function b_Goal_Claim:AddParameter(d78,C6pS)
if(d78 ==0)then
self.TerritoryID=tonumber(C6pS)if not self.TerritoryID then
self.TerritoryID=GetTerritoryIDByName(C6pS)end end end
function b_Goal_Claim:GetMsgKey()return"Quest_Claim_Territory"end;Core:RegisterBehavior(b_Goal_Claim)function Goal_ClaimXTerritories(...)return
b_Goal_ClaimXTerritories:new(...)end
b_Goal_ClaimXTerritories={Name="Goal_ClaimXTerritories",Description={en="Goal: Claim the given number of territories, all player territories are counted",de="Ziel: Erobere die angegebene Anzahl Territorien, alle spielereigenen Territorien werden gezählt"},Parameter={{ParameterType.Number,en="Territories",de="Territorien"}}}
function b_Goal_ClaimXTerritories:GetGoalTable()return
{Objective.Claim,2,self.TerritoriesToClaim}end;function b_Goal_ClaimXTerritories:AddParameter(GwH,O)
if(GwH==0)then self.TerritoriesToClaim=O*1 end end;function b_Goal_ClaimXTerritories:GetMsgKey()return
"Quest_Claim_Territory"end
Core:RegisterBehavior(b_Goal_ClaimXTerritories)
function Goal_Create(...)return b_Goal_Create:new(...)end
b_Goal_Create={Name="Goal_Create",Description={en="Goal: Create Buildings/Units on a specified territory",de="Ziel: Erstelle Einheiten/Gebäude auf einem bestimmten Territorium."},Parameter={{ParameterType.Entity,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.TerritoryNameWithUnknown,en="Territory",de="Territorium"}}}
function b_Goal_Create:GetGoalTable()return
{Objective.Create,assert(Entities[self.EntityName]),self.Amount,self.TerritoryID}end
function b_Goal_Create:AddParameter(sbuS4,Rrfir0)
if(sbuS4 ==0)then self.EntityName=Rrfir0 elseif(sbuS4 ==1)then self.Amount=
Rrfir0*1 elseif(sbuS4 ==2)then self.TerritoryID=tonumber(Rrfir0)
if not
self.TerritoryID then self.TerritoryID=GetTerritoryIDByName(Rrfir0)end end end
function b_Goal_Create:GetMsgKey()
return


Logic.IsEntityTypeInCategory(Entities[self.EntityName],EntityCategories.AttackableBuilding)==1 and"Quest_Create_Building"or"Quest_Create_Unit"end;Core:RegisterBehavior(b_Goal_Create)function Goal_Produce(...)return
b_Goal_Produce:new(...)end
b_Goal_Produce={Name="Goal_Produce",Description={en="Goal: Produce an amount of goods",de="Ziel: Produziere eine Anzahl einer bestimmten Ware."},Parameter={{ParameterType.RawGoods,en="Type of good",de="Ressourcentyp"},{ParameterType.Number,en="Amount of good",de="Anzahl der Ressource"}}}
function b_Goal_Produce:GetGoalTable()
local lXr=Logic.GetGoodTypeID(self.GoodTypeName)return{Objective.Produce,lXr,self.GoodAmount}end
function b_Goal_Produce:AddParameter(hz,f)if(hz==0)then self.GoodTypeName=f elseif(hz==1)then
self.GoodAmount=f*1 end end;function b_Goal_Produce:GetMsgKey()return"Quest_Produce"end
Core:RegisterBehavior(b_Goal_Produce)
function Goal_GoodAmount(...)return b_Goal_GoodAmount:new(...)end
b_Goal_GoodAmount={Name="Goal_GoodAmount",Description={en="Goal: Obtain an amount of goods - either by trading or producing them",de="Ziel: Beschaffe eine Anzahl Waren - entweder durch Handel oder durch eigene Produktion."},Parameter={{ParameterType.Custom,en="Type of good",de="Warentyp"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.Custom,en="Relation",de="Relation"}}}
function b_Goal_GoodAmount:GetGoalTable()
local knCGg=Logic.GetGoodTypeID(self.GoodTypeName)
return{Objective.Produce,knCGg,self.GoodAmount,self.bRelSmallerThan}end
function b_Goal_GoodAmount:AddParameter(UPf,amxXn)
if(UPf==0)then self.GoodTypeName=amxXn elseif(UPf==1)then self.GoodAmount=
amxXn*1 elseif(UPf==2)then
self.bRelSmallerThan=amxXn=="<"or tostring(amxXn)=="true"end end
function b_Goal_GoodAmount:GetCustomData(CSwsYPyj)local I9I={}
if CSwsYPyj==0 then for aB,BiUZ8vx4 in pairs(Goods)do if string.find(aB,"^G_")then
table.insert(I9I,aB)end end
table.sort(I9I)elseif CSwsYPyj==2 then table.insert(I9I,">=")
table.insert(I9I,"<")else assert(false)end;return I9I end;Core:RegisterBehavior(b_Goal_GoodAmount)function Goal_SatisfyNeed(...)return
b_Goal_SatisfyNeed:new(...)end
b_Goal_SatisfyNeed={Name="Goal_SatisfyNeed",Description={en="Goal: Satisfy a need",de="Ziel: Erfuelle ein Beduerfnis"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Need,en="Need",de="Beduerfnis"}}}
function b_Goal_SatisfyNeed:GetGoalTable()return
{Objective.SatisfyNeed,self.PlayerID,assert(Needs[self.Need])}end
function b_Goal_SatisfyNeed:AddParameter(v,W8dN)if(v==0)then self.PlayerID=W8dN*1 elseif(v==1)then
self.Need=W8dN end end
function b_Goal_SatisfyNeed:GetMsgKey()
local eL={[Needs.Clothes]="Quest_SatisfyNeed_Clothes",[Needs.Entertainment]="Quest_SatisfyNeed_Entertainment",[Needs.Nutrition]="Quest_SatisfyNeed_Food",[Needs.Hygiene]="Quest_SatisfyNeed_Hygiene",[Needs.Medicine]="Quest_SatisfyNeed_Medicine"}local U4G6f=eL[Needs[self.Need]]if U4G6f then return U4G6f end end;Core:RegisterBehavior(b_Goal_SatisfyNeed)function Goal_SettlersNumber(...)return
b_Goal_SettlersNumber:new(...)end
b_Goal_SettlersNumber={Name="Goal_SettlersNumber",Description={en="Goal: Get a given amount of settlers",de="Ziel: Erreiche eine bestimmte Anzahl Siedler."},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"}}}
function b_Goal_SettlersNumber:GetGoalTable()return
{Objective.SettlersNumber,1,self.SettlersAmount}end;function b_Goal_SettlersNumber:AddParameter(gmhVDH,a)
if(gmhVDH==0)then self.SettlersAmount=a*1 end end;function b_Goal_SettlersNumber:GetMsgKey()return
"Quest_NumberSettlers"end
Core:RegisterBehavior(b_Goal_SettlersNumber)
function Goal_Spouses(...)return b_Goal_Spouses:new(...)end
b_Goal_Spouses={Name="Goal_Spouses",Description={en="Goal: Get a given amount of spouses",de="Ziel: Erreiche eine bestimmte Ehefrauenanzahl"},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"}}}function b_Goal_Spouses:GetGoalTable()
return{Objective.Spouses,self.SpousesAmount}end
function b_Goal_Spouses:AddParameter(NesXI,OZ8oHL)if
(NesXI==0)then self.SpousesAmount=OZ8oHL*1 end end
function b_Goal_Spouses:GetMsgKey()return"Quest_NumberSpouses"end;Core:RegisterBehavior(b_Goal_Spouses)function Goal_SoldierCount(...)return
b_Goal_SoldierCount:new(...)end
b_Goal_SoldierCount={Name="Goal_SoldierCount",Description={en="Goal: Create a specified number of soldiers",de="Ziel: Erreiche eine Anzahl grösser oder kleiner der angegebenen Menge Soldaten."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Number of soldiers",de="Anzahl Soldaten"}}}
function b_Goal_SoldierCount:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_SoldierCount:AddParameter(sa,hT)
if(sa==0)then self.PlayerID=hT*1 elseif(sa==1)then
self.bRelSmallerThan=
tostring(hT)=="true"or tostring(hT)=="<"elseif(sa==2)then self.NumberOfUnits=hT*1 end end
function b_Goal_SoldierCount:CustomFunction(zICb5)
if not zICb5.QuestDescription or
zICb5.QuestDescription==""then
local kJZlA=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
local blNC=(kJZlA=="de"and"SOLDATENANZAHL {cr}Partei: ")or
"SOLDIERS {cr}faction: "local l=tostring(self.bRelSmallerThan)
local y9={["true"]={de="Weniger als",en="Less than"},["false"]={de="Mindestens",en="At least"}}local z=GetPlayerName(self.PlayerID)or""
local MjtdB7KS="{center}"..blNC..z..

"{cr}{cr}"..y9[l][kJZlA].." "..self.NumberOfUnits;Core:ChangeCustomQuestCaptionText(MjtdB7KS,zICb5)end;local HB_RPF=Logic.GetCurrentSoldierCount(self.PlayerID)
if
(
self.bRelSmallerThan and HB_RPF<self.NumberOfUnits)then return true elseif
(not self.bRelSmallerThan and HB_RPF>=self.NumberOfUnits)then return true end;return nil end
function b_Goal_SoldierCount:GetCustomData(_M_Cmn9C)local GZQBW7r7={}
if _M_Cmn9C==1 then
table.insert(GZQBW7r7,">=")table.insert(GZQBW7r7,"<")else assert(false)end;return GZQBW7r7 end;function b_Goal_SoldierCount:GetIcon()return{7,11}end;function b_Goal_SoldierCount:GetMsgKey()return
"Quest_Create_Unit"end
function b_Goal_SoldierCount:DEBUG(VHBi5G)
if
tonumber(self.NumberOfUnits)==nil or self.NumberOfUnits<0 then
dbg(""..

VHBi5G.Identifier.." "..self.Name..": amount can not be below 0!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
dbg(""..VHBi5G.Identifier.." "..self.Name..
": got an invalid playerID!")return true end;return false end;Core:RegisterBehavior(b_Goal_SoldierCount)function Goal_KnightTitle(...)return
b_Goal_KnightTitle:new(...)end
b_Goal_KnightTitle={Name="Goal_KnightTitle",Description={en="Goal: Reach a specified knight title",de="Ziel: Erreiche einen vorgegebenen Titel"},Parameter={{ParameterType.Custom,en="Knight title",de="Titel"}}}
function b_Goal_KnightTitle:GetGoalTable()return
{Objective.KnightTitle,assert(KnightTitles[self.KnightTitle])}end;function b_Goal_KnightTitle:AddParameter(Z1D6NL,XAy)
if(Z1D6NL==0)then self.KnightTitle=XAy end end;function b_Goal_KnightTitle:GetMsgKey()return
"Quest_KnightTitle"end
function b_Goal_KnightTitle:GetCustomData(zxyLTb)return
{"Knight","Mayor","Baron","Earl","Marquees","Duke","Archduke"}end;Core:RegisterBehavior(b_Goal_KnightTitle)function Goal_Festivals(...)return
b_Goal_Festivals:new(...)end
b_Goal_Festivals={Name="Goal_Festivals",Description={en="Goal: The player has to start the given number of festivals.",de="Ziel: Der Spieler muss eine gewisse Anzahl Feste gestartet haben."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Number,en="Number of festivals",de="Anzahl Feste"}}}function b_Goal_Festivals:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_Festivals:AddParameter(rhMWaiC,pM)
if
rhMWaiC==0 then self.PlayerID=tonumber(pM)else
assert(rhMWaiC==1,"Error in "..self.Name..
": AddParameter: Index is invalid.")self.NeededFestivals=tonumber(pM)end end
function b_Goal_Festivals:CustomFunction(i)
if
not i.QuestDescription or i.QuestDescription==""then local M=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
local Ucy5ca=(M=="de"and
"FESTE FEIERN {cr}{cr}Partei: ")or"HOLD PARTIES {cr}{cr}faction: "
local ycyK=(M=="de"and"Anzahl: ")or"Amount: "local Yfm6hogh=GetPlayerName(self.PlayerID)or""
local T6eti="{center}"..
Ucy5ca..
Yfm6hogh.."{cr}{cr}"..ycyK.." "..self.NeededFestivals;Core:ChangeCustomQuestCaptionText(T6eti,i)end
if Logic.GetStoreHouse(self.PlayerID)==0 then return false end
local k={Logic.GetPlayerEntities(self.PlayerID,Entities.B_TableBeer,5,0)}local hr=0
for z7j=2,#k do local CGz=k[z7j]
if
Logic.GetIndexOnOutStockByGoodType(CGz,Goods.G_Beer)~=-1 then
local aukN3ZWX=Logic.GetAmountOnOutStockByGoodType(CGz,Goods.G_Beer)hr=hr+aukN3ZWX end end
if not self.FestivalStarted and hr>0 then self.FestivalStarted=true
self.FestivalCounter=(
self.FestivalCounter and self.FestivalCounter+1)or 1;if self.FestivalCounter>=self.NeededFestivals then self.FestivalCounter=nil
return true end elseif hr==0 then
self.FestivalStarted=false end end
function b_Goal_Festivals:DEBUG(eSCsri5)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
dbg(eSCsri5.Identifier..": Error in "..self.Name..
": Player "..self.PlayerID.." is dead :-(")return true elseif
GetPlayerCategoryType(self.PlayerID)~=PlayerCategories.City then
dbg(eSCsri5.Identifier..": Error in "..self.Name..
":  Player "..self.PlayerID.." is no city")return true elseif self.NeededFestivals<0 then
dbg(eSCsri5.Identifier..": Error in "..self.Name..
": Number of Festivals is negative")return true end;return false end
function b_Goal_Festivals:Reset()self.FestivalCounter=nil;self.FestivalStarted=nil end;function b_Goal_Festivals:GetIcon()return{4,15}end
Core:RegisterBehavior(b_Goal_Festivals)
function Goal_Capture(...)return b_Goal_Capture:new(...)end
b_Goal_Capture={Name="Goal_Capture",Description={en="Goal: Capture a cart.",de="Ziel: Ein Karren muss erobert werden."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}function b_Goal_Capture:GetGoalTable()
return{Objective.Capture,1,{self.ScriptName}}end
function b_Goal_Capture:AddParameter(_g10f_,r4cyFP)if
(_g10f_==0)then self.ScriptName=r4cyFP end end
function b_Goal_Capture:GetMsgKey()local fcSy4_k0=GetID(self.ScriptName)
if
Logic.IsEntityAlive(fcSy4_k0)then fcSy4_k0=Logic.GetEntityType(fcSy4_k0)
if
fcSy4_k0 and fcSy4_k0 ~=0 then
if
Logic.IsEntityTypeInCategory(fcSy4_k0,EntityCategories.AttackableMerchant)==1 then return"Quest_Capture_Cart"elseif
Logic.IsEntityTypeInCategory(fcSy4_k0,EntityCategories.SiegeEngine)==1 then return"Quest_Capture_SiegeEngine"elseif


Logic.IsEntityTypeInCategory(fcSy4_k0,EntityCategories.Worker)==1 or
Logic.IsEntityTypeInCategory(fcSy4_k0,EntityCategories.Spouse)==1 or
Logic.IsEntityTypeInCategory(fcSy4_k0,EntityCategories.Hero)==1 then return"Quest_Capture_VIPOfPlayer"end end end end;Core:RegisterBehavior(b_Goal_Capture)function Goal_CaptureType(...)return
b_Goal_CaptureType:new(...)end
b_Goal_CaptureType={Name="Goal_CaptureType",Description={en="Goal: Capture specified entity types",de="Ziel: Nimm bestimmte Entitätstypen gefangen"},Parameter={{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function b_Goal_CaptureType:GetGoalTable()return
{Objective.Capture,2,Entities[self.EntityName],self.Amount,self.PlayerID}end
function b_Goal_CaptureType:AddParameter(TrC17,MEwJPiqM)
if(TrC17 ==0)then self.EntityName=MEwJPiqM elseif
(TrC17 ==1)then self.Amount=MEwJPiqM*1 elseif(TrC17 ==2)then self.PlayerID=MEwJPiqM*1 end end
function b_Goal_CaptureType:GetCustomData(jHIxW_)local gny={}
if jHIxW_==0 then
for KabKdEUu,oQ8AOvfn in pairs(Entities)do
if

string.find(KabKdEUu,"^U_.+Cart")or
Logic.IsEntityTypeInCategory(oQ8AOvfn,EntityCategories.AttackableMerchant)==1 then table.insert(gny,KabKdEUu)end end;table.sort(gny)elseif jHIxW_==2 then
for m=0,8 do table.insert(gny,m)end else assert(false)end;return gny end
function b_Goal_CaptureType:GetMsgKey()local cX88nonB=self.EntityName
if
Logic.IsEntityTypeInCategory(cX88nonB,EntityCategories.AttackableMerchant)==1 then return"Quest_Capture_Cart"elseif
Logic.IsEntityTypeInCategory(cX88nonB,EntityCategories.SiegeEngine)==1 then return"Quest_Capture_SiegeEngine"elseif


Logic.IsEntityTypeInCategory(cX88nonB,EntityCategories.Worker)==1 or
Logic.IsEntityTypeInCategory(cX88nonB,EntityCategories.Spouse)==1 or
Logic.IsEntityTypeInCategory(cX88nonB,EntityCategories.Hero)==1 then return"Quest_Capture_VIPOfPlayer"end end;Core:RegisterBehavior(b_Goal_CaptureType)function Goal_Protect(...)return
b_Goal_Protect:new(...)end
b_Goal_Protect={Name="Goal_Protect",Description={en="Goal: Protect an entity (entity needs a script name",de="Ziel: Beschütze eine Entität (Entität benötigt einen Skriptnamen)"},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}function b_Goal_Protect:GetGoalTable()
return{Objective.Protect,{self.ScriptName}}end
function b_Goal_Protect:AddParameter(kkWQP4,E4F)if
(kkWQP4 ==0)then self.ScriptName=E4F end end
function b_Goal_Protect:GetMsgKey()
if Logic.IsEntityAlive(self.ScriptName)then
local E=GetID(self.ScriptName)
if E and E~=0 then E=Logic.GetEntityType(E)
if E and E~=0 then
if
Logic.IsEntityTypeInCategory(E,EntityCategories.AttackableBuilding)==1 then return"Quest_Protect_Building"elseif
Logic.IsEntityTypeInCategory(E,EntityCategories.SpecialBuilding)==1 then
local IGef7Hc5={[PlayerCategories.City]="Quest_Protect_City",[PlayerCategories.Cloister]="Quest_Protect_Cloister",[PlayerCategories.Village]="Quest_Protect_Village"}
local RY1=GetPlayerCategoryType(Logic.EntityGetPlayer(GetID(self.ScriptName)))
if RY1 then local bkV=IGef7Hc5[RY1]if bkV then return bkV end end;return"Quest_Protect_Building"elseif
Logic.IsEntityTypeInCategory(E,EntityCategories.Hero)==1 then return"Quest_Protect_Knight"elseif
Logic.IsEntityTypeInCategory(E,EntityCategories.AttackableMerchant)==1 then return"Quest_Protect_Cart"end end end end;return"Quest_Protect"end;Core:RegisterBehavior(b_Goal_Protect)function Goal_Refill(...)return
b_Goal_Refill:new(...)end
b_Goal_Refill={Name="Goal_Refill",Description={en="Goal: Refill an object using a geologist",de="Ziel: Eine Mine soll durch einen Geologen wieder aufgefuellt werden."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}},RequiresExtraNo=1}function b_Goal_Refill:GetGoalTable()return
{Objective.Refill,{GetID(self.ScriptName)}}end;function b_Goal_Refill:GetIcon()return
{8,1,1}end;function b_Goal_Refill:AddParameter(VOG,r8MEhbdT)if(VOG==0)then
self.ScriptName=r8MEhbdT end end
if
g_GameExtraNo>0 then Core:RegisterBehavior(b_Goal_Refill)end
function Goal_ResourceAmount(...)return b_Goal_ResourceAmount:new(...)end
b_Goal_ResourceAmount={Name="Goal_ResourceAmount",Description={en="Goal: Reach a specified amount of resources in a doodad",de="Ziel: In einer Mine soll weniger oder mehr als eine angegebene Anzahl an Rohstoffen sein."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Amount",de="Menge"}}}
function b_Goal_ResourceAmount:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_ResourceAmount:AddParameter(klSf0ZT5,t85a4rt)
if(klSf0ZT5 ==0)then self.ScriptName=t85a4rt elseif
(klSf0ZT5 ==1)then self.bRelSmallerThan=t85a4rt=="<"elseif(klSf0ZT5 ==2)then
self.Amount=t85a4rt*1 end end
function b_Goal_ResourceAmount:CustomFunction(OfQcD)local Yj=GetID(self.ScriptName)
if

Yj and Yj~=0 and Logic.GetResourceDoodadGoodType(Yj)~=0 then local LvKdRh=Logic.GetResourceDoodadGoodAmount(Yj)
if(
self.bRelSmallerThan and LvKdRh<self.Amount)or
(not
self.bRelSmallerThan and LvKdRh>=self.Amount)then return true end end;return nil end
function b_Goal_ResourceAmount:GetCustomData(_D)local uYwYKAU={}
if _D==1 then
table.insert(uYwYKAU,">=")table.insert(uYwYKAU,"<")else assert(false)end;return uYwYKAU end
function b_Goal_ResourceAmount:DEBUG(mq)
if not IsExisting(self.ScriptName)then
dbg(""..

mq.Identifier.." "..self.Name..
": entity '"..self.ScriptName.."' does not exist!")return true elseif
tonumber(self.Amount)==nil or self.Amount<0 then
dbg(""..mq.Identifier..
" "..self.Name..": error at amount! (nil or below 0)")return true end;return false end;Core:RegisterBehavior(b_Goal_ResourceAmount)function Goal_InstantFailure()return
b_Goal_InstantFailure:new()end
b_Goal_InstantFailure={Name="Goal_InstantFailure",Description={en="Instant failure, the goal returns false.",de="Direkter Misserfolg, das Goal sendet false."}}
function b_Goal_InstantFailure:GetGoalTable()return{Objective.DummyFail}end;Core:RegisterBehavior(b_Goal_InstantFailure)function Goal_InstantSuccess()return
b_Goal_InstantSuccess:new()end
b_Goal_InstantSuccess={Name="Goal_InstantSuccess",Description={en="Instant success, the goal returns true.",de="Direkter Erfolg, das Goal sendet true."}}
function b_Goal_InstantSuccess:GetGoalTable()return{Objective.Dummy}end;Core:RegisterBehavior(b_Goal_InstantSuccess)function Goal_NoChange()return
b_Goal_NoChange:new()end
b_Goal_NoChange={Name="Goal_NoChange",Description={en="The quest state doesn't change. Use reward functions of other quests to change the state of this quest.",de="Der Questzustand wird nicht verändert. Ein Reward einer anderen Quest sollte den Zustand dieser Quest verändern."}}
function b_Goal_NoChange:GetGoalTable()return{Objective.NoChange}end;Core:RegisterBehavior(b_Goal_NoChange)function Goal_MapScriptFunction(...)return
b_Goal_MapScriptFunction:new(...)end
b_Goal_MapScriptFunction={Name="Goal_MapScriptFunction",Description={en="Goal: Calls a function within the global map script. Return 'true' means success, 'false' means failure and 'nil' doesn't change anything.",de="Ziel: Ruft eine Funktion im globalen Skript auf, die einen Wahrheitswert zurueckgibt. Rueckgabe 'true' gilt als erfuellt, 'false' als gescheitert und 'nil' ändert nichts."},Parameter={{ParameterType.Default,en="Function name",de="Funktionsname"}}}
function b_Goal_MapScriptFunction:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end;function b_Goal_MapScriptFunction:AddParameter(m7YIn,tYqOsEJ)
if(m7YIn==0)then self.FuncName=tYqOsEJ end end;function b_Goal_MapScriptFunction:CustomFunction(udoq)return
_G[self.FuncName](self,udoq)end
function b_Goal_MapScriptFunction:DEBUG(boTHtaG)
if
not self.FuncName or not _G[self.FuncName]then
dbg(""..

boTHtaG.Identifier.." "..
self.Name..": function '"..self.FuncName.."' does not exist!")return true end;return false end;Core:RegisterBehavior(b_Goal_MapScriptFunction)function Goal_CustomVariables(...)return
b_Goal_CustomVariables:new(...)end
b_Goal_CustomVariables={Name="Goal_CustomVariables",Description={en="Goal: A customised variable has to assume a certain value.",de="Ziel: Eine benutzerdefinierte Variable muss einen bestimmten Wert annehmen."},Parameter={{ParameterType.Default,en="Name of Variable",de="Variablenname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Default,en="Value or variable",de="Wert oder Variable"}}}
function b_Goal_CustomVariables:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_CustomVariables:AddParameter(zbQgT,duYPlVu)
if zbQgT==0 then self.VariableName=duYPlVu elseif zbQgT==1 then
self.Relation=duYPlVu elseif zbQgT==2 then local n5=tonumber(duYPlVu)n5=(n5 ~=nil and n5)or
tostring(duYPlVu)self.Value=n5 end end
function b_Goal_CustomVariables:CustomFunction()
if
_G["QSB_CustomVariables_"..self.VariableName]then
local zl5hfbAb=
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value]
if self.Relation=="=="then
if
_G["QSB_CustomVariables_"..self.VariableName]==zl5hfbAb then return true end elseif self.Relation=="~="then
if
_G["QSB_CustomVariables_"..self.VariableName]==zl5hfbAb then return true end elseif self.Relation=="<"then
if
_G["QSB_CustomVariables_"..self.VariableName]<zl5hfbAb then return true end elseif self.Relation=="<="then
if
_G["QSB_CustomVariables_"..self.VariableName]<=zl5hfbAb then return true end elseif self.Relation==">="then
if
_G["QSB_CustomVariables_"..self.VariableName]>=zl5hfbAb then return true end else if
_G["QSB_CustomVariables_"..self.VariableName]>zl5hfbAb then return true end end end;return nil end
function b_Goal_CustomVariables:GetCustomData(xVvJF)return{"==","~=","<=","<",">",">="}end
function b_Goal_CustomVariables:DEBUG(zsKRyBU)local Lukg={"==","~=","<=","<",">",">="}
local rkKj={true,false,nil}
if
not _G["QSB_CustomVariables_"..self.VariableName]then
dbg(zsKRyBU.Identifier.." "..self.Name..
": variable '"..self.VariableName.."' do not exist!")return true elseif not Inside(self.Relation,Lukg)then
dbg(zsKRyBU.Identifier.." "..
self.Name..": '"..
self.Relation.."' is an invalid relation!")return true end;return false end;Core:RegisterBehavior(b_Goal_CustomVariables)function Goal_Decide(...)return
b_Goal_Decide:new(...)end
b_Goal_Decide={Name="Goal_Decide",Description={en="Opens a Yes/No Dialog. Decision = Quest Result",de="Oeffnet einen Ja/Nein-Dialog. Die Entscheidung bestimmt das Quest-Ergebnis (ja=true, nein=false)."},Parameter={{ParameterType.Default,en="Text",de="Text"},{ParameterType.Default,en="Title",de="Titel"},{ParameterType.Custom,en="Button labels",de="Button Beschriftung"}}}function b_Goal_Decide:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_Decide:AddParameter(yAaxRZGY,_Tb)
if(
yAaxRZGY==0)then self.Text=_Tb elseif(yAaxRZGY==1)then self.Title=_Tb elseif
(yAaxRZGY==2)then self.Buttons=(_Tb=="Ok/Cancel")end end
function b_Goal_Decide:CustomFunction(BJRFwSz)
if
not IsBriefingActive or(IsBriefingActive and
IsBriefingActive()==false)then
if not self.LocalExecuted then if QSB.DialogActive then return end;QSB.DialogActive=true;local beAAh6T=(
self.Buttons and"true")or"nil"
self.LocalExecuted=true
local yUaD=[[
                Game.GameTimeSetFactor( GUI.GetPlayerID(), 0 )
                OpenRequesterDialog(%q,
                                    %q,
                                    "Game.GameTimeSetFactor( GUI.GetPlayerID(), 1 ); GUI.SendScriptCommand( 'QSB.DecisionWindowResult = true ')",
                                    %s ,
                                    "Game.GameTimeSetFactor( GUI.GetPlayerID(), 1 ); GUI.SendScriptCommand( 'QSB.DecisionWindowResult = false ')")
            ]]
local yUaD=string.format(yUaD,self.Text,"{center} "..self.Title,beAAh6T)Logic.ExecuteInLuaLocalState(yUaD)end;local C3MNkiZ=QSB.DecisionWindowResult;if C3MNkiZ~=nil then QSB.DecisionWindowResult=nil
QSB.DialogActive=false;return C3MNkiZ end end end;function b_Goal_Decide:Reset()self.LocalExecuted=nil end;function b_Goal_Decide:GetIcon()return
{4,12}end
function b_Goal_Decide:GetCustomData(Enu)if Enu==2 then return
{"Yes/No","Ok/Cancel"}end end;Core:RegisterBehavior(b_Goal_Decide)function Goal_TributeDiplomacy(...)return
b_Goal_TributeDiplomacy:new(...)end
b_Goal_TributeDiplomacy={Name="Goal_TributeDiplomacy",Description={en="Goal: AI requests periodical tribute for better Diplomacy",de="Ziel: Die KI fordert einen regelmässigen Tribut fuer bessere Diplomatie. Der Questgeber ist der fordernde Spieler."},Parameter={{ParameterType.Number,en="Amount",de="Menge"},{ParameterType.Number,en="Time till next peyment in seconds",de="Zeit bis zur Forderung in Sekunden"},{ParameterType.Number,en="Time to pay tribute in seconds",de="Zeit bis zur Zahlung in Sekunden"},{ParameterType.Default,en="Start Message for TributQuest",de="Startnachricht der Tributquest"},{ParameterType.Default,en="Success Message for TributQuest",de="Erfolgsnachricht der Tributquest"},{ParameterType.Default,en="Failure Message for TributQuest",de="Niederlagenachricht der Tributquest"},{ParameterType.Custom,en="Restart if failed to pay",de="Nicht-bezahlen beendet die Quest"}}}
function b_Goal_TributeDiplomacy:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_TributeDiplomacy:AddParameter(YJ31A6_,fChy5)
if(YJ31A6_==0)then self.Amount=fChy5*1 elseif
(YJ31A6_==1)then self.PeriodLength=fChy5*1 elseif(YJ31A6_==2)then self.TributTime=fChy5*1 elseif(
YJ31A6_==3)then self.StartMsg=fChy5 elseif(YJ31A6_==4)then self.SuccessMsg=fChy5 elseif
(YJ31A6_==5)then self.FailureMsg=fChy5 elseif(YJ31A6_==6)then
self.RestartAtFailure=AcceptAlternativeBoolean(fChy5)end end
function b_Goal_TributeDiplomacy:GetTributeQuest(DNPo4Wqt)
if not self.InternTributeQuest then
local S8Kb,UMeQ=QuestTemplate:New(
DNPo4Wqt.Identifier.."_TributeDiplomacyQuest",DNPo4Wqt.SendingPlayer,DNPo4Wqt.ReceivingPlayer,{{Objective.Deliver,{Goods.G_Gold,self.Amount}}},{{Triggers.Time,0}},self.TributTime,
nil,nil,nil,nil,true,true,nil,self.StartMsg,self.SuccessMsg,self.FailureMsg)self.InternTributeQuest=UMeQ;self.Time=Logic.GetTime()end end
function b_Goal_TributeDiplomacy:CheckTributeQuest(AGhdl3)
if self.InternTributeQuest and self.InternTributeQuest.State==
QuestState.Over and
not self.RestartQuest then
if
self.InternTributeQuest.Result~=QuestResult.Success then
SetDiplomacyState(AGhdl3.ReceivingPlayer,AGhdl3.SendingPlayer,DiplomacyStates.Enemy)if not self.RestartAtFailure then return false end else
SetDiplomacyState(AGhdl3.ReceivingPlayer,AGhdl3.SendingPlayer,DiplomacyStates.TradeContact)end;self.RestartQuest=true end end
function b_Goal_TributeDiplomacy:CheckTributePlayer(P32)
local xj1=Logic.GetStoreHouse(P32.SendingPlayer)
if(xj1 ==0 or Logic.IsEntityDestroyed(xj1))then
if

self.InternTributeQuest and self.InternTributeQuest.State==QuestState.Active then self.InternTributeQuest:Interrupt()end;return true end end
function b_Goal_TributeDiplomacy:TributQuestRestarter(rd)
if
self.InternTributeQuest and self.RestartQuest and
((Logic.GetTime()-self.Time)>=self.PeriodLength)then self.InternTributeQuest.Objectives[1].Completed=
nil;self.InternTributeQuest.Objectives[1].Data[3]=
nil;self.InternTributeQuest.Objectives[1].Data[4]=
nil;self.InternTributeQuest.Objectives[1].Data[5]=
nil;self.InternTributeQuest.Result=nil
self.InternTributeQuest.State=QuestState.NotTriggered
Logic.ExecuteInLuaLocalState("LocalScriptCallback_OnQuestStatusChanged("..
self.InternTributeQuest.Index..")")
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_SECOND,"",QuestTemplate.Loop,1,0,{self.InternTributeQuest.QueueID})self.Time=Logic.GetTime()self.RestartQuest=nil end end
function b_Goal_TributeDiplomacy:CustomFunction(wtX)self:GetTributeQuest(wtX)if
self:CheckTributeQuest(wtX)==false then return false end;if
self:CheckTributePlayer(wtX)==true then return true end
self:TributQuestRestarter(wtX)end
function b_Goal_TributeDiplomacy:DEBUG(Y)if self.Amount<0 then
dbg(Y.Identifier.." "..
self.Name..": Amount is negative!")return true end;if self.PeriodLength<
self.TributTime then
dbg(Y.Identifier..
" "..self.Name..": TributTime too long!")return true end end;function b_Goal_TributeDiplomacy:Reset()self.Time=nil;self.InternTributeQuest=nil;self.RestartQuest=
nil end
function b_Goal_TributeDiplomacy:Interrupt(EHSv)if
self.InternTributeQuest~=nil then
if
self.InternTributeQuest.State==QuestState.Active then self.InternTributeQuest:Interrupt()end end end;function b_Goal_TributeDiplomacy:GetCustomData(Ati7Oq)
if(Ati7Oq==6)then return{"true","false"}end end
Core:RegisterBehavior(b_Goal_TributeDiplomacy)
function Goal_TributeClaim(...)return b_Goal_TributeClaim:new(...)end
b_Goal_TributeClaim={Name="Goal_TributeClaim",Description={en="Goal: AI requests periodical tribute for a specified territory. The quest sender is the demanding player.",de="Ziel: Die KI fordert einen regelmässigen Tribut fuer ein Territorium. Der Questgeber ist der fordernde Spieler."},Parameter={{ParameterType.TerritoryName,en="Territory",de="Territorium"},{ParameterType.PlayerID,en="PlayerID",de="PlayerID"},{ParameterType.Number,en="Amount",de="Menge"},{ParameterType.Number,en="Length of Period in seconds",de="Sekunden bis zur nächsten Forderung"},{ParameterType.Number,en="Time to pay Tribut in seconds",de="Zeit bis zur Zahlung in Sekunden"},{ParameterType.Default,en="Start Message for TributQuest",de="Startnachricht der Tributquest"},{ParameterType.Default,en="Success Message for TributQuest",de="Erfolgsnachricht der Tributquest"},{ParameterType.Default,en="Failure Message for TributQuest",de="Niederlagenachricht der Tributquest"},{ParameterType.Number,en="How often to pay (0 = forerver)",de="Anzahl der Tributquests (0 = unendlich)"},{ParameterType.Custom,en="Other Owner cancels the Quest",de="Anderer Spieler kann Quest beenden"},{ParameterType.Custom,en="About if a rate is not payed",de="Nicht-bezahlen beendet die Quest"}}}
function b_Goal_TributeClaim:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_TributeClaim:AddParameter(Tqo2jko,uJz)
if(Tqo2jko==0)then
self.TerritoryID=GetTerritoryIDByName(uJz)elseif(Tqo2jko==1)then self.PlayerID=uJz*1 elseif(Tqo2jko==2)then self.Amount=uJz*1 elseif(
Tqo2jko==3)then self.PeriodLength=uJz*1 elseif(Tqo2jko==4)then
self.TributTime=uJz*1 elseif(Tqo2jko==5)then self.StartMsg=uJz elseif(Tqo2jko==6)then self.SuccessMsg=uJz elseif
(Tqo2jko==7)then self.FailureMsg=uJz elseif(Tqo2jko==8)then self.HowOften=uJz*1 elseif(Tqo2jko==9)then
self.OtherOwnerCancels=AcceptAlternativeBoolean(uJz)elseif(Tqo2jko==10)then
self.DontPayCancels=AcceptAlternativeBoolean(uJz)end end
function b_Goal_TributeClaim:CureOutpost(qVvlt)
local aGkESg=Logic.GetTerritoryAcquiringBuildingID(self.TerritoryID)
if IsExisting(aGkESg)and GetHealth(aGkESg)<25 and
Logic.IsBuildingBeingKnockedDown(aGkESg)==false then
while
(
Logic.GetEntityHealth(aGkESg)<Logic.GetEntityMaxHealth(aGkESg)*0.6)do Logic.HealEntity(aGkESg,1)end end end
function b_Goal_TributeClaim:RestartTributeQuest(KXnNMI7S)self.Time=Logic.GetTime()
if
self.InternTributeQuest then
self.InternTributeQuest.Objectives[1].Completed=nil;self.InternTributeQuest.Objectives[1].Data[3]=
nil;self.InternTributeQuest.Objectives[1].Data[4]=
nil;self.InternTributeQuest.Objectives[1].Data[5]=
nil;self.InternTributeQuest.Result=nil
self.InternTributeQuest.State=QuestState.NotTriggered
Logic.ExecuteInLuaLocalState("LocalScriptCallback_OnQuestStatusChanged("..
self.InternTributeQuest.Index..")")
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_SECOND,"",QuestTemplate.Loop,1,0,{self.InternTributeQuest.QueueID})end end
function b_Goal_TributeClaim:CreateTributeQuest(fL)
if not self.InternTributeQuest then
local Oj,pGR0Ig=QuestTemplate:New(
fL.Identifier.."_TributeClaimQuest",self.PlayerID,fL.ReceivingPlayer,{{Objective.Deliver,{Goods.G_Gold,self.Amount}}},{{Triggers.Time,0}},self.TributTime,
nil,nil,nil,nil,true,true,nil,self.StartMsg,self.SuccessMsg,self.FailureMsg)self.InternTributeQuest=pGR0Ig;self.Time=Logic.GetTime()end end
function b_Goal_TributeClaim:OnTributeFailed(bBq)
local i=Logic.GetTerritoryAcquiringBuildingID(self.TerritoryID)if IsExisting(i)then
Logic.ChangeEntityPlayerID(i,self.PlayerID)end
Logic.SetTerritoryPlayerID(self.TerritoryID,self.PlayerID)self.InternTributeQuest.State=false
self.Time=Logic.GetTime()if self.DontPayCancels then bBq:Interrupt()end end
function b_Goal_TributeClaim:OnTributePaid(yCkt)
local i=Logic.GetTerritoryAcquiringBuildingID(self.TerritoryID)
if self.InternTributeQuest.Result==QuestResult.Success then
if
Logic.GetTerritoryPlayerID(self.TerritoryID)==self.PlayerID then if IsExisting(i)then
Logic.ChangeEntityPlayerID(i,yCkt.ReceivingPlayer)end
Logic.SetTerritoryPlayerID(self.TerritoryID,yCkt.ReceivingPlayer)end end
if Logic.GetTime()>=self.Time+self.PeriodLength then
if
self.HowOften and self.HowOften~=0 then self.TributeCounter=
(self.TributeCounter or 0)+1;if
self.TributeCounter>=self.HowOften then return false end end;self:RestartTributeQuest()end end
function b_Goal_TributeClaim:CustomFunction(rs579)self:CureOutpost(rs579)
if

Logic.GetTerritoryPlayerID(self.TerritoryID)==rs579.ReceivingPlayer or
Logic.GetTerritoryPlayerID(self.TerritoryID)==self.PlayerID then
if self.OtherOwner then self:RestartTributeQuest()self.OtherOwner=nil end;self:CreateTributeQuest(rs579)
if self.InternTributeQuest.State==
QuestState.Over then if
self.InternTributeQuest.Result==QuestResult.Failure then self:OnTributeFailed(rs579)else
self:OnTributePaid(rs579)end elseif
self.InternTributeQuest.State==false then
if
Logic.GetTime()>=self.Time+self.PeriodLength then self:RestartTributeQuest(rs579)end end elseif Logic.GetTerritoryPlayerID(self.TerritoryID)==0 and
self.InternTributeQuest then if self.InternTributeQuest.State==
QuestState.Active then
self.InternTributeQuest:Interrupt()end elseif
Logic.GetTerritoryPlayerID(self.TerritoryID)~=self.PlayerID then if self.InternTributeQuest.State==
QuestState.Active then
self.InternTributeQuest:Interrupt()end;if self.OtherOwnerCancels then
rs579:Interrupt()end;self.OtherOwner=true end;local ptD=Logic.GetStoreHouse(self.PlayerID)
if(ptD==0 or
Logic.IsEntityDestroyed(ptD))then
if
self.InternTributeQuest and
self.InternTributeQuest.State==QuestState.Active then self.InternTributeQuest:Interrupt()end;return true end end
function b_Goal_TributeClaim:DEBUG(mj_P)if self.TerritoryID==0 then
dbg(mj_P.Identifier..": "..
self.Name..": Unknown Territory")return true end
if

not self.InternTributeQuest and Logic.GetStoreHouse(self.PlayerID)==0 then
dbg(mj_P.Identifier..": "..self.Name..
": Player "..self.PlayerID.." is dead. :-(")return true end;if self.Amount<0 then
dbg(mj_P.Identifier..
": "..self.Name..": Amount is negative")return true end
if self.PeriodLength<
self.TributTime or self.PeriodLength<1 then
dbg(
mj_P.Identifier..": "..self.Name..": Period Length is wrong")return true end;if self.HowOften<0 then
dbg(mj_P.Identifier..
": "..self.Name..": HowOften is negative")return true end end;function b_Goal_TributeClaim:Reset()self.InternTributeQuest=nil;self.Time=nil
self.OtherOwner=nil end
function b_Goal_TributeClaim:Interrupt(w)if
type(self.InternTributeQuest)=="table"then
if
self.InternTributeQuest.State==QuestState.Active then self.InternTributeQuest:Interrupt()end end end
function b_Goal_TributeClaim:GetCustomData(Nge6L)if(Nge6L==9)or(Nge6L==10)then return
{"false","true"}end end;Core:RegisterBehavior(b_Goal_TributeClaim)function Reprisal_ObjectDeactivate(...)return
b_Reprisal_ObjectDeactivate:new(...)end
b_Reprisal_ObjectDeactivate={Name="Reprisal_ObjectDeactivate",Description={en="Reprisal: Deactivates an interactive object",de="Vergeltung: Deaktiviert ein interaktives Objekt"},Parameter={{ParameterType.ScriptName,en="Interactive object",de="Interaktives Objekt"}}}
function b_Reprisal_ObjectDeactivate:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_ObjectDeactivate:AddParameter(aWnFL1,D)
if(aWnFL1 ==0)then self.ScriptName=D end end;function b_Reprisal_ObjectDeactivate:CustomFunction(R)
InteractiveObjectDeactivate(self.ScriptName)end
function b_Reprisal_ObjectDeactivate:DEBUG(u51)
if

not Logic.IsInteractiveObject(GetID(self.ScriptName))then
warn(""..
u51.Identifier.." "..self.Name..
": '"..self.ScriptName.."' is not a interactive object!")self.WarningPrinted=true end;local O0NUxa=GetID(self.ScriptName)
if QSB.InitalizedObjekts[O0NUxa]and
QSB.InitalizedObjekts[O0NUxa]==u51.Identifier then
dbg(""..

u51.Identifier.." "..
self.Name..": you can not deactivate in the same quest the object is initalized!")return true end;return false end
Core:RegisterBehavior(b_Reprisal_ObjectDeactivate)function Reprisal_ObjectActivate(...)
return b_Reprisal_ObjectActivate:new(...)end
b_Reprisal_ObjectActivate={Name="Reprisal_ObjectActivate",Description={en="Reprisal: Activates an interactive object",de="Vergeltung: Aktiviert ein interaktives Objekt"},Parameter={{ParameterType.ScriptName,en="Interactive object",de="Interaktives Objekt"},{ParameterType.Custom,en="Availability",de="Nutzbarkeit"}}}
function b_Reprisal_ObjectActivate:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_ObjectActivate:AddParameter(RngfRQ6g,F)if(RngfRQ6g==0)then self.ScriptName=F elseif
(RngfRQ6g==1)then local WSlpP=0;if F=="Always"or 1 then WSlpP=1 end
self.UsingState=WSlpP*1 end end;function b_Reprisal_ObjectActivate:CustomFunction(xSMd)
InteractiveObjectActivate(self.ScriptName,self.UsingState)end
function b_Reprisal_ObjectActivate:GetCustomData(vYmD9ed)if
vYmD9ed==1 then return{"Knight only","Always"}end end
function b_Reprisal_ObjectActivate:DEBUG(Cez)
if not
Logic.IsInteractiveObject(GetID(self.ScriptName))then
warn(""..Cez.Identifier..
" "..self.Name..": '"..
self.ScriptName.."' is not a interactive object!")self.WarningPrinted=true end;local NvSMm=GetID(self.ScriptName)
if QSB.InitalizedObjekts[NvSMm]and
QSB.InitalizedObjekts[NvSMm]==Cez.Identifier then
dbg(""..

Cez.Identifier.." "..
self.Name..": you can not activate in the same quest the object is initalized!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_ObjectActivate)function Reprisal_DiplomacyDecrease()return
b_Reprisal_DiplomacyDecrease:new()end
b_Reprisal_DiplomacyDecrease={Name="Reprisal_DiplomacyDecrease",Description={en="Reprisal: Diplomacy decreases slightly to another player.",de="Vergeltung: Der Diplomatiestatus zum Auftraggeber wird um eine Stufe verringert."}}
function b_Reprisal_DiplomacyDecrease:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_DiplomacyDecrease:CustomFunction(wRpQf)local ed9P=wRpQf.SendingPlayer
local NJ5=wRpQf.ReceivingPlayer;local bpAJ=GetDiplomacyState(NJ5,ed9P)if bpAJ>-2 then
SetDiplomacyState(NJ5,ed9P,bpAJ-1)end end
function b_Reprisal_DiplomacyDecrease:AddParameter(UdPyHc,SciVUxEq)if(UdPyHc==0)then
self.PlayerID=SciVUxEq*1 end end
Core:RegisterBehavior(b_Reprisal_DiplomacyDecrease)
function Reprisal_Diplomacy(...)return b_Reprisal_Diplomacy:new(...)end
b_Reprisal_Diplomacy={Name="Reprisal_Diplomacy",Description={en="Reprisal: Sets Diplomacy state of two Players to a stated value.",de="Vergeltung: Setzt den Diplomatiestatus zweier Spieler auf den angegebenen Wert."},Parameter={{ParameterType.PlayerID,en="PlayerID 1",de="Spieler 1"},{ParameterType.PlayerID,en="PlayerID 2",de="Spieler 2"},{ParameterType.DiplomacyState,en="Relation",de="Beziehung"}}}
function b_Reprisal_Diplomacy:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_Diplomacy:AddParameter(Te,WN)
if(Te==0)then self.PlayerID1=WN*1 elseif(Te==1)then
self.PlayerID2=WN*1 elseif(Te==2)then self.Relation=DiplomacyStates[WN]end end;function b_Reprisal_Diplomacy:CustomFunction(f)
SetDiplomacyState(self.PlayerID1,self.PlayerID2,self.Relation)end
function b_Reprisal_Diplomacy:DEBUG(FleDs3)
if

not tonumber(self.PlayerID1)or self.PlayerID1 <1 or self.PlayerID1 >8 then
dbg(FleDs3.Identifier.." "..self.Name..
": PlayerID 1 is invalid!")return true elseif
not tonumber(self.PlayerID2)or self.PlayerID2 <1 or self.PlayerID2 >8 then
dbg(FleDs3.Identifier.." "..self.Name..
": PlayerID 2 is invalid!")return true elseif
not tonumber(self.Relation)or self.Relation<-2 or self.Relation>2 then
dbg(FleDs3.Identifier.." "..
self.Name..": '"..
self.Relation.."' is a invalid diplomacy state!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_Diplomacy)function Reprisal_DestroyEntity(...)return
b_Reprisal_DestroyEntity:new(...)end
b_Reprisal_DestroyEntity={Name="Reprisal_DestroyEntity",Description={en="Reprisal: Replaces an entity with an invisible script entity, which retains the entities name.",de="Vergeltung: Ersetzt eine Entity mit einer unsichtbaren Script-Entity, die den Namen übernimmt."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"}}}
function b_Reprisal_DestroyEntity:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_DestroyEntity:AddParameter(LP,RLovoVo)
if(LP==0)then self.ScriptName=RLovoVo end end;function b_Reprisal_DestroyEntity:CustomFunction(Je6Srpf8)
ReplaceEntity(self.ScriptName,Entities.XD_ScriptEntity)end
function b_Reprisal_DestroyEntity:DEBUG(p)
if
not IsExisting(self.ScriptName)then
warn(p.Identifier.." "..
self.Name..": '"..self.ScriptName..
"' is already destroyed!")self.WarningPrinted=true end;return false end;Core:RegisterBehavior(b_Reprisal_DestroyEntity)function Reprisal_DestroyEffect(...)return
b_Reprisal_DestroyEffect:new(...)end
b_Reprisal_DestroyEffect={Name="Reprisal_DestroyEffect",Description={en="Reprisal: Destroys an effect",de="Vergeltung: Zerstört einen Effekt"},Parameter={{ParameterType.Default,en="Effect name",de="Effektname"}}}function b_Reprisal_DestroyEffect:AddParameter(Z0RFr5F,_Myb)
if Z0RFr5F==0 then self.EffectName=_Myb end end
function b_Reprisal_DestroyEffect:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_DestroyEffect:CustomFunction(Zq)if

not QSB.EffectNameToID[self.EffectName]or not
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])then return end
Logic.DestroyEffect(QSB.EffectNameToID[self.EffectName])end
function b_Reprisal_DestroyEffect:DEBUG(TKS)if
not QSB.EffectNameToID[self.EffectName]then
dbg(TKS.Identifier.." "..self.Name..
": Effect "..self.EffectName.." never created")end
return false end;Core:RegisterBehavior(b_Reprisal_DestroyEffect)function Reprisal_Defeat()return
b_Reprisal_Defeat:new()end
b_Reprisal_Defeat={Name="Reprisal_Defeat",Description={en="Reprisal: The player loses the game.",de="Vergeltung: Der Spieler verliert das Spiel."}}
function b_Reprisal_Defeat:GetReprisalTable()return{Reprisal.Defeat}end;Core:RegisterBehavior(b_Reprisal_Defeat)function Reprisal_FakeDefeat()return
b_Reprisal_FakeDefeat:new()end
b_Reprisal_FakeDefeat={Name="Reprisal_FakeDefeat",Description={en="Reprisal: Displays a defeat icon for a quest",de="Vergeltung: Zeigt ein Niederlage Icon fuer eine Quest an"}}
function b_Reprisal_FakeDefeat:GetReprisalTable()return{Reprisal.FakeDefeat}end;Core:RegisterBehavior(b_Reprisal_FakeDefeat)function Reprisal_ReplaceEntity(...)return
b_Reprisal_ReplaceEntity:new(...)end
b_Reprisal_ReplaceEntity={Name="Reprisal_ReplaceEntity",Description={en="Reprisal: Replaces an entity with a new one of a different type. The playerID can be changed too.",de="Vergeltung: Ersetzt eine Entity durch eine neue anderen Typs. Es kann auch die Spielerzugehörigkeit geändert werden."},Parameter={{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Custom,en="New Type",de="Neuer Typ"},{ParameterType.Custom,en="New playerID",de="Neue Spieler ID"}}}
function b_Reprisal_ReplaceEntity:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_ReplaceEntity:AddParameter(DUSiwPZm,QSjpjN5)if(DUSiwPZm==0)then self.ScriptName=QSjpjN5 elseif(
DUSiwPZm==1)then self.NewType=QSjpjN5 elseif(DUSiwPZm==2)then
self.PlayerID=tonumber(QSjpjN5)end end
function b_Reprisal_ReplaceEntity:CustomFunction(M3ptD1Cf)local B=GetID(self.ScriptName)
local jv=self.PlayerID;if jv==Logic.EntityGetPlayer(B)then jv=nil end
ReplaceEntity(self.ScriptName,Entities[self.NewType],jv)end
function b_Reprisal_ReplaceEntity:GetCustomData(oTpq)local CjPV={}
if oTpq==1 then
for d,z0 in pairs(Entities)do
local I_bHR9bD={"^M_","^XS_","^X_","^XT_","^Z_","^XB_"}local YJha=false;for g9QyV=1,#I_bHR9bD do
if d:find(I_bHR9bD[g9QyV])then YJha=true;break end end;if not YJha then
table.insert(CjPV,d)end end;table.sort(CjPV)elseif oTpq==2 then
CjPV={"-","0","1","2","3","4","5","6","7","8"}end;return CjPV end
function b_Reprisal_ReplaceEntity:DEBUG(An_hQ3m)
if not Entities[self.NewType]then
dbg(
An_hQ3m.Identifier.." "..self.Name..": got an invalid entity type!")return true elseif self.PlayerID~=nil and
(self.PlayerID<1 or self.PlayerID>8)then
dbg(An_hQ3m.Identifier.." "..
self.Name..": got an invalid playerID!")return true end
if not IsExisting(self.ScriptName)then self.WarningPrinted=true
warn(
An_hQ3m.Identifier.." "..
self.Name..": '"..self.ScriptName.."' does not exist!")end;return false end;Core:RegisterBehavior(b_Reprisal_ReplaceEntity)function Reprisal_QuestRestart(...)return
b_Reprisal_QuestRestart(...)end
b_Reprisal_QuestRestart={Name="Reprisal_QuestRestart",Description={en="Reprisal: Restarts a (completed) quest so it can be triggered and completed again",de="Vergeltung: Startet eine (beendete) Quest neu, damit diese neu ausgelöst und beendet werden kann"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reprisal_QuestRestart:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_QuestRestart:AddParameter(S,eMj5b1DD)
if(S==0)then self.QuestName=eMj5b1DD end end;function b_Reprisal_QuestRestart:CustomFunction(lDdmS)
RestartQuestByName(self.QuestName,true)end
function b_Reprisal_QuestRestart:DEBUG(k1kp870h)
if not
Quests[GetQuestID(self.QuestName)]then
dbg(k1kp870h.Identifier..
" "..self.Name..": quest "..
self.QuestName.." does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_QuestRestart)function Reprisal_QuestFailure(...)return
b_Reprisal_QuestFailure(...)end
b_Reprisal_QuestFailure={Name="Reprisal_QuestFailure",Description={en="Reprisal: Lets another active quest fail",de="Vergeltung: Lässt eine andere aktive Quest fehlschlagen"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reprisal_QuestFailure:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_QuestFailure:AddParameter(Xfv1_F,F74YQ)
if(Xfv1_F==0)then self.QuestName=F74YQ end end;function b_Reprisal_QuestFailure:CustomFunction(SHlZ8Rw)
FailQuestByName(self.QuestName,true)end
function b_Reprisal_QuestFailure:DEBUG(FxP66)if not
Quests[GetQuestID(self.QuestName)]then
dbg(""..FxP66.Identifier..
" "..self.Name..": got an invalid quest!")return true end
return false end;Core:RegisterBehavior(b_Reprisal_QuestFailure)function Reprisal_QuestSuccess(...)return
b_Reprisal_QuestSuccess(...)end
b_Reprisal_QuestSuccess={Name="Reprisal_QuestSuccess",Description={en="Reprisal: Completes another active quest successfully",de="Vergeltung: Beendet eine andere aktive Quest erfolgreich"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reprisal_QuestSuccess:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_QuestSuccess:AddParameter(y,Ou)if(y==0)then self.QuestName=Ou end end;function b_Reprisal_QuestSuccess:CustomFunction(AbN)
WinQuestByName(self.QuestName,true)end
function b_Reprisal_QuestSuccess:DEBUG(lINgqxG1)
if not
Quests[GetQuestID(self.QuestName)]then
dbg(lINgqxG1.Identifier..
" "..self.Name..": quest "..
self.QuestName.." does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_QuestSuccess)function Reprisal_QuestActivate(...)return
b_Reprisal_QuestActivate(...)end
b_Reprisal_QuestActivate={Name="Reprisal_QuestActivate",Description={en="Reprisal: Activates another quest that is not triggered yet.",de="Vergeltung: Aktiviert eine andere Quest die noch nicht ausgelöst wurde."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reprisal_QuestActivate:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_QuestActivate:AddParameter(Tz4j,vUctRT)if(Tz4j==0)then self.QuestName=vUctRT else
assert(false,"Error in "..
self.Name..": AddParameter: Index is invalid")end end;function b_Reprisal_QuestActivate:CustomFunction(ry0d9cxF)
StartQuestByName(self.QuestName,true)end
function b_Reprisal_QuestActivate:DEBUG(fdMS0Bi)
if
not IsValidQuest(self.QuestName)then
dbg(fdMS0Bi.Identifier.." "..
self.Name..": Quest: "..
self.QuestName.." does not exist")return true end;return false end;Core:RegisterBehavior(b_Reprisal_QuestActivate)function Reprisal_QuestInterrupt(...)return
b_Reprisal_QuestInterrupt(...)end
b_Reprisal_QuestInterrupt={Name="Reprisal_QuestInterrupt",Description={en="Reprisal: Interrupts another active quest without success or failure",de="Vergeltung: Beendet eine andere aktive Quest ohne Erfolg oder Misserfolg"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reprisal_QuestInterrupt:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_QuestInterrupt:AddParameter(jUfRhXXt,bncqpLFj)
if(jUfRhXXt==0)then self.QuestName=bncqpLFj end end
function b_Reprisal_QuestInterrupt:CustomFunction(c9P3)
if(
GetQuestID(self.QuestName)~=nil)then
local D=GetQuestID(self.QuestName)local A=Quests[D]if A.State==QuestState.Active then
StopQuestByName(self.QuestName,true)end end end
function b_Reprisal_QuestInterrupt:DEBUG(cO3SXQC)
if
not Quests[GetQuestID(self.QuestName)]then
dbg(cO3SXQC.Identifier.." "..self.Name..
": quest "..self.QuestName.." does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_QuestInterrupt)function Reprisal_QuestForceInterrupt(...)return
b_Reprisal_QuestForceInterrupt(...)end
b_Reprisal_QuestForceInterrupt={Name="Reprisal_QuestForceInterrupt",Description={en="Reprisal: Interrupts another quest (even when it isn't active yet) without success or failure",de="Vergeltung: Beendet eine andere Quest, auch wenn diese noch nicht aktiv ist ohne Erfolg oder Misserfolg"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Custom,en="Ended quests",de="Beendete Quests"}}}
function b_Reprisal_QuestForceInterrupt:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_QuestForceInterrupt:AddParameter(qiw,bQRP)if(qiw==0)then self.QuestName=bQRP elseif(qiw==1)then
self.InterruptEnded=AcceptAlternativeBoolean(bQRP)end end
function b_Reprisal_QuestForceInterrupt:GetCustomData(K5)local M={}
if K5 ==1 then
table.insert(M,"false")table.insert(M,"true")else assert(false)end;return M end
function b_Reprisal_QuestForceInterrupt:CustomFunction(ZubW5sf)
if
(GetQuestID(self.QuestName)~=nil)then local VLlBaUgt=GetQuestID(self.QuestName)
local QniH=Quests[VLlBaUgt]if self.InterruptEnded or QniH.State~=QuestState.Over then
QniH:Interrupt()end end end
function b_Reprisal_QuestForceInterrupt:DEBUG(j)
if not
Quests[GetQuestID(self.QuestName)]then
dbg(j.Identifier.." "..self.Name..
": quest "..self.QuestName.." does not exist!")return true end;return false end
Core:RegisterBehavior(b_Reprisal_QuestForceInterrupt)function Reprisal_CustomVariables(...)
return b_Reprisal_CustomVariables:new(...)end
b_Reprisal_CustomVariables={Name="Reprisal_CustomVariables",Description={en="Reprisal: Executes a mathematical operation with this variable. The other operand can be a number or another custom variable.",de="Vergeltung: Fuehrt eine mathematische Operation mit der Variable aus. Der andere Operand kann eine Zahl oder eine Custom-Varible sein."},Parameter={{ParameterType.Default,en="Name of variable",de="Variablenname"},{ParameterType.Custom,en="Operator",de="Operator"},{ParameterType.Default,en="Value or variable",de="Wert oder Variable"}}}
function b_Reprisal_CustomVariables:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_CustomVariables:AddParameter(x_BU2,AFii)
if x_BU2 ==0 then self.VariableName=AFii elseif x_BU2 ==1 then
self.Operator=AFii elseif x_BU2 ==2 then local Au=tonumber(AFii)
Au=(Au~=nil and Au)or tostring(AFii)self.Value=Au end end
function b_Reprisal_CustomVariables:CustomFunction()
_G["QSB_CustomVariables_"..self.VariableName]=_G[
"QSB_CustomVariables_"..self.VariableName]or 0
local fgK=_G["QSB_CustomVariables_"..self.VariableName]
if self.Operator=="="then
_G["QSB_CustomVariables_"..self.VariableName]=(
type(self.Value)~="string"and self.Value)or _G[
"QSB_CustomVariables_"..self.Value]elseif self.Operator=="+"then
_G["QSB_CustomVariables_"..self.VariableName]=
fgK+
(type(self.Value)~="string"and self.Value)or
_G["QSB_CustomVariables_"..self.Value]elseif self.Operator=="-"then
_G["QSB_CustomVariables_"..self.VariableName]=
fgK-
(type(self.Value)~="string"and self.Value)or
_G["QSB_CustomVariables_"..self.Value]elseif self.Operator=="*"then
_G["QSB_CustomVariables_"..self.VariableName]=
fgK*
(type(self.Value)~="string"and self.Value)or
_G["QSB_CustomVariables_"..self.Value]elseif self.Operator=="/"then
_G["QSB_CustomVariables_"..self.VariableName]=
fgK/
(type(self.Value)~="string"and self.Value)or
_G["QSB_CustomVariables_"..self.Value]elseif self.Operator=="^"then
_G["QSB_CustomVariables_"..self.VariableName]=
fgK^
(type(self.Value)~="string"and self.Value)or
_G["QSB_CustomVariables_"..self.Value]end end
function b_Reprisal_CustomVariables:GetCustomData(gm)return{"=","+","-","*","/","^"}end
function b_Reprisal_CustomVariables:DEBUG(jwJufiF)local YogtAPf={"=","+","-","*","/","^"}
if not
Inside(self.Operator,YogtAPf)then
dbg(jwJufiF.Identifier..
" "..self.Name..": got an invalid operator!")return true elseif self.VariableName==""then
dbg(jwJufiF.Identifier.." "..
self.Name..": missing name for variable!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_CustomVariables)function Reprisal_MapScriptFunction(...)return
b_Reprisal_MapScriptFunction:new(...)end
b_Reprisal_MapScriptFunction={Name="Reprisal_MapScriptFunction",Description={en="Reprisal: Calls a function within the global map script if the quest has failed.",de="Vergeltung: Ruft eine Funktion im globalen Kartenskript auf, wenn die Quest fehlschlägt."},Parameter={{ParameterType.Default,en="Function name",de="Funktionsname"}}}
function b_Reprisal_MapScriptFunction:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_MapScriptFunction:AddParameter(q7h,WS)
if(q7h==0)then self.FuncName=WS end end;function b_Reprisal_MapScriptFunction:CustomFunction(Uee8Une)return
_G[self.FuncName](self,Uee8Une)end
function b_Reprisal_MapScriptFunction:DEBUG(UtI)
if
not self.FuncName or not _G[self.FuncName]then
dbg(""..

UtI.Identifier.." "..
self.Name..": function '"..self.FuncName.."' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Reprisal_MapScriptFunction)
function Reprisal_Technology(...)return b_Reprisal_Technology:new(...)end
b_Reprisal_Technology={Name="Reprisal_Technology",Description={en="Reprisal: Locks or unlocks a technology for the given player",de="Vergeltung: Sperrt oder erlaubt eine Technolgie fuer den angegebenen Player"},Parameter={{ParameterType.PlayerID,en="PlayerID",de="SpielerID"},{ParameterType.Custom,en="Un / Lock",de="Sperren/Erlauben"},{ParameterType.Custom,en="Technology",de="Technologie"}}}
function b_Reprisal_Technology:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_Technology:AddParameter(L,qx27)
if(L==0)then self.PlayerID=qx27*1 elseif(L==1)then self.LockType=qx27 ==
"Lock"elseif(L==2)then self.Technology=qx27 end end
function b_Reprisal_Technology:CustomFunction(whvO)
if
self.PlayerID and
Logic.GetStoreHouse(self.PlayerID)~=0 and Technologies[self.Technology]then
if self.LockType then
LockFeaturesForPlayer(self.PlayerID,Technologies[self.Technology])else
UnLockFeaturesForPlayer(self.PlayerID,Technologies[self.Technology])end else return false end end
function b_Reprisal_Technology:GetCustomData(kpbY)local m_gHw={}if(kpbY==1)then m_gHw[1]="Lock"
m_gHw[2]="UnLock"elseif(kpbY==2)then
for RFOr,NL in pairs(Technologies)do table.insert(m_gHw,RFOr)end end
return m_gHw end
function b_Reprisal_Technology:DEBUG(g0d1ms_)
if not Technologies[self.Technology]then
dbg(""..

g0d1ms_.Identifier.." "..self.Name..": got an invalid technology type!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
dbg(""..g0d1ms_.Identifier.." "..self.Name..
": got an invalid playerID!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_Technology)function Reward_ObjectDeactivate(...)return
b_Reward_ObjectDeactivate:new(...)end
b_Reward_ObjectDeactivate=API.InstanceTable(b_Reprisal_ObjectDeactivate)b_Reward_ObjectDeactivate.Name="Reward_ObjectDeactivate"
b_Reward_ObjectDeactivate.Description.de="Reward: Deactivates an interactive object"
b_Reward_ObjectDeactivate.Description.en="Lohn: Deaktiviert ein interaktives Objekt"b_Reward_ObjectDeactivate.GetReprisalTable=nil
b_Reward_ObjectDeactivate.GetRewardTable=function(Xmu5,lC3P)return
{Reward.Custom,{Xmu5,Xmu5.CustomFunction}}end;Core:RegisterBehavior(b_Reward_ObjectDeactivate)function Reward_ObjectActivate(...)return
b_Reward_ObjectActivate:new(...)end
b_Reward_ObjectActivate=API.InstanceTable(b_Reprisal_ObjectActivate)b_Reward_ObjectActivate.Name="Reward_ObjectActivate"
b_Reward_ObjectActivate.Description.de="Reward: Activates an interactive object"
b_Reward_ObjectActivate.Description.en="Lohn: Aktiviert ein interaktives Objekt"b_Reward_ObjectActivate.GetReprisalTable=nil
b_Reward_ObjectActivate.GetRewardTable=function(QwHnJ1MC,giqW)return
{Reward.Custom,{QwHnJ1MC,QwHnJ1MC.CustomFunction}}end;Core:RegisterBehavior(b_Reward_ObjectActivate)function Reward_ObjectInit(...)return
b_Reward_ObjectInit:new(...)end
b_Reward_ObjectInit={Name="Reward_ObjectInit",Description={en="Reward: Setup an interactive object with costs and rewards.",de="Lohn: Initialisiert ein interaktives Objekt mit seinen Kosten und Schätzen."},Parameter={{ParameterType.ScriptName,en="Interactive object",de="Interaktives Objekt"},{ParameterType.Number,en="Distance to use",de="Nutzungsentfernung"},{ParameterType.Number,en="Waittime",de="Wartezeit"},{ParameterType.Custom,en="Reward good",de="Belohnungsware"},{ParameterType.Number,en="Reward amount",de="Anzahl"},{ParameterType.Custom,en="Cost good 1",de="Kostenware 1"},{ParameterType.Number,en="Cost amount 1",de="Anzahl 1"},{ParameterType.Custom,en="Cost good 2",de="Kostenware 2"},{ParameterType.Number,en="Cost amount 2",de="Anzahl 2"},{ParameterType.Custom,en="Availability",de="Verfï¿½gbarkeit"}}}function b_Reward_ObjectInit:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_ObjectInit:AddParameter(UJP9j,SObxoJk)
if(
UJP9j==0)then self.ScriptName=SObxoJk elseif(UJP9j==1)then
self.Distance=SObxoJk*1 elseif(UJP9j==2)then self.Waittime=SObxoJk*1 elseif(UJP9j==3)then
self.RewardType=SObxoJk elseif(UJP9j==4)then self.RewardAmount=SObxoJk*1 elseif(UJP9j==5)then
self.FirstCostType=SObxoJk elseif(UJP9j==6)then self.FirstCostAmount=SObxoJk*1 elseif(UJP9j==7)then
self.SecondCostType=SObxoJk elseif(UJP9j==8)then self.SecondCostAmount=SObxoJk*1 elseif(UJP9j==9)then local _nBsWM3x=nil
if SObxoJk==
"Always"or SObxoJk==1 then _nBsWM3x=1 elseif
SObxoJk=="Never"or SObxoJk==2 then _nBsWM3x=2 elseif SObxoJk=="Knight only"or SObxoJk==0 then _nBsWM3x=0 end;self.UsingState=_nBsWM3x end end
function b_Reward_ObjectInit:CustomFunction(D5)local I=GetID(self.ScriptName)
if I==0 then return end;QSB.InitalizedObjekts[I]=D5.Identifier
Logic.InteractiveObjectClearCosts(I)Logic.InteractiveObjectClearRewards(I)
Logic.InteractiveObjectSetInteractionDistance(I,self.Distance)
Logic.InteractiveObjectSetTimeToOpen(I,self.Waittime)if self.RewardType and self.RewardType~="disabled"then
Logic.InteractiveObjectAddRewards(I,Goods[self.RewardType],self.RewardAmount)end;if
self.FirstCostType and self.FirstCostType~="disabled"then
Logic.InteractiveObjectAddCosts(I,Goods[self.FirstCostType],self.FirstCostAmount)end;if
self.SecondCostType and self.SecondCostType~="disabled"then
Logic.InteractiveObjectAddCosts(I,Goods[self.SecondCostType],self.SecondCostAmount)end
Logic.InteractiveObjectSetAvailability(I,true)
if self.UsingState then for rgZln=1,8 do
Logic.InteractiveObjectSetPlayerState(I,rgZln,self.UsingState)end end
Logic.InteractiveObjectSetRewardResourceCartType(I,Entities.U_ResourceMerchant)
Logic.InteractiveObjectSetRewardGoldCartType(I,Entities.U_GoldCart)
Logic.InteractiveObjectSetCostResourceCartType(I,Entities.U_ResourceMerchant)
Logic.InteractiveObjectSetCostGoldCartType(I,Entities.U_GoldCart)RemoveInteractiveObjectFromOpenedList(I)
table.insert(HiddenTreasures,I)end
function b_Reward_ObjectInit:GetCustomData(vB)
if vB==3 or vB==5 or vB==7 then
local vFea={"-","G_Beer","G_Bread","G_Broom","G_Carcass","G_Cheese","G_Clothes","G_Dye","G_Gold","G_Grain","G_Herb","G_Honeycomb","G_Iron","G_Leather","G_Medicine","G_Milk","G_RawFish","G_Salt","G_Sausage","G_SmokedFish","G_Soap","G_Stone","G_Water","G_Wood","G_Wool"}
if g_GameExtraNo>=1 then vFea[#vFea+1]="G_Gems"
vFea[#vFea+1]="G_MusicalInstrument"vFea[#vFea+1]="G_Olibanum"end;return vFea elseif vB==9 then return{"-","Knight only","Always","Never"}end end
function b_Reward_ObjectInit:DEBUG(_T5)
if
Logic.IsInteractiveObject(GetID(self.ScriptName))==false then
dbg(""..
_T5.Identifier.." "..
self.Name..": '"..self.ScriptName..
"' is not a interactive object!")return true end;if self.UsingState~=1 and self.Distance<50 then
warn(""..
_T5.Identifier.." "..
self.Name..": distance is maybe too short!")end;if
self.Waittime<0 then
dbg("".._T5.Identifier..
" "..self.Name..": waittime must be equal or greater than 0!")return true end
if
self.RewardType and self.RewardType~="-"then
if
not Goods[self.RewardType]then
dbg(""..
_T5.Identifier.." "..self.Name..
": '"..self.RewardType.."' is invalid good type!")return true elseif self.RewardAmount<1 then
dbg("".._T5.Identifier.." "..
self.Name..": amount can not be 0 or negative!")return true end end
if self.FirstCostType and self.FirstCostType~="-"then
if not
Goods[self.FirstCostType]then
dbg("".._T5.Identifier..
" "..self.Name..": '"..
self.FirstCostType.."' is invalid good type!")return true elseif self.FirstCostAmount<1 then
dbg("".._T5.Identifier.." "..
self.Name..": amount can not be 0 or negative!")return true end end
if self.SecondCostType and self.SecondCostType~="-"then
if not
Goods[self.SecondCostType]then
dbg("".._T5.Identifier..
" "..self.Name..": '"..
self.SecondCostType.."' is invalid good type!")return true elseif self.SecondCostAmount<1 then
dbg("".._T5.Identifier.." "..
self.Name..": amount can not be 0 or negative!")return true end end;return false end;Core:RegisterBehavior(b_Reward_ObjectInit)function Reward_Diplomacy(...)return
b_Reward_Diplomacy:new(...)end
b_Reward_Diplomacy=API.InstanceTable(b_Reprisal_Diplomacy)b_Reward_Diplomacy.Name="Reward_Diplomacy"
b_Reward_Diplomacy.Description.de="Reward: Sets Diplomacy state of two Players to a stated value."
b_Reward_Diplomacy.Description.en="Lohn: Setzt den Diplomatiestatus zweier Spieler auf den angegebenen Wert."b_Reward_Diplomacy.GetReprisalTable=nil
b_Reward_Diplomacy.GetRewardTable=function(fx,ZkXY)return
{Reward.Custom,{fx,fx.CustomFunction}}end;Core:RegisterBehavior(b_Reward_Diplomacy)function Reward_DiplomacyIncrease()return
b_Reward_DiplomacyIncrease:new()end
b_Reward_DiplomacyIncrease={Name="Reward_DiplomacyIncrease",Description={en="Reward: Diplomacy increases slightly to another player",de="Lohn: Verbesserug des Diplomatiestatus zu einem anderen Spieler"}}
function b_Reward_DiplomacyIncrease:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_DiplomacyIncrease:CustomFunction(sWJA)local NVvo=sWJA.SendingPlayer
local P2Kd8=sWJA.ReceivingPlayer;local asrUjwf=GetDiplomacyState(P2Kd8,NVvo)if asrUjwf<2 then
SetDiplomacyState(P2Kd8,NVvo,asrUjwf+1)end end;function b_Reward_DiplomacyIncrease:AddParameter(Q,ya253Ad)
if(Q==0)then self.PlayerID=ya253Ad*1 end end
Core:RegisterBehavior(b_Reward_DiplomacyIncrease)
function Reward_TradeOffers(...)return b_Reward_TradeOffers:new(...)end
b_Reward_TradeOffers={Name="Reward_TradeOffers",Description={en="Reward: Deletes all existing offers for a merchant and sets new offers, if given",de="Lohn: Löscht alle Angebote eines Händlers und setzt neue, wenn angegeben"},Parameter={{ParameterType.Custom,en="PlayerID",de="PlayerID"},{ParameterType.Custom,en="Amount 1",de="Menge 1"},{ParameterType.Custom,en="Offer 1",de="Angebot 1"},{ParameterType.Custom,en="Amount 2",de="Menge 2"},{ParameterType.Custom,en="Offer 2",de="Angebot 2"},{ParameterType.Custom,en="Amount 3",de="Menge 3"},{ParameterType.Custom,en="Offer 3",de="Angebot 3"},{ParameterType.Custom,en="Amount 4",de="Menge 4"},{ParameterType.Custom,en="Offer 4",de="Angebot 4"}}}function b_Reward_TradeOffers:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_TradeOffers:AddParameter(T49bAP,bS5Jz)
if(
T49bAP==0)then self.PlayerID=bS5Jz elseif(T49bAP==1)then
self.AmountOffer1=tonumber(bS5Jz)elseif(T49bAP==2)then self.Offer1=bS5Jz elseif(T49bAP==3)then
self.AmountOffer2=tonumber(bS5Jz)elseif(T49bAP==4)then self.Offer2=bS5Jz elseif(T49bAP==5)then
self.AmountOffer3=tonumber(bS5Jz)elseif(T49bAP==6)then self.Offer3=bS5Jz elseif(T49bAP==7)then
self.AmountOffer4=tonumber(bS5Jz)elseif(T49bAP==8)then self.Offer4=bS5Jz end end
function b_Reward_TradeOffers:CustomFunction()
if(self.PlayerID>1)and
(self.PlayerID<9)then
local yl=Logic.GetStoreHouse(self.PlayerID)Logic.RemoveAllOffers(yl)
for srV=1,4 do
if self["Offer"..srV]and
self["Offer"..srV]~="-"then
if Goods[self["Offer"..srV]]then
AddOffer(yl,self[
"AmountOffer"..srV],Goods[self["Offer"..srV]])elseif
Logic.IsEntityTypeInCategory(Entities[self["Offer"..srV]],EntityCategories.Military)==1 then
AddMercenaryOffer(yl,self["AmountOffer"..srV],Entities[self[
"Offer"..srV]])else
AddEntertainerOffer(yl,Entities[self["Offer"..srV]])end end end end end
function b_Reward_TradeOffers:DEBUG(tSO4)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
dbg(tSO4.Identifier..": Error in "..self.Name..
": Player "..self.PlayerID.." is dead. :-(")return true end end
function b_Reward_TradeOffers:GetCustomData(ALU1Lf)local odzL_={"2","3","4","5","6","7","8"}
local rHhv={"1","2","3","4","5","6","7","8","9"}
local DUv3={"-","G_Beer","G_Bow","G_Bread","G_Broom","G_Candle","G_Carcass","G_Cheese","G_Clothes","G_Cow","G_Grain","G_Herb","G_Honeycomb","G_Iron","G_Leather","G_Medicine","G_Milk","G_RawFish","G_Sausage","G_Sheep","G_SmokedFish","G_Soap","G_Stone","G_Sword","G_Wood","G_Wool","G_Salt","G_Dye","U_AmmunitionCart","U_BatteringRamCart","U_CatapultCart","U_SiegeTowerCart","U_MilitaryBandit_Melee_ME","U_MilitaryBandit_Melee_SE","U_MilitaryBandit_Melee_NA","U_MilitaryBandit_Melee_NE","U_MilitaryBandit_Ranged_ME","U_MilitaryBandit_Ranged_NA","U_MilitaryBandit_Ranged_NE","U_MilitaryBandit_Ranged_SE","U_MilitaryBow_RedPrince","U_MilitaryBow","U_MilitarySword_RedPrince","U_MilitarySword","U_Entertainer_NA_FireEater","U_Entertainer_NA_StiltWalker","U_Entertainer_NE_StrongestMan_Barrel","U_Entertainer_NE_StrongestMan_Stone"}
if g_GameExtraNo and g_GameExtraNo>=1 then
table.insert(DUv3,"G_Gems")table.insert(DUv3,"G_Olibanum")
table.insert(DUv3,"G_MusicalInstrument")table.insert(DUv3,"G_MilitaryBandit_Ranged_AS")
table.insert(DUv3,"G_MilitaryBandit_Melee_AS")table.insert(DUv3,"U_MilitarySword_Khana")
table.insert(DUv3,"U_MilitaryBow_Khana")end
if(ALU1Lf==0)then return odzL_ elseif
(ALU1Lf==1)or(ALU1Lf==3)or(ALU1Lf==5)or(ALU1Lf==7)then return rHhv elseif
(ALU1Lf==2)or(ALU1Lf==4)or(ALU1Lf==6)or(ALU1Lf==8)then
return DUv3 end end;Core:RegisterBehavior(b_Reward_TradeOffers)function Reward_DestroyEntity(...)return
b_Reward_DestroyEntity:new(...)end
b_Reward_DestroyEntity=API.InstanceTable(b_Reprisal_DestroyEntity)b_Reward_DestroyEntity.Name="Reward_DestroyEntity"
b_Reward_DestroyEntity.Description.en="Reward: Replaces an entity with an invisible script entity, which retains the entities name."
b_Reward_DestroyEntity.Description.de="Lohn: Ersetzt eine Entity mit einer unsichtbaren Script-Entity, die den Namen übernimmt."b_Reward_DestroyEntity.GetReprisalTable=nil
b_Reward_DestroyEntity.GetRewardTable=function(qM23K,HnNik4)return
{Reward.Custom,{qM23K,qM23K.CustomFunction}}end;Core:RegisterBehavior(b_Reward_DestroyEntity)function Reward_DestroyEffect(...)return
b_Reward_DestroyEffect:new(...)end
b_Reward_DestroyEffect=API.InstanceTable(b_Reprisal_DestroyEffect)b_Reward_DestroyEffect.Name="Reward_DestroyEffect"
b_Reward_DestroyEffect.Description.en="Reward: Destroys an effect."
b_Reward_DestroyEffect.Description.de="Lohn: Zerstört einen Effekt."b_Reward_DestroyEffect.GetReprisalTable=nil
b_Reward_DestroyEffect.GetRewardTable=function(Tb,k)return
{Reward.Custom,{Tb,Tb.CustomFunction}}end;Core:RegisterBehavior(b_Reward_DestroyEffect)function Reward_CreateBattalion(...)return
b_Reward_CreateBattalion:new(...)end
b_Reward_CreateBattalion={Name="Reward_CreateBattalion",Description={en="Reward: Replaces a script entity with a battalion, which retains the entities name",de="Lohn: Ersetzt eine Script-Entity durch ein Bataillon, welches den Namen der Script-Entity übernimmt"},Parameter={{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Number,en="Number of soldiers",de="Anzahl Soldaten"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}
function b_Reward_CreateBattalion:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_CreateBattalion:AddParameter(g,mOxUSY)
if(g==0)then self.ScriptNameEntity=mOxUSY elseif(g==1)then self.PlayerID=
mOxUSY*1 elseif(g==2)then self.UnitKey=mOxUSY elseif(g==3)then
self.Orientation=mOxUSY*1 elseif(g==4)then self.SoldierCount=mOxUSY*1 elseif(g==5)then
self.HideFromAI=AcceptAlternativeBoolean(mOxUSY)end end
function b_Reward_CreateBattalion:CustomFunction(t)if
not IsExisting(self.ScriptNameEntity)then return false end
local CY=GetPosition(self.ScriptNameEntity)
local EPz43s=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],CY.X,CY.Y,self.Orientation,self.PlayerID,self.SoldierCount)local zR=GetID(self.ScriptNameEntity)if
Logic.IsBuilding(zR)==0 then DestroyEntity(self.ScriptNameEntity)
Logic.SetEntityName(EPz43s,self.ScriptNameEntity)end;if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,EPz43s,true)end end
function b_Reward_CreateBattalion:GetCustomData(ZiGUK4j)local X5xyw_Y={}
if ZiGUK4j==2 then
for Zb3oLBm1,gVS in pairs(Entities)do if
Logic.IsEntityTypeInCategory(gVS,EntityCategories.Soldier)==1 then
table.insert(X5xyw_Y,Zb3oLBm1)end end;table.sort(X5xyw_Y)elseif ZiGUK4j==5 then
table.insert(X5xyw_Y,"false")table.insert(X5xyw_Y,"true")else assert(false)end;return X5xyw_Y end
function b_Reward_CreateBattalion:DEBUG(y7AFV)
if not Entities[self.UnitKey]then
dbg(y7AFV.Identifier..
" "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
dbg(y7AFV.Identifier.." "..
self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
dbg(y7AFV.Identifier.." "..self.Name..
": playerID is wrong!")return true elseif tonumber(self.Orientation)==nil then
dbg(y7AFV.Identifier.." "..self.Name..
": orientation must be a number!")return true elseif
tonumber(self.SoldierCount)==nil or self.SoldierCount<1 then
dbg(y7AFV.Identifier..
" "..self.Name..": you can not create a empty batallion!")return true end;return false end;Core:RegisterBehavior(b_Reward_CreateBattalion)function Reward_CreateSeveralBattalions(...)return
b_Reward_CreateSeveralBattalions:new(...)end
b_Reward_CreateSeveralBattalions={Name="Reward_CreateSeveralBattalions",Description={en="Reward: Creates a given amount of battalions",de="Lohn: Erstellt eine gegebene Anzahl Bataillone"},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Number,en="Number of soldiers",de="Anzahl Soldaten"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}
function b_Reward_CreateSeveralBattalions:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_CreateSeveralBattalions:AddParameter(BUtgk5wL,yvkTFEw)
if(BUtgk5wL==0)then
self.Amount=yvkTFEw*1 elseif(BUtgk5wL==1)then self.ScriptNameEntity=yvkTFEw elseif(BUtgk5wL==2)then self.PlayerID=
yvkTFEw*1 elseif(BUtgk5wL==3)then self.UnitKey=yvkTFEw elseif(BUtgk5wL==4)then self.Orientation=
yvkTFEw*1 elseif(BUtgk5wL==5)then self.SoldierCount=yvkTFEw*1 elseif
(BUtgk5wL==6)then self.HideFromAI=AcceptAlternativeBoolean(yvkTFEw)end end
function b_Reward_CreateSeveralBattalions:CustomFunction(FPuu)if
not IsExisting(self.ScriptNameEntity)then return false end
local IM6lQ1nN=GetID(self.ScriptNameEntity)local cdRq,rk6C,a4EodrlS=Logic.EntityGetPos(IM6lQ1nN)if
Logic.IsBuilding(IM6lQ1nN)==1 then
cdRq,rk6C=Logic.GetBuildingApproachPosition(IM6lQ1nN)end
for QDUH3=1,self.Amount do
local FZNkY=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],cdRq,rk6C,self.Orientation,self.PlayerID,self.SoldierCount)
Logic.SetEntityName(FZNkY,self.ScriptNameEntity.."_"..QDUH3)if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,FZNkY,true)end end end
function b_Reward_CreateSeveralBattalions:GetCustomData(AMQfXns)local N={}
if AMQfXns==3 then for Zv1xWmbK,usLtv in pairs(Entities)do
if
Logic.IsEntityTypeInCategory(usLtv,EntityCategories.Soldier)==1 then table.insert(N,Zv1xWmbK)end end
table.sort(N)elseif AMQfXns==6 then table.insert(N,"false")
table.insert(N,"true")else assert(false)end;return N end
function b_Reward_CreateSeveralBattalions:DEBUG(D0WSWx)
if not Entities[self.UnitKey]then
dbg(
D0WSWx.Identifier.." "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
dbg(D0WSWx.Identifier.." "..
self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
dbg(D0WSWx.Identifier.." "..self.Name..
": playerDI is wrong!")return true elseif tonumber(self.Orientation)==nil then
dbg(D0WSWx.Identifier.." "..self.Name..
": orientation must be a number!")return true elseif
tonumber(self.SoldierCount)==nil or self.SoldierCount<1 then
dbg(D0WSWx.Identifier..
" "..self.Name..": you can not create a empty batallion!")return true elseif
tonumber(self.Amount)==nil or self.Amount<0 then
dbg(D0WSWx.Identifier..
" "..self.Name..": amount can not be negative!")return true end;return false end
Core:RegisterBehavior(b_Reward_CreateSeveralBattalions)
function Reward_CreateEffect(...)return b_Reward_CreateEffect:new(...)end
b_Reward_CreateEffect={Name="Reward_CreateEffect",Description={en="Reward: Creates an effect at a specified position",de="Lohn: Erstellt einen Effekt an der angegebenen Position"},Parameter={{ParameterType.Default,en="Effect name",de="Effektname"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.ScriptName,en="Location",de="Ort"},{ParameterType.Number,en="Orientation (in degrees)(-1: from locating entity)",de="Ausrichtung (in Grad)(-1: von Positionseinheit)"}}}
function b_Reward_CreateEffect:AddParameter(fI4Jq_JC,CK17)
if fI4Jq_JC==0 then self.EffectName=CK17 elseif fI4Jq_JC==1 then
self.Type=EGL_Effects[CK17]elseif fI4Jq_JC==2 then self.PlayerID=CK17*1 elseif fI4Jq_JC==3 then self.Location=CK17 elseif fI4Jq_JC==4 then self.Orientation=
CK17*1 end end;function b_Reward_CreateEffect:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_CreateEffect:CustomFunction(EN6EGq)if
Logic.IsEntityDestroyed(self.Location)then return end
local _Nz=assert(GetID(self.Location),EN6EGq.Identifier.."Error in "..
self.Name..": CustomFunction: Entity is invalid")
if QSB.EffectNameToID[self.EffectName]and
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])then return end;local Lsvt0Xp,Js8fS1VE=Logic.GetEntityPosition(_Nz)
local nfU=tonumber(self.Orientation)
local Zt78U=Logic.CreateEffectWithOrientation(self.Type,Lsvt0Xp,Js8fS1VE,nfU,self.PlayerID)if self.EffectName~=""then
QSB.EffectNameToID[self.EffectName]=Zt78U end end
function b_Reward_CreateEffect:DEBUG(B_tZsz)
if QSB.EffectNameToID[self.EffectName]and
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])then
dbg(""..B_tZsz.Identifier.." "..self.Name..
": effect already exists!")return true elseif not IsExisting(self.Location)then
dbg(""..B_tZsz.Identifier.." "..
self.Name..
": location '"..self.Location.."' is missing!")return true elseif self.PlayerID and
(self.PlayerID<0 or self.PlayerID>8)then
dbg(""..B_tZsz.Identifier.." "..
self.Name..": invalid playerID!")return true elseif tonumber(self.Orientation)==nil then
dbg(""..B_tZsz.Identifier.." "..self.Name..
": invalid orientation!")return true end end
function b_Reward_CreateEffect:GetCustomData(NUeM)
assert(NUeM==1,"Error in "..
self.Name..": GetCustomData: Index is invalid.")local DiSdlMR3={}
for nE,CIkqRkzw in pairs(EGL_Effects)do table.insert(DiSdlMR3,nE)end;table.sort(DiSdlMR3)return DiSdlMR3 end;Core:RegisterBehavior(b_Reward_CreateEffect)function Reward_CreateEntity(...)return
b_Reward_CreateEntity:new(...)end
b_Reward_CreateEntity={Name="Reward_CreateEntity",Description={en="Reward: Replaces an entity by a new one of a given type",de="Lohn: Ersetzt eine Entity durch eine neue gegebenen Typs"},Parameter={{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}function b_Reward_CreateEntity:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_CreateEntity:AddParameter(sBI,vyewX)
if(
sBI==0)then self.ScriptNameEntity=vyewX elseif(sBI==1)then self.PlayerID=vyewX*1 elseif
(sBI==2)then self.UnitKey=vyewX elseif(sBI==3)then self.Orientation=vyewX*1 elseif(sBI==4)then
self.HideFromAI=AcceptAlternativeBoolean(vyewX)end end
function b_Reward_CreateEntity:CustomFunction(ZXMlRMR)if
not IsExisting(self.ScriptNameEntity)then return false end
local CCo8Y=GetPosition(self.ScriptNameEntity)local hx1fY90
if
Logic.IsEntityTypeInCategory(self.UnitKey,EntityCategories.Soldier)==1 then
hx1fY90=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],CCo8Y.X,CCo8Y.Y,self.Orientation,self.PlayerID,1)
local HBjl,tcVr={Logic.GetSoldiersAttachedToLeader(hx1fY90)}Logic.SetOrientation(tcVr,self.Orientation)else
hx1fY90=Logic.CreateEntityOnUnblockedLand(Entities[self.UnitKey],CCo8Y.X,CCo8Y.Y,self.Orientation,self.PlayerID)end;local dt7v=GetID(self.ScriptNameEntity)if
Logic.IsBuilding(dt7v)==0 then DestroyEntity(self.ScriptNameEntity)
Logic.SetEntityName(hx1fY90,self.ScriptNameEntity)end;if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,hx1fY90,true)end end
function b_Reward_CreateEntity:GetCustomData(r)local htj={}
if r==2 then
for Ltq_xgJ,Re in pairs(Entities)do
local cG3HJLZ={"^M_*","^XS_*","^X_*","^XT_*","^Z_*"}local LG=false;for x__e0OAv=1,#cG3HJLZ do
if Ltq_xgJ:find(cG3HJLZ[x__e0OAv])then LG=true;break end end;if not LG then
table.insert(htj,Ltq_xgJ)end end;table.sort(htj)elseif r==4 or r==5 then table.insert(htj,"false")
table.insert(htj,"true")else assert(false)end;return htj end
function b_Reward_CreateEntity:DEBUG(F9)
if not Entities[self.UnitKey]then
dbg(F9.Identifier.." "..
self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
dbg(F9.Identifier.." "..
self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<0 or self.PlayerID>8 then
dbg(F9.Identifier.." "..self.Name..
": playerID is not valid!")return true elseif tonumber(self.Orientation)==nil then
dbg(F9.Identifier.." "..self.Name..
": orientation must be a number!")return true end;return false end;Core:RegisterBehavior(b_Reward_CreateEntity)function Reward_CreateSeveralEntities(...)return
b_Reward_CreateSeveralEntities:new(...)end
b_Reward_CreateSeveralEntities={Name="Reward_CreateSeveralEntities",Description={en="Reward: Creating serveral battalions at the position of a entity. They retains the entities name and a _[index] suffix",de="Lohn: Erzeugt mehrere Entities an der Position der Entity. Sie übernimmt den Namen der Script Entity und den Suffix _[index]"},Parameter={{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Orientation (in degrees)",de="Ausrichtung (in Grad)"},{ParameterType.Custom,en="Hide from AI",de="Vor KI verstecken"}}}
function b_Reward_CreateSeveralEntities:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_CreateSeveralEntities:AddParameter(IbKWp,j)
if(IbKWp==0)then self.Amount=j*1 elseif
(IbKWp==1)then self.ScriptNameEntity=j elseif(IbKWp==2)then self.PlayerID=j*1 elseif(IbKWp==3)then
self.UnitKey=j elseif(IbKWp==4)then self.Orientation=j*1 elseif(IbKWp==5)then
self.HideFromAI=AcceptAlternativeBoolean(j)end end
function b_Reward_CreateSeveralEntities:CustomFunction(nY4CweuF)if
not IsExisting(self.ScriptNameEntity)then return false end
local Ttb=GetPosition(self.ScriptNameEntity)local wIat2P0
for m7M=1,self.Amount do
if
Logic.IsEntityTypeInCategory(self.UnitKey,EntityCategories.Soldier)==1 then
wIat2P0=Logic.CreateBattalionOnUnblockedLand(Entities[self.UnitKey],Ttb.X,Ttb.Y,self.Orientation,self.PlayerID,1)
local J8,VchN={Logic.GetSoldiersAttachedToLeader(wIat2P0)}Logic.SetOrientation(VchN,self.Orientation)else
wIat2P0=Logic.CreateEntityOnUnblockedLand(Entities[self.UnitKey],Ttb.X,Ttb.Y,self.Orientation,self.PlayerID)end
Logic.SetEntityName(wIat2P0,self.ScriptNameEntity.."_"..m7M)if self.HideFromAI then
AICore.HideEntityFromAI(self.PlayerID,wIat2P0,true)end end end
function b_Reward_CreateSeveralEntities:GetCustomData(ws7lX6m_)local cXif={}
if ws7lX6m_==3 then
for UV,o6kB in pairs(Entities)do
local sdfJ={"^M_*","^XS_*","^X_*","^XT_*","^Z_*"}local uwuecWs=false
for l=1,#sdfJ do if UV:find(sdfJ[l])then uwuecWs=true;break end end;if not uwuecWs then table.insert(cXif,UV)end end;table.sort(cXif)elseif ws7lX6m_==5 or ws7lX6m_==6 then
table.insert(cXif,"false")table.insert(cXif,"true")else assert(false)end;return cXif end
function b_Reward_CreateSeveralEntities:DEBUG(xhVT42E)
if not Entities[self.UnitKey]then
dbg(
xhVT42E.Identifier.." "..self.Name..": got an invalid entity type!")return true elseif not IsExisting(self.ScriptNameEntity)then
dbg(xhVT42E.Identifier..
" "..self.Name..": spawnpoint does not exist!")return true elseif
tonumber(self.PlayerID)==nil or self.PlayerID<1 or self.PlayerID>8 then
dbg(xhVT42E.Identifier.." "..self.Name..
": spawnpoint does not exist!")return true elseif tonumber(self.Orientation)==nil then
dbg(xhVT42E.Identifier.." "..self.Name..
": orientation must be a number!")return true elseif
tonumber(self.Amount)==nil or self.Amount<0 then
dbg(xhVT42E.Identifier..
" "..self.Name..": amount can not be negative!")return true end;return false end
Core:RegisterBehavior(b_Reward_CreateSeveralEntities)
function Reward_MoveSettler(...)return b_Reward_MoveSettler:new(...)end
b_Reward_MoveSettler={Name="Reward_MoveSettler",Description={en="Reward: Moves a (NPC) settler to a destination. Must not be AI controlled, or it won't move",de="Lohn: Bewegt einen (NPC) Siedler zu einem Zielort. Darf keinem KI Spieler gehören, ansonsten wird sich der Siedler nicht bewegen"},Parameter={{ParameterType.ScriptName,en="Settler",de="Siedler"},{ParameterType.ScriptName,en="Destination",de="Ziel"}}}function b_Reward_MoveSettler:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function b_Reward_MoveSettler:AddParameter(q,X)
if(
q==0)then self.ScriptNameUnit=X elseif(q==1)then self.ScriptNameDest=X end end
function b_Reward_MoveSettler:CustomFunction(A)if

Logic.IsEntityDestroyed(self.ScriptNameUnit)or Logic.IsEntityDestroyed(self.ScriptNameDest)then return false end
local la=GetID(self.ScriptNameDest)local W,Ihh6yjj=Logic.GetEntityPosition(la)
if
Logic.IsBuilding(la)==1 then W,Ihh6yjj=Logic.GetBuildingApproachPosition(la)end
Logic.MoveSettler(GetID(self.ScriptNameUnit),W,Ihh6yjj)end
function b_Reward_MoveSettler:DEBUG(q5)
if not IsExisting(self.ScriptNameUnit)then
dbg(
q5.Identifier.." "..self.Name..": mover entity does not exist!")return true elseif not IsExisting(self.ScriptNameDest)then
dbg(q5.Identifier.." "..self.Name..
": destination does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reward_MoveSettler)function Reward_Victory()return
b_Reward_Victory:new()end
b_Reward_Victory={Name="Reward_Victory",Description={en="Reward: The player wins the game.",de="Lohn: Der Spieler gewinnt das Spiel."}}
function b_Reward_Victory:GetRewardTable()return{Reward.Victory}end;Core:RegisterBehavior(b_Reward_Victory)function Reward_Defeat()return
b_Reward_Defeat:new()end
b_Reward_Defeat={Name="Reward_Defeat",Description={en="Reward: The player loses the game.",de="Lohn: Der Spieler verliert das Spiel."}}function b_Reward_Defeat:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_Defeat:CustomFunction(hgc6Q)
hgc6Q:TerminateEventsAndStuff()
Logic.ExecuteInLuaLocalState("GUI_Window.MissionEndScreenSetVictoryReasonText("..
g_VictoryAndDefeatType.DefeatMissionFailed..")")Defeated(hgc6Q.ReceivingPlayer)end;Core:RegisterBehavior(b_Reward_Defeat)function Reward_FakeVictory()return
b_Reward_FakeVictory:new()end
b_Reward_FakeVictory={Name="Reward_FakeVictory",Description={en="Reward: Display a victory icon for a quest",de="Lohn: Zeigt ein Siegesicon fuer diese Quest"}}
function b_Reward_FakeVictory:GetRewardTable()return{Reward.FakeVictory}end;Core:RegisterBehavior(b_Reward_FakeVictory)
function Reward_AI_SpawnAndAttackTerritory(...)return
b_Reward_AI_SpawnAndAttackTerritory:new(...)end
b_Reward_AI_SpawnAndAttackTerritory={Name="Reward_AI_SpawnAndAttackTerritory",Description={en="Reward: Spawns AI troops and attacks a territory (Hint: Use for hidden quests as a surprise)",de="Lohn: Erstellt KI Truppen und greift ein Territorium an (Tipp: Fuer eine versteckte Quest als Ueberraschung verwenden)"},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.ScriptName,en="Spawn point",de="Erstellungsort"},{ParameterType.TerritoryName,en="Territory",de="Territorium"},{ParameterType.Number,en="Sword",de="Schwert"},{ParameterType.Number,en="Bow",de="Bogen"},{ParameterType.Number,en="Catapults",de="Katapulte"},{ParameterType.Number,en="Siege towers",de="Belagerungstuerme"},{ParameterType.Number,en="Rams",de="Rammen"},{ParameterType.Number,en="Ammo carts",de="Munitionswagen"},{ParameterType.Custom,en="Soldier type",de="Soldatentyp"},{ParameterType.Custom,en="Reuse troops",de="Verwende bestehende Truppen"}}}
function b_Reward_AI_SpawnAndAttackTerritory:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_SpawnAndAttackTerritory:AddParameter(mIJ_kc4,J)
if(mIJ_kc4 ==0)then
self.AIPlayerID=J*1 elseif(mIJ_kc4 ==1)then self.Spawnpoint=J elseif(mIJ_kc4 ==2)then
self.TerritoryID=tonumber(J)
if not self.TerritoryID then self.TerritoryID=GetTerritoryIDByName(J)end elseif(mIJ_kc4 ==3)then self.NumSword=J*1 elseif(mIJ_kc4 ==4)then self.NumBow=J*1 elseif
(mIJ_kc4 ==5)then self.NumCatapults=J*1 elseif(mIJ_kc4 ==6)then self.NumSiegeTowers=J*1 elseif
(mIJ_kc4 ==7)then self.NumRams=J*1 elseif(mIJ_kc4 ==8)then self.NumAmmoCarts=J*1 elseif(mIJ_kc4 ==9)then
if J==
"Normal"or J==false then self.TroopType=false elseif
J=="RedPrince"or J==true then self.TroopType=true elseif J=="Bandit"or J==2 then self.TroopType=2 elseif
J=="Cultist"or J==3 then self.TroopType=3 else assert(false)end elseif(mIJ_kc4 ==10)then
self.ReuseTroops=AcceptAlternativeBoolean(J)end end
function b_Reward_AI_SpawnAndAttackTerritory:GetCustomData(uUw95D)local KRLJOGI={}
if uUw95D==9 then
table.insert(KRLJOGI,"Normal")table.insert(KRLJOGI,"RedPrince")
table.insert(KRLJOGI,"Bandit")
if g_GameExtraNo>=1 then table.insert(KRLJOGI,"Cultist")end elseif uUw95D==10 then table.insert(KRLJOGI,"false")
table.insert(KRLJOGI,"true")else assert(false)end;return KRLJOGI end
function b_Reward_AI_SpawnAndAttackTerritory:CustomFunction(Gns3m_)
local f=Logic.GetTerritoryAcquiringBuildingID(self.TerritoryID)
if f~=0 then
AIScript_SpawnAndAttackCity(self.AIPlayerID,f,self.Spawnpoint,self.NumSword,self.NumBow,self.NumCatapults,self.NumSiegeTowers,self.NumRams,self.NumAmmoCarts,self.TroopType,self.ReuseTroops)end end
function b_Reward_AI_SpawnAndAttackTerritory:DEBUG(_zxBo)
if self.AIPlayerID<2 then
dbg(_zxBo.Identifier..": Error in "..

self.Name..": Player "..self.AIPlayerID.." is wrong")return true elseif Logic.IsEntityDestroyed(self.Spawnpoint)then
dbg(_zxBo.Identifier.." "..
self.Name..
": Entity "..self.SpawnPoint.." is missing")return true elseif self.TerritoryID==0 then
dbg(_zxBo.Identifier..
" "..self.Name..": Territory unknown")return true elseif self.NumSword<0 then
dbg(_zxBo.Identifier.." "..
self.Name..": Number of Swords is negative")return true elseif self.NumBow<0 then
dbg(_zxBo.Identifier.." "..
self.Name..": Number of Bows is negative")return true elseif self.NumBow+self.NumSword<1 then
dbg(_zxBo.Identifier.." "..self.Name..
": No Soldiers?")return true elseif self.NumCatapults<0 then
dbg(_zxBo.Identifier.." "..
self.Name..": Catapults is negative")return true elseif self.NumSiegeTowers<0 then
dbg(_zxBo.Identifier.." "..
self.Name..": SiegeTowers is negative")return true elseif self.NumRams<0 then
dbg(_zxBo.Identifier..
" "..self.Name..": Rams is negative")return true elseif self.NumAmmoCarts<0 then
dbg(_zxBo.Identifier.." "..
self.Name..": AmmoCarts is negative")return true end;return false end
Core:RegisterBehavior(b_Reward_AI_SpawnAndAttackTerritory)function Reward_AI_SpawnAndAttackArea(...)
return b_Reward_AI_SpawnAndAttackArea:new(...)end
b_Reward_AI_SpawnAndAttackArea={Name="Reward_AI_SpawnAndAttackArea",Description={en="Reward: Spawns AI troops and attacks everything within the specified area, except the players main buildings",de="Lohn: Erstellt KI Truppen und greift ein angegebenes Gebiet an, aber nicht die Hauptgebauede eines Spielers"},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.ScriptName,en="Spawn point",de="Erstellungsort"},{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Number,en="Radius",de="Radius"},{ParameterType.Number,en="Sword",de="Schwert"},{ParameterType.Number,en="Bow",de="Bogen"},{ParameterType.Custom,en="Soldier type",de="Soldatentyp"},{ParameterType.Custom,en="Reuse troops",de="Verwende bestehende Truppen"}}}
function b_Reward_AI_SpawnAndAttackArea:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_SpawnAndAttackArea:AddParameter(gN,oZs2khg)
if(gN==0)then self.AIPlayerID=oZs2khg*1 elseif(
gN==1)then self.Spawnpoint=oZs2khg elseif(gN==2)then self.TargetName=oZs2khg elseif(gN==3)then self.Radius=
oZs2khg*1 elseif(gN==4)then self.NumSword=oZs2khg*1 elseif(gN==5)then
self.NumBow=oZs2khg*1 elseif(gN==6)then
if oZs2khg=="Normal"or oZs2khg==false then self.TroopType=false elseif
oZs2khg=="RedPrince"or oZs2khg==true then self.TroopType=true elseif
oZs2khg=="Bandit"or oZs2khg==2 then self.TroopType=2 elseif
oZs2khg=="Cultist"or oZs2khg==3 then self.TroopType=3 else assert(false)end elseif(gN==7)then self.ReuseTroops=AcceptAlternativeBoolean(oZs2khg)end end
function b_Reward_AI_SpawnAndAttackArea:GetCustomData(pSEIak)local AkjIt={}
if pSEIak==6 then
table.insert(AkjIt,"Normal")table.insert(AkjIt,"RedPrince")
table.insert(AkjIt,"Bandit")
if g_GameExtraNo>=1 then table.insert(AkjIt,"Cultist")end elseif pSEIak==7 then table.insert(AkjIt,"false")
table.insert(AkjIt,"true")else assert(false)end;return AkjIt end
function b_Reward_AI_SpawnAndAttackArea:CustomFunction(ox)
if

Logic.IsEntityAlive(self.TargetName)and Logic.IsEntityAlive(self.Spawnpoint)then local y5FoBZ5=GetID(self.TargetName)
AIScript_SpawnAndRaidSettlement(self.AIPlayerID,y5FoBZ5,self.Spawnpoint,self.Radius,self.NumSword,self.NumBow,self.TroopType,self.ReuseTroops)end end
function b_Reward_AI_SpawnAndAttackArea:DEBUG(VXwusjUq)
if self.AIPlayerID<2 then
dbg(VXwusjUq.Identifier.." "..
self.Name..
": Player "..self.AIPlayerID.." is wrong")return true elseif Logic.IsEntityDestroyed(self.Spawnpoint)then
dbg(VXwusjUq.Identifier.." "..
self.Name..
": Entity "..self.SpawnPoint.." is missing")return true elseif Logic.IsEntityDestroyed(self.TargetName)then
dbg(VXwusjUq.Identifier.." "..
self.Name..
": Entity "..self.TargetName.." is missing")return true elseif self.Radius<1 then
dbg(VXwusjUq.Identifier.." "..
self.Name..": Radius is to small or negative")return true elseif self.NumSword<0 then
dbg(VXwusjUq.Identifier.." "..
self.Name..": Number of Swords is negative")return true elseif self.NumBow<0 then
dbg(VXwusjUq.Identifier.." "..
self.Name..": Number of Bows is negative")return true elseif self.NumBow+self.NumSword<1 then
dbg(VXwusjUq.Identifier..": Error in "..
self.Name..": No Soldiers?")return true end;return false end
Core:RegisterBehavior(b_Reward_AI_SpawnAndAttackArea)function Reward_AI_SpawnAndProtectArea(...)
return b_Reward_AI_SpawnAndProtectArea:new(...)end
b_Reward_AI_SpawnAndProtectArea={Name="Reward_AI_SpawnAndProtectArea",Description={en="Reward: Spawns AI troops and defends a specified area",de="Lohn: Erstellt KI Truppen und verteidigt ein angegebenes Gebiet"},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.ScriptName,en="Spawn point",de="Erstellungsort"},{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Number,en="Radius",de="Radius"},{ParameterType.Number,en="Time (-1 for infinite)",de="Zeit (-1 fuer unendlich)"},{ParameterType.Number,en="Sword",de="Schwert"},{ParameterType.Number,en="Bow",de="Bogen"},{ParameterType.Custom,en="Capture tradecarts",de="Handelskarren angreifen"},{ParameterType.Custom,en="Soldier type",de="Soldatentyp"},{ParameterType.Custom,en="Reuse troops",de="Verwende bestehende Truppen"}}}
function b_Reward_AI_SpawnAndProtectArea:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_SpawnAndProtectArea:AddParameter(xP7ck,Bu1tX_x3)
if(xP7ck==0)then
self.AIPlayerID=Bu1tX_x3*1 elseif(xP7ck==1)then self.Spawnpoint=Bu1tX_x3 elseif(xP7ck==2)then self.TargetName=Bu1tX_x3 elseif(
xP7ck==3)then self.Radius=Bu1tX_x3*1 elseif(xP7ck==4)then
self.Time=Bu1tX_x3*1 elseif(xP7ck==5)then self.NumSword=Bu1tX_x3*1 elseif(xP7ck==6)then
self.NumBow=Bu1tX_x3*1 elseif(xP7ck==7)then
self.CaptureTradeCarts=AcceptAlternativeBoolean(Bu1tX_x3)elseif(xP7ck==8)then
if Bu1tX_x3 =="Normal"or Bu1tX_x3 ==true then
self.TroopType=false elseif Bu1tX_x3 =="RedPrince"or Bu1tX_x3 ==false then
self.TroopType=true elseif Bu1tX_x3 =="Bandit"or Bu1tX_x3 ==2 then self.TroopType=2 elseif
Bu1tX_x3 =="Cultist"or Bu1tX_x3 ==3 then self.TroopType=3 else assert(false)end elseif(xP7ck==9)then
self.ReuseTroops=AcceptAlternativeBoolean(Bu1tX_x3)end end
function b_Reward_AI_SpawnAndProtectArea:GetCustomData(m0)local n={}
if m0 ==7 then
table.insert(n,"false")table.insert(n,"true")elseif m0 ==8 then
table.insert(n,"Normal")table.insert(n,"RedPrince")
table.insert(n,"Bandit")
if g_GameExtraNo>=1 then table.insert(n,"Cultist")end elseif m0 ==9 then table.insert(n,"false")table.insert(n,"true")else
assert(false)end;return n end
function b_Reward_AI_SpawnAndProtectArea:CustomFunction(Q)
if

Logic.IsEntityAlive(self.TargetName)and Logic.IsEntityAlive(self.Spawnpoint)then local CoiGQD=GetID(self.TargetName)
AIScript_SpawnAndProtectArea(self.AIPlayerID,CoiGQD,self.Spawnpoint,self.Radius,self.NumSword,self.NumBow,self.Time,self.TroopType,self.ReuseTroops,self.CaptureTradeCarts)end end
function b_Reward_AI_SpawnAndProtectArea:DEBUG(KR7)
if self.AIPlayerID<2 then
dbg(KR7.Identifier.." "..
self.Name..
": Player "..self.AIPlayerID.." is wrong")return true elseif Logic.IsEntityDestroyed(self.Spawnpoint)then
dbg(KR7.Identifier..
" "..self.Name..": Entity "..
self.SpawnPoint.." is missing")return true elseif Logic.IsEntityDestroyed(self.TargetName)then
dbg(KR7.Identifier..
" "..self.Name..": Entity "..
self.TargetName.." is missing")return true elseif self.Radius<1 then
dbg(KR7.Identifier.." "..
self.Name..": Radius is to small or negative")return true elseif self.Time<-1 then
dbg(KR7.Identifier..
" "..self.Name..": Time is smaller than -1")return true elseif self.NumSword<0 then
dbg(KR7.Identifier.." "..
self.Name..": Number of Swords is negative")return true elseif self.NumBow<0 then
dbg(KR7.Identifier.." "..
self.Name..": Number of Bows is negative")return true elseif self.NumBow+self.NumSword<1 then
dbg(KR7.Identifier.." "..self.Name..
": No Soldiers?")return true end;return false end
Core:RegisterBehavior(b_Reward_AI_SpawnAndProtectArea)function Reward_AI_SetNumericalFact(...)
return b_Reward_AI_SetNumericalFact:new(...)end
b_Reward_AI_SetNumericalFact={Name="Reward_AI_SetNumericalFact",Description={en="Reward: Sets a numerical fact for the AI player",de="Lohn: Setzt eine Verhaltensregel fuer den KI-Spieler. "},Parameter={{ParameterType.PlayerID,en="AI Player",de="KI Spieler"},{ParameterType.Custom,en="Numerical Fact",de="Verhaltensregel"},{ParameterType.Number,en="Value",de="Wert"}}}
function b_Reward_AI_SetNumericalFact:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_SetNumericalFact:AddParameter(a,P5)
if(a==0)then self.AIPlayerID=P5*1 elseif(a==1)then
local h={["Courage"]="FEAR",["Reconstruction"]="BARB",["Build Order"]="BPMX",["Conquer Outposts"]="FCOP",["Mount Outposts"]="FMOP",["max. Bowmen"]="FMBM",["max. Swordmen"]="FMSM",["max. Rams"]="FMRA",["max. Catapults"]="FMCA",["max. Ammunition Carts"]="FMAC",["max. Siege Towers"]="FMST",["max. Wall Catapults"]="FMBA",["FEAR"]="FEAR",["BARB"]="BARB",["BPMX"]="BPMX",["FCOP"]="FCOP",["FMOP"]="FMOP",["FMBM"]="FMBM",["FMSM"]="FMSM",["FMRA"]="FMRA",["FMCA"]="FMCA",["FMAC"]="FMAC",["FMST"]="FMST",["FMBA"]="FMBA"}self.NumericalFact=h[P5]elseif(a==2)then self.Value=P5*1 end end;function b_Reward_AI_SetNumericalFact:CustomFunction(TCVpKFp)
AICore.SetNumericalFact(self.AIPlayerID,self.NumericalFact,self.Value)end
function b_Reward_AI_SetNumericalFact:GetCustomData(NY)
if(
NY==1)then
return
{"Courage","Reconstruction","Build Order","Conquer Outposts","Mount Outposts","max. Bowmen","max. Swordmen","max. Rams","max. Catapults","max. Ammunition Carts","max. Siege Towers","max. Wall Catapults"}end end
function b_Reward_AI_SetNumericalFact:DEBUG(hEVRc)
if
Logic.GetStoreHouse(self.AIPlayerID)==0 then
dbg(hEVRc.Identifier.." "..self.Name..
": Player "..self.AIPlayerID.." is wrong or dead!")return true elseif not self.NumericalFact then
dbg(hEVRc.Identifier.." "..
self.Name..": invalid numerical fact choosen!")return true else
if
self.NumericalFact=="BARB"or self.NumericalFact=="FCOP"or self.NumericalFact=="FMOP"then
if
self.Value~=0 and self.Value~=1 then
dbg(hEVRc.Identifier.." "..self.Name..
": BARB, FCOP, FMOP: value must be 1 or 0!")return true end elseif self.NumericalFact=="FEAR"then if self.Value<=0 then
dbg(hEVRc.Identifier.." "..self.Name..
": FEAR: value must greater than 0!")return true end else if
self.Value<0 then
dbg(hEVRc.Identifier..
" "..self.Name..": value must always greater than or equal 0!")return true end end end;return false end
Core:RegisterBehavior(b_Reward_AI_SetNumericalFact)function Reward_AI_Aggressiveness(...)
return b_Reward_AI_Aggressiveness:new(...)end
b_Reward_AI_Aggressiveness={Name="Reward_AI_Aggressiveness",Description={en="Reward: Sets the AI player's aggressiveness.",de="Lohn: Setzt die Aggressivität des KI-Spielers fest."},Parameter={{ParameterType.PlayerID,en="AI player",de="KI-Spieler"},{ParameterType.Custom,en="Aggressiveness (1-3)",de="Aggressivität (1-3)"}}}
function b_Reward_AI_Aggressiveness:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_Aggressiveness:AddParameter(BA6zaoJ,Y7)if BA6zaoJ==0 then self.AIPlayer=Y7*1 elseif BA6zaoJ==1 then
self.Aggressiveness=tonumber(Y7)end end
function b_Reward_AI_Aggressiveness:CustomFunction()
local g=(PlayerAIs[self.AIPlayer]or
AIPlayerTable[self.AIPlayer]or
AIPlayer:new(self.AIPlayer,AIPlayerProfile_City))PlayerAIs[self.AIPlayer]=g
if self.Aggressiveness>=2 then
g.m_ProfileLoop=AIProfile_Skirmish;g.Skirmish=g.Skirmish or{}
g.Skirmish.Claim_MinTime=SkirmishDefault.Claim_MinTime+ (
self.Aggressiveness-2)*390;g.Skirmish.Claim_MaxTime=g.Skirmish.Claim_MinTime*2 else
g.m_ProfileLoop=AIPlayerProfile_City end end
function b_Reward_AI_Aggressiveness:DEBUG(jtL2)
if self.AIPlayer<2 or
Logic.GetStoreHouse(self.AIPlayer)==0 then
dbg(jtL2.Identifier..
": Error in "..self.Name..
": Player "..self.PlayerID.." is wrong")return true end end
function b_Reward_AI_Aggressiveness:GetCustomData(DA)
assert(DA==1,"Error in "..
self.Name..": GetCustomData: Index is invalid.")return{"1","2","3"}end;Core:RegisterBehavior(b_Reward_AI_Aggressiveness)function Reward_AI_SetEnemy(...)return
b_Reward_AI_SetEnemy:new(...)end
b_Reward_AI_SetEnemy={Name="Reward_AI_SetEnemy",Description={en="Reward:Sets the enemy of an AI player (the AI only handles one enemy properly).",de="Lohn: Legt den Feind eines KI-Spielers fest (die KI behandelt nur einen Feind korrekt)."},Parameter={{ParameterType.PlayerID,en="AI player",de="KI-Spieler"},{ParameterType.PlayerID,en="Enemy",de="Feind"}}}function b_Reward_AI_SetEnemy:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function b_Reward_AI_SetEnemy:AddParameter(d7K3,Ozih058u)
if
d7K3 ==0 then self.AIPlayer=Ozih058u*1 elseif d7K3 ==1 then self.Enemy=Ozih058u*1 end end
function b_Reward_AI_SetEnemy:CustomFunction()
local oW9bf=PlayerAIs[self.AIPlayer]
if oW9bf and oW9bf.Skirmish then oW9bf.Skirmish.Enemy=self.Enemy end end
function b_Reward_AI_SetEnemy:DEBUG(u)
if self.AIPlayer<=1 or self.AIPlayer>=8 or
Logic.PlayerGetIsHumanFlag(self.AIPlayer)then
dbg(u.Identifier..
": Error in "..self.Name..": Player "..
self.AIPlayer.." is wrong")return true end;return false end;Core:RegisterBehavior(b_Reward_AI_SetEnemy)function Reward_ReplaceEntity(...)return
b_Reward_ReplaceEntity:new(...)end
b_Reward_ReplaceEntity=API.InstanceTable(b_Reprisal_ReplaceEntity)b_Reward_ReplaceEntity.Name="Reward_ReplaceEntity"
b_Reward_ReplaceEntity.Description.en="Reward: Replaces an entity with a new one of a different type. The playerID can be changed too."
b_Reward_ReplaceEntity.Description.de="Lohn: Ersetzt eine Entity durch eine neue anderen Typs. Es kann auch die Spielerzugehörigkeit geändert werden."b_Reward_ReplaceEntity.GetReprisalTable=nil
b_Reward_ReplaceEntity.GetRewardTable=function(rZrrL,E4a)return
{Reward.Custom,{rZrrL,rZrrL.CustomFunction}}end;Core:RegisterBehavior(b_Reward_ReplaceEntity)function Reward_SetResourceAmount(...)return
b_Reward_SetResourceAmount:new(...)end
b_Reward_SetResourceAmount={Name="Reward_SetResourceAmount",Description={en="Reward: Set the current and maximum amount of a resource doodad (the amount can also set to 0)",de="Lohn: Setzt die aktuellen sowie maximalen Resourcen in einem Doodad (auch 0 ist möglich)"},Parameter={{ParameterType.ScriptName,en="Ressource",de="Resource"},{ParameterType.Number,en="Amount",de="Menge"}}}
function b_Reward_SetResourceAmount:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_SetResourceAmount:AddParameter(QXFNNY,e)if(QXFNNY==0)then self.ScriptName=e elseif
(QXFNNY==1)then self.Amount=e*1 end end
function b_Reward_SetResourceAmount:CustomFunction(BH)if
Logic.IsEntityDestroyed(self.ScriptName)then return false end
local xD=GetID(self.ScriptName)
if Logic.GetResourceDoodadGoodType(xD)==0 then return false end
Logic.SetResourceDoodadGoodAmount(xD,self.Amount)end
function b_Reward_SetResourceAmount:DEBUG(fl)
if not IsExisting(self.ScriptName)then
dbg(
fl.Identifier.." "..self.Name..": resource entity does not exist!")return true elseif
not type(self.Amount)=="number"or self.Amount<0 then
dbg(fl.Identifier..
" "..self.Name..": resource amount can not be negative!")return true end;return false end;Core:RegisterBehavior(b_Reward_SetResourceAmount)function Reward_Resources(...)return
b_Reward_Resources:new(...)end
b_Reward_Resources={Name="Reward_Resources",Description={en="Reward: The player receives a given amount of Goods in his store.",de="Lohn: Legt der Partei die angegebenen Rohstoffe ins Lagerhaus."},Parameter={{ParameterType.RawGoods,en="Type of good",de="Resourcentyp"},{ParameterType.Number,en="Amount of good",de="Anzahl der Resource"}}}
function b_Reward_Resources:AddParameter(QCv,qd_HCf)if(QCv==0)then self.GoodTypeName=qd_HCf elseif(QCv==1)then self.GoodAmount=
qd_HCf*1 end end
function b_Reward_Resources:GetRewardTable()
local CU=Logic.GetGoodTypeID(self.GoodTypeName)return{Reward.Resources,CU,self.GoodAmount}end;Core:RegisterBehavior(b_Reward_Resources)function Reward_SendCart(...)return
b_Reward_SendCart:new(...)end
b_Reward_SendCart={Name="Reward_SendCart",Description={en="Reward: Sends a cart to a player. It spawns at a building or by replacing an entity. The cart can replace the entity if it's not a building.",de="Lohn: Sendet einen Karren zu einem Spieler. Der Karren wird an einem Gebäude oder einer Entity erstellt. Er ersetzt die Entity, wenn diese kein Gebäude ist."},Parameter={{ParameterType.ScriptName,en="Script entity",de="Script Entity"},{ParameterType.PlayerID,en="Owning player",de="Besitzer"},{ParameterType.Custom,en="Type name",de="Typbezeichnung"},{ParameterType.Custom,en="Good type",de="Warentyp"},{ParameterType.Number,en="Amount",de="Anzahl"},{ParameterType.Custom,en="Override target player",de="Anderer Zielspieler"},{ParameterType.Custom,en="Ignore reservations",de="Ignoriere Reservierungen"},{ParameterType.Custom,en="Replace entity",de="Entity ersetzen"}}}function b_Reward_SendCart:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_SendCart:AddParameter(M1ywSQ,g)
if(
M1ywSQ==0)then self.ScriptNameEntity=g elseif(M1ywSQ==1)then self.PlayerID=g*1 elseif
(M1ywSQ==2)then self.UnitKey=g elseif(M1ywSQ==3)then self.GoodType=g elseif(M1ywSQ==4)then
self.GoodAmount=g*1 elseif(M1ywSQ==5)then self.OverrideTargetPlayer=tonumber(g)elseif(M1ywSQ==6)then
self.IgnoreReservation=AcceptAlternativeBoolean(g)elseif(M1ywSQ==7)then self.ReplaceEntity=AcceptAlternativeBoolean(g)end end
function b_Reward_SendCart:CustomFunction(hPc4e3hn)if
not IsExisting(self.ScriptNameEntity)then return false end
local m=SendCart(self.ScriptNameEntity,self.PlayerID,Goods[self.GoodType],self.GoodAmount,Entities[self.UnitKey],self.IgnoreReservation)
if self.ReplaceEntity and
Logic.IsBuilding(GetID(self.ScriptNameEntity))==0 then
DestroyEntity(self.ScriptNameEntity)Logic.SetEntityName(m,self.ScriptNameEntity)end;if self.OverrideTargetPlayer then
Logic.ResourceMerchant_OverrideTargetPlayerID(m,self.OverrideTargetPlayer)end end
function b_Reward_SendCart:GetCustomData(Rlb)local KgX={}
if Rlb==2 then
KgX={"U_ResourceMerchant","U_Medicus","U_Marketer","U_ThiefCart","U_GoldCart","U_Noblemen_Cart","U_RegaliaCart"}elseif Rlb==3 then for SXr,IZQg6shq in pairs(Goods)do
if string.find(SXr,"^G_")then table.insert(KgX,SXr)end end;table.sort(KgX)elseif
Rlb==5 then table.insert(KgX,"-")
for bz=1,8 do table.insert(KgX,bz)end elseif Rlb==6 then table.insert(KgX,"false")
table.insert(KgX,"true")elseif Rlb==7 then table.insert(KgX,"false")
table.insert(KgX,"true")end;return KgX end
function b_Reward_SendCart:DEBUG(wL)
if not IsExisting(self.ScriptNameEntity)then
dbg(
wL.Identifier.." "..self.Name..": spawnpoint does not exist!")return true elseif
not tonumber(self.PlayerID)or self.PlayerID<1 or self.PlayerID>8 then
dbg(wL.Identifier.." "..self.Name..
": got a invalid playerID!")return true elseif not Entities[self.UnitKey]then
dbg(wL.Identifier.." "..
self.Name..": entity type '"..
self.UnitKey.."' is invalid!")return true elseif not Goods[self.GoodType]then
dbg(wL.Identifier..
" "..self.Name..": good type '"..self.GoodType..
"' is invalid!")return true elseif
not tonumber(self.GoodAmount)or self.GoodAmount<1 then
dbg(wL.Identifier..
" "..self.Name..": good amount can not be below 1!")return true elseif
tonumber(self.OverrideTargetPlayer)and(self.OverrideTargetPlayer<1 or
self.OverrideTargetPlayer>8)then
dbg(wL.Identifier..
" "..self.Name..": overwrite target player with invalid playerID!")return true end;return false end;Core:RegisterBehavior(b_Reward_SendCart)function Reward_Units(...)return
b_Reward_Units:new(...)end
b_Reward_Units={Name="Reward_Units",Description={en="Reward: Units",de="Lohn: Einheiten"},Parameter={{ParameterType.Entity,en="Type name",de="Typbezeichnung"},{ParameterType.Number,en="Amount",de="Anzahl"}}}
function b_Reward_Units:AddParameter(BSDnLt_,vQ6pTDbn)if(BSDnLt_==0)then self.EntityName=vQ6pTDbn elseif
(BSDnLt_==1)then self.Amount=vQ6pTDbn*1 end end
function b_Reward_Units:GetRewardTable()return
{Reward.Units,assert(Entities[self.EntityName]),self.Amount}end;Core:RegisterBehavior(b_Reward_Units)function Reward_QuestRestart(...)return
b_Reward_QuestRestart:new(...)end
b_Reward_QuestRestart=API.InstanceTable(b_Reprisal_QuestRestart)b_Reward_QuestRestart.Name="Reward_QuestRestart"
b_Reward_QuestRestart.Description.en="Reward: Restarts a (completed) quest so it can be triggered and completed again."
b_Reward_QuestRestart.Description.de="Lohn: Startet eine (beendete) Quest neu, damit diese neu ausgelöst und beendet werden kann."b_Reward_QuestRestart.GetReprisalTable=nil
b_Reward_QuestRestart.GetRewardTable=function(P,W)return
{Reward.Custom,{P,P.CustomFunction}}end;Core:RegisterBehavior(b_Reward_QuestRestart)function Reward_QuestFailure(...)return
b_Reward_QuestFailure:new(...)end
b_Reward_QuestFailure=API.InstanceTable(b_Reprisal_QuestFailure)b_Reward_QuestFailure.Name="Reward_QuestFailure"
b_Reward_QuestFailure.Description.en="Reward: Lets another active quest fail."
b_Reward_QuestFailure.Description.de="Lohn: Lässt eine andere aktive Quest fehlschlagen."b_Reward_QuestFailure.GetReprisalTable=nil
b_Reward_QuestFailure.GetRewardTable=function(CDG3os,MOd9uwnL)return
{Reward.Custom,{CDG3os,CDG3os.CustomFunction}}end;Core:RegisterBehavior(b_Reward_QuestFailure)function Reward_QuestSuccess(...)return
b_Reward_QuestSuccess:new(...)end
b_Reward_QuestSuccess=API.InstanceTable(b_Reprisal_QuestSuccess)b_Reward_QuestSuccess.Name="Reward_QuestSuccess"
b_Reward_QuestSuccess.Description.en="Reward: Completes another active quest successfully."
b_Reward_QuestSuccess.Description.de="Lohn: Beendet eine andere aktive Quest erfolgreich."b_Reward_QuestSuccess.GetReprisalTable=nil
b_Reward_QuestSuccess.GetRewardTable=function(JZDx8,_XR0EY1)return
{Reward.Custom,{JZDx8,JZDx8.CustomFunction}}end;Core:RegisterBehavior(b_Reward_QuestSuccess)function Reward_QuestActivate(...)return
b_Reward_QuestActivate:new(...)end
b_Reward_QuestActivate=API.InstanceTable(b_Reprisal_QuestActivate)b_Reward_QuestActivate.Name="Reward_QuestActivate"
b_Reward_QuestActivate.Description.en="Reward: Activates another quest that is not triggered yet."
b_Reward_QuestActivate.Description.de="Lohn: Aktiviert eine andere Quest die noch nicht ausgelöst wurde."b_Reward_QuestActivate.GetReprisalTable=nil
b_Reward_QuestActivate.GetRewardTable=function(z3J,ufXNV)return
{Reward.Custom,{z3J,z3J.CustomFunction}}end;Core:RegisterBehavior(b_Reward_QuestActivate)function Reward_QuestInterrupt(...)return
b_Reward_QuestInterrupt:new(...)end
b_Reward_QuestInterrupt=API.InstanceTable(b_Reprisal_QuestInterrupt)b_Reward_QuestInterrupt.Name="Reward_QuestInterrupt"
b_Reward_QuestInterrupt.Description.en="Reward: Interrupts another active quest without success or failure."
b_Reward_QuestInterrupt.Description.de="Lohn: Beendet eine andere aktive Quest ohne Erfolg oder Misserfolg."b_Reward_QuestInterrupt.GetReprisalTable=nil
b_Reward_QuestInterrupt.GetRewardTable=function(Vum8,NQSh)return
{Reward.Custom,{Vum8,Vum8.CustomFunction}}end;Core:RegisterBehavior(b_Reward_QuestInterrupt)function Reward_QuestForceInterrupt(...)return
b_Reward_QuestForceInterrupt:new(...)end
b_Reward_QuestForceInterrupt=API.InstanceTable(b_Reprisal_QuestForceInterrupt)
b_Reward_QuestForceInterrupt.Name="Reward_QuestForceInterrupt"
b_Reward_QuestForceInterrupt.Description.en="Reward: Interrupts another quest (even when it isn't active yet) without success or failure."
b_Reward_QuestForceInterrupt.Description.de="Lohn: Beendet eine andere Quest, auch wenn diese noch nicht aktiv ist ohne Erfolg oder Misserfolg."b_Reward_QuestForceInterrupt.GetReprisalTable=nil
b_Reward_QuestForceInterrupt.GetRewardTable=function(Y1rSR,aqQh)return
{Reward.Custom,{Y1rSR,Y1rSR.CustomFunction}}end
Core:RegisterBehavior(b_Reward_QuestForceInterrupt)
function Reward_CustomVariables(...)return b_Reward_CustomVariables:new(...)end
b_Reward_CustomVariables=API.InstanceTable(b_Reprisal_CustomVariables)b_Reward_CustomVariables.Name="Reward_CustomVariables"
b_Reward_CustomVariables.Description.en="Reward: Executes a mathematical operation with this variable. The other operand can be a number or another custom variable."
b_Reward_CustomVariables.Description.de="Lohn: Fuehrt eine mathematische Operation mit der Variable aus. Der andere Operand kann eine Zahl oder eine Custom-Varible sein."b_Reward_CustomVariables.GetReprisalTable=nil
b_Reward_CustomVariables.GetRewardTable=function(H_,EQaFI0gZ)return
{Reward.Custom,{H_,H_.CustomFunction}}end;Core:RegisterBehavior(b_Reward_CustomVariables)function Reward_MapScriptFunction(...)return
b_Reward_MapScriptFunction:new(...)end
b_Reward_MapScriptFunction=API.InstanceTable(b_Reprisal_MapScriptFunction)b_Reward_MapScriptFunction.Name="Reward_MapScriptFunction"
b_Reward_MapScriptFunction.Description.en="Reward: Calls a function within the global map script if the quest has failed."
b_Reward_MapScriptFunction.Description.de="Lohn: Ruft eine Funktion im globalen Kartenskript auf, wenn die Quest fehlschlägt."b_Reward_MapScriptFunction.GetReprisalTable=nil
b_Reward_MapScriptFunction.GetRewardTable=function(kKiLOav,XW8)return
{Reward.Custom,{kKiLOav,kKiLOav.CustomFunction}}end;Core:RegisterBehavior(b_Reward_MapScriptFunction)function Reward_Technology(...)return
b_Reward_Technology:new(...)end
b_Reward_Technology=API.InstanceTable(b_Reprisal_Technology)b_Reward_Technology.Name="Reward_Technology"
b_Reward_Technology.Description.en="Reward: Locks or unlocks a technology for the given player."
b_Reward_Technology.Description.de="Lohn: Sperrt oder erlaubt eine Technolgie fuer den angegebenen Player."b_Reward_Technology.GetReprisalTable=nil
b_Reward_Technology.GetRewardTable=function(_8Ls,t_t7)return
{Reward.Custom,{_8Ls,_8Ls.CustomFunction}}end;Core:RegisterBehavior(b_Reward_Technology)function Reward_PrestigePoints(...)return
b_Reward_PrestigePoints:mew(...)end
b_Reward_PrestigePoints={Name="Reward_PrestigePoints",Description={en="Reward: Prestige",de="Lohn: Prestige"},Parameter={{ParameterType.Number,en="Points",de="Punkte"}}}function b_Reward_PrestigePoints:AddParameter(A_oCK8,o)
if(A_oCK8 ==0)then self.Points=o end end;function b_Reward_PrestigePoints:GetRewardTable()return
{Reward.PrestigePoints,self.Points}end
Core:RegisterBehavior(b_Reward_PrestigePoints)
function Reward_AI_MountOutpost(...)return b_Reward_AI_MountOutpost:new(...)end
b_Reward_AI_MountOutpost={Name="Reward_AI_MountOutpost",Description={en="Reward: Places a troop of soldiers on a named outpost.",de="Lohn: Platziert einen Trupp Soldaten auf einem Aussenposten der KI."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Soldiers type",de="Soldatentyp"}}}
function b_Reward_AI_MountOutpost:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_MountOutpost:AddParameter(ogi5Usg,pA)if ogi5Usg==0 then self.Scriptname=pA else
self.SoldiersType=pA end end
function b_Reward_AI_MountOutpost:CustomFunction(DOIqPj09)
local RoKAkM=assert(not
Logic.IsEntityDestroyed(self.Scriptname)and GetID(self.Scriptname),
DOIqPj09.Identifier..
": Error in "..self.Name..": CustomFunction: Outpost is invalid")local FETmJjQd=Logic.EntityGetPlayer(RoKAkM)
local RK,XAv=Logic.GetBuildingApproachPosition(RoKAkM)
local bdJvhbGA=Logic.CreateBattalionOnUnblockedLand(Entities[self.SoldiersType],RK,XAv,0,FETmJjQd,0)AICore.HideEntityFromAI(FETmJjQd,bdJvhbGA,true)
Logic.CommandEntityToMountBuilding(bdJvhbGA,RoKAkM)end
function b_Reward_AI_MountOutpost:GetCustomData(c9M)
if c9M==1 then local bcYXd={}
for wbw9,jFg in pairs(Entities)do if
string.find(wbw9,"U_MilitaryBandit")or string.find(wbw9,"U_MilitarySword")or
string.find(wbw9,"U_MilitaryBow")then
bcYXd[#bcYXd+1]=wbw9 end end;return bcYXd end end
function b_Reward_AI_MountOutpost:DEBUG(_3BxMtBx)
if Logic.IsEntityDestroyed(self.Scriptname)then
dbg(
_3BxMtBx.Identifier.." "..
self.Name..": Outpost "..self.Scriptname.." is missing")return true end end;Core:RegisterBehavior(b_Reward_AI_MountOutpost)function Reward_QuestRestartForceActive(...)return
b_Reward_QuestRestartForceActive:new(...)end
b_Reward_QuestRestartForceActive={Name="Reward_QuestRestartForceActive",Description={en="Reward: Restarts a (completed) quest and triggers it immediately.",de="Lohn: Startet eine (beendete) Quest neu und triggert sie sofort."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Reward_QuestRestartForceActive:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_QuestRestartForceActive:AddParameter(j5rH,mKQv1MD)
assert(j5rH==0,"Error in "..self.Name..
": AddParameter: Index is invalid.")self.QuestName=mKQv1MD end
function b_Reward_QuestRestartForceActive:CustomFunction(XvjCso)
local _R3NsF,I=self:ResetQuest(XvjCso)if _R3NsF then I:SetMsgKeyOverride()I:SetIconOverride()
I:Trigger()end end
b_Reward_QuestRestartForceActive.ResetQuest=b_Reward_QuestRestart.CustomFunction
function b_Reward_QuestRestartForceActive:DEBUG(luJe)
if not
Quests[GetQuestID(self.QuestName)]then
dbg(luJe.Identifier..
": Error in "..self.Name..": Quest: "..
self.QuestName.." does not exist")return true end;return false end
Core:RegisterBehavior(b_Reward_QuestRestartForceActive)
function Reward_UpgradeBuilding(...)return b_Reward_UpgradeBuilding:new(...)end
b_Reward_UpgradeBuilding={Name="Reward_UpgradeBuilding",Description={en="Reward: Upgrades a building",de="Lohn: Baut ein Gebäude aus"},Parameter={{ParameterType.ScriptName,en="Building",de="Gebäude"}}}
function b_Reward_UpgradeBuilding:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function b_Reward_UpgradeBuilding:AddParameter(oJ,XRK37sBn)
if oJ==0 then self.Building=XRK37sBn end end
function b_Reward_UpgradeBuilding:CustomFunction(W6W)
local HUwZ2ikl=GetID(self.Building)
if HUwZ2ikl~=0 and Logic.IsBuilding(HUwZ2ikl)==1 and
Logic.IsBuildingUpgradable(HUwZ2ikl,true)and
Logic.IsBuildingUpgradable(HUwZ2ikl,false)then
Logic.UpgradeBuilding(HUwZ2ikl)end end
function b_Reward_UpgradeBuilding:DEBUG(trUgnCUz)local CTJB=GetID(self.Building)
if not
(
CTJB~=0 and
Logic.IsBuilding(CTJB)==1 and Logic.IsBuildingUpgradable(CTJB,true)and Logic.IsBuildingUpgradable(CTJB,false))then
dbg(
trUgnCUz.Identifier.." "..self.Name..": Building is wrong")return true end end;Core:RegisterBehavior(b_Reward_UpgradeBuilding)function Trigger_PlayerDiscovered(...)return
b_Trigger_PlayerDiscovered:new(...)end
b_Trigger_PlayerDiscovered={Name="Trigger_PlayerDiscovered",Description={en="Trigger: if a given player has been discovered",de="Auslöser: wenn ein angegebener Spieler entdeckt wurde"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"}}}
function b_Trigger_PlayerDiscovered:GetTriggerTable()return
{Triggers.PlayerDiscovered,self.PlayerID}end;function b_Trigger_PlayerDiscovered:AddParameter(PK9,hd)
if(PK9 ==0)then self.PlayerID=hd*1 end end
Core:RegisterBehavior(b_Trigger_PlayerDiscovered)
function Trigger_OnDiplomacy(...)return b_Trigger_OnDiplomacy:new(...)end
b_Trigger_OnDiplomacy={Name="Trigger_OnDiplomacy",Description={en="Trigger: if diplomatic relations have been established with a player",de="Auslöser: wenn ein angegebener Diplomatie-Status mit einem Spieler erreicht wurde."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.DiplomacyState,en="Relation",de="Beziehung"}}}
function b_Trigger_OnDiplomacy:GetTriggerTable()return
{Triggers.Diplomacy,self.PlayerID,assert(DiplomacyStates[self.DiplState])}end
function b_Trigger_OnDiplomacy:AddParameter(l8vftvD,xb)if(l8vftvD==0)then self.PlayerID=xb*1 elseif
(l8vftvD==1)then self.DiplState=xb end end;Core:RegisterBehavior(b_Trigger_OnDiplomacy)function Trigger_OnNeedUnsatisfied(...)return
b_Trigger_OnNeedUnsatisfied:new(...)end
b_Trigger_OnNeedUnsatisfied={Name="Trigger_OnNeedUnsatisfied",Description={en="Trigger: if a specified need is unsatisfied",de="Auslöser: wenn ein bestimmtes Beduerfnis nicht befriedigt ist."},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.Need,en="Need",de="Beduerfnis"},{ParameterType.Number,en="Workers on strike",de="Streikende Arbeiter"}}}
function b_Trigger_OnNeedUnsatisfied:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnNeedUnsatisfied:AddParameter(KHB,RZ8IqF)
if(KHB==0)then self.PlayerID=RZ8IqF*1 elseif
(KHB==1)then self.Need=RZ8IqF elseif(KHB==2)then self.WorkersOnStrike=RZ8IqF*1 end end
function b_Trigger_OnNeedUnsatisfied:CustomFunction(FasBerA)
return
Logic.GetNumberOfStrikingWorkersPerNeed(self.PlayerID,Needs[self.Need])>=self.WorkersOnStrike end
function b_Trigger_OnNeedUnsatisfied:DEBUG(pf)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
dbg(pf.Identifier.." "..
self.Name..": "..self.PlayerID.." does not exist.")return true elseif not Needs[self.Need]then
dbg(pf.Identifier.." "..self.Name..": "..
self.Need.." does not exist.")return true elseif self.WorkersOnStrike<0 then
dbg(pf.Identifier.." "..
self.Name..": WorkersOnStrike value negative")return true end;return false end
Core:RegisterBehavior(b_Trigger_OnNeedUnsatisfied)function Trigger_OnResourceDepleted(...)
return b_Trigger_OnResourceDepleted:new(...)end
b_Trigger_OnResourceDepleted={Name="Trigger_OnResourceDepleted",Description={en="Trigger: if a resource is (temporarily) depleted",de="Auslöser: wenn eine Ressource (zeitweilig) verbraucht ist"},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}
function b_Trigger_OnResourceDepleted:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnResourceDepleted:AddParameter(ayR7Lua6,Ini5SE)if(ayR7Lua6 ==0)then
self.ScriptName=Ini5SE end end
function b_Trigger_OnResourceDepleted:CustomFunction(PyZ2PUy0)local ZiDK=GetID(self.ScriptName)
return not
ZiDK or ZiDK==0 or
Logic.GetResourceDoodadGoodType(ZiDK)==0 or
Logic.GetResourceDoodadGoodAmount(ZiDK)==0 end
Core:RegisterBehavior(b_Trigger_OnResourceDepleted)function Trigger_OnAmountOfGoods(...)
return b_Trigger_OnAmountOfGoods:new(...)end
b_Trigger_OnAmountOfGoods={Name="Trigger_OnAmountOfGoods",Description={en="Trigger: if the player has gathered a given amount of resources in his storehouse",de="Auslöser: wenn der Spieler eine bestimmte Menge einer Ressource in seinem Lagerhaus hat"},Parameter={{ParameterType.PlayerID,en="Player",de="Spieler"},{ParameterType.RawGoods,en="Type of good",de="Resourcentyp"},{ParameterType.Number,en="Amount of good",de="Anzahl der Resource"}}}
function b_Trigger_OnAmountOfGoods:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnAmountOfGoods:AddParameter(HfV,kYK3PhRd)
if(HfV==0)then self.PlayerID=kYK3PhRd*1 elseif
(HfV==1)then self.GoodTypeName=kYK3PhRd elseif(HfV==2)then self.GoodAmount=kYK3PhRd*1 end end
function b_Trigger_OnAmountOfGoods:CustomFunction(O)
local xme2_Bb=Logic.GetStoreHouse(self.PlayerID)if(xme2_Bb==0)then return false end
local ccqzSAU=Logic.GetGoodTypeID(self.GoodTypeName)
local N=Logic.GetAmountOnOutStockByGoodType(xme2_Bb,ccqzSAU)if(N>=self.GoodAmount)then return true end;return false end
function b_Trigger_OnAmountOfGoods:DEBUG(Rl1JVg)
if
Logic.GetStoreHouse(self.PlayerID)==0 then
dbg(Rl1JVg.Identifier.." "..self.Name..
": "..self.PlayerID.." does not exist.")return true elseif not Goods[self.GoodTypeName]then
dbg(Rl1JVg.Identifier.." "..self.Name..
": Good type is wrong.")return true elseif self.GoodAmount<0 then
dbg(Rl1JVg.Identifier.." "..
self.Name..": Good amount is negative.")return true end;return false end;Core:RegisterBehavior(b_Trigger_OnAmountOfGoods)function Trigger_OnQuestActive(...)return
b_Trigger_OnQuestActive:new(...)end
b_Trigger_OnQuestActive={Name="Trigger_OnQuestActive",Description={en="Trigger: if a given quest has been activated. Waiting time optional",de="Auslöser: wenn eine angegebene Quest aktiviert wurde. Optional mit Wartezeit"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function b_Trigger_OnQuestActive:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnQuestActive:AddParameter(h,nwlg80aZ)if(h==0)then self.QuestName=nwlg80aZ elseif(h==1)then
self.WaitTime=(
nwlg80aZ~=nil and tonumber(nwlg80aZ))or 0 end end
function b_Trigger_OnQuestActive:CustomFunction(B)
local PDGF=GetQuestID(self.QuestName)
if PDGF~=nil then assert(type(PDGF)=="number")
if(
Quests[PDGF].State==QuestState.Active)then self.WasActivated=self.WasActivated or
true end
if self.WasActivated then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end end;return false end
function b_Trigger_OnQuestActive:DEBUG(x_gZS_6x)
if type(self.QuestName)~="string"then
dbg(""..

x_gZS_6x.Identifier.." "..self.Name..": invalid quest name!")return true elseif self.WaitTime and
(type(self.WaitTime)~="number"or self.WaitTime<0)then
dbg(""..x_gZS_6x.Identifier.." "..
self.Name..": waitTime must be a number!")return true end;return false end;function b_Trigger_OnQuestActive:Interrupt()end
function b_Trigger_OnQuestActive:Reset()self.WaitTimeTimer=
nil;self.WasActivated=nil end;Core:RegisterBehavior(b_Trigger_OnQuestActive)function Trigger_OnQuestFailure(...)return
b_Trigger_OnQuestFailure:new(...)end
b_Trigger_OnQuestFailure={Name="Trigger_OnQuestFailure",Description={en="Trigger: if a given quest has failed. Waiting time optional",de="Auslöser: wenn eine angegebene Quest fehlgeschlagen ist. Optional mit Wartezeit"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function b_Trigger_OnQuestFailure:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnQuestFailure:AddParameter(cG,L9PPA2e)if(cG==0)then self.QuestName=L9PPA2e elseif(cG==1)then
self.WaitTime=(
L9PPA2e~=nil and tonumber(L9PPA2e))or 0 end end
function b_Trigger_OnQuestFailure:CustomFunction(JwAi)
if
(GetQuestID(self.QuestName)~=nil)then local wjgKmwQJ=GetQuestID(self.QuestName)
if(Quests[wjgKmwQJ].Result==
QuestResult.Failure)then
if
self.WaitTime and self.WaitTime>0 then
self.WaitTimeTimer=self.WaitTimeTimer or Logic.GetTime()if
Logic.GetTime()>=self.WaitTimeTimer+self.WaitTime then return true end else return true end end end;return false end
function b_Trigger_OnQuestFailure:DEBUG(Sq5Mc)
if type(self.QuestName)~="string"then
dbg(""..

Sq5Mc.Identifier.." "..self.Name..": invalid quest name!")return true elseif self.WaitTime and
(type(self.WaitTime)~="number"or self.WaitTime<0)then
dbg(""..Sq5Mc.Identifier.." "..
self.Name..": waitTime must be a number!")return true end;return false end
function b_Trigger_OnQuestFailure:Interrupt()self.WaitTimeTimer=nil end
function b_Trigger_OnQuestFailure:Reset()self.WaitTimeTimer=nil end;Core:RegisterBehavior(b_Trigger_OnQuestFailure)function Trigger_OnQuestNotTriggered(...)return
b_Trigger_OnQuestNotTriggered:new(...)end
b_Trigger_OnQuestNotTriggered={Name="Trigger_OnQuestNotTriggered",Description={en="Trigger: if a given quest is not yet active. Should be used in combination with other triggers.",de="Auslöser: wenn eine angegebene Quest noch inaktiv ist. Sollte mit weiteren Triggern kombiniert werden."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"}}}
function b_Trigger_OnQuestNotTriggered:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function b_Trigger_OnQuestNotTriggered:AddParameter(iAXm7_,fJ)
if(iAXm7_==0)then self.QuestName=fJ end end
function b_Trigger_OnQuestNotTriggered:CustomFunction(aG3O)
if(
GetQuestID(self.QuestName)~=nil)then
local M6IbY=GetQuestID(self.QuestName)if
(Quests[M6IbY].State==QuestState.NotTriggered)then return true end end;return false end
function b_Trigger_OnQuestNotTriggered:DEBUG(vxWBA)if type(self.QuestName)~="string"then
dbg(""..

vxWBA.Identifier.." "..self.Name..": invalid quest name!")return true end
return false end
Core:RegisterBehavior(b_Trigger_OnQuestNotTriggered)function Trigger_OnQuestInterrupted(...)
return b_Trigger_OnQuestInterrupted:new(...)end
b_Trigger_OnQuestInterrupted={Name="Trigger_OnQuestInterrupted",Description={en="Trigger: if a given quest has been interrupted. Should be used in combination with other triggers.",de="Auslöser: wenn eine angegebene Quest abgebrochen wurde. Sollte mit weiteren Triggern kombiniert werden."},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function b_Trigger_OnQuestInterrupted:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnQuestInterrupted:AddParameter(is,_l)if(is==0)then self.QuestName=_l elseif(is==1)then
self.WaitTime=(
_l~=nil and tonumber(_l))or 0 end end
function b_Trigger_OnQuestInterrupted:CustomFunction(IVdNQHj)
if
(GetQuestID(self.QuestName)~=nil)then local l=GetQuestID(self.QuestName)
if
(
Quests[l].State==QuestState.Over and Quests[l].Result==QuestResult.Interrupted)then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end end;return false end
function b_Trigger_OnQuestInterrupted:DEBUG(icedjl)
if type(self.QuestName)~="string"then
dbg(""..

icedjl.Identifier.." "..self.Name..": invalid quest name!")return true elseif self.WaitTime and
(type(self.WaitTime)~="number"or self.WaitTime<0)then
dbg(""..icedjl.Identifier.." "..
self.Name..": waitTime must be a number!")return true end;return false end
function b_Trigger_OnQuestInterrupted:Interrupt()self.WaitTimeTimer=nil end
function b_Trigger_OnQuestInterrupted:Reset()self.WaitTimeTimer=nil end
Core:RegisterBehavior(b_Trigger_OnQuestInterrupted)
function Trigger_OnQuestOver(...)return b_Trigger_OnQuestOver:new(...)end
b_Trigger_OnQuestOver={Name="Trigger_OnQuestOver",Description={en="Trigger: if a given quest has been finished, regardless of its result. Waiting time optional",de="Auslöser: wenn eine angegebene Quest beendet wurde, unabhängig von deren Ergebnis. Wartezeit optional"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function b_Trigger_OnQuestOver:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnQuestOver:AddParameter(H,d1J)
if(H==0)then self.QuestName=d1J elseif(H==1)then self.WaitTime=(d1J~=nil and
tonumber(d1J))or 0 end end
function b_Trigger_OnQuestOver:CustomFunction(zVUtED)
if
(GetQuestID(self.QuestName)~=nil)then local d_UB9=GetQuestID(self.QuestName)
if
(Quests[d_UB9].State==
QuestState.Over and
Quests[d_UB9].Result~=QuestResult.Interrupted)then
if self.WaitTime and self.WaitTime>0 then self.WaitTimeTimer=self.WaitTimeTimer or
Logic.GetTime()
if Logic.GetTime()>=self.WaitTimeTimer+
self.WaitTime then return true end else return true end end end;return false end
function b_Trigger_OnQuestOver:DEBUG(FysQC)
if type(self.QuestName)~="string"then
dbg(""..

FysQC.Identifier.." "..self.Name..": invalid quest name!")return true elseif self.WaitTime and
(type(self.WaitTime)~="number"or self.WaitTime<0)then
dbg(""..FysQC.Identifier.." "..
self.Name..": waitTime must be a number!")return true end;return false end
function b_Trigger_OnQuestOver:Interrupt()self.WaitTimeTimer=nil end
function b_Trigger_OnQuestOver:Reset()self.WaitTimeTimer=nil end;Core:RegisterBehavior(b_Trigger_OnQuestOver)function Trigger_OnQuestSuccess(...)return
b_Trigger_OnQuestSuccess:new(...)end
b_Trigger_OnQuestSuccess={Name="Trigger_OnQuestSuccess",Description={en="Trigger: if a given quest has been finished successfully. Waiting time optional",de="Auslöser: wenn eine angegebene Quest erfolgreich abgeschlossen wurde. Wartezeit optional"},Parameter={{ParameterType.QuestName,en="Quest name",de="Questname"},{ParameterType.Number,en="Waiting time",de="Wartezeit"}}}
function b_Trigger_OnQuestSuccess:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnQuestSuccess:AddParameter(AnG,yV8C)if(AnG==0)then self.QuestName=yV8C elseif(AnG==1)then
self.WaitTime=(
yV8C~=nil and tonumber(yV8C))or 0 end end
function b_Trigger_OnQuestSuccess:CustomFunction()
if
(GetQuestID(self.QuestName)~=nil)then local bt4Y=GetQuestID(self.QuestName)
if(Quests[bt4Y].Result==
QuestResult.Success)then
if
self.WaitTime and self.WaitTime>0 then
self.WaitTimeTimer=self.WaitTimeTimer or Logic.GetTime()if
Logic.GetTime()>=self.WaitTimeTimer+self.WaitTime then return true end else return true end end end;return false end
function b_Trigger_OnQuestSuccess:DEBUG(sZNR)
if type(self.QuestName)~="string"then
dbg(""..

sZNR.Identifier.." "..self.Name..": invalid quest name!")return true elseif self.WaitTime and
(type(self.WaitTime)~="number"or self.WaitTime<0)then
dbg(""..sZNR.Identifier.." "..
self.Name..": waittime must be a number!")return true end;return false end
function b_Trigger_OnQuestSuccess:Interrupt()self.WaitTimeTimer=nil end
function b_Trigger_OnQuestSuccess:Reset()self.WaitTimeTimer=nil end;Core:RegisterBehavior(b_Trigger_OnQuestSuccess)function Trigger_CustomVariables(...)return
b_Trigger_CustomVariables:new(...)end
b_Trigger_CustomVariables={Name="Trigger_CustomVariables",Description={en="Trigger: if the variable has a certain value.",de="Auslöser: wenn die Variable einen bestimmen Wert eingenommen hat."},Parameter={{ParameterType.Default,en="Name of Variable",de="Variablennamen"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Default,en="Value",de="Wert"}}}
function b_Trigger_CustomVariables:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_CustomVariables:AddParameter(WAIOz7,ICLcYduB)
if WAIOz7 ==0 then self.VariableName=ICLcYduB elseif
WAIOz7 ==1 then self.Relation=ICLcYduB elseif WAIOz7 ==2 then local oXFiMbj=tonumber(ICLcYduB)
oXFiMbj=(
oXFiMbj~=nil and oXFiMbj)or ICLcYduB;self.Value=oXFiMbj end end
function b_Trigger_CustomVariables:CustomFunction()
if
_G["QSB_CustomVariables_"..self.VariableName]~=nil then
if self.Relation=="=="then
return
_G["QSB_CustomVariables_"..self.VariableName]==
(
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value])elseif self.Relation~="~="then
return
_G["QSB_CustomVariables_"..self.VariableName]~=
(
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value])elseif self.Relation==">"then
return
_G["QSB_CustomVariables_"..self.VariableName]>
(
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value])elseif self.Relation==">="then
return
_G["QSB_CustomVariables_"..self.VariableName]>=
(
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value])elseif self.Relation=="<="then
return
_G["QSB_CustomVariables_"..self.VariableName]<=
(
(type(self.Value)~="string"and self.Value)or _G["QSB_CustomVariables_"..self.Value])else
return _G["QSB_CustomVariables_"..self.VariableName]<
((
type(self.Value)~="string"and self.Value)or _G[
"QSB_CustomVariables_"..self.Value])end end;return false end
function b_Trigger_CustomVariables:GetCustomData(i5L)if i5L==1 then
return{"==","~=","<=","<",">",">="}end end
function b_Trigger_CustomVariables:DEBUG(vYC4bdrc)
local QAFVQu14={"==","~=","<=","<",">",">="}local DVx={true,false,nil}
if not
_G["QSB_CustomVariables_"..self.VariableName]then
dbg(vYC4bdrc.Identifier..
" "..self.Name..": variable '"..
self.VariableName.."' do not exist!")return true elseif not Inside(self.Relation,QAFVQu14)then
dbg(vYC4bdrc.Identifier.." "..

self.Name..": '"..self.Relation.."' is an invalid relation!")return true end;return false end;Core:RegisterBehavior(b_Trigger_CustomVariables)function Trigger_AlwaysActive()return
b_Trigger_AlwaysActive:new()end
b_Trigger_AlwaysActive={Name="Trigger_AlwaysActive",Description={en="Trigger: the map has been started.",de="Auslöser: Start der Karte."}}
function b_Trigger_AlwaysActive:GetTriggerTable()return{Triggers.Time,0}end;Core:RegisterBehavior(b_Trigger_AlwaysActive)function Trigger_OnMonth(...)return
b_Trigger_OnMonth:new(...)end
b_Trigger_OnMonth={Name="Trigger_OnMonth",Description={en="Trigger: a specified month",de="Auslöser: ein bestimmter Monat"},Parameter={{ParameterType.Custom,en="Month",de="Monat"}}}
function b_Trigger_OnMonth:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnMonth:AddParameter(r,Knh56)if(r==0)then self.Month=Knh56*1 end end;function b_Trigger_OnMonth:CustomFunction(DG90Rh)
return self.Month==Logic.GetCurrentMonth()end
function b_Trigger_OnMonth:GetCustomData(mBxSp8y2)
local W09NOBin={}if mBxSp8y2 ==0 then
for Tek7X=1,12 do table.insert(W09NOBin,Tek7X)end else assert(false)end
return W09NOBin end
function b_Trigger_OnMonth:DEBUG(Wzzgk)if self.Month<1 or self.Month>12 then
dbg(Wzzgk.Identifier..
" "..self.Name..": Month has the wrong value")return true end
return false end;Core:RegisterBehavior(b_Trigger_OnMonth)function Trigger_OnMonsoon()return
b_Trigger_OnMonsoon:new()end
b_Trigger_OnMonsoon={Name="Trigger_OnMonsoon",Description={en="Trigger: on monsoon.",de="Auslöser: wenn der Monsun beginnt."},RequiresExtraNo=1}
function b_Trigger_OnMonsoon:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnMonsoon:CustomFunction(anaV)if Logic.GetWeatherDoesShallowWaterFlood(0)then
return true end end;Core:RegisterBehavior(b_Trigger_OnMonsoon)function Trigger_Time(...)return
b_Trigger_Time:new(...)end
b_Trigger_Time={Name="Trigger_Time",Description={en="Trigger: a given amount of time since map start",de="Auslöser: eine gewisse Anzahl Sekunden nach Spielbeginn"},Parameter={{ParameterType.Number,en="Time (sec.)",de="Zeit (Sek.)"}}}
function b_Trigger_Time:GetTriggerTable()return{Triggers.Time,self.Time}end
function b_Trigger_Time:AddParameter(gwxp,Qf)if(gwxp==0)then self.Time=Qf*1 end end;Core:RegisterBehavior(b_Trigger_Time)function Trigger_OnWaterFreezes()return
b_Trigger_OnWaterFreezes:new()end
b_Trigger_OnWaterFreezes={Name="Trigger_OnWaterFreezes",Description={en="Trigger: if the water starts freezing",de="Auslöser: wenn die Gewässer gefrieren"}}
function b_Trigger_OnWaterFreezes:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function b_Trigger_OnWaterFreezes:CustomFunction(sRf)
if Logic.GetWeatherDoesWaterFreeze(0)then return true end end
Core:RegisterBehavior(b_Trigger_OnWaterFreezes)
function Trigger_NeverTriggered()return b_Trigger_NeverTriggered:new()end
b_Trigger_NeverTriggered={Name="Trigger_NeverTriggered",Description={en="Never triggers a Quest. The quest may be set active by Reward_QuestActivate or Reward_QuestRestartForceActive",de="Löst nie eine Quest aus. Die Quest kann von Reward_QuestActivate oder Reward_QuestRestartForceActive aktiviert werden."}}function b_Trigger_NeverTriggered:GetTriggerTable()return
{Triggers.Custom2,{self,function()end}}end
Core:RegisterBehavior(b_Trigger_NeverTriggered)function Trigger_OnAtLeastOneQuestFailure(...)
return b_Trigger_OnAtLeastOneQuestFailure:new(...)end
b_Trigger_OnAtLeastOneQuestFailure={Name="Trigger_OnAtLeastOneQuestFailure",Description={en="Trigger: if one or both of the given quests have failed.",de="Auslöser: wenn einer oder beide der angegebenen Aufträge fehlgeschlagen sind."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function b_Trigger_OnAtLeastOneQuestFailure:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnAtLeastOneQuestFailure:AddParameter(Ir,On7i)self.QuestTable={}if(Ir==0)then
self.Quest1=On7i elseif(Ir==1)then self.Quest2=On7i end end
function b_Trigger_OnAtLeastOneQuestFailure:CustomFunction(GAQjek)
local b=Quests[GetQuestID(self.Quest1)]local t=Quests[GetQuestID(self.Quest2)]
if
(b.State==
QuestState.Over and b.Result==QuestResult.Failure)or
(t.State==QuestState.Over and t.Result==QuestResult.Failure)then return true end;return false end
function b_Trigger_OnAtLeastOneQuestFailure:DEBUG(nUqS)
if self.Quest1 ==self.Quest2 then
dbg(
nUqS.Identifier..": "..self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
dbg(nUqS.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
dbg(nUqS.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Trigger_OnAtLeastOneQuestFailure)function Trigger_OnAtLeastOneQuestSuccess(...)
return b_Trigger_OnAtLeastOneQuestSuccess:new(...)end
b_Trigger_OnAtLeastOneQuestSuccess={Name="Trigger_OnAtLeastOneQuestSuccess",Description={en="Trigger: if one or both of the given quests are won.",de="Auslöser: wenn einer oder beide der angegebenen Aufträge gewonnen wurden."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function b_Trigger_OnAtLeastOneQuestSuccess:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnAtLeastOneQuestSuccess:AddParameter(wTVytu,VZjB)self.QuestTable={}if(wTVytu==0)then
self.Quest1=VZjB elseif(wTVytu==1)then self.Quest2=VZjB end end
function b_Trigger_OnAtLeastOneQuestSuccess:CustomFunction(Qv_pumH)
local Rm=Quests[GetQuestID(self.Quest1)]local Wq2v=Quests[GetQuestID(self.Quest2)]
if
(Rm.State==
QuestState.Over and Rm.Result==QuestResult.Success)or
(Wq2v.State==QuestState.Over and Wq2v.Result==QuestResult.Success)then return true end;return false end
function b_Trigger_OnAtLeastOneQuestSuccess:DEBUG(G)
if self.Quest1 ==self.Quest2 then
dbg(G.Identifier..": "..
self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
dbg(G.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
dbg(G.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Trigger_OnAtLeastOneQuestSuccess)
function Trigger_OnAtLeastXOfYQuestsSuccess(...)return
b_Trigger_OnAtLeastXOfYQuestsSuccess:new(...)end
b_Trigger_OnAtLeastXOfYQuestsSuccess={Name="Trigger_OnAtLeastXOfYQuestsSuccess",Description={en="Trigger: if at least X of Y given quests has been finished successfully.",de="Auslöser: wenn X von Y angegebener Quests erfolgreich abgeschlossen wurden."},Parameter={{ParameterType.Custom,en="Least Amount",de="Mindest Anzahl"},{ParameterType.Custom,en="Quest Amount",de="Quest Anzahl"},{ParameterType.QuestName,en="Quest name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest name 2",de="Questname 2"},{ParameterType.QuestName,en="Quest name 3",de="Questname 3"},{ParameterType.QuestName,en="Quest name 4",de="Questname 4"},{ParameterType.QuestName,en="Quest name 5",de="Questname 5"}}}
function b_Trigger_OnAtLeastXOfYQuestsSuccess:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnAtLeastXOfYQuestsSuccess:AddParameter(e5kmv,PSNhu)
if(e5kmv==0)then
self.LeastAmount=tonumber(PSNhu)elseif(e5kmv==1)then self.QuestAmount=tonumber(PSNhu)elseif(e5kmv==2)then
self.QuestName1=PSNhu elseif(e5kmv==3)then self.QuestName2=PSNhu elseif(e5kmv==4)then self.QuestName3=PSNhu elseif
(e5kmv==5)then self.QuestName4=PSNhu elseif(e5kmv==6)then self.QuestName5=PSNhu end end
function b_Trigger_OnAtLeastXOfYQuestsSuccess:CustomFunction()local mAaO3eJ=0
for EO=1,self.QuestAmount do local Qw9=GetQuestID(self["QuestName"..
EO])if IsValidQuest(Qw9)then
if(
Quests[Qw9].Result==QuestResult.Success)then
mAaO3eJ=mAaO3eJ+1;if mAaO3eJ>=self.LeastAmount then return true end end end end;return false end
function b_Trigger_OnAtLeastXOfYQuestsSuccess:DEBUG(GMgV5kh)local Shm=self.LeastAmount
local iIKY5x=self.QuestAmount
if Shm<=0 or Shm>5 then
dbg(GMgV5kh.Identifier..
": Error in "..self.Name..": LeastAmount is wrong")return true elseif iIKY5x<=0 or iIKY5x>5 then
dbg(GMgV5kh.Identifier..": Error in "..
self.Name..": QuestAmount is wrong")return true elseif Shm>iIKY5x then
dbg(GMgV5kh.Identifier..": Error in "..
self.Name..": LeastAmount is greater than QuestAmount")return true end
for fLF=1,iIKY5x do
if
not IsValidQuest(self["QuestName"..fLF])then
dbg(GMgV5kh.Identifier..
": Error in "..self.Name..": Quest "..
self["QuestName"..fLF].." not found")return true end end;return false end
function b_Trigger_OnAtLeastXOfYQuestsSuccess:GetCustomData(eQ)if(eQ==0)or(eQ==1)then return
{"1","2","3","4","5"}end end
Core:RegisterBehavior(b_Trigger_OnAtLeastXOfYQuestsSuccess)function Trigger_MapScriptFunction(...)
return b_Trigger_MapScriptFunction:new(...)end
b_Trigger_MapScriptFunction={Name="Trigger_MapScriptFunction",Description={en="Calls a function within the global map script. If the function returns true the quest will be started",de="Ruft eine Funktion im globalen Skript auf. Wenn sie true sendet, wird die Quest gestartet."},Parameter={{ParameterType.Default,en="Function name",de="Funktionsname"}}}
function b_Trigger_MapScriptFunction:GetTriggerTable(yGT7hv6)return
{Triggers.Custom2,{self,self.CustomFunction}}end;function b_Trigger_MapScriptFunction:AddParameter(qG4fWn4a,Zkf)
if(qG4fWn4a==0)then self.FuncName=Zkf end end;function b_Trigger_MapScriptFunction:CustomFunction(N)return
_G[self.FuncName](self,N)end
function b_Trigger_MapScriptFunction:DEBUG(Bh)
if
not self.FuncName or not _G[self.FuncName]then
local r42joJ=string.format("%s Trigger_MapScriptFunction: function '%s' does not exist!",Bh.Identifier,tostring(self.FuncName))dbg(r42joJ)return true end;return false end
Core:RegisterBehavior(b_Trigger_MapScriptFunction)
function Goal_InputDialog(...)return b_Goal_InputDialog:new(...)end
b_Goal_InputDialog={Name="Goal_InputDialog",Description={en="Goal: Player must type in something. The passwords have to be seperated by ; and whitespaces will be ignored.",de="Ziel: Oeffnet einen Dialog, der Spieler muss Lösungswörter eingeben. Diese sind durch ; abzutrennen. Leerzeichen werden ignoriert."},DefaultMessage={de="Versuche bis zum Fehlschlag: ",en="Trials remaining until failure: "},Parameter={{ParameterType.Default,en="Password to enter",de="Einzugebendes Passwort"},{ParameterType.Number,en="Trials till failure (0 endless)",de="Versuche bis Fehlschlag (0 endlos)"},{ParameterType.Default,en="Wrong password message",de="Text bei Falscheingabe"}}}
function b_Goal_InputDialog:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_InputDialog:AddParameter(zl1g,Cx)
if(zl1g==0)then
self.Password=self:LowerCase(Cx or"")elseif(zl1g==1)then self.Trials=(Cx or 0)*1 elseif(zl1g==2)then self.Message=Cx
local A6o=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if type(self.Message)=="table"then
self.Message=self.Message[A6o]end end end
function b_Goal_InputDialog:CustomFunction(s2_)
local i6j=function(oKC)
if not self.Shown then
self:InitReturnVariable(oKC)self:ShowBox()self.Shown=true end end
if not IsBriefingActive or
(IsBriefingActive and IsBriefingActive()==false)then
if(not self.Trials)or
(self.Trials)==0 then i6j(s2_.Identifier)elseif not self.Shown then self.TrialCounter=
self.TrialCounter or self.Trials
i6j(s2_.Identifier)self.TrialCounter=self.TrialCounter-1 end
if s2_.InputDialogResult then
Logic.ExecuteInLuaLocalState([[
                GUI_Chat.Confirm = GUI_Chat.Confirm_Orig_Goal_InputDialog
                GUI_Chat.Confirm_Orig_Goal_InputDialog = nil
                GUI_Chat.Abort = GUI_Chat.Abort_Orig_Goal_InputDialog
                GUI_Chat.Abort_Orig_Goal_InputDialog = nil
            ]])
if self.Password~=nil and self.Password~=""then self.Shown=nil
if
self:LowerCase(s2_.InputDialogResult)==self.Password then return true elseif
(self.Trials==0)or(
self.Trials>0 and self.TrialCounter>0)then self:OnWrongInput(s2_)return else return false end end;return true end end end
function b_Goal_InputDialog:OnWrongInput(Xzi2KU)
if self.Trials>0 and not self.Message then
local _c=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
Logic.DEBUG_AddNote(self.DefaultMessage..self.TrialCounter)return end
if self.Message then Logic.DEBUG_AddNote(self.Message)end;Xzi2KU.InputDialogResult=nil end
function b_Goal_InputDialog:LowerCase(S)S=S:lower(S)S=S:gsub("Ä","ä")
S=S:gsub("Ö","ö")S=S:gsub("Ü","ü")return S end
function b_Goal_InputDialog:ShowBox()
Logic.ExecuteInLuaLocalState([[
        Input.ChatMode()
        XGUIEng.ShowWidget("/InGame/Root/Normal/ChatInput",1)
        XGUIEng.SetText("/InGame/Root/Normal/ChatInput/ChatInput", "")
        XGUIEng.SetFocus("/InGame/Root/Normal/ChatInput/ChatInput")
    ]])end
function b_Goal_InputDialog:InitReturnVariable(pI1x)
Logic.ExecuteInLuaLocalState(
[[
        GUI_Chat.Abort_Orig_Goal_InputDialog = GUI_Chat.Abort
        GUI_Chat.Confirm_Orig_Goal_InputDialog = GUI_Chat.Confirm

        GUI_Chat.Confirm = function()
            Input.GameMode()
            XGUIEng.ShowWidget("/InGame/Root/Normal/ChatInput",0)
            local ChatMessage = XGUIEng.GetText("/InGame/Root/Normal/ChatInput/ChatInput")
            g_Chat.JustClosed = 1
            GUI.SendScriptCommand("Quests[GetQuestID(']]..
pI1x..[[')].InputDialogResult = '"..ChatMessage.."'")
        end
        GUI_Chat.Abort = function()
        end
    ]])end;function b_Goal_InputDialog:DEBUG(NgDx9_)return false end;function b_Goal_InputDialog:GetIcon()return
{12,2}end
function b_Goal_InputDialog:Reset(KzYaixt)
KzYaixt.InputDialogResult=nil;self.TrialCounter=nil;self.Shown=nil end;Core:RegisterBehavior(b_Goal_InputDialog)function Trigger_OnEffectDestroyed(...)return
b_Trigger_OnEffectDestroyed:new(...)end
b_Trigger_OnEffectDestroyed={Name="Trigger_OnEffectDestroyed",Description={en="Trigger: Starts a quest after an effect was destroyed",de="Ausloeser: Startet eine Quest, nachdem ein Effekt zerstoert wurde"},Parameter={{ParameterType.Default,en="Effect name",de="Effektname"}}}
function b_Trigger_OnEffectDestroyed:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnEffectDestroyed:AddParameter(i,DM7)if i==0 then self.EffectName=DM7 end end
function b_Trigger_OnEffectDestroyed:CustomFunction()return

not QSB.EffectNameToID[self.EffectName]or not
Logic.IsEffectRegistered(QSB.EffectNameToID[self.EffectName])end
function b_Trigger_OnEffectDestroyed:DEBUG(sBDh6v)if
not QSB.EffectNameToID[self.EffectName]then
dbg(sBDh6v.Identifier..
" "..self.Name..": Effect has never existed")return true end end
Core:RegisterBehavior(b_Trigger_OnEffectDestroyed)function Reward_SetBuildingUpgradeLevel(...)
return b_Reward_SetBuildingUpgradeLevel:new(...)end
b_Reward_SetBuildingUpgradeLevel={Name="Reward_SetBuildingUpgradeLevel",Description={en="Sets the upgrade level of the specified building.",de="Legt das Upgrade-Level eines Gebaeudes fest."},Parameter={{ParameterType.ScriptName,en="Building",de="Gebäude"},{ParameterType.Custom,en="Upgrade level",de="Upgrade-Level"}}}
function b_Reward_SetBuildingUpgradeLevel:GetRewardTable()return
{Reward.Custom,self,self.CustomFunction}end
function b_Reward_SetBuildingUpgradeLevel:AddParameter(siy_21f,wkUEOv)
if siy_21f==0 then self.Building=wkUEOv elseif
siy_21f==1 then self.UpgradeLevel=tonumber(wkUEOv)end end
function b_Reward_SetBuildingUpgradeLevel:CustomFunction()
local b=Logic.GetEntityIDByName(self.Building)local s1sExxI=Logic.GetUpgradeLevel(b)
local qR=Logic.GetMaxUpgradeLevel(b)
if b~=0 and Logic.IsBuilding(b)==1 and
(
Logic.IsBuildingUpgradable(b,true)or(qR~=0 and qR==s1sExxI))then
Logic.SetUpgradableBuildingState(b,math.min(self.UpgradeLevel,qR),0)end end
function b_Reward_SetBuildingUpgradeLevel:DEBUG(KMeqP)
local y3tk=Logic.GetEntityIDByName(self.Building)local A=Logic.GetMaxUpgradeLevel(y3tk)
if not y3tk or
Logic.IsBuilding(y3tk)==0 then
dbg(KMeqP.Identifier.." "..
self.Name..": Building "..self.Building..
" is missing or no building.")return true elseif not self.UpgradeLevel or self.UpgradeLevel<0 then
dbg(
KMeqP.Identifier.." "..self.Name..": Upgrade level is wrong")return true end end;function b_Reward_SetBuildingUpgradeLevel:GetCustomData(Iysi_9UF)
if Iysi_9UF==1 then return{"0","1","2","3"}end end
Core:RegisterBehavior(b_Reward_SetBuildingUpgradeLevel)BundleClassicBehaviors={Global={},Local={}}function BundleClassicBehaviors.Global:Install()
end
function BundleClassicBehaviors.Global:GetInputFromQuest(joAA)
local w=Quests[GetQuestID(joAA)]if not w then return end;return w.InputDialogResult end;Core:RegisterBundle("BundleClassicBehaviors")
BundleQuestGeneration={}API=API or{}QSB=QSB or{}QSB.GeneratedQuestDialogs={}
function API.CreateQuest(ta59)if GUI then
API.Fatal("API.CreateQuest: Could not execute in local script!")return end;return
BundleQuestGeneration.Global:QuestCreateNewQuest(ta59)end;AddQuest=API.CreateQuest
function API.CreateQuestMessage(b_knq,J_AlR,_dqQ8fSw,onKnnPCx,WytqKWPI,M)if GUI then
API.Fatal("API.CreateQuestMessage: Could not execute in local script!")return end;return
BundleQuestGeneration.Global:QuestMessage(b_knq,J_AlR,_dqQ8fSw,onKnnPCx,WytqKWPI,M)end;QuestMessage=API.CreateQuestMessage
function API.CreateQuestDialog(K4o_AriB)if GUI then
API.Fatal("API.CreateQuestDialog: Could not execute in local script!")return end
table.insert(K4o_AriB,{"KEY(NO_MESSAGE)",1,1})local MXcdGX;local R9={}
for n9zj=1,#K4o_AriB,1 do
K4o_AriB[n9zj][4]=K4o_AriB[n9zj][4]or 12
if n9zj>1 then
K4o_AriB[n9zj][6]=K4o_AriB[n9zj][6]or MXcdGX else
K4o_AriB[n9zj][6]=K4o_AriB[n9zj][6]or K4o_AriB.Ancestor;K4o_AriB[n9zj][4]=K4o_AriB.Delay or 0 end
if n9zj==#K4o_AriB and#K4o_AriB[n9zj-1]then
K4o_AriB[n9zj][7]=K4o_AriB.Name;K4o_AriB[n9zj][4]=K4o_AriB[n9zj-1][4]end
MXcdGX=BundleQuestGeneration.Global:QuestMessage(unpack(K4o_AriB[n9zj]))table.insert(R9,MXcdGX)end;if K4o_AriB.Name then
QSB.GeneratedQuestDialogs[K4o_AriB.Name]=R9 end;return R9[#R9],R9 end;QuestDialog=API.CreateQuestDialog
function API.InterruptQuestDialog(sWU)if GUI then
API.Fatal("API.InterruptQuestDialog: Could not execute in local script!")return end;local JoZ28=sWU
if
type(JoZ28)=="string"then JoZ28=QSB.GeneratedQuestDialogs[JoZ28]end;if JoZ28 ==nil then
API.Fatal("API.InterruptQuestDialog: Dialog is invalid!")return end;for hBfySU=1,#JoZ28-1,1 do
API.StopQuest(JoZ28[hBfySU],true)end
API.WinQuest(JoZ28[#JoZ28],true)end;QuestDialogInterrupt=API.InterruptQuestDialog
function API.RestartQuestDialog(Uvmu)if GUI then
API.Fatal("API.ResetQuestDialog: Could not execute in local script!")return end;local _=Uvmu;if type(_)=="string"then
_=QSB.GeneratedQuestDialogs[_]end;if _==nil then
API.Fatal("API.ResetQuestDialog: Dialog is invalid!")return end;for SeHRNaX=1,#_,1 do Quests[GetQuestID(_[SeHRNaX])].Triggers[1][2][1].WaitTimeTimer=
nil
API.RestartQuest(_[SeHRNaX],true)end
Quests[GetQuestID(_[1])]:Trigger()end;QuestDialogRestart=API.RestartQuestDialog
BundleQuestGeneration={Global={Data={QuestMessageID=0}}}function BundleQuestGeneration.Global:Install()end
function BundleQuestGeneration.Global:QuestMessage(kH7r,HOB,RCc,vLr4f,Pad5yPd,GAeGfl,TYRl)self.Data.QuestMessageID=
self.Data.QuestMessageID+1
local uoRdE7k={Triggers.Custom2,{{QuestName=GAeGfl,WaitTime=vLr4f or 1},function(VAKgo)
local QB=GetQuestID(VAKgo.QuestName)if not VAKgo.QuestName then return true end
if
(Quests[QB]and Quests[QB].State==
QuestState.Over and Quests[QB].Result~=
QuestResult.Interrupted)then
VAKgo.WaitTimeTimer=VAKgo.WaitTimeTimer or API.RealTimeGetSecondsPassedSinceGameStart()
if API.RealTimeGetSecondsPassedSinceGameStart()>=
VAKgo.WaitTimeTimer+VAKgo.WaitTime then return true end end;return false end}}local k5=
(Network.GetDesiredLanguage()=="de"and"de")or"en"if
type(kH7r)=="table"then kH7r=kH7r[k5]end
local F_cOghKV,Ytf=QuestTemplate:New(
(TYRl~=nil and TYRl)or"QSB_QuestMessage_"..self.Data.QuestMessageID,(
HOB or 1),(RCc or 1),{{Objective.Dummy}},{uoRdE7k},0,nil,nil,Pad5yPd,nil,false,(kH7r~=nil),
nil,nil,kH7r,nil)return Ytf.Identifier end
function BundleQuestGeneration.Global:QuestCreateNewQuest(y8zF)
if not y8zF.Name then
QSB.AutomaticQuestNameCounter=(
QSB.AutomaticQuestNameCounter or 0)+1
y8zF.Name=string.format("AutoNamed_Quest_%d",QSB.AutomaticQuestNameCounter)end;if not Core:CheckQuestName(y8zF.Name)then
dbg("Quest '"..
tostring(y8zF.Name).."': invalid questname! Contains forbidden characters!")return end
local T=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
local fT1={y8zF.Name,(y8zF.Sender~=nil and y8zF.Sender)or 1,(
y8zF.Receiver~=nil and y8zF.Receiver)or 1,{},{},(
y8zF.Time~=nil and y8zF.Time)or 0,{},{},y8zF.Callback,y8zF.Loop,
y8zF.Visible==true or y8zF.Suggestion~=nil,
y8zF.EndMessage==true or(y8zF.Failure~=nil or y8zF.Success~=nil),
(
type(y8zF.Description)=="table"and y8zF.Description[T])or y8zF.Description,(
type(y8zF.Suggestion)=="table"and y8zF.Suggestion[T])or
y8zF.Suggestion,(type(y8zF.Success)=="table"and
y8zF.Success[T])or y8zF.Success,
(
type(y8zF.Failure)=="table"and y8zF.Failure[T])or y8zF.Failure}
if not self:QuestValidateQuestData(fT1)then
API.Fatal("AddQuest: Error while creating quest. Table has been copied to log.")API.DumpTable(fT1,"Quest")return end
for MwI,t in pairs(y8zF)do
if tonumber(MwI)~=nil then
if type(t)=="table"then
if t.GetGoalTable then
table.insert(fT1[4],t:GetGoalTable())local rcbgP=#fT1[4]fT1[4][rcbgP].Context=t
fT1[4][rcbgP].FuncOverrideIcon=fT1[4][rcbgP].Context.GetIcon
fT1[4][rcbgP].FuncOverrideMsgKey=fT1[4][rcbgP].Context.GetMsgKey elseif t.GetReprisalTable then
table.insert(fT1[8],t:GetReprisalTable())elseif t.GetRewardTable then
table.insert(fT1[7],t:GetRewardTable())else table.insert(fT1[5],t:GetTriggerTable())end end end end;local lMKfa,P25nFo1=QuestTemplate:New(unpack(fT1,1,16))
P25nFo1.MsgTableOverride=y8zF.MSGKeyOverwrite;P25nFo1.IconOverride=y8zF.IconOverwrite;P25nFo1.Arguments=
(
y8zF.Arguments~=nil and API.InstanceTable(y8zF.Arguments))or{}return
y8zF.Name end
function BundleQuestGeneration.Global:QuestValidateQuestData(nwoQ)
return
(









(
type(nwoQ[1])=="string"and self:QuestValidateQuestName(nwoQ[1]))and
(type(nwoQ[2])=="number"and nwoQ[2]>=1 and nwoQ[2]<=8)and
(
type(nwoQ[3])=="number"and nwoQ[3]>=1 and nwoQ[3]<=8)and
(type(nwoQ[6])=="number"and nwoQ[6]>=0)and
(
(nwoQ[9]~=nil and type(nwoQ[9])=="function")or(nwoQ[9]==nil))and
(
(nwoQ[10]~=nil and type(nwoQ[10])=="function")or(nwoQ[10]==nil))and(type(nwoQ[11])=="boolean")and(type(nwoQ[12])=="boolean")and
(
(nwoQ[13]~=nil and type(nwoQ[13])=="string")or(nwoQ[13]==nil))and
(
(nwoQ[14]~=nil and type(nwoQ[14])=="string")or(nwoQ[14]==nil))and
(
(nwoQ[15]~=nil and type(nwoQ[15])=="string")or(nwoQ[15]==nil))and
(
(nwoQ[16]~=nil and type(nwoQ[16])=="string")or(nwoQ[16]==nil)))end
function BundleQuestGeneration.Global:QuestValidateQuestName(pazH2Fh)return
string.find(pazH2Fh,"^[A-Za-z0-9_]+$")~=nil end;Core:RegisterBundle("BundleQuestGeneration")
BundleConstructionControl={}API=API or{}QSB=QSB or{}
function API.BanTypeAtTerritory(GZ2PbO,y)
if GUI then
local cMk1b62p=(type(_center)=="string"and"'"..
y.."'")or y
GUI.SendScriptCommand("API.BanTypeAtTerritory("..GZ2PbO..", "..cMk1b62p..")")return end
if type(y)=="string"then y=GetTerritoryIDByName(y)end
BundleConstructionControl.Global.Data.TerritoryBlockEntities[GZ2PbO]=
BundleConstructionControl.Global.Data.TerritoryBlockEntities[GZ2PbO]or{}
if not
Inside(y,BundleConstructionControl.Global.Data.TerritoryBlockEntities[GZ2PbO])then
table.insert(BundleConstructionControl.Global.Data.TerritoryBlockEntities[GZ2PbO],y)end end
function API.BanCategoryAtTerritory(iAIf,Am0WLx)
if GUI then local T=
(type(_center)=="string"and"'"..Am0WLx.."'")or Am0WLx
GUI.SendScriptCommand(
"API.BanTypeAtTerritory("..iAIf..", "..T..")")return end
if type(Am0WLx)=="string"then Am0WLx=GetTerritoryIDByName(Am0WLx)end
BundleConstructionControl.Global.Data.TerritoryBlockCategories[iAIf]=
BundleConstructionControl.Global.Data.TerritoryBlockCategories[iAIf]or{}
if not
Inside(Am0WLx,BundleConstructionControl.Global.Data.TerritoryBlockCategories[iAIf])then
table.insert(BundleConstructionControl.Global.Data.TerritoryBlockCategories[iAIf],Am0WLx)end end
function API.BanTypeInArea(DJshmj,LTJy0,N)
if GUI then local Ns=
(type(LTJy0)=="string"and"'"..LTJy0 .."'")or LTJy0
GUI.SendScriptCommand(
"API.BanTypeInArea("..DJshmj..", "..Ns..", "..N..")")return end
BundleConstructionControl.Global.Data.AreaBlockEntities[LTJy0]=
BundleConstructionControl.Global.Data.AreaBlockEntities[LTJy0]or{}
if not
Inside(DJshmj,BundleConstructionControl.Global.Data.AreaBlockEntities[LTJy0],true)then
table.insert(BundleConstructionControl.Global.Data.AreaBlockEntities[LTJy0],{DJshmj,N})end end
function API.BanCategoryInArea(ZOvR1,L75,zh)
if GUI then local v=
(type(L75)=="string"and"'"..L75 .."'")or L75
GUI.SendScriptCommand("API.BanCategoryInArea("..
ZOvR1 ..", "..v..", "..zh..")")return end
BundleConstructionControl.Global.Data.AreaBlockCategories[L75]=
BundleConstructionControl.Global.Data.AreaBlockCategories[L75]or{}
if not
Inside(ZOvR1,BundleConstructionControl.Global.Data.AreaBlockCategories[L75],true)then
table.insert(BundleConstructionControl.Global.Data.AreaBlockCategories[L75],{ZOvR1,zh})end end
function API.UnbanTypeAtTerritory(Il05,d0W)
if GUI then local b=
(type(_center)=="string"and"'"..d0W.."'")or d0W
GUI.SendScriptCommand(
"API.UnbanTypeAtTerritory("..Il05 ..", "..b..")")return end
if type(d0W)=="string"then d0W=GetTerritoryIDByName(d0W)end
if not
BundleConstructionControl.Global.Data.TerritoryBlockEntities[Il05]then return end
for dG=#
BundleConstructionControl.Global.Data.TerritoryBlockEntities[Il05],1,-1 do
if
BundleConstructionControl.Global.Data.TerritoryBlockEntities[Il05][dG]==d0W then
table.remove(BundleConstructionControl.Global.Data.TerritoryBlockEntities[Il05],dG)break end end end
function API.UnbanCategoryAtTerritory(wF9WF,b097)
if GUI then local Qu1=
(type(_center)=="string"and"'"..b097 .."'")or b097
GUI.SendScriptCommand(
"API.UnbanTypeAtTerritory("..wF9WF..", "..Qu1 ..")")return end
if type(b097)=="string"then b097=GetTerritoryIDByName(b097)end
if not
BundleConstructionControl.Global.Data.TerritoryBlockCategories[wF9WF]then return end
for r6=#
BundleConstructionControl.Global.Data.TerritoryBlockCategories[wF9WF],1,-1 do
if
BundleConstructionControl.Global.Data.TerritoryBlockCategories[wF9WF][r6]==b097 then
table.remove(BundleConstructionControl.Global.Data.TerritoryBlockCategories[wF9WF],r6)break end end end
function API.UnbanTypeInArea(DOx,sQe35a)
if GUI then local p2=
(type(sQe35a)=="string"and"'"..sQe35a.."'")or sQe35a
GUI.SendScriptCommand(
"API.UnbanTypeInArea(".._eCat..", "..p2 ..")")return end
if not
BundleConstructionControl.Global.Data.AreaBlockEntities[sQe35a]then return end
for TN=#
BundleConstructionControl.Global.Data.AreaBlockEntities[sQe35a],1,-1 do
if
BundleConstructionControl.Global.Data.AreaBlockEntities[sQe35a][TN][1]==DOx then
table.remove(BundleConstructionControl.Global.Data.AreaBlockEntities[sQe35a],TN)break end end end
function API.UnbanCategoryInArea(vtk,ENKi)
if GUI then local HgWdXJXD=
(type(ENKi)=="string"and"'"..ENKi.."'")or ENKi
GUI.SendScriptCommand(
"API.UnbanCategoryInArea(".._type..", "..HgWdXJXD..")")return end
if not
BundleConstructionControl.Global.Data.AreaBlockCategories[ENKi]then return end
for wiugbQS=#
BundleConstructionControl.Global.Data.AreaBlockCategories[ENKi],1,-1 do
if
BundleConstructionControl.Global.Data.AreaBlockCategories[ENKi][wiugbQS][1]==vtk then
table.remove(BundleConstructionControl.Global.Data.AreaBlockCategories[ENKi],wiugbQS)break end end end
BundleConstructionControl={Global={Data={TerritoryBlockCategories={},TerritoryBlockEntities={},AreaBlockCategories={},AreaBlockEntities={}}}}
function BundleConstructionControl.Global:Install()
Core:AppendFunction("GameCallback_CanPlayerPlaceBuilding",BundleConstructionControl.Global.CanPlayerPlaceBuilding)end
function BundleConstructionControl.Global.CanPlayerPlaceBuilding(Cz5,UfgAV,LO0nqS,PIht9)
for bn,A666l08 in
pairs(BundleConstructionControl.Global.Data.TerritoryBlockCategories)do
if A666l08 then
for R02tO,oVO in pairs(A666l08)do
if oVO and
Logic.GetTerritoryAtPosition(LO0nqS,PIht9)==oVO then if
Logic.IsEntityTypeInCategory(UfgAV,bn)==1 then return false end end end end end
for X0NOlR5,drv in
pairs(BundleConstructionControl.Global.Data.TerritoryBlockEntities)do
if drv then for r,sZyXLp in pairs(drv)do
if sZyXLp and
Logic.GetTerritoryAtPosition(LO0nqS,PIht9)==sZyXLp then if UfgAV==X0NOlR5 then return false end end end end end
for nHUmh,VEw8 in
pairs(BundleConstructionControl.Global.Data.AreaBlockCategories)do
if VEw8 then
for QAD,R6Ky in pairs(VEw8)do
if
Logic.IsEntityTypeInCategory(UfgAV,R6Ky[1])==1 then if GetDistance(nHUmh,{X=LO0nqS,Y=PIht9})<R6Ky[2]then
return false end end end end end
for vq5u9jrx,kNsSSMzG in
pairs(BundleConstructionControl.Global.Data.AreaBlockEntities)do
if kNsSSMzG then for ZcV,WiZA in pairs(kNsSSMzG)do
if UfgAV==WiZA[1]then if
GetDistance(vq5u9jrx,{X=LO0nqS,Y=PIht9})<WiZA[2]then return false end end end end end;return true end;Core:RegisterBundle("BundleConstructionControl")
BundleDestructionControl={}API=API or{}QSB=QSB or{}
function API.ProtectEntity(K4SQ1h2e)
if not GUI then
API.Bridge([[
            API.ProtectEntity("]]..K4SQ1h2e..
[[")
        ]])else if not
Inside(_enitry,BundleDestructionControl.Local.Data.Entities)then
table.insert(BundleDestructionControl.Local.Data.Entities,K4SQ1h2e)end end end
function API.ProtectEntityType(y6z6ip)
if not GUI then
API.Bridge([[
            API.ProtectEntityType(]]..y6z6ip..[[)
        ]])else if not
Inside(_enitry,BundleDestructionControl.Local.Data.EntityTypes)then
table.insert(BundleDestructionControl.Local.Data.EntityTypes,y6z6ip)end end end
function API.ProtectCategory(v)
if not GUI then
API.Bridge([[
            API.ProtectCategory(]]..v..[[)
        ]])else
if not
Inside(_enitry,BundleDestructionControl.Local.Data.EntityCategories)then
table.insert(BundleDestructionControl.Local.Data.EntityCategories,v)end end end
function API.ProtectTerritory(Bu)
if not GUI then
API.Bridge([[
            API.ProtectTerritory(]]..Bu..[[)
        ]])else if not
Inside(Bu,BundleDestructionControl.Local.Data.OnTerritory)then
table.insert(BundleDestructionControl.Local.Data.OnTerritory,Bu)end end end
function API.UnprotectEntity(_TI)
if not GUI then
API.Bridge([[
            API.UnprotectEntity("]].._TI..[[")
        ]])else
for YE7=1,#BundleDestructionControl.Local.Data.Entities
do if
BundleDestructionControl.Local.Data.Entities[YE7]==_TI then
table.remove(BundleDestructionControl.Local.Data.Entities,YE7)return end end end end
function API.UnprotectEntityType(Q2e)
if not GUI then
API.Bridge([[
            API.UnprotectEntityType(]]..Q2e..[[)
        ]])else
for z=1,#BundleDestructionControl.Local.Data.EntityTypes
do if
BundleDestructionControl.Local.Data.EntityTypes[z]==Q2e then
table.remove(BundleDestructionControl.Local.Data.EntityTypes,z)return end end end end
function API.UnprotectCategory(Cy)
if not GUI then
API.Bridge([[
            API.UnprotectCategory(]]..Cy..[[)
        ]])else
for ZhG=1,#BundleDestructionControl.Local.Data.EntityCategories
do
if
BundleDestructionControl.Local.Data.EntityCategories[ZhG]==Cy then
table.remove(BundleDestructionControl.Local.Data.EntityCategories,ZhG)return end end end end
function API.UnprotectTerritory(ARBIKz)
if not GUI then
API.Bridge([[
            API.UnprotectTerritory(]]..ARBIKz..[[)
        ]])else
for p7=1,#BundleDestructionControl.Local.Data.OnTerritory
do if
BundleDestructionControl.Local.Data.OnTerritory[p7]==ARBIKz then
table.remove(BundleDestructionControl.Local.Data.OnTerritory,p7)return end end end end
BundleDestructionControl={Local={Data={Entities={},EntityTypes={},EntityCategories={},OnTerritory={}}}}
function BundleDestructionControl.Local:Install()
Core:AppendFunction("GameCallback_GUI_DeleteEntityStateBuilding",BundleDestructionControl.Local.DeleteEntityStateBuilding)end
function BundleDestructionControl.Local.DeleteEntityStateBuilding(j)
local zbC2yHd0=Logic.GetEntityType(j)local I=Logic.GetEntityName(j)
local Jt=GetTerritoryUnderEntity(j)
if Logic.IsConstructionComplete(j)==1 then
if
Inside(I,BundleDestructionControl.Local.Data.Entities)then GUI.CancelBuildingKnockDown(j)return end
if
Inside(zbC2yHd0,BundleDestructionControl.Local.Data.EntityTypes)then GUI.CancelBuildingKnockDown(j)return end
if
Inside(Jt,BundleDestructionControl.Local.Data.OnTerritory)then GUI.CancelBuildingKnockDown(j)return end
for aUu,We1INxkk in
pairs(BundleDestructionControl.Local.Data.EntityCategories)do if Logic.IsEntityInCategory(j,We1INxkk)==1 then
GUI.CancelBuildingKnockDown(j)return end end end end;Core:RegisterBundle("BundleDestructionControl")
BundleDialogWindows={}API=API or{}QSB=QSB or{}
function API.DialogInfoBox(X37Nsx,eE,pCWPYYE)if not GUI then
API.Fatal("API.DialogInfoBox: Can only be used in the local script!")return end
local g=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if type(X37Nsx)=="table"then X37Nsx=X37Nsx[g]end;if type(eE)==
"table"then eE=eE[g]end;return
BundleDialogWindows.Local:OpenDialog(X37Nsx,eE,pCWPYYE)end;UserOpenDialog=API.DialogInfoBox
function API.DialogRequestBox(kUNaj9,AiX,CzFcrl,X8Gpm3)if not GUI then
API.Fatal("API.DialogRequestBox: Can only be used in the local script!")return end
local Ewt=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if type(kUNaj9)=="table"then kUNaj9=kUNaj9[Ewt]end;if
type(AiX)=="table"then AiX=AiX[Ewt]end;return
BundleDialogWindows.Local:OpenRequesterDialog(kUNaj9,AiX,CzFcrl,X8Gpm3)end;UserOpenRequesterDialog=API.DialogRequestBox
function API.DialogSelectBox(TzK,jjU,DGflu,FF9q1AO)if not GUI then
API.Fatal("API.DialogSelectBox: Can only be used in the local script!")return end
local pJWQ=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if type(TzK)=="table"then TzK=TzK[pJWQ]end;if
type(jjU)=="table"then jjU=jjU[pJWQ]end;jjU=jjU.."{cr}"return
BundleDialogWindows.Local:OpenSelectionDialog(TzK,jjU,DGflu,FF9q1AO)end;UserOpenSelectionDialog=API.DialogSelectBox
function API.SimpleTextWindow(DZJXU,Oo6w)
local hN=(
Network.GetDesiredLanguage()=="de"and"de")or"en"if type(DZJXU)=="table"then DZJXU=DZJXU[hN]end;if type(Oo6w)==
"table"then Oo6w=Oo6w[hN]end;if not GUI then
API.Bridge("API.SimpleTextWindow('"..DZJXU..
"', '"..Oo6w.."')")return end
BundleDialogWindows.Local.TextWindow:New(DZJXU,Oo6w):Show()end
BundleDialogWindows={Global={Data={}},Local={Data={Requester={ActionFunction=nil,ActionRequester=nil,Next=nil,Queue={}}},TextWindow={Data={Shown=false,Caption="",Text="",ButtonText="",Picture=
nil,Action=nil,Callback=function()end}}}}function BundleDialogWindows.Global:Install()end
function BundleDialogWindows.Local:Install()
self:DialogOverwriteOriginal()TextWindow=self.TextWindow end
function BundleDialogWindows.Local:Callback()
if self.Data.Requester.ActionFunction then self.Data.Requester.ActionFunction(
CustomGame.Knight+1)end;self:OnDialogClosed()end
function BundleDialogWindows.Local:CallbackRequester(jz1uXDx)if
self.Data.Requester.ActionRequester then
self.Data.Requester.ActionRequester(jz1uXDx)end
self:OnDialogClosed()end
function BundleDialogWindows.Local:OnDialogClosed()
self:DialogQueueStartNext()self:RestoreSaveGame()end
function BundleDialogWindows.Local:DialogQueueStartNext()
self.Data.Requester.Next=table.remove(self.Data.Requester.Queue,1)
DialogQueueStartNext_HiResControl=function()
local vTRoD0X=BundleDialogWindows.Local.Data.Requester.Next
if vTRoD0X and vTRoD0X[1]and vTRoD0X[2]then local oX9O28J=vTRoD0X[1]
BundleDialogWindows.Local[oX9O28J](BundleDialogWindows.Local,unpack(vTRoD0X[2]))BundleDialogWindows.Local.Data.Requester.Next=
nil end;return true end
StartSimpleHiResJob("DialogQueueStartNext_HiResControl")end;function BundleDialogWindows.Local:DialogQueuePush(sTbHW,upZW)local AWQPjyxs={sTbHW,upZW}
table.insert(self.Data.Requester.Queue,AWQPjyxs)end
function BundleDialogWindows.Local:OpenDialog(V,M,sPh)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then assert(type(V)=="string")assert(
type(M)=="string")V="{center}"..V;if
string.len(M)<35 then M=M.."{cr}"end
g_MapAndHeroPreview.SelectKnight=function()end;XGUIEng.ShowAllSubWidgets("/InGame/Dialog/BG",1)
XGUIEng.ShowWidget("/InGame/Dialog/Backdrop",0)XGUIEng.ShowWidget(RequesterDialog,1)
XGUIEng.ShowWidget(RequesterDialog_Yes,0)XGUIEng.ShowWidget(RequesterDialog_No,0)
XGUIEng.ShowWidget(RequesterDialog_Ok,1)
if type(sPh)=="function"then
self.Data.Requester.ActionFunction=sPh;local RKD_1r="XGUIEng.ShowWidget(RequesterDialog, 0)"
RKD_1r=RKD_1r.."; XGUIEng.PopPage()"
RKD_1r=RKD_1r.."; BundleDialogWindows.Local.Callback(BundleDialogWindows.Local)"
XGUIEng.SetActionFunction(RequesterDialog_Ok,RKD_1r)else self.Data.Requester.ActionFunction=nil
local hnrLmi="XGUIEng.ShowWidget(RequesterDialog, 0)"hnrLmi=hnrLmi.."; XGUIEng.PopPage()"
hnrLmi=hnrLmi..
"; BundleDialogWindows.Local.Callback(BundleDialogWindows.Local)"
XGUIEng.SetActionFunction(RequesterDialog_Ok,hnrLmi)end
XGUIEng.SetText(RequesterDialog_Message,"{center}"..M)XGUIEng.SetText(RequesterDialog_Title,V)XGUIEng.SetText(
RequesterDialog_Title.."White",V)
XGUIEng.PushPage(RequesterDialog,false)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/QuickSave",0)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/SaveGame",0)
if not KeyBindings_SaveGame_Orig_QSB_Windows then
KeyBindings_SaveGame_Orig_QSB_Windows=KeyBindings_SaveGame;KeyBindings_SaveGame=function()end end else self:DialogQueuePush("OpenDialog",{V,M,sPh})end end
function BundleDialogWindows.Local:OpenRequesterDialog(Ea23,gdet,x,KzXd)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then
assert(type(Ea23)=="string")assert(type(gdet)=="string")
Ea23="{center}"..Ea23;self:OpenDialog(Ea23,gdet,x)
XGUIEng.ShowWidget(RequesterDialog_Yes,1)XGUIEng.ShowWidget(RequesterDialog_No,1)
XGUIEng.ShowWidget(RequesterDialog_Ok,0)
if KzXd~=nil then
XGUIEng.SetText(RequesterDialog_Yes,XGUIEng.GetStringTableText("UI_Texts/Ok_center"))
XGUIEng.SetText(RequesterDialog_No,XGUIEng.GetStringTableText("UI_Texts/Cancel_center"))else
XGUIEng.SetText(RequesterDialog_Yes,XGUIEng.GetStringTableText("UI_Texts/Yes_center"))
XGUIEng.SetText(RequesterDialog_No,XGUIEng.GetStringTableText("UI_Texts/No_center"))end;self.Data.Requester.ActionRequester=nil
if x then
assert(type(x)=="function")self.Data.Requester.ActionRequester=x end;local gqa3M1="XGUIEng.ShowWidget(RequesterDialog, 0)"
gqa3M1=gqa3M1 .."; XGUIEng.PopPage()"
gqa3M1=gqa3M1 .."; BundleDialogWindows.Local.CallbackRequester(BundleDialogWindows.Local, true)"
XGUIEng.SetActionFunction(RequesterDialog_Yes,gqa3M1)local gqa3M1="XGUIEng.ShowWidget(RequesterDialog, 0)"
gqa3M1=gqa3M1 .."; XGUIEng.PopPage()"
gqa3M1=gqa3M1 .."; BundleDialogWindows.Local.CallbackRequester(BundleDialogWindows.Local, false)"
XGUIEng.SetActionFunction(RequesterDialog_No,gqa3M1)else
self:DialogQueuePush("OpenRequesterDialog",{Ea23,gdet,x,KzXd})end end
function BundleDialogWindows.Local:OpenSelectionDialog(Z,neYEY,H0,r)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then self:OpenDialog(Z,neYEY,H0)
local JF4a=XGUIEng.GetWidgetID(CustomGame.Widget.KnightsList)XGUIEng.ListBoxPopAll(JF4a)for xfxoXu=1,#r do
XGUIEng.ListBoxPushItem(JF4a,r[xfxoXu])end
XGUIEng.ListBoxSetSelectedIndex(JF4a,0)CustomGame.Knight=0;local HeQL="XGUIEng.ShowWidget(RequesterDialog, 0)"HeQL=HeQL..
"; XGUIEng.PopPage()"HeQL=HeQL.."; XGUIEng.PopPage()"HeQL=
HeQL.."; XGUIEng.PopPage()"HeQL=HeQL..
"; BundleDialogWindows.Local.Callback(BundleDialogWindows.Local)"
XGUIEng.SetActionFunction(RequesterDialog_Ok,HeQL)local AuacAxlc="/InGame/Singleplayer/CustomGame/ContainerSelection/"
XGUIEng.SetText(
AuacAxlc.."HeroComboBoxMain/HeroComboBox","")if r[1]then
XGUIEng.SetText(AuacAxlc.."HeroComboBoxMain/HeroComboBox",r[1])end
XGUIEng.PushPage(AuacAxlc.."HeroComboBoxContainer",false)
XGUIEng.PushPage(AuacAxlc.."HeroComboBoxMain",false)
XGUIEng.ShowWidget(AuacAxlc.."HeroComboBoxContainer",0)local Bk={GUI.GetScreenSize()}
local IulFXIJ,b=XGUIEng.GetWidgetScreenPosition(RequesterDialog_Ok)
XGUIEng.SetWidgetScreenPosition(AuacAxlc.."HeroComboBoxMain",IulFXIJ-25,b-90)
XGUIEng.SetWidgetScreenPosition(AuacAxlc.."HeroComboBoxContainer",IulFXIJ-25,b-20)else
self:DialogQueuePush("OpenSelectionDialog",{Z,neYEY,H0,r})end end
function BundleDialogWindows.Local:RestoreSaveGame()
if BundleGameHelperFunctions and not
BundleGameHelperFunctions.Local.Data.ForbidSave then
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/QuickSave",1)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/SaveGame",1)end
if KeyBindings_SaveGame_Orig_QSB_Windows then
KeyBindings_SaveGame=KeyBindings_SaveGame_Orig_QSB_Windows;KeyBindings_SaveGame_Orig_QSB_Windows=nil end end
function BundleDialogWindows.Local:DialogOverwriteOriginal()
OpenDialog_Orig_Windows=OpenDialog
OpenDialog=function(KJ0Y6,KPlOw,C)
if XGUIEng.IsWidgetShown(RequesterDialog)==0 then
local BA="XGUIEng.ShowWidget(RequesterDialog, 0)"BA=BA.."; XGUIEng.PopPage()"
XGUIEng.SetActionFunction(RequesterDialog_Ok,BA)OpenDialog_Orig_Windows(KPlOw,KJ0Y6)end end;OpenRequesterDialog_Orig_Windows=OpenRequesterDialog
OpenRequesterDialog=function(ybxsK,_0fP,l6,rGOqO96U,odN0bo)
if
XGUIEng.IsWidgetShown(RequesterDialog)==0 then local sn1BOCT5="XGUIEng.ShowWidget(RequesterDialog, 0)"sn1BOCT5=
sn1BOCT5 .."; XGUIEng.PopPage()"
XGUIEng.SetActionFunction(RequesterDialog_Yes,sn1BOCT5)local sn1BOCT5="XGUIEng.ShowWidget(RequesterDialog, 0)"
sn1BOCT5=sn1BOCT5 .."; XGUIEng.PopPage()"
XGUIEng.SetActionFunction(RequesterDialog_No,sn1BOCT5)
OpenRequesterDialog_Orig_Windows(ybxsK,_0fP,l6,rGOqO96U,odN0bo)end end end
function BundleDialogWindows.Local.TextWindow:New(...)
assert(self==
BundleDialogWindows.Local.TextWindow,"Can not be used from instance!")local k0iue=API.InstanceTable(self)k0iue.Data.Caption=arg[1]or
k0iue.Data.Caption
k0iue.Data.Text=arg[2]or k0iue.Data.Text;k0iue.Data.Action=arg[3]
k0iue.Data.ButtonText=arg[4]or k0iue.Data.ButtonText
k0iue.Data.Callback=arg[5]or k0iue.Data.Callback;return k0iue end
function BundleDialogWindows.Local.TextWindow:AddParamater(J5,d3)
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")
assert(self.Data[J5]~=nil,"Key '"..J5 .."' already exists!")self.Data[J5]=d3;return self end
function BundleDialogWindows.Local.TextWindow:SetCaption(DAeG)
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")local eb6VK=
(Network.GetDesiredLanguage()=="de"and"de")or"en"if
type(DAeG)=="table"then DAeG=DAeG[eb6VK]end
assert(type(DAeG)=="string")self.Data.Caption=DAeG;return self end
function BundleDialogWindows.Local.TextWindow:SetContent(U8PPAC)
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")local bK92X9wQ=
(Network.GetDesiredLanguage()=="de"and"de")or"en"if
type(U8PPAC)=="table"then U8PPAC=U8PPAC[bK92X9wQ]end
assert(type(U8PPAC)=="string")self.Data.Text=U8PPAC;return self end
function BundleDialogWindows.Local.TextWindow:SetAction(PZ)
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")assert(nil or type(PZ)=="function")
self.Data.Callback=PZ;return self end
function BundleDialogWindows.Local.TextWindow:SetButton(toG0,EZ3qRhLq)
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")
if toG0 then local E7Q=
(Network.GetDesiredLanguage()=="de"and"de")or"en"if
type(toG0)=="table"then toG0=toG0[E7Q]end
assert(type(toG0)=="string")assert(type(EZ3qRhLq)=="function")end;self.Data.ButtonText=toG0;self.Data.Action=EZ3qRhLq;return self end
function BundleDialogWindows.Local.TextWindow:Show()
assert(self~=
BundleDialogWindows.Local.TextWindow,"Can not be used in static context!")
BundleDialogWindows.Local.TextWindow.Data.Shown=true;self.Data.Shown=true;self:Prepare()
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ToggleWhisperTarget",1)if not self.Data.Action then
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ToggleWhisperTarget",0)end
XGUIEng.SetText("/InGame/Root/Normal/MessageLog/Name",
"{center}"..self.Data.Caption)
XGUIEng.SetText("/InGame/Root/Normal/ChatOptions/ToggleWhisperTarget","{center}"..self.Data.ButtonText)GUI_Chat.ClearMessageLog()
GUI_Chat.ChatlogAddMessage(self.Data.Text)local qts06Ch3=string.len(self.Data.Text)local cBwDRgK=1;local veqNhn=0
while
(true)do
local OiD,prw2Jl=string.find(self.Data.Text,"{cr}",cBwDRgK)if not prw2Jl then break end;if prw2Jl-cBwDRgK<=58 then qts06Ch3=qts06Ch3+58-
(prw2Jl-cBwDRgK)end
cBwDRgK=prw2Jl+1 end;if(qts06Ch3+ (veqNhn*55))>1000 then
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatLogSlider",1)end
Game.GameTimeSetFactor(GUI.GetPlayerID(),0)end
function BundleDialogWindows.Local.TextWindow:Prepare()
function GUI_Chat.CloseChatMenu()
BundleDialogWindows.Local.TextWindow.Data.Shown=false;self.Data.Shown=false;if self.Data.Callback then
self.Data.Callback(self)end
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/BG",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Close",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Slider",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Text",1)Game.GameTimeReset(GUI.GetPlayerID())end;function GUI_Chat.ToggleWhisperTargetUpdate()
Game.GameTimeSetFactor(GUI.GetPlayerID(),0)end;function GUI_Chat.CheckboxMessageTypeWhisperUpdate()
XGUIEng.SetText("/InGame/Root/Normal/ChatOptions/TextCheckbox",
"{center}"..self.Data.Caption)end
function GUI_Chat.ToggleWhisperTarget()if
self.Data.Action then self.Data.Action(self)end end;function GUI_Chat.ClearMessageLog()g_Chat.ChatHistory={}end
function GUI_Chat.ChatlogAddMessage(DYo)
table.insert(g_Chat.ChatHistory,DYo)local kcCL9hT=""
for pvg,M in ipairs(g_Chat.ChatHistory)do kcCL9hT=kcCL9hT..M.."{cr}"end
XGUIEng.SetText("/InGame/Root/Normal/ChatOptions/ChatLog",kcCL9hT)end;local oo=
(Network.GetDesiredLanguage()=="de"and"de")or"en"if
type(self.Data.Caption)=="table"then
self.Data.Caption=self.Data.Caption[oo]end;if type(self.Data.ButtonText)==
"table"then
self.Data.ButtonText=self.Data.ButtonText[oo]end
if
type(self.Data.Text)=="table"then self.Data.Text=self.Data.Text[oo]end
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatModeAllPlayers",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatModeTeam",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatModeWhisper",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatChooseModeCaption",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/Background/TitleBig",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/Background/TitleBig/Info",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatLogCaption",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/BGChoose",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/BGChatLog",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatOptions/ChatLogSlider",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/BG",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Close",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Slider",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/MessageLog/Text",0)
XGUIEng.DisableButton("/InGame/Root/Normal/ChatOptions/ToggleWhisperTarget",0)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/MessageLog",0,95)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/MessageLog/Name",0,0)
XGUIEng.SetTextColor("/InGame/Root/Normal/MessageLog/Name",51,51,121,255)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/ChatOptions/ChatLog",140,150)
XGUIEng.SetWidgetSize("/InGame/Root/Normal/ChatOptions/Background/DialogBG/1 (2)/2",150,400)
XGUIEng.SetWidgetPositionAndSize("/InGame/Root/Normal/ChatOptions/Background/DialogBG/1 (2)/3",400,500,350,400)
XGUIEng.SetWidgetSize("/InGame/Root/Normal/ChatOptions/ChatLog",640,580)
XGUIEng.SetWidgetSize("/InGame/Root/Normal/ChatOptions/ChatLogSlider",46,660)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/ChatOptions/ChatLogSlider",780,130)
XGUIEng.SetWidgetLocalPosition("/InGame/Root/Normal/ChatOptions/ToggleWhisperTarget",110,760)end;Core:RegisterBundle("BundleDialogWindows")
BundleEntityCommandFunctions={}API=API or{}QSB=QSB or{}
function API.SetPosition(USR,Wxk9CBfb)
if GUI then local jWPa=
(type(USR)~="string"and USR)or"'"..USR.."'"
local d=Wxk9CBfb
if type(d)=="table"then d="{X= "..
tostring(d.X)..", Y= "..tostring(d.Y).."}"end
API.Bridge("API.SetPosition("..jWPa..", "..d..")")return end
if not IsExisting(USR)then local j3Fn=(type(USR)~="string"and USR)or"'"..
USR.."'"
API.Fatal(
"API.SetPosition: Entity "..j3Fn.." does not exist!")return end;local V=API.LocateEntity(Wxk9CBfb)if
not API.ValidatePosition(V)then
API.Fatal("API.SetPosition: Position is invalid!")return end;return
BundleEntityCommandFunctions.Global:SetPosition(USR,V)end;SetPosition=API.SetPosition
function API.MoveToPosition(oZ65m5,hQjlCjY,JDyNU5,cMv6ou,HPZKRJ)
if GUI then
API.Bridge("API.MoveToPosition("..
GetID(oZ65m5)..", "..

GetID(hQjlCjY)..", "..JDyNU5 ..
", "..cMv6ou..", "..tostring(HPZKRJ)..")")return end
if not IsExisting(oZ65m5)then
local cn=
(type(oZ65m5)~="string"and oZ65m5)or"'"..oZ65m5 .."'"
API.Fatal("API.MoveToPosition: Entity "..cn.." does not exist!")return end
if not IsExisting(hQjlCjY)then
local _Yf=
(type(hQjlCjY)~="string"and hQjlCjY)or"'"..hQjlCjY.."'"
API.Fatal("API.MoveToPosition: Entity ".._Yf.." does not exist!")return end;return
BundleEntityCommandFunctions.Global:MoveToPosition(oZ65m5,hQjlCjY,JDyNU5,cMv6ou,HPZKRJ)end
MoveEntityToPositionToAnotherOne=function(rl,Z,jOFP,LCqNO,jF4YoB)
API.MoveToPosition(rl,jOFP,Z,LCqNO,jF4YoB)end
function API.MoveAndLookAt(nROZ,_GVROa,bO3YuZv,Vq)if GUI then
API.Bridge("API.MoveAndLookAt("..GetID(nROZ)..
", "..GetID(_GVROa)..", "..bO3YuZv..", "..
tostring(Vq)..")")return end
if not
IsExisting(nROZ)then local cW=(type(nROZ)~="string"and nROZ)or
"'"..nROZ.."'"
API.Fatal("API.MoveAndLookAt: Entity "..cW..
" does not exist!")return end
if not IsExisting(_GVROa)then
local c7GfSrtA=
(type(_GVROa)~="string"and _GVROa)or"'".._GVROa.."'"
API.Fatal("API.MoveAndLookAt: Entity "..c7GfSrtA.." does not exist!")return end;return
BundleEntityCommandFunctions.Global:MoveAndLookAt(nROZ,_GVROa,bO3YuZv,Vq)end
MoveEntityFaceToFaceToAnotherOne=function(lEP9VGU,xpKd,r,oa)API.MoveAndLookAt(lEP9VGU,r,xpKd,oa)end;MoveEx=API.MoveAndLookAt
function API.PlaceToPosition(dT,xa78yAit,s_CnSV,s)if GUI then
API.Bridge("API.PlaceToPosition("..GetID(dT)..
", "..
GetID(xa78yAit)..", "..s_CnSV..", "..s..")")return end
if not
IsExisting(dT)then
local w3nHh=(type(dT)~="string"and dT)or"'"..dT.."'"
API.Fatal("API.PlaceToPosition: Entity "..w3nHh.." does not exist!")return end
if not IsExisting(xa78yAit)then
local bo0I=
(type(xa78yAit)~="string"and xa78yAit)or"'"..xa78yAit.."'"
API.Fatal("API.PlaceToPosition: Entity "..bo0I.." does not exist!")return end
local wqRzXIG7=BundleEntityCommandFunctions.Shared:GetRelativePos(xa78yAit,s_CnSV,s,true)API.SetPosition(dT,wqRzXIG7)end
PlaceEntityToPositionToAnotherOne=function(lK5ogD,I8F,Y3NU,Avel7IrZ)
API.PlaceToPosition(lK5ogD,Y3NU,I8F,Avel7IrZ)end
function API.PlaceAndLookAt(F,_,DpWpo7kA)if GUI then
API.Bridge("API.PlaceAndLookAt("..GetID(F)..", "..
GetID(_)..", "..DpWpo7kA..")")return end
API.PlaceToPosition(F,_,DpWpo7kA,0)LookAt(F,_)end
PlaceEntityFaceToFaceToAnotherOne=function(LS,cQvh,llU3aki)API.PlaceAndLookAt(LS,llU3aki,cQvh)end;SetPositionEx=API.PlaceAndLookAt
function API.CommandAttack(HQrwQErj,tu)if GUI then
API.Bridge("API.CommandAttack("..GetID(HQrwQErj)..
", "..GetID(tu)..")")return end
if
not IsExisting(HQrwQErj)then local XSuzlcm=
(type(HQrwQErj)=="string"and"'"..HQrwQErj.."'")or HQrwQErj
API.Fatal(
"API.CommandAttack: Entity "..XSuzlcm.." does not exist!")return end
if not IsExisting(tu)then local nbAjk49J=
(type(tu)=="string"and"'"..tu.."'")or tu
API.Fatal("API.CommandAttack: Target "..nbAjk49J..
" does not exist!")return end;return
BundleEntityCommandFunctions.Global:Attack(HQrwQErj,tu)end;Attack=API.CommandAttack
function API.CommandAttackMove(cB0vBn,IccvGO)if GUI then
API.Fatal("API.CommandAttackMove: Cannot be used from local script!")return end
if
not IsExisting(cB0vBn)then local s3=
(type(cB0vBn)=="string"and"'"..cB0vBn.."'")or cB0vBn
API.Fatal(
"API.CommandAttackMove: Entity "..s3 .." does not exist!")return end;local BNC=API.LocateEntity(IccvGO)if
not API.ValidatePosition(BNC)then
API.Fatal("API.CommandAttackMove: Position is invalid!")return end;return
BundleEntityCommandFunctions.Global:AttackMove(cB0vBn,BNC)end;AttackMove=API.CommandAttackMove
function API.CommandMove(QXOjuVP,KOk)if GUI then
API.Fatal("API.CommandMove: Cannot be used from local script!")return end
if not IsExisting(QXOjuVP)then local B=
(
type(QXOjuVP)=="string"and"'"..QXOjuVP.."'")or QXOjuVP
API.Fatal(
"API.CommandMove: Entity "..B.." does not exist!")return end;local GQ8QsA=API.LocateEntity(KOk)if
not API.ValidatePosition(GQ8QsA)then
API.Fatal("API.CommandMove: Position is invalid!")return end;return
BundleEntityCommandFunctions.Global:Move(QXOjuVP,GQ8QsA)end;Move=API.CommandMove
BundleEntityCommandFunctions={Global={Data={}},Shared={Data={}}}
function BundleEntityCommandFunctions.Global:Install()end
function BundleEntityCommandFunctions.Global:SetPosition(i,zmF)if
not IsExisting(i)then return end;local RKBSOvv=GetEntityId(i)
Logic.DEBUG_SetSettlerPosition(RKBSOvv,zmF.X,zmF.Y)
if Logic.IsLeader(RKBSOvv)==1 then
local GxQqHPYH={Logic.GetSoldiersAttachedToLeader(RKBSOvv)}
if GxQqHPYH[1]>0 then for KEhfU=1,#GxQqHPYH do
Logic.DEBUG_SetSettlerPosition(GxQqHPYH[KEhfU],zmF.X,zmF.Y)end end end end
function BundleEntityCommandFunctions.Global:MoveToPosition(zufQE,QwSnT,WrvmQJ6,rOMAEo,SFGo78)if
not IsExisting(zufQE)then return end;if not WrvmQJ6 then WrvmQJ6=0 end
local LTd5=GetID(zufQE)local JmrwaH=GetID(QwSnT)
local qqciA=BundleEntityCommandFunctions.Shared:GetRelativePos(QwSnT,WrvmQJ6)if type(rOMAEo)=="number"then
qqciA=BundleEntityCommandFunctions.Shared:GetRelativePos(QwSnT,WrvmQJ6,rOMAEo)end
if SFGo78 then
Logic.MoveEntity(LTd5,qqciA.X,qqciA.Y)else Logic.MoveSettler(LTd5,qqciA.X,qqciA.Y)end
StartSimpleJobEx(function(bgKb,b0q)if not Logic.IsEntityMoving(bgKb)then LookAt(bgKb,b0q)
return true end end,LTd5,JmrwaH)end
function BundleEntityCommandFunctions.Global:MoveAndLookAt(MRluMhh,n0R1Mj,a4j6,lg6u)if
not IsExisting(MRluMhh)then return end;if not a4j6 then a4j6=0 end
self:MoveToPosition(MRluMhh,n0R1Mj,a4j6,0,lg6u)
StartSimpleJobEx(function(ubseU,kfDX)if not Logic.IsEntityMoving(ubseU)then
LookAt(ubseU,kfDX)return true end end,GetID(MRluMhh),GetID(n0R1Mj))end
function BundleEntityCommandFunctions.Global:Attack(g26,HDP)local c6nlekUb=GetID(g26)
local NJQ0=GetID(HDP)Logic.GroupAttack(c6nlekUb,NJQ0)end;function BundleEntityCommandFunctions.Global:AttackMove(o_v3,zI)local ET=GetID(o_v3)
Logic.GroupAttackMove(ET,zI.X,zI.Y)end
function BundleEntityCommandFunctions.Global:Move(RPrsE2M,T2WO5I)
local f7pL=GetID(RPrsE2M)Logic.MoveSettler(f7pL,T2WO5I.X,T2WO5I.Y)end
function BundleEntityCommandFunctions.Shared:GetRelativePos(bHs,eThxHw,tJVrOA,tqJFy)
if
not type(bHs)=="table"and not IsExisting(bHs)then return end;if tJVrOA==nil then tJVrOA=0 end;local EoFG
if type(bHs)=="table"then local DQsI=bHs
local Cam=0+tJVrOA
EoFG={X=DQsI.X+eThxHw*math.cos(math.rad(Cam)),Y=
DQsI.Y+eThxHw*math.sin(math.rad(Cam))}else local wF77=GetID(bHs)local A5pk0=GetPosition(wF77)local j=
Logic.GetEntityOrientation(wF77)+tJVrOA
if
Logic.IsBuilding(wF77)==1 and not tqJFy then
x,y=Logic.GetBuildingApproachPosition(wF77)A5pk0={X=x,Y=y}j=j-90 end
EoFG={X=A5pk0.X+eThxHw*math.cos(math.rad(j)),Y=
A5pk0.Y+eThxHw*math.sin(math.rad(j))}end;return EoFG end
Core:RegisterBundle("BundleEntityCommandFunctions")BundleEntityHealth={}function API.GetEntityHealth(XE)return
BundleEntityHealth.Shared:GetHealth(XE)end
GetHealth=API.GetEntityHealth
function API.ChangeEntityHealth(vtfBBQgI,U1Ca2x)
if GUI then local AM_2j6=
(type(vtfBBQgI)=="string"and"'"..vtfBBQgI.."'")or vtfBBQgI
API.Bridge(
"API.ChangeEntityHealth("..AM_2j6 ..", "..U1Ca2x..")")return end
if not IsExisting(vtfBBQgI)then
local tqvqCh=(type(vtfBBQgI)=="string"and
"'"..vtfBBQgI.."'")or vtfBBQgI
API.Fatal("API.ChangeEntityHealth: _Entity "..tqvqCh.." does not exist!")return end;if type(U1Ca2x)~="number"then
API.Fatal("API.ChangeEntityHealth: _Percentage must be a number!")return end;U1Ca2x=
(U1Ca2x<0 and 0)or U1Ca2x;if U1Ca2x>100 then
API.Warn("API.ChangeEntityHealth: _Percentage is larger than 100%. This could cause problems!")end
BundleEntityHealth.Global:SetEntityHealth(vtfBBQgI,U1Ca2x)end;SetHealth=API.ChangeEntityHealth
function API.SetBuildingOnFire(wQb3,MV_ePmkQ)
if GUI then
local cX3Y=(type(wQb3)=="string"and"'"..
wQb3 .."'")or wQb3
API.Bridge("API.SetBuildingOnFire("..cX3Y..", "..MV_ePmkQ..")")return end
if not IsExisting(wQb3)then local dOb=
(type(wQb3)=="string"and"'"..wQb3 .."'")or wQb3
API.Fatal(
"API.SetBuildingOnFire: Entity "..dOb.." does not exist!")return end;if Logic.IsBuilding(GetID(wQb3))==0 then
API.Fatal("API.SetBuildingOnFire: Only buildings can be set on fire!")return end;if
type(MV_ePmkQ)~="number"then
API.Fatal("API.SetBuildingOnFire: _Strength must be a number!")return end;MV_ePmkQ=
(MV_ePmkQ<0 and 0)or MV_ePmkQ
Logic.DEBUG_SetBuildingOnFile(GetID(wQb3),MV_ePmkQ)end;SetOnFire=API.SetBuildingOnFire
function API.HurtEntity(JTBnP,Nm,sCwnNPE)
if GUI then
local _WlOka=(type(JTBnP)=="string"and"'"..
JTBnP.."'")or JTBnP;local tFt48gVX=
(type(sCwnNPE)=="string"and"'"..sCwnNPE.."'")or sCwnNPE
API.Bridge(
"API.HurtEntity(".._WlOka..
", "..Nm..", "..tostring(tFt48gVX)..")")return end
if not IsExisting(JTBnP)then local VcvWqUR=
(type(JTBnP)=="string"and"'"..JTBnP.."'")or JTBnP
API.Warn(
"API.HurtEntity: Entity "..JTBnP.." does not exist!")return end;if type(Nm)~="number"or Nm<0 then
API.Fatal("API.HurtEntity: _AmountOfDamage must be a number greater or equal 0!")return end
local J=GetID(JTBnP)local jUlV2=GetID(sCwnNPE)return
BundleEntityHealth.Global:HurtEntityEx(J,Nm,jUlV2)end;HurtEntityEx=API.HurtEntity
function API.AddOnEntityHurtAction(g9LOIN)if GUI then
API.Fatal("API.AddOnEntityHurtAction: Can not be used in local script!")return end
if
type(g9LOIN)~="function"then API.Fatal("_Function must be a function!")return end
BundleEntityHealth.Global.AddOnEntityHurtAction(g9LOIN)end;AddHurtAction=API.AddOnEntityHurtAction
function API.AddOnEntityDestroyedAction(Ldc7)if GUI then
API.Fatal("API.AddOnEntityDestroyedAction: Can not be used in local script!")return end
if
type(Ldc7)~="function"then API.Fatal("_Function must be a function!")return end
BundleEntityHealth.Global.AddOnEntityDestroyedAction(Ldc7)end;AddKilledAction=API.AddOnEntityDestroyedAction
function API.AddOnEntityCreatedAction(OWMI6)if GUI then
API.Fatal("API.AddOnEntityCreatedAction: Can not be used in local script!")return end
if
type(OWMI6)~="function"then API.Fatal("_Function must be a function!")return end
BundleEntityHealth.Global.AddOnEntityCreatedAction(OWMI6)end;AddSpawnedAction=API.AddOnEntityCreatedAction
BundleEntityHealth={Global={Data={OnEntityCreatedAction={},OnEntityDestroyedAction={},OnEntityHurtAction={}}},Local={Data={}},Shared={Data={}}}
function BundleEntityHealth.Global:Install()
BundleEntityHealth_EntityHurtEntityController=self.EntityHurtEntityController
Trigger.RequestTrigger(Events.LOGIC_EVENT_ENTITY_HURT_ENTITY,"","BundleEntityHealth_EntityHurtEntityController",1)
BundleEntityHealth_EntityDestroyedController=self.EntityDestroyedController
Trigger.RequestTrigger(Events.LOGIC_EVENT_ENTITY_DESTROYED,"","BundleEntityHealth_EntityDestroyedController",1)
Core:AppendFunction("GameCallback_SettlerSpawned",self.EntityCreatedController)end
function BundleEntityHealth.Global:SetEntityHealth(y,PN)
if not IsExisting(y)then return end;local D4=GetID(y)local bqUq2I19=Logic.GetEntityMaxHealth(D4)
local vfT16V9=Logic.GetEntityHealth(D4)
local Idod8USP=math.floor((bqUq2I19* (PN/100))+0.5)Logic.HealEntity(D4,bqUq2I19-vfT16V9)Logic.HurtEntity(D4,
bqUq2I19-Idod8USP)end
function BundleEntityHealth.Global:HurtEntityEx(n,Enpu,F)
if IsExisting(n)then local ed=0;if
Logic.IsEntityInCategory(n,EntityCategories.Soldier)==1 then
ed=Logic.SoldierGetLeaderEntityID(n)end;if
Logic.IsEntityInCategory(n,EntityCategories.Leader)==1 then ed=n end
if ed~=nil and
ed~=0 then
local QamDb5OV={Logic.GetSoldiersAttachedToLeader(ed)}if QamDb5OV[1]==nil then QamDb5OV[1]=0 end
if QamDb5OV[1]>0 then
local Jz=0;local by73=1000;for sbbJI=1,#QamDb5OV do
local QYayh=Logic.GetEntityHealth(QamDb5OV[sbbJI])
if QYayh<by73 and QYayh>0 then by73=QYayh;Jz=QamDb5OV[sbbJI]end end;local lQlrrh=QamDb5OV[
#QamDb5OV]
if Jz~=nil and Jz~=0 then lQlrrh=Jz end;local XQtO=0;local JefwEh=Enpu
if IsExisting(lQlrrh)then
XQtO=Logic.GetEntityHealth(lQlrrh)JefwEh=Enpu-XQtO
if XQtO<=Enpu then
if F and XQtO>0 then
GameCallback_EntityKilled(n,Logic.EntityGetPlayer(n),F,Logic.EntityGetPlayer(F),Logic.GetEntityType(n),Logic.GetEntityType(F))local nr6uCL,FQ1oRl_,Q=Logic.EntityGetPos(n)
Logic.ExecuteInLuaLocalState(
"GameCallback_Feedback_EntityKilled("..
""..
n..
","..
""..
Logic.EntityGetPlayer(n)..
","..""..
F..","..
""..Logic.EntityGetPlayer(F)..
","..""..

Logic.GetEntityType(n)..","..
""..Logic.GetEntityType(F)..","..
""..nr6uCL..","..FQ1oRl_..")")end;Logic.HurtEntity(lQlrrh,XQtO)else
Logic.HurtEntity(lQlrrh,Enpu)end end;if JefwEh>0 then HurtEntityEx(ed,JefwEh,F)end end else local sHA_0P=Logic.GetEntityHealth(n)
if sHA_0P<=Enpu then
if F and sHA_0P>0 then
GameCallback_EntityKilled(n,Logic.EntityGetPlayer(n),F,Logic.EntityGetPlayer(F),Logic.GetEntityType(n),Logic.GetEntityType(F))local zskX,z37Qz,MUu=Logic.EntityGetPos(n)
Logic.ExecuteInLuaLocalState(
"GameCallback_Feedback_EntityKilled("..
""..
n..
","..
""..
Logic.EntityGetPlayer(n)..","..
""..F..
","..""..
Logic.EntityGetPlayer(F)..","..
""..
Logic.GetEntityType(n)..
","..""..Logic.GetEntityType(F)..
","..""..zskX..","..z37Qz..")")end;Logic.HurtEntity(n,sHA_0P)else
Logic.HurtEntity(n,Enpu)end end end end;function BundleEntityHealth.Global.AddOnEntityHurtAction(rRNsXW)
table.insert(BundleEntityHealth.Global.Data.OnEntityHurtAction,rRNsXW)end
function BundleEntityHealth.Global.AddOnEntityDestroyedAction(zslu25lH)
table.insert(BundleEntityHealth.Global.Data.OnEntityDestroyedAction,zslu25lH)end;function BundleEntityHealth.Global.AddOnEntityCreatedAction(K)
table.insert(BundleEntityHealth.Global.Data.OnEntityCreatedAction,K)end
function BundleEntityHealth.Global.EntityHurtEntityController()
local dBzmP={Event.GetEntityID1()}local obk={Event.GetEntityID2()}
for MsipHD_w=1,#dBzmP,1 do
for uBw1Z77=1,#obk,1 do
local bdJJE=dBzmP[MsipHD_w]local spYT=obk[uBw1Z77]
if IsExisting(bdJJE)and IsExisting(spYT)then
for lEPWTkAE,S in
pairs(BundleEntityHealth.Global.Data.OnEntityHurtAction)do if S then S(bdJJE,spYT)end end end end end end
function BundleEntityHealth.Global.EntityDestroyedController()
local Zbxec={Event.GetEntityID()}
for ViHDT=1,#Zbxec,1 do local fcbl4H=Zbxec[ViHDT]
for ora4Z,wmfjOlWH in
pairs(BundleEntityHealth.Global.Data.OnEntityDestroyedAction)do if wmfjOlWH then wmfjOlWH(fcbl4H)end end end end
function BundleEntityHealth.Global.EntityCreatedController(d)
for w60sb3_,MCm__CEC in
pairs(BundleEntityHealth.Global.Data.OnEntityDestroyedAction)do if MCm__CEC then MCm__CEC(d)end end end;function BundleEntityHealth.Local:Install()end
function BundleEntityHealth.Shared:GetHealth(Jr9hz4jk)if
not IsExisting(Jr9hz4jk)then return 0 end
local Abv=GetID(Jr9hz4jk)local aqOk=Logic.GetEntityMaxHealth(Abv)
local A4ZSOV=Logic.GetEntityHealth(Abv)return(A4ZSOV/aqOk)*100 end;Core:RegisterBundle("BundleEntityHealth")function Reprisal_SetHealth(...)return
b_Reprisal_SetHealth:new(...)end
b_Reprisal_SetHealth={Name="Reprisal_SetHealth",Description={en="Reprisal: Changes the health of an entity.",de="Vergeltung: Setzt die Gesundheit eines Entity."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Number,en="Percentage",de="Prozentsatz"}}}
function b_Reprisal_SetHealth:GetRewardTable(wtbkXqKs)return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_SetHealth:AddParameter(vX_5TSFO,MFweCJ3)if(vX_5TSFO==0)then self.Entity=MFweCJ3 elseif
(vX_5TSFO==1)then self.Percentage=MFweCJ3 end end;function b_Reprisal_SetHealth:CustomFunction(z6)
SetHealth(self.Entity,self.Percentage)end
function b_Reprisal_SetHealth:DEBUG(n0q2)if not
IsExisting(self.Entity)then
dbg(n0q2.Identifier..
" "..self.Name..": Entity is dead! :(")end
if self.Percentage<0 or
self.Percentage>100 then
dbg(n0q2.Identifier.." "..
self.Name..": Percentage must be between 0 and 100!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_SetHealth)function Reward_SetHealth(...)return
b_Reward_SetHealth:new(...)end
b_Reward_SetHealth=API.InstanceTable(b_Reprisal_SetHealth)b_Reward_SetHealth.Name="Reward_SetHealth"
b_Reward_SetHealth.Description.en="Reward: Changes the health of an entity."
b_Reward_SetHealth.Description.de="Lohn: Setzt die Gesundheit eines Entity."b_Reward_SetHealth.GetReprisalTable=nil
b_Reward_SetHealth.GetRewardTable=function(X2UHF,uanm)return
{Reward.Custom,{X2UHF,X2UHF.CustomFunction}}end
function b_Reward_SetHealth:DEBUG(BJf2)if not IsExisting(self.Entity)then
dbg(BJf2.Identifier.." "..
self.Name..": Entity is dead! :(")return true end
if
self.Percentage<0 or self.Percentage>100 then
dbg(BJf2.Identifier.." "..self.Name..
": Percentage must be between 0 and 100!")return true end;return false end;Core:RegisterBehavior(b_Reward_SetHealth)function Trigger_EntityHealth(...)return
b_Trigger_EntityHealth:new(...)end
b_Trigger_EntityHealth={Name="Trigger_EntityHealth",Description={en="Trigger: The health of a unit must reach a certain point.",de="Auslöser: Die Gesundheit eines Entity muss einen bestimmten Wert erreichen."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Percentage",de="Prozentwert"}}}
function b_Trigger_EntityHealth:GetTriggerTable(bV)return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_EntityHealth:AddParameter(hhe,hw)
if(hhe==0)then self.ScriptName=hw elseif(hhe==1)then self.BeSmalerThan=
hw=="<"elseif(hhe==2)then self.Percentage=hw end end
function b_Trigger_EntityHealth:GetCustomData(Xjh2)if Xjh2 ==1 then return{"<",">="}end end
function b_Trigger_EntityHealth:CustomFunction(wS)
if self.BeSmalerThan then return GetHealth(self.ScriptName)<
self.Percentage else return GetHealth(self.ScriptName)>=
self.Percentage end end
function b_Trigger_EntityHealth:DEBUG(SxbR)if not IsExisting(self.ScriptName)then
dbg(
SxbR.Identifier.." "..self.Name..": Entity is dead! :(")return true end
if
self.Percentage<0 or self.Percentage>100 then
dbg(SxbR.Identifier.." "..self.Name..
": Percentage must be between 0 and 100!")return true end;return false end;Core:RegisterBehavior(b_Trigger_EntityHealth)
BundleEntityHelperFunctions={}API=API or{}QSB=QSB or{}
function API.GetEntitiesOfCategoriesInTerritories(G,ufs,rBbV5m)return
BundleEntityHelperFunctions.Shared:GetEntitiesOfCategoriesInTerritories(G,ufs,rBbV5m)end
GetEntitiesOfCategoriesInTerritories=API.GetEntitiesOfCategoriesInTerritories;EntitiesInCategories=API.GetEntitiesOfCategoriesInTerritories
function API.GetEntitiesByPrefix(v)return
BundleEntityHelperFunctions.Shared:GetEntitiesByPrefix(v)end;GetEntitiesNamedWith=API.GetEntitiesByPrefix
function API.SetResourceAmount(L_4ez,ILvdT1AO,X)
if GUI then
local iiB=(
type(L_4ez)~="string"and L_4ez)or"'"..L_4ez.."'"
API.Bridge("API.SetResourceAmount("..
iiB..", "..ILvdT1AO..", "..X..")")return end
if not IsExisting(L_4ez)then
local Ai9ugkhp=
(type(L_4ez)~="string"and L_4ez)or"'"..L_4ez.."'"
API.Fatal("API.SetResourceAmount: Entity "..Ai9ugkhp.." does not exist!")return end;return
BundleEntityHelperFunctions.Global:SetResourceAmount(L_4ez,ILvdT1AO,X)end;SetResourceAmount=API.SetResourceAmount
function API.GetRelativePosition(vx0,oTT0I_tH,d,HF)
if not
API.ValidatePosition(vx0)then if not IsExisting(vx0)then
API.Fatal("API.GetRelativePosition: Target is invalid!")return end end;return
BundleEntityHelperFunctions.Shared:GetRelativePos(vx0,oTT0I_tH,d,HF)end;GetRelativePos=API.GetRelativePosition
function API.EntityGetName(ORg_K6y)
if
not IsExisting(ORg_K6y)then local Y0=(type(ORg_K6y)~="string"and ORg_K6y)or"'"..
ORg_K6y.."'"
API.Warn(
"API.EntityGetName: Entity "..Y0 .." does not exist!")return nil end;return Logic.GetEntityName(GetID(ORg_K6y))end;GetEntityName=API.EntityGetName
function API.EntitySetName(gwII,ItMCtiyJ)if GUI then
API.Bridge("API.EntitySetName("..GetID(_EntityID)..
", '"..ItMCtiyJ.."')")return end;if IsExisting(ItMCtiyJ)then
API.Fatal(
"API.EntitySetName: Entity '"..ItMCtiyJ.."' already exists!")return end;return
Logic.SetEntityName(GetID(gwII),ItMCtiyJ)end;SetEntityName=API.EntitySetName
function API.EntitySetOrientation(iXtk,snG)if GUI then
API.Bridge("API.EntitySetOrientation("..
GetID(iXtk)..", "..snG..")")return end
if not IsExisting(iXtk)then
local V5j=(
type(iXtk)~="string"and iXtk)or"'"..iXtk.."'"
API.Fatal("API.EntitySetOrientation: Entity "..V5j.." does not exist!")return end;return Logic.SetOrientation(GetID(iXtk),snG)end;SetOrientation=API.EntitySetOrientation
function API.EntityGetOrientation(lItF)
if
not IsExisting(lItF)then
local xq1bs=(type(lItF)~="string"and lItF)or"'"..lItF.."'"
API.Warn("API.EntityGetOrientation: Entity "..xq1bs.." does not exist!")return 0 end;return Logic.GetEntityOrientation(GetID(lItF))end;GetOrientation=API.EntityGetOrientation
function API.GetKnightsNearby(F,Oro89)local O_dX={}
Logic.GetKnights(Oro89,O_dX)return API.GetEntitiesNearby(F,O_dX)end;GetClosestKnight=API.GetKnightsNearby
function API.GetEntitiesNearby(k3U,p8)if not IsExisting(k3U)then
return end;if#p8 ==0 then
API.Fatal("API.GetEntitiesNearby: The target list is empty!")return end
for BLvFfZ=1,#p8,1 do if
not IsExisting(p8[BLvFfZ])then
API.Fatal("API.GetEntitiesNearby: At least one target entity is dead!")return end end;return
BundleEntityHelperFunctions.Shared:GetNearestEntity(k3U,p8)end;GetClosestEntity=API.GetEntitiesNearby
BundleEntityHelperFunctions={Global={Data={RefillAmounts={}}},Shared={Data={}}}function BundleEntityHelperFunctions.Global:Install()
BundleEntityHelperFunctions.Global:OverwriteGeologistRefill()end
function BundleEntityHelperFunctions.Global:OverwriteGeologistRefill()
if
Framework.GetGameExtraNo()>=1 then
GameCallback_OnGeologistRefill_Orig_QSBPlusComforts1=GameCallback_OnGeologistRefill
GameCallback_OnGeologistRefill=function(_,dAcD,e)
GameCallback_OnGeologistRefill_Orig_QSBPlusComforts1(_,dAcD,e)
if
BundleEntityHelperFunctions.Global.Data.RefillAmounts[dAcD]then
local RG=BundleEntityHelperFunctions.Global.Data.RefillAmounts[dAcD]
local Y=RG+math.random(1,math.floor((RG*0.2)+0.5))Logic.SetResourceDoodadGoodAmount(dAcD,Y)end end end end
function BundleEntityHelperFunctions.Global:SetResourceAmount(htKd_R2,vr,ylrttgX)
assert(type(vr)=="number")assert(type(ylrttgX)=="number")
local L=GetID(htKd_R2)
if
not IsExisting(L)or Logic.GetResourceDoodadGoodType(L)==0 then
API.Fatal("SetResourceAmount: Resource entity is invalid!")return false end;if Logic.GetResourceDoodadGoodAmount(L)==0 then
L=ReplaceEntity(L,Logic.GetEntityType(L))end
Logic.SetResourceDoodadGoodAmount(L,vr)
if ylrttgX then self.Data.RefillAmounts[L]=ylrttgX end;return true end
function BundleEntityHelperFunctions.Shared:GetEntitiesOfCategoriesInTerritories(I,KYV,d)local sBB=(type(I)==
"table"and I)or{I}
local vvEDp5PM=(
type(KYV)=="table"and KYV)or{KYV}
local EBzZ=(type(d)=="table"and d)or{d}local JnR5AeB={}
for vfXvA0O=1,#sBB,1 do
for OZRh=1,#vvEDp5PM,1 do
for eNaZt=1,#EBzZ,1 do
local eE49cc=API.GetEntitiesOfCategoryInTerritory(sBB[vfXvA0O],vvEDp5PM[OZRh],EBzZ[eNaZt])JnR5AeB=Array_Append(JnR5AeB,eE49cc)end end end;return JnR5AeB end
function BundleEntityHelperFunctions.Shared:GetEntitiesByPrefix(n_Q69rHB)local h2_ty={}local zHG=1
local FYzFO1=true
while FYzFO1 do local gR48Oozb=GetID(n_Q69rHB..zHG)if gR48Oozb~=0 then
table.insert(h2_ty,gR48Oozb)else FYzFO1=false end;zHG=zHG+1 end;return h2_ty end
function BundleEntityHelperFunctions.Shared:GetRelativePos(bK0bhdq,nP,eN5tc,KehBOft6)if
not type(bK0bhdq)=="table"and not IsExisting(bK0bhdq)then
return end;if eN5tc==nil then eN5tc=0 end;local R
if
type(bK0bhdq)=="table"then local ao5=bK0bhdq;local oZy=0+eN5tc
R={X=ao5.X+nP*
math.cos(math.rad(oZy)),Y=ao5.Y+
nP*math.sin(math.rad(oZy))}else local oZ=GetID(bK0bhdq)local ndeNBp=GetPosition(oZ)local o76bqPp=
Logic.GetEntityOrientation(oZ)+eN5tc
if
Logic.IsBuilding(oZ)==1 and not KehBOft6 then
x,y=Logic.GetBuildingApproachPosition(oZ)ndeNBp={X=x,Y=y}o76bqPp=o76bqPp-90 end
R={X=ndeNBp.X+nP*math.cos(math.rad(o76bqPp)),Y=
ndeNBp.Y+nP*math.sin(math.rad(o76bqPp))}end;return R end
function BundleEntityHelperFunctions.Shared:GetNearestEntity(idRDAlB,tXR1E510)
local ZawK6=Logic.WorldGetSize()local bK=nil
for OJGVLn=1,#tXR1E510 do
local UzgoE5O=Logic.GetDistanceBetweenEntities(tXR1E510[OJGVLn],idRDAlB)if UzgoE5O<ZawK6 and tXR1E510[OJGVLn]~=idRDAlB then
ZawK6=UzgoE5O;bK=tXR1E510[OJGVLn]end end;return bK end
Core:RegisterBundle("BundleEntityHelperFunctions")BundleKnightTitleRequirements={}API=API or{}QSB=QSB or{}
QSB.RequirementTooltipTypes={}QSB.ConsumedGoodsCounter={}
BundleKnightTitleRequirements={Global={},Local={Data={}}}function BundleKnightTitleRequirements.Global:Install()
self:OverwriteConsumedGoods()end
function BundleKnightTitleRequirements.Global:RegisterConsumedGoods(RvHs,u)QSB.ConsumedGoodsCounter[RvHs]=
QSB.ConsumedGoodsCounter[RvHs]or{}QSB.ConsumedGoodsCounter[RvHs][u]=
QSB.ConsumedGoodsCounter[RvHs][u]or 0;QSB.ConsumedGoodsCounter[RvHs][u]=
QSB.ConsumedGoodsCounter[RvHs][u]+1 end
function BundleKnightTitleRequirements.Global:OverwriteConsumedGoods()
GameCallback_ConsumeGood_Orig_QSB_Requirements=GameCallback_ConsumeGood
GameCallback_ConsumeGood=function(Anrb,C9lJAfo,NeSAkW)
GameCallback_ConsumeGood_Orig_QSB_Requirements(Anrb,C9lJAfo,NeSAkW)local Ccoa=Logic.EntityGetPlayer(Anrb)
BundleKnightTitleRequirements.Global:RegisterConsumedGoods(Ccoa,C9lJAfo)
Logic.ExecuteInLuaLocalState([[
            BundleKnightTitleRequirements.Local:RegisterConsumedGoods(
                ]]..Ccoa..[[, ]]..C9lJAfo..
[[
            );
        ]])end end
function BundleKnightTitleRequirements.Local:Install()
self:OverwriteTooltips()self:InitTexturePositions()
self:OverwriteUpdateRequirements()self:OverwritePromotionCelebration()end
function BundleKnightTitleRequirements.Local:RegisterConsumedGoods(Y,zljPh)QSB.ConsumedGoodsCounter[Y]=
QSB.ConsumedGoodsCounter[Y]or{}QSB.ConsumedGoodsCounter[Y][zljPh]=
QSB.ConsumedGoodsCounter[Y][zljPh]or 0;QSB.ConsumedGoodsCounter[Y][zljPh]=
QSB.ConsumedGoodsCounter[Y][zljPh]+1 end
function BundleKnightTitleRequirements.Local:InitTexturePositions()
g_TexturePositions.EntityCategories[EntityCategories.GC_Food_Supplier]={1,1}
g_TexturePositions.EntityCategories[EntityCategories.GC_Clothes_Supplier]={1,2}
g_TexturePositions.EntityCategories[EntityCategories.GC_Hygiene_Supplier]={16,1}
g_TexturePositions.EntityCategories[EntityCategories.GC_Entertainment_Supplier]={1,4}
g_TexturePositions.EntityCategories[EntityCategories.GC_Luxury_Supplier]={16,3}
g_TexturePositions.EntityCategories[EntityCategories.GC_Weapon_Supplier]={1,7}
g_TexturePositions.EntityCategories[EntityCategories.GC_Medicine_Supplier]={2,10}
g_TexturePositions.EntityCategories[EntityCategories.Outpost]={12,3}
g_TexturePositions.EntityCategories[EntityCategories.Spouse]={5,15}
g_TexturePositions.EntityCategories[EntityCategories.CattlePasture]={3,16}
g_TexturePositions.EntityCategories[EntityCategories.SheepPasture]={4,1}
g_TexturePositions.EntityCategories[EntityCategories.Soldier]={7,12}
g_TexturePositions.EntityCategories[EntityCategories.GrainField]={14,2}
g_TexturePositions.EntityCategories[EntityCategories.OuterRimBuilding]={3,4}
g_TexturePositions.EntityCategories[EntityCategories.CityBuilding]={8,1}
g_TexturePositions.EntityCategories[EntityCategories.Leader]={7,11}
g_TexturePositions.EntityCategories[EntityCategories.Range]={9,8}
g_TexturePositions.EntityCategories[EntityCategories.Melee]={9,7}
g_TexturePositions.EntityCategories[EntityCategories.SiegeEngine]={2,15}
g_TexturePositions.Entities[Entities.B_Outpost]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_AS]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_ME]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_NA]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_NE]={12,3}
g_TexturePositions.Entities[Entities.B_Outpost_SE]={12,3}
g_TexturePositions.Entities[Entities.B_Cathedral_Big]={3,12}
g_TexturePositions.Entities[Entities.U_MilitaryBallista]={10,5}
g_TexturePositions.Entities[Entities.U_Trebuchet]={9,1}
g_TexturePositions.Entities[Entities.U_SiegeEngineCart]={9,4}
g_TexturePositions.Needs[Needs.Medicine]={2,10}
g_TexturePositions.Technologies[Technologies.R_Castle_Upgrade_1]={4,7}
g_TexturePositions.Technologies[Technologies.R_Castle_Upgrade_2]={4,7}
g_TexturePositions.Technologies[Technologies.R_Castle_Upgrade_3]={4,7}
g_TexturePositions.Technologies[Technologies.R_Cathedral_Upgrade_1]={4,5}
g_TexturePositions.Technologies[Technologies.R_Cathedral_Upgrade_2]={4,5}
g_TexturePositions.Technologies[Technologies.R_Cathedral_Upgrade_3]={4,5}
g_TexturePositions.Technologies[Technologies.R_Storehouse_Upgrade_1]={4,6}
g_TexturePositions.Technologies[Technologies.R_Storehouse_Upgrade_2]={4,6}
g_TexturePositions.Technologies[Technologies.R_Storehouse_Upgrade_3]={4,6}
g_TexturePositions.Buffs=g_TexturePositions.Buffs or{}
g_TexturePositions.Buffs[Buffs.Buff_ClothesDiversity]={1,2}
g_TexturePositions.Buffs[Buffs.Buff_EntertainmentDiversity]={1,4}
g_TexturePositions.Buffs[Buffs.Buff_FoodDiversity]={1,1}
g_TexturePositions.Buffs[Buffs.Buff_HygieneDiversity]={1,3}
g_TexturePositions.Buffs[Buffs.Buff_Colour]={5,11}
g_TexturePositions.Buffs[Buffs.Buff_Entertainers]={5,12}
g_TexturePositions.Buffs[Buffs.Buff_ExtraPayment]={1,8}
g_TexturePositions.Buffs[Buffs.Buff_Sermon]={4,14}
g_TexturePositions.Buffs[Buffs.Buff_Spice]={5,10}
g_TexturePositions.Buffs[Buffs.Buff_NoTaxes]={1,6}
if Framework.GetGameExtraNo()~=0 then
g_TexturePositions.Buffs[Buffs.Buff_Gems]={1,1,1}
g_TexturePositions.Buffs[Buffs.Buff_MusicalInstrument]={1,3,1}
g_TexturePositions.Buffs[Buffs.Buff_Olibanum]={1,2,1}end
g_TexturePositions.GoodCategories=g_TexturePositions.GoodCategories or{}
g_TexturePositions.GoodCategories[GoodCategories.GC_Ammunition]={10,6}
g_TexturePositions.GoodCategories[GoodCategories.GC_Animal]={4,16}
g_TexturePositions.GoodCategories[GoodCategories.GC_Clothes]={1,2}
g_TexturePositions.GoodCategories[GoodCategories.GC_Document]={5,6}
g_TexturePositions.GoodCategories[GoodCategories.GC_Entertainment]={1,4}
g_TexturePositions.GoodCategories[GoodCategories.GC_Food]={1,1}
g_TexturePositions.GoodCategories[GoodCategories.GC_Gold]={1,8}
g_TexturePositions.GoodCategories[GoodCategories.GC_Hygiene]={16,1}
g_TexturePositions.GoodCategories[GoodCategories.GC_Luxury]={16,3}
g_TexturePositions.GoodCategories[GoodCategories.GC_Medicine]={2,10}
g_TexturePositions.GoodCategories[GoodCategories.GC_None]={15,16}
g_TexturePositions.GoodCategories[GoodCategories.GC_RawFood]={3,4}
g_TexturePositions.GoodCategories[GoodCategories.GC_RawMedicine]={2,2}
g_TexturePositions.GoodCategories[GoodCategories.GC_Research]={5,6}
g_TexturePositions.GoodCategories[GoodCategories.GC_Resource]={3,4}
g_TexturePositions.GoodCategories[GoodCategories.GC_Tools]={4,12}
g_TexturePositions.GoodCategories[GoodCategories.GC_Water]={1,16}
g_TexturePositions.GoodCategories[GoodCategories.GC_Weapon]={8,5}end
function BundleKnightTitleRequirements.Local:OverwriteUpdateRequirements()
GUI_Knight.UpdateRequirements=function()
local C7mQfN=BundleKnightTitleRequirements.Local.Data.RequirementWidgets;local hIkuxuG=1;local wSnPWSA8=GUI.GetPlayerID()
local Ktu1=Logic.GetKnightTitle(wSnPWSA8)local g=Ktu1+1;local R=Logic.GetKnightID(wSnPWSA8)
local WiBcS8j=Logic.GetEntityType(R)
XGUIEng.SetText("/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/NextKnightTitle","{center}"..
GUI_Knight.GetTitleNameByTitleID(WiBcS8j,g))
XGUIEng.SetText("/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/NextKnightTitleWhite","{center}"..
GUI_Knight.GetTitleNameByTitleID(WiBcS8j,g))
if KnightTitleRequirements[g].Settlers~=nil then SetIcon(
C7mQfN[hIkuxuG].."/Icon",{5,16})
local t,jYRxYT,kd=DoesNeededNumberOfSettlersForKnightTitleExist(wSnPWSA8,g)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..jYRxYT.."/"..kd)if t then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)QSB.RequirementTooltipTypes[hIkuxuG]="Settlers"
hIkuxuG=hIkuxuG+1 end
if KnightTitleRequirements[g].RichBuildings~=nil then SetIcon(
C7mQfN[hIkuxuG].."/Icon",{8,4})
local kalNjedc,b2Pn,trdghrt=DoNeededNumberOfRichBuildingsForKnightTitleExist(wSnPWSA8,g)if trdghrt==-1 then
trdghrt=Logic.GetNumberOfPlayerEntitiesInCategory(wSnPWSA8,EntityCategories.CityBuilding)end
XGUIEng.SetText(
C7mQfN[hIkuxuG].."/Amount","{center}"..b2Pn.."/"..trdghrt)if kalNjedc then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)QSB.RequirementTooltipTypes[hIkuxuG]="RichBuildings"hIkuxuG=
hIkuxuG+1 end
if KnightTitleRequirements[g].Headquarters~=nil then SetIcon(
C7mQfN[hIkuxuG].."/Icon",{4,7})
local J,y1gHSu,lF3FR=DoNeededSpecialBuildingUpgradeForKnightTitleExist(wSnPWSA8,g,EntityCategories.Headquarters)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..
y1gHSu+1 .."/"..lF3FR+1)if J then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)QSB.RequirementTooltipTypes[hIkuxuG]="Headquarters"hIkuxuG=
hIkuxuG+1 end
if KnightTitleRequirements[g].Storehouse~=nil then SetIcon(
C7mQfN[hIkuxuG].."/Icon",{4,6})
local _HG,W,rEJdQN=DoNeededSpecialBuildingUpgradeForKnightTitleExist(wSnPWSA8,g,EntityCategories.Storehouse)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..W+1 .."/"..rEJdQN+1)if _HG then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)QSB.RequirementTooltipTypes[hIkuxuG]="Storehouse"
hIkuxuG=hIkuxuG+1 end
if KnightTitleRequirements[g].Cathedrals~=nil then SetIcon(
C7mQfN[hIkuxuG].."/Icon",{4,5})
local HF6Ag,Y,TEM=DoNeededSpecialBuildingUpgradeForKnightTitleExist(wSnPWSA8,g,EntityCategories.Cathedrals)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..Y+1 .."/"..TEM+1)if HF6Ag then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)QSB.RequirementTooltipTypes[hIkuxuG]="Cathedrals"
hIkuxuG=hIkuxuG+1 end
if
KnightTitleRequirements[g].FullDecoratedBuildings~=nil then
local jWvh,Y,O_aE9lks=DoNeededNumberOfFullDecoratedBuildingsForKnightTitleExist(wSnPWSA8,g)
local wuF=KnightTitleRequirements[g].FullDecoratedBuildings
SetIcon(C7mQfN[hIkuxuG].."/Icon",g_TexturePositions.Needs[Needs.Wealth])
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..Y.."/"..O_aE9lks)if jWvh then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)
QSB.RequirementTooltipTypes[hIkuxuG]="FullDecoratedBuildings"hIkuxuG=hIkuxuG+1 end
if KnightTitleRequirements[g].Reputation~=nil then SetIcon(
C7mQfN[hIkuxuG].."/Icon",{5,14})
local ipXc,EgbUS,XJ=DoesNeededCityReputationForKnightTitleExist(wSnPWSA8,g)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..EgbUS.."/"..XJ)if ipXc then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)QSB.RequirementTooltipTypes[hIkuxuG]="Reputation"
hIkuxuG=hIkuxuG+1 end
if KnightTitleRequirements[g].Goods~=nil then
for RDsGq=1,#
KnightTitleRequirements[g].Goods do
local wg6c1w=KnightTitleRequirements[g].Goods[RDsGq][1]
SetIcon(C7mQfN[hIkuxuG].."/Icon",g_TexturePositions.Goods[wg6c1w])
local iPEJyOaN,D0,a223=DoesNeededNumberOfGoodTypesForKnightTitleExist(wSnPWSA8,g,RDsGq)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..D0 .."/"..a223)if iPEJyOaN then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)QSB.RequirementTooltipTypes[hIkuxuG]="Goods"..RDsGq;hIkuxuG=
hIkuxuG+1 end end
if KnightTitleRequirements[g].Category~=nil then
for px4R7I=1,#
KnightTitleRequirements[g].Category do
local a=KnightTitleRequirements[g].Category[px4R7I][1]
SetIcon(C7mQfN[hIkuxuG].."/Icon",g_TexturePositions.EntityCategories[a])
local I29,aqji75cGk,BRk_bg=DoesNeededNumberOfEntitiesInCategoryForKnightTitleExist(wSnPWSA8,g,px4R7I)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..aqji75cGk.."/"..BRk_bg)if I29 then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)
local B97ZvZrX={Logic.GetEntityTypesInCategory(a)}
if
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.GC_Weapon_Supplier)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"Weapons"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.SiegeEngine)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"HeavyWeapons"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.Spouse)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"Spouse"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.Worker)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"Worker"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.Soldier)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"Soldiers"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.Leader)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"Leader"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.Outpost)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"Outposts"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.CattlePasture)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"Cattle"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.SheepPasture)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"Sheep"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.CityBuilding)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"CityBuilding"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.OuterRimBuilding)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"OuterRimBuilding"..px4R7I elseif
Logic.IsEntityTypeInCategory(B97ZvZrX[1],EntityCategories.AttackableBuilding)==1 then QSB.RequirementTooltipTypes[hIkuxuG]=
"Buildings"..px4R7I else QSB.RequirementTooltipTypes[hIkuxuG]=
"EntityCategoryDefault"..px4R7I end;hIkuxuG=hIkuxuG+1 end end
if KnightTitleRequirements[g].Entities~=nil then
for DINB=1,#
KnightTitleRequirements[g].Entities do
local rvLAm9=KnightTitleRequirements[g].Entities[DINB][1]
SetIcon(C7mQfN[hIkuxuG].."/Icon",g_TexturePositions.Entities[rvLAm9])
local E,Im,yWsj=DoesNeededNumberOfEntitiesOfTypeForKnightTitleExist(wSnPWSA8,g,DINB)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..Im.."/"..yWsj)if E then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)
QSB.RequirementTooltipTypes[hIkuxuG]="Entities"..DINB;hIkuxuG=hIkuxuG+1 end end
if KnightTitleRequirements[g].Consume~=nil then
for MFbe=1,#
KnightTitleRequirements[g].Consume do
local i=KnightTitleRequirements[g].Consume[MFbe][1]
SetIcon(C7mQfN[hIkuxuG].."/Icon",g_TexturePositions.Goods[i])
local ayLU,T2y,QgLdZF=DoNeededNumberOfConsumedGoodsForKnightTitleExist(wSnPWSA8,g,MFbe)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..T2y.."/"..QgLdZF)if ayLU then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)
QSB.RequirementTooltipTypes[hIkuxuG]="Consume"..MFbe;hIkuxuG=hIkuxuG+1 end end
if KnightTitleRequirements[g].Products~=nil then
for XGyz6oE=1,#
KnightTitleRequirements[g].Products do
local i3NlQ94=KnightTitleRequirements[g].Products[XGyz6oE][1]
SetIcon(C7mQfN[hIkuxuG].."/Icon",g_TexturePositions.GoodCategories[i3NlQ94])
local RnFNLp,wOOFocF,cUoJ=DoNumberOfProductsInCategoryExist(wSnPWSA8,g,XGyz6oE)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..wOOFocF.."/"..cUoJ)if RnFNLp then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)
QSB.RequirementTooltipTypes[hIkuxuG]="Products"..XGyz6oE;hIkuxuG=hIkuxuG+1 end end
if KnightTitleRequirements[g].Buff~=nil then
for m3QdLvW=1,#
KnightTitleRequirements[g].Buff do
local xv=KnightTitleRequirements[g].Buff[m3QdLvW]
SetIcon(C7mQfN[hIkuxuG].."/Icon",g_TexturePositions.Buffs[xv])
local H=DoNeededDiversityBuffForKnightTitleExist(wSnPWSA8,g,m3QdLvW)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","")if H then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)
QSB.RequirementTooltipTypes[hIkuxuG]="Buff"..m3QdLvW;hIkuxuG=hIkuxuG+1 end end
if KnightTitleRequirements[g].Custom~=nil then
for Gjvc=1,#
KnightTitleRequirements[g].Custom do
local u3iW5=KnightTitleRequirements[g].Custom[Gjvc][2]
BundleKnightTitleRequirements.Local:RequirementIcon(C7mQfN[hIkuxuG].."/Icon",u3iW5)
local MGaxDz,ezQ,c=DoCustomFunctionForKnightTitleSucceed(wSnPWSA8,g,Gjvc)if ezQ and c then
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..ezQ.."/"..c)else
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","")end
if MGaxDz then XGUIEng.ShowWidget(
C7mQfN[hIkuxuG].."/Done",1)else XGUIEng.ShowWidget(
C7mQfN[hIkuxuG].."/Done",0)end;XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)QSB.RequirementTooltipTypes[hIkuxuG]=
"Custom"..Gjvc;hIkuxuG=hIkuxuG+1 end end
if KnightTitleRequirements[g].DecoratedBuildings~=nil then
for FVJlfw=1,#
KnightTitleRequirements[g].DecoratedBuildings do
local MwzzZ=KnightTitleRequirements[g].DecoratedBuildings[FVJlfw][1]
SetIcon(C7mQfN[hIkuxuG].."/Icon",g_TexturePositions.Goods[MwzzZ])
local EQI,zdm,OQaP=DoNeededNumberOfDecoratedBuildingsForKnightTitleExist(wSnPWSA8,g,FVJlfw)
XGUIEng.SetText(C7mQfN[hIkuxuG].."/Amount","{center}"..zdm.."/"..OQaP)if EQI then
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",1)else
XGUIEng.ShowWidget(C7mQfN[hIkuxuG].."/Done",0)end
XGUIEng.ShowWidget(C7mQfN[hIkuxuG],1)
QSB.RequirementTooltipTypes[hIkuxuG]="DecoratedBuildings"..FVJlfw;hIkuxuG=hIkuxuG+1 end end
for V1AAbF=hIkuxuG,6 do XGUIEng.ShowWidget(C7mQfN[V1AAbF],0)end end end
function BundleKnightTitleRequirements.Local:OverwritePromotionCelebration()
StartKnightsPromotionCelebration=function(DVp,uMHoys,hebAWpv)if

DVp~=GUI.GetPlayerID()or Logic.GetTime()<5 then return end
local iO=Logic.GetMarketplace(DVp)
if hebAWpv==1 then local VF=Logic.GetKnightID(DVp)local qby
repeat qby=1+
XGUIEng.GetRandom(3)until qby~=g_LastGotPromotionMessageRandom;g_LastGotPromotionMessageRandom=qby
local xocXyH="Title_GotPromotion"..qby
LocalScriptCallback_QueueVoiceMessage(DVp,xocXyH,false,DVp)GUI.StartFestival(DVp,1)end;local kQfTr6=QSB.ConsumedGoodsCounter[DVp]QSB.ConsumedGoodsCounter[DVp]=
kQfTr6 or{}
for guNNjlMM,wvoHfla in
pairs(QSB.ConsumedGoodsCounter[DVp])do QSB.ConsumedGoodsCounter[DVp][guNNjlMM]=0 end
GUI.SendScriptCommand([[
            local Consume = QSB.ConsumedGoodsCounter[]]..
DVp..
[[];
            QSB.ConsumedGoodsCounter[]]..
DVp..

[[] = Consume or {};
            for k,v in pairs(QSB.ConsumedGoodsCounter[]]..DVp..
[[]) do
                QSB.ConsumedGoodsCounter[]]..DVp..[[][k] = 0;
            end
        ]])
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopCenter/KnightTitleMenuBig",0)g_WantsPromotionMessageInterval=30;g_TimeOfPromotionPossible=nil end end
function BundleKnightTitleRequirements.Local:OverwriteTooltips()
GUI_Tooltip.SetNameAndDescription_Orig_QSB_Requirements=GUI_Tooltip.SetNameAndDescription
GUI_Tooltip.SetNameAndDescription=function(UIgl,ij,m,TO857,Uo5o)local xX9=XGUIEng.GetCurrentWidgetID()
local pOltGg=GUI.GetSelectedEntity()local aD=GUI.GetPlayerID()
for KO,Z in
pairs(BundleKnightTitleRequirements.Local.Data.RequirementWidgets)do
if Z.."/Icon"==XGUIEng.GetWidgetPathByID(xX9)then
local kv6Rc=QSB.RequirementTooltipTypes[KO]
local G8PtJug=tonumber(string.sub(kv6Rc,string.len(kv6Rc)))if G8PtJug~=nil then
kv6Rc=string.sub(kv6Rc,1,string.len(kv6Rc)-1)end
BundleKnightTitleRequirements.Local:RequirementTooltipWrapped(kv6Rc,G8PtJug)return end end
GUI_Tooltip.SetNameAndDescription_Orig_QSB_Requirements(UIgl,ij,m,TO857,Uo5o)end
GUI_Knight.RequiredGoodTooltip=function()local RwGMa=QSB.RequirementTooltipTypes[2]
local wODtgBt=tonumber(string.sub(RwGMa,string.len(RwGMa)))if wODtgBt~=nil then
RwGMa=string.sub(RwGMa,1,string.len(RwGMa)-1)end
BundleKnightTitleRequirements.Local:RequirementTooltipWrapped(RwGMa,wODtgBt)end
if Framework.GetGameExtraNo()~=0 then
BundleKnightTitleRequirements.Local.Data.BuffTypeNames[Buffs.Buff_Gems]={de="Edelsteine beschaffen",en="Obtain gems"}
BundleKnightTitleRequirements.Local.Data.BuffTypeNames[Buffs.Buff_Olibanum]={de="Weihrauch beschaffen",en="Obtain olibanum"}
BundleKnightTitleRequirements.Local.Data.BuffTypeNames[Buffs.Buff_MusicalInstrument]={de="Muskinstrumente beschaffen",en="Obtain instruments"}end end
function BundleKnightTitleRequirements.Local:RequirementIcon(R83,O3)
if
type(O3)=="table"then
if type(O3[3])=="string"then local Y=1
if XGUIEng.IsButton(R83)==1 then Y=7 end;local Nau29CQd,rPWy4BIw,FIDceK,h;Nau29CQd=(O3[1]-1)*64
FIDceK=(O3[2]-1)*64;rPWy4BIw=(O3[1])*64;h=(O3[2])*64
XGUIEng.SetMaterialAlpha(R83,Y,255)
XGUIEng.SetMaterialTexture(R83,Y,O3[3].."big.png")
XGUIEng.SetMaterialUV(R83,Y,Nau29CQd,FIDceK,rPWy4BIw,h)else SetIcon(R83,O3)end else local lSW={GUI.GetScreenSize()}local kl=330
if lSW[2]>=800 then kl=260 end;if lSW[2]>=1000 then kl=210 end
XGUIEng.SetMaterialAlpha(R83,1,255)XGUIEng.SetMaterialTexture(R83,1,_file)
XGUIEng.SetMaterialUV(R83,1,0,0,kl,kl)end end
function BundleKnightTitleRequirements.Local:RequirementTooltip(W,xtH)
local qujnE="/InGame/Root/Normal/TooltipNormal"local fX=XGUIEng.GetWidgetID(qujnE)
local Gu9cA=XGUIEng.GetWidgetID(qujnE.."/FadeIn/Name")
local qie86E6k=XGUIEng.GetWidgetID(qujnE.."/FadeIn/Text")
local _7XdqeK=XGUIEng.GetWidgetID(qujnE.."/FadeIn/BG")local FUhqkm2=XGUIEng.GetWidgetID(qujnE.."/FadeIn")
local OmYbhPA=XGUIEng.GetCurrentWidgetID()GUI_Tooltip.ResizeBG(_7XdqeK,qie86E6k)
local o1={_7XdqeK}GUI_Tooltip.SetPosition(fX,o1,OmYbhPA)
GUI_Tooltip.FadeInTooltip(FUhqkm2)XGUIEng.SetText(Gu9cA,"{center}"..W)
XGUIEng.SetText(qie86E6k,xtH)local cKy3Dt=XGUIEng.GetTextHeight(qie86E6k,true)
local y,zB6zO=XGUIEng.GetWidgetSize(qie86E6k)XGUIEng.SetWidgetSize(qie86E6k,y,cKy3Dt)end
function BundleKnightTitleRequirements.Local:RequirementTooltipWrapped(C6,J09Np7H8)
local tf=(
Network.GetDesiredLanguage()=="de"and"de")or"en"local VzDXmgRS=GUI.GetPlayerID()
local QHdb=Logic.GetKnightTitle(VzDXmgRS)local dtRn=""local eHQcOZ4=""
if C6 =="Consume"or C6 =="Goods"or
C6 =="DecoratedBuildings"then
local Sd6s=KnightTitleRequirements[QHdb+1][C6][J09Np7H8][1]local G4=Logic.GetGoodTypeName(Sd6s)
local A=XGUIEng.GetStringTableText("UI_ObjectNames/"..G4)if A==nil then A="Goods."..G4 end;dtRn=A
eHQcOZ4=BundleKnightTitleRequirements.Local.Data.Description[C6].Text elseif C6 =="Products"then
local KVcI5x=BundleKnightTitleRequirements.Local.Data.GoodCategoryNames
local AHVxk8=KnightTitleRequirements[QHdb+1][C6][J09Np7H8][1]local ykIP=KVcI5x[AHVxk8][tf]
if ykIP==nil then ykIP="ERROR: Name missng!"end;dtRn=ykIP
eHQcOZ4=BundleKnightTitleRequirements.Local.Data.Description[C6].Text elseif C6 =="Entities"then
local XQaA=KnightTitleRequirements[QHdb+1][C6][J09Np7H8][1]local UFkKFj0=Logic.GetEntityTypeName(XQaA)local mj8vF=XGUIEng.GetStringTableText("Names/"..
UFkKFj0)if mj8vF==nil then mj8vF=
"Entities."..UFkKFj0 end;dtRn=mj8vF
eHQcOZ4=BundleKnightTitleRequirements.Local.Data.Description[C6].Text elseif C6 =="Custom"then
local N=KnightTitleRequirements[QHdb+1].Custom[J09Np7H8]dtRn=N[3]eHQcOZ4=N[4]elseif C6 =="Buff"then
local XN_r=BundleKnightTitleRequirements.Local.Data.BuffTypeNames
local ihQKt=KnightTitleRequirements[QHdb+1][C6][J09Np7H8]local Nf=XN_r[ihQKt][tf]
if Nf==nil then Nf="ERROR: Name missng!"end;dtRn=Nf
eHQcOZ4=BundleKnightTitleRequirements.Local.Data.Description[C6].Text else
dtRn=BundleKnightTitleRequirements.Local.Data.Description[C6].Title
eHQcOZ4=BundleKnightTitleRequirements.Local.Data.Description[C6].Text end
dtRn=(type(dtRn)=="table"and dtRn[tf])or dtRn;eHQcOZ4=
(type(eHQcOZ4)=="table"and eHQcOZ4[tf])or eHQcOZ4
self:RequirementTooltip(dtRn,eHQcOZ4)end
BundleKnightTitleRequirements.Local.Data.RequirementWidgets={[1]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Settlers",[2]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Goods",[3]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/RichBuildings",[4]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Castle",[5]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Storehouse",[6]="/InGame/Root/Normal/AlignBottomRight/KnightTitleMenu/Requirements/Cathedral"}
BundleKnightTitleRequirements.Local.Data.GoodCategoryNames={[GoodCategories.GC_Ammunition]={de="Munition",en="Ammunition"},[GoodCategories.GC_Animal]={de="Nutztiere",en="Livestock"},[GoodCategories.GC_Clothes]={de="Kleidung",en="Clothes"},[GoodCategories.GC_Document]={de="Dokumente",en="Documents"},[GoodCategories.GC_Entertainment]={de="Unterhaltung",en="Entertainment"},[GoodCategories.GC_Food]={de="Nahrungsmittel",en="Food"},[GoodCategories.GC_Gold]={de="Gold",en="Gold"},[GoodCategories.GC_Hygiene]={de="Hygieneartikel",en="Hygiene"},[GoodCategories.GC_Luxury]={de="Dekoration",en="Decoration"},[GoodCategories.GC_Medicine]={de="Medizin",en="Medicine"},[GoodCategories.GC_None]={de="Nichts",en="None"},[GoodCategories.GC_RawFood]={de="Nahrungsmittel",en="Food"},[GoodCategories.GC_RawMedicine]={de="Medizin",en="Medicine"},[GoodCategories.GC_Research]={de="Forschung",en="Research"},[GoodCategories.GC_Resource]={de="Rohstoffe",en="Resource"},[GoodCategories.GC_Tools]={de="Werkzeug",en="Tools"},[GoodCategories.GC_Water]={de="Wasser",en="Water"},[GoodCategories.GC_Weapon]={de="Waffen",en="Weapon"}}
BundleKnightTitleRequirements.Local.Data.BuffTypeNames={[Buffs.Buff_ClothesDiversity]={de="Abwechslungsreiche Kleidung",en="Clothes diversity"},[Buffs.Buff_Colour]={de="Farben beschaffen",en="Obtain color"},[Buffs.Buff_Entertainers]={de="Gaukler anheuern",en="Hire entertainer"},[Buffs.Buff_EntertainmentDiversity]={de="Abwechslungsreiche Unterhaltung",en="Entertainment diversity"},[Buffs.Buff_ExtraPayment]={de="Sonderzahlung",en="Extra payment"},[Buffs.Buff_Festival]={de="Fest veranstalten",en="Hold Festival"},[Buffs.Buff_FoodDiversity]={de="Abwechslungsreiche Nahrung",en="Food diversity"},[Buffs.Buff_HygieneDiversity]={de="Abwechslungsreiche Hygiene",en="Hygiene diversity"},[Buffs.Buff_NoTaxes]={de="Steuerbefreiung",en="No taxes"},[Buffs.Buff_Sermon]={de="Pregigt abhalten",en="Hold sermon"},[Buffs.Buff_Spice]={de="Salz beschaffen",en="Obtain salt"}}
BundleKnightTitleRequirements.Local.Data.Description={Settlers={Title={de="Benötigte Siedler",en="Needed settlers"},Text={de="- Benötigte Menge an Siedlern",en="- Needed number of settlers"}},RichBuildings={Title={de="Reiche Stadtgebäude",en="Rich city buildings"},Text={de="- Menge an reichen Stadtgebäuden",en="- Needed amount of rich city buildings"}},Goods={Title={de="Waren lagern",en="Store Goods"},Text={de="- Benötigte Menge",en="- Needed amount"}},FullDecoratedBuildings={Title={de="Dekorierte Stadtgebäude",en="Decorated City buildings"},Text={de="- Menge an voll dekorierten Gebäuden",en="- Amount of full decoraded city buildings"}},DecoratedBuildings={Title={de="Dekoration",en="Decoration"},Text={de="- Menge an Dekorationsgütern in der Siedlung",en="- Amount of decoration goods in settlement"}},Headquarters={Title={de="Burgstufe",en="Castle level"},Text={de="- Benötigte Ausbauten der Burg",en="- Needed castle upgrades"}},Storehouse={Title={de="Lagerhausstufe",en="Storehouse level"},Text={de="- Benötigte Ausbauten des Lagerhauses",en="- Needed storehouse upgrades"}},Cathedrals={Title={de="Kirchenstufe",en="Cathedral level"},Text={de="- Benötigte Ausbauten der Kirche",en="- Needed cathedral upgrades"}},Reputation={Title={de="Ruf der Stadt",en="City reputation"},Text={de="- Benötigter Ruf der Stadt",en="- Needed city reputation"}},EntityCategoryDefault={Title={de="",en=""},Text={de="- Benötigte Anzahl",en="- Needed amount"}},Cattle={Title={de="Kühe",en="Cattle"},Text={de="- Benötigte Menge an Kühen",en="- Needed amount of cattle"}},Sheep={Title={de="Schafe",en="Sheeps"},Text={de="- Benötigte Menge an Schafen",en="- Needed amount of sheeps"}},Outposts={Title={de="Territorien",en="Territories"},Text={de="- Zu erobernde Territorien",en="- Territories to claim"}},CityBuilding={Title={de="Stadtgebäude",en="City buildings"},Text={de="- Menge benötigter Stadtgebäude",en="- Needed amount of city buildings"}},OuterRimBuilding={Title={de="Rohstoffgebäude",en="Gatherer"},Text={de="- Menge benötigter Rohstoffgebäude",en="- Needed amount of gatherer"}},Consume={Title={de="",en=""},Text={de="- Durch Siedler zu konsumierende Menge",en="- Amount to be consumed by the settlers"}},Products={Title={de="",en=""},Text={de="- Benötigte Menge",en="- Needed amount"}},Buff={Title={de="Bonus aktivieren",en="Activate Buff"},Text={de="- Aktiviere diesen Bonus auf den Ruf der Stadt",en="- Raise the city reputatition with this buff"}},Leader={Title={de="Batalione",en="Battalions"},Text={de="- Menge an Batalionen unterhalten",en="- Battalions you need under your command"}},Soldiers={Title={de="Soldaten",en="Soldiers"},Text={de="- Menge an Streitkräften unterhalten",en="- Soldiers you need under your command"}},Worker={Title={de="Arbeiter",en="Workers"},Text={de="- Menge an arbeitender Bevölkerung",en="- Workers you need under your reign"}},Entities={Title={de="",en=""},Text={de="- Benötigte Menge",en="- Needed Amount"}},Buildings={Title={de="Gebäude",en="Buildings"},Text={de="- Gesamtmenge an Gebäuden",en="- Amount of buildings"}},Weapons={Title={de="Waffen",en="Weapons"},Text={de="- Benötigte Menge an Waffen",en="- Needed amount of weapons"}},HeavyWeapons={Title={de="Belagerungsgeräte",en="Siege Engines"},Text={de="- Benötigte Menge an Belagerungsgeräten",en="- Needed amount of siege engine"}},Spouse={Title={de="Ehefrauen",en="Spouses"},Text={de="- Benötigte Anzahl Ehefrauen in der Stadt",en="- Needed amount of spouses in your city"}}}
Core:RegisterBundle("BundleKnightTitleRequirements")
DoesNeededNumberOfEntitiesInCategoryForKnightTitleExist=function(v0xXBtzp,Rh8dzZf_,k6z)if
KnightTitleRequirements[Rh8dzZf_].Category==nil then return end
if k6z then
local W=KnightTitleRequirements[Rh8dzZf_].Category[k6z][1]
local DQKzz7t=KnightTitleRequirements[Rh8dzZf_].Category[k6z][2]local I=0
if W==EntityCategories.Spouse then
I=Logic.GetNumberOfSpouses(v0xXBtzp)else
local jvpPcK={Logic.GetPlayerEntitiesInCategory(v0xXBtzp,W)}for s=1,#jvpPcK do
if Logic.IsBuilding(jvpPcK[s])==1 then if
Logic.IsConstructionComplete(jvpPcK[s])==1 then I=I+1 end else I=I+1 end end end;if I>=DQKzz7t then return true,I,DQKzz7t end;return false,I,DQKzz7t else local Tx,izebj,RioX
for sgtu=1,#
KnightTitleRequirements[Rh8dzZf_].Category do
Tx,izebj,RioX=DoesNeededNumberOfEntitiesInCategoryForKnightTitleExist(v0xXBtzp,Rh8dzZf_,sgtu)if Tx==false then return Tx,izebj,RioX end end;return Tx end end
DoesNeededNumberOfEntitiesOfTypeForKnightTitleExist=function(i3XH,USt6PLe2,j)if
KnightTitleRequirements[USt6PLe2].Entities==nil then return end
if j then
local EHi=KnightTitleRequirements[USt6PLe2].Entities[j][1]
local Du4PWm2=KnightTitleRequirements[USt6PLe2].Entities[j][2]local jEJClb=GetPlayerEntities(i3XH,EHi)local np8JkPc=0
for Rfao=1,#jEJClb do if
Logic.IsBuilding(jEJClb[Rfao])==1 then if
Logic.IsConstructionComplete(jEJClb[Rfao])==1 then np8JkPc=np8JkPc+1 end else
np8JkPc=np8JkPc+1 end end;if np8JkPc>=Du4PWm2 then return true,np8JkPc,Du4PWm2 end
return false,np8JkPc,Du4PWm2 else local N6IWFa,Hr3mtiCq,mf1UO
for wykbGA84=1,#KnightTitleRequirements[USt6PLe2].Entities
do
N6IWFa,Hr3mtiCq,mf1UO=DoesNeededNumberOfEntitiesOfTypeForKnightTitleExist(i3XH,USt6PLe2,wykbGA84)if N6IWFa==false then return N6IWFa,Hr3mtiCq,mf1UO end end;return N6IWFa end end
DoesNeededNumberOfGoodTypesForKnightTitleExist=function(Pd,po2ff4F,f)if
KnightTitleRequirements[po2ff4F].Goods==nil then return end
if f then
local a=KnightTitleRequirements[po2ff4F].Goods[f][1]
local mBRe=KnightTitleRequirements[po2ff4F].Goods[f][2]local Cb=GetPlayerGoodsInSettlement(a,Pd,true)if Cb>=mBRe then
return true,Cb,mBRe end;return false,Cb,mBRe else local QP,k,NTz6jdr
for cgIU3=1,#
KnightTitleRequirements[po2ff4F].Goods do
QP,k,NTz6jdr=DoesNeededNumberOfGoodTypesForKnightTitleExist(Pd,po2ff4F,cgIU3)if QP==false then return QP,k,NTz6jdr end end;return QP end end
DoNeededNumberOfConsumedGoodsForKnightTitleExist=function(auV7A3JP,FzJwZ,Zb5)if
KnightTitleRequirements[FzJwZ].Consume==nil then return end
if Zb5 then QSB.ConsumedGoodsCounter[auV7A3JP]=
QSB.ConsumedGoodsCounter[auV7A3JP]or{}
local U=KnightTitleRequirements[FzJwZ].Consume[Zb5][1]
local D1Bo4qP=QSB.ConsumedGoodsCounter[auV7A3JP][U]or 0
local CaGUl8h=KnightTitleRequirements[FzJwZ].Consume[Zb5][2]
if D1Bo4qP>=CaGUl8h then return true,D1Bo4qP,CaGUl8h else return false,D1Bo4qP,CaGUl8h end else local zL,Ofe,TV4H8
for HdS=1,#KnightTitleRequirements[FzJwZ].Consume
do
zL,Ofe,TV4H8=DoNeededNumberOfConsumedGoodsForKnightTitleExist(auV7A3JP,FzJwZ,HdS)if zL==false then return false,Ofe,TV4H8 end end;return true,Ofe,TV4H8 end end
DoNumberOfProductsInCategoryExist=function(bvGUlnl8,E2J9X,y)if
KnightTitleRequirements[E2J9X].Products==nil then return end
if y then local _Sbcpg=0
local y99_=KnightTitleRequirements[E2J9X].Products[y][2]
local f7ZTY=KnightTitleRequirements[E2J9X].Products[y][1]
local WO={Logic.GetGoodTypesInGoodCategory(f7ZTY)}for dcu=1,#WO do
_Sbcpg=_Sbcpg+GetPlayerGoodsInSettlement(WO[dcu],bvGUlnl8,true)end
return(_Sbcpg>=y99_),_Sbcpg,y99_ else local HR,P,y1jZqCcc
for ARVZ=1,#KnightTitleRequirements[E2J9X].Products
do
HR,P,y1jZqCcc=DoNumberOfProductsInCategoryExist(bvGUlnl8,E2J9X,ARVZ)if HR==false then return HR,P,y1jZqCcc end end;return HR end end
DoNeededDiversityBuffForKnightTitleExist=function(ulU,mkpyU5eh,U9)if
KnightTitleRequirements[mkpyU5eh].Buff==nil then return end
if U9 then
local pzpDOr=KnightTitleRequirements[mkpyU5eh].Buff[U9]if
Logic.GetBuff(ulU,pzpDOr)and Logic.GetBuff(ulU,pzpDOr)~=0 then return true end;return false else local yoo,MXzW,Uvqu6c5
for MMXv=1,#
KnightTitleRequirements[mkpyU5eh].Buff do
yoo,MXzW,Uvqu6c5=DoNeededDiversityBuffForKnightTitleExist(ulU,mkpyU5eh,MMXv)if yoo==false then return yoo,MXzW,Uvqu6c5 end end;return yoo end end
DoCustomFunctionForKnightTitleSucceed=function(R,u,ipLsp)if
KnightTitleRequirements[u].Custom==nil then return end
if ipLsp then return
KnightTitleRequirements[u].Custom[ipLsp][1]()else local cpC,k73bTK,cqVt
for ywq=1,#
KnightTitleRequirements[u].Custom do
cpC,k73bTK,cqVt=DoCustomFunctionForKnightTitleSucceed(R,u,ywq)if cpC==false then return cpC,k73bTK,cqVt end end;return cpC end end
DoNeededNumberOfDecoratedBuildingsForKnightTitleExist=function(lMF,WVA,iWh)if
KnightTitleRequirements[WVA].DecoratedBuildings==nil then return end
if iWh then
local XG={Logic.GetPlayerEntitiesInCategory(lMF,EntityCategories.CityBuilding)}
local Ts=KnightTitleRequirements[WVA].DecoratedBuildings[iWh][1]
local K8jL8qZ=KnightTitleRequirements[WVA].DecoratedBuildings[iWh][2]local wucZH2qz=0
for Ox0yyMI3=1,#XG do local hvw=XG[Ox0yyMI3]
local ZFhe=Logic.GetBuildingWealthGoodState(hvw,Ts)if ZFhe>0 then wucZH2qz=wucZH2qz+1 end end
if wucZH2qz>=K8jL8qZ then return true,wucZH2qz,K8jL8qZ else return false,wucZH2qz,K8jL8qZ end else local Kgpa,TEz,AJJ1kZS
for B=1,#KnightTitleRequirements[WVA].DecoratedBuildings
do
Kgpa,TEz,AJJ1kZS=DoNeededNumberOfDecoratedBuildingsForKnightTitleExist(lMF,WVA,B)if Kgpa==false then return Kgpa,TEz,AJJ1kZS end end;return Kgpa end end
DoNeededSpecialBuildingUpgradeForKnightTitleExist=function(vZdI,Bd,e)local tsGRH;local U
if e==EntityCategories.Headquarters then
tsGRH=Logic.GetHeadquarters(vZdI)U="Headquarters"elseif e==EntityCategories.Storehouse then
tsGRH=Logic.GetStoreHouse(vZdI)U="Storehouse"elseif e==EntityCategories.Cathedrals then
tsGRH=Logic.GetCathedral(vZdI)U="Cathedrals"else return end
if KnightTitleRequirements[Bd][U]==nil then return end;local m=KnightTitleRequirements[Bd][U]
if tsGRH~=nil then
local U84H37=Logic.GetUpgradeLevel(tsGRH)
if U84H37 >=m then return true,U84H37,m else return false,U84H37,m end else return false,0,m end end
DoesNeededCityReputationForKnightTitleExist=function(C,f4fN)if
KnightTitleRequirements[f4fN].Reputation==nil then return end
local ODzAx=KnightTitleRequirements[f4fN].Reputation;if not ODzAx then return end;local IsAkf=math.floor(
(Logic.GetCityReputation(C)*100)+0.5)if
IsAkf>=ODzAx then return true,IsAkf,ODzAx end;return false,IsAkf,ODzAx end
DoNeededNumberOfFullDecoratedBuildingsForKnightTitleExist=function(Pwzq_Fj,GKDMp)if
KnightTitleRequirements[GKDMp].FullDecoratedBuildings==nil then return end
local SC={Logic.GetPlayerEntitiesInCategory(Pwzq_Fj,EntityCategories.CityBuilding)}
local bWuOG=KnightTitleRequirements[GKDMp].FullDecoratedBuildings;local jGg=0
for x=1,#SC do local vqs1_7=SC[x]local vLdk=0
if
Logic.GetBuildingWealthGoodState(vqs1_7,Goods.G_Banner)>0 then vLdk=vLdk+1 end;if
Logic.GetBuildingWealthGoodState(vqs1_7,Goods.G_Sign)>0 then vLdk=vLdk+1 end
if
Logic.GetBuildingWealthGoodState(vqs1_7,Goods.G_Candle)>0 then vLdk=vLdk+1 end;if
Logic.GetBuildingWealthGoodState(vqs1_7,Goods.G_Ornament)>0 then vLdk=vLdk+1 end
if vLdk>=4 then jGg=jGg+1 end end
if jGg>=bWuOG then return true,jGg,bWuOG else return false,jGg,bWuOG end end
CanKnightBePromoted=function(cU6JgXi,tEiL)if tEiL==nil then
tEiL=Logic.GetKnightTitle(cU6JgXi)+1 end
if
Logic.CanStartFestival(cU6JgXi,1)==true then
if















KnightTitleRequirements[tEiL]~=nil and
DoesNeededNumberOfSettlersForKnightTitleExist(cU6JgXi,tEiL)~=false and
DoNeededNumberOfGoodsForKnightTitleExist(cU6JgXi,tEiL)~=false and
DoNeededSpecialBuildingUpgradeForKnightTitleExist(cU6JgXi,tEiL,EntityCategories.Headquarters)~=false and
DoNeededSpecialBuildingUpgradeForKnightTitleExist(cU6JgXi,tEiL,EntityCategories.Storehouse)~=false and
DoNeededSpecialBuildingUpgradeForKnightTitleExist(cU6JgXi,tEiL,EntityCategories.Cathedrals)~=false and
DoNeededNumberOfRichBuildingsForKnightTitleExist(cU6JgXi,tEiL)~=false and
DoNeededNumberOfFullDecoratedBuildingsForKnightTitleExist(cU6JgXi,tEiL)~=false and
DoNeededNumberOfDecoratedBuildingsForKnightTitleExist(cU6JgXi,tEiL)~=false and
DoesNeededCityReputationForKnightTitleExist(cU6JgXi,tEiL)~=false and
DoesNeededNumberOfEntitiesInCategoryForKnightTitleExist(cU6JgXi,tEiL)~=false and
DoesNeededNumberOfEntitiesOfTypeForKnightTitleExist(cU6JgXi,tEiL)~=false and
DoesNeededNumberOfGoodTypesForKnightTitleExist(cU6JgXi,tEiL)~=false and
DoNeededDiversityBuffForKnightTitleExist(cU6JgXi,tEiL)~=false and
DoCustomFunctionForKnightTitleSucceed(cU6JgXi,tEiL)~=false and
DoNeededNumberOfConsumedGoodsForKnightTitleExist(cU6JgXi,tEiL)~=false and DoNumberOfProductsInCategoryExist(cU6JgXi,tEiL)~=false then return true end end;return false end
VictroryBecauseOfTitle=function()QuestTemplate:TerminateEventsAndStuff()
Victory(g_VictoryAndDefeatType.VictoryMissionComplete)end
InitKnightTitleTables=function()KnightTitles={}KnightTitles.Knight=0
KnightTitles.Mayor=1;KnightTitles.Baron=2;KnightTitles.Earl=3
KnightTitles.Marquees=4;KnightTitles.Duke=5;KnightTitles.Archduke=6
NeedsAndRightsByKnightTitle={}
NeedsAndRightsByKnightTitle[KnightTitles.Knight]={ActivateNeedForPlayer,{Needs.Nutrition,Needs.Medicine},ActivateRightForPlayer,{Technologies.R_Gathering,Technologies.R_Woodcutter,Technologies.R_StoneQuarry,Technologies.R_HuntersHut,Technologies.R_FishingHut,Technologies.R_CattleFarm,Technologies.R_GrainFarm,Technologies.R_SheepFarm,Technologies.R_IronMine,Technologies.R_Beekeeper,Technologies.R_HerbGatherer,Technologies.R_Nutrition,Technologies.R_Bakery,Technologies.R_Dairy,Technologies.R_Butcher,Technologies.R_SmokeHouse,Technologies.R_Clothes,Technologies.R_Tanner,Technologies.R_Weaver,Technologies.R_Construction,Technologies.R_Wall,Technologies.R_Pallisade,Technologies.R_Trail,Technologies.R_KnockDown,Technologies.R_Sermon,Technologies.R_SpecialEdition,Technologies.R_SpecialEdition_Pavilion}}
NeedsAndRightsByKnightTitle[KnightTitles.Mayor]={ActivateNeedForPlayer,{Needs.Clothes},ActivateRightForPlayer,{Technologies.R_Hygiene,Technologies.R_Soapmaker,Technologies.R_BroomMaker,Technologies.R_Military,Technologies.R_SwordSmith,Technologies.R_Barracks,Technologies.R_Thieves,Technologies.R_SpecialEdition_StatueFamily},StartKnightsPromotionCelebration}
NeedsAndRightsByKnightTitle[KnightTitles.Baron]={ActivateNeedForPlayer,{Needs.Hygiene},ActivateRightForPlayer,{Technologies.R_Medicine,Technologies.R_BowMaker,Technologies.R_BarracksArchers,Technologies.R_Entertainment,Technologies.R_Tavern,Technologies.R_Festival,Technologies.R_Street,Technologies.R_SpecialEdition_Column},StartKnightsPromotionCelebration}
NeedsAndRightsByKnightTitle[KnightTitles.Earl]={ActivateNeedForPlayer,{Needs.Entertainment,Needs.Prosperity},ActivateRightForPlayer,{Technologies.R_SiegeEngineWorkshop,Technologies.R_BatteringRam,Technologies.R_Baths,Technologies.R_AmmunitionCart,Technologies.R_Prosperity,Technologies.R_Taxes,Technologies.R_Ballista,Technologies.R_SpecialEdition_StatueSettler},StartKnightsPromotionCelebration}
NeedsAndRightsByKnightTitle[KnightTitles.Marquees]={ActivateNeedForPlayer,{Needs.Wealth},ActivateRightForPlayer,{Technologies.R_Theater,Technologies.R_Wealth,Technologies.R_BannerMaker,Technologies.R_SiegeTower,Technologies.R_SpecialEdition_StatueProduction},StartKnightsPromotionCelebration}
NeedsAndRightsByKnightTitle[KnightTitles.Duke]={ActivateNeedForPlayer,nil,ActivateRightForPlayer,{Technologies.R_Catapult,Technologies.R_Carpenter,Technologies.R_CandleMaker,Technologies.R_Blacksmith,Technologies.R_SpecialEdition_StatueDario},StartKnightsPromotionCelebration}
NeedsAndRightsByKnightTitle[KnightTitles.Archduke]={ActivateNeedForPlayer,nil,ActivateRightForPlayer,{Technologies.R_Victory},StartKnightsPromotionCelebration}
if g_GameExtraNo>=1 then local nWMi=4
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Mayor][nWMi],Technologies.R_Cistern)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Mayor][nWMi],Technologies.R_Beautification_Brazier)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Mayor][nWMi],Technologies.R_Beautification_Shrine)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Baron][nWMi],Technologies.R_Beautification_Pillar)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Earl][nWMi],Technologies.R_Beautification_StoneBench)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Earl][nWMi],Technologies.R_Beautification_Vase)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Marquees][nWMi],Technologies.R_Beautification_Sundial)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Archduke][nWMi],Technologies.R_Beautification_TriumphalArch)
table.insert(NeedsAndRightsByKnightTitle[KnightTitles.Duke][nWMi],Technologies.R_Beautification_VictoryColumn)end;KnightTitleRequirements={}
KnightTitleRequirements[KnightTitles.Mayor]={}
KnightTitleRequirements[KnightTitles.Mayor].Headquarters=1
KnightTitleRequirements[KnightTitles.Mayor].Settlers=10
KnightTitleRequirements[KnightTitles.Mayor].Products={{GoodCategories.GC_Clothes,6}}KnightTitleRequirements[KnightTitles.Baron]={}
KnightTitleRequirements[KnightTitles.Baron].Settlers=30
KnightTitleRequirements[KnightTitles.Baron].Headquarters=1
KnightTitleRequirements[KnightTitles.Baron].Storehouse=1
KnightTitleRequirements[KnightTitles.Baron].Cathedrals=1
KnightTitleRequirements[KnightTitles.Baron].Products={{GoodCategories.GC_Hygiene,12}}KnightTitleRequirements[KnightTitles.Earl]={}
KnightTitleRequirements[KnightTitles.Earl].Settlers=50
KnightTitleRequirements[KnightTitles.Earl].Headquarters=2
KnightTitleRequirements[KnightTitles.Earl].Products={{GoodCategories.GC_Entertainment,18}}
KnightTitleRequirements[KnightTitles.Marquees]={}
KnightTitleRequirements[KnightTitles.Marquees].Settlers=70
KnightTitleRequirements[KnightTitles.Marquees].Headquarters=2
KnightTitleRequirements[KnightTitles.Marquees].Storehouse=2
KnightTitleRequirements[KnightTitles.Marquees].Cathedrals=2
KnightTitleRequirements[KnightTitles.Marquees].RichBuildings=20;KnightTitleRequirements[KnightTitles.Duke]={}
KnightTitleRequirements[KnightTitles.Duke].Settlers=90
KnightTitleRequirements[KnightTitles.Duke].Storehouse=2
KnightTitleRequirements[KnightTitles.Duke].Cathedrals=2
KnightTitleRequirements[KnightTitles.Duke].Headquarters=3
KnightTitleRequirements[KnightTitles.Duke].DecoratedBuildings={{Goods.G_Banner,9}}
KnightTitleRequirements[KnightTitles.Archduke]={}
KnightTitleRequirements[KnightTitles.Archduke].Settlers=150
KnightTitleRequirements[KnightTitles.Archduke].Storehouse=3
KnightTitleRequirements[KnightTitles.Archduke].Cathedrals=3
KnightTitleRequirements[KnightTitles.Archduke].Headquarters=3
KnightTitleRequirements[KnightTitles.Archduke].RichBuildings=30
KnightTitleRequirements[KnightTitles.Archduke].FullDecoratedBuildings=30;CreateTechnologyKnightTitleTable()end;BundleMinimapMarker={}API=API or{}QSB=QSB or{}
MarkerColor={Blue={17,7,216},Red={216,7,7},Yellow={25,185,8},Green={16,194,220}}
function API.CreateMinimapSignal(gl9xJb,oHk5pUB)if GUI then
dbg("API.CreateMinimapSignal: Can not be used in local script!")return end;local Ltm=oHk5pUB;if
type(oHk5pUB)~="table"then Ltm=GetPosition(oHk5pUB)end;if
type(Ltm)~="table"or(not Ltm.X or not Ltm.X)then
dbg("API.CreateMinimapSignal: Position is invalid!")return end;return
BundleMinimapMarker.Global:CreateMinimapMarker(gl9xJb,Ltm.X,Ltm.Y,7)end;CreateMinimapSignal=API.CreateMinimapSignal
function API.CreateMinimapMarker(yW9GRj,QGXSL6)if GUI then
dbg("API.CreateMinimapMarker: Can not be used in local script!")return end;local M=QGXSL6;if
type(QGXSL6)~="table"then M=GetPosition(QGXSL6)end;if type(M)~="table"or(
not M.X or not M.X)then
dbg("API.CreateMinimapMarker: Position is invalid!")return end;return
BundleMinimapMarker.Global:CreateMinimapMarker(yW9GRj,M.X,M.Y,6)end;CreateMinimapMarker=API.CreateMinimapMarker
function API.CreateMinimapPulse(_X,eir)if GUI then
dbg("API.CreateMinimapPulse: Can not be used in local script!")return end;local e=eir;if type(eir)~="table"then
e=GetPosition(eir)end;if
type(e)~="table"or(not e.X or not e.X)then
dbg("API.CreateMinimapPulse: Position is invalid!")return end;return
BundleMinimapMarker.Global:CreateMinimapMarker(_X,e.X,e.Y,1)end;CreateMinimapPulse=API.CreateMinimapPulse
function API.DestroyMinimapSignal(XKqiVa3)if GUI then
dbg("API.DestroyMinimapSignal: Can not be used in local script!")return end;if type(XKqiVa3)~="number"then
dbg("API.DestroyMinimapSignal: _ID must be a number!")return end
BundleMinimapMarker.Global:DestroyMinimapMarker(XKqiVa3)end;DestroyMinimapMarker=API.DestroyMinimapSignal
BundleMinimapMarker={Global={Data={MarkerCounter=1000000,CreatedMinimapMarkers={}}},Local={Data={}}}function BundleMinimapMarker.Global:Install()
API.AddSaveGameAction(self.OnSaveGameLoaded)end
function BundleMinimapMarker.Global:CreateMinimapMarker(v4mltq,AIOtQ8e_,d,l7)self.Data.MarkerCounter=
self.Data.MarkerCounter+1
self.Data.CreatedMinimapMarkers[self.Data.MarkerCounter]={v4mltq,AIOtQ8e_,d,l7}
self:ShowMinimapMarker(self.Data.MarkerCounter)return self.Data.MarkerCounter end
function BundleMinimapMarker.Global:DestroyMinimapMarker(vtjp)self.Data.CreatedMinimapMarkers[vtjp]=
nil
API.Bridge([[GUI.DestroyMinimapSignal(]]..vtjp..[[)]])end
function BundleMinimapMarker.Global:ShowMinimapMarker(qLEp2)if not
self.Data.CreatedMinimapMarkers[qLEp2]then return end
local XbIEI_3k=self.Data.CreatedMinimapMarkers[qLEp2]local Ysuv=XbIEI_3k[1]if type(Ysuv)=="table"then
Ysuv=API.ConvertTableToString(Ysuv)end
API.Bridge([[
        BundleMinimapMarker.Local:ShowMinimapMarker(
            ]]..

qLEp2 ..[[,]]..
Ysuv..[[,]]..
XbIEI_3k[2]..[[,]]..XbIEI_3k[3]..
[[, ]]..XbIEI_3k[4]..[[
        )
    ]])end
function BundleMinimapMarker.Global.OnSaveGameLoaded()
for vmy19G,oO in
pairs(BundleMinimapMarker.Global.Data.CreatedMinimapMarkers)do if oO and oO[4]~=7 then
BundleMinimapMarker.Global:ShowMinimapMarker(vmy19G)end end end;function BundleMinimapMarker.Local:Install()end
function BundleMinimapMarker.Local:ShowMinimapMarker(zqYNA,XMzOvb,l8zYu,x17pq6s,Cxc)
local GdZty4,d,NQQjm0G
if type(XMzOvb)=="number"then
GdZty4,d,NQQjm0G=GUI.GetPlayerColor(XMzOvb)else GdZty4=XMzOvb[1]d=XMzOvb[2]NQQjm0G=XMzOvb[3]end
GUI.CreateMinimapSignalRGBA(zqYNA,l8zYu,x17pq6s,GdZty4,d,NQQjm0G,255,Cxc)end;Core:RegisterBundle("BundleMinimapMarker")
BundleSymfoniaBehaviors={}API=API or{}QSB=QSB or{}function Goal_MoveToPosition(...)return
b_Goal_MoveToPosition:new(...)end
b_Goal_MoveToPosition={Name="Goal_MoveToPosition",Description={en="Goal: A entity have to moved as close as the distance to another entity. The target can be marked with a static marker.",de="Ziel: Eine Entity muss sich einer anderen bis auf eine bestimmte Distanz nähern. Die Lupe wird angezeigt, das Ziel kann markiert werden."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.ScriptName,en="Target",de="Ziel"},{ParameterType.Number,en="Distance",de="Entfernung"},{ParameterType.Custom,en="Marker",de="Ziel markieren"}}}
function b_Goal_MoveToPosition:GetGoalTable()return
{Objective.Distance,self.Entity,self.Target,self.Distance,self.Marker}end
function b_Goal_MoveToPosition:AddParameter(qeyvW,fuJ)
if(qeyvW==0)then self.Entity=fuJ elseif(qeyvW==1)then
self.Target=fuJ elseif(qeyvW==2)then self.Distance=fuJ*1 elseif(qeyvW==3)then
self.Marker=AcceptAlternativeBoolean(fuJ)end end;function b_Goal_MoveToPosition:GetCustomData(vBt)local j6f={}
if vBt==3 then j6f={"true","false"}end;return j6f end
Core:RegisterBehavior(b_Goal_MoveToPosition)
function Goal_WinQuest(...)return b_Goal_WinQuest:new(...)end
b_Goal_WinQuest={Name="Goal_WinQuest",Description={en="Goal: The player has to win a given quest",de="Ziel: Der Spieler muss eine angegebene Quest erfolgreich abschliessen."},Parameter={{ParameterType.QuestName,en="Quest Name",de="Questname"}}}function b_Goal_WinQuest:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_WinQuest:AddParameter(DhLDRM,LgVwYh6)if(
DhLDRM==0)then self.Quest=LgVwYh6 end end
function b_Goal_WinQuest:CustomFunction(tSBo)
local FuIUnM=Quests[GetQuestID(self.Quest)]if FuIUnM then
if FuIUnM.Result==QuestResult.Failure then return false end
if FuIUnM.Result==QuestResult.Success then return true end end;return nil end
function b_Goal_WinQuest:DEBUG(WtoMT)
if
Quests[GetQuestID(self.Quest)]==nil then
dbg(WtoMT.Identifier..": "..self.Name..
": Quest '"..self.Quest.."' does not exist!")return true end;return false end;Core:RegisterBehavior(b_Goal_WinQuest)function Goal_StealGold(...)return
b_Goal_StealGold:new(...)end
b_Goal_StealGold={Name="Goal_StealGold",Description={en="Goal: Steal an explicit amount of gold from a players or any players city buildings.",de="Ziel: Diebe sollen eine bestimmte Menge Gold aus feindlichen Stadtgebäuden stehlen."},Parameter={{ParameterType.Number,en="Amount on Gold",de="Zu stehlende Menge"},{ParameterType.Custom,en="Target player",de="Spieler von dem gestohlen wird"},{ParameterType.Custom,en="Print progress",de="Fortschritt ausgeben"}}}function b_Goal_StealGold:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_StealGold:AddParameter(gTa7jfw,d6RaDSY)
if(
gTa7jfw==0)then self.Amount=d6RaDSY*1 elseif(gTa7jfw==1)then
local hJEr=tonumber(_Paramater)or-1;self.Target=hJEr*1 elseif(gTa7jfw==2)then d6RaDSY=d6RaDSY or"true"
self.Printout=AcceptAlternativeBoolean(d6RaDSY)end;self.StohlenGold=0 end
function b_Goal_StealGold:GetCustomData(deq_fwZ)if deq_fwZ==1 then return{"-",1,2,3,4,5,6,7,8}elseif deq_fwZ==2 then return
{"true","false"}end end
function b_Goal_StealGold:SetDescriptionOverwrite(d4iuG)
local tn2=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
local iFXPT_P=(tn2 =="de"and" anderen Spielern ")or" different parties"if self.Target~=-1 then iFXPT_P=GetPlayerName(self.Target)
if iFXPT_P==nil or
iFXPT_P==""then iFXPT_P=" PLAYER_NAME_MISSING "end end
local KY={self.Target}if self.Target==-1 then KY={1,2,3,4,5,6,7,8}end
for HLe=1,#KY,1 do
if
HLe~=
d4iuG.ReceivingPlayer and Logic.GetStoreHouse(HLe)~=0 then
local COX={Logic.GetPlayerEntitiesInCategory(HLe,EntityCategories.CityBuilding)}
for BP9Y0=1,#COX,1 do
local DR=Logic.GetBuildingProductEarnings(COX[BP9Y0])
if DR<45 and Logic.GetTime()%5 ==0 then Logic.SetBuildingEarnings(COX[BP9Y0],
DR+1)end end end end;local Vg7WM=self.Amount-self.StohlenGold;Vg7WM=
(Vg7WM>0 and Vg7WM)or 0
local DPOHoac={de="Gold von %s stehlen {cr}{cr}Aus Stadtgebäuden zu stehlende Goldmenge: %d",en="Steal gold from %s {cr}{cr}Amount on gold to steal from city buildings: %d"}return
"{center}"..string.format(DPOHoac[tn2],iFXPT_P,Vg7WM)end
function b_Goal_StealGold:CustomFunction(Lc4UCGl)
Core:ChangeCustomQuestCaptionText(self:SetDescriptionOverwrite(Lc4UCGl),Lc4UCGl)if self.StohlenGold>=self.Amount then return true end;return nil end;function b_Goal_StealGold:GetIcon()return{5,13}end
function b_Goal_StealGold:DEBUG(lEoJniu)
if
tonumber(self.Amount)==nil and self.Amount<0 then
dbg(lEoJniu.Identifier..": "..self.Name..
": amount can not be negative!")return true end;return false end;function b_Goal_StealGold:Reset()self.StohlenGold=0 end
Core:RegisterBehavior(b_Goal_StealGold)
function Goal_StealBuilding(...)return b_Goal_StealBuilding:new(...)end
b_Goal_StealBuilding={Name="Goal_StealBuilding",Description={en="Goal: The player has to steal from a building. Not a castle and not a village storehouse!",de="Ziel: Der Spieler muss ein bestimmtes Gebäude bestehlen. Dies darf keine Burg und kein Dorflagerhaus sein!"},Parameter={{ParameterType.ScriptName,en="Building",de="Gebäude"}}}
function b_Goal_StealBuilding:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end;function b_Goal_StealBuilding:AddParameter(sMV,HLkyy)if(sMV==0)then self.Building=HLkyy end
self.RobberList={}end
function b_Goal_StealBuilding:GetCustomData(ttFi_l_)if
ttFi_l_==1 then return{"true","false"}end end
function b_Goal_StealBuilding:SetDescriptionOverwrite(dSeSQ5)
local CHYkRQW6=
Logic.IsEntityInCategory(GetID(self.Building),EntityCategories.Cathedrals)==1
local cZtDtN7N=Logic.GetEntityType(GetID(self.Building))==Entities.B_StoreHouse;local Z7UyFJN=
(Network.GetDesiredLanguage()=="de"and"de")or"en"local DYBqYM
if CHYkRQW6 then
DYBqYM={de="Sabotage {cr}{cr} Sabotiert die mit Pfeil markierte Kirche.",en="Sabotage {cr}{cr} Sabotage the Church of the opponent."}elseif cZtDtN7N then
DYBqYM={de="Lagerhaus bestehlen {cr}{cr} Sendet einen Dieb in das markierte Lagerhaus.",en="Steal from storehouse {cr}{cr} Steal from the marked storehouse."}else
DYBqYM={de="Gebäude bestehlen {cr}{cr} Bestehlt das durch einen Pfeil markierte Gebäude.",en="Steal from building {cr}{cr} Steal from the building marked by an arrow."}end;return"{center}"..DYBqYM[Z7UyFJN]end
function b_Goal_StealBuilding:CustomFunction(s1)if not IsExisting(self.Building)then
if
self.Marker then Logic.DestroyEffect(self.Marker)end;return false end;if
not self.Marker then local aFb6x0hg=GetPosition(self.Building)
self.Marker=Logic.CreateEffect(EGL_Effects.E_Questmarker,aFb6x0hg.X,aFb6x0hg.Y,0)end
local v=GetID(self.Building)
if

Logic.IsEntityInCategory(v,EntityCategories.CityBuilding)==1 and Logic.GetBuildingEarnings(v)<10 then Logic.SetBuildingEarnings(v,10)end
if self.SuccessfullyStohlen then Logic.DestroyEffect(self.Marker)return true end;return nil end;function b_Goal_StealBuilding:GetIcon()return{5,13}end
function b_Goal_StealBuilding:DEBUG(_KKTJh)
local Gikjz8_9=Logic.GetEntityTypeName(Logic.GetEntityType(GetID(self.Building)))
local WN20gP=
Logic.IsEntityInCategory(GetID(self.Building),EntityCategories.Headquarters)==1
if Logic.IsBuilding(GetID(self.Building))==0 then
dbg(
_KKTJh.Identifier..": "..self.Name..": target is not a building")return true elseif not IsExisting(self.Building)then
dbg(_KKTJh.Identifier..": "..self.Name..
": target is destroyed :(")return true elseif string.find(Gikjz8_9,"B_NPC_BanditsHQ")or
string.find(Gikjz8_9,"B_NPC_Cloister")or
string.find(Gikjz8_9,"B_NPC_StoreHouse")then
dbg(_KKTJh.Identifier..

": "..self.Name..": village storehouses are not allowed!")return true elseif WN20gP then
dbg(_KKTJh.Identifier..": "..
self.Name..": use Goal_StealInformation for headquarters!")return true end;return false end;function b_Goal_StealBuilding:Reset()self.SuccessfullyStohlen=false;self.RobberList={}self.Marker=
nil end;function b_Goal_StealBuilding:Interrupt(L2VjlBE)
Logic.DestroyEffect(self.Marker)end
Core:RegisterBehavior(b_Goal_StealBuilding)
function Goal_SpyBuilding(...)return b_Goal_SpyBuilding:new(...)end
b_Goal_SpyBuilding={Name="Goal_SpyBuilding",IconOverwrite={5,13},Description={en="Goal: Infiltrate a building with a thief. A thief must be able to steal from the target building.",de="Ziel: Infiltriere ein Gebäude mit einem Dieb. Nur mit Gebaueden möglich, die bestohlen werden koennen."},Parameter={{ParameterType.ScriptName,en="Target Building",de="Zielgebäude"},{ParameterType.Custom,en="Destroy Thief",de="Dieb löschen"}}}
function b_Goal_SpyBuilding:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_SpyBuilding:AddParameter(xH,N)if(xH==0)then self.Building=N elseif(xH==1)then N=N or"true"
self.Delete=AcceptAlternativeBoolean(N)end end
function b_Goal_SpyBuilding:GetCustomData(R)if R==1 then return{"true","false"}end end
function b_Goal_SpyBuilding:SetDescriptionOverwrite(owi4kS)
if not owi4kS.QuestDescription then
local zUfjp=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
local fd5S4R={de="Gebäude infriltrieren {cr}{cr}Spioniere das markierte Gebäude mit einem Dieb aus!",en="Infiltrate building {cr}{cr}Spy on the highlighted buildings with a thief!"}return fd5S4R[zUfjp]else return owi4kS.QuestDescription end end
function b_Goal_SpyBuilding:CustomFunction(Jt)
if not IsExisting(self.Building)then if self.Marker then
Logic.DestroyEffect(self.Marker)end;return false end;if not self.Marker then local GVscDb=GetPosition(self.Building)
self.Marker=Logic.CreateEffect(EGL_Effects.E_Questmarker,GVscDb.X,GVscDb.Y,0)end
local vJ88gTG=GetID(self.Building)
if

Logic.IsEntityInCategory(vJ88gTG,EntityCategories.CityBuilding)==1 and Logic.GetBuildingEarnings(vJ88gTG)<10 then Logic.SetBuildingEarnings(vJ88gTG,10)end
if self.Infiltrated then Logic.DestroyEffect(self.Marker)return true end;return nil end
function b_Goal_SpyBuilding:GetIcon()return self.IconOverwrite end
function b_Goal_SpyBuilding:DEBUG(eGuTD)
if
Logic.IsBuilding(GetID(self.Building))==0 then
dbg(eGuTD.Identifier..
": "..self.Name..": target is not a building")return true elseif not IsExisting(self.Building)then
dbg(eGuTD.Identifier..": "..self.Name..
": target is destroyed :(")return true end;return false end
function b_Goal_SpyBuilding:Reset()self.Infiltrated=false;self.Marker=nil end
function b_Goal_SpyBuilding:Interrupt(l)Logic.DestroyEffect(self.Marker)end;Core:RegisterBehavior(b_Goal_SpyBuilding)function Goal_AmmunitionAmount(...)return
b_Goal_AmmunitionAmount:new(...)end
b_Goal_AmmunitionAmount={Name="Goal_AmmunitionAmount",Description={en="Goal: Reach a smaller or bigger value than the given amount of ammunition in a war machine.",de="Ziel: Ueber- oder unterschreite die angegebene Anzahl Munition in einem Kriegsgerät."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"},{ParameterType.Custom,en="Relation",de="Relation"},{ParameterType.Number,en="Amount",de="Menge"}}}
function b_Goal_AmmunitionAmount:GetGoalTable()return
{Objective.Custom2,{self,self.CustomFunction}}end
function b_Goal_AmmunitionAmount:AddParameter(rcJbyavv,nPu)
if(rcJbyavv==0)then self.Scriptname=nPu elseif
(rcJbyavv==1)then
self.bRelSmallerThan=tostring(nPu)=="true"or nPu=="<"elseif(rcJbyavv==2)then self.Amount=nPu*1 end end
function b_Goal_AmmunitionAmount:CustomFunction()local wKdmIyn=GetID(self.Scriptname)if not
IsExisting(wKdmIyn)then return false end
local Po67cFi=Logic.GetAmmunitionAmount(wKdmIyn)
if
(self.bRelSmallerThan and Po67cFi<self.Amount)or
(not self.bRelSmallerThan and Po67cFi>=self.Amount)then return true end;return nil end
function b_Goal_AmmunitionAmount:DEBUG(nlAeE)if self.Amount<0 then
dbg(nlAeE.Identifier..": Error in "..self.Name..
": Amount is negative")return true end end
function b_Goal_AmmunitionAmount:GetCustomData(h)if h==1 then return{"<",">="}end end;Core:RegisterBehavior(b_Goal_AmmunitionAmount)function Reprisal_SetPosition(...)return
b_Reprisal_SetPosition:new(...)end
b_Reprisal_SetPosition={Name="Reprisal_SetPosition",Description={en="Reprisal: Places an entity relative to the position of another. The entity can look the target.",de="Vergeltung: Setzt eine Entity relativ zur Position einer anderen. Die Entity kann zum Ziel ausgerichtet werden."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.ScriptName,en="Target position",de="Zielposition"},{ParameterType.Custom,en="Face to face",de="Ziel ansehen"},{ParameterType.Number,en="Distance",de="Zielentfernung"}}}
function b_Reprisal_SetPosition:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_SetPosition:AddParameter(B,mmcA)
if(B==0)then self.Entity=mmcA elseif(B==1)then
self.Target=mmcA elseif(B==2)then self.FaceToFace=AcceptAlternativeBoolean(mmcA)elseif(B==3)then
self.Distance=(
mmcA~=nil and tonumber(mmcA))or 100 end end
function b_Reprisal_SetPosition:CustomFunction(Pk)
if not IsExisting(self.Entity)or not
IsExisting(self.Target)then return end;local es=GetID(self.Entity)local F0ZX=GetID(self.Target)
local W_,he3X,IAEOa=Logic.EntityGetPos(F0ZX)if Logic.IsBuilding(F0ZX)==1 then
W_,he3X=Logic.GetBuildingApproachPosition(F0ZX)end;local lq0=
Logic.GetEntityOrientation(F0ZX)+90
if self.FaceToFace then W_=W_+self.Distance*
math.cos(math.rad(lq0))he3X=he3X+self.Distance*
math.sin(math.rad(lq0))
Logic.DEBUG_SetSettlerPosition(es,W_,he3X)LookAt(self.Entity,self.Target)else
if
Logic.IsBuilding(F0ZX)==1 then W_,he3X=Logic.GetBuildingApproachPosition(F0ZX)end;Logic.DEBUG_SetSettlerPosition(es,W_,he3X)end end;function b_Reprisal_SetPosition:GetCustomData(cJ)
if cJ==3 then return{"true","false"}end end
function b_Reprisal_SetPosition:DEBUG(VxeY5X)
if
self.FaceToFace then
if
tonumber(self.Distance)==nil or self.Distance<50 then
dbg(VxeY5X.Identifier..
" "..self.Name..": Distance is nil or to short!")return true end end
if
not IsExisting(self.Entity)or not IsExisting(self.Target)then
dbg(VxeY5X.Identifier.." "..
self.Name..": Mover entity or target entity does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_SetPosition)function Reprisal_ChangePlayer(...)return
b_Reprisal_ChangePlayer:new(...)end
b_Reprisal_ChangePlayer={Name="Reprisal_ChangePlayer",Description={en="Reprisal: Changes the owner of the entity or a battalion.",de="Vergeltung: Aendert den Besitzer einer Entity oder eines Battalions."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Player",de="Spieler"}}}
function b_Reprisal_ChangePlayer:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_ChangePlayer:AddParameter(oS8SgP,hBilFrU4)
if(oS8SgP==0)then self.Entity=hBilFrU4 elseif
(oS8SgP==1)then self.Player=tostring(hBilFrU4)end end
function b_Reprisal_ChangePlayer:CustomFunction(AodN1)
if not IsExisting(self.Entity)then return end;local yj4Mo=GetID(self.Entity)
if Logic.IsLeader(yj4Mo)==1 then
Logic.ChangeSettlerPlayerID(yj4Mo,self.Player)else Logic.ChangeEntityPlayerID(yj4Mo,self.Player)end end
function b_Reprisal_ChangePlayer:GetCustomData(BiwDB)if BiwDB==1 then
return{"0","1","2","3","4","5","6","7","8"}end end
function b_Reprisal_ChangePlayer:DEBUG(Ca)if not IsExisting(self.Entity)then
dbg(Ca.Identifier.." "..

self.Name..": entity '"..self.Entity.."' does not exist!")return true end;return
false end;Core:RegisterBehavior(b_Reprisal_ChangePlayer)function Reprisal_SetVisible(...)return
b_Reprisal_SetVisible:new(...)end
b_Reprisal_SetVisible={Name="Reprisal_SetVisible",Description={en="Reprisal: Changes the visibility of an entity. If the entity is a spawner the spawned entities will be affected.",de="Strafe: Setzt die Sichtbarkeit einer Entity. Handelt es sich um einen Spawner werden auch die gespawnten Entities beeinflusst."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Visible",de="Sichtbar"}}}
function b_Reprisal_SetVisible:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_SetVisible:AddParameter(wHJE0ZY,Js7)if(wHJE0ZY==0)then self.Entity=Js7 elseif(wHJE0ZY==1)then
self.Visible=AcceptAlternativeBoolean(Js7)end end
function b_Reprisal_SetVisible:CustomFunction(h6W2B6z)
if not IsExisting(self.Entity)then return end;local Cx=GetID(self.Entity)
local oj=Logic.EntityGetPlayer(Cx)local u1=Logic.GetEntityType(Cx)
local TYixjzX4=Logic.GetEntityTypeName(u1)
if

string.find(TYixjzX4,"S_")or string.find(TYixjzX4,"B_NPC_Bandits")or string.find(TYixjzX4,"B_NPC_Barracks")then local vI9Mah0={Logic.GetSpawnedEntities(Cx)}
for Ad=1,#vI9Mah0 do
if
Logic.IsLeader(vI9Mah0[Ad])==1 then
local l={Logic.GetSoldiersAttachedToLeader(vI9Mah0[Ad])}
for LwNRuJvR=2,#l do Logic.SetVisible(l[LwNRuJvR],self.Visible)end else Logic.SetVisible(vI9Mah0[Ad],self.Visible)end end else
if Logic.IsLeader(Cx)==1 then
local nohO9Ia={Logic.GetSoldiersAttachedToLeader(Cx)}for FDJ=2,#nohO9Ia do
Logic.SetVisible(nohO9Ia[FDJ],self.Visible)end else
Logic.SetVisible(Cx,self.Visible)end end end;function b_Reprisal_SetVisible:GetCustomData(u)
if u==1 then return{"true","false"}end end
function b_Reprisal_SetVisible:DEBUG(v)if not
IsExisting(self.Entity)then
dbg(v.Identifier.." "..self.Name..
": entity '"..self.Entity.."' does not exist!")return true end;return
false end;Core:RegisterBehavior(b_Reprisal_SetVisible)function Reprisal_SetVulnerability(...)return
b_Reprisal_SetVulnerability:new(...)end
b_Reprisal_SetVulnerability={Name="Reprisal_SetVulnerability",Description={en="Reprisal: Changes the vulnerability of the entity. If the entity is a spawner the spawned entities will be affected.",de="Vergeltung: Macht eine Entity verwundbar oder unverwundbar. Handelt es sich um einen Spawner, sind die gespawnten Entities betroffen"},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Vulnerability",de="Verwundbar"}}}
function b_Reprisal_SetVulnerability:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end
function b_Reprisal_SetVulnerability:AddParameter(i0iuEsi,q)
if(i0iuEsi==0)then self.Entity=q elseif
(i0iuEsi==1)then self.Vulnerability=AcceptAlternativeBoolean(q)end end
function b_Reprisal_SetVulnerability:CustomFunction(Wrjc)
if not IsExisting(self.Entity)then return end;local y2zVVi=GetID(self.Entity)
local mQIVEP5=Logic.GetEntityType(y2zVVi)local QV4HoK0r=Logic.GetEntityTypeName(mQIVEP5)local uqoP={y2zVVi}
if
string.find(QV4HoK0r,"S_")or string.find(QV4HoK0r,"B_NPC_Bandits")or
string.find(QV4HoK0r,"B_NPC_Barracks")then
uqoP={Logic.GetSpawnedEntities(y2zVVi)}end;local fXnJ2kO="MakeInvulnerable"
if self.Vulnerability then fXnJ2kO="MakeVulnerable"end
for mHD8=1,#uqoP,1 do
if Logic.IsLeader(uqoP[mHD8])==1 then
local L={Logic.GetSoldiersAttachedToLeader(uqoP[mHD8])}for tlNupYZ=2,#L,1 do _G[fXnJ2kO](L[tlNupYZ])end end;_G[fXnJ2kO](uqoP[mHD8])end end;function b_Reprisal_SetVulnerability:GetCustomData(VY6SD)
if VY6SD==1 then return{"true","false"}end end
function b_Reprisal_SetVulnerability:DEBUG(ydb)if
not IsExisting(self.Entity)then
dbg(ydb.Identifier..
" "..self.Name..": entity '"..self.Entity..
"' does not exist!")return true end;return
false end
Core:RegisterBehavior(b_Reprisal_SetVulnerability)
function Reprisal_SetModel(...)return b_Reprisal_SetModel:new(...)end
b_Reprisal_SetModel={Name="Reprisal_SetModel",Description={en="Reprisal: Changes the model of the entity. Be careful, some models crash the game.",de="Vergeltung: Aendert das Model einer Entity. Achtung: Einige Modelle fuehren zum Absturz."},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="Model",de="Model"}}}
function b_Reprisal_SetModel:GetReprisalTable()return
{Reprisal.Custom,{self,self.CustomFunction}}end;function b_Reprisal_SetModel:AddParameter(O,_)
if(O==0)then self.Entity=_ elseif(O==1)then self.Model=_ end end
function b_Reprisal_SetModel:CustomFunction(ElVn76)if
not IsExisting(self.Entity)then return end
local yAEULfS=GetID(self.Entity)Logic.SetModel(yAEULfS,Models[self.Model])end
function b_Reprisal_SetModel:GetCustomData(O6Ft6oPX)
if O6Ft6oPX==1 then local RWubfxqF={}
for E,e0kpxJ in pairs(Models)do
if










not
string.find(E,"Animals_")and not string.find(E,"Banners_")and not string.find(E,"Goods_")and not string.find(E,"goods_")and not string.find(E,"Heads_")and not string.find(E,"MissionMap_")and not string.find(E,"R_Fish")and not string.find(E,"Units_")and not string.find(E,"XD_")and not string.find(E,"XS_")and not string.find(E,"XT_")and not string.find(E,"Z_")then table.insert(RWubfxqF,E)end end;return RWubfxqF end end
function b_Reprisal_SetModel:DEBUG(VXZfG)
if not IsExisting(self.Entity)then
dbg(VXZfG.Identifier.." "..

self.Name..": entity '"..self.Entity.."' does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reprisal_SetModel)function Reward_SetPosition(...)return
b_Reward_SetPosition:new(...)end
b_Reward_SetPosition=API.InstanceTable(b_Reprisal_SetPosition)b_Reward_SetPosition.Name="Reward_SetPosition"
b_Reward_SetPosition.Description.en="Reward: Places an entity relative to the position of another. The entity can look the target."
b_Reward_SetPosition.Description.de="Lohn: Setzt eine Entity relativ zur Position einer anderen. Die Entity kann zum Ziel ausgerichtet werden."b_Reward_SetPosition.GetReprisalTable=nil
b_Reward_SetPosition.GetRewardTable=function(Bd,Qf)return
{Reward.Custom,{Bd,Bd.CustomFunction}}end;Core:RegisterBehavior(b_Reward_SetPosition)function Reward_ChangePlayer(...)return
b_Reward_ChangePlayer:new(...)end
b_Reward_ChangePlayer=API.InstanceTable(b_Reprisal_ChangePlayer)b_Reward_ChangePlayer.Name="Reward_ChangePlayer"
b_Reward_ChangePlayer.Description.en="Reward: Changes the owner of the entity or a battalion."
b_Reward_ChangePlayer.Description.de="Lohn: Aendert den Besitzer einer Entity oder eines Battalions."b_Reward_ChangePlayer.GetReprisalTable=nil
b_Reward_ChangePlayer.GetRewardTable=function(p2jTk,_5Pf)return
{Reward.Custom,{p2jTk,p2jTk.CustomFunction}}end;Core:RegisterBehavior(b_Reward_ChangePlayer)function Reward_MoveToPosition(...)return
b_Reward_MoveToPosition:new(...)end
b_Reward_MoveToPosition={Name="Reward_MoveToPosition",Description={en="Reward: Moves an entity relative to another entity. If angle is zero the entities will be standing directly face to face.",de="Lohn: Bewegt eine Entity relativ zur Position einer anderen. Wenn Winkel 0 ist, stehen sich die Entities direkt gegen�ber."},Parameter={{ParameterType.ScriptName,en="Settler",de="Siedler"},{ParameterType.ScriptName,en="Destination",de="Ziel"},{ParameterType.Number,en="Distance",de="Entfernung"},{ParameterType.Number,en="Angle",de="Winkel"}}}function b_Reward_MoveToPosition:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_MoveToPosition:AddParameter(vHVSWs9,IR7v)
if(
vHVSWs9 ==0)then self.Entity=IR7v elseif(vHVSWs9 ==1)then self.Target=IR7v elseif
(vHVSWs9 ==2)then self.Distance=IR7v*1 elseif(vHVSWs9 ==3)then self.Angle=IR7v*1 end end
function b_Reward_MoveToPosition:CustomFunction(_SmNfMoD)
if not IsExisting(self.Entity)or not
IsExisting(self.Target)then return end;self.Angle=self.Angle or 0;local g5wBR=GetID(self.Entity)
local z0SIbm=GetID(self.Target)local zL=Logic.GetEntityOrientation(z0SIbm)
local nWzKrVe,zha,yBtE=Logic.EntityGetPos(z0SIbm)if Logic.IsBuilding(z0SIbm)==1 then
nWzKrVe,zha=Logic.GetBuildingApproachPosition(z0SIbm)zL=zL-90 end;nWzKrVe=nWzKrVe+

self.Distance*math.cos(math.rad(zL+self.Angle))
zha=zha+self.Distance*math.sin(math.rad(
zL+self.Angle))Logic.MoveSettler(g5wBR,nWzKrVe,zha)
StartSimpleJobEx(function(GlmZIM,bm)
if
Logic.IsEntityMoving(GlmZIM)==false then LookAt(GlmZIM,bm)return true end end,g5wBR,z0SIbm)end
function b_Reward_MoveToPosition:DEBUG(ken)
if tonumber(self.Distance)==nil or
self.Distance<50 then
dbg(ken.Identifier.." "..
self.Name..": Distance is nil or to short!")return true elseif not IsExisting(self.Entity)or
not IsExisting(self.Target)then
dbg(ken.Identifier.." "..
self.Name..": Mover entity or target entity does not exist!")return true end;return false end;Core:RegisterBehavior(b_Reward_MoveToPosition)function Reward_VictoryWithParty()return
b_Reward_VictoryWithParty:new()end
b_Reward_VictoryWithParty={Name="Reward_VictoryWithParty",Description={en="Reward: The player wins the game with an animated festival on the market.",de="Lohn: Der Spieler gewinnt das Spiel mit einer animierten Siegesfeier."},Parameter={}}
function b_Reward_VictoryWithParty:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function b_Reward_VictoryWithParty:AddParameter(gHpr,wL)end
function b_Reward_VictoryWithParty:CustomFunction(uXW)
Victory(g_VictoryAndDefeatType.VictoryMissionComplete)local f1Guph=uXW.ReceivingPlayer
local VoIe2R=Logic.GetMarketplace(f1Guph)
if IsExisting(VoIe2R)then local wULNB=GetPosition(VoIe2R)
Logic.CreateEffect(EGL_Effects.FXFireworks01,wULNB.X,wULNB.Y,0)
Logic.CreateEffect(EGL_Effects.FXFireworks02,wULNB.X,wULNB.Y,0)
local Uin1c={Entities.U_SmokeHouseWorker,Entities.U_Butcher,Entities.U_Carpenter,Entities.U_Tanner,Entities.U_Blacksmith,Entities.U_CandleMaker,Entities.U_Baker,Entities.U_DairyWorker,Entities.U_SpouseS01,Entities.U_SpouseS02,Entities.U_SpouseS02,Entities.U_SpouseS03,Entities.U_SpouseF01,Entities.U_SpouseF01,Entities.U_SpouseF02,Entities.U_SpouseF03}VictoryGenerateFestivalAtPlayer(f1Guph,Uin1c)
Logic.ExecuteInLuaLocalState(
[[
            if IsExisting(]]..
VoIe2R..

[[) then
                CameraAnimation.AllowAbort = false
                CameraAnimation.QueueAnimation( CameraAnimation.SetCameraToEntity, ]]..
VoIe2R..
[[)
                CameraAnimation.QueueAnimation( CameraAnimation.StartCameraRotation,  5 )
                CameraAnimation.QueueAnimation( CameraAnimation.Stay ,  9999 )
            end
            XGUIEng.ShowWidget("/InGame/InGame/MissionEndScreen/ContinuePlaying", 0);
        ]])end end;function b_Reward_VictoryWithParty:DEBUG(uZOynu)return false end
Core:RegisterBehavior(b_Reward_VictoryWithParty)
function Reward_SetVisible(...)return b_Reward_SetVisible:new(...)end
b_Reward_SetVisible=API.InstanceTable(b_Reprisal_SetVisible)b_Reward_SetVisible.Name="Reward_SetVisible"
b_Reward_SetVisible.Description.en="Reward: Changes the visibility of an entity. If the entity is a spawner the spawned entities will be affected."
b_Reward_SetVisible.Description.de="Lohn: Setzt die Sichtbarkeit einer Entity. Handelt es sich um einen Spawner werden auch die gespawnten Entities beeinflusst."b_Reward_SetVisible.GetReprisalTable=nil
b_Reward_SetVisible.GetRewardTable=function(XYjab,g226Ed)return
{Reward.Custom,{XYjab,XYjab.CustomFunction}}end;Core:RegisterBehavior(b_Reward_SetVisible)function Reward_AI_SetEntityControlled(...)return
b_Reward_AI_SetEntityControlled:new(...)end
b_Reward_AI_SetEntityControlled={Name="Reward_AI_SetEntityControlled",Description={en="Reward: Bind or Unbind an entity or a battalion to/from an AI player. The AI player must be activated!",de="Lohn: Die KI kontrolliert die Entity oder der KI die Kontrolle entziehen. Die KI muss aktiv sein!"},Parameter={{ParameterType.ScriptName,en="Entity",de="Entity"},{ParameterType.Custom,en="AI control entity",de="KI kontrolliert Entity"}}}
function b_Reward_AI_SetEntityControlled:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_AI_SetEntityControlled:AddParameter(iKS,vKlf)if(iKS==0)then self.Entity=vKlf elseif(iKS==1)then
self.Hidden=AcceptAlternativeBoolean(vKlf)end end
function b_Reward_AI_SetEntityControlled:CustomFunction(SlWsaU)if
not IsExisting(self.Entity)then return end;local Mj=GetID(self.Entity)
local c_=Logic.EntityGetPlayer(Mj)local Kw4ta8iS=Logic.GetEntityType(Mj)
local AlV6=Logic.GetEntityTypeName(Kw4ta8iS)
if

string.find(AlV6,"S_")or string.find(AlV6,"B_NPC_Bandits")or string.find(AlV6,"B_NPC_Barracks")then local LtS={Logic.GetSpawnedEntities(Mj)}
for TaJ2US=1,#LtS do if
Logic.IsLeader(LtS[TaJ2US])==1 then
AICore.HideEntityFromAI(c_,LtS[TaJ2US],not self.Hidden)end end else
AICore.HideEntityFromAI(c_,Mj,not self.Hidden)end end;function b_Reward_AI_SetEntityControlled:GetCustomData(Ghp0)
if Ghp0 ==1 then return{"false","true"}end end
function b_Reward_AI_SetEntityControlled:DEBUG(opR)if
not IsExisting(self.Entity)then
dbg(opR.Identifier..
" "..self.Name..": entity '"..self.Entity..
"' does not exist!")return true end;return
false end
Core:RegisterBehavior(b_Reward_AI_SetEntityControlled)function Reward_SetVulnerability(...)
return b_Reward_SetVulnerability:new(...)end
b_Reward_SetVulnerability=API.InstanceTable(b_Reprisal_SetVulnerability)b_Reward_SetVulnerability.Name="Reward_SetVulnerability"
b_Reward_SetVulnerability.Description.en="Reward: Changes the vulnerability of the entity. If the entity is a spawner the spawned entities will be affected."
b_Reward_SetVulnerability.Description.de="Lohn: Macht eine Entity verwundbar oder unverwundbar. Handelt es sich um einen Spawner, sind die gespawnten Entities betroffen."b_Reward_SetVulnerability.GetReprisalTable=nil
b_Reward_SetVulnerability.GetRewardTable=function(sif2,PGiQADW)return
{Reward.Custom,{sif2,sif2.CustomFunction}}end;Core:RegisterBehavior(b_Reward_SetVulnerability)function Reward_SetModel(...)return
b_Reward_SetModel:new(...)end
b_Reward_SetModel=API.InstanceTable(b_Reprisal_SetModel)b_Reward_SetModel.Name="Reward_SetModel"
b_Reward_SetModel.Description.en="Reward: Changes the model of the entity. Be careful, some models crash the game."
b_Reward_SetModel.Description.de="Lohn: Aendert das Model einer Entity. Achtung: Einige Modelle fuehren zum Absturz."b_Reward_SetModel.GetReprisalTable=nil
b_Reward_SetModel.GetRewardTable=function(PI,dZc)return
{Reward.Custom,{PI,PI.CustomFunction}}end;Core:RegisterBehavior(b_Reward_SetModel)function Reward_RefillAmmunition(...)return
b_Reward_RefillAmmunition:new(...)end
b_Reward_RefillAmmunition={Name="Reward_RefillAmmunition",Description={en="Reward: Refills completely the ammunition of the entity.",de="Lohn: Fuellt die Munition der Entity vollständig auf."},Parameter={{ParameterType.ScriptName,en="Script name",de="Skriptname"}}}
function b_Reward_RefillAmmunition:GetRewardTable()return
{Reward.Custom,{self,self.CustomFunction}}end;function b_Reward_RefillAmmunition:AddParameter(iebKJjA,d)
if(iebKJjA==0)then self.Scriptname=d end end
function b_Reward_RefillAmmunition:CustomFunction()
local CaFSQRf=GetID(self.Scriptname)if not IsExisting(CaFSQRf)then return end
local vn3NH=Logic.GetAmmunitionAmount(CaFSQRf)while(vn3NH<10)do Logic.RefillAmmunitions(CaFSQRf)
vn3NH=Logic.GetAmmunitionAmount(CaFSQRf)end end
function b_Reward_RefillAmmunition:DEBUG(JFZ)
if not IsExisting(self.Scriptname)then
dbg(
JFZ.Identifier..": Error in "..
self.Name..": '"..self.Scriptname.."' is destroyed!")return true end;return false end;Core:RegisterBehavior(b_Reward_RefillAmmunition)
function Trigger_OnAtLeastXOfYQuestsFailed(...)return
b_Trigger_OnAtLeastXOfYQuestsFailed:new(...)end
b_Trigger_OnAtLeastXOfYQuestsFailed={Name="Trigger_OnAtLeastXOfYQuestsFailed",Description={en="Trigger: if at least X of Y given quests has been finished successfully.",de="Ausloeser: wenn X von Y angegebener Quests fehlgeschlagen sind."},Parameter={{ParameterType.Custom,en="Least Amount",de="Mindest Anzahl"},{ParameterType.Custom,en="Quest Amount",de="Quest Anzahl"},{ParameterType.QuestName,en="Quest name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest name 2",de="Questname 2"},{ParameterType.QuestName,en="Quest name 3",de="Questname 3"},{ParameterType.QuestName,en="Quest name 4",de="Questname 4"},{ParameterType.QuestName,en="Quest name 5",de="Questname 5"}}}
function b_Trigger_OnAtLeastXOfYQuestsFailed:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnAtLeastXOfYQuestsFailed:AddParameter(L,j_st9)
if(L==0)then
self.LeastAmount=tonumber(j_st9)elseif(L==1)then self.QuestAmount=tonumber(j_st9)elseif(L==2)then self.QuestName1=j_st9 elseif(L==
3)then self.QuestName2=j_st9 elseif(L==4)then self.QuestName3=j_st9 elseif(L==5)then
self.QuestName4=j_st9 elseif(L==6)then self.QuestName5=j_st9 end end
function b_Trigger_OnAtLeastXOfYQuestsFailed:CustomFunction()local Ubiy=0
for mIV=1,self.QuestAmount do
local hgRaw=GetQuestID(self["QuestName"..mIV])if IsValidQuest(hgRaw)then
if
(Quests[hgRaw].Result==QuestResult.Failure)then Ubiy=Ubiy+1;if Ubiy>=self.LeastAmount then return true end end end end;return false end
function b_Trigger_OnAtLeastXOfYQuestsFailed:DEBUG(vvwRldj)local f_7I8Jo=self.LeastAmount
local K072gC9=self.QuestAmount
if f_7I8Jo<=0 or f_7I8Jo>5 then
dbg(vvwRldj.Identifier..": Error in "..
self.Name..": LeastAmount is wrong")return true elseif K072gC9 <=0 or K072gC9 >5 then
dbg(vvwRldj.Identifier..": Error in "..self.Name..
": QuestAmount is wrong")return true elseif f_7I8Jo>K072gC9 then
dbg(vvwRldj.Identifier..": Error in "..
self.Name..": LeastAmount is greater than QuestAmount")return true end
for SbuPM=1,K072gC9 do
if
not IsValidQuest(self["QuestName"..SbuPM])then
dbg(vvwRldj.Identifier..
": Error in "..self.Name..": Quest "..
self["QuestName"..SbuPM].." not found")return true end end;return false end
function b_Trigger_OnAtLeastXOfYQuestsFailed:GetCustomData(cobaoFK)if
(cobaoFK==0)or(cobaoFK==1)then return{"1","2","3","4","5"}end end
Core:RegisterBehavior(b_Trigger_OnAtLeastXOfYQuestsFailed)function Trigger_AmmunitionDepleted(...)
return b_Trigger_AmmunitionDepleted:new(...)end
b_Trigger_AmmunitionDepleted={Name="Trigger_AmmunitionDepleted",Description={en="Trigger: if the ammunition of the entity is depleted.",de="Ausloeser: wenn die Munition der Entity aufgebraucht ist."},Parameter={{ParameterType.Scriptname,en="Script name",de="Skriptname"}}}
function b_Trigger_AmmunitionDepleted:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end;function b_Trigger_AmmunitionDepleted:AddParameter(JbhOvI,yA)
if(JbhOvI==0)then self.Scriptname=yA end end
function b_Trigger_AmmunitionDepleted:CustomFunction()
if
not IsExisting(self.Scriptname)then return false end;local NUsjSgB=GetID(self.Scriptname)if
Logic.GetAmmunitionAmount(NUsjSgB)>0 then return false end;return true end
function b_Trigger_AmmunitionDepleted:DEBUG(Xuvxfbm)
if not IsExisting(self.Scriptname)then
dbg(
Xuvxfbm.Identifier..": Error in "..
self.Name..": '"..self.Scriptname.."' is destroyed!")return true end;return false end
Core:RegisterBehavior(b_Trigger_AmmunitionDepleted)function Trigger_OnExactOneQuestIsWon(...)
return b_Trigger_OnExactOneQuestIsWon:new(...)end
b_Trigger_OnExactOneQuestIsWon={Name="Trigger_OnExactOneQuestIsWon",Description={en="Trigger: if one of two given quests has been finished successfully, but NOT both.",de="Ausloeser: wenn eine von zwei angegebenen Quests (aber NICHT beide) erfolgreich abgeschlossen wurde."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function b_Trigger_OnExactOneQuestIsWon:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnExactOneQuestIsWon:AddParameter(tY,l1YAdT2c)self.QuestTable={}if(tY==0)then
self.Quest1=l1YAdT2c elseif(tY==1)then self.Quest2=l1YAdT2c end end
function b_Trigger_OnExactOneQuestIsWon:CustomFunction(A1A)
local PMB1UGv=Quests[GetQuestID(self.Quest1)]local TicLenZ=Quests[GetQuestID(self.Quest2)]
if
TicLenZ and PMB1UGv then
local Xc=(PMB1UGv.State==QuestState.Over and
PMB1UGv.Result==QuestResult.Success)
local onx=(TicLenZ.State==QuestState.Over and
TicLenZ.Result==QuestResult.Success)
if(Xc and not onx)or(not Xc and onx)then return true end end;return false end
function b_Trigger_OnExactOneQuestIsWon:DEBUG(z)
if self.Quest1 ==self.Quest2 then
dbg(z.Identifier..": "..
self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
dbg(z.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
dbg(z.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Trigger_OnExactOneQuestIsWon)function Trigger_OnExactOneQuestIsLost(...)
return b_Trigger_OnExactOneQuestIsLost:new(...)end
b_Trigger_OnExactOneQuestIsLost={Name="Trigger_OnExactOneQuestIsLost",Description={en="Trigger: If one of two given quests has been lost, but NOT both.",de="Ausloeser: Wenn einer von zwei angegebenen Quests (aber NICHT beide) fehlschlägt."},Parameter={{ParameterType.QuestName,en="Quest Name 1",de="Questname 1"},{ParameterType.QuestName,en="Quest Name 2",de="Questname 2"}}}
function b_Trigger_OnExactOneQuestIsLost:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_OnExactOneQuestIsLost:AddParameter(hHo,fgqM6D)self.QuestTable={}if(hHo==0)then
self.Quest1=fgqM6D elseif(hHo==1)then self.Quest2=fgqM6D end end
function b_Trigger_OnExactOneQuestIsLost:CustomFunction(KXz5)
local IxVqKpu=Quests[GetQuestID(self.Quest1)]local B0cg08r_=Quests[GetQuestID(self.Quest2)]
if
B0cg08r_ and IxVqKpu then
local GRkE=(IxVqKpu.State==QuestState.Over and
IxVqKpu.Result==QuestResult.Failure)
local _MI=(B0cg08r_.State==QuestState.Over and
B0cg08r_.Result==QuestResult.Failure)
if(GRkE and not _MI)or(not GRkE and _MI)then return true end end;return false end
function b_Trigger_OnExactOneQuestIsLost:DEBUG(TITR)
if self.Quest1 ==self.Quest2 then
dbg(TITR.Identifier..": "..
self.Name..": Both quests are identical!")return true elseif not IsValidQuest(self.Quest1)then
dbg(TITR.Identifier..": "..
self.Name..": Quest '"..
self.Quest1 .."' does not exist!")return true elseif not IsValidQuest(self.Quest2)then
dbg(TITR.Identifier..": "..
self.Name..": Quest '"..
self.Quest2 .."' does not exist!")return true end;return false end
Core:RegisterBehavior(b_Trigger_OnExactOneQuestIsLost)BundleSymfoniaBehaviors={Global={},Local={}}
function BundleSymfoniaBehaviors.Global:Install()
GameCallback_OnThiefDeliverEarnings_Orig_QSB_SymfoniaBehaviors=GameCallback_OnThiefDeliverEarnings
GameCallback_OnThiefDeliverEarnings=function(i_aIFe,YFJRo6,V3EcTFrW,z)
GameCallback_OnThiefDeliverEarnings_Orig_QSB_SymfoniaBehaviors(i_aIFe,YFJRo6,V3EcTFrW,z)
for JbXZu2D=1,Quests[0]do
if Quests[JbXZu2D]and
Quests[JbXZu2D].State==QuestState.Active then
for drq=1,Quests[JbXZu2D].Objectives[0]do
if
Quests[JbXZu2D].Objectives[drq].Type==Objective.Custom2 then
if
Quests[JbXZu2D].Objectives[drq].Data[1].Name=="Goal_StealBuilding"then local ezkF
for dlHohKjZ=1,#
Quests[JbXZu2D].Objectives[drq].Data[1].RobberList do
local QI=Quests[JbXZu2D].Objectives[drq].Data[1].RobberList[dlHohKjZ]if
QI[1]==
GetID(Quests[JbXZu2D].Objectives[drq].Data[1].Building)and QI[2]==YFJRo6 then ezkF=true;break end end;if ezkF then
Quests[JbXZu2D].Objectives[drq].Data[1].SuccessfullyStohlen=true end elseif
Quests[JbXZu2D].Objectives[drq].Data[1].Name=="Goal_StealGold"then
local fI=Quests[JbXZu2D].Objectives[drq].Data[1]local In=Logic.EntityGetPlayer(V3EcTFrW)if fI.Target~=-1 and
fI.Target~=In then return end
Quests[JbXZu2D].Objectives[drq].Data[1].StohlenGold=
Quests[JbXZu2D].Objectives[drq].Data[1].StohlenGold+z
if fI.Printout then local u=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
local ygfhj={de="Talern gestohlen",en="gold stolen"}local fN=fI.StohlenGold;local ws8=fI.Amount
API.Note(string.format("%d/%d %s",fN,ws8,ygfhj[u]))end end end end end end end
GameCallback_OnThiefStealBuilding_Orig_QSB_SymfoniaBehaviors=GameCallback_OnThiefStealBuilding
GameCallback_OnThiefStealBuilding=function(yDc8,d3g,vZH,RWqs)
GameCallback_OnThiefStealBuilding_Orig_QSB_SymfoniaBehaviors(yDc8,d3g,vZH,RWqs)
for tn=1,Quests[0]do
if
Quests[tn]and Quests[tn].State==QuestState.Active then
for FKyVcS=1,Quests[tn].Objectives[0]do
if
Quests[tn].Objectives[FKyVcS].Type==Objective.Custom2 then
if
Quests[tn].Objectives[FKyVcS].Data[1].Name=="Goal_SpyBuilding"then
if

GetID(Quests[tn].Objectives[FKyVcS].Data[1].Building)==vZH and Quests[tn].ReceivingPlayer==d3g then
Quests[tn].Objectives[FKyVcS].Data[1].Infiltrated=true;if
Quests[tn].Objectives[FKyVcS].Data[1].Delete then DestroyEntity(yDc8)end end elseif
Quests[tn].Objectives[FKyVcS].Data[1].Name=="Goal_StealBuilding"then local z;local NfSeV=
Logic.IsEntityInCategory(vZH,EntityCategories.Cathedrals)==1;local HtbHbcu=
Logic.GetEntityType(vZH)==Entities.B_StoreHouse
if HtbHbcu or
NfSeV then
Quests[tn].Objectives[FKyVcS].Data[1].SuccessfullyStohlen=true else
for MDLzj7=1,#
Quests[tn].Objectives[FKyVcS].Data[1].RobberList do
local RNIZJ=Quests[tn].Objectives[FKyVcS].Data[1].RobberList[MDLzj7]
if RNIZJ[1]==vZH and RNIZJ[2]==yDc8 then z=true;break end end end;if not z then
table.insert(Quests[tn].Objectives[FKyVcS].Data[1].RobberList,{vZH,yDc8})end end end end end end end
QuestTemplate.IsObjectiveCompleted_Orig_QSB_SymfoniaBehaviors=QuestTemplate.IsObjectiveCompleted
QuestTemplate.IsObjectiveCompleted=function(ma,X_)local E_fkS=X_.Type;local iv18CGzs=X_.Data;if X_.Completed~=nil then return
X_.Completed end
if E_fkS==Objective.Distance then
local TpEB=GetID(iv18CGzs[1])local x=GetID(iv18CGzs[2])
iv18CGzs[3]=iv18CGzs[3]or 2500
if not
(Logic.IsEntityDestroyed(TpEB)or Logic.IsEntityDestroyed(x))then
if Logic.GetDistanceBetweenEntities(TpEB,x)<=
iv18CGzs[3]then DestroyQuestMarker(x)X_.Completed=true end else DestroyQuestMarker(x)X_.Completed=false end else
return ma:IsObjectiveCompleted_Orig_QSB_SymfoniaBehaviors(X_)end end
function QuestTemplate:RemoveQuestMarkers()
for yF1U=1,self.Objectives[0]do
if
self.Objectives[yF1U].Type==Objective.Distance then if
self.Objectives[yF1U].Data[4]then
DestroyQuestMarker(self.Objectives[yF1U].Data[2])end end end end
function QuestTemplate:ShowQuestMarkers()
for JE6a4s=1,self.Objectives[0]do
if
self.Objectives[JE6a4s].Type==Objective.Distance then if
self.Objectives[JE6a4s].Data[4]then
ShowQuestMarker(self.Objectives[JE6a4s].Data[2])end end end end
function ShowQuestMarker(sloRQ)local mJ2=GetID(sloRQ)
local P,Ge=Logic.GetEntityPosition(mJ2)local tYF=EGL_Effects.E_Questmarker_low;if Logic.IsBuilding(mJ2)==1 then
tYF=EGL_Effects.E_Questmarker end
Questmarkers[mJ2]=Logic.CreateEffect(tYF,P,Ge,0)end
function DestroyQuestMarker(jzn73)local vQTwJ6V1=GetID(jzn73)
if Questmarkers[vQTwJ6V1]~=nil then
Logic.DestroyEffect(Questmarkers[vQTwJ6V1])Questmarkers[vQTwJ6V1]=nil end end end;function BundleSymfoniaBehaviors.Local:Install()end
Core:RegisterBundle("BundleSymfoniaBehaviors")BundleTimeLine={}API=API or{}QSB=QSB or{}function API.TimeLineStart(Knf7U)return
BundleTimeLine.Shared.TimeLine:Start(Knf7U)end;function API.TimeLineRestart(I0)return
BundleTimeLine.Shared.TimeLine:Restart(I0)end;function API.TimeLineIsRunning(jFyAt)return
BundleTimeLine.Shared.TimeLine:IsRunning(jFyAt)end;function API.TimeLineYield(LyJxC)return
BundleTimeLine.Shared.TimeLine:Yield(LyJxC)end;function API.TimeLineResume(E)return
BundleTimeLine.Shared.TimeLine:Resume(E)end
BundleTimeLine={Global={Data={}},Local={Data={}},Shared={TimeLine={Data={TimeLineUniqueJobID=1,TimeLineJobs={}}}}}
function BundleTimeLine.Global:Install()
QSB.TimeLine=BundleTimeLine.Shared.TimeLine;TimeLine=QSB.TimeLine end
function BundleTimeLine.Local:Install()
QSB.TimeLine=BundleTimeLine.Shared.TimeLine;TimeLine=QSB.TimeLine end
function BundleTimeLine.Shared.TimeLine:Start(vnC8kIGX)
local dnKfz=self.Data.TimeLineUniqueJobID;self.Data.TimeLineUniqueJobID=dnKfz+1;vnC8kIGX.Running=true
vnC8kIGX.StartTime=Logic.GetTime()vnC8kIGX.Iterator=1;local kDt=0;for QLp=1,#vnC8kIGX,1 do
if vnC8kIGX[QLp].Time<kDt then vnC8kIGX[QLp].Time=
kDt+1;kDt=vnC8kIGX[QLp].Time end end
self.Data.TimeLineJobs[dnKfz]=vnC8kIGX
if not self.Data.ControlerID then
local IXNl=StartSimpleJobEx(BundleTimeLine.Shared.TimeLine.TimeLineControler)self.Data.ControlerID=IXNl end;return dnKfz end
function BundleTimeLine.Shared.TimeLine:Restart(oqPG)if not
self.Data.TimeLineJobs[oqPG]then return end
self.Data.TimeLineJobs[oqPG].Running=true
self.Data.TimeLineJobs[oqPG].StartTime=Logic.GetTime()self.Data.TimeLineJobs[oqPG].Iterator=1 end
function BundleTimeLine.Shared.TimeLine:IsRunning(Pa)if
self.Data.TimeLineJobs[Pa]then
return self.Data.TimeLineJobs[Pa].Running==true end;return false end
function BundleTimeLine.Shared.TimeLine:Yield(j37n1ZA)if not
self.Data.TimeLineJobs[j37n1ZA]then return end
self.Data.TimeLineJobs[j37n1ZA].YieldTime=Logic.GetTime()
self.Data.TimeLineJobs[j37n1ZA].Running=false end
function BundleTimeLine.Shared.TimeLine:Resume(aLxQ)if not
self.Data.TimeLineJobs[aLxQ]then return end
if
self.Data.TimeLineJobs[aLxQ].YieldTime then
local GW=self.Data.TimeLineJobs[aLxQ].StartTime
local AzhdvccS=Logic.GetTime()-self.Data.TimeLineJobs[aLxQ].YieldTime
self.Data.TimeLineJobs[aLxQ].StartTime=GW+AzhdvccS;self.Data.TimeLineJobs[aLxQ].YieldTime=nil end;self.Data.TimeLineJobs[aLxQ].Running=true end
function BundleTimeLine.Shared.TimeLine.TimeLineControler()
for J,PYFFxAp in
pairs(BundleTimeLine.Shared.TimeLine.Data.TimeLineJobs)do if PYFFxAp.Iterator>#PYFFxAp then
BundleTimeLine.Shared.TimeLine.Data.TimeLineJobs[J].Running=false end
if PYFFxAp.Running then
if(
PYFFxAp[PYFFxAp.Iterator].Time+PYFFxAp.StartTime)<=
Logic.GetTime()then
PYFFxAp[PYFFxAp.Iterator].Action(unpack(PYFFxAp[PYFFxAp.Iterator]))BundleTimeLine.Shared.TimeLine.Data.TimeLineJobs[J].Iterator=
PYFFxAp.Iterator+1 end end end end;Core:RegisterBundle("BundleTimeLine")
BundleTravelingSalesman={}API=API or{}QSB=QSB or{}QSB.TravelingSalesman={Harbors={}}
function API.TravelingSalesmanActivate(i,AP1UcfB,e,H4,CMIGYkL8,n9FOtM)if
GUI then
API.Log("Can not execute API.TravelingSalesmanActivate in local script!")return end;return
BundleTravelingSalesman.Global:TravelingSalesman_Create(i,AP1UcfB,CMIGYkL8,e,H4,n9FOtM)end;ActivateTravelingSalesman=API.TravelingSalesmanActivate
function API.TravelingSalesmanDeactivate(K)if GUI then
API.Bridge(
"API.TravelingSalesmanDeactivate("..K..")")return end;return
BundleTravelingSalesman.Global:TravelingSalesman_Disband(K)end;DeactivateTravelingSalesman=API.TravelingSalesmanDeactivate
function API.TravelingSalesmanDiplomacyOverride(EeAZn,aCKog)if
GUI then
API.Bridge("API.TravelingSalesmanDiplomacyOverride("..
EeAZn..", "..tostring(aCKog)..")")return end;return
BundleTravelingSalesman.Global:TravelingSalesman_AlterDiplomacyFlag(EeAZn,aCKog)end;TravelingSalesmanDiplomacyOverride=API.TravelingSalesmanDiplomacyOverride
function API.TravelingSalesmanRotationMode(c,OWrvY)if
GUI then
API.Bridge("API.TravelingSalesmanRotationMode("..
c..", "..tostring(OWrvY)..")")return end;if not
QSB.TravelingSalesman.Harbors[c]then return end;QSB.TravelingSalesman.Harbors[c].RotationMode=
OWrvY==true end;TravelingSalesmanRotationMode=API.TravelingSalesmanRotationMode
BundleTravelingSalesman={Global={Data={}}}function BundleTravelingSalesman.Global:Install()
TravelingSalesman_Control=BundleTravelingSalesman.Global.TravelingSalesman_Control end
function BundleTravelingSalesman.Global:TravelingSalesman_GetHumanPlayer()
local lp2=1;for k=1,8 do
if Logic.PlayerGetIsHumanFlag(1)==true then lp2=k;break end end;return lp2 end
function BundleTravelingSalesman.Global:TravelingSalesman_Create(sEjUvkV,pnOWD9,iRm2,J61iBvjC,_,X79LkbfD)
assert(type(sEjUvkV)=="number")assert(type(pnOWD9)=="table")iRm2=iRm2 or
{{3,5},{8,10}}
assert(type(iRm2)=="table")assert(type(J61iBvjC)=="table")if not _ then _={}
for JNRj6X=#J61iBvjC,1,
-1 do _[#J61iBvjC+1-JNRj6X]=J61iBvjC[JNRj6X]end end
if not
QSB.TravelingSalesman.Harbors[sEjUvkV]then
QSB.TravelingSalesman.Harbors[sEjUvkV]={}
QSB.TravelingSalesman.Harbors[sEjUvkV].Waypoints=J61iBvjC
QSB.TravelingSalesman.Harbors[sEjUvkV].Reversed=_
QSB.TravelingSalesman.Harbors[sEjUvkV].SpawnPos=J61iBvjC[1]
QSB.TravelingSalesman.Harbors[sEjUvkV].Destination=_[1]
QSB.TravelingSalesman.Harbors[sEjUvkV].Appearance=iRm2
QSB.TravelingSalesman.Harbors[sEjUvkV].Status=0
QSB.TravelingSalesman.Harbors[sEjUvkV].Offer=pnOWD9
QSB.TravelingSalesman.Harbors[sEjUvkV].LastOffer=0
QSB.TravelingSalesman.Harbors[sEjUvkV].AlterDiplomacy=true;QSB.TravelingSalesman.Harbors[sEjUvkV].RotationMode=
X79LkbfD==true end;math.randomseed(Logic.GetTimeMs())if not
QSB.TravelingSalesman.JobID then
QSB.TravelingSalesman.JobID=StartSimpleJob("TravelingSalesman_Control")end end
function BundleTravelingSalesman.Global:TravelingSalesman_Disband(ldz480)
assert(type(ldz480)=="number")QSB.TravelingSalesman.Harbors[ldz480]=nil
Logic.RemoveAllOffers(Logic.GetStoreHouse(ldz480))
DestroyEntity("TravelingSalesmanShip_Player"..ldz480)end
function BundleTravelingSalesman.Global:TravelingSalesman_AlterDiplomacyFlag(rE,f7eR2T)
assert(type(rE)=="number")
assert(QSB.TravelingSalesman.Harbors[rE])
QSB.TravelingSalesman.Harbors[rE].AlterDiplomacy=f7eR2T==true end
function BundleTravelingSalesman.Global:TravelingSalesman_NextOffer(l)local XZ3A
if
QSB.TravelingSalesman.Harbors[l].RotationMode then QSB.TravelingSalesman.Harbors[l].LastOffer=
QSB.TravelingSalesman.Harbors[l].LastOffer+1
local Czs0f=QSB.TravelingSalesman.Harbors[l].LastOffer;if Czs0f>
#QSB.TravelingSalesman.Harbors[l].Offer then
QSB.TravelingSalesman.Harbors[l].LastOffer=1;Czs0f=1 end
XZ3A=QSB.TravelingSalesman.Harbors[l].Offer[Czs0f]else local aMvb=1
if
#QSB.TravelingSalesman.Harbors[l].Offer>1 then repeat
aMvb=math.random(1,#
QSB.TravelingSalesman.Harbors[l].Offer)until
(aMvb~=QSB.TravelingSalesman.Harbors[l].LastOffer)end
QSB.TravelingSalesman.Harbors[l].LastOffer=aMvb
XZ3A=QSB.TravelingSalesman.Harbors[l].Offer[aMvb]end;return XZ3A end
function BundleTravelingSalesman.Global:TravelingSalesman_DisplayMessage(_QG)
if
((IsBriefingActive and not
IsBriefingActive())or true)then
local CWG=Quests[GetQuestID("TravelingSalesman_Info_P".._QG)]if CWG then
API.RestartQuest("TravelingSalesman_Info_P".._QG,true)CWG:SetMsgKeyOverride()CWG:SetIconOverride()
CWG:Trigger()return end
local z1q=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
local YkD6SuyP={de="Ein Schiff hat angelegt. Es bringt Güter von weit her.",en="A ship is at the pier. It deliver goods from far away."}
QuestTemplate:New("TravelingSalesman_Info_P".._QG,_QG,self:TravelingSalesman_GetHumanPlayer(),{{Objective.Dummy}},{{Triggers.Time,0}},0,
nil,nil,nil,nil,false,true,nil,nil,YkD6SuyP[z1q],nil)end end
function BundleTravelingSalesman.Global:TravelingSalesman_AddOffer(GW3xWh)
MerchantSystem.TradeBlackList[GW3xWh]={}MerchantSystem.TradeBlackList[GW3xWh][0]=#
MerchantSystem.TradeBlackList[3]
local eA_ohY=Logic.GetStoreHouse(GW3xWh)local b5p2AMKP=self:TravelingSalesman_NextOffer(GW3xWh)
Logic.RemoveAllOffers(eA_ohY)
if#b5p2AMKP>0 then
for m=1,#b5p2AMKP,1 do local Xve=b5p2AMKP[m][1]local Hk0hzj=false;for Mfs,JqnndWc in
pairs(Goods)do if Mfs==Xve then Hk0hzj=true end end
if Hk0hzj then
local l5T8J5g1=b5p2AMKP[m][2]AddOffer(eA_ohY,l5T8J5g1,Goods[Xve],9999)else
if
Logic.IsEntityTypeInCategory(Entities[Xve],EntityCategories.Military)==0 then
AddEntertainerOffer(eA_ohY,Entities[Xve])else local RhLeG=b5p2AMKP[m][2]
AddMercenaryOffer(eA_ohY,RhLeG,Entities[Xve],9999)end end end end
if QSB.TravelingSalesman.Harbors[GW3xWh].AlterDiplomacy then
SetDiplomacyState(self:TravelingSalesman_GetHumanPlayer(),GW3xWh,DiplomacyStates.TradeContact)end
ActivateMerchantPermanentlyForPlayer(Logic.GetStoreHouse(GW3xWh),self:TravelingSalesman_GetHumanPlayer())self:TravelingSalesman_DisplayMessage(GW3xWh)end
function BundleTravelingSalesman.Global.TravelingSalesman_Control()
for tOSI20,n in
pairs(QSB.TravelingSalesman.Harbors)do
if QSB.TravelingSalesman.Harbors[tOSI20]~=nil then
if n.Status==
0 then local mZcPQEV=Logic.GetCurrentMonth()local O_oVTYL=false;for PGzKhtPH=1,#n.Appearance,1 do
if
mZcPQEV==n.Appearance[PGzKhtPH][1]then O_oVTYL=true end end
if O_oVTYL then
local wI3DS0Kh=Logic.GetEntityOrientation(GetID(n.SpawnPos))
local CwTDNbR=CreateEntity(0,Entities.D_X_TradeShip,GetPosition(n.SpawnPos),"TravelingSalesmanShip_Player"..tOSI20,wI3DS0Kh)
Path:new(CwTDNbR,n.Waypoints,nil,nil,nil,nil,true,nil,nil,300)n.Status=1 end elseif n.Status==1 then
if
IsNear("TravelingSalesmanShip_Player"..tOSI20,n.Destination,400)then
BundleTravelingSalesman.Global:TravelingSalesman_AddOffer(tOSI20)n.Status=2 end elseif n.Status==2 then local A=Logic.GetCurrentMonth()local JfSij6_=false
for Lr=1,#n.Appearance,1
do if A==n.Appearance[Lr][2]then JfSij6_=true end end
if JfSij6_ then
if
QSB.TravelingSalesman.Harbors[tOSI20].AlterDiplomacy then
SetDiplomacyState(BundleTravelingSalesman.Global:TravelingSalesman_GetHumanPlayer(),tOSI20,DiplomacyStates.EstablishedContact)end
Path:new(GetID("TravelingSalesmanShip_Player"..tOSI20),n.Reversed,nil,nil,
nil,nil,true,nil,nil,300)
Logic.RemoveAllOffers(Logic.GetStoreHouse(tOSI20))n.Status=3 end elseif n.Status==3 then
if
IsNear("TravelingSalesmanShip_Player"..tOSI20,n.SpawnPos,400)then
DestroyEntity("TravelingSalesmanShip_Player"..tOSI20)n.Status=0 end end end end end;Core:RegisterBundle("BundleTravelingSalesman")
BundleBuildingButtons={}API=API or{}QSB=QSB or{}
function API.ActivateSingleStop()if not GUI then
API.Bridge("API.ActivateSingleStop()")return end
BundleBuildingButtons.Local:AddOptionalButton(2,BundleBuildingButtons.Local.ButtonDefaultSingleStop_Action,BundleBuildingButtons.Local.ButtonDefaultSingleStop_Tooltip,BundleBuildingButtons.Local.ButtonDefaultSingleStop_Update)end;ActivateSingleStop=API.ActivateSingleStop
function API.DeactivateSingleStop()if not GUI then
API.Bridge("API.DeactivateSingleStop()")return end
BundleBuildingButtons.Local:DeleteOptionalButton(2)end;DeactivateSingleStop=API.DeactivateSingleStop;function API.ActivateDowngrade()if not GUI then
API.Bridge("API.ActivateDowngrade()")return end
BundleBuildingButtons.Local.Data.Downgrade=true end
ActivateDowngrade=API.ActivateDowngrade
function API.DeactivateDowngrade()if not GUI then
API.Bridge("API.DeactivateDowngrade()")return end
BundleBuildingButtons.Local.Data.Downgrade=false end;DeactivateDowngrade=API.DeactivateDowngrade
function API.UseBreedSheeps(NXu695)if not GUI then
API.Bridge(
"API.UseBreedSheeps("..tostring(NXu695)..")")return end;BundleBuildingButtons.Local.Data.BreedSheeps=
NXu695 ==true
if NXu695 ==true then
local lzWnF=MerchantSystem.BasePricesOrigBundleBuildingButtons[Goods.G_Sheep]MerchantSystem.BasePrices[Goods.G_Sheep]=lzWnF
API.Bridge(
"MerchantSystem.BasePrices[Goods.G_Sheep] = "..lzWnF)else
local sNe6_x=BundleBuildingButtons.Local.Data.SheepMoneyCost;MerchantSystem.BasePrices[Goods.G_Sheep]=sNe6_x
API.Bridge(
"MerchantSystem.BasePrices[Goods.G_Sheep] = "..sNe6_x)end end;UseBreedSheeps=API.UseBreedSheeps
function API.UseBreedCattle(fBLoB6JH)if not GUI then
API.Bridge("API.UseBreedCattle("..
tostring(fBLoB6JH)..")")return end;BundleBuildingButtons.Local.Data.BreedCattle=
fBLoB6JH==true
if fBLoB6JH==true then
local z6gv=MerchantSystem.BasePricesOrigBundleBuildingButtons[Goods.G_Cow]MerchantSystem.BasePrices[Goods.G_Cow]=z6gv
API.Bridge(
"MerchantSystem.BasePrices[Goods.G_Cow] = "..z6gv)else
local ZZ93rHc0=BundleBuildingButtons.Local.Data.CattleMoneyCost;MerchantSystem.BasePrices[Goods.G_Cow]=ZZ93rHc0
API.Bridge(
"MerchantSystem.BasePrices[Goods.G_Cow] = "..ZZ93rHc0)end end;UseBreedCattle=API.UseBreedCattle
function API.SetSheepGrainCost(j_V)
if not GUI then API.Bridge("API.SetSheepGrainCost("..
j_V..")")return end
BundleBuildingButtons.Local.Data.SheepCosts=j_V end;SetSheepGrainCost=API.SetSheepGrainCost
function API.SetCattleGrainCost(I_)
if not GUI then API.Bridge(
"API.SetCattleGrainCost("..I_..")")return end
BundleBuildingButtons.Local.Data.CattleCosts=I_ end;SetCattleGrainCost=API.SetCattleGrainCost
function API.SetSheepNeeded(yPn)
if not GUI then API.Bridge("API.SetSheepNeeded("..
yPn..")")return end;if type(yPn)~="number"or yPn<0 or yPn>5 then
API.Fatal("API.SetSheepNeeded: Needed amount is invalid!")end
BundleBuildingButtons.Local.Data.SheepNeeded=yPn end;SetSheepNeeded=API.SetSheepNeeded
function API.SetCattleNeeded(LsT)if not GUI then
API.Bridge("API.SetCattleNeeded("..LsT..")")return end;if
type(LsT)~="number"or LsT<0 or LsT>5 then
API.Fatal("API.SetCattleNeeded: Needed amount is invalid!")end
BundleBuildingButtons.Local.Data.CattleNeeded=LsT end;SetCattleNeeded=API.SetCattleNeeded
function API.AddCustomBuildingButton(E,dOD2G,jhOfPSgm,eri)
if not GUI then
API.Bridge(
"API.AddCustomBuildingButton("..
tostring(E)..","..
tostring(dOD2G)..","..tostring(jhOfPSgm)..
","..tostring(eri)..",)")return end;if(type(E)~="number"or(E<1 or E>2))then
API.Fatal("API.AddCustomBuildingButton: Index must be 1 or 2!")return end
if
(
type(dOD2G)~="function"or type(jhOfPSgm)~="function"or
type(eri)~="function")then
API.Fatal("API.AddCustomBuildingButton: Action, tooltip and update must be functions!")return end;return
BundleBuildingButtons.Local:AddOptionalButton(E,dOD2G,jhOfPSgm,eri)end;AddBuildingButton=API.AddCustomBuildingButton
function API.RemoveCustomBuildingButton(uaTR)if not GUI then
API.Fatal(
"API.RemoveCustomBuildingButton("..tostring(uaTR)..")")return end;if(type(uaTR)~="number"or(
uaTR<1 or uaTR>2))then
API.Fatal("API.RemoveCustomBuildingButton: Index must be 1 or 2!")return end;return
BundleBuildingButtons.Local:DeleteOptionalButton(uaTR)end;DeleteBuildingButton=API.RemoveCustomBuildingButton
BundleBuildingButtons={Global={Data={}},Local={Data={OptionalButton1={UseButton=false},OptionalButton2={UseButton=false},StoppedBuildings={},Downgrade=true,BreedCattle=true,CattleCosts=10,CattleNeeded=3,CattleKnightTitle=0,CattleMoneyCost=300,BreedSheeps=true,SheepCosts=10,SheepNeeded=3,SheepKnightTitle=0,SheepMoneyCost=300},Description={Downgrade={Title={de="Rückbau",en="Downgrade"},Text={de="- Reißt eine Stufe des Geb?udes ein {cr}- Der überschüssige Arbeiter wird entlassen",en="- Destroy one level of this building {cr}- The surplus worker will be dismissed"},Disabled={de="Kann nicht zurückgebaut werden!",en="Can not be downgraded yet!"}},BuyCattle={Title={de="Nutztier kaufen",en="Buy Farm animal"},Text={de="- Kauft ein Nutztier {cr}- Nutztiere produzieren Rohstoffe",en="- Buy a farm animal {cr}- Farm animals produce resources"},Disabled={de="Kauf ist nicht möglich!",en="Buy not possible!"}},SingleStop={Title={de="Arbeit anhalten/aufnehmen",en="Start/Stop Work"},Text={de="- Startet oder stoppe die Arbeit in diesem Betrieb",en="- Continue or stop work for this building"}}}}}function BundleBuildingButtons.Global:Install()end
function BundleBuildingButtons.Local:Install()
MerchantSystem.BasePricesOrigBundleBuildingButtons={}
MerchantSystem.BasePricesOrigBundleBuildingButtons[Goods.G_Sheep]=MerchantSystem.BasePrices[Goods.G_Sheep]
MerchantSystem.BasePricesOrigBundleBuildingButtons[Goods.G_Cow]=MerchantSystem.BasePrices[Goods.G_Cow]
MerchantSystem.BasePrices[Goods.G_Sheep]=BundleBuildingButtons.Local.Data.SheepMoneyCost
MerchantSystem.BasePrices[Goods.G_Cow]=BundleBuildingButtons.Local.Data.CattleMoneyCost;self:OverwriteHouseMenuButtons()
self:OverwriteBuySiegeEngine()self:OverwriteToggleTrap()
self:OverwriteGateOpenClose()self:OverwriteAutoToggle()
Core:AppendFunction("GameCallback_GUI_SelectionChanged",self.OnSelectionChanged)end
function BundleBuildingButtons.Local:BuyAnimal(JDs76MG)
Sound.FXPlay2DSound("ui\\menu_click")local aDZVav=Logic.GetEntityType(JDs76MG)
if
aDZVav==Entities.B_CattlePasture then
local sRoTvf=BundleBuildingButtons.Local.Data.CattleCosts* (-1)
GUI.SendScriptCommand([[
            local pID = Logic.EntityGetPlayer(]]..
JDs76MG..
[[)
            local x, y = Logic.GetBuildingApproachPosition(]]..

JDs76MG..[[)
            Logic.CreateEntity(Entities.A_X_Cow01, x, y, 0, pID)
            AddGood(Goods.G_Grain, ]]..
sRoTvf..[[, pID)
        ]])elseif aDZVav==Entities.B_SheepPasture then local R1TLssk=
BundleBuildingButtons.Local.Data.SheepCosts* (-1)
GUI.SendScriptCommand(
[[
            local pID = Logic.EntityGetPlayer(]]..
JDs76MG..
[[)
            local x, y = Logic.GetBuildingApproachPosition(]]..JDs76MG..

[[)
            Logic.CreateEntity(Entities.A_X_Sheep01, x, y, 0, pID)
            AddGood(Goods.G_Grain, ]]..R1TLssk..[[, pID)
        ]])end end
function BundleBuildingButtons.Local:DowngradeBuilding()
Sound.FXPlay2DSound("ui\\menu_click")local H=GUI.GetSelectedEntity()GUI.DeselectEntity(H)
if
Logic.GetUpgradeLevel(H)>0 then
local cUR=math.ceil(Logic.GetEntityMaxHealth(H)/2)if Logic.GetEntityHealth(H)>=cUR then
GUI.SendScriptCommand([[Logic.HurtEntity(]]..H..[[, ]]..
cUR..[[)]])end else
local p=Logic.GetEntityMaxHealth(H)
GUI.SendScriptCommand([[Logic.HurtEntity(]]..H..[[, ]]..p..[[)]])end end
function BundleBuildingButtons.Local:AddOptionalButton(kKdY4XaA,d,sPM6lF,Qp_1)
assert(kKdY4XaA==1 or kKdY4XaA==2)
local q1YAR={XGUIEng.GetWidgetID("/InGame/Root/Normal/BuildingButtons/GateAutoToggle"),XGUIEng.GetWidgetID("/InGame/Root/Normal/BuildingButtons/GateOpenClose")}
BundleBuildingButtons.Local.Data["OptionalButton"..kKdY4XaA].WidgetID=q1YAR[kKdY4XaA]
BundleBuildingButtons.Local.Data["OptionalButton"..kKdY4XaA].UseButton=true
BundleBuildingButtons.Local.Data["OptionalButton"..kKdY4XaA].ActionFunction=d
BundleBuildingButtons.Local.Data["OptionalButton"..kKdY4XaA].TooltipFunction=sPM6lF
BundleBuildingButtons.Local.Data["OptionalButton"..kKdY4XaA].UpdateFunction=Qp_1 end
function BundleBuildingButtons.Local:DeleteOptionalButton(kg)
assert(kg==1 or kg==2)
local bijI={XGUIEng.GetWidgetID("/InGame/Root/Normal/BuildingButtons/GateAutoToggle"),XGUIEng.GetWidgetID("/InGame/Root/Normal/BuildingButtons/GateOpenClose")}
BundleBuildingButtons.Local.Data["OptionalButton"..kg].WidgetID=bijI[kg]
BundleBuildingButtons.Local.Data["OptionalButton"..kg].UseButton=false;BundleBuildingButtons.Local.Data["OptionalButton"..kg].ActionFunction=
nil
BundleBuildingButtons.Local.Data[
"OptionalButton"..kg].TooltipFunction=nil;BundleBuildingButtons.Local.Data["OptionalButton"..kg].UpdateFunction=
nil end
function BundleBuildingButtons.Local:OverwriteAutoToggle()
GUI_BuildingButtons.GateAutoToggleClicked=function()
local K=XGUIEng.GetCurrentWidgetID()local lCr41We=GUI.GetSelectedEntity()
if not
BundleBuildingButtons.Local.Data.OptionalButton1.ActionFunction then return end
BundleBuildingButtons.Local.Data.OptionalButton1.ActionFunction(K,lCr41We)end
GUI_BuildingButtons.GateAutoToggleMouseOver=function()
local NhucT=XGUIEng.GetCurrentWidgetID()local SZMbpM=GUI.GetSelectedEntity()
if not
BundleBuildingButtons.Local.Data.OptionalButton1.TooltipFunction then return end
BundleBuildingButtons.Local.Data.OptionalButton1.TooltipFunction(NhucT,SZMbpM)end
GUI_BuildingButtons.GateAutoToggleUpdate=function()
local aTkVS=XGUIEng.GetCurrentWidgetID()local eBp38EEt=GUI.GetSelectedEntity()
local U8NHKEk=Logic.GetEntityMaxHealth(eBp38EEt)local yf0=Logic.GetEntityHealth(eBp38EEt)
SetIcon(aTkVS,{8,16})
if



eBp38EEt==nil or Logic.IsBuilding(eBp38EEt)==0 or not
BundleBuildingButtons.Local.Data.OptionalButton1.UpdateFunction or not
BundleBuildingButtons.Local.Data.OptionalButton1.UseButton or Logic.IsConstructionComplete(eBp38EEt)==0 then XGUIEng.ShowWidget(aTkVS,0)return end
if


Logic.BuildingDoWorkersStrike(eBp38EEt)==true or
Logic.IsBuildingBeingUpgraded(eBp38EEt)==true or
Logic.IsBuildingBeingKnockedDown(eBp38EEt)==true or Logic.IsBurning(eBp38EEt)==true or U8NHKEk-yf0 >0 then XGUIEng.ShowWidget(aTkVS,0)return end
BundleBuildingButtons.Local.Data.OptionalButton1.UpdateFunction(aTkVS,eBp38EEt)end end
function BundleBuildingButtons.Local:OverwriteGateOpenClose()
GUI_BuildingButtons.GateOpenCloseClicked=function()
local skphQH=XGUIEng.GetCurrentWidgetID()local ioxmHxH=GUI.GetSelectedEntity()
if not
BundleBuildingButtons.Local.Data.OptionalButton2.ActionFunction then return end
BundleBuildingButtons.Local.Data.OptionalButton2.ActionFunction(skphQH,ioxmHxH)end
GUI_BuildingButtons.GateOpenCloseMouseOver=function()
local YGhYv64=XGUIEng.GetCurrentWidgetID()local i=GUI.GetSelectedEntity()
if not
BundleBuildingButtons.Local.Data.OptionalButton2.TooltipFunction then return end
BundleBuildingButtons.Local.Data.OptionalButton2.TooltipFunction(YGhYv64,i)end
GUI_BuildingButtons.GateOpenCloseUpdate=function()
local e09Nk=XGUIEng.GetCurrentWidgetID()local ifI_m2=GUI.GetSelectedEntity()
local QSX2=Logic.GetEntityMaxHealth(ifI_m2)local L1dTNDQb=Logic.GetEntityHealth(ifI_m2)
SetIcon(e09Nk,{8,16})
if



ifI_m2 ==nil or Logic.IsBuilding(ifI_m2)==0 or not
BundleBuildingButtons.Local.Data.OptionalButton2.UpdateFunction or not
BundleBuildingButtons.Local.Data.OptionalButton2.UseButton or Logic.IsConstructionComplete(ifI_m2)==0 or Logic.IsBuilding(ifI_m2)==0 then XGUIEng.ShowWidget(e09Nk,0)return end
if


Logic.BuildingDoWorkersStrike(ifI_m2)==true or
Logic.IsBuildingBeingUpgraded(ifI_m2)==true or
Logic.IsBuildingBeingKnockedDown(ifI_m2)==true or Logic.IsBurning(ifI_m2)==true or QSX2-L1dTNDQb>0 then XGUIEng.ShowWidget(e09Nk,0)return end
BundleBuildingButtons.Local.Data.OptionalButton2.UpdateFunction(e09Nk,ifI_m2)end end
function BundleBuildingButtons.Local:OverwriteToggleTrap()
GUI_BuildingButtons.TrapToggleClicked=function()
BundleBuildingButtons.Local:DowngradeBuilding()end
GUI_BuildingButtons.TrapToggleMouseOver=function()
local eMzb=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
BundleBuildingButtons.Local:TextNormal(BundleBuildingButtons.Local.Description.Downgrade.Title[eMzb],BundleBuildingButtons.Local.Description.Downgrade.Text[eMzb],BundleBuildingButtons.Local.Description.Downgrade.Disabled[eMzb])end
GUI_BuildingButtons.TrapToggleUpdate=function()
local J0KiSt=XGUIEng.GetCurrentWidgetID()local pXdVoc=GUI.GetSelectedEntity()
local xme=Logic.GetEntityName(pXdVoc)local kAbF=Logic.GetEntityType(pXdVoc)
local h=GetTerritoryUnderEntity(pXdVoc)local GtezA0=Logic.GetEntityMaxHealth(pXdVoc)
local sqZtSeO=Logic.GetEntityHealth(pXdVoc)local K4W6=Logic.GetUpgradeLevel(pXdVoc)
local R4qp7,_F71WhJ=XGUIEng.GetWidgetLocalPosition("/InGame/Root/Normal/BuildingButtons/Upgrade")SetIcon(J0KiSt,{3,15})
XGUIEng.SetWidgetLocalPosition(J0KiSt,R4qp7+64,_F71WhJ)if pXdVoc==nil or Logic.IsBuilding(pXdVoc)==0 then
XGUIEng.ShowWidget(J0KiSt,0)return end
if BundleDestructionControl then
if
Inside(xme,BundleDestructionControl.Local.Data.Entities)then XGUIEng.ShowWidget(J0KiSt,0)return end
if
Inside(kAbF,BundleDestructionControl.Local.Data.EntityTypes)then XGUIEng.ShowWidget(J0KiSt,0)return end
if
Inside(h,BundleDestructionControl.Local.Data.OnTerritory)then XGUIEng.ShowWidget(J0KiSt,0)return end
for YciJj,CZ2Wt in
pairs(BundleDestructionControl.Local.Data.EntityCategories)do if Logic.IsEntityInCategory(_BuildingID,CZ2Wt)==1 then
XGUIEng.ShowWidget(J0KiSt,0)return end end end
if


Logic.IsConstructionComplete(pXdVoc)==0 or
(
Logic.IsEntityInCategory(pXdVoc,EntityCategories.OuterRimBuilding)==0 and
Logic.IsEntityInCategory(pXdVoc,EntityCategories.CityBuilding)==0)or
not BundleBuildingButtons.Local.Data.Downgrade or K4W6 ==0 then XGUIEng.ShowWidget(J0KiSt,0)return end
if


Logic.BuildingDoWorkersStrike(pXdVoc)==true or
Logic.IsBuildingBeingUpgraded(pXdVoc)==true or
Logic.IsBuildingBeingKnockedDown(pXdVoc)==true or Logic.IsBurning(pXdVoc)==true or GtezA0-sqZtSeO>0 then XGUIEng.DisableButton(J0KiSt,1)else
XGUIEng.DisableButton(J0KiSt,0)end end end
function BundleBuildingButtons.Local:OverwriteBuySiegeEngine()
GUI_BuildingButtons.BuySiegeEngineCartMouseOver=function(rp3QaP,Anqa)
local sDak1ecL=(
Network.GetDesiredLanguage()=="de"and"de")or"en"local r=XGUIEng.GetCurrentWidgetID()
local C=GUI.GetSelectedEntity()local wM4R=Logic.GetEntityType(C)
if
wM4R~=Entities.B_SiegeEngineWorkshop and wM4R~=Entities.B_CattlePasture and wM4R~=
Entities.B_SheepPasture then return end;local sHOVr={Logic.GetUnitCost(C,rp3QaP)}
if wM4R==
Entities.B_CattlePasture then
BundleBuildingButtons.Local:TextCosts(BundleBuildingButtons.Local.Description.BuyCattle.Title[sDak1ecL],BundleBuildingButtons.Local.Description.BuyCattle.Text[sDak1ecL],BundleBuildingButtons.Local.Description.BuyCattle.Disabled[sDak1ecL],{Goods.G_Grain,BundleBuildingButtons.Local.Data.CattleCosts},false)elseif wM4R==Entities.B_SheepPasture then
BundleBuildingButtons.Local:TextCosts(BundleBuildingButtons.Local.Description.BuyCattle.Title[sDak1ecL],BundleBuildingButtons.Local.Description.BuyCattle.Text[sDak1ecL],BundleBuildingButtons.Local.Description.BuyCattle.Disabled[sDak1ecL],{Goods.G_Grain,BundleBuildingButtons.Local.Data.SheepCosts},false)else GUI_Tooltip.TooltipBuy(sHOVr,nil,nil,Anqa)end end
GUI_BuildingButtons.BuySiegeEngineCartClicked_OrigTHEA_Buildings=GUI_BuildingButtons.BuySiegeEngineCartClicked
GUI_BuildingButtons.BuySiegeEngineCartClicked=function(v4D)local KBI_GdWx=GUI.GetSelectedEntity()
local XcV=GUI.GetPlayerID()local yq_h4JT=Logic.GetEntityType(KBI_GdWx)
if
yq_h4JT==Entities.B_CattlePasture or yq_h4JT==Entities.B_SheepPasture then
BundleBuildingButtons.Local:BuyAnimal(KBI_GdWx)else
GUI_BuildingButtons.BuySiegeEngineCartClicked_OrigTHEA_Buildings(v4D)end end
GUI_BuildingButtons.BuySiegeEngineCartUpdate=function(Dde)local RIc=GUI.GetPlayerID()
local WL7T8_G=Logic.GetKnightTitle(RIc)local DN=XGUIEng.GetCurrentWidgetID()
local _neQ47D=GUI.GetSelectedEntity()local scY=Logic.GetEntityType(_neQ47D)
local H42=GetPlayerResources(Goods.G_Grain,RIc)local JLx=GetPosition(_neQ47D)
if scY==Entities.B_SiegeEngineWorkshop then
XGUIEng.ShowWidget(DN,1)
if Dde==Technologies.R_BatteringRam then SetIcon(DN,{9,5})elseif Dde==
Technologies.R_SiegeTower then SetIcon(DN,{9,6})elseif Dde==Technologies.R_Catapult then
SetIcon(DN,{9,4})end elseif scY==Entities.B_CattlePasture then
local vDPis1Y=GetPlayerEntities(RIc,Entities.B_CattlePasture)
local pEV={Logic.GetPlayerEntitiesInArea(RIc,Entities.A_X_Cow01,JLx.X,JLx.Y,800,16)}
local v1pCX6=Logic.GetNumberOfPlayerEntitiesInCategory(RIc,EntityCategories.CattlePasture)local NK=#vDPis1Y*5;SetIcon(DN,{3,16})
if
Dde==Technologies.R_Catapult then
if BundleBuildingButtons.Local.Data.BreedCattle then
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/BuyCatapultCart",1)
if v1pCX6 >=NK then XGUIEng.DisableButton(DN,1)elseif H42 <
BundleBuildingButtons.Local.Data.CattleCosts then XGUIEng.DisableButton(DN,1)elseif WL7T8_G<
BundleBuildingButtons.Local.Data.CattleKnightTitle then XGUIEng.DisableButton(DN,1)elseif

pEV[1]<BundleBuildingButtons.Local.Data.CattleNeeded then XGUIEng.DisableButton(DN,1)else
XGUIEng.DisableButton(DN,0)end end else XGUIEng.ShowWidget(DN,0)end elseif scY==Entities.B_SheepPasture then
local KNYh=GetPlayerEntities(RIc,Entities.B_SheepPasture)
local STO_Hubw={Logic.GetPlayerEntitiesInArea(RIc,Entities.A_X_Sheep01,JLx.X,JLx.Y,800,16)}table.remove(STO_Hubw,1)
local S4jSoR={Logic.GetPlayerEntitiesInArea(RIc,Entities.A_X_Sheep02,JLx.X,JLx.Y,800,16)}table.remove(S4jSoR,1)
local w=Logic.GetNumberOfPlayerEntitiesInCategory(RIc,EntityCategories.SheepPasture)local yX3j=#KNYh*5;STO_Hubw=Array_Append(STO_Hubw,S4jSoR)
SetIcon(DN,{4,1})
if Dde==Technologies.R_Catapult then
if
BundleBuildingButtons.Local.Data.BreedSheeps then
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/BuyCatapultCart",1)
if w>=yX3j then XGUIEng.DisableButton(DN,1)elseif H42 <
BundleBuildingButtons.Local.Data.SheepCosts then XGUIEng.DisableButton(DN,1)elseif

#STO_Hubw<BundleBuildingButtons.Local.Data.SheepKnightTitle then XGUIEng.DisableButton(DN,1)elseif#STO_Hubw<
BundleBuildingButtons.Local.Data.SheepNeeded then XGUIEng.DisableButton(DN,1)else
XGUIEng.DisableButton(DN,0)end end else XGUIEng.ShowWidget(DN,0)end else XGUIEng.ShowWidget(DN,0)return end
if
Logic.IsConstructionComplete(GUI.GetSelectedEntity())==0 then XGUIEng.ShowWidget(DN,0)return end
if
scY~=Entities.B_SheepPasture and scY~=Entities.B_CattlePasture then local bOwWOjQH=Logic.TechnologyGetState(RIc,Dde)if EnableRights==nil or
EnableRights==false then XGUIEng.DisableButton(DN,0)
return end;if
bOwWOjQH==TechnologyStates.Researched then XGUIEng.DisableButton(DN,0)else
XGUIEng.DisableButton(DN,1)end end end end
function BundleBuildingButtons.Local:OverwriteHouseMenuButtons()
HouseMenuStopProductionClicked_Orig_tHEA_SingleStop=HouseMenuStopProductionClicked
HouseMenuStopProductionClicked=function()
HouseMenuStopProductionClicked_Orig_tHEA_SingleStop()local d=HouseMenu.Widget.CurrentBuilding;local pM6sO5R0=Entities[d]
local TF4nyv=GUI.GetPlayerID()local lilD_Ll=GetPlayerEntities(TF4nyv,pM6sO5R0)
for Q2jN=1,#lilD_Ll,1 do
if
BundleBuildingButtons.Local.Data.StoppedBuildings[lilD_Ll[Q2jN]]~=HouseMenu.StopProductionBool then
BundleBuildingButtons.Local.Data.StoppedBuildings[lilD_Ll[Q2jN]]=HouseMenu.StopProductionBool
GUI.SetStoppedState(lilD_Ll[Q2jN],HouseMenu.StopProductionBool)end end end end
function BundleBuildingButtons.Local:HouseMenuIcon(Y1v09ha,XWU)
if type(XWU)=="table"then
if
type(XWU[3])=="string"then local t=1
if XGUIEng.IsButton(Y1v09ha)==1 then t=7 end;local i,MMHRexVY,XuJg,BHH;i=(_Coordinates[1]-1)*64;XuJg=(
_Coordinates[2]-1)*64
MMHRexVY=(_Coordinates[1])*64;BHH=(_Coordinates[2])*64
XGUIEng.SetMaterialAlpha(Y1v09ha,t,255)
XGUIEng.SetMaterialTexture(Y1v09ha,t,XWU[3].."big.png")
XGUIEng.SetMaterialUV(Y1v09ha,t,i,XuJg,MMHRexVY,BHH)else SetIcon(Y1v09ha,XWU)end else local xgg={GUI.GetScreenSize()}local ZBy9gf=330;if xgg[2]>=800 then
ZBy9gf=260 end;if xgg[2]>=1000 then ZBy9gf=210 end
XGUIEng.SetMaterialAlpha(Y1v09ha,1,255)XGUIEng.SetMaterialTexture(Y1v09ha,1,_file)
XGUIEng.SetMaterialUV(Y1v09ha,1,0,0,ZBy9gf,ZBy9gf)end end
function BundleBuildingButtons.Local:TextNormal(EN7tA2,zUI2QhxM,RjVt1)
local pQkj="/InGame/Root/Normal/TooltipNormal"local ra=XGUIEng.GetWidgetID(pQkj)
local wkRGa3D=XGUIEng.GetWidgetID(pQkj.."/FadeIn/Name")
local VNmZ70v=XGUIEng.GetWidgetID(pQkj.."/FadeIn/Text")
local hJ37cfVD=XGUIEng.GetWidgetID(pQkj.."/FadeIn/BG")local TO=XGUIEng.GetWidgetID(pQkj.."/FadeIn")
local I=XGUIEng.GetCurrentWidgetID()GUI_Tooltip.ResizeBG(hJ37cfVD,VNmZ70v)
local Z7fRnl7={hJ37cfVD}GUI_Tooltip.SetPosition(ra,Z7fRnl7,I)
GUI_Tooltip.FadeInTooltip(TO)RjVt1=RjVt1 or""local aRpd=""
if XGUIEng.IsButtonDisabled(I)==1 and
RjVt1 ~=""and zUI2QhxM~=""then aRpd=aRpd..
"{cr}{@color:255,32,32,255}"..RjVt1 end;XGUIEng.SetText(wkRGa3D,"{center}"..EN7tA2)XGUIEng.SetText(VNmZ70v,
zUI2QhxM..aRpd)
local BnDo=XGUIEng.GetTextHeight(VNmZ70v,true)local c4garR3x,NKbxmTq=XGUIEng.GetWidgetSize(VNmZ70v)
XGUIEng.SetWidgetSize(VNmZ70v,c4garR3x,BnDo)end
function BundleBuildingButtons.Local:TextCosts(nqH,MW,SF,b,et_6O)
local e="/InGame/Root/Normal/TooltipBuy"local ImNpFgb8=XGUIEng.GetWidgetID(e)
local Mag5n_n=XGUIEng.GetWidgetID(e.."/FadeIn/Name")local ihv0gF=XGUIEng.GetWidgetID(e.."/FadeIn/Text")local nWwZzgPY=XGUIEng.GetWidgetID(
e.."/FadeIn/BG")local itk0=XGUIEng.GetWidgetID(e..
"/FadeIn")
local K1=XGUIEng.GetWidgetID(e.."/Costs")local L2mc=XGUIEng.GetCurrentWidgetID()
GUI_Tooltip.ResizeBG(nWwZzgPY,ihv0gF)GUI_Tooltip.SetCosts(K1,b,et_6O)
local SETRKu={ImNpFgb8,K1,nWwZzgPY}
GUI_Tooltip.SetPosition(ImNpFgb8,SETRKu,L2mc,nil,true)
GUI_Tooltip.OrderTooltip(SETRKu,itk0,K1,L2mc,nWwZzgPY)GUI_Tooltip.FadeInTooltip(itk0)SF=SF or""local q_e=""
if

XGUIEng.IsButtonDisabled(L2mc)==1 and SF~=""and MW~=""then q_e=q_e.."{cr}{@color:255,32,32,255}"..SF end;XGUIEng.SetText(Mag5n_n,"{center}"..nqH)XGUIEng.SetText(ihv0gF,
MW..q_e)
local B6v4t=XGUIEng.GetTextHeight(ihv0gF,true)local rtQ,lqn5PVK=XGUIEng.GetWidgetSize(ihv0gF)
XGUIEng.SetWidgetSize(ihv0gF,rtQ,B6v4t)end
function BundleBuildingButtons.Local.ButtonDefaultSingleStop_Action(DBN90B,b2vH)local l=
BundleBuildingButtons.Local.Data.StoppedBuildings[b2vH]==true;GUI.SetStoppedState(b2vH,
not l)BundleBuildingButtons.Local.Data.StoppedBuildings[b2vH]=
not l end
function BundleBuildingButtons.Local.ButtonDefaultSingleStop_Tooltip(nv,I73L)
local x42X6=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
BundleBuildingButtons.Local:TextNormal(BundleBuildingButtons.Local.Description.SingleStop.Title[x42X6],BundleBuildingButtons.Local.Description.SingleStop.Text[x42X6])end
function BundleBuildingButtons.Local.ButtonDefaultSingleStop_Update(Nol,V1MjIq)
local xVX3Hs=
Logic.IsEntityInCategory(V1MjIq,EntityCategories.OuterRimBuilding)==1
local wzN=Logic.IsEntityInCategory(V1MjIq,EntityCategories.CityBuilding)==1
if xVX3Hs==false and wzN==false then XGUIEng.ShowWidget(Nol,0)end;if
BundleBuildingButtons.Local.Data.StoppedBuildings[V1MjIq]==true then SetIcon(Nol,{4,12})else
SetIcon(Nol,{4,13})end end
function BundleBuildingButtons.Local.OnSelectionChanged(orr)
local DC=GUI.GetSelectedEntity()local D=Logic.GetEntityType(DC)
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/GateAutoToggle",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/GateOpenClose",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/BuildingButtons/TrapToggle",1)end;Core:RegisterBundle("BundleBuildingButtons")
BundleEntityScriptingValues={}API=API or{}QSB=QSB or{}
function API.GetEntityScale(QV8)
if not IsExisting(QV8)then
local Bwx=(
type(QV8)=="string"and"'"..QV8 .."'")or QV8
API.Fatal("API.GetEntityScale: Target "..Bwx.." is invalid!")return-1 end;return
BundleEntityScriptingValues.Shared:GetEntitySize(QV8)end;GetScale=API.GetEntityScale
function API.GetEntityPlayer(fuI)
if not IsExisting(fuI)then
local JxLHnlG=(
type(fuI)=="string"and"'"..fuI.."'")or fuI
API.Fatal("API.GetEntityPlayer: Target "..JxLHnlG.." is invalid!")return-1 end;return
BundleEntityScriptingValues.Shared:GetPlayerID(fuI)end;GetPlayer=API.GetEntityPlayer
function API.GetMovementTarget(cfqBNa9)
if not IsExisting(cfqBNa9)then local jvCz=
(
type(cfqBNa9)=="string"and"'"..cfqBNa9 .."'")or cfqBNa9
API.Fatal(
"API.GetMovementTarget: Target "..jvCz.." is invalid!")return nil end;return
BundleEntityScriptingValues.Shared:GetMovingTargetPosition(cfqBNa9)end;GetMovingTarget=API.GetMovementTarget
function API.IsActiveNpc(e)
if not IsExisting(e)then
local oPiOwh7r=(type(e)==
"string"and"'"..e.."'")or e
API.Fatal("API.IsActiveNpc: Target "..oPiOwh7r.." is invalid!")return false end;return
BundleEntityScriptingValues.Shared:IsOnScreenInformationActive(e)end;IsNpc=API.IsActiveNpc
function API.IsEntityVisible(i)
if not IsExisting(i)then
local xvq=(type(i)=="string"and"'"..i..
"'")or i
API.Fatal("API.IsEntityVisible: Target "..xvq.." is invalid!")return false end;return
BundleEntityScriptingValues.Shared:IsEntityVisible(i)end;IsVisible=API.IsEntityVisible
function API.SetEntityScale(a3,CT)
if
GUI or not IsExisting(a3)then
local PhkTY=(type(a3)=="string"and"'"..a3 .."'")or a3
API.Fatal("API.SetEntityScale: Target "..PhkTY.." is invalid!")return end;if type(CT)~="number"then
API.Fatal("API.SetEntityScale: Scale must be a number!")return end;return
BundleEntityScriptingValues.Global:SetEntitySize(a3,CT)end;SetScale=API.SetEntityScale
function API.SetEntityPlayer(VASxcm,Kzav_qIb)
if
GUI or not IsExisting(VASxcm)then local fF8A=
(type(VASxcm)=="string"and"'"..VASxcm.."'")or VASxcm
API.Fatal(
"API.SetEntityPlayer: Target "..fF8A.." is invalid!")return end;if
type(Kzav_qIb)~="number"or Kzav_qIb<=0 or Kzav_qIb>8 then
API.Fatal("API.SetEntityPlayer: Player-ID must between 0 and 8!")return end;return
BundleEntityScriptingValues.Global:SetPlayerID(VASxcm,math.floor(Kzav_qIb))end;ChangePlayer=API.SetEntityPlayer
BundleEntityScriptingValues={Global={},Local={},Shared={}}
function BundleEntityScriptingValues.Global:SetEntitySize(XE,yKhek)local bC=GetID(XE)
Logic.SetEntityScriptingValue(bC,
-45,BundleEntityScriptingValues.Shared:Float2Int(yKhek))if Logic.IsSettler(bC)==1 then
Logic.SetSpeedFactor(bC,yKhek)end end
function BundleEntityScriptingValues.Global:SetPlayerID(n8rNUjo,imJ)
local QjsBmE7O=GetID(n8rNUjo)Logic.SetEntityScriptingValue(QjsBmE7O,-71,imJ)end
function BundleEntityScriptingValues.Shared:GetEntitySize(tLKkEU)
local qSchaN8z=GetID(tLKkEU)local M=Logic.GetEntityScriptingValue(qSchaN8z,-45)return
self:Int2Float(M)end
function BundleEntityScriptingValues.Shared:GetPlayerID(pNj8Z)
local D4MAT=GetID(pNj8Z)return Logic.GetEntityScriptingValue(D4MAT,-71)end;function BundleEntityScriptingValues.Shared:IsEntityVisible(OvVIG)
local q=GetID(OvVIG)
return Logic.GetEntityScriptingValue(q,-50)==801280 end
function BundleEntityScriptingValues.Shared:IsOnScreenInformationActive(UdkYgWc)
local ek_j1tcZ=GetID(UdkYgWc)
if Logic.IsSettler(ek_j1tcZ)==0 then return false end
return Logic.GetEntityScriptingValue(ek_j1tcZ,6)==1 end
function BundleEntityScriptingValues.Shared:GetMovingTargetPosition(Z27GZHi3)local Z95zgc={}Z95zgc.X=
self:GetValueAsFloat(Z27GZHi3,19)or 0;Z95zgc.Y=
self:GetValueAsFloat(Z27GZHi3,20)or 0;return Z95zgc end
function BundleEntityScriptingValues.Shared:GetValueAsInteger(KV7iu,OV)
local _1PosB=Logic.GetEntityScriptingValue(GetID(KV7iu),OV)return _1PosB end
function BundleEntityScriptingValues.Shared:GetValueAsFloat(J,ROgo)
local Z3D=Logic.GetEntityScriptingValue(GetID(J),ROgo)return self:Int2Float(Z3D)end
function BundleEntityScriptingValues.Shared:qmod(nMh,z9hE)return nMh-
math.floor(nMh/z9hE)*z9hE end
function BundleEntityScriptingValues.Shared:Int2Float(Krg)
if(Krg==0)then return 0 end;local IM=1;if(Krg<0)then Krg=2147483648+Krg;IM=-1 end
local E6p_LK8=self:qmod(Krg,8388608)local JWafFaRJ=(Krg-E6p_LK8)/8388608
local T=self:qmod(JWafFaRJ,256)local rWA2KhWZ=T-127;local IMPQjN=1;local L=0.5;local qgM5=4194304;for lTm=23,0,-1 do if(E6p_LK8-qgM5)>0 then IMPQjN=
IMPQjN+L;E6p_LK8=E6p_LK8-qgM5 end
qgM5=qgM5/2;L=L/2 end;return IMPQjN*
math.pow(2,rWA2KhWZ)*IM end
function BundleEntityScriptingValues.Shared:bitsInt(PLHm)local sh={}
while PLHm>0 do
rest=self:qmod(PLHm,2)table.insert(sh,1,rest)PLHm=(PLHm-rest)/2 end;table.remove(sh,1)return sh end
function BundleEntityScriptingValues.Shared:bitsFrac(JatyUzO,Ra8)
for UEUWu40=1,48 do JatyUzO=JatyUzO*2;if(
JatyUzO>=1)then table.insert(Ra8,1)JatyUzO=JatyUzO-1 else
table.insert(Ra8,0)end
if(JatyUzO==0)then return Ra8 end end;return Ra8 end
function BundleEntityScriptingValues.Shared:Float2Int(F3tuY)
if(F3tuY==0)then return 0 end;local y3uo=false;if(F3tuY<0)then y3uo=true;F3tuY=F3tuY*-1 end
local QwilI=0;local RQZzGcfq;local MaDT=0
if F3tuY>=1 then local y6zY=math.floor(F3tuY)local Y=F3tuY-y6zY
RQZzGcfq=self:bitsInt(y6zY)MaDT=table.getn(RQZzGcfq)self:bitsFrac(Y,RQZzGcfq)else
RQZzGcfq={}self:bitsFrac(F3tuY,RQZzGcfq)while(RQZzGcfq[1]==0)do
MaDT=MaDT-1;table.remove(RQZzGcfq,1)end
MaDT=MaDT-1;table.remove(RQZzGcfq,1)end;local rhTj1d2=4194304;local z=1
for oS=z,23 do local oJ=RQZzGcfq[oS]if(not oJ)then break end;if(oJ==1)then QwilI=
QwilI+rhTj1d2 end;rhTj1d2=rhTj1d2/2 end;QwilI=QwilI+ (MaDT+127)*8388608;if(y3uo)then
QwilI=QwilI-2147483648 end;return QwilI end
Core:RegisterBundle("BundleEntityScriptingValues")BundleEntitySelection={}API=API or{}QSB=QSB or{}
function API.DisableRefillTrebuchet(xWos)if not GUI then
API.Bridge(
"API.DisableRefillTrebuchet("..tostring(xWos)..")")return end
API.Bridge(
"BundleEntitySelection.Local.Data.RefillTrebuchet = "..tostring(not xWos))
BundleEntitySelection.Local.Data.RefillTrebuchet=not xWos end
function API.DisableReleaseThieves(yfBivMH)if not GUI then
API.Bridge("API.DisableReleaseThieves("..tostring(yfBivMH)..")")return end;BundleEntitySelection.Local.Data.ThiefRelease=
not yfBivMH end
function API.DisableReleaseSiegeEngines(tM)if not GUI then
API.Bridge("API.DisableReleaseSiegeEngines("..tostring(tM)..")")return end;BundleEntitySelection.Local.Data.SiegeEngineRelease=
not tM end
function API.DisableReleaseSoldiers(nh)if not GUI then
API.Bridge("API.DisableReleaseSoldiers("..tostring(nh)..")")return end;BundleEntitySelection.Local.Data.MilitaryRelease=
not nh end
function API.IsEntityInSelection(jS_C7lFG)
if IsExisting(jS_C7lFG)then local KcGY=GetID(jS_C7lFG)
local sHfW_=BundleEntitySelection.Global.Data.SelectedEntities
if GUI then sHfW_={GUI.GetSelectedEntities()}end
for TNEo=1,#sHfW_,1 do if sHfW_[TNEo]==KcGY then return true end end end;return false end;IsEntitySelected=API.IsEntityInSelection
function API.GetSelectedEntity()
local lkd1oTM=BundleEntitySelection.Global.Data.SelectedEntities[1]if GUI then lkd1oTM=GUI.GetSelectedEntity()end;return
lkd1oTM or 0 end;GetSelectedEntity=API.GetSelectedEntity
function API.GetSelectedEntities()
local cfWcw=BundleEntitySelection.Global.Data.SelectedEntities
if GUI then cfWcw={GUI.GetSelectedEntities()}end;return cfWcw end;GetSelectedEntities=API.GetSelectedEntities
BundleEntitySelection={Global={Data={RefillTrebuchet=true,AmmunitionUnderway={},TrebuchetIDToCart={},SelectedEntities={}}},Local={Data={RefillTrebuchet=true,ThiefRelease=false,SiegeEngineRelease=true,MilitaryRelease=true,Tooltips={KnightButton={Title={de="Ritter selektieren",en="Select Knight"},Text={de="- Klick selektiert den Ritter {cr}- Doppelklick springt zum Ritter{cr}- STRG halten selektiert alle Ritter",en="- Click selects the knight {cr}- Double click jumps to knight{cr}- Press CTRL to select all knights"}},BattalionButton={Title={de="Militär selektieren",en="Select Units"},Text={de="- Selektiert alle Militäreinheiten {cr}- SHIFT halten um auch Munitionswagen und Trebuchets auszuwählen",en="- Selects all military units {cr}- Press SHIFT to additionally select ammunition carts and trebuchets"}},ReleaseSoldiers={Title={de="Militär entlassen",en="Release military unit"},Text={de="- Eine Militäreinheit entlassen {cr}- Soldaten werden nacheinander entlassen",en="- Dismiss a military unit {cr}- Soldiers will be dismissed each after another"},Disabled={de="Kann nicht entlassen werden!",en="Releasing is impossible!"}},TrebuchetCart={Title={de="Trebuchetwagen",en="Trebuchet cart"},Text={de="- Kann einmalig zum Trebuchet ausgebaut werden",en="- Can uniquely be transmuted into a trebuchet"}},Trebuchet={Title={de="Trebuchet",en="Trebuchet"},Text={de="- Kann über weite Strecken Gebäude angreifen {cr}- Kann Gebäude in Brand stecken {cr}- Kann nur durch Munitionsanforderung befüllt werden {cr}- Trebuchet kann manuell zurückgeschickt werden",en="- Can perform long range attacks on buildings {cr}- Can set buildings on fire {cr}- Can only be filled by ammunition request {cr}- The trebuchet can be manually send back to the city"}},TrebuchetRefiller={Title={de="Aufladen",en="Refill"},Text={de="- Läd das Trebuchet mit Karren aus dem Lagerhaus nach {cr}- Benötigt die Differenz an Steinen {cr}- Kann jeweils nur einen Wagen zu selben Zeit senden",en="- Refill the Trebuchet with a cart from the storehouse {cr}- Stones for missing ammunition required {cr}- Only one cart at the time allowed"}}}}}}function BundleEntitySelection.Global:Install()end
function BundleEntitySelection.Global:DeactivateRefillTrebuchet(V971Awo)self.Data.RefillTrebuchet=
not V971Awo
Logic.ExecuteInLuaLocalState(
[[
        BundleEntitySelection.Local:DeactivateRefillTrebuchet(]]..tostring(V971Awo)..[[)
    ]])end
function BundleEntitySelection.Global:MilitaryDisambleTrebuchet(YQW3)
local QI2rZmm,Anw4285,HVG=Logic.EntityGetPos(YQW3)local TiL7=Logic.EntityGetPlayer(YQW3)if GameCallback_QSB_OnDisambleTrebuchet then
GameCallback_QSB_OnDisambleTrebuchet(YQW3,TiL7,QI2rZmm,Anw4285,HVG)return end
if
self.Data.AmmunitionUnderway[YQW3]then
API.Message{de="Eine Munitionslieferung ist auf dem Weg!",en="A ammunition card is on the way!"}return end
Logic.CreateEffect(EGL_Effects.E_Shockwave01,QI2rZmm,Anw4285,0)Logic.SetEntityInvulnerabilityFlag(YQW3,1)
Logic.SetEntitySelectableFlag(YQW3,0)Logic.SetVisible(YQW3,false)
local omdR7=self.Data.TrebuchetIDToCart[YQW3]
if omdR7 ~=nil then Logic.SetEntityInvulnerabilityFlag(omdR7,0)
Logic.SetEntitySelectableFlag(omdR7,1)Logic.SetVisible(omdR7,true)else
omdR7=Logic.CreateEntity(Entities.U_SiegeEngineCart,QI2rZmm,Anw4285,0,TiL7)self.Data.TrebuchetIDToCart[YQW3]=omdR7 end
Logic.DEBUG_SetSettlerPosition(omdR7,QI2rZmm,Anw4285)Logic.SetTaskList(omdR7,TaskLists.TL_NPC_IDLE)
Logic.ExecuteInLuaLocalState(
[[
        GUI.SelectEntity(]]..omdR7 ..[[)
    ]])end
function BundleEntitySelection.Global:MilitaryErectTrebuchet(Oz)
local FqaEj69D,Y6,Sl=Logic.EntityGetPos(Oz)local pWXuxn=Logic.EntityGetPlayer(Oz)if GameCallback_QSB_OnErectTrebuchet then
GameCallback_QSB_OnErectTrebuchet(Oz,pWXuxn,FqaEj69D,Y6,Sl)return end
Logic.CreateEffect(EGL_Effects.E_Shockwave01,FqaEj69D,Y6,0)Logic.SetEntityInvulnerabilityFlag(Oz,1)
Logic.SetEntitySelectableFlag(Oz,0)Logic.SetVisible(Oz,false)local otCrxF
for jQmXBU,EO0o5H in
pairs(self.Data.TrebuchetIDToCart)do if EO0o5H==Oz then otCrxF=tonumber(jQmXBU)end end
if otCrxF==nil then
otCrxF=Logic.CreateEntity(Entities.U_Trebuchet,FqaEj69D,Y6,0,pWXuxn)self.Data.TrebuchetIDToCart[otCrxF]=Oz end;Logic.SetEntityInvulnerabilityFlag(otCrxF,0)
Logic.SetEntitySelectableFlag(otCrxF,1)Logic.SetVisible(otCrxF,true)
Logic.DEBUG_SetSettlerPosition(otCrxF,FqaEj69D,Y6)
Logic.ExecuteInLuaLocalState([[
        GUI.SelectEntity(]]..otCrxF..[[)
    ]])end
function BundleEntitySelection.Global:MilitaryCallForRefiller(a9p)
local v=Logic.EntityGetPlayer(a9p)local r3IQ=Logic.GetStoreHouse(v)
local lZfWd=Logic.GetAmmunitionAmount(a9p)local S_9wu=GetPlayerResources(Goods.G_Stone,v)if
GameCallback_tHEA_OnRefillerCartCalled then
GameCallback_tHEA_OnRefillerCartCalled(a9p,v,r3IQ,lZfWd,S_9wu)return end
if
self.Data.AmmunitionUnderway[a9p]or r3IQ==0 then
API.Message{de="Eine Munitionslieferung ist auf dem Weg!",en="A ammunition card is on the way!"}return end
if lZfWd==10 or S_9wu<10-lZfWd then
API.Message{de="Nicht genug Steine oder das Trebuchet ist voll!",en="Not enough stones or the trebuchet is full!"}return end;local IMlB,VE=Logic.GetBuildingApproachPosition(r3IQ)
local w=Logic.CreateEntity(Entities.U_AmmunitionCart,IMlB,VE,0,v)
self.Data.AmmunitionUnderway[a9p]={w,10-lZfWd}Logic.SetEntityInvulnerabilityFlag(w,1)
Logic.SetEntitySelectableFlag(w,0)
AddGood(Goods.G_Stone,(10-lZfWd)* (-1),v)
StartSimpleJobEx(function(WHBYT6)
local w=self.Data.AmmunitionUnderway[a9p][1]
local kqx=self.Data.AmmunitionUnderway[a9p][2]
if not IsExisting(w)or not IsExisting(WHBYT6)then self.Data.AmmunitionUnderway[a9p]=
nil;return true end
if not Logic.IsEntityMoving(w)then
local IMlB,VE,BFXIwu=Logic.EntityGetPos(WHBYT6)Logic.MoveSettler(w,IMlB,VE)end
if IsNear(w,WHBYT6,500)then
for HDMJDfnq=1,kqx,1 do Logic.RefillAmmunitions(WHBYT6)end;DestroyEntity(w)end end,a9p)end
function BundleEntitySelection.Local:Install()
self:OverwriteSelectAllUnits()self:OverwriteSelectKnight()
self:OverwriteNamesAndDescription()self:OverwriteThiefDeliver()
self:OverwriteMilitaryDismount()self:OverwriteMultiselectIcon()
self:OverwriteMilitaryDisamble()self:OverwriteMilitaryErect()
self:OverwriteMilitaryCommands()self:OverwriteGetStringTableText()
Core:AppendFunction("GameCallback_GUI_SelectionChanged",self.OnSelectionCanged)end;function BundleEntitySelection.Local:DeactivateRefillTrebuchet(T)
self.Data.RefillTrebuchet=not T end
function BundleEntitySelection.Local.OnSelectionCanged(Igyb)
local xtIq={GUI.GetSelectedEntities()}local vevbcnP=GUI.GetPlayerID()local _M6=GUI.GetSelectedEntity()
local eZIgrsq=Logic.GetEntityType(_M6)local vGHB=API.ConvertTableToString(xtIq)
API.Bridge(
"BundleEntitySelection.Global.Data.SelectedEntities = "..vGHB)
if _M6 ~=nil then
if eZIgrsq==Entities.U_SiegeEngineCart then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/BGMilitary",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/DialogButtons",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/SiegeEngineCart",1)elseif eZIgrsq==Entities.U_Trebuchet then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/BGMilitary",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/DialogButtons",0)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military",1)
if BundleEntitySelection.Local.Data.RefillTrebuchet then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military/Attack",1)else
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military/Attack",0)end;GUI_Military.StrengthUpdate()
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/DialogButtons/SiegeEngine",1)end end end
function BundleEntitySelection.Local:OverwriteGetStringTableText()
GetStringTableText_Orig_BundleEntitySelection=XGUIEng.GetStringTableText
XGUIEng.GetStringTableText=function(lW3)local jYQGrQ=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
if
lW3 =="UI_ObjectDescription/Attack"then local Rd=GUI.GetSelectedEntity()
if Logic.GetEntityType(Rd)==
Entities.U_Trebuchet then return
BundleEntitySelection.Local.Data.Tooltips.TrebuchetRefiller.Text[jYQGrQ]end end
if lW3 =="UI_ObjectNames/Attack"then local Et48BC6=GUI.GetSelectedEntity()
if
Logic.GetEntityType(Et48BC6)==Entities.U_Trebuchet then return
BundleEntitySelection.Local.Data.Tooltips.TrebuchetRefiller.Title[jYQGrQ]end end
return GetStringTableText_Orig_BundleEntitySelection(lW3)end end
function BundleEntitySelection.Local:OverwriteMilitaryCommands()
GUI_Military.AttackClicked=function()
Sound.FXPlay2DSound("ui\\menu_click")local dtlzW={GUI.GetSelectedEntities()}
local Zngjkt=Logic.GetEntityType(dtlzW[1])
if Zngjkt==Entities.U_Trebuchet then
for JX8SNa=1,#dtlzW,1 do
Zngjkt=Logic.GetEntityType(dtlzW[JX8SNa])
if Zngjkt==Entities.U_Trebuchet then
GUI.SendScriptCommand(
[[
                        BundleEntitySelection.Global:MilitaryCallForRefiller(]]..dtlzW[JX8SNa]..[[)
                    ]])end end else GUI.ActivateExplicitAttackCommandState()end end
GUI_Military.StandGroundClicked=function()
Sound.FXPlay2DSound("ui\\menu_click")local _AeB0Ml_={GUI.GetSelectedEntities()}
for KBHfN=1,#_AeB0Ml_ do
local i=_AeB0Ml_[KBHfN]local ot2=Logic.GetEntityType(i)
GUI.SendCommandStationaryDefend(i)
if ot2 ==Entities.U_Trebuchet then
GUI.SendScriptCommand([[
                    Logic.SetTaskList(]]..i..
[[, TaskLists.TL_NPC_IDLE)
                ]])end end end
GUI_Military.StandGroundUpdate=function()
local woM="/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military/Attack"local ks_Z4ZyB={GUI.GetSelectedEntities()}
SetIcon(woM,{12,4})
if#ks_Z4ZyB==1 then local NH=ks_Z4ZyB[1]
local F8ZBmP=Logic.GetEntityType(NH)
if F8ZBmP==Entities.U_Trebuchet then if
Logic.GetAmmunitionAmount(NH)>0 then XGUIEng.ShowWidget(woM,0)else
XGUIEng.ShowWidget(woM,1)end
SetIcon(woM,{1,10})else XGUIEng.ShowWidget(woM,1)end end end end
function BundleEntitySelection.Local:OverwriteMilitaryErect()
GUI_Military.ErectClicked_Orig_BundleEntitySelection=GUI_Military.ErectClicked
GUI_Military.ErectClicked=function()
GUI_Military.ErectClicked_Orig_BundleEntitySelection()local U39GHDv7=GUI.GetPlayerID()
local jPOOiRL3={GUI.GetSelectedEntities()}
for qfG=1,#jPOOiRL3,1 do local KoS=Logic.GetEntityType(jPOOiRL3[qfG])
if KoS==
Entities.U_SiegeEngineCart then
GUI.SendScriptCommand([[
                    BundleEntitySelection.Global:MilitaryErectTrebuchet(]]..
jPOOiRL3[qfG]..[[)
                ]])end end end
GUI_Military.ErectUpdate_Orig_BundleEntitySelection=GUI_Military.ErectUpdate
GUI_Military.ErectUpdate=function()local vqax=XGUIEng.GetCurrentWidgetID()
local SKzkkCgD=GUI.GetSelectedEntity()local LdLB2=GUI.GetPlayerID()
local z=Logic.GetEntityType(SKzkkCgD)if z==Entities.U_SiegeEngineCart then
XGUIEng.DisableButton(vqax,0)SetIcon(vqax,{12,6})else
GUI_Military.ErectUpdate_Orig_BundleEntitySelection()end end
GUI_Military.ErectMouseOver_Orig_BundleEntitySelection=GUI_Military.ErectMouseOver
GUI_Military.ErectMouseOver=function()local l=GUI.GetSelectedEntity()local mnaov0
if
Logic.GetEntityType(l)==Entities.U_SiegeEngineCart then mnaov0="ErectCatapult"else
GUI_Military.ErectMouseOver_Orig_BundleEntitySelection()return end;GUI_Tooltip.TooltipNormal(mnaov0,"Erect")end end
function BundleEntitySelection.Local:OverwriteMilitaryDisamble()
GUI_Military.DisassembleClicked_Orig_BundleEntitySelection=GUI_Military.DisassembleClicked
GUI_Military.DisassembleClicked=function()
GUI_Military.DisassembleClicked_Orig_BundleEntitySelection()local mBrjs33=GUI.GetPlayerID()
local Pqjad1={GUI.GetSelectedEntities()}
for Uo=1,#Pqjad1,1 do local j=Logic.GetEntityType(Pqjad1[Uo])
if j==
Entities.U_Trebuchet then
GUI.SendScriptCommand([[
                    BundleEntitySelection.Global:MilitaryDisambleTrebuchet(]]..Pqjad1[Uo]..
[[)
                ]])end end end
GUI_Military.DisassembleUpdate_Orig_BundleEntitySelection=GUI_Military.DisassembleUpdate
GUI_Military.DisassembleUpdate=function()local F=XGUIEng.GetCurrentWidgetID()
local hf=GUI.GetPlayerID()local TlU=GUI.GetSelectedEntity()
local NQu55R=Logic.GetEntityType(TlU)if NQu55R==Entities.U_Trebuchet then XGUIEng.DisableButton(F,0)
SetIcon(F,{12,9})else
GUI_Military.DisassembleUpdate_Orig_BundleEntitySelection()end end end
function BundleEntitySelection.Local:OverwriteMultiselectIcon()
GUI_MultiSelection.IconUpdate_Orig_BundleEntitySelection=GUI_MultiSelection.IconUpdate
GUI_MultiSelection.IconUpdate=function()local t3Rb=XGUIEng.GetCurrentWidgetID()
local yTS=XGUIEng.GetWidgetsMotherID(t3Rb)local xO=XGUIEng.GetWidgetNameByID(yTS)local FUe3cof=xO+0
local OW637_=XGUIEng.GetWidgetPathByID(yTS)local zRG=OW637_.."/Health"
local Ei=g_MultiSelection.EntityList[FUe3cof]local Z4=Logic.GetEntityType(Ei)
local HR1MTEE=Logic.GetEntityHealth(Ei)local j=Logic.GetEntityMaxHealth(Ei)if
Z4 ~=Entities.U_SiegeEngineCart and Z4 ~=Entities.U_Trebuchet then
GUI_MultiSelection.IconUpdate_Orig_BundleEntitySelection()return end;if
Logic.IsEntityAlive(Ei)==false then XGUIEng.ShowWidget(yTS,0)
GUI_MultiSelection.CreateEX()return end
SetIcon(t3Rb,g_TexturePositions.Entities[Z4])HR1MTEE=math.floor(HR1MTEE/j*100)
if HR1MTEE<50 then local WRZ3=math.floor(
2*255* (HR1MTEE/100))
XGUIEng.SetMaterialColor(zRG,0,255,WRZ3,20,255)else
local lMRdB=2*255-math.floor(2*255* (HR1MTEE/100))XGUIEng.SetMaterialColor(zRG,0,lMRdB,255,20,255)end;XGUIEng.SetProgressBarValues(zRG,HR1MTEE,100)end
GUI_MultiSelection.IconMouseOver_Orig_BundleEntitySelection=GUI_MultiSelection.IconMouseOver
GUI_MultiSelection.IconMouseOver=function()
local Dy7Xk=XGUIEng.GetCurrentWidgetID()local K4E0h_=XGUIEng.GetWidgetsMotherID(Dy7Xk)
local c4bFot0j=XGUIEng.GetWidgetNameByID(K4E0h_)local fKLRcR=tonumber(c4bFot0j)
local Nd=g_MultiSelection.EntityList[fKLRcR]local X7VAP1qM=Logic.GetEntityType(Nd)
if
X7VAP1qM~=Entities.U_SiegeEngineCart and X7VAP1qM~=Entities.U_Trebuchet then
GUI_MultiSelection.IconMouseOver_Orig_BundleEntitySelection()return end;local ay=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
if X7VAP1qM==
Entities.U_SiegeEngineCart then
local jf=BundleEntitySelection.Local.Data.Tooltips.TrebuchetCart
BundleEntitySelection.Local:SetTooltip(jf.Title[ay],jf.Text[ay])elseif X7VAP1qM==Entities.U_Trebuchet then
local r=BundleEntitySelection.Local.Data.Tooltips.Trebuchet
BundleEntitySelection.Local:SetTooltip(r.Title[ay],r.Text[ay])end end end
function BundleEntitySelection.Local:OverwriteMilitaryDismount()
GUI_Military.DismountClicked_Orig_BundleEntitySelection=GUI_Military.DismountClicked
GUI_Military.DismountClicked=function()local cqVJ=GUI.GetSelectedEntity(Selected)
local bODdRt=Logic.GetEntityType(cqVJ)local vLShI=GUI.GetPlayerID()
if
Logic.GetGuardianEntityID(cqVJ)==0 and Logic.IsKnight(cqVJ)==false then
if

(





bODdRt==
Entities.U_SiegeEngineCart or bODdRt==Entities.U_MilitarySiegeTower or bODdRt==Entities.U_MilitaryCatapult or bODdRt==Entities.U_MilitaryBatteringRam or bODdRt==Entities.U_SiegeTowerCart or bODdRt==Entities.U_CatapultCart or bODdRt==Entities.U_BatteringRamCart or bODdRt==Entities.U_AmmunitionCart)and BundleEntitySelection.Local.Data.SiegeEngineRelease then Sound.FXPlay2DSound("ui\\menu_click")
GUI.SendScriptCommand(
[[DestroyEntity(]]..cqVJ..[[)]])return end
if
(Logic.IsLeader(cqVJ)==1 and
BundleEntitySelection.Local.Data.MilitaryRelease)then Sound.FXPlay2DSound("ui\\menu_click")
local Rw2dL={Logic.GetSoldiersAttachedToLeader(cqVJ)}
GUI.SendScriptCommand([[DestroyEntity(]]..Rw2dL[#Rw2dL]..[[)]])return end else
GUI_Military.DismountClicked_Orig_BundleEntitySelection()end end
GUI_Military.DismountUpdate_Orig_BundleEntitySelection=GUI_Military.DismountUpdate
GUI_Military.DismountUpdate=function()local f3=XGUIEng.GetCurrentWidgetID()
local _fT3EIme=GUI.GetSelectedEntity()local L=Logic.GetEntityType(_fT3EIme)
if
(

Logic.GetGuardianEntityID(_fT3EIme)==0 and Logic.IsKnight(_fT3EIme)==false and
Logic.IsEntityInCategory(_fT3EIme,EntityCategories.AttackableMerchant)==0)then
if Logic.IsLeader(_fT3EIme)==1 and not
BundleEntitySelection.Local.Data.MilitaryRelease then
XGUIEng.DisableButton(f3,1)elseif Logic.IsLeader(_fT3EIme)==0 then
if not
BundleEntitySelection.Local.Data.SiegeEngineRelease then XGUIEng.DisableButton(f3,1)end
if L==Entities.U_Trebuchet then XGUIEng.DisableButton(f3,1)end else SetIcon(f3,{12,1})XGUIEng.DisableButton(f3,0)end;SetIcon(f3,{14,12})else SetIcon(f3,{12,1})
GUI_Military.DismountUpdate_Orig_BundleEntitySelection()end end end
function BundleEntitySelection.Local:OverwriteThiefDeliver()
GUI_Thief.ThiefDeliverClicked_Orig_BundleEntitySelection=GUI_Thief.ThiefDeliverClicked
GUI_Thief.ThiefDeliverClicked=function()if not
BundleEntitySelection.Local.Data.ThiefRelease then
GUI_Thief.ThiefDeliverClicked_Orig_BundleEntitySelection()return end
Sound.FXPlay2DSound("ui\\menu_click")local bjfwUrkF=GUI.GetPlayerID()
local cA6Xqh6Z=GUI.GetSelectedEntity()
if cA6Xqh6Z==nil or
Logic.GetEntityType(cA6Xqh6Z)~=Entities.U_Thief then return end
GUI.SendScriptCommand([[DestroyEntity(]]..cA6Xqh6Z..[[)]])end
GUI_Thief.ThiefDeliverMouseOver_Orig_BundleEntitySelection=GUI_Thief.ThiefDeliverMouseOver
GUI_Thief.ThiefDeliverMouseOver=function()if not
BundleEntitySelection.Local.Data.ThiefRelease then
GUI_Thief.ThiefDeliverMouseOver_Orig_BundleEntitySelection()return end
local aa9V=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
BundleEntitySelection.Local:SetTooltip(BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Title[aa9V],BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Text[aa9V])end
GUI_Thief.ThiefDeliverUpdate_Orig_BundleEntitySelection=GUI_Thief.ThiefDeliverUpdate
GUI_Thief.ThiefDeliverUpdate=function()if not
BundleEntitySelection.Local.Data.ThiefRelease then
GUI_Thief.ThiefDeliverUpdate_Orig_BundleEntitySelection()return end
local r_qeRw=XGUIEng.GetCurrentWidgetID()local qgONc=GUI.GetSelectedEntity()
if qgONc==nil or
Logic.GetEntityType(qgONc)~=Entities.U_Thief then
XGUIEng.DisableButton(r_qeRw,1)else XGUIEng.DisableButton(r_qeRw,0)end;SetIcon(r_qeRw,{14,12})end end
function BundleEntitySelection.Local:OverwriteNamesAndDescription()
GUI_Tooltip.SetNameAndDescription_Orig_QSB_EntitySelection=GUI_Tooltip.SetNameAndDescription
GUI_Tooltip.SetNameAndDescription=function(cw,kH82nEqp,DsS06,dL,fTtrf)local hhPNw=XGUIEng.GetCurrentWidgetID()
local _KjX=(
Network.GetDesiredLanguage()=="de"and"de")or"en"
if
XGUIEng.GetWidgetID("/InGame/Root/Normal/AlignBottomRight/MapFrame/KnightButton")==hhPNw then
BundleEntitySelection.Local:SetTooltip(BundleEntitySelection.Local.Data.Tooltips.KnightButton.Title[_KjX],BundleEntitySelection.Local.Data.Tooltips.KnightButton.Text[_KjX])return end
if
XGUIEng.GetWidgetID("/InGame/Root/Normal/AlignBottomRight/MapFrame/BattalionButton")==hhPNw then
BundleEntitySelection.Local:SetTooltip(BundleEntitySelection.Local.Data.Tooltips.BattalionButton.Title[_KjX],BundleEntitySelection.Local.Data.Tooltips.BattalionButton.Text[_KjX])return end
if


XGUIEng.GetWidgetID("/InGame/Root/Normal/AlignBottomRight/DialogButtons/SiegeEngineCart/Dismount")==hhPNw or
XGUIEng.GetWidgetID("/InGame/Root/Normal/AlignBottomRight/DialogButtons/AmmunitionCart/Dismount")==hhPNw or
XGUIEng.GetWidgetID("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Military/Dismount")==hhPNw then local jkZ9GO=GUI.GetSelectedEntity()
if jkZ9GO~=0 then
if

Logic.IsEntityInCategory(jkZ9GO,EntityCategories.Military)==1 and
Logic.IsEntityInCategory(jkZ9GO,EntityCategories.Hero)==0 then local s9cWYiY=Logic.GetGuardianEntityID(jkZ9GO)
if s9cWYiY==nil or
s9cWYiY==0 then
BundleEntitySelection.Local:SetTooltip(BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Title[_KjX],BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Text[_KjX],BundleEntitySelection.Local.Data.Tooltips.ReleaseSoldiers.Disabled[_KjX])return end end end end
GUI_Tooltip.SetNameAndDescription_Orig_QSB_EntitySelection(cw,kH82nEqp,DsS06,dL,fTtrf)end end
function BundleEntitySelection.Local:SetTooltip(EKiiQwP,khI,y2ag)
local vFk6Xa="/InGame/Root/Normal/TooltipNormal"local cJRCHa=XGUIEng.GetWidgetID(vFk6Xa)
local bKQ=XGUIEng.GetWidgetID(vFk6Xa.."/FadeIn/Name")
local oEBIT=XGUIEng.GetWidgetID(vFk6Xa.."/FadeIn/Text")local cQ=XGUIEng.GetCurrentWidgetID()y2ag=y2ag or""local EPVOE=""if

XGUIEng.IsButtonDisabled(cQ)==1 and _disabledText~=""and _text~=""then
EPVOE=EPVOE.."{cr}{@color:255,32,32,255}"..y2ag end;XGUIEng.SetText(bKQ,
"{center}"..EKiiQwP)
XGUIEng.SetText(oEBIT,khI..EPVOE)local jJqck=XGUIEng.GetTextHeight(oEBIT,true)
local D,U_kQHnm1=XGUIEng.GetWidgetSize(oEBIT)XGUIEng.SetWidgetSize(oEBIT,D,jJqck)end
function BundleEntitySelection.Local:OverwriteSelectKnight()
GUI_Knight.JumpToButtonClicked=function()
local Huy4=GUI.GetPlayerID()local f=Logic.GetKnightID(Huy4)
if f>0 then
g_MultiSelection.EntityList={}g_MultiSelection.Highlighted={}GUI.ClearSelection()
if
XGUIEng.IsModifierPressed(Keys.ModifierControl)then local BH={}Logic.GetKnights(Huy4,BH)for F=1,#BH do
GUI.SelectEntity(BH[F])end else
GUI.SelectEntity(Logic.GetKnightID(Huy4))
if
(
(Framework.GetTimeMs()-g_Selection.LastClickTime)<g_Selection.MaxDoubleClickTime)then local S=GetPosition(f)
Camera.RTS_SetLookAtPosition(S.X,S.Y)else Sound.FXPlay2DSound("ui\\mini_knight")end;g_Selection.LastClickTime=Framework.GetTimeMs()end
GUI_MultiSelection.CreateMultiSelection(g_SelectionChangedSource.User)else GUI.AddNote("Debug: You do not have a knight")end end end
function BundleEntitySelection.Local:OverwriteSelectAllUnits()
GUI_MultiSelection.SelectAllPlayerUnitsClicked=function()
if
XGUIEng.IsModifierPressed(Keys.ModifierShift)then
BundleEntitySelection.Local:ExtendedLeaderSortOrder()else
BundleEntitySelection.Local:NormalLeaderSortOrder()end;Sound.FXPlay2DSound("ui\\menu_click")
GUI.ClearSelection()local Zn=GUI.GetPlayerID()
for C446IR=1,#LeaderSortOrder do
local mt7NNq=GetPlayerEntities(Zn,LeaderSortOrder[C446IR])
for BRJyrZ7=1,#mt7NNq do GUI.SelectEntity(mt7NNq[BRJyrZ7])end end;local uo6gRHf={}Logic.GetKnights(Zn,uo6gRHf)for Wm23NCP=1,#uo6gRHf do
GUI.SelectEntity(uo6gRHf[Wm23NCP])end
GUI_MultiSelection.CreateMultiSelection(g_SelectionChangedSource.User)end end
function BundleEntitySelection.Local:NormalLeaderSortOrder()g_MultiSelection={}
g_MultiSelection.EntityList={}g_MultiSelection.Highlighted={}LeaderSortOrder={}
LeaderSortOrder[1]=Entities.U_MilitarySword;LeaderSortOrder[2]=Entities.U_MilitaryBow
LeaderSortOrder[3]=Entities.U_MilitarySword_RedPrince;LeaderSortOrder[4]=Entities.U_MilitaryBow_RedPrince
LeaderSortOrder[5]=Entities.U_MilitaryBandit_Melee_ME;LeaderSortOrder[6]=Entities.U_MilitaryBandit_Melee_NA
LeaderSortOrder[7]=Entities.U_MilitaryBandit_Melee_NE;LeaderSortOrder[8]=Entities.U_MilitaryBandit_Melee_SE
LeaderSortOrder[9]=Entities.U_MilitaryBandit_Ranged_ME;LeaderSortOrder[10]=Entities.U_MilitaryBandit_Ranged_NA
LeaderSortOrder[11]=Entities.U_MilitaryBandit_Ranged_NE;LeaderSortOrder[12]=Entities.U_MilitaryBandit_Ranged_SE
LeaderSortOrder[13]=Entities.U_MilitaryCatapult;LeaderSortOrder[14]=Entities.U_MilitarySiegeTower
LeaderSortOrder[15]=Entities.U_MilitaryBatteringRam;LeaderSortOrder[16]=Entities.U_CatapultCart
LeaderSortOrder[17]=Entities.U_SiegeTowerCart;LeaderSortOrder[18]=Entities.U_BatteringRamCart
LeaderSortOrder[19]=Entities.U_Thief
if g_GameExtraNo>=1 then
table.insert(LeaderSortOrder,4,Entities.U_MilitarySword_Khana)
table.insert(LeaderSortOrder,6,Entities.U_MilitaryBow_Khana)
table.insert(LeaderSortOrder,7,Entities.U_MilitaryBandit_Melee_AS)
table.insert(LeaderSortOrder,12,Entities.U_MilitaryBandit_Ranged_AS)end end
function BundleEntitySelection.Local:ExtendedLeaderSortOrder()g_MultiSelection={}
g_MultiSelection.EntityList={}g_MultiSelection.Highlighted={}LeaderSortOrder={}
LeaderSortOrder[1]=Entities.U_MilitarySword;LeaderSortOrder[2]=Entities.U_MilitaryBow
LeaderSortOrder[3]=Entities.U_MilitarySword_RedPrince;LeaderSortOrder[4]=Entities.U_MilitaryBow_RedPrince
LeaderSortOrder[5]=Entities.U_MilitaryBandit_Melee_ME;LeaderSortOrder[6]=Entities.U_MilitaryBandit_Melee_NA
LeaderSortOrder[7]=Entities.U_MilitaryBandit_Melee_NE;LeaderSortOrder[8]=Entities.U_MilitaryBandit_Melee_SE
LeaderSortOrder[9]=Entities.U_MilitaryBandit_Ranged_ME;LeaderSortOrder[10]=Entities.U_MilitaryBandit_Ranged_NA
LeaderSortOrder[11]=Entities.U_MilitaryBandit_Ranged_NE;LeaderSortOrder[12]=Entities.U_MilitaryBandit_Ranged_SE
LeaderSortOrder[13]=Entities.U_MilitaryCatapult;LeaderSortOrder[14]=Entities.U_Trebuchet
LeaderSortOrder[15]=Entities.U_MilitarySiegeTower;LeaderSortOrder[16]=Entities.U_MilitaryBatteringRam
LeaderSortOrder[17]=Entities.U_CatapultCart;LeaderSortOrder[18]=Entities.U_SiegeTowerCart
LeaderSortOrder[19]=Entities.U_BatteringRamCart;LeaderSortOrder[20]=Entities.U_AmmunitionCart
LeaderSortOrder[21]=Entities.U_Thief
if g_GameExtraNo>=1 then
table.insert(LeaderSortOrder,4,Entities.U_MilitarySword_Khana)
table.insert(LeaderSortOrder,6,Entities.U_MilitaryBow_Khana)
table.insert(LeaderSortOrder,7,Entities.U_MilitaryBandit_Melee_AS)
table.insert(LeaderSortOrder,12,Entities.U_MilitaryBandit_Ranged_AS)end end;Core:RegisterBundle("BundleEntitySelection")
BundleGameHelperFunctions={}API=API or{}QSB=QSB or{}function API.FocusCameraOnKnight(_ml,mdh,wJ)
API.FocusCameraOnEntity(Logic.GetKnightID(_ml),mdh,wJ)end
SetCameraToPlayerKnight=API.FocusCameraOnKnight
function API.FocusCameraOnEntity(GRvo4IFg,f2jPg9y,U6)
if not GUI then
local s7nH=
(type(GRvo4IFg)~="string"and GRvo4IFg)or"'"..GRvo4IFg.."'"
API.Bridge("API.FocusCameraOnEntity("..
s7nH..", "..f2jPg9y..", "..U6 ..")")return end
if not IsExisting(GRvo4IFg)then
local mVpmh=
(type(GRvo4IFg)~="string"and GRvo4IFg)or"'"..GRvo4IFg.."'"
API.Warn("API.FocusCameraOnEntity: Entity "..mVpmh.." does not exist!")return end;return
BundleGameHelperFunctions.Local:SetCameraToEntity(GRvo4IFg,f2jPg9y,U6)end;SetCameraToEntity=API.FocusCameraOnEntity
function API.SpeedLimitSet(M83H)
if not GUI then API.Bridge("API.SpeedLimitSet("..
M83H..")")return end;return
BundleGameHelperFunctions.Local:SetSpeedLimit(M83H)end;SetSpeedLimit=API.SpeedLimitSet
function API.SpeedLimitActivate(jD)if GUI then
API.Bridge("API.SpeedLimitActivate("..
tostring(jD)..")")return end;return
API.Bridge(
"BundleGameHelperFunctions.Local:ActivateSpeedLimit("..tostring(jD)..")")end;ActivateSpeedLimit=API.SpeedLimitActivate
function API.ForbidCheats()if GUI then
API.Bridge("API.ForbidCheats()")return end;return
BundleGameHelperFunctions.Global:KillCheats()end;KillCheats=API.ForbidCheats
function API.AllowCheats()if GUI then
API.Bridge("API.AllowCheats()")return end;return
BundleGameHelperFunctions.Global:RessurectCheats()end;RessurectCheats=API.AllowCheats
function API.ForbidSaveGame(ZSwX02)if GUI then
API.Bridge("API.ForbidSaveGame("..
tostring(ZSwX02)..")")return end
API.Bridge(
[[
        BundleGameHelperFunctions.Local.Data.ForbidSave = ]]..
tostring(ZSwX02)..[[ == true
        BundleGameHelperFunctions.Local:DisplaySaveButtons(]]..
tostring(ZSwX02)..[[)
    ]])end;ForbidSaveGame=API.ForbidSaveGame
function API.AllowExtendedZoom(B)if GUI then
API.Bridge("API.AllowExtendedZoom("..
tostring(B)..")")return end;BundleGameHelperFunctions.Global.Data.ExtendedZoomAllowed=
B==true;if B==false then
BundleGameHelperFunctions.Global:DeactivateExtendedZoom()end end;AllowExtendedZoom=API.AllowExtendedZoom
function API.ThridPersonActivate(nUqFP6,n_)
if GUI then
local Q7Pv3Wo=(
type(nUqFP6)=="string"and"'"..nUqFP6 .."'")or nUqFP6
API.Bridge("API.ThridPersonActivate("..Q7Pv3Wo..", "..n_..")")return end;return
BundleGameHelperFunctions.Global:ThridPersonActivate(nUqFP6,n_)end;HeroCameraActivate=API.ThridPersonActivate
function API.ThridPersonDeactivate()if GUI then
API.Bridge("API.ThridPersonDeactivate()")return end;return
BundleGameHelperFunctions.Global:ThridPersonDeactivate()end;HeroCameraDeactivate=API.ThridPersonDeactivate
function API.ThridPersonIsRuning()
if not GUI then return
BundleGameHelperFunctions.Global:ThridPersonIsRuning()else return
BundleGameHelperFunctions.Local:ThridPersonIsRuning()end end;HeroCameraIsRuning=API.ThridPersonIsRuning
function API.FollowKnightSaveStart(ZEPCR,bA,iGKEb,VJC)
if GUI then
local rcSg=(
type(ZEPCR)=="string"and"'"..ZEPCR.."'")or ZEPCR
local fpMKmEri=(type(bA)=="string"and"'"..bA.."'")or bA
API.Bridge("API.FollowKnightSaveStart("..rcSg..", "..
fpMKmEri..", "..iGKEb..","..VJC..")")return end;return
BundleGameHelperFunctions.Global:AddFollowKnightSave(ZEPCR,bA,iGKEb,VJC)end;AddFollowKnightSave=API.FollowKnightSaveStart
function API.FollowKnightSaveStop(sgn)if GUI then
API.Bridge(
"API.FollowKnightSaveStop("..sgn..")")return end;return
BundleGameHelperFunctions.Global:StopFollowKnightSave(sgn)end;StopFollowKnightSave=API.FollowKnightSaveStop
function API.ChangeTerrainTypeInSquare(giL,I6Z,l9bJ6h1)
if GUI then
local ik=(type(giL)==
"string"and"'"..giL.."'")or giL
API.Bridge("API.ChangeTerrainTypeInSquare("..ik..
", "..I6Z..", "..l9bJ6h1 ..")")return end;if not IsExisting(giL)then
API.Fatal("API.ChangeTerrainTypeInSquare: Central point does not exist!")return end;if I6Z<100 then
API.Warn("API.ChangeTerrainTypeInSquare: Check your offset! It seems to small!")end;return
BundleGameHelperFunctions.Global:ChangeTerrainTypeInSquare(giL,I6Z,l9bJ6h1)end;TerrainType=API.ChangeTerrainTypeInSquare
function API.ChangeWaterHeightInSquare(C0UmiQ,ypK42166,iNVzz,Tad)
if GUI then
local w=(
type(C0UmiQ)=="string"and"'"..C0UmiQ.."'")or C0UmiQ
API.Bridge("API.ChangeWaterHeightInSquare("..
w..", "..ypK42166 ..", "..
iNVzz..", "..tostring(Tad)..")")return end;if not IsExisting(C0UmiQ)then
API.Fatal("API.ChangeWaterHeightInSquare: Central point does not exist!")return end;if ypK42166 <100 then
API.Warn("API.ChangeWaterHeightInSquare: Check your offset! It seems to small!")end;return
BundleGameHelperFunctions.Global:ChangeWaterHeightInSquare(C0UmiQ,ypK42166,iNVzz,Tad)end;WaterHeight=API.ChangeWaterHeightInSquare
function API.ChangeTerrainHeightInSquare(ZtU9dlwY,S8nxL4,zHVoF,MzvQ)
if GUI then local j=
(type(ZtU9dlwY)==
"string"and"'"..ZtU9dlwY.."'")or ZtU9dlwY
API.Bridge(
"API.ChangeTerrainHeightInSquare("..
j..", "..S8nxL4 ..
", "..zHVoF..", "..tostring(MzvQ)..")")return end;if not IsExisting(ZtU9dlwY)then
API.Fatal("API.ChangeTerrainHeightInSquare: Central point does not exist!")return end;if S8nxL4 <100 then
API.Warn("API.ChangeTerrainHeightInSquare: Check your offset! It seems to small!")end;return
BundleGameHelperFunctions.Global:ChangeTerrainHeightInSquare(ZtU9dlwY,S8nxL4,zHVoF,MzvQ)end;TerrainHeight=API.ChangeTerrainHeightInSquare
BundleGameHelperFunctions={Global={Data={HumanPlayerChangedOnce=false,HumanKnightType=0,HumanPlayerID=1,ExtendedZoomAllowed=true,FollowKnightSave={}}},Local={Data={SpeedLimit=32,ThirdPersonIsActive=false,ThirdPersonLastHero=
nil,ThirdPersonLastZoom=nil}}}
function BundleGameHelperFunctions.Global:Install()
self:InitExtendedZoomHotkeyFunction()self:InitExtendedZoomHotkeyDescription()
API.AddSaveGameAction(BundleGameHelperFunctions.Global.OnSaveGameLoaded)end
function BundleGameHelperFunctions.Global:ToggleExtendedZoom()
if self.Data.ExtendedZoomAllowed then if
self.Data.ExtendedZoomActive then self:DeactivateExtendedZoom()else
self:ActivateExtendedZoom()end end end
function BundleGameHelperFunctions.Global:ActivateExtendedZoom()
self.Data.ExtendedZoomActive=true
API.Bridge("BundleGameHelperFunctions.Local:ActivateExtendedZoom()")end
function BundleGameHelperFunctions.Global:DeactivateExtendedZoom()
self.Data.ExtendedZoomActive=false
API.Bridge("BundleGameHelperFunctions.Local:DeactivateExtendedZoom()")end
function BundleGameHelperFunctions.Global:InitExtendedZoomHotkeyFunction()
API.Bridge([[
        BundleGameHelperFunctions.Local:ActivateExtendedZoomHotkey()
    ]])end
function BundleGameHelperFunctions.Global:InitExtendedZoomHotkeyDescription()
API.Bridge([[
        BundleGameHelperFunctions.Local:RegisterExtendedZoomHotkey()
    ]])end;function BundleGameHelperFunctions.Global:KillCheats()
self.Data.CheatsForbidden=true
API.Bridge("BundleGameHelperFunctions.Local:KillCheats()")end
function BundleGameHelperFunctions.Global:RessurectCheats()
self.Data.CheatsForbidden=false
API.Bridge("BundleGameHelperFunctions.Local:RessurectCheats()")end
function BundleGameHelperFunctions.Global:ThridPersonActivate(I9B_,pOerGm)if BriefingSystem then
BundleGameHelperFunctions.Global:ThridPersonOverwriteStartAndEndBriefing()end;local nmhapKPO=GetID(I9B_)
BundleGameHelperFunctions.Global.Data.ThridPersonIsActive=true
Logic.ExecuteInLuaLocalState([[
        BundleGameHelperFunctions.Local:ThridPersonActivate(]]..tostring(nmhapKPO)..[[, ]]..
tostring(pOerGm)..[[);
    ]])end
function BundleGameHelperFunctions.Global:ThridPersonDeactivate()
BundleGameHelperFunctions.Global.Data.ThridPersonIsActive=false
Logic.ExecuteInLuaLocalState([[
        BundleGameHelperFunctions.Local:ThridPersonDeactivate();
    ]])end;function BundleGameHelperFunctions.Global:ThridPersonIsRuning()return
self.Data.ThridPersonIsActive end
function BundleGameHelperFunctions.Global:ThridPersonOverwriteStartAndEndBriefing()
if
BriefingSystem then
if not BriefingSystem.StartBriefing_Orig_HeroCamera then
BriefingSystem.StartBriefing_Orig_HeroCamera=BriefingSystem.StartBriefing
BriefingSystem.StartBriefing=function(n6iYWoBH,K)
if
BundleGameHelperFunctions.Global:ThridPersonIsRuning()then
BundleGameHelperFunctions.Global:ThridPersonDeactivate()
BundleGameHelperFunctions.Global.Data.ThirdPersonStoppedByCode=true end
BriefingSystem.StartBriefing_Orig_HeroCamera(n6iYWoBH,K)end;StartBriefing=BriefingSystem.StartBriefing end
if not BriefingSystem.EndBriefing_Orig_HeroCamera then
BriefingSystem.EndBriefing_Orig_HeroCamera=BriefingSystem.EndBriefing
BriefingSystem.EndBriefing=function(jiHylRW,hQxzK)
BriefingSystem.EndBriefing_Orig_HeroCamera()
if
BundleGameHelperFunctions.Global.Data.ThridPersonStoppedByCode then
BundleGameHelperFunctions.Global:ThridPersonActivate(0)
BundleGameHelperFunctions.Global.Data.ThridPersonStoppedByCode=false end end end end end
function BundleGameHelperFunctions.Global:AddFollowKnightSave(MSUXIj,W,ApJe8,j31BJV)
local mTV=GetID(MSUXIj)local g4fMP=GetID(W)j31BJV=j31BJV or 0
local qBf0=Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_TURN,nil,"ControlFollowKnightSave",1,{},{mTV,g4fMP,ApJe8,j31BJV})table.insert(self.Data.FollowKnightSave,qBf0)return
qBf0 end
function BundleGameHelperFunctions.Global:StopFollowKnightSave(A)
for fZg8Dv2f,SM7wSDM in
pairs(self.Data.FollowKnightSave)do if A==SM7wSDM then self.Data.FollowKnightSave[fZg8Dv2f]=nil
EndJob(A)end end end
function BundleGameHelperFunctions.Global.ControlFollowKnightSave(jRE,hnei,Nn2mDxL,hAtnV)
if
not IsExisting(hnei)or not IsExisting(jRE)then return true end
if Logic.IsKnight(jRE)and
Logic.KnightGetResurrectionProgress(jRE)~=1 then return false end
if Logic.IsKnight(hnei)and
Logic.KnightGetResurrectionProgress(hnei)~=1 then return false end
if Logic.IsEntityMoving(jRE)==false and
Logic.IsFighting(jRE)==false and
IsNear(jRE,hnei,Nn2mDxL+300)==false then
local e6f5QPQ,Cd,o9=Logic.EntityGetPos(hnei)
local gZMKt=Logic.GetEntityOrientation(hnei)- (180+hAtnV)
local ar=e6f5QPQ+Nn2mDxL*math.cos(math.rad(gZMKt))
local Q3ih_M=Cd+Nn2mDxL*math.sin(math.rad(gZMKt))
local bAqzK=Logic.CreateEntityOnUnblockedLand(Entities.XD_ScriptEntity,ar,Q3ih_M,0,0)local e6f5QPQ,Cd,o9=Logic.EntityGetPos(bAqzK)
DestroyEntity(bAqzK)Logic.MoveSettler(jRE,e6f5QPQ,Cd)end end
ControlFollowKnightSave=BundleGameHelperFunctions.Global.ControlFollowKnightSave
function BundleGameHelperFunctions.Global:ChangeTerrainTypeInSquare(qbSBn,j5xdrPIH,g6fP5pGX)
local Xphl0JVa,GViWJ,gm,EdmSw3k,bg=self:GetSquareForWaterAndTerrain(qbSBn,j5xdrPIH)
if Xphl0JVa==-1 or Xphl0JVa==-2 then return Xphl0JVa end;if type(g6fP5pGX)=="number"then
for VzEkUqPm=Xphl0JVa,gm do for UZIS=GViWJ,EdmSw3k do
Logic.SetTerrainNodeType(VzEkUqPm,UZIS,g6fP5pGX)end end end
Logic.UpdateBlocking(Xphl0JVa,GViWJ,gm,EdmSw3k)end
function BundleGameHelperFunctions.Global:ChangeWaterHeightInSquare(IygK,omF2bw,kw3c,uOFbxQ)
local zGqG,cY04Q,jj,H30t4PRX,Yv=self:GetSquareForWaterAndTerrain(IygK,omF2bw)if zGqG==-1 or zGqG==-2 then return zGqG end
if not uOFbxQ then
if kw3c<0 then return-3 end
Logic.WaterSetAbsoluteHeight(zGqG,cY04Q,jj,H30t4PRX,kw3c)else if Yv+kw3c<0 then return-3 end
Logic.WaterSetAbsoluteHeight(zGqG,cY04Q,jj,H30t4PRX,Yv+kw3c)end;Logic.UpdateBlocking(zGqG,cY04Q,jj,H30t4PRX)return 0 end
function BundleGameHelperFunctions.Global:ChangeTerrainHeightInSquare(u,oKbx,M_Fb98K,W7NGu)
local V,u9n7n,SN2tGrc,nCDyRI,RZDU=self:GetSquareForWaterAndTerrain(u,oKbx)if V==-1 or V==-2 then return V end;local SyxC;if not W7NGu then
if M_Fb98K<0 then return-3 end;SyxC=M_Fb98K else if RZDU+M_Fb98K<0 then return-3 end
SyxC=RZDU+M_Fb98K end
for vsjEP=V,SN2tGrc do for T08RehZq=u9n7n,nCDyRI do
Logic.SetTerrainNodeHeight(vsjEP,T08RehZq,SyxC)end end;Logic.UpdateBlocking(V,u9n7n,SN2tGrc,nCDyRI)return 0 end
function BundleGameHelperFunctions.Global:GetSquareForWaterAndTerrain(EiLA,zMGKTRQ)
local Y=type(EiLA)if
(Y~="string"and Y~="number")or not IsExisting(EiLA)then return-1 end;local Qy13Za,B4cZEv1W,OLbETI,eW
local HvVdj=GetID(EiLA)local Ec0SEQ,V,xy=Logic.EntityGetPos(HvVdj)Qy13Za=math.floor(
(Ec0SEQ-zMGKTRQ)/100)
B4cZEv1W=math.floor((V-zMGKTRQ)/100)
OLbETI=math.floor((Ec0SEQ+zMGKTRQ)/100)eW=math.floor((V+zMGKTRQ)/100)
if
IsValidPosition({X=Qy13Za,Y=B4cZEv1W})==false or
IsValidPosition({X=OLbETI,Y=eW})==false then return-2 end;return Qy13Za,B4cZEv1W,OLbETI,eW,xy end
function BundleGameHelperFunctions.Global.OnSaveGameLoaded()if
BundleGameHelperFunctions.Global.Data.ExtendedZoomActive then
BundleGameHelperFunctions.Global:ActivateExtendedZoom()end
BundleGameHelperFunctions.Global:InitExtendedZoomHotkeyFunction()if BundleGameHelperFunctions.Global.Data.CheatsForbidden==
true then
BundleGameHelperFunctions.Global:KillCheats()end end
function BundleGameHelperFunctions.Local:Install()
self:InitForbidSpeedUp()self:InitForbidSaveGame()end
function BundleGameHelperFunctions.Local:SetCameraToEntity(sBouqn,O9nnGl,KmcnJFXi)
local uBleBgJ=GetPosition(sBouqn)local vWEos=(O9nnGl or-45)local n7=(KmcnJFXi or 0.5)
Camera.RTS_SetLookAtPosition(uBleBgJ.X,uBleBgJ.Y)Camera.RTS_SetRotationAngle(vWEos)
Camera.RTS_SetZoomFactor(n7)end
function BundleGameHelperFunctions.Local:SetSpeedLimit(CF)CF=(CF<1 and 1)or
math.floor(CF)self.Data.SpeedLimit=CF end
function BundleGameHelperFunctions.Local:ActivateSpeedLimit(s)
self.Data.UseSpeedLimit=s==true;if s and
Game.GameTimeGetFactor(GUI.GetPlayerID())>self.Data.SpeedLimit then
Game.GameTimeSetFactor(GUI.GetPlayerID(),self.Data.SpeedLimit)end end
function BundleGameHelperFunctions.Local:InitForbidSpeedUp()
GameCallback_GameSpeedChanged_Orig_Preferences_ForbidSpeedUp=GameCallback_GameSpeedChanged
GameCallback_GameSpeedChanged=function(pv7)
GameCallback_GameSpeedChanged_Orig_Preferences_ForbidSpeedUp(pv7)
if
BundleGameHelperFunctions.Local.Data.UseSpeedLimit==true then
if
pv7 >BundleGameHelperFunctions.Local.Data.SpeedLimit then
Game.GameTimeSetFactor(GUI.GetPlayerID(),BundleGameHelperFunctions.Local.Data.SpeedLimit)end end end end
function BundleGameHelperFunctions.Local:KillCheats()
Input.KeyBindDown(Keys.ModifierControl+
Keys.ModifierShift+Keys.Divide,"KeyBindings_EnableDebugMode(0)",2,false)end
function BundleGameHelperFunctions.Local:RessurectCheats()
Input.KeyBindDown(Keys.ModifierControl+
Keys.ModifierShift+Keys.Divide,"KeyBindings_EnableDebugMode(2)",2,false)end
function BundleGameHelperFunctions.Local:RegisterExtendedZoomHotkey()
API.AddHotKey({de="Strg + Umschalt + K",en="Ctrl + Shift + K"},{de="Alternativen Zoom ein/aus",en="Alternative zoom on/off"})end
function BundleGameHelperFunctions.Local:ActivateExtendedZoomHotkey()
Input.KeyBindDown(
Keys.ModifierControl+Keys.ModifierShift+Keys.K,"BundleGameHelperFunctions.Local:ToggleExtendedZoom()",2,false)end;function BundleGameHelperFunctions.Local:ToggleExtendedZoom()
API.Bridge("BundleGameHelperFunctions.Global:ToggleExtendedZoom()")end
function BundleGameHelperFunctions.Local:ActivateExtendedZoom()
Camera.RTS_SetZoomFactorMax(0.8701)Camera.RTS_SetZoomFactor(0.8700)
Camera.RTS_SetZoomFactorMin(0.0999)end
function BundleGameHelperFunctions.Local:DeactivateExtendedZoom()
Camera.RTS_SetZoomFactor(0.5000)Camera.RTS_SetZoomFactorMax(0.5001)
Camera.RTS_SetZoomFactorMin(0.0999)end
function BundleGameHelperFunctions.Local:InitForbidSaveGame()
KeyBindings_SaveGame_Orig_Preferences_SaveGame=KeyBindings_SaveGame
KeyBindings_SaveGame=function()if
BundleGameHelperFunctions.Local.Data.ForbidSave then return end
KeyBindings_SaveGame_Orig_Preferences_SaveGame()end end
function BundleGameHelperFunctions.Local:DisplaySaveButtons(GPo_j)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/SaveGame",(
GPo_j and 0)or 1)
XGUIEng.ShowWidget("/InGame/InGame/MainMenu/Container/QuickSave",(GPo_j and 0)or 1)end
function BundleGameHelperFunctions.Local:ThridPersonActivate(oBe,p81DrYU)
oBe=
(oBe~=0 and oBe)or self.Data.ThridPersonLastHero or
Logic.GetKnightID(GUI.GetPlayerID())
p81DrYU=p81DrYU or self.Data.ThridPersonLastZoom or 0.5;if not oBe then return end
if
not GameCallback_Camera_GetBorderscrollFactor_Orig_HeroCamera then self:ThridPersonOverwriteGetBorderScrollFactor()end;self.Data.ThridPersonLastHero=oBe
self.Data.ThridPersonLastZoom=p81DrYU;self.Data.ThridPersonIsActive=true
local M7mxb=Logic.GetEntityOrientation(oBe)Camera.RTS_FollowEntity(oBe)
Camera.RTS_SetRotationAngle(M7mxb-90)Camera.RTS_SetZoomFactor(p81DrYU)
Camera.RTS_SetZoomFactorMax(p81DrYU+0.0001)end
function BundleGameHelperFunctions.Local:ThridPersonDeactivate()
self.Data.ThridPersonIsActive=false;Camera.RTS_SetZoomFactorMax(0.5)
Camera.RTS_SetZoomFactor(0.5)Camera.RTS_FollowEntity(0)end;function BundleGameHelperFunctions.Local:ThridPersonIsRuning()
return self.Data.ThridPersonIsActive end
function BundleGameHelperFunctions.Local:ThridPersonOverwriteGetBorderScrollFactor()
GameCallback_Camera_GetBorderscrollFactor_Orig_HeroCamera=GameCallback_Camera_GetBorderscrollFactor
GameCallback_Camera_GetBorderscrollFactor=function()
if not
BundleGameHelperFunctions.Local.Data.ThridPersonIsActive then return
GameCallback_Camera_GetBorderscrollFactor_Orig_HeroCamera()end;local r=Camera.RTS_GetRotationAngle()
local oIOzWi,Hc=GUI.GetScreenSize()local VV8gT0,vaKOcJ=GUI.GetMousePosition()local yUdqq=VV8gT0/oIOzWi;if
yUdqq<=0.02 then r=r+0.3 elseif yUdqq>=0.98 then r=r-0.3 else return 0 end;if r>=360 then
r=0 end;Camera.RTS_SetRotationAngle(r)return 0 end end;Core:RegisterBundle("BundleGameHelperFunctions")
BundleInteractiveObjects={}API=API or{}QSB=QSB or{}QSB.IOList={}
function API.CreateObject(BYOcq)if GUI then
API.Fatal("API.CreateObject: Can not be used from local enviorment!")return end;return
BundleInteractiveObjects.Global:CreateObject(BYOcq)end;CreateObject=API.CreateObject
function API.RemoveInteractiveObject(v)if GUI then
API.Bridge("API.RemoveInteractiveObject('"..v.."')")return end;if not IsExisting(v)then
API.Warn(
"API.RemoveInteractiveObject: Entity \""..v.."\" is invalid!")return end;return
BundleInteractiveObjects.Global:RemoveInteractiveObject(v)end;RemoveInteractiveObject=API.RemoveInteractiveObject
function API.InteractiveObjectActivate(i,aK)if GUI then
API.Bridge(
"API.InteractiveObjectActivate('"..i.."', "..tostring(aK)..")")return end;if not IsExisting(i)then
API.Warn(
"API.InteractiveObjectActivate: Entity \""..i.."\" is invalid!")return end
if not
Logic.IsInteractiveObject(GetID(i))then
if IO[i]then IO[i].Inactive=false;IO[i].Used=false end else API.ActivateIO(i,aK)end end;InteractiveObjectActivate=API.InteractiveObjectActivate
function API.InteractiveObjectDeactivate(Ff)if GUI then
API.Bridge(
"API.InteractiveObjectDeactivate('"..Ff.."')")return end;if not IsExisting(Ff)then
API.Warn(
"API.InteractiveObjectDeactivate: Entity \""..Ff.."\" is invalid!")return end;if not
Logic.IsInteractiveObject(GetID(Ff))then if IO[Ff]then IO[Ff].Inactive=true end else
API.DeactivateIO(Ff)end end;InteractiveObjectDeactivate=API.InteractiveObjectDeactivate
function API.AddCustomIOName(JOa,oBIMp)
if type(
oBIMp=="table")then local b=
(Network.GetDesiredLanguage()=="de"and"de")or"en"oBIMp=oBIMp[b]end;if GUI then
API.Bridge("API.AddCustomIOName('"..JOa.."', '"..oBIMp.."')")return end;return
BundleInteractiveObjects.Global:AddCustomIOName(JOa,oBIMp)end;AddCustomIOName=API.AddCustomIOName
BundleInteractiveObjects={Global={Data={}},Local={Data={IOCustomNames={},IOCustomNamesByEntityName={}}}}
function BundleInteractiveObjects.Global:Install()IO={}end
function BundleInteractiveObjects.Global:CreateObject(OPYcKca)
local NaBH8sz=Network.GetDesiredLanguage()self:HackOnInteractionEvent()
self:RemoveInteractiveObject(OPYcKca.Name)if type(OPYcKca.Title)=="table"then
OPYcKca.Title=OPYcKca.Title[NaBH8sz]end
if not OPYcKca.Title or
OPYcKca.Title==""then OPYcKca.Title=
(NaBH8sz=="de"and"Interaktion")or"Interaction"end;if type(OPYcKca.Text)=="table"then
OPYcKca.Text=OPYcKca.Text[NaBH8sz]end
if not OPYcKca.Text then OPYcKca.Text=""end;if type(OPYcKca.WrongKnight)=="table"then
OPYcKca.WrongKnight=OPYcKca.WrongKnight[NaBH8sz]end
OPYcKca.WrongKnight=OPYcKca.WrongKnight or""if type(OPYcKca.ConditionUnfulfilled)=="table"then
OPYcKca.ConditionUnfulfilled=OPYcKca.ConditionUnfulfilled[NaBH8sz]end;OPYcKca.ConditionUnfulfilled=
OPYcKca.ConditionUnfulfilled or""OPYcKca.Condition=OPYcKca.Condition or function()return
true end;OPYcKca.Callback=
OPYcKca.Callback or function()end
OPYcKca.Distance=OPYcKca.Distance or 1200;OPYcKca.Waittime=OPYcKca.Waittime or 15;OPYcKca.Texture=
OPYcKca.Texture or{14,10}
OPYcKca.Reward=OPYcKca.Reward or{}OPYcKca.Costs=OPYcKca.Costs or{}
OPYcKca.State=OPYcKca.State or 0
Logic.ExecuteInLuaLocalState([[
        QSB.IOList[#QSB.IOList+1] = "]]..
OPYcKca.Name..
[["
        if not BundleInteractiveObjects.Local.Data.InteractionHackStarted then
            BundleInteractiveObjects.Local:ActivateInteractiveObjectControl()
            BundleInteractiveObjects.Local.Data.InteractionHackStarted = true;
        end
    ]])IO[OPYcKca.Name]=API.InstanceTable(OPYcKca)
local pUFEVkWc=GetID(OPYcKca.Name)
if Logic.IsInteractiveObject(pUFEVkWc)==true then
Logic.InteractiveObjectClearCosts(pUFEVkWc)Logic.InteractiveObjectClearRewards(pUFEVkWc)
Logic.InteractiveObjectSetInteractionDistance(pUFEVkWc,OPYcKca.Distance)
Logic.InteractiveObjectSetTimeToOpen(pUFEVkWc,OPYcKca.Waittime)
Logic.InteractiveObjectAddRewards(pUFEVkWc,OPYcKca.Reward[1],OPYcKca.Reward[2])
Logic.InteractiveObjectSetAvailability(pUFEVkWc,true)
Logic.InteractiveObjectSetPlayerState(pUFEVkWc,OPYcKca.PlayerID or 1,OPYcKca.State)
Logic.InteractiveObjectSetRewardResourceCartType(pUFEVkWc,Entities.U_ResourceMerchant)
Logic.InteractiveObjectSetRewardGoldCartType(pUFEVkWc,Entities.U_GoldCart)table.insert(HiddenTreasures,pUFEVkWc)end end
function BundleInteractiveObjects.Global:RemoveInteractiveObject(cD8yLh5F)
for L4YQoO,mSob4P in pairs(IO)do
if
L4YQoO==cD8yLh5F then
Logic.ExecuteInLuaLocalState([[
                IO["]]..cD8yLh5F..[["] = nil;
            ]])IO[cD8yLh5F]=nil end end end
function BundleInteractiveObjects.Global:AddCustomIOName(cQfE6hL5,HZ27J5I)
if
type(HZ27J5I)=="table"then local le2NWe=HZ27J5I.de;local k3=HZ27J5I.en
Logic.ExecuteInLuaLocalState(
[[
            BundleInteractiveObjects.Local.Data.IOCustomNames["]]..cQfE6hL5 ..
[["] = {
                de = "]]..le2NWe..
[[",
                en = "]]..k3 ..[["
            }
        ]])else
Logic.ExecuteInLuaLocalState([[
            BundleInteractiveObjects.Local.Data.IOCustomNames["]]..cQfE6hL5 ..[["] = "]]..
HZ27J5I..[["
        ]])end end
function BundleInteractiveObjects.Global:HackOnInteractionEvent()
if not
BundleInteractiveObjects.Global.Data.InteractionEventHacked then
StartSimpleJobEx(BundleInteractiveObjects.Global.ControlInteractiveObjects)
BundleInteractiveObjects.Global.Data.InteractionEventHacked=true
OnTreasureFound=function(RhM,hz)
for KW=1,#HiddenTreasures do local TjT=HiddenTreasures[KW]
if TjT==RhM then
Logic.InteractiveObjectSetAvailability(RhM,false)
for s5=1,8 do Logic.InteractiveObjectSetPlayerState(RhM,s5,2)end;table.remove(HiddenTreasures,KW)
HiddenTreasures[0]=#HiddenTreasures;local IoOFF0gQ="menu_left_prestige"local KI7x=Logic.GetEntityName(RhM)if
IO[KI7x]and IO[KI7x].ActivationSound then
IoOFF0gQ=IO[KI7x].ActivationSound end
Logic.ExecuteInLuaLocalState("Play2DSound("..hz..",'"..
IoOFF0gQ.."')")end end end
GameCallback_OnObjectInteraction=function(Lg6QrU,VWJKqc)OnInteractiveObjectOpened(Lg6QrU,VWJKqc)
OnTreasureFound(Lg6QrU,VWJKqc)local D_PK9L=Logic.GetEntityName(Lg6QrU)
for lmM,F71veV in pairs(IO)do if lmM==D_PK9L then
if
not F71veV.Used then IO[lmM].Used=true;F71veV.Callback(F71veV,VWJKqc)end end end end
GameCallback_ExecuteCustomObjectReward=function(othH7mP,EoMjIBJ,nXBww,UyXD84)local WsyrYW=GetPosition(EoMjIBJ)
local Cm6p=Logic.GetGoodCategoryForGoodType(nXBww)local Wx
if Cm6p==GoodCategories.GC_Resource then
Wx=Logic.CreateEntityOnUnblockedLand(Entities.U_ResourceMerchant,WsyrYW.X,WsyrYW.Y,0,othH7mP)elseif nXBww==Goods.G_Medicine then
Wx=Logic.CreateEntityOnUnblockedLand(Entities.U_Medicus,WsyrYW.X,WsyrYW.Y,0,othH7mP)elseif nXBww==Goods.G_Gold then
Wx=Logic.CreateEntityOnUnblockedLand(Entities.U_GoldCart,WsyrYW.X,WsyrYW.Y,0,othH7mP)else
Wx=Logic.CreateEntityOnUnblockedLand(Entities.U_Marketer,WsyrYW.X,WsyrYW.Y,0,othH7mP)end
Logic.HireMerchant(Wx,othH7mP,nXBww,UyXD84,othH7mP)end
function QuestTemplate:AreObjectsActivated(Fl2HF34)
for L4E=1,Fl2HF34[0]do if not Fl2HF34[-L4E]then
Fl2HF34[-L4E]=GetEntityId(Fl2HF34[L4E])end
local Mf9P=Logic.GetEntityName(Fl2HF34[-L4E])
if Logic.IsInteractiveObject(Fl2HF34[-L4E])then if not
IsInteractiveObjectOpen(Fl2HF34[-L4E])then return false end else if
not IO[Mf9P]then return false end
if IO[Mf9P].Used~=true then return false end end end;return true end end end
function BundleInteractiveObjects.Global.ControlInteractiveObjects()for mQ8nL1g,csxkE in pairs(IO)do
if
not csxkE.Used==true then csxkE.ConditionFullfilled=csxkE.Condition(csxkE)end end end;function BundleInteractiveObjects.Local:Install()
IO=Logic.CreateReferenceToTableInGlobaLuaState("IO")end
function BundleInteractiveObjects.Local:CanBeBought(_r4p4,b,NDhXt)
local CMfd0J=GetPlayerGoodsInSettlement(b,_r4p4,true)if CMfd0J<NDhXt then return false end;return true end
function BundleInteractiveObjects.Local:BuyObject(L,Mm,vHXw)
if

Logic.GetGoodCategoryForGoodType(Mm)~=GoodCategories.GC_Resource and Mm~=Goods.G_Gold then local qe=GetPlayerEntities(L,0)local rKVl=vHXw
for VLMZ=1,#qe do
if
Logic.IsBuilding(qe[VLMZ])==1 and rKVl>0 then
if
Logic.GetBuildingProduct(qe[VLMZ])==Mm then
local gZtWL_VC=Logic.GetAmountOnOutStockByIndex(qe[VLMZ],0)for FpkkcYC=1,gZtWL_VC do
API.Bridge("Logic.RemoveGoodFromStock("..qe[VLMZ]..","..Mm..",1)")rKVl=rKVl-1 end end end end else
API.Bridge("AddGood("..
Mm..",".. (vHXw* (-1))..","..L..")")end end
function BundleInteractiveObjects.Local:ActivateInteractiveObjectControl()g_Interaction.ActiveObjectsOnScreen=
g_Interaction.ActiveObjectsOnScreen or{}g_Interaction.ActiveObjects=
g_Interaction.ActiveObjects or{}
GUI_Interaction.InteractiveObjectUpdate=function()
local Xr0dYV=GUI.GetPlayerID()if g_Interaction.ActiveObjects==nil then return end
for zOG=1,#
g_Interaction.ActiveObjects do local BW7kBC=g_Interaction.ActiveObjects[zOG]
local l,lRRle90=GUI.GetEntityInfoScreenPosition(BW7kBC)local V7k,DNPcx=GUI.GetScreenSize()
if

l~=0 and lRRle90 ~=0 and l>-50 and lRRle90 >-50 and l< (V7k+50)and lRRle90 < (DNPcx+50)then if
Inside(BW7kBC,g_Interaction.ActiveObjectsOnScreen)==false then
table.insert(g_Interaction.ActiveObjectsOnScreen,BW7kBC)end else
for zOG=1,#
g_Interaction.ActiveObjectsOnScreen do if
g_Interaction.ActiveObjectsOnScreen[zOG]==BW7kBC then
table.remove(g_Interaction.ActiveObjectsOnScreen,zOG)end end end end
for d=1,#g_Interaction.ActiveObjectsOnScreen do
local nSzenj3="/InGame/Root/Normal/InteractiveObjects/"..d
if XGUIEng.IsWidgetExisting(nSzenj3)==1 then
local buOFdHT=g_Interaction.ActiveObjectsOnScreen[d]local NszoYjly=Logic.GetEntityType(buOFdHT)
local NR9,xtw7rbXI=GUI.GetEntityInfoScreenPosition(buOFdHT)
local ZnLxH={XGUIEng.GetWidgetScreenSize(nSzenj3)}
local Y={Logic.InteractiveObjectGetCosts(buOFdHT)}
local OVQDo8Ns={Logic.InteractiveObjectGetEffectiveCosts(buOFdHT,Xr0dYV)}
local h=Logic.InteractiveObjectGetAvailability(buOFdHT)local EqwyI=Logic.GetEntityType(buOFdHT)
local jW4=Logic.GetEntityName(buOFdHT)local yEVxuB=Logic.GetEntityTypeName(EqwyI)local yLKEV03=false
XGUIEng.SetWidgetScreenPosition(nSzenj3,
NR9- (ZnLxH[1]/2),xtw7rbXI- (ZnLxH[2]/2))if Y[1]~=nil and OVQDo8Ns[1]==nil and h==true then
yLKEV03=true end
local rrEne=Logic.InteractiveObjectHasPlayerEnoughSpaceForRewards(buOFdHT,Xr0dYV)if rrEne==false then yLKEV03=true end
if yLKEV03 ==true then
XGUIEng.DisableButton(nSzenj3,1)else XGUIEng.DisableButton(nSzenj3,0)end;if GUI_Interaction.InteractiveObjectUpdateEx1 ~=nil then
GUI_Interaction.InteractiveObjectUpdateEx1(nSzenj3,NszoYjly)end;if IO[jW4]then
BundleInteractiveObjects.Local:SetIcon(nSzenj3,IO[jW4].Texture)end
XGUIEng.ShowWidget(nSzenj3,1)end end
for T,X0K in pairs(QSB.IOList)do local qg=GUI.GetPlayerID()
local lrdJsW4=Logic.GetEntityType(GetID(X0K))local capBAoBx=Logic.GetEntityTypeName(lrdJsW4)
if
capBAoBx and X0K~=""then
if
not(string.find(capBAoBx,"I_X_"))and not
(string.find(capBAoBx,"Mine"))and not
(string.find(capBAoBx,"B_Wel"))and not
(string.find(capBAoBx,"B_Cis"))then
if IO[X0K].State==0 and IO[X0K].Distance~=nil and
IO[X0K].Distance>0 then local Hhkk={}
Logic.GetKnights(qg,Hhkk)local n=false;for Gw=1,#Hhkk do
if IsNear(Hhkk[Gw],X0K,IO[X0K].Distance)then n=true;break end end
if not IO[X0K].Used and not
IO[X0K].Inactive then if n then
ScriptCallback_ObjectInteraction(qg,GetID(X0K))else
ScriptCallback_CloseObjectInteraction(qg,GetID(X0K))end else
ScriptCallback_CloseObjectInteraction(qg,GetID(X0K))end else
if not IO[X0K].Used and not IO[X0K].Inactive then
ScriptCallback_ObjectInteraction(qg,GetID(X0K))else
ScriptCallback_CloseObjectInteraction(qg,GetID(X0K))end end end end end;for HNBMc=#g_Interaction.ActiveObjectsOnScreen+1,2 do local zK=
"/InGame/Root/Normal/InteractiveObjects/"..HNBMc
XGUIEng.ShowWidget(zK,0)end end
GUI_Interaction.InteractiveObjectMouseOver_Orig_BundleInteractiveObjects=GUI_Interaction.InteractiveObjectMouseOver
GUI_Interaction.InteractiveObjectMouseOver=function()local UFW_E=GUI.GetPlayerID()
local U814=tonumber(XGUIEng.GetWidgetNameByID(XGUIEng.GetCurrentWidgetID()))local doEnFnqj=g_Interaction.ActiveObjectsOnScreen[U814]
local apv=Logic.GetEntityType(doEnFnqj)
if g_GameExtraNo>0 then local tIn=Logic.GetEntityTypeName(apv)
if
Inside(tIn,{"R_StoneMine","R_IronMine","B_Cistern","I_X_TradePostConstructionSite"})then
GUI_Interaction.InteractiveObjectMouseOver_Orig_BundleInteractiveObjects()return end end;local Sw=Logic.GetEntityTypeName(apv)
if string.find(Sw,"^I_X_")and
tonumber(Logic.GetEntityName(doEnFnqj))~=nil then
GUI_Interaction.InteractiveObjectMouseOver_Orig_BundleInteractiveObjects()return end;local Rl=XGUIEng.GetCurrentWidgetID()
local nfD={Logic.InteractiveObjectGetEffectiveCosts(doEnFnqj,UFW_E)}
local bLm=Logic.InteractiveObjectGetAvailability(doEnFnqj)local hV;local BmY4vP;local g=Logic.GetEntityName(doEnFnqj)
if bLm==true then
hV="InteractiveObjectAvailable"else hV="InteractiveObjectNotAvailable"end
if
Logic.InteractiveObjectHasPlayerEnoughSpaceForRewards(doEnFnqj,UFW_E)==false then BmY4vP="InteractiveObjectAvailableReward"end;local n8YUk0U;if
nfD and nfD[1]and Logic.GetGoodCategoryForGoodType(nfD[1])~=
GoodCategories.GC_Resource then n8YUk0U=true end
if IO[g]and
IO[g].Used~=true then local H;local waLkflE;if IO[g].Title or IO[g].Text then
H=IO[g].Title or""waLkflE=IO[g].Text or""end
nfD=IO[g].Costs;if
nfD and nfD[1]and Logic.GetGoodCategoryForGoodType(nfD[1])~=
GoodCategories.GC_Resource then n8YUk0U=true end
BundleInteractiveObjects.Local:TextCosts(H,waLkflE,
nil,{nfD[1],nfD[2],nfD[3],nfD[4]},n8YUk0U)return end end
GUI_Interaction.InteractiveObjectClicked_Orig_BundleInteractiveObjects=GUI_Interaction.InteractiveObjectClicked
GUI_Interaction.InteractiveObjectClicked=function()
local q3L=tonumber(XGUIEng.GetWidgetNameByID(XGUIEng.GetCurrentWidgetID()))local sqozL=g_Interaction.ActiveObjectsOnScreen[q3L]
local w=GUI.GetPlayerID()local mnbIg3H=Logic.GetEntityType(sqozL)
local dFSRs8EO=Network.GetDesiredLanguage()
dFSRs8EO=(dFSRs8EO=="de"and dFSRs8EO)or"en"
if g_GameExtraNo>0 then local WsVQOPz=Logic.GetEntityTypeName(mnbIg3H)
if
Inside(WsVQOPz,{"R_StoneMine","R_IronMine","B_Cistern","I_X_TradePostConstructionSite"})then
GUI_Interaction.InteractiveObjectClicked_Orig_BundleInteractiveObjects()return end end;local Mc=Logic.GetEntityTypeName(mnbIg3H)
if

string.find(Mc,"^I_X_")and tonumber(Logic.GetEntityName(sqozL))~=nil then
GUI_Interaction.InteractiveObjectClicked_Orig_BundleInteractiveObjects()return end
for F,QMZ_IpD in pairs(IO)do
if sqozL==GetID(F)then local Z="menu_left_prestige"if QMZ_IpD.ActivationSound then
Z=QMZ_IpD.ActivationSound end;local lUuFOTao={}
if IO[F].Reward and
IO[F].Reward[1]~=nil then
table.insert(lUuFOTao,IO[F].Reward[1])table.insert(lUuFOTao,IO[F].Reward[2])end;local fQ=true
if

lUuFOTao[2]and type(lUuFOTao[2])=="number"and lUuFOTao[1]~=Goods.G_Gold and
Logic.GetGoodCategoryForGoodType(lUuFOTao[1])==GoodCategories.GC_Resource then local vPAqF=Logic.GetPlayerUnreservedStorehouseSpace(w)if vPAqF<
lUuFOTao[2]then fQ=false end end;local SQwf
if IO[F].Costs and IO[F].Costs[1]then
if
Logic.GetGoodCategoryForGoodType(IO[F].Costs[1])~=GoodCategories.GC_Resource then SQwf=true end
if fQ==false then
local wK=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_MerchantStorehouseSpace")Message(wK)return end;local _hcI4G5H=IO[F].Costs
local LzWd=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_NotEnough_Resources")local Nmp=true;if _hcI4G5H[1]then
Nmp=Nmp and
BundleInteractiveObjects.Local:CanBeBought(w,_hcI4G5H[1],_hcI4G5H[2])end;if _hcI4G5H[3]then
Nmp=Nmp and
BundleInteractiveObjects.Local:CanBeBought(w,_hcI4G5H[3],_hcI4G5H[4])end
if
not IO[F].ConditionFullfilled then if IO[F].ConditionUnfulfilled then local mdD7gg=IO[F].ConditionUnfulfilled;if
type(mdD7gg)=="table"then mdD7gg=mdD7gg[dFSRs8EO]end
Message(mdD7gg)end
return end
if IO[F].Opener then
if
Logic.GetDistanceBetweenEntities(GetID(IO[F].Opener),GetID(F))>IO[F].Distance then
if IO[F].WrongKnight and IO[F].WrongKnight~=
""then Message(IO[F].WrongKnight)end;return end end
if Nmp==true then if _hcI4G5H[1]~=nil then
BundleInteractiveObjects.Local:BuyObject(w,_hcI4G5H[1],_hcI4G5H[2])end;if _hcI4G5H[3]~=nil then
BundleInteractiveObjects.Local:BuyObject(w,_hcI4G5H[3],_hcI4G5H[4])end;if#lUuFOTao>0 then
GUI.SendScriptCommand(
"GameCallback_ExecuteCustomObjectReward("..w..",'"..F..
"',"..lUuFOTao[1]..","..lUuFOTao[2]..")")end
Play2DSound(w,Z)
GUI.SendScriptCommand("GameCallback_OnObjectInteraction("..sqozL..","..w..")")else Message(LzWd)end else
if fQ==false then
local TR2sVkoI=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_MerchantStorehouseSpace")Message(TR2sVkoI)return end
if not IO[F].ConditionFullfilled then if IO[F].ConditionUnfulfilled and
IO[F].ConditionUnfulfilled~=""then
Message(IO[F].ConditionUnfulfilled)end;return end
if IO[F].Opener then
if
Logic.GetDistanceBetweenEntities(GetID(IO[F].Opener),GetID(F))>IO[F].Distance then
if IO[F].WrongKnight and IO[F].WrongKnight~=
""then Message(IO[F].WrongKnight)end;return end end;if#lUuFOTao>0 then
GUI.SendScriptCommand("GameCallback_ExecuteCustomObjectReward("..w..
",'"..F.."',"..lUuFOTao[1]..","..
lUuFOTao[2]..")")end
Play2DSound(w,Z)
GUI.SendScriptCommand("GameCallback_OnObjectInteraction("..sqozL..","..w..")")end end end end
GUI_Interaction.DisplayQuestObjective_Orig_BundleInteractiveObjects=GUI_Interaction.DisplayQuestObjective
GUI_Interaction.DisplayQuestObjective=function(CX,jDZXa)
local EPUGlx=Network.GetDesiredLanguage()if EPUGlx~="de"then EPUGlx="en"end;local crhDlmpf=tonumber(CX)if crhDlmpf then
CX=crhDlmpf end
local xCsyl,FjXjP6e3=GUI_Interaction.GetPotentialSubQuestAndType(CX)local Gwx="/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives"
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)local SkwF1W03;local rqPmvfY;local OMDEiK=Quests[CX]local DA39ke;if
OMDEiK~=nil and type(OMDEiK)=="table"then DA39ke=OMDEiK.Identifier end;local nX={}
g_CurrentDisplayedQuestID=CX
if FjXjP6e3 ==Objective.Object then SkwF1W03=Gwx.."/List"
rqPmvfY=Wrapped_GetStringTableText(CX,"UI_Texts/QuestInteraction")local l_={}
for cmh4WHmm=1,xCsyl.Objectives[1].Data[0]do local _m65G
if
Logic.IsEntityDestroyed(xCsyl.Objectives[1].Data[cmh4WHmm])then
_m65G=g_Interaction.SavedQuestEntityTypes[CX][cmh4WHmm]else
_m65G=Logic.GetEntityType(GetEntityId(xCsyl.Objectives[1].Data[cmh4WHmm]))end
local H=Logic.GetEntityName(xCsyl.Objectives[1].Data[cmh4WHmm])local BEW2=""
if _m65G~=0 then local L=Logic.GetEntityTypeName(_m65G)BEW2=Wrapped_GetStringTableText(CX,
"Names/"..L)
if BEW2 ==""then BEW2=Wrapped_GetStringTableText(CX,
"UI_ObjectNames/"..L)end
if BEW2 ==""then
BEW2=BundleInteractiveObjects.Local.Data.IOCustomNames[L]if type(BEW2)=="table"then local EPUGlx=Network.GetDesiredLanguage()EPUGlx=(
EPUGlx=="de"and"de")or"en"
BEW2=BEW2[EPUGlx]end end
if BEW2 ==""then
BEW2=BundleInteractiveObjects.Local.Data.IOCustomNames[H]if type(BEW2)=="table"then local EPUGlx=Network.GetDesiredLanguage()EPUGlx=(
EPUGlx=="de"and"de")or"en"
BEW2=BEW2[EPUGlx]end end
if BEW2 ==""then BEW2="Debug: ObjectName missing for "..L end end;table.insert(l_,BEW2)end;for NqHMxq=1,4 do local Hf7Gu5=l_[NqHMxq]if Hf7Gu5 ==nil then Hf7Gu5=""end
XGUIEng.SetText(SkwF1W03 ..
"/Entry"..NqHMxq,"{center}"..Hf7Gu5)end;SetIcon(
SkwF1W03 .."/QuestTypeIcon",{14,10})
XGUIEng.SetText(
SkwF1W03 .."/Caption","{center}"..rqPmvfY)XGUIEng.ShowWidget(SkwF1W03,1)else
GUI_Interaction.DisplayQuestObjective_Orig_BundleInteractiveObjects(CX,jDZXa)end end end
function BundleInteractiveObjects.Local:TextCosts(N1yyVsQ,SG,w4ABWuCz,W,c)
local u2kefvo="/InGame/Root/Normal/TooltipBuy"local A5omZ27=XGUIEng.GetWidgetID(u2kefvo)
local yHY=XGUIEng.GetWidgetID(u2kefvo.."/FadeIn/Name")
local Sx7=XGUIEng.GetWidgetID(u2kefvo.."/FadeIn/Text")
local Mbe8K6N=XGUIEng.GetWidgetID(u2kefvo.."/FadeIn/BG")local aTW=XGUIEng.GetWidgetID(u2kefvo.."/FadeIn")local jgBMAEKw=XGUIEng.GetWidgetID(
u2kefvo.."/Costs")
local BYV2=XGUIEng.GetCurrentWidgetID()GUI_Tooltip.ResizeBG(Mbe8K6N,Sx7)
GUI_Tooltip.SetCosts(jgBMAEKw,W,c)local hhR7={A5omZ27,jgBMAEKw,Mbe8K6N}
GUI_Tooltip.SetPosition(A5omZ27,hhR7,BYV2,nil,true)
GUI_Tooltip.OrderTooltip(hhR7,aTW,jgBMAEKw,BYV2,Mbe8K6N)GUI_Tooltip.FadeInTooltip(aTW)
w4ABWuCz=w4ABWuCz or""local P=""if
XGUIEng.IsButtonDisabled(BYV2)==1 and w4ABWuCz~=""and SG~=""then
P=P.."{cr}{@color:255,32,32,255}"..w4ABWuCz end;XGUIEng.SetText(yHY,"{center}"..
N1yyVsQ)
XGUIEng.SetText(Sx7,SG..P)local HNa=XGUIEng.GetTextHeight(Sx7,true)
local hb,W0=XGUIEng.GetWidgetSize(Sx7)XGUIEng.SetWidgetSize(Sx7,hb,HNa)end
function BundleInteractiveObjects.Local:SetIcon(OylG,a)
if type(a)=="table"then
if type(a[3])==
"string"then local JwdcLX=1
if XGUIEng.IsButton(OylG)==1 then JwdcLX=7 end;local doE4,e5,fEQrY,fzXTuklV;doE4=(a[1]-1)*64;fEQrY=(a[2]-1)*64;e5=
(a[1])*64;fzXTuklV=(a[2])*64
XGUIEng.SetMaterialAlpha(OylG,JwdcLX,255)
XGUIEng.SetMaterialTexture(OylG,JwdcLX,a[3].."big.png")
XGUIEng.SetMaterialUV(OylG,JwdcLX,doE4,fEQrY,e5,fzXTuklV)else SetIcon(OylG,a)end else local __={GUI.GetScreenSize()}local xU=330
if __[2]>=800 then xU=260 end;if __[2]>=1000 then xU=210 end
XGUIEng.SetMaterialAlpha(OylG,1,255)XGUIEng.SetMaterialTexture(OylG,1,_file)
XGUIEng.SetMaterialUV(OylG,1,0,0,xU,xU)end end;Core:RegisterBundle("BundleInteractiveObjects")function Goal_ActivateSeveralObjects(...)return
b_Goal_ActivateSeveralObjects:new(...)end
b_Goal_ActivateSeveralObjects={Name="Goal_ActivateSeveralObjects",Description={en="Goal: Activate an interactive object",de="Ziel: Aktiviere ein interaktives Objekt"},Parameter={{ParameterType.ScriptName,en="Object name 1",de="Skriptname 1"},{ParameterType.ScriptName,en="Object name 2",de="Skriptname 2"},{ParameterType.ScriptName,en="Object name 3",de="Skriptname 3"},{ParameterType.ScriptName,en="Object name 4",de="Skriptname 4"}},ScriptNames={}}
function b_Goal_ActivateSeveralObjects:GetGoalTable()return
{Objective.Object,{unpack(self.ScriptNames)}}end
function b_Goal_ActivateSeveralObjects:AddParameter(nYlRfo_,f3m)if nYlRfo_==0 then
assert(f3m~=nil and f3m~="","Goal_ActivateSeveralObjects: At least one IO needed!")end
if
f3m~=nil and f3m~=""then table.insert(self.ScriptNames,f3m)end end
function b_Goal_ActivateSeveralObjects:GetMsgKey()return"Quest_Object_Activate"end
Core:RegisterBehavior(b_Goal_ActivateSeveralObjects)BundleInterfaceApperance={}API=API or{}QSB=QSB or{}QSB.PlayerNames={}
function API.InterfaceHideMinimap(E4kGC_z)if
not GUI then
Logic.ExecuteInLuaLocalState("API.InterfaceHideMinimap("..tostring(E4kGC_z)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/Minimap/MinimapOverlay",E4kGC_z)
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/Minimap/MinimapTerrain",E4kGC_z)end
function API.InterfaceHideToggleMinimap(zD1DMP4)if not GUI then
Logic.ExecuteInLuaLocalState("API.InterfaceHideToggleMinimap("..
tostring(zD1DMP4)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/MinimapButton",zD1DMP4)end
function API.InterfaceHideDiplomacyMenu(kr8oA)if not GUI then
Logic.ExecuteInLuaLocalState("API.InterfaceHideDiplomacyMenu("..
tostring(kr8oA)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/DiplomacyMenuButton",kr8oA)end
function API.InterfaceHideProductionMenu(_Bd)if not GUI then
Logic.ExecuteInLuaLocalState("API.InterfaceHideProductionMenu("..
tostring(_Bd)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/ProductionMenuButton",_Bd)end
function API.InterfaceHideWeatherMenu(M)if not GUI then
Logic.ExecuteInLuaLocalState("API.InterfaceHideWeatherMenu("..tostring(M)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/WeatherMenuButton",M)end
function API.InterfaceHideBuyTerritory(Nshu)if not GUI then
Logic.ExecuteInLuaLocalState("API.InterfaceHideBuyTerritory("..
tostring(Nshu)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Knight/ClaimTerritory",Nshu)end
function API.InterfaceHideKnightAbility(Ww8cAf)if not GUI then
Logic.ExecuteInLuaLocalState("API.InterfaceHideKnightAbility("..
tostring(Ww8cAf)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Knight/StartAbilityProgress",Ww8cAf)
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/DialogButtons/Knight/StartAbility",Ww8cAf)end
function API.InterfaceHideKnightButton(K0)if not GUI then
Logic.ExecuteInLuaLocalState("API.InterfaceHideKnightButton("..tostring(K0)..")")return end
local _wMF=Logic.GetKnightID(GUI.GetPlayerID())
if K0 ==true then
GUI.SendScriptCommand("Logic.SetEntitySelectableFlag(".._wMF..", 0)")GUI.DeselectEntity(_wMF)else
GUI.SendScriptCommand("Logic.SetEntitySelectableFlag("..
_wMF..", 1)")end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/KnightButtonProgress",K0)
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/KnightButton",K0)end
function API.InterfaceHideSelectionButton(YUjlt)if not GUI then
Logic.ExecuteInLuaLocalState("API.InterfaceHideSelectionButton("..
tostring(YUjlt)..")")return end
API.InterfaceHideKnightButton(YUjlt)GUI.ClearSelection()
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/MapFrame/BattalionButton",YUjlt)end
function API.InterfaceHideBuildMenu(APwub54n)if not GUI then
Logic.ExecuteInLuaLocalState("API.InterfaceHideBuildMenu("..
tostring(APwub54n)..")")return end
BundleInterfaceApperance.Local:HideInterfaceButton("/InGame/Root/Normal/AlignBottomRight/BuildMenu",APwub54n)end;function API.InterfaceSetTexture(R46tO,gapFs5Q5)if not GUI then return end
BundleInterfaceApperance.Local:SetTexture(R46tO,gapFs5Q5)end
UserSetTexture=API.InterfaceSetTexture
function API.InterfaceSetIcon(yHyNgdS,uHxlpQZ,VWioVI,egMrVf6)if not GUI then return end
BundleInterfaceApperance.Local:SetIcon(yHyNgdS,uHxlpQZ,VWioVI,egMrVf6)end;UserSetIcon=API.InterfaceSetIcon
function API.InterfaceSetTooltipNormal(jYZW,a8U7It,G0Ovhyy)if not GUI then return end
BundleInterfaceApperance.Local:TextNormal(jYZW,a8U7It,G0Ovhyy)end;UserSetTextNormal=API.InterfaceSetTooltipNormal
function API.InterfaceSetTooltipCosts(__mhh7,jCM5O,IllGvUus,ik41DzF,wSb2g8k)
if not GUI then return end
BundleInterfaceApperance.Local:TextCosts(__mhh7,jCM5O,IllGvUus,ik41DzF,wSb2g8k)end;UserSetTextBuy=API.InterfaceSetTooltipCosts
function API.InterfaceGetTerritoryName(kAJi)
local UUACpgc=Logic.GetTerritoryName(kAJi)local H=Framework.GetCurrentMapTypeAndCampaignName()if
H==1 or H==3 then return UUACpgc end
local YTFMRfY=Framework.GetCurrentMapName()local hb="Map_"..YTFMRfY;local mip65=string.gsub(UUACpgc," ","")
mip65=XGUIEng.GetStringTableText(
hb.."/Territory_"..mip65)if mip65 ==""then mip65=UUACpgc.."(key?)"end;return mip65 end;GetTerritoryName=API.InterfaceGetTerritoryName
function API.InterfaceGetPlayerName(hhTu)
local GH85Le1=Logic.GetPlayerName(hhTu)local GJzJirs=QSB.PlayerNames[hhTu]if GJzJirs~=nil and GJzJirs~=""then
GH85Le1=GJzJirs end
local wj=Framework.GetCurrentMapTypeAndCampaignName()
local eI=Framework.GetMultiplayerMapMode(Framework.GetCurrentMapName(),wj)if eI>0 then return GH85Le1 end
if wj==1 or wj==3 then
local _,Tiw,h6T=Framework.GetPlayerInfo(hhTu)if GH85Le1 ~=""then return GH85Le1 end;return _ end end;GetPlayerName_OrigName=GetPlayerName
GetPlayerName=API.InterfaceGetPlayerName
function API.InterfaceSetPlayerName(oXCh7KM,G8P)
assert(type(oXCh7KM)=="number")assert(type(G8P)=="string")
if not GUI then
Logic.ExecuteInLuaLocalState(
"SetPlayerName("..oXCh7KM..",'"..G8P.."')")else GUI_MissionStatistic.PlayerNames[oXCh7KM]=G8P
GUI.SendScriptCommand(
"QSB.PlayerNames["..oXCh7KM.."] = '"..G8P.."'")end;QSB.PlayerNames[oXCh7KM]=G8P end;SetPlayerName=API.InterfaceSetPlayerName
function API.InterfaceSetPlayerColor(LqWKj8t,QN,nF,PXyZ9Qy2)if GUI then return end
g_ColorIndex["ExtraColor1"]=16;g_ColorIndex["ExtraColor2"]=17;local chR4IJ1y=type(QN)
local Z3w=(
type(QN)=="string"and g_ColorIndex[QN])or QN;local QxqW7=nF or-1;local HoLC1F=PXyZ9Qy2 or-1
StartSimpleJobEx(function(Z3w,LqWKj8t,nF,PXyZ9Qy2)
Logic.PlayerSetPlayerColor(LqWKj8t,Z3w,nF,PXyZ9Qy2)return true end,Z3w,LqWKj8t,QxqW7,HoLC1F)end
function API.InterfaceSetPlayerPortrait(LGdKF6YB,_IUL1CGx)
if

not LGdKF6YB or type(LGdKF6YB)~="number"or(LGdKF6YB<1 or LGdKF6YB>8)then
API.Fatal("API.InterfaceSetPlayerPortrait: Invalid player ID!")return end
if not GUI then local qih=
(_IUL1CGx~=nil and"'".._IUL1CGx.."'")or"nil"
API.Bridge(
"API.InterfaceSetPlayerPortrait("..LGdKF6YB..", "..qih..")")return end;if _IUL1CGx==nil then
BundleInterfaceApperance.Local:SetPlayerPortraitByPrimaryKnight(LGdKF6YB)return end;if _IUL1CGx~=nil and
IsExisting(_IUL1CGx)then
BundleInterfaceApperance.Local:SetPlayerPortraitBySettler(LGdKF6YB,_IUL1CGx)return end
BundleInterfaceApperance.Local:SetPlayerPortraitByModelName(LGdKF6YB,_IUL1CGx)end
BundleInterfaceApperance={Global={},Local={Data={HiddenWidgets={}}}}function BundleInterfaceApperance.Global:Install()
API.AddSaveGameAction(BundleInterfaceApperance.Global.RestoreAfterLoad)end
function BundleInterfaceApperance.Global.RestoreAfterLoad()
Logic.ExecuteInLuaLocalState([[
        BundleInterfaceApperance.Local:RestoreAfterLoad();
    ]])end
function BundleInterfaceApperance.Local:Install()
StartMissionGoodOrEntityCounter=function(Mf,rIuZsr4Q)
if
type(Mf)=="string"then
BundleInterfaceApperance.Local:SetTexture("/InGame/Root/Normal/MissionGoodOrEntityCounter/Icon",Mf)else
if type(Mf[3])=="string"then
BundleInterfaceApperance.Local:SetIcon("/InGame/Root/Normal/MissionGoodOrEntityCounter/Icon",Mf,64,Mf[3])else
SetIcon("/InGame/Root/Normal/MissionGoodOrEntityCounter/Icon",Mf)end end;g_MissionGoodOrEntityCounterAmountToReach=rIuZsr4Q
g_MissionGoodOrEntityCounterIcon=Mf
XGUIEng.ShowWidget("/InGame/Root/Normal/MissionGoodOrEntityCounter",1)end
GUI_Knight.ClaimTerritoryUpdate_Orig_QSB_InterfaceApperance=GUI_Knight.ClaimTerritoryUpdate
GUI_Knight.ClaimTerritoryUpdate=function()
local n1tB="/InGame/Root/Normal/AlignBottomRight/DialogButtons/Knight/ClaimTerritory"if
BundleInterfaceApperance.Local.Data.HiddenWidgets[n1tB]==true then
BundleInterfaceApperance.Local:HideInterfaceButton(n1tB,true)end
GUI_Knight.ClaimTerritoryUpdate_Orig_QSB_InterfaceApperance()end end
function BundleInterfaceApperance.Local:SetPlayerPortraitByPrimaryKnight(p)
local rUtt=Logic.GetKnightID(p)if rUtt==0 then return end;local vwS=Logic.GetEntityType(rUtt)
local vq=Logic.GetEntityTypeName(vwS)
local OybL="H"..string.sub(vq,2,8).."_"..string.sub(vq,9)
if not Models["Heads_"..OybL]then OybL="H_NPC_Generic_Trader"end;g_PlayerPortrait[p]=OybL end
function BundleInterfaceApperance.Local:SetPlayerPortraitBySettler(fJPyS,PrnXi_)
local UuHyyB={["U_KnightChivalry"]="H_Knight_Chivalry",["U_KnightHealing"]="H_Knight_Healing",["U_KnightPlunder"]="H_Knight_Plunder",["U_KnightRedPrince"]="H_Knight_RedPrince",["U_KnightSabatta"]="H_Knight_Sabatt",["U_KnightSong"]="H_Knight_Song",["U_KnightTrading"]="H_Knight_Trading",["U_KnightWisdom"]="H_Knight_Wisdom",["U_NPC_Amma_NE"]="H_NPC_Amma",["U_NPC_Castellan_ME"]="H_NPC_Castellan_ME",["U_NPC_Castellan_NA"]="H_NPC_Castellan_NA",["U_NPC_Castellan_NE"]="H_NPC_Castellan_NE",["U_NPC_Castellan_SE"]="H_NPC_Castellan_SE",["U_MilitaryBandit_Ranged_ME"]="H_NPC_Mercenary_ME",["U_MilitaryBandit_Melee_NA"]="H_NPC_Mercenary_NA",["U_MilitaryBandit_Melee_NE"]="H_NPC_Mercenary_NE",["U_MilitaryBandit_Melee_SE"]="H_NPC_Mercenary_SE",["U_NPC_Monk_ME"]="H_NPC_Monk_ME",["U_NPC_Monk_NA"]="H_NPC_Monk_NA",["U_NPC_Monk_NE"]="H_NPC_Monk_NE",["U_NPC_Monk_SE"]="H_NPC_Monk_SE",["U_NPC_Villager01_ME"]="H_NPC_Villager01_ME",["U_NPC_Villager01_NA"]="H_NPC_Villager01_NA",["U_NPC_Villager01_NE"]="H_NPC_Villager01_NE",["U_NPC_Villager01_SE"]="H_NPC_Villager01_SE"}
if g_GameExtraNo>0 then UuHyyB["U_KnightPraphat"]="H_Knight_Praphat"
UuHyyB["U_KnightSaraya"]="H_Knight_Saraya"UuHyyB["U_KnightKhana"]="H_Knight_Khana"
UuHyyB["U_MilitaryBandit_Melee_AS"]="H_NPC_Mercenary_AS"UuHyyB["U_NPC_Castellan_AS"]="H_NPC_Castellan_AS"
UuHyyB["U_NPC_Villager_AS"]="H_NPC_Villager_AS"UuHyyB["U_NPC_Monk_AS"]="H_NPC_Monk_AS"
UuHyyB["U_NPC_Monk_Khana"]="H_NPC_Monk_Khana"end;local R5fp="H_NPC_Generic_Trader"local Klh5k=GetID(PrnXi_)
if Klh5k~=0 then
local v=Logic.GetEntityType(Klh5k)local Ea8=Logic.GetEntityTypeName(v)
R5fp=UuHyyB[Ea8]or"H_NPC_Generic_Trader"if not R5fp then R5fp="H_NPC_Generic_Trader"end end;g_PlayerPortrait[fJPyS]=R5fp end
function BundleInterfaceApperance.Local:SetPlayerPortraitByModelName(M,yp)
if not
Models["Heads_"..tostring(yp)]then yp="H_NPC_Generic_Trader"end;g_PlayerPortrait[M]=yp end
function BundleInterfaceApperance.Local:HideInterfaceButton(G,ez5ySfaV)self.Data.HiddenWidgets[G]=
ez5ySfaV==true;XGUIEng.ShowWidget(G,
(ez5ySfaV==true and 0)or 1)end
function BundleInterfaceApperance.Local:RestoreAfterLoad()
for v5e8z,me in
pairs(self.Data.HiddenWidgets)do if me then XGUIEng.ShowWidget(v5e8z,0)end end end
function BundleInterfaceApperance.Local:SetTexture(HW,DjwuJhxD)
assert((type(HW)=="string"or
type(HW)=="number"))local tNg9=
(type(HW)=="string"and XGUIEng.GetWidgetID(HW))or HW
local Tj29={GUI.GetScreenSize()}local M09bv9P=1
if XGUIEng.IsButton(tNg9)==1 then M09bv9P=7 end;local v7=330;if Tj29[2]>=800 then v7=260 end
if Tj29[2]>=1000 then v7=210 end;XGUIEng.SetMaterialAlpha(tNg9,M09bv9P,255)
XGUIEng.SetMaterialTexture(tNg9,M09bv9P,DjwuJhxD)XGUIEng.SetMaterialUV(tNg9,M09bv9P,0,0,v7,v7)end
function BundleInterfaceApperance.Local:SetIcon(x,LK9rp92,p08_9,obwuv)
if obwuv==nil then obwuv="usericons"end;if p08_9 ==nil then p08_9=64 end
if p08_9 ==44 then obwuv=obwuv..".png"end;if p08_9 ==64 then obwuv=obwuv.."big.png"end;if p08_9 ==128 then obwuv=obwuv..
"verybig.png"end;local HP394cUA,tpOc,xo,e;HP394cUA=
(LK9rp92[1]-1)*p08_9
xo=(LK9rp92[2]-1)*p08_9;tpOc=(LK9rp92[1])*p08_9
e=(LK9rp92[2])*p08_9;State=1;if XGUIEng.IsButton(x)==1 then State=7 end
XGUIEng.SetMaterialAlpha(x,State,255)XGUIEng.SetMaterialTexture(x,State,obwuv)
XGUIEng.SetMaterialUV(x,State,HP394cUA,xo,tpOc,e)end
function BundleInterfaceApperance.Local:TextNormal(qUsr,Tt,XU)
local ZaQ=Network.GetDesiredLanguage()if ZaQ~="de"then ZaQ="en"end
if type(qUsr)=="table"then qUsr=qUsr[ZaQ]end;if type(Tt)=="table"then Tt=Tt[ZaQ]end;Tt=Tt or""if
type(XU)=="table"then XU=XU[ZaQ]end;local QC="/InGame/Root/Normal/TooltipNormal"
local B_=XGUIEng.GetWidgetID(QC)local e=XGUIEng.GetWidgetID(QC.."/FadeIn/Name")local F1X=XGUIEng.GetWidgetID(
QC.."/FadeIn/Text")local CWsjs=XGUIEng.GetWidgetID(
QC.."/FadeIn/BG")local oC=XGUIEng.GetWidgetID(QC..
"/FadeIn")
local f=XGUIEng.GetCurrentWidgetID()GUI_Tooltip.ResizeBG(CWsjs,F1X)local xd29wlH={CWsjs}
GUI_Tooltip.SetPosition(B_,xd29wlH,f)GUI_Tooltip.FadeInTooltip(oC)XU=XU or""local riA7=""
if
XGUIEng.IsButtonDisabled(f)==1 and XU~=""and Tt~=""then riA7=
riA7 .."{cr}{@color:255,32,32,255}"..XU end;XGUIEng.SetText(e,"{center}"..qUsr)XGUIEng.SetText(F1X,Tt..
riA7)
local uwKHRXC=XGUIEng.GetTextHeight(F1X,true)local uPwhsbyt,VM5=XGUIEng.GetWidgetSize(F1X)
XGUIEng.SetWidgetSize(F1X,uPwhsbyt,uwKHRXC)end
function BundleInterfaceApperance.Local:TextCosts(JjCT,D,rLSWV,Web2WQ7,F)
local C66ukx5a=Network.GetDesiredLanguage()if C66ukx5a~="de"then C66ukx5a="en"end;Web2WQ7=Web2WQ7 or{}if
type(JjCT)=="table"then JjCT=JjCT[C66ukx5a]end;if
type(D)=="table"then D=D[C66ukx5a]end;D=D or""if type(rLSWV)=="table"then
rLSWV=rLSWV[C66ukx5a]end;local L7ua9g_="/InGame/Root/Normal/TooltipBuy"
local S=XGUIEng.GetWidgetID(L7ua9g_)
local Ki=XGUIEng.GetWidgetID(L7ua9g_.."/FadeIn/Name")
local eKjBW=XGUIEng.GetWidgetID(L7ua9g_.."/FadeIn/Text")
local bd5inx2i=XGUIEng.GetWidgetID(L7ua9g_.."/FadeIn/BG")
local UtP06XAU=XGUIEng.GetWidgetID(L7ua9g_.."/FadeIn")local a7zN7=XGUIEng.GetWidgetID(L7ua9g_.."/Costs")
local MFsC_GMt=XGUIEng.GetCurrentWidgetID()GUI_Tooltip.ResizeBG(bd5inx2i,eKjBW)
GUI_Tooltip.SetCosts(a7zN7,Web2WQ7,F)local Q0_OBYt={S,a7zN7,bd5inx2i}
GUI_Tooltip.SetPosition(S,Q0_OBYt,MFsC_GMt,nil,true)
GUI_Tooltip.OrderTooltip(Q0_OBYt,UtP06XAU,a7zN7,MFsC_GMt,bd5inx2i)GUI_Tooltip.FadeInTooltip(UtP06XAU)
rLSWV=rLSWV or""local wUukx=""if
XGUIEng.IsButtonDisabled(MFsC_GMt)==1 and rLSWV~=""and D~=""then
wUukx=wUukx.."{cr}{@color:255,32,32,255}"..rLSWV end;XGUIEng.SetText(Ki,
"{center}"..JjCT)
XGUIEng.SetText(eKjBW,D..wUukx)local qpF=XGUIEng.GetTextHeight(eKjBW,true)
local QLdWNEL4,uVkik8Nw=XGUIEng.GetWidgetSize(eKjBW)XGUIEng.SetWidgetSize(eKjBW,QLdWNEL4,qpF)end;Core:RegisterBundle("BundleInterfaceApperance")
BundlePlayerHelperFunctions={}API=API or{}QSB=QSB or{}
function API.UndiscoverTerritory(hnR6,tMsQhj)if GUI then
API.Bridge("API.UndiscoverTerritory("..hnR6 ..", "..
tMsQhj..")")return end;return
BundlePlayerHelperFunctions.Global:UndiscoverTerritory(hnR6,tMsQhj)end;UndiscoverTerritory=API.UndiscoverTerritory
function API.UndiscoverTerritories(W_8N3,baUwKBHt)if GUI then
API.Bridge(
"API.UndiscoverTerritories("..W_8N3 ..", "..baUwKBHt..")")return end;return
BundlePlayerHelperFunctions.Global:UndiscoverTerritories(W_8N3,baUwKBHt)end;UndiscoverTerritories=API.UndiscoverTerritories
function API.SetEarningsOfPlayerCity(j,p)if GUI then
API.Bridge(
"API.SetEarningsOfPlayerCity("..j..", "..p..")")return end;if j~=-1 and
Logic.GetStoreHouse(j)==0 then
API.Fatal("API.SetEarningsOfPlayerCity: Player "..j.." is dead! :(")return end;if p==nil or(p<0 or
p>100)then
API.Fatal("API.SetEarningsOfPlayerCity: _Earnings must be between 0 and 100!")return end;return
BundlePlayerHelperFunctions.Global:SetEarningsOfPlayerCity(j,p)end;SetPlayerEarnings=API.SetEarningsOfPlayerCity
function API.SetNeedSatisfaction(fVpzAa,b76KzY,Pslyt9l8)if GUI then
API.Bridge(
"API.SetNeedSatisfaction("..
fVpzAa..", "..b76KzY..", "..Pslyt9l8 ..")")return end;if Pslyt9l8 ~=-1 and
Logic.GetStoreHouse(Pslyt9l8)==0 then
API.Fatal("API.SetNeedSatisfaction: Player "..Pslyt9l8 ..
" is dead! :(")return end;if
b76KzY<0 or b76KzY>1 then
API.Fatal("API.SetNeedSatisfaction: _State must be between 0 and 1!")return end;return
BundlePlayerHelperFunctions.Global:SetNeedSatisfactionLevel(fVpzAa,b76KzY,Pslyt9l8)end;SetNeedSatisfactionLevel=API.SetNeedSatisfaction
function API.UnlockTitleForPlayer(tE2CiFB,aQdNx)if GUI then
API.Bridge(
"API.UnlockTitleForPlayer("..tE2CiFB..", "..aQdNx..")")return end;return
BundlePlayerHelperFunctions.Global:UnlockTitleForPlayer(tE2CiFB,aQdNx)end;UnlockTitleForPlayer=API.UnlockTitleForPlayer
function API.StartNormalFestival(kgeSZw7)if GUI then
API.Bridge(
"API.StartNormalFestival("..kgeSZw7 ..")")return end
BundlePlayerHelperFunctions.Global:RestrictFestivalForPlayer(kgeSZw7,0,false)Logic.StartFestival(kgeSZw7,0)end;StartNormalFestival=API.StartNormalFestival
function API.StartCityUpgradeFestival(QJ5ho3)if GUI then
API.Bridge(
"API.StartCityUpgradeFestival("..QJ5ho3 ..")")return end
BundlePlayerHelperFunctions.Global:RestrictFestivalForPlayer(QJ5ho3,1,false)Logic.StartFestival(QJ5ho3,1)end;StartCityUpgradeFestival=API.StartCityUpgradeFestival
function API.ForbidFestival(PJrObx_P)if GUI then
API.Bridge(
"API.ForbidFestival("..PJrObx_P..")")return end
local graOv=Logic.GetKnightTitle(PJrObx_P)local pf=Technologies.R_Festival;local sANN=TechnologyStates.Locked;if
KnightTitleNeededForTechnology[pf]==nil or
graOv>=KnightTitleNeededForTechnology[pf]then
sANN=TechnologyStates.Prohibited end
Logic.TechnologySetState(PJrObx_P,pf,sANN)
BundlePlayerHelperFunctions.Global:RestrictFestivalForPlayer(PJrObx_P,0,true)
API.Bridge("BundlePlayerHelperFunctions.Local.Data.NormalFestivalLockedForPlayer["..PJrObx_P.."] = true")end;ForbidFestival=API.ForbidFestival
function API.AllowFestival(NshB)if GUI then
API.Bridge("API.AllowFestival("..NshB..")")return end
BundlePlayerHelperFunctions.Global:RestrictFestivalForPlayer(NshB,0,false)local gla9=Logic.GetKnightTitle(NshB)
local zAP=Technologies.R_Festival;local lWk6cfui=TechnologyStates.Unlocked;if KnightTitleNeededForTechnology[zAP]==
nil or
gla9 >=KnightTitleNeededForTechnology[zAP]then
lWk6cfui=TechnologyStates.Researched end
Logic.TechnologySetState(NshB,zAP,lWk6cfui)
API.Bridge("BundlePlayerHelperFunctions.Local.Data.NormalFestivalLockedForPlayer["..NshB.."] = false")end;AllowFestival=API.AllowFestival
function API.SetControllingPlayer(V_,dxizE,Ize7j0g0,yafK8Ew)if GUI then
API.Bridge("API.SetControllingPlayer("..
V_..", "..dxizE..
", '"..
Ize7j0g0 .."', "..tostring(yafK8Ew)..")")return end;return
BundlePlayerHelperFunctions.Global:SetControllingPlayer(V_,dxizE,Ize7j0g0,yafK8Ew)end;PlayerSetPlayerID=API.SetControllingPlayer
function API.GetControllingPlayer()
if not GUI then return
BundlePlayerHelperFunctions.Global:GetControllingPlayer()else return GUI.GetPlayerID()end end;PlayerGetPlayerID=API.GetControllingPlayer
BundlePlayerHelperFunctions={Global={Data={FestivalBlacklist={},DiscoveredTerritories={}}},Local={Data={NormalFestivalLockedForPlayer={}}}}function BundlePlayerHelperFunctions.Global:Install()
API.AddSaveGameAction(BundlePlayerHelperFunctions.Global.OnSaveGameLoaded)end
function BundlePlayerHelperFunctions.Global:InitFestival()if
not Logic.StartFestival_Orig_NothingToCelebrate then
Logic.StartFestival_Orig_NothingToCelebrate=Logic.StartFestival end
Logic.StartFestival=function(ii7in,QXk)
if
BundlePlayerHelperFunctions.Global.Data.FestivalBlacklist[ii7in]then if
BundlePlayerHelperFunctions.Global.Data.FestivalBlacklist[ii7in][QXk]then return end end
Logic.StartFestival_Orig_NothingToCelebrate(ii7in,QXk)end end
function BundlePlayerHelperFunctions.Global:UndiscoverTerritory(R,qpsZ)if
self.Data.DiscoveredTerritories[R]==nil then
self.Data.DiscoveredTerritories[R]={}end
for JyAkBP0=1,#
self.Data.DiscoveredTerritories[R],1 do if
self.Data.DiscoveredTerritories[R][JyAkBP0]==qpsZ then
table.remove(self.Data.DiscoveredTerritories[R],JyAkBP0)break end end end
function BundlePlayerHelperFunctions.Global:UndiscoverTerritories(InI0A81,Gnov)if
self.Data.DiscoveredTerritories[InI0A81]==nil then
self.Data.DiscoveredTerritories[InI0A81]={}end;local ZWUH={}
for pU4,lCSrBk50 in
pairs(self.Data.DiscoveredTerritories[InI0A81])do local mQNlZ8=Logic.GetTerritoryPlayerID(lCSrBk50)if mQNlZ8 ~=Gnov then
table.insert(ZWUH,lCSrBk50)break end end
self.Data.DiscoveredTerritories[InI0A81][i]=ZWUH end
function BundlePlayerHelperFunctions.Global:SetEarningsOfPlayerCity(xFFgd,ZxITO_fD)
if xFFgd==-1 then for CQ=1,8,1 do
self:SetEarningsOfPlayerCity(CQ,ZxITO_fD)end else
local ZAr={Logic.GetPlayerEntitiesInCategory(xFFgd,EntityCategories.CityBuilding)}for qvUP8U1k=1,#ZAr,1 do
Logic.SetBuildingEarnings(ZAr[qvUP8U1k],ZxITO_fD)end end end
function BundlePlayerHelperFunctions.Global:SetNeedSatisfactionLevel(u9LBzZsg,y6xsF,r)
if r==-1 then for Np330=1,8,1 do
self:SetNeedSatisfactionLevel(u9LBzZsg,y6xsF,Np330)end else
local _IsgSo={Logic.GetPlayerEntitiesInCategory(r,EntityCategories.CityBuilding)}
if
u9LBzZsg==Needs.Nutrition or u9LBzZsg==Needs.Medicine then
local C1P6Qd={Logic.GetPlayerEntitiesInCategory(r,EntityCategories.OuterRimBuilding)}_IsgSo=Array_Append(_IsgSo,C1P6Qd)end
for F=1,#_IsgSo,1 do if Logic.IsNeedActive(_IsgSo[F],u9LBzZsg)then
Logic.SetNeedState(_IsgSo[F],u9LBzZsg,y6xsF)end end end end
function BundlePlayerHelperFunctions.Global:UnlockTitleForPlayer(_2WxAKPU,Lybo)
if
LockedKnightTitles[_2WxAKPU]==Lybo then LockedKnightTitles[_2WxAKPU]=nil
for k5cR3U=Lybo,#
NeedsAndRightsByKnightTitle do
local F0=NeedsAndRightsByKnightTitle[k5cR3U][4]
if F0 ~=nil then for uPIimV0z=1,#F0 do local cYStp_4=F0[uPIimV0z]
Logic.TechnologySetState(_2WxAKPU,cYStp_4,TechnologyStates.Unlocked)end end end end end
function BundlePlayerHelperFunctions.Global:RestrictFestivalForPlayer(FLi,EvKpTl,TyhuymW)
self:InitFestival()if not self.Data.FestivalBlacklist[FLi]then
self.Data.FestivalBlacklist[FLi]={}end;self.Data.FestivalBlacklist[FLi][EvKpTl]=
TyhuymW==true end
function BundlePlayerHelperFunctions.Global:SetControllingPlayer(j0Fw8,W,pB7SCmX,m6)
assert(type(j0Fw8)=="number")assert(type(W)=="number")pB7SCmX=pB7SCmX or""m6=
(m6 and true)or false;local M1,_vwx,iQt5Tf
if m6 then
M1=Logic.GetKnightID(j0Fw8)_vwx=Logic.GetEntityName(M1)
iQt5Tf=Logic.GetEntityType(M1)Logic.ChangeEntityPlayerID(M1,W)
Logic.SetPrimaryKnightID(W,GetID(_vwx))else M1=Logic.GetKnightID(W)_vwx=Logic.GetEntityName(M1)
iQt5Tf=Logic.GetEntityType(M1)end;Logic.PlayerSetIsHumanFlag(j0Fw8,0)
Logic.PlayerSetIsHumanFlag(W,1)Logic.PlayerSetGameStateToPlaying(W)
self.Data.HumanKnightType=iQt5Tf;self.Data.HumanPlayerID=W
GameCallback_PlayerLost=function(U1G)
if
U1G==self:GetControllingPlayer()then QuestTemplate:TerminateEventsAndStuff()
if
MissionCallback_Player1Lost then MissionCallback_Player1Lost()end end end
Logic.ExecuteInLuaLocalState([[
        GUI.ClearSelection()
        GUI.SetControlledPlayer(]]..
W..

[[)

        for k,v in pairs(Buffs)do
            GUI_Buffs.UpdateBuffsInInterface(]]..
W..

[[,v)
            GUI.ResetMiniMap()
        end

        if IsExisting(Logic.GetKnightID(GUI.GetPlayerID())) then
            local portrait = GetKnightActor(]]..
iQt5Tf..
[[)
            g_PlayerPortrait[GUI.GetPlayerID()] = portrait
            LocalSetKnightPicture()
        end

        local newName = "]]..

pB7SCmX..

[["
        if newName ~= "" then
            GUI_MissionStatistic.PlayerNames[GUI.GetPlayerID()] = newName
        end
        HideOtherMenus()

        function GUI_Knight.GetTitleNameByTitleID(_KnightType, _TitleIndex)
            local KeyName = "Title_" .. GetNameOfKeyInTable(KnightTitles, _TitleIndex) .. "_" .. KnightGender[]]..
iQt5Tf..
[[]
            local String = XGUIEng.GetStringTableText("UI_ObjectNames/" .. KeyName)
            if String == nil or String == "" then
                String = "Knight not in Gender Table? (localscript.lua)"
            end
            return String
        end
    ]])self.Data.HumanPlayerChangedOnce=true end
function BundlePlayerHelperFunctions.Global:GetControllingPlayer()local uFBueCd_=1;for ghOiW8T8=1,8 do
if
Logic.PlayerGetIsHumanFlag(ghOiW8T8)==true then uFBueCd_=ghOiW8T8;break end end;return uFBueCd_ end
function BundlePlayerHelperFunctions.Global.OnSaveGameLoaded()Logic.StartFestival_Orig_NothingToCelebrate=
nil
BundlePlayerHelperFunctions.Global:InitFestival()
if
BundlePlayerHelperFunctions.Global.Data.HumanPlayerChangedOnce then
Logic.ExecuteInLuaLocalState([[
            GUI.SetControlledPlayer(]]..

BundlePlayerHelperFunctions.Global.Data.HumanPlayerID..
[[)
            for k,v in pairs(Buffs)do
                GUI_Buffs.UpdateBuffsInInterface(]]..

BundlePlayerHelperFunctions.Global.Data.HumanPlayerID..

[[,v)
                GUI.ResetMiniMap()
            end
            if IsExisting(Logic.GetKnightID(GUI.GetPlayerID())) then
                local portrait = GetKnightActor(]]..

BundlePlayerHelperFunctions.Global.Data.HumanKnightType..
[[)
                g_PlayerPortrait[]]..

BundlePlayerHelperFunctions.Global.Data.HumanPlayerID..[[] = portrait
                LocalSetKnightPicture()
            end
        ]])end end;function BundlePlayerHelperFunctions.Local:Install()
self:InitForbidFestival()self:OverrideQuestLogPlayerIcon()
self:OverrideQuestPlayerIcon()end
function BundlePlayerHelperFunctions.Local:InitForbidFestival()
NewStartFestivalUpdate=function()
local WOjsG4n=XGUIEng.GetCurrentWidgetID()local lo82ZRiy=GUI.GetPlayerID()
if
BundlePlayerHelperFunctions.Local.Data.NormalFestivalLockedForPlayer[lo82ZRiy]then XGUIEng.ShowWidget(WOjsG4n,0)return true end end
Core:StackFunction("GUI_BuildingButtons.StartFestivalUpdate",NewStartFestivalUpdate)end
function BundlePlayerHelperFunctions.Local:OverrideQuestPlayerIcon()
GUI_Interaction.SetPlayerIcon_Orig_BundlePlayerHelperFunctions=GUI_Interaction.SetPlayerIcon
GUI_Interaction.SetPlayerIcon=function(Hp811y,xOm)if xOm==GUI.GetPlayerID()then
GUI_Interaction.SetPlayerIcon_Orig_BundlePlayerHelperFunctions(Hp811y,xOm)return end;local PQVVbm
local V=Hp811y.."/Logo"local tu=Hp811y.."/Pattern"local V9=GetPlayerCategoryType(xOm)
local PQVVbm=g_TexturePositions.PlayerCategories[V9]if Mission_Callback_OverridePlayerIconForQuest then
PQVVbm=Mission_Callback_OverridePlayerIconForQuest(xOm)or PQVVbm end;if PQVVbm==nil then
PQVVbm={13,7}end;SetIcon(V,PQVVbm)SetIcon(tu,{14,1})
local LXDh2,ana,_K6Ojp=GUI.GetPlayerColor(xOm)
if V9 ==PlayerCategories.Harbour then LXDh2,ana,_K6Ojp=255,255,255 end
XGUIEng.SetMaterialColor(tu,0,LXDh2,ana,_K6Ojp,255)end end
function BundlePlayerHelperFunctions.Local:OverrideQuestLogPlayerIcon()
QuestLog.PushQuestGiverLogo_Orig_BundlePlayerHelperFunctions=QuestLog.PushQuestGiverLogo
QuestLog.PushQuestGiverLogo=function(J1d87,sl)local cgaqTv05="Icons.png"local JXGR9=44
local Bxo43OJ=GetPlayerCategoryType(sl)
local PUzh=g_TexturePositions.PlayerCategories[Bxo43OJ]
if PUzh~=nil or Mission_Callback_OverridePlayerIconForQuest then
QuestLog.PushQuestGiverLogo_Orig_BundlePlayerHelperFunctions(J1d87,sl)return end;PUzh={13,7}local Y=(PUzh[1]-1)*JXGR9
local Mg=(PUzh[2]-1)*JXGR9;local WfMV3=PUzh[1]*JXGR9;local pYo=PUzh[2]*JXGR9;if
PUzh[3]and PUzh[3]==1 then cgaqTv05="Icons2.png"end
XGUIEng.ListBoxPushItemEx(J1d87,"",cgaqTv05,nil,Y,Mg,WfMV3,pYo)end end
Core:RegisterBundle("BundlePlayerHelperFunctions")BundleMusicTools={}API=API or{}QSB=QSB or{}
function API.StartMusic(wGPFwuj)if GUI then
API.Log("Could not execute API.StartMusic in local script!")return end
BundleMusicTools.Global:StartSong(wGPFwuj)end;StartSong=API.StartMusic
function API.StartMusicSimple(SGsaf,i,z,VUb5rRI)if GUI then
API.Bridge("API.StartMusicSimple('"..
SGsaf.."', "..i..", "..z..", "..
VUb5rRI..")")return end
local HEOhp={File=SGsaf,Volume=i,Length=z,Fadeout=VUb5rRI*10,MuteAtmo=true,MuteUI=true}
BundleMusicTools.Global:StartSong(HEOhp)end;StartSongSimple=API.StartMusicSimple
function API.StartPlaylist(gPsSgOy)if GUI then
API.Log("Could not execute API.StartPlaylist in local script!")return end
BundleMusicTools.Global:StartPlaylist(gPsSgOy)end;StartPlaylist=API.StartPlaylist
function API.StartPlaylistTitle(_K3WVxIn)if GUI then
API.Log("Could not execute API.StartPlaylistTitle in local script!")return end
BundleMusicTools.Global:StartPlaylistTitle(_K3WVxIn)end;StartPlaylistTitle=API.StartPlaylistTitle;function API.StopSong()if GUI then
API.Bridge("API.StopSong()")return end
BundleMusicTools.Global:StopSong()end
StopSong=API.StopSong
function API.AbortMusic()
if GUI then API.Bridge("API.AbortMusic()")return end;BundleMusicTools.Global:AbortMusic()end;AbortSongOrPlaylist=API.AbortMusic
BundleMusicTools={Global={Data={StartSongData={},StartSongPlaylist={},StartSongQueue={}}},Local={Data={SoundBackup={}}}}function BundleMusicTools.Global:Install()end
function BundleMusicTools.Global:StartSong(pMwmXH)
if
self.Data.StartSongData.Running then table.insert(self.Data.StartSongQueue,pMwmXH)else assert(
type(pMwmXH.File)=="string")assert(
type(pMwmXH.Volume)=="number")assert(
type(pMwmXH.Length)=="number")pMwmXH.Length=
pMwmXH.Length*10
assert(type(pMwmXH.Fadeout)=="number")pMwmXH.MuteAtmo=pMwmXH.MuteAtmo==true
pMwmXH.MuteUI=pMwmXH.MuteUI==true;pMwmXH.CurrentVolume=pMwmXH.Volume;pMwmXH.Time=0
self.Data.StartSongData=pMwmXH;self.Data.StartSongData.Running=true
Logic.ExecuteInLuaLocalState(
[[
            BundleMusicTools.Local:BackupSound(
                ]]..
pMwmXH.Volume..
[[,
                "]]..pMwmXH.File..
[[",
                ]]..tostring(pMwmXH.MuteAtmo)..

[[,
                ]]..tostring(pMwmXH.MuteUI)..[[
            )
        ]])if not self.Data.StartSongJob then
self.Data.StartSongJob=StartSimpleHiResJob("StartSongControl")end end end
function BundleMusicTools.Global:StartPlaylist(JFRvx)
for VEf=1,#JFRvx,1 do
table.insert(self.Data.StartSongPlaylist,JFRvx[VEf])self:StartSong(JFRvx[VEf])end
self.Data.StartSongPlaylist.Repeat=JFRvx.Repeat==true end
function BundleMusicTools.Global:StartPlaylistTitle(_f)
local l=self.Data.StartSongPlaylist;local EKlDX0I0=#length
if(EKlDX0I0 >=_f)then
self.Data.StartSongData.Running=false;self.Data.StartSongQueue={}self.Data.StartSongData={}
self:StopSong()EndJob(self.Data.StartSongJob)
self.Data.StartSongJob=nil;for DCBhcqf=_f,EKlDX0I0,1 do self:StartSong(l)end end end
function BundleMusicTools.Global:StopSong()
local eBbs2V=#self.Data.StartSongQueue;local Ms4sPCS3=self.Data.StartSongData
Logic.ExecuteInLuaLocalState(
[[
        BundleMusicTools.Local:ResetSound(
            "]]..

((Ms4sPCS3.File~=nil and Ms4sPCS3.File)or"")..[[",
            ]]..eBbs2V..[[
        )
    ]])end
function BundleMusicTools.Global:AbortMusic()self.Data.StartSongPlaylist={}
self.Data.StartSongQueue={}self:StopSong()self.Data.StartSongData={}
EndJob(self.Data.StartSongJob)self.Data.StartSongJob=nil end
function BundleMusicTools.Global.StartSongControl()
if not
BundleMusicTools.Global.Data.StartSongData.Running then
BundleMusicTools.Global.Data.StartSongData={}
BundleMusicTools.Global.Data.StartSongJob=nil
if
#BundleMusicTools.Global.Data.StartSongQueue>0 then
local ihjLIXJP=table.remove(BundleMusicTools.Global.Data.StartSongQueue,1)
BundleMusicTools.Global:StartSong(ihjLIXJP)else if
BundleMusicTools.Global.Data.StartSongPlaylist.Repeat then
BundleMusicTools.Global:StartPlaylist(BundleMusicTools.Global.Data.StartSongPlaylist)end end;return true end
local eCHE=BundleMusicTools.Global.Data.StartSongData;BundleMusicTools.Global.Data.StartSongData.Time=
eCHE.Time+1
if eCHE.Fadeout<5 then
if
eCHE.Time>=eCHE.Length then
BundleMusicTools.Global.Data.StartSongData.Running=false;BundleMusicTools.Global:StopSong()end else local se=eCHE.Length-eCHE.Fadeout+1
if eCHE.Time>=se then
if
eCHE.Time>=eCHE.Length then
BundleMusicTools.Global.Data.StartSongData.Running=false;BundleMusicTools.Global:StopSong()else local Nob_vHvC=
eCHE.Volume/eCHE.Fadeout;BundleMusicTools.Global.Data.StartSongData.CurrentVolume=
eCHE.CurrentVolume-Nob_vHvC
Logic.ExecuteInLuaLocalState(
[[
                    Sound.SetSpeechVolume(]]..eCHE.CurrentVolume..[[)
                ]])end end end end
StartSongControl=BundleMusicTools.Global.StartSongControl;function BundleMusicTools.Local:Install()end
function BundleMusicTools.Local:BackupSound(zZ6,fmN,lz_ocRIw,U)
if
self.Data.SoundBackup.FXSP==nil then
self.Data.SoundBackup.FXSP=Sound.GetFXSoundpointVolume()
self.Data.SoundBackup.FXAtmo=Sound.GetFXAtmoVolume()self.Data.SoundBackup.FXVol=Sound.GetFXVolume()
self.Data.SoundBackup.Sound=Sound.GetGlobalVolume()
self.Data.SoundBackup.Music=Sound.GetMusicVolume()
self.Data.SoundBackup.Voice=Sound.GetSpeechVolume()self.Data.SoundBackup.UI=Sound.Get2DFXVolume()end;Sound.SetFXVolume(100)Sound.SetSpeechVolume(zZ6)if
lz_ocRIw==true then Sound.SetFXSoundpointVolume(0)
Sound.SetFXAtmoVolume(0)end;if U==true then
Sound.Set2DFXVolume(0)Sound.SetFXVolume(0)end
Sound.SetMusicVolume(0)Sound.PlayVoice("ImportantStuff",fmN)end
function BundleMusicTools.Local:ResetSound(TOeT,WAt)if TOeT~=nil then
Sound.StopVoice("ImportantStuff",TOeT)end
if WAt<=0 then
if
self.Data.SoundBackup.FXSP~=nil then
Sound.SetFXSoundpointVolume(self.Data.SoundBackup.FXSP)
Sound.SetFXAtmoVolume(self.Data.SoundBackup.FXAtmo)
Sound.SetFXVolume(self.Data.SoundBackup.FXVol)
Sound.SetGlobalVolume(self.Data.SoundBackup.Sound)
Sound.SetMusicVolume(self.Data.SoundBackup.Music)
Sound.SetSpeechVolume(self.Data.SoundBackup.Voice)
Sound.Set2DFXVolume(self.Data.SoundBackup.UI)self.Data.SoundBackup={}end end end;Core:RegisterBundle("BundleMusicTools")
BundleNonPlayerCharacter={}API=API or{}QSB=QSB or{}
function API.NpcCompose(LeEmy5X)
local ryXfNT=function(zHd)if zHd.WrongHeroMessage then
API.Note(zHd.WrongHeroMessage)end end;local j=NonPlayerCharacter:New(LeEmy5X.Name)
j:SetDialogPartner(LeEmy5X.Hero)j:SetWrongPartnerCallback(ryXfNT)
j:SetCallback(LeEmy5X.Callback)return j:Activate()end;CreateNPC=API.NpcCompose
function API.NpcDispose(zD_ikopp)
local IH=Logic.GetEntityName(GetID(zD_ikopp))local nJlT5=NonPlayerCharacter:GetInstance(IH)
if not nJlT5 then return end;nJlT5:Dispose()end;DestroyNPC=API.NpcDispose
function API.NpcActivate(x19XA)
local I7gFmhU9=Logic.GetEntityName(GetID(x19XA))local dhJjEw=NonPlayerCharacter:GetInstance(I7gFmhU9)if not
dhJjEw then return end;dhJjEw:Activate()end;EnableNPC=API.NpcActivate
function API.NpcDeactivate(j4)
local nMu4=Logic.GetEntityName(GetID(j4))local RoMu=NonPlayerCharacter:GetInstance(nMu4)if not RoMu then
return end;RoMu:Deactivate()end;DisableNPC=API.NpcDeactivate
function API.NpcReset(HE4ef)
local UhX5O8TI=Logic.GetEntityName(GetID(HE4ef))local nfwc_0q=NonPlayerCharacter:GetInstance(UhX5O8TI)if not
nfwc_0q then return end;nfwc_0q:Reset()end;ResetNPC=API.NpcReset
function API.NpcHasSpoken(lCMmvx4)
local D=Logic.GetEntityName(GetID(lCMmvx4))local R=NonPlayerCharacter:GetInstance(D)
if not R then return end;return R:HasTalkedTo()end;TalkedToNPC=API.NpcHasSpoken
BundleNonPlayerCharacter={Global={NonPlayerCharacter={Data={}},NonPlayerCharacterObjects={},LastNpcEntityID=0,LastHeroEntityID=0},Local={}}
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:New(ppjstV)
assert(
self==BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used from instance!')
assert(IsExisting(ppjstV),'entity "'..ppjstV..'" does not exist!')local Aza=CopyTableRecursive(self)Aza.Data.NpcName=ppjstV
BundleNonPlayerCharacter.Global.NonPlayerCharacterObjects[ppjstV]=Aza;Aza:CreateMarker()Aza:HideMarker()return Aza end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:GetInstance(xLhKn4r0)
assert(
self==BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used from instance!')local bLf6=GetID(xLhKn4r0)local HNXm=Logic.GetEntityName(bLf6)
if
Logic.IsEntityInCategory(bLf6,EntityCategories.Soldier)==1 then
local PbQ5gKb=Logic.SoldierGetLeaderEntityID(bLf6)
if IsExisting(PbQ5gKb)then HNXm=Logic.GetEntityName(PbQ5gKb)end end;return
BundleNonPlayerCharacter.Global.NonPlayerCharacterObjects[HNXm]end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:GetNpcId()
assert(
self==BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used from instance!')
return BundleNonPlayerCharacter.Global.LastNpcEntityID end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:GetHeroId()
assert(
self==BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used from instance!')
return BundleNonPlayerCharacter.Global.LastHeroEntityID end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:GetID()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')local sckZ9ldO=GetID(self.Data.NpcName)
if
Logic.IsEntityInCategory(sckZ9ldO,EntityCategories.Leader)==1 then
local eK_={Logic.GetSoldiersAttachedToLeader(sckZ9ldO)}if eK_[1]>0 then return eK_[2]end end;return sckZ9ldO end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:Dispose()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self:Deactivate()self:DestroyMarker()BundleNonPlayerCharacter.Global.NonPlayerCharacterObjects[self.Data.NpcName]=
nil end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:Activate()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')
if IsExisting(self.Data.NpcName)then
Logic.SetOnScreenInformation(self:GetID(),1)self:ShowMarker()end;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:Deactivate()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')
if IsExisting(self.Data.NpcName)then
Logic.SetOnScreenInformation(self:GetID(),0)self:HideMarker()end;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:IsActive()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')return
Logic.GetEntityScriptingValue(self:GetID(),6)==1 end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:Reset()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')
if IsExisting(self.Data.NpcName)then
Logic.SetOnScreenInformation(self:GetID(),0)self.Data.TalkedTo=nil;self:HideMarker()end;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:HasTalkedTo()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')if self.Data.HeroName then return
self.Data.TalkedTo==GetID(self.Data.HeroName)end;return
self.Data.TalkedTo~=nil end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetDialogPartner(CB)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self.Data.HeroName=CB;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetWrongPartnerCallback(_)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')self.Data.WrongHeroCallback=_;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:SetCallback(GSk1M)
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')
assert(type(GSk1M)=="function",'callback must be a function!')self.Data.Callback=GSk1M;return self end;function Goal_NPC(...)return b_Goal_NPC:new(...)end
b_Goal_NPC={Name="Goal_NPC",Description={en="Goal: The hero has to talk to a non-player character.",de="Ziel: Der Held muss einen Nichtspielercharakter ansprechen."},Parameter={{ParameterType.ScriptName,en="NPC",de="NPC"},{ParameterType.ScriptName,en="Hero",de="Held"}}}
function b_Goal_NPC:GetGoalTable(T_5rAEl_)return
{Objective.Distance,-65565,self.Hero,self.NPC,self}end
function b_Goal_NPC:AddParameter(YGObdZwx,E)
if(YGObdZwx==0)then self.NPC=E elseif(YGObdZwx==1)then self.Hero=E;if
self.Hero=="-"then self.Hero=nil end end end;function b_Goal_NPC:GetIcon()return{14,10}end
Core:RegisterBehavior(b_Goal_NPC)
function Trigger_NPC(...)return b_Trigger_NPC:new(...)end
b_Trigger_NPC={Name="Trigger_NPC",Description={en="Trigger: Starts the quest after the npc was spoken to.",de="Ausloeser: Startet den Quest, sobald der NPC angesprochen wurde."},Parameter={{ParameterType.ScriptName,en="NPC",de="NPC"},{ParameterType.ScriptName,en="Hero",de="Held"}}}function b_Trigger_NPC:GetTriggerTable()return
{Triggers.Custom2,{self,self.CustomFunction}}end
function b_Trigger_NPC:AddParameter(YSkEYRe,_fiEcf)
if(
YSkEYRe==0)then self.NPC=_fiEcf elseif(YSkEYRe==1)then self.Hero=_fiEcf;if
self.Hero=="-"then self.Hero=nil end end end
function b_Trigger_NPC:CustomFunction()
if not IsExisting(self.NPC)then return end;if not self.NpcInstance then
local Be0ARSm=NonPlayerCharacter:New(self.NPC)Be0ARSm:SetDialogPartner(self.Hero)
self.NpcInstance=Be0ARSm end
local EoAoi=self.NpcInstance:HasTalkedTo(self.Hero)
if not EoAoi then if not self.NpcInstance:IsActive()then
self.NpcInstance:Activate()end end;return EoAoi end;function b_Trigger_NPC:Reset(Je_mlkI4)
if self.NpcInstance then self.NpcInstance:Dispose()end end
function b_Trigger_NPC:DEBUG(lwIquV)return false end;Core:RegisterBehavior(b_Trigger_NPC)
function BundleNonPlayerCharacter.Global:Install()
NonPlayerCharacter=BundleNonPlayerCharacter.Global.NonPlayerCharacter
StartSimpleJobEx(function()
for gG6o,y in
pairs(BundleNonPlayerCharacter.Global.NonPlayerCharacterObjects)do y:ControlMarker()end end)
GameCallback_OnNPCInteraction_Orig_QSB_NPC_Rewrite=GameCallback_OnNPCInteraction
GameCallback_OnNPCInteraction=function(YMGGBH,niV2P)
GameCallback_OnNPCInteraction_Orig_QSB_NPC_Rewrite(YMGGBH,niV2P)Quest_OnNPCInteraction(YMGGBH,niV2P)end
Quest_OnNPCInteraction=function(Jo5s7r,upXVDiqQ)local K={}Logic.GetKnights(upXVDiqQ,K)local UtWdaQ=0
local rYdnnfag=Logic.WorldGetSize()
for dAVJjBHz=1,#K,1 do
local htDqaV=Logic.GetDistanceBetweenEntities(K[dAVJjBHz],Jo5s7r)
if htDqaV<rYdnnfag then rYdnnfag=htDqaV;UtWdaQ=K[dAVJjBHz]end end
BundleNonPlayerCharacter.Global.LastHeroEntityID=UtWdaQ;local Kp=NonPlayerCharacter:GetInstance(Jo5s7r)
BundleNonPlayerCharacter.Global.LastNpcEntityID=Kp:GetID()
if Kp then Kp:RotateActors()Kp.Data.TalkedTo=UtWdaQ
if Kp:HasTalkedTo()then
Kp:Deactivate()
if Kp.Data.Callback then Kp.Data.Callback(Kp,UtWdaQ)end else
if Kp.Data.WrongHeroCallback then Kp.Data.WrongHeroCallback(Kp,UtWdaQ)end end end end
function QuestTemplate:RemoveQuestMarkers()
for X=1,self.Objectives[0]do
if self.Objectives[X].Type==
Objective.Distance then
if

(
(
type(self.Objectives[X].Data[1])=="number"and
self.Objectives[X].Data[1]>0)or
(type(self.Objectives[X].Data[1])~="number"))and self.Objectives[X].Data[4]then
DestroyQuestMarker(self.Objectives[X].Data[2])end end end end
function QuestTemplate:ShowQuestMarkers()
for sY=1,self.Objectives[0]do
if self.Objectives[sY].Type==
Objective.Distance then
if

(
(
type(self.Objectives[sY].Data[1])=="number"and
self.Objectives[sY].Data[1]>0)or
(type(self.Objectives[sY].Data[1])~="number"))and self.Objectives[sY].Data[4]then
ShowQuestMarker(self.Objectives[sY].Data[2])end end end end
function QuestTemplate:RemoveNPCMarkers()
for W_AQib=1,self.Objectives[0]do
if
type(self.Objectives[W_AQib].Data)=="table"then
if
self.Objectives[W_AQib].Data[1]==-65565 then
if
type(self.Objectives[W_AQib].Data[4])=="table"then
if
self.Objectives[W_AQib].Data[4].NpcInstance then
self.Objectives[W_AQib].Data[4].NpcInstance:Dispose()self.Objectives[W_AQib].Data[4].NpcInstance=
nil end end end end end end
QuestTemplate.Interrupt_Orig_BundleNonPlayerCharacter=QuestTemplate.Interrupt
QuestTemplate.Interrupt=function(Xkrl,KHi)
QuestTemplate.Interrupt_Orig_BundleNonPlayerCharacter(Xkrl,KHi)Xkrl:RemoveNPCMarkers()end
QuestTemplate.IsObjectiveCompleted_Orig_BundleNonPlayerCharacter=QuestTemplate.IsObjectiveCompleted
QuestTemplate.IsObjectiveCompleted=function(o00rC8D,Fxq)local cJz5v=Fxq.Type;local RLwak=Fxq.Data;if Fxq.Completed~=nil then return
Fxq.Completed end
if cJz5v~=Objective.Distance then return
o00rC8D:IsObjectiveCompleted_Orig_BundleNonPlayerCharacter(Fxq)else
if RLwak[1]==-65565 then
if not
IsExisting(RLwak[3])then
API.Fatal(RLwak[3].." is dead! :(")Fxq.Completed=false else
if not RLwak[4].NpcInstance then
local n=NonPlayerCharacter:New(RLwak[3])n:SetDialogPartner(RLwak[2])RLwak[4].NpcInstance=n end;if RLwak[4].NpcInstance:HasTalkedTo(RLwak[2])then
Fxq.Completed=true end
if not Fxq.Completed then if not
RLwak[4].NpcInstance:IsActive()then
RLwak[4].NpcInstance:Activate()end end end else
return o00rC8D:IsObjectiveCompleted_Orig_BundleNonPlayerCharacter(Fxq)end end end end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:RotateActors()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')
local KCkxINI=Logic.EntityGetPlayer(BundleNonPlayerCharacter.Global.LastHeroEntityID)local CW9AS={}Logic.GetKnights(KCkxINI,CW9AS)
for YnXwsjT=1,#CW9AS,1 do
if
Logic.GetDistanceBetweenEntities(CW9AS[YnXwsjT],BundleNonPlayerCharacter.Global.LastNpcEntityID)<3000 then
local gG6tlNB,usMT,_=Logic.EntityGetPos(CW9AS[YnXwsjT])if Logic.IsEntityMoving(CW9AS[YnXwsjT])then
Logic.MoveEntity(CW9AS[YnXwsjT],gG6tlNB,usMT)end
LookAt(CW9AS[YnXwsjT],self.Data.NpcName)end end;local i8CsGD=0
if Logic.IsKnight(GetID(self.Data.NpcName))then i8CsGD=15 end
LookAt(self.Data.NpcName,BundleNonPlayerCharacter.Global.LastHeroEntityID,i8CsGD)
LookAt(BundleNonPlayerCharacter.Global.LastHeroEntityID,self.Data.NpcName,15)end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:CreateMarker()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')local c,ALg,FGaxGreB=Logic.EntityGetPos(self:GetID())
local dOXU9k2M=Logic.CreateEntity(Entities.XD_ScriptEntity,c,ALg,0,0)DestroyEntity(self.Data.MarkerID)
self.Data.MarkerID=dOXU9k2M;self:HideMarker()return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:DestroyMarker()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')if self.Data.MarkerID then DestroyEntity(self.Data.MarkerID)self.Data.MarkerID=
nil end;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:ShowMarker()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')
if IsExisting(self.Data.MarkerID)then
local IQR=Logic.GetEntityScriptingValue(self:GetID(),-45)
Logic.SetEntityScriptingValue(self.Data.MarkerID,-45,IQR)
Logic.SetModel(self.Data.MarkerID,Models.Effects_E_Wealth)Logic.SetVisible(self.Data.MarkerID,true)end;self.Data.MarkerVisibility=true;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:HideMarker()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')
if IsExisting(self.Data.MarkerID)then
Logic.SetModel(self.Data.MarkerID,Models.Effects_E_NullFX)Logic.SetVisible(self.Data.MarkerID,false)end;self.Data.MarkerVisibility=false;return self end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:IsMarkerVisible()
assert(
self~=BundleNonPlayerCharacter.Global.NonPlayerCharacter,'Can not be used in static context!')return
IsExisting(self.Data.MarkerID)and self.Data.MarkerVisibility==true end
function BundleNonPlayerCharacter.Global.NonPlayerCharacter:ControlMarker()
if
self:IsActive()and not self:HasTalkedTo()then if self:IsMarkerVisible()then
self:HideMarker()else self:ShowMarker()end
local fOj,KFl4,UJWa=Logic.EntityGetPos(self.Data.MarkerID)local PFlgL,rxyThD6,VRs=Logic.EntityGetPos(self:GetID())if
math.abs(
fOj-PFlgL)>20 or math.abs(KFl4-rxyThD6)>20 then
Logic.DEBUG_SetPosition(self.Data.MarkerID,PFlgL,rxyThD6)end end
if IsBriefingActive and IsBriefingActive()then self:HideMarker()end end
function BundleNonPlayerCharacter.Local:Install()g_CurrentDisplayedQuestID=0
GUI_Interaction.DisplayQuestObjective_Orig_BundleNonPlayerCharacter=GUI_Interaction.DisplayQuestObjective
GUI_Interaction.DisplayQuestObjective=function(GCS,YdnmmM)
local POMCJU=Network.GetDesiredLanguage()if POMCJU~="de"then POMCJU="en"end;local _2rnCxKx=tonumber(GCS)if _2rnCxKx then
GCS=_2rnCxKx end
local doOPrgd_,AO=GUI_Interaction.GetPotentialSubQuestAndType(GCS)local V="/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives"
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomLeft/Message/QuestObjectives",0)local TKg;local fYS;local e=Quests[GCS]local b;if e~=nil and type(e)=="table"then
b=e.Identifier end;local zpMucVRd={}g_CurrentDisplayedQuestID=GCS
if AO==
Objective.Distance then TKg=V.."/List"
fYS=Wrapped_GetStringTableText(GCS,"UI_Texts/QuestInteraction")local M={}
if
doOPrgd_.Objectives[1].Data[1]==-65565 then TKg=V.."/Distance"
fYS=Wrapped_GetStringTableText(GCS,"UI_Texts/QuestMoveHere")SetIcon(TKg.."/QuestTypeIcon",{7,10})
local cVSRx56=GetEntityId(doOPrgd_.Objectives[1].Data[2])local Xts2D=Logic.GetEntityType(cVSRx56)
local qwzj=g_TexturePositions.Entities[Xts2D]
if
doOPrgd_.Objectives[1].Data[1]==-65567 or not qwzj then qwzj={16,12}end;SetIcon(TKg.."/IconMover",qwzj)
local JXJOBh=GetEntityId(doOPrgd_.Objectives[1].Data[3])local kDP8=Logic.GetEntityType(JXJOBh)
local v=g_TexturePositions.Entities[kDP8]if not v then v={14,10}end;local nNyK4b=TKg.."/IconTarget"
local j=TKg.."/TargetPlayerColor"SetIcon(nNyK4b,v)
XGUIEng.SetMaterialColor(j,0,255,255,255,0)SetIcon(TKg.."/QuestTypeIcon",{16,12})
local eiI8Mxj={de="Gespräch beginnen",en="Start conversation"}fYS=eiI8Mxj[POMCJU]
XGUIEng.SetText(TKg.."/Caption","{center}"..fYS)XGUIEng.ShowWidget(TKg,1)else
GUI_Interaction.DisplayQuestObjective_Orig_BundleNonPlayerCharacter(GCS,YdnmmM)end else
GUI_Interaction.DisplayQuestObjective_Orig_BundleNonPlayerCharacter(GCS,YdnmmM)end end
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_BundleNonPlayerCharacter=GUI_Interaction.GetEntitiesOrTerritoryListForQuest
GUI_Interaction.GetEntitiesOrTerritoryListForQuest=function(BWtY5OFl,VI)local N={}local PUc=true
if VI==Objective.Distance then
if
BWtY5OFl.Objectives[1].Data[1]==-65565 then
local Jud9Pl=GetEntityId(BWtY5OFl.Objectives[1].Data[3])table.insert(N,Jud9Pl)else return
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_BundleNonPlayerCharacter(BWtY5OFl,VI)end else return
GUI_Interaction.GetEntitiesOrTerritoryListForQuest_Orig_BundleNonPlayerCharacter(BWtY5OFl,VI)end;return N,PUc end end;Core:RegisterBundle("BundleNonPlayerCharacter")
BundleTradingAnalysis={}API=API or{}QSB=QSB or{}
QSB.TraderTypes={GoodTrader=0,MercenaryTrader=1,EntertainerTrader=2,Unknown=3}
function API.GetOfferInformation(iRVM9)if GUI then
API.Log("Can not execute API.GetOfferInformation in local script!")return end;return
BundleTradingAnalysis.Global:GetStorehouseInformation(iRVM9)end
function API.GetOfferCount(PT)if GUI then
API.Log("Can not execute API.GetOfferCount in local script!")return end;return
BundleTradingAnalysis.Global:GetOfferCount(PT)end
function API.IsGoodOrUnitOffered(c,V3)if GUI then
API.Log("Can not execute API.IsGoodOrUnitOffered in local script!")return end
local RP3PZr,WowPed3=BundleTradingAnalysis.Global:GetOfferAndTrader(c,V3)return RP3PZr~=1 and WowPed3 ~=1 end
function API.RemoveTradeOffer(y8,m_Lk)if GUI then
API.Bridge("API.RemoveTradeOffer("..y8 ..", "..m_Lk..")")return end;return
BundleTradingAnalysis.Global:RemoveTradeOffer(y8,m_Lk)end
function API.ModifyTradeOffer(YSQs9,D,_Y)if GUI then
API.Bridge("API.ModifyTradeOffer("..
YSQs9 ..", "..D..", ".._Y..")")return end;return
BundleTradingAnalysis.Global:ModifyTradeOffer(YSQs9,D,_Y)end
BundleTradingAnalysis={Global={Data={PlayerOffersAmount={[1]={},[2]={},[3]={},[4]={},[5]={},[6]={},[7]={},[8]={}}}}}
function BundleTradingAnalysis.Global:Install()
self.OverwriteOfferFunctions()self.OverwriteBasePricesAndRefreshRates()end
function BundleTradingAnalysis.Global:OverwriteOfferFunctions()
AddOffer=function(A4DFCOwh,n1,duwFJh,M,EK)
local _Wjvmo8b=GetID(A4DFCOwh)
if type(duwFJh)=="string"then duwFJh=Goods[duwFJh]else duwFJh=duwFJh end;local WmqSPRxj=Logic.EntityGetPlayer(_Wjvmo8b)
local J1BebH,Zd6=BundleTradingAnalysis.Global:GetOfferAndTrader(WmqSPRxj,duwFJh)if J1BebH~=-1 and Zd6 ~=-1 then
API.Warn("Good offer for good type "..duwFJh.." already exists for player "..
WmqSPRxj.."!")return end
AddGoodToTradeBlackList(WmqSPRxj,duwFJh)local RRg1i=Entities.U_Marketer;if duwFJh==Goods.G_Medicine then
RRg1i=Entities.U_Medicus end;if M==nil then
M=MerchantSystem.RefreshRates[duwFJh]if M==nil then M=0 end end
if EK==nil then EK=1 end;local lRuboeH8=9
BundleTradingAnalysis.Global.Data.PlayerOffersAmount[WmqSPRxj][duwFJh]=n1;return
Logic.AddGoodTraderOffer(_Wjvmo8b,n1,Goods.G_Gold,0,duwFJh,lRuboeH8,EK,M,RRg1i,Entities.U_ResourceMerchant)end
AddMercenaryOffer=function(WTDfbIzV,zZ,C,F9hulT,tjife)local pVmM=GetID(WTDfbIzV)if C==nil then
C=Entities.U_MilitaryBandit_Melee_ME end
if F9hulT==nil then
F9hulT=MerchantSystem.RefreshRates[C]if F9hulT==nil then F9hulT=0 end end;local bS=Logic.EntityGetPlayer(pVmM)
local A8exon,XeVzFYp=BundleTradingAnalysis.Global:GetOfferAndTrader(bS,C)if A8exon~=-1 and XeVzFYp~=-1 then
API.Warn("Mercenary offer for type "..C..
" already exists for player "..bS.."!")return end;local za7c=3
local y=Logic.GetEntityTypeName(C)
if
string.find(y,"MilitaryBow")or string.find(y,"MilitarySword")then za7c=6 elseif string.find(y,"Cart")then za7c=0 end;if tjife==nil then tjife=1 end
BundleTradingAnalysis.Global.Data.PlayerOffersAmount[bS][C]=zZ
return Logic.AddMercenaryTraderOffer(pVmM,zZ,Goods.G_Gold,3,C,za7c,tjife,F9hulT)end
AddEntertainerOffer=function(aAUdT020,mXBnquTt,fYtG9)local vbqky1=GetID(aAUdT020)local Pi=1
local VO=Logic.EntityGetPlayer(vbqky1)
local IowEa,s=BundleTradingAnalysis.Global:GetOfferAndTrader(VO,mXBnquTt)if IowEa~=-1 and s~=-1 then
API.Warn("Entertainer offer for type "..mXBnquTt..
" already exists for player "..VO.."!")return end
if
mXBnquTt==nil then mXBnquTt=Entities.U_Entertainer_NA_FireEater end;if fYtG9 ==nil then fYtG9=1 end
BundleTradingAnalysis.Global.Data.PlayerOffersAmount[VO][mXBnquTt]=1
return Logic.AddEntertainerTraderOffer(vbqky1,Pi,Goods.G_Gold,0,mXBnquTt,fYtG9,0)end end
function BundleTradingAnalysis.Global:OverwriteBasePricesAndRefreshRates()
MerchantSystem.BasePrices[Entities.U_CatapultCart]=
MerchantSystem.BasePrices[Entities.U_CatapultCart]or 1000
MerchantSystem.BasePrices[Entities.U_BatteringRamCart]=
MerchantSystem.BasePrices[Entities.U_BatteringRamCart]or 450
MerchantSystem.BasePrices[Entities.U_SiegeTowerCart]=
MerchantSystem.BasePrices[Entities.U_SiegeTowerCart]or 600
MerchantSystem.BasePrices[Entities.U_AmmunitionCart]=
MerchantSystem.BasePrices[Entities.U_AmmunitionCart]or 180
MerchantSystem.BasePrices[Entities.U_MilitarySword_RedPrince]=
MerchantSystem.BasePrices[Entities.U_MilitarySword_RedPrince]or 150
MerchantSystem.BasePrices[Entities.U_MilitarySword]=
MerchantSystem.BasePrices[Entities.U_MilitarySword]or 150
MerchantSystem.BasePrices[Entities.U_MilitaryBow_RedPrince]=
MerchantSystem.BasePrices[Entities.U_MilitaryBow_RedPrince]or 220
MerchantSystem.BasePrices[Entities.U_MilitaryBow]=
MerchantSystem.BasePrices[Entities.U_MilitaryBow]or 220
MerchantSystem.RefreshRates[Entities.U_CatapultCart]=
MerchantSystem.RefreshRates[Entities.U_CatapultCart]or 270
MerchantSystem.RefreshRates[Entities.U_BatteringRamCart]=
MerchantSystem.RefreshRates[Entities.U_BatteringRamCart]or 190
MerchantSystem.RefreshRates[Entities.U_SiegeTowerCart]=
MerchantSystem.RefreshRates[Entities.U_SiegeTowerCart]or 220
MerchantSystem.RefreshRates[Entities.U_AmmunitionCart]=
MerchantSystem.RefreshRates[Entities.U_AmmunitionCart]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_RedPrince]=
MerchantSystem.RefreshRates[Entities.U_MilitarySword_RedPrince]or 150
MerchantSystem.RefreshRates[Entities.U_MilitarySword]=
MerchantSystem.RefreshRates[Entities.U_MilitarySword]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_RedPrince]=
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_RedPrince]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow]=
MerchantSystem.RefreshRates[Entities.U_MilitaryBow]or 150
if g_GameExtraNo>=1 then
MerchantSystem.BasePrices[Entities.U_MilitaryBow_Khana]=
MerchantSystem.BasePrices[Entities.U_MilitaryBow_Khana]or 220
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_Khana]=
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_Khana]or 150
MerchantSystem.BasePrices[Entities.U_MilitarySword_Khana]=
MerchantSystem.BasePrices[Entities.U_MilitarySword_Khana]or 150
MerchantSystem.RefreshRates[Entities.U_MilitaryBow_Khana]=
MerchantSystem.RefreshRates[Entities.U_MilitarySword_Khana]or 150 end end
function BundleTradingAnalysis.Global:GetStorehouseInformation(ZZnX)
local __=Logic.GetStoreHouse(ZZnX)local _KWPG={Player=ZZnX,Storehouse=__,OfferCount=0,{}}
local qchCVHOE=Logic.GetNumberOfMerchants(Logic.GetStoreHouse(2))local AWoTSoj=0
if __~=0 then
for sx3q16Z9=0,qchCVHOE,1 do
local Z={Logic.GetMerchantOfferIDs(__,sx3q16Z9,ZZnX)}
for ehQhD=1,#Z,1 do local S7,e,NPi,GfZ=0,0,0,0
if Logic.IsGoodTrader(__,sx3q16Z9)then
S7,e,NPi,GfZ=Logic.GetGoodTraderOffer(__,Z[ehQhD],ZZnX)
if S7 ==Goods.G_Sheep or S7 ==Goods.G_Cow then e=5 end elseif Logic.IsMercenaryTrader(__,sx3q16Z9)then
S7,e,NPi,GfZ=Logic.GetMercenaryOffer(__,Z[ehQhD],ZZnX)elseif Logic.IsEntertainerTrader(__,sx3q16Z9)then
S7,e,NPi,GfZ=Logic.GetEntertainerTraderOffer(__,Z[ehQhD],ZZnX)end;AWoTSoj=AWoTSoj+1;local zHE8E={sx3q16Z9,Z[ehQhD],S7,e,NPi}
table.insert(_KWPG[1],zHE8E)end end end;_KWPG.OfferCount=AWoTSoj;return _KWPG end
function BundleTradingAnalysis.Global:GetOfferCount(li)
local LNaSNj=self:GetStorehouseInformation(li)if Info then return LNaSNj.OfferCount end;return 0 end
function BundleTradingAnalysis.Global:GetOfferAndTrader(dCA7LRIA,Q)
local XBH=self:GetStorehouseInformation(dCA7LRIA)
if XBH then for w8av9p=1,#XBH[1],1 do
if XBH[1][w8av9p][3]==Q then return XBH[1][w8av9p][2],
XBH[1][w8av9p][1],XBH.Storehouse end end end;return-1,-1,-1 end
function BundleTradingAnalysis.Global:GetTraderType(tZR3r,Mxb4n)
if
Logic.IsGoodTrader(BuildingID,Mxb4n)==true then return QSB.TraderTypes.GoodTrader elseif
Logic.IsMercenaryTrader(BuildingID,Mxb4n)==true then return QSB.TraderTypes.MercenaryTrader elseif
Logic.IsEntertainerTrader(BuildingID,Mxb4n)==true then return QSB.TraderTypes.EntertainerTrader else return
QSB.TraderTypes.Unknown end end
function BundleTradingAnalysis.Global:RemoveTradeOffer(YAkpb,MdPQ4A)
local RuV7,o,ZLk=self:GetOfferAndTrader(YAkpb,MdPQ4A)if not IsExisting(ZLk)then return end;local HB0Y9E=
(o==1 and 2)or(o==2 and 1)or 0
Logic.RemoveOffer(ZLk,HB0Y9E,RuV7)end
function BundleTradingAnalysis.Global:ModifyTradeOffer(D,R8,mDAsG)
local ME,KC,U=self:GetOfferAndTrader(D,R8)if not IsExisting(U)then return end;if mDAsG==nil or mDAsG==-1 then
mDAsG=self.Data.PlayerOffersAmount[D][R8]end;if
self.Data.PlayerOffersAmount[D][R8]and
self.Data.PlayerOffersAmount[D][R8]<mDAsG then
mDAsG=self.Data.PlayerOffersAmount[D][R8]end
Logic.ModifyTraderOffer(U,ME,mDAsG,KC)end;Core:RegisterBundle("BundleTradingAnalysis")
AddOnQuestDebug={}API=API or{}QSB=QSB or{}
AddOnQuestDebug={Global={Data={}},Local={Data={}}}
function API.ActivateDebugMode(vh,Y,rmNp,Pl)if GUI then
API.Bridge("API.ActivateDebugMode("..tostring(vh)..", "..
tostring(Y)..", "..tostring(rmNp)..", "..
tostring(Pl)..")")return end
AddOnQuestDebug.Global:ActivateDebug(vh,Y,rmNp,Pl)end;ActivateDebugMode=API.ActivateDebugMode;function Reward_DEBUG(...)
return b_Reward_DEBUG:new(...)end
b_Reward_DEBUG={Name="Reward_DEBUG",Description={en="Reward: Start the debug mode. See documentation for more information.",de="Lohn: Startet den Debug-Modus. Für mehr Informationen siehe Dokumentation."},Parameter={{ParameterType.Custom,en="Check quest while runtime",de="Quests zur Laufzeit prüfen"},{ParameterType.Custom,en="Use quest trace",de="Questverfolgung"},{ParameterType.Custom,en="Activate developing cheats",de="Testmodus aktivieren"},{ParameterType.Custom,en="Activate developing shell",de="Testmodus aktivieren"}}}function b_Reward_DEBUG:GetRewardTable(e6lN)return
{Reward.Custom,{self,self.CustomFunction}}end
function b_Reward_DEBUG:AddParameter(M,itdcJb3)
if(
M==1)then
self.CheckWhileRuntime=AcceptAlternativeBoolean(itdcJb3)elseif(M==2)then self.UseQuestTrace=AcceptAlternativeBoolean(itdcJb3)elseif(
M==3)then
self.DelepoingCheats=AcceptAlternativeBoolean(itdcJb3)elseif(M==3)then
self.DelepoingShell=AcceptAlternativeBoolean(itdcJb3)end end
function b_Reward_DEBUG:CustomFunction(izUgNShl)
API.ActivateDebugMode(self.CheckWhileRuntime,self.UseQuestTrace,self.DelepoingCheats,self.DelepoingShell)end
function b_Reward_DEBUG:GetCustomData(vGkNE)return{"true","false"}end;Core:RegisterBehavior(b_Reward_DEBUG)
function AddOnQuestDebug.Global:Install()
AddOnQuestDebug.Global.Data.DebugCommands={{"clear",AddOnQuestDebug.Global.Clear},{"diplomacy",AddOnQuestDebug.Global.Diplomacy},{"restartmap",AddOnQuestDebug.Global.RestartMap},{"shareview",AddOnQuestDebug.Global.ShareView},{"setposition",AddOnQuestDebug.Global.SetPosition},{"version",AddOnQuestDebug.Global.ShowVersion},{"win",AddOnQuestDebug.Global.QuestSuccess,true},{"winall",AddOnQuestDebug.Global.QuestSuccess,false},{"fail",AddOnQuestDebug.Global.QuestFailure,true},{"failall",AddOnQuestDebug.Global.QuestFailure,false},{"stop",AddOnQuestDebug.Global.QuestInterrupt,true},{"stopall",AddOnQuestDebug.Global.QuestInterrupt,false},{"start",AddOnQuestDebug.Global.QuestTrigger,true},{"startall",AddOnQuestDebug.Global.QuestTrigger,false},{"restart",AddOnQuestDebug.Global.QuestReset,true},{"restartall",AddOnQuestDebug.Global.QuestReset,false},{"printequal",AddOnQuestDebug.Global.PrintQuests,1},{"printactive",AddOnQuestDebug.Global.PrintQuests,2},{"printdetail",AddOnQuestDebug.Global.PrintQuests,3},{"lload",AddOnQuestDebug.Global.LoadScript,true},{"gload",AddOnQuestDebug.Global.LoadScript,false},{"lexec",AddOnQuestDebug.Global.ExecuteCommand,true},{"gexec",AddOnQuestDebug.Global.ExecuteCommand,false},{"collectgarbage",AddOnQuestDebug.Global.CollectGarbage},{"dumpmemory",AddOnQuestDebug.Global.CountLuaLoad}}
for BBp,Ymp0dS in pairs(_G)do
if

type(Ymp0dS)=="table"and Ymp0dS.Name and BBp==
"b_"..Ymp0dS.Name and Ymp0dS.CustomFunction and not Ymp0dS.CustomFunction2 then Ymp0dS.CustomFunction2=Ymp0dS.CustomFunction
Ymp0dS.CustomFunction=function(S2,DqcJg)
if
AddOnQuestDebug.Global.Data.CheckAtRun then if
S2.DEBUG and not S2.FOUND_ERROR and S2:DEBUG(DqcJg)then S2.FOUND_ERROR=true end end
if not S2.FOUND_ERROR then return S2:CustomFunction2(DqcJg)end end end end;self:OverwriteCreateQuests()
API.AddSaveGameAction(self.OnSaveGameLoad)end
function AddOnQuestDebug.Global:ActivateDebug(b9SvjY_,m,V,I5IP4R)
if self.Data.DebugModeIsActive then return end;self.Data.DebugModeIsActive=true
self.Data.CheckAtRun=b9SvjY_==true;self.Data.TraceQuests=m==true
self.Data.DevelopingCheats=V==true;self.Data.DevelopingShell=I5IP4R==true
self:ActivateQuestTrace()self:ActivateDevelopingCheats()
self:ActivateDevelopingShell()end
function AddOnQuestDebug.Global:ActivateQuestTrace()if self.Data.TraceQuests then
DEBUG_EnableQuestDebugKeys()DEBUG_QuestTrace(true)end end
function AddOnQuestDebug.Global:ActivateDevelopingCheats()if self.Data.DevelopingCheats then
Logic.ExecuteInLuaLocalState("AddOnQuestDebug.Local:ActivateDevelopingCheats()")end end
function AddOnQuestDebug.Global:ActivateDevelopingShell()if self.Data.DevelopingShell then
Logic.ExecuteInLuaLocalState("AddOnQuestDebug.Local:ActivateDevelopingShell()")end end
function AddOnQuestDebug.Global:Parser(Qfy_)local HQm_JlS8={}
local NWi=self:Tokenize(Qfy_)
for D0vQpsa,r_V_21 in pairs(NWi)do local wFI2A=string.lower(r_V_21[1])
for COL=1,#
AddOnQuestDebug.Global.Data.DebugCommands,1 do
if r_V_21[1]==
AddOnQuestDebug.Global.Data.DebugCommands[COL][1]then
local oHow=AddOnQuestDebug.Global.Data.DebugCommands[COL]for V0rk7x=2,#r_V_21,1 do local ZPkQ3=tonumber(r_V_21[V0rk7x])if ZPkQ3 then
r_V_21[V0rk7x]=ZPkQ3 end end
local XA=oHow[2](r_V_21,oHow[3])if XA then table.insert(HQm_JlS8,XA)end end end end;return HQm_JlS8 end;function eval(VxHi)
return AddOnQuestDebug.Global:Parser(VxHi)end
function AddOnQuestDebug.Global:Tokenize(oSTuph)local TPkH5={}
local tVhs={oSTuph}local S0U4Xe0h={oSTuph}local KJ5qWk,_ZXQ=string.find(oSTuph,"%s+&&%s+")
if
KJ5qWk then tVhs={}
while(KJ5qWk)do local cC=string.sub(oSTuph,1,KJ5qWk-1)
table.insert(tVhs,cC)oSTuph=string.sub(oSTuph,_ZXQ+1)
KJ5qWk,_ZXQ=string.find(oSTuph,"%s+&&%s+")end
if string.len(oSTuph)>0 then table.insert(tVhs,oSTuph)end end;if#tVhs>0 then S0U4Xe0h={}end
for hBH3AN3=1,#tVhs,1 do
local KJ5qWk,_ZXQ=string.find(tVhs[hBH3AN3],"%s+&%s+")
if KJ5qWk then local WB=""
while(KJ5qWk)do
local FCIV=string.sub(tVhs[hBH3AN3],1,KJ5qWk-1)table.insert(S0U4Xe0h,WB..FCIV)if string.find(FCIV," ")then
WB=string.sub(FCIV,1,
string.find(FCIV," ")-1).." "end;tVhs[hBH3AN3]=string.sub(tVhs[hBH3AN3],
_ZXQ+1)
KJ5qWk,_ZXQ=string.find(tVhs[hBH3AN3],"%s+&%s+")end;if string.len(tVhs[hBH3AN3])>0 then
table.insert(S0U4Xe0h,WB..tVhs[hBH3AN3])end else
table.insert(S0U4Xe0h,tVhs[hBH3AN3])end end
for tal6=1,#S0U4Xe0h,1 do local aJV10ZbH={}
local KJ5qWk,_ZXQ=string.find(S0U4Xe0h[tal6],"%s+")
if KJ5qWk then
while(KJ5qWk)do
local Gb=string.sub(S0U4Xe0h[tal6],1,KJ5qWk-1)table.insert(aJV10ZbH,Gb)
S0U4Xe0h[tal6]=string.sub(S0U4Xe0h[tal6],_ZXQ+1)KJ5qWk,_ZXQ=string.find(S0U4Xe0h[tal6],"%s+")end;table.insert(aJV10ZbH,S0U4Xe0h[tal6])else
table.insert(aJV10ZbH,S0U4Xe0h[tal6])end;table.insert(TPkH5,aJV10ZbH)end;return TPkH5 end;function AddOnQuestDebug.Global.CollectGarbage()collectgarbage()
Logic.ExecuteInLuaLocalState("AddOnQuestDebug.Local:CollectGarbage()")end
function AddOnQuestDebug.Global.CountLuaLoad()
Logic.ExecuteInLuaLocalState("AddOnQuestDebug.Local:CountLuaLoad()")local jw=collectgarbage("count")
API.StaticNote("Global Lua Size: "..jw)end
function AddOnQuestDebug.Global.PrintQuests(A,uiK)local mr0yvY9=""local ZwdI4bZ=0;local FLZy0ua=function(YD5JPPCW,M3Y1)return
YD5JPPCW.State==M3Y1 end
if
uiK==3 then return AddOnQuestDebug.PrintDetail(A)end
if uiK==1 then
FLZy0ua=function(VuV,n1bj7)return string.find(VuV.Identifier,n1bj7)end elseif uiK==2 then A[2]=QuestState.Active end
for xZEFbs1=1,Quests[0]do
if Quests[xZEFbs1]then
if FLZy0ua(Quests[xZEFbs1],A[2])then
ZwdI4bZ=ZwdI4bZ+1
if ZwdI4bZ<=15 then mr0yvY9=mr0yvY9 ..
((mr0yvY9:len()>0 and"{cr}")or"")mr0yvY9=mr0yvY9 ..
Quests[xZEFbs1].Identifier end end end end;if ZwdI4bZ>=15 then
mr0yvY9=mr0yvY9 .."{cr}{cr}("..
(ZwdI4bZ-15).." weitere Ergebnis(se) gefunden!)"end
Logic.ExecuteInLuaLocalState(
[[
        GUI.ClearNotes()
        GUI.AddStaticNote("]]..mr0yvY9 ..[[")
    ]])mr0yvY9=string.gsub(mr0yvY9,"{cr}","\n")return mr0yvY9 end
function AddOnQuestDebug.Global.PrintDetail(O)local O0=""
local ak=GetQuestID(string.gsub(O[2]," ",""))
if Quests[ak]then
local cF=
(Quests[ak].State==QuestState.NotTriggered and"not triggered")or
(Quests[ak].State==QuestState.Active and"active")or"over"
local K=

(Quests[ak].Result==QuestResult.Success and"success")or
(Quests[ak].Result==QuestResult.Failure and"failure")or
(Quests[ak].Result==
QuestResult.Interrupted and"interrupted")or"undecided"
O0=O0 .."Name: "..Quests[ak].Identifier.."{cr}"O0=O0 .."State: "..cF.."{cr}"O0=O0 ..
"Result: "..K.."{cr}"O0=O0 .."Sender: "..
Quests[ak].SendingPlayer.."{cr}"
O0=
O0 .."Receiver: "..Quests[ak].ReceivingPlayer.."{cr}"
O0=O0 .."Duration: "..Quests[ak].Duration.."{cr}"O0=O0 ..
"Start Text: "..tostring(Quests[ak].QuestStartMsg).."{cr}"O0=O0 ..

"Failure Text: "..tostring(Quests[ak].QuestFailureMsg).."{cr}"O0=O0 ..

"Success Text: "..tostring(Quests[ak].QuestSuccessMsg).."{cr}"O0=O0 ..

"Description: "..tostring(Quests[ak].QuestDescription).."{cr}"
O0=O0 ..
"Objectives: "..#Quests[ak].Objectives.."{cr}"O0=O0 ..
"Reprisals: "..#Quests[ak].Reprisals.."{cr}"
O0=O0 .."Rewards: "..#
Quests[ak].Rewards.."{cr}"
O0=O0 .."Triggers: "..#Quests[ak].Triggers.."{cr}"else O0=O0 ..tostring(O[2]).." not found!"end
Logic.ExecuteInLuaLocalState([[
        GUI.ClearNotes()
        GUI.AddStaticNote("]]..O0 ..[[")
    ]])O0=string.gsub(O0,"{cr}","\n")return O0 end
function AddOnQuestDebug.Global.LoadScript(KLDyw3U,G)
if KLDyw3U[2]then
if G==true then
Logic.ExecuteInLuaLocalState([[Script.Load("]]..
KLDyw3U[2]..[[")]])elseif G==false then Script.Load(KLDyw3U[2])end;if
not AddOnQuestDebug.Global.Data.SurpassMessages then
Logic.DEBUG_AddNote("load script "..KLDyw3U[2])end end end
function AddOnQuestDebug.Global.ExecuteCommand(PM9Sqn4,ensY)
if PM9Sqn4[2]then local U5gIdZ=""for M5A=2,#PM9Sqn4 do U5gIdZ=U5gIdZ.." "..
PM9Sqn4[M5A]end
if
ensY==true then
Logic.ExecuteInLuaLocalState([[]]..U5gIdZ..[[]])elseif ensY==false then
Logic.ExecuteInLuaLocalState([[GUI.SendScriptCommand("]]..U5gIdZ..[[")]])end end end;function AddOnQuestDebug.Global.Clear()
Logic.ExecuteInLuaLocalState("GUI.ClearNotes()")end;function AddOnQuestDebug.Global.Diplomacy(anG4iz)
SetDiplomacyState(anG4iz[2],anG4iz[3],anG4iz[4])end;function AddOnQuestDebug.Global.RestartMap()
Logic.ExecuteInLuaLocalState("Framework.RestartMap()")end;function AddOnQuestDebug.Global.ShareView(qDf4Jn)
Logic.SetShareExplorationWithPlayerFlag(qDf4Jn[2],qDf4Jn[3],qDf4Jn[4])end
function AddOnQuestDebug.Global.SetPosition(JeZq21)
local yMCqWrJN=GetID(JeZq21[2])local LKSqYp=GetID(JeZq21[3])
local XmuZ,m,ypyyO5=Logic.EntityGetPos(LKSqYp)if Logic.IsBuilding(LKSqYp)==1 then
XmuZ,m=Logic.GetBuildingApproachPosition(LKSqYp)end
Logic.DEBUG_SetSettlerPosition(yMCqWrJN,XmuZ,m)end;function AddOnQuestDebug.Global.ShowVersion()
API.Bridge("GUI.AddStaticNote(QSB.Version)")return QSB.Version end
function AddOnQuestDebug.Global.QuestSuccess(IWH,jg83BZw)
local RV=FindQuestsByName(IWH[2],jg83BZw)if#RV==0 then return end;API.WinAllQuests(unpack(RV))end
function AddOnQuestDebug.Global.QuestFailure(Rd,o)
local TlLbKE3f=FindQuestsByName(Rd[2],o)if#TlLbKE3f==0 then return end
API.FailAllQuests(unpack(TlLbKE3f))end
function AddOnQuestDebug.Global.QuestInterrupt(vzVPs,zqnaUK8)
local _q=FindQuestsByName(vzVPs[2],zqnaUK8)if#_q==0 then return end;API.StopAllQuests(unpack(_q))end
function AddOnQuestDebug.Global.QuestTrigger(sEv4cSNk,TAilwSF1)
local diKp6EQ=FindQuestsByName(sEv4cSNk[2],TAilwSF1)if#diKp6EQ==0 then return end
API.StartAllQuests(unpack(diKp6EQ))end
function AddOnQuestDebug.Global.QuestReset(Ob,aIq4dSM)
local P1YNd5qQ=FindQuestsByName(Ob[2],aIq4dSM)if#P1YNd5qQ==0 then return end
API.RestartAllQuests(unpack(P1YNd5qQ))end
function AddOnQuestDebug.Global.OverwriteCreateQuests()
AddOnQuestDebug.Global.Data.CreateQuestsOriginal=CreateQuests
CreateQuests=function()local _=Logic.Quest_GetQuestNames()
for IPqUQsL=1,#_,1 do local kw=_[IPqUQsL]
local K5iaOIeQ={Logic.Quest_GetQuestParamter(kw)}local RWV9xh8={}
local lBxBd=Logic.Quest_GetQuestNumberOfBehaviors(kw)
if lBxBd>0 then
for q=0,lBxBd-1,1 do
local p2cJ5=Logic.Quest_GetQuestBehaviorName(kw,q)local gPT=GetBehaviorTemplateByName(p2cJ5)
assert(gPT~=nil)local fUePAeAY=Logic.Quest_GetQuestBehaviorParameter(kw,q)
table.insert(RWV9xh8,gPT:new(unpack(fUePAeAY)))end
API.CreateQuest{Name=kw,Sender=K5iaOIeQ[1],Receiver=K5iaOIeQ[2],Time=K5iaOIeQ[4],Description=K5iaOIeQ[5],Suggestion=K5iaOIeQ[6],Failure=K5iaOIeQ[7],Success=K5iaOIeQ[8],unpack(RWV9xh8)}end end end end
function AddOnQuestDebug.Global.OnSaveGameLoad(LFn,wvoMUWLk)
AddOnQuestDebug.Global:ActivateDevelopingCheats()
AddOnQuestDebug.Global:ActivateDevelopingShell()
AddOnQuestDebug.Global:ActivateQuestTrace()end;function AddOnQuestDebug.Local:Install()end;function AddOnQuestDebug.Local:CollectGarbage()
collectgarbage()end
function AddOnQuestDebug.Local:CountLuaLoad()
local Ug2Cs=collectgarbage("count")API.StaticNote("Local Lua Size: "..Ug2Cs)end
function AddOnQuestDebug.Local:ActivateDevelopingCheats()
KeyBindings_EnableDebugMode(1)KeyBindings_EnableDebugMode(2)
KeyBindings_EnableDebugMode(3)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignTopLeft/GameClock",1)end
function AddOnQuestDebug.Local:ActivateDevelopingShell()GUI_Chat.Abort=function()end
GUI_Chat.Confirm=function()
Input.GameMode()
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatInput",0)
AddOnQuestDebug.Local.Data.ChatBoxInput=XGUIEng.GetText("/InGame/Root/Normal/ChatInput/ChatInput")g_Chat.JustClosed=1
Game.GameTimeSetFactor(GUI.GetPlayerID(),1)end
QSB_DEBUG_InputBoxJob=function()
if
not AddOnQuestDebug.Local.Data.BoxShown then Input.ChatMode()
Game.GameTimeSetFactor(GUI.GetPlayerID(),0)
XGUIEng.ShowWidget("/InGame/Root/Normal/ChatInput",1)
XGUIEng.SetText("/InGame/Root/Normal/ChatInput/ChatInput","")
XGUIEng.SetFocus("/InGame/Root/Normal/ChatInput/ChatInput")AddOnQuestDebug.Local.Data.BoxShown=true elseif
AddOnQuestDebug.Local.Data.ChatBoxInput then
AddOnQuestDebug.Local.Data.ChatBoxInput=string.gsub(AddOnQuestDebug.Local.Data.ChatBoxInput,"'","\'")
GUI.SendScriptCommand("AddOnQuestDebug.Global:Parser('"..
AddOnQuestDebug.Local.Data.ChatBoxInput.."')")AddOnQuestDebug.Local.Data.BoxShown=nil
return true end end
Input.KeyBindDown(Keys.ModifierShift+Keys.OemPipe,"StartSimpleJob('QSB_DEBUG_InputBoxJob')",2)end;Core:RegisterBundle("AddOnQuestDebug")
AddOnCastleStore={}API=API or{}QSB=QSB or{}function API.CastleStoreCreate(K4KEggK)if GUI then
API.Bridge("API.CastleStoreCreate("..K4KEggK..")")return end
return QSB.CastleStore:New(K4KEggK)end
function API.CastleStoreDestroy(mn1)if
GUI then
API.Bridge("API.CastleStoreCreate("..mn1 ..")")return end
local oKej=QSB.CastleStore:GetInstance(mn1)if oKej then oKej:Dispose()end end
function API.CastleStoreAddGood(t8Mc,jreWoiec,KCJuhHS)if GUI then
API.Bridge("API.CastleStoreAddGood("..t8Mc..
","..jreWoiec..","..KCJuhHS..")")return end
local B59eP=QSB.CastleStore:GetInstance(t8Mc)if B59eP then B59eP:Add(jreWoiec,KCJuhHS)end end
function API.CastleStoreRemoveGood(jo3,b,pdbSXE)if GUI then
API.Bridge("API.CastleStoreRemoveGood("..jo3 ..
","..b..","..pdbSXE..")")return end
local r5=QSB.CastleStore:GetInstance(jo3)if r5 then r5:Remove(b,pdbSXE)end end
function API.CastleStoreGetGoodAmount(yJI3,_vGVMvD)if GUI then
return QSB.CastleStore:GetAmount(yJI3,_vGVMvD)end
local w5Z1F1=QSB.CastleStore:GetInstance(yJI3)if w5Z1F1 then return w5Z1F1:GetAmount(_vGVMvD)end
return 0 end
function API.CastleStoreGetTotalAmount(YqAB)if GUI then
return QSB.CastleStore:GetTotalAmount(YqAB)end
local nirjQRs=QSB.CastleStore:GetInstance(YqAB)if nirjQRs then return nirjQRs:GetTotalAmount()end;return 0 end
function API.CastleStoreGetSize(Mnrt)
if GUI then return QSB.CastleStore:GetLimit(Mnrt)end;local Yw5YA=QSB.CastleStore:GetInstance(Mnrt)if Yw5YA then return
Yw5YA:GetLimit()end;return 0 end
function API.CastleStoreSetBaseCapacity(AEAvfg,IzvV)if GUI then
API.Bridge("API.CastleStoreSetBaseCapacity("..AEAvfg..","..IzvV..")")return end
local H=QSB.CastleStore:GetInstance(AEAvfg)if H then H:SetStorageLimit(IzvV)end end
function API.CastleStoreSetOutsourceBoundary(yd,lPMSGfm,sG7n8)if GUI then
API.Bridge("API.CastleStoreOutsourceBoundary("..yd..","..
lPMSGfm..","..sG7n8 ..")")return end
local wANY4u=QSB.CastleStore:GetInstance(yd)if wANY4u then
Stores:SetUperLimitInStorehouseForGoodType(lPMSGfm,sG7n8)end end
AddOnCastleStore={Global={Data={UpdateCastleStore=false,CastleStoreObjects={}},CastleStore={Data={CapacityBase=75,Goods={[Goods.G_Wood]={0,true,false,35},[Goods.G_Stone]={0,true,false,35},[Goods.G_Iron]={0,true,false,35},[Goods.G_Carcass]={0,true,false,15},[Goods.G_Grain]={0,true,false,15},[Goods.G_RawFish]={0,true,false,15},[Goods.G_Milk]={0,true,false,15},[Goods.G_Herb]={0,true,false,15},[Goods.G_Wool]={0,true,false,15},[Goods.G_Honeycomb]={0,true,false,15}}}}},Local={Data={},CastleStore={Data={}},Description={ShowCastle={Text={de="Finanzansicht",en="Financial view"}},ShowCastleStore={Text={de="Lageransicht",en="Storeage view"}},GoodButtonDisabled={Text={de="Diese Ware wird nicht angenommen.",en="This good will not be stored."}},CityTab={Title={de="Güter verwaren",en="Keep goods"},Text={de="[UMSCHALT + N]{cr}- Lagert Waren im Burglager ein {cr}- Waren verbleiben auch im Lager, wenn Platz vorhanden ist",en="[SHIFT + N]{cr}- Stores goods inside the vault {cr}- Goods also remain in the warehouse when space is available"}},StorehouseTab={Title={de="Güter zwischenlagern",en="Store in vault"},Text={de="[UMSCHALT + B]{cr}- Lagert Waren im Burglager ein {cr}- Lagert waren wieder aus, sobald Platz frei wird",en="[SHIFT + B]{cr}- Stores goods inside the vault {cr}- Allows to extrac goods as soon as space becomes available"}},MultiTab={Title={de="Lager räumen",en="Clear store"},Text={de="[UMSCHALT + M]{cr}- Lagert alle Waren aus {cr}- Benötigt Platz im Lagerhaus",en="[Shift + M]{cr}- Removes all goods {cr}- Requires space in the storehouse"}}}}}
function AddOnCastleStore.Global:Install()QSB.CastleStore=self.CastleStore
self:OverwriteGameFunctions()API.AddSaveGameAction(self.OnSaveGameLoaded)end
function AddOnCastleStore.Global.CastleStore:New(tI5LnSA)
assert(self==
AddOnCastleStore.Global.CastleStore,"Can not be used from instance!")local hZ0ZXf5c=API.InstanceTable(self)
hZ0ZXf5c.Data.PlayerID=tI5LnSA
AddOnCastleStore.Global.Data.CastleStoreObjects[tI5LnSA]=hZ0ZXf5c;if not self.Data.UpdateCastleStore then self.Data.UpdateCastleStore=true
StartSimpleJobEx(AddOnCastleStore.Global.CastleStore.UpdateStores)end
Logic.ExecuteInLuaLocalState(
[[
        QSB.CastleStore:CreateStore(]]..hZ0ZXf5c.Data.PlayerID..[[);
    ]])return hZ0ZXf5c end
function AddOnCastleStore.Global.CastleStore:GetInstance(bsGi)
assert(self==
AddOnCastleStore.Global.CastleStore,"Can not be used from instance!")return
AddOnCastleStore.Global.Data.CastleStoreObjects[bsGi]end
function AddOnCastleStore.Global.CastleStore:GetGoodAmountWithCastleStore(P,E)
assert(self==
AddOnCastleStore.Global.CastleStore,"Can not be used from instance!")local HNabeH=self:GetInstance(E)
local Jyj2UBYh=GetPlayerGoodsInSettlement(P,E,true)
if
HNabeH~=nil and P~=Goods.G_Gold and
Logic.GetGoodCategoryForGoodType(P)==GoodCategories.GC_Resource then Jyj2UBYh=Jyj2UBYh+HNabeH:GetAmount(P)end;return Jyj2UBYh end
function AddOnCastleStore.Global.CastleStore:Dispose()
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLuaLocalState([[
        QSB.CastleStore:DeleteStore(]]..self.Data.PlayerID..[[);
    ]])AddOnCastleStore.Global.Data.CastleStoreObjects[self.Data.PlayerID]=
nil end
function AddOnCastleStore.Global.CastleStore:SetUperLimitInStorehouseForGoodType(xGl,ktL)
assert(
self~=AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")self.Data.Goods[xGl][4]=ktL
Logic.ExecuteInLuaLocalState(
[[
        AddOnCastleStore.Local.Data.CastleStore[]]..self.Data.PlayerID..
[[].Goods[]]..xGl..[[][4] = ]]..ktL..[[
    ]])return self end
function AddOnCastleStore.Global.CastleStore:SetStorageLimit(oKNn)
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")self.Data.CapacityBase=math.floor(oKNn/2)
Logic.ExecuteInLuaLocalState(
[[
        AddOnCastleStore.Local.Data.CastleStore[]]..self.Data.PlayerID..
[[].CapacityBase = ]]..math.floor(oKNn/2)..[[
    ]])return self end
function AddOnCastleStore.Global.CastleStore:GetAmount(_CCA_0mj)
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")if self.Data.Goods[_CCA_0mj]then return
self.Data.Goods[_CCA_0mj][1]end;return 0 end
function AddOnCastleStore.Global.CastleStore:GetTotalAmount()
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")local qzsV=0
for cW3,eFXmR9 in pairs(self.Data.Goods)do qzsV=qzsV+eFXmR9[1]end;return qzsV end
function AddOnCastleStore.Global.CastleStore:GetLimit()
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")local wtF1lx5=0
local e9jy=Logic.GetHeadquarters(self.Data.PlayerID)
if e9jy~=0 then wtF1lx5=Logic.GetUpgradeLevel(e9jy)end;local sKhlm=self.Data.CapacityBase
for KI=1,(wtF1lx5+1),1 do sKhlm=sKhlm*2 end;return sKhlm end
function AddOnCastleStore.Global.CastleStore:IsGoodAccepted(q0rlv)
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")
return self.Data.Goods[q0rlv][2]==true end
function AddOnCastleStore.Global.CastleStore:SetGoodAccepted(Br6q1mk,UJwh5Pw)
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")
self.Data.Goods[Br6q1mk][2]=UJwh5Pw==true
Logic.ExecuteInLuaLocalState([[
        QSB.CastleStore:SetAccepted(
            ]]..
self.Data.PlayerID..[[, ]]..Br6q1mk..
[[, ]]..tostring(
UJwh5Pw==true)..[[
        )
    ]])return self end
function AddOnCastleStore.Global.CastleStore:IsGoodLocked(AU7uLy85)
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")
return self.Data.Goods[AU7uLy85][3]==true end
function AddOnCastleStore.Global.CastleStore:SetGoodLocked(ifvo,rNeEPXM)
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")self.Data.Goods[ifvo][3]=rNeEPXM==true
Logic.ExecuteInLuaLocalState(
[[
        QSB.CastleStore:SetLocked(
            ]]..self.Data.PlayerID..
[[, ]]..ifvo..[[, ]]..
tostring(rNeEPXM==true)..[[
        )
    ]])return self end
function AddOnCastleStore.Global.CastleStore:ActivateTemporaryMode()
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLocalLuaState([[
        QSB.CastleStore.OnStorehouseTabClicked(QSB.CastleStore, ]]..
self.Data.PlayerID..[[)
    ]])return self end
function AddOnCastleStore.Global.CastleStore:ActivateStockMode()
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLocalLuaState([[
        QSB.CastleStore.OnCityTabClicked(QSB.CastleStore, ]]..
self.Data.PlayerID..[[)
    ]])return self end
function AddOnCastleStore.Global.CastleStore:ActivateOutsourceMode()
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")
Logic.ExecuteInLocalLuaState([[
        QSB.CastleStore.OnMultiTabClicked(QSB.CastleStore, ]]..
self.Data.PlayerID..[[)
    ]])return self end
function AddOnCastleStore.Global.CastleStore:Store(HCp2GJri,gYyFosn)
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")
if self:IsGoodAccepted(HCp2GJri)then
if self:GetLimit()>=
self:GetTotalAmount()+gYyFosn then
local jr=Logic.GetUpgradeLevel(Logic.GetHeadquarters(self.Data.PlayerID))
if
GetPlayerResources(HCp2GJri,self.Data.PlayerID)> (
self.Data.Goods[HCp2GJri][4]* (jr+1))then
AddGood(HCp2GJri,gYyFosn* (-1),self.Data.PlayerID)self.Data.Goods[HCp2GJri][1]=
self.Data.Goods[HCp2GJri][1]+gYyFosn
Logic.ExecuteInLuaLocalState(
[[
                    QSB.CastleStore:SetAmount(
                        ]]..self.Data.PlayerID..
[[, ]]..HCp2GJri..
[[, ]]..self.Data.Goods[HCp2GJri][1]..
[[
                    )
                ]])end end end;return self end
function AddOnCastleStore.Global.CastleStore:Outsource(L,UAm)
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")
local RY=Logic.GetUpgradeLevel(Logic.GetHeadquarters(self.Data.PlayerID))
if
Logic.GetPlayerUnreservedStorehouseSpace(self.Data.PlayerID)>=UAm then
if self:GetAmount(L)>=UAm then
AddGood(L,UAm,self.Data.PlayerID)
self.Data.Goods[L][1]=self.Data.Goods[L][1]-UAm
Logic.ExecuteInLuaLocalState([[
                QSB.CastleStore:SetAmount(
                    ]]..
self.Data.PlayerID..[[, ]]..L..
[[, ]]..
self.Data.Goods[L][1]..[[
                )
            ]])end end;return self end
function AddOnCastleStore.Global.CastleStore:Add(zaZKcMVP,UgNF)
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")for d3g=1,UgNF,1 do
if self:GetLimit()>self:GetTotalAmount()then self.Data.Goods[zaZKcMVP][1]=
self.Data.Goods[zaZKcMVP][1]+1 end end
Logic.ExecuteInLuaLocalState(
[[
        QSB.CastleStore:SetAmount(
            ]]..
self.Data.PlayerID..[[, ]]..
zaZKcMVP..[[, ]]..self.Data.Goods[zaZKcMVP][1]..
[[
        )
    ]])return self end
function AddOnCastleStore.Global.CastleStore:Remove(Dtxkh,jvv2)
assert(self~=
AddOnCastleStore.Global.CastleStore,"Can not be used in static context!")
if self:GetAmount(Dtxkh)>0 then
local ZLBXwY=
(jvv2 <=self:GetAmount(Dtxkh)and jvv2)or self:GetAmount(Dtxkh)self.Data.Goods[Dtxkh][1]=
self.Data.Goods[Dtxkh][1]-ZLBXwY
Logic.ExecuteInLuaLocalState(
[[
            QSB.CastleStore:SetAmount(
                ]]..
self.Data.PlayerID..[[, ]]..
Dtxkh..[[, ]]..self.Data.Goods[Dtxkh][1]..
[[
            )
        ]])end;return self end
function AddOnCastleStore.Global.CastleStore.UpdateStores()
assert(self==nil,"This method is only procedural!")
for DsnHMB,jClZ_J in
pairs(AddOnCastleStore.Global.Data.CastleStoreObjects)do
if jClZ_J~=nil then
local zde=Logic.GetUpgradeLevel(Logic.GetHeadquarters(jClZ_J.Data.PlayerID))
for s,jGocGLi in pairs(jClZ_J.Data.Goods)do
if jGocGLi~=nil then
if jGocGLi[2]==true then
local Ddl=GetPlayerResources(s,jClZ_J.Data.PlayerID)local Ixo=jClZ_J:GetAmount(s)
if Ddl< (
jClZ_J.Data.Goods[s][4]* (zde+1))then
if
jGocGLi[3]==false then local le_8Imi=
(jClZ_J.Data.Goods[s][4]* (zde+1))-Ddl;le_8Imi=
(le_8Imi>10 and 10)or le_8Imi
for SnMe=1,le_8Imi,1 do jClZ_J:Outsource(s,1)end end else local ItCltM4j=(Ddl>10 and 10)or Ddl;for V=1,ItCltM4j,1 do
jClZ_J:Store(s,1)end end else local U7=(jClZ_J:GetAmount(s)>=10 and 10)or
jClZ_J:GetAmount(s)for tPxJvfIm=1,U7,1 do
jClZ_J:Outsource(s,1)end end end end end end end
function AddOnCastleStore.Global.OnSaveGameLoaded()
API.Bridge("AddOnCastleStore.Local:OverwriteGetStringTableText()")
API.Bridge("AddOnCastleStore.Local.CastleStore:ActivateHotkeys()")end
function AddOnCastleStore.Global:OverwriteGameFunctions()
QuestTemplate.IsObjectiveCompleted_Orig_QSB_CastleStore=QuestTemplate.IsObjectiveCompleted
QuestTemplate.IsObjectiveCompleted=function(h_XGi,d)local ioV91a=d.Type;local YuXD=d.Data;if d.Completed~=nil then
return d.Completed end
if ioV91a==Objective.Produce then
local sOkLu=GetPlayerGoodsInSettlement(YuXD[1],h_XGi.ReceivingPlayer,true)
local dWsHKph=QSB.CastleStore:GetInstance(h_XGi.ReceivingPlayer)
if dWsHKph and
Logic.GetGoodCategoryForGoodType(YuXD[1])==GoodCategories.GC_Resource then sOkLu=sOkLu+
dWsHKph:GetAmount(YuXD[1])end
if(not YuXD[3]and sOkLu>=YuXD[2])or(YuXD[3]and
sOkLu<YuXD[2])then d.Completed=true end else
return QuestTemplate.IsObjectiveCompleted_Orig_QSB_CastleStore(h_XGi,d)end end
QuestTemplate.SendGoods=function(aLc)
for bg=1,aLc.Objectives[0]do
if aLc.Objectives[bg].Type==
Objective.Deliver then
if
aLc.Objectives[bg].Data[3]==nil then local cA=aLc.Objectives[bg].Data[1]
local Pt=aLc.Objectives[bg].Data[2]
local U9P1X4o9=QSB.CastleStore:GetGoodAmountWithCastleStore(cA,aLc.ReceivingPlayer,true)
if U9P1X4o9 >=Pt then local B7iRHUj=aLc.ReceivingPlayer
local B7C8=
aLc.Objectives[bg].Data[6]and aLc.Objectives[bg].Data[6]or
aLc.SendingPlayer;local uikbyc={}uikbyc.Good=cA;uikbyc.Amount=Pt;uikbyc.PlayerID=B7C8
uikbyc.ID=nil;aLc.Objectives[bg].Data[5]=uikbyc
aLc.Objectives[bg].Data[3]=1;QuestMerchants[#QuestMerchants+1]=uikbyc
if cA==
Goods.G_Gold then local lbxEE=Logic.GetHeadquarters(B7iRHUj)if lbxEE==0 then
lbxEE=Logic.GetStoreHouse(B7iRHUj)end
aLc.Objectives[bg].Data[3]=Logic.CreateEntityAtBuilding(Entities.U_GoldCart,lbxEE,0,B7C8)
Logic.HireMerchant(aLc.Objectives[bg].Data[3],B7C8,cA,Pt,aLc.ReceivingPlayer)Logic.RemoveGoodFromStock(lbxEE,cA,Pt)if MapCallback_DeliverCartSpawned then
MapCallback_DeliverCartSpawned(aLc,aLc.Objectives[bg].Data[3],cA)end elseif cA==Goods.G_Water then
local m=Logic.GetMarketplace(B7iRHUj)
aLc.Objectives[bg].Data[3]=Logic.CreateEntityAtBuilding(Entities.U_Marketer,m,0,B7C8)
Logic.HireMerchant(aLc.Objectives[bg].Data[3],B7C8,cA,Pt,aLc.ReceivingPlayer)Logic.RemoveGoodFromStock(m,cA,Pt)if MapCallback_DeliverCartSpawned then
MapCallback_DeliverCartSpawned(aLc,aLc.Objectives[bg].Data[3],cA)end else
if
Logic.GetGoodCategoryForGoodType(cA)==GoodCategories.GC_Resource then
local g=Logic.GetStoreHouse(B7C8)local vCtUvsA=Logic.GetNumberOfGoodTypesOnOutStock(g)
if
vCtUvsA~=nil then
for FbEE=0,vCtUvsA-1 do
local ivWwJX0=Logic.GetGoodTypeOnOutStockByIndex(g,FbEE)local t=Logic.GetAmountOnOutStockByIndex(g,FbEE)if t>=Pt then
Logic.RemoveGoodFromStock(g,ivWwJX0,Pt,false)end end end;local CO8Ag7HO=Logic.GetStoreHouse(B7iRHUj)
local eLs=GetPlayerResources(cA,B7iRHUj)
if eLs<Pt then local T3_=Pt-eLs;AddGood(cA,eLs* (-1),B7iRHUj)
local DQM=QSB.CastleStore:GetInstance(aLc.ReceivingPlayer)if DQM then DQM:Remove(cA,T3_)end else
AddGood(cA,Pt* (-1),B7iRHUj)end
aLc.Objectives[bg].Data[3]=Logic.CreateEntityAtBuilding(Entities.U_ResourceMerchant,CO8Ag7HO,0,B7C8)
Logic.HireMerchant(aLc.Objectives[bg].Data[3],B7C8,cA,Pt,aLc.ReceivingPlayer)else
Logic.StartTradeGoodGathering(B7iRHUj,B7C8,cA,Pt,0)end end end end end end end end
function AddOnCastleStore.Local:Install()QSB.CastleStore=self.CastleStore
self:OverwriteGameFunctions()self:OverwriteGetStringTableText()
self:OverwriteInteractiveObject()end
function AddOnCastleStore.Local.CastleStore:CreateStore(BIKqyT)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")
local C={StoreMode=1,CapacityBase=75,Goods={[Goods.G_Wood]={0,true,false,35},[Goods.G_Stone]={0,true,false,35},[Goods.G_Iron]={0,true,false,35},[Goods.G_Carcass]={0,true,false,15},[Goods.G_Grain]={0,true,false,15},[Goods.G_RawFish]={0,true,false,15},[Goods.G_Milk]={0,true,false,15},[Goods.G_Herb]={0,true,false,15},[Goods.G_Wool]={0,true,false,15},[Goods.G_Honeycomb]={0,true,false,15}}}self.Data[BIKqyT]=C;self:ActivateHotkeys()
self:DescribeHotkeys()end
function AddOnCastleStore.Local.CastleStore:DeleteStore(T2W)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")self.Data[T2W]=nil end
function AddOnCastleStore.Local.CastleStore:GetAmount(xNwe,dCSN4)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(xNwe)then return 0 end;return
self.Data[xNwe].Goods[dCSN4][1]end
function AddOnCastleStore.Local.CastleStore:GetGoodAmountWithCastleStore(izS,YU2h)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")local P3Xt=GetPlayerGoodsInSettlement(izS,YU2h,true)
if
self:HasCastleStore(YU2h)then
if
izS~=Goods.G_Gold and Logic.GetGoodCategoryForGoodType(izS)==
GoodCategories.GC_Resource then P3Xt=P3Xt+self:GetAmount(YU2h,izS)end end;return P3Xt end
function AddOnCastleStore.Local.CastleStore:GetTotalAmount(T3)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(T3)then return 0 end;local ci716=0;for mDwX4_,kN4tg6 in
pairs(self.Data[T3].Goods)do ci716=ci716+kN4tg6[1]end
return ci716 end
function AddOnCastleStore.Local.CastleStore:SetAmount(x,wPKv,WWo)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(x)then return end
self.Data[x].Goods[wPKv][1]=WWo;return self end
function AddOnCastleStore.Local.CastleStore:IsAccepted(Oj9qNQ,lqOp)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")
if not self:HasCastleStore(Oj9qNQ)then return false end
if not self.Data[Oj9qNQ].Goods[lqOp]then return false end;return
self.Data[Oj9qNQ].Goods[lqOp][2]==true end
function AddOnCastleStore.Local.CastleStore:SetAccepted(HT,v1jDQnBp,wbSWhZz7)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")if self:HasCastleStore(HT)then
if self.Data[HT].Goods[v1jDQnBp]then self.Data[HT].Goods[v1jDQnBp][2]=
wbSWhZz7 ==true end end;return self end
function AddOnCastleStore.Local.CastleStore:IsLocked(k8tdNn0p,fXHaGjQ)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")
if not self:HasCastleStore(k8tdNn0p)then return true end;if not self.Data[k8tdNn0p].Goods[fXHaGjQ]then
return false end;return
self.Data[k8tdNn0p].Goods[fXHaGjQ][3]==true end
function AddOnCastleStore.Local.CastleStore:SetLocked(pTN,ce,E2Ln7)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")
if self:HasCastleStore(pTN)then if self.Data[pTN].Goods[ce]then self.Data[pTN].Goods[ce][3]=
E2Ln7 ==true end end;return self end
function AddOnCastleStore.Local.CastleStore:HasCastleStore(gt)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")return self.Data[gt]~=nil end
function AddOnCastleStore.Local.CastleStore:GetStore(ToswiR)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")return self.Data[ToswiR]end
function AddOnCastleStore.Local.CastleStore:GetLimit(L8Ub)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")local M4=0;local wAJr=Logic.GetHeadquarters(L8Ub)if wAJr~=0 then
M4=Logic.GetUpgradeLevel(wAJr)end
local ZdqOOSE=self.Data[L8Ub].CapacityBase;for pun0PwS=1,(M4+1),1 do ZdqOOSE=ZdqOOSE*2 end;return ZdqOOSE end
function AddOnCastleStore.Local.CastleStore:OnStorehouseTabClicked(Y9)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")self.Data[Y9].StoreMode=1
self:UpdateBehaviorTabs(Y9)
GUI.SendScriptCommand([[
        local Store = QSB.CastleStore:GetInstance(]]..
Y9 ..
[[);
        for k, v in pairs(Store.Data.Goods) do
            Store:SetGoodAccepted(k, true);
            Store:SetGoodLocked(k, false);
        end
    ]])end
function AddOnCastleStore.Local.CastleStore:OnCityTabClicked(fsFM)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")self.Data[fsFM].StoreMode=2
self:UpdateBehaviorTabs(fsFM)
GUI.SendScriptCommand([[
        local Store = QSB.CastleStore:GetInstance(]]..
fsFM..
[[);
        for k, v in pairs(Store.Data.Goods) do
            Store:SetGoodAccepted(k, true);
            Store:SetGoodLocked(k, true);
        end
    ]])end
function AddOnCastleStore.Local.CastleStore:OnMultiTabClicked(bQ2dS)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")self.Data[bQ2dS].StoreMode=3
self:UpdateBehaviorTabs(bQ2dS)
GUI.SendScriptCommand([[
        local Store = QSB.CastleStore:GetInstance(]]..
bQ2dS..
[[);
        for k, v in pairs(Store.Data.Goods) do
            Store:SetGoodLocked(k, false);
            Store:SetGoodAccepted(k, false);
        end
    ]])end
function AddOnCastleStore.Local.CastleStore:GoodClicked(YYupSw,dZ_T)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")
if self:HasCastleStore(YYupSw)then
local akyNsRQ=XGUIEng.GetCurrentWidgetID()
GUI.SendScriptCommand([[
            local Store = QSB.CastleStore:GetInstance(]]..
YYupSw..
[[);
            local Accepted = Store:IsGoodAccepted(]]..
dZ_T..

[[)
            local Locked   = Store:IsGoodLocked(]]..
dZ_T..
[[)
            
            if Accepted and not Locked then
                Store:SetGoodLocked(]]..
dZ_T..

[[, true);
                Store:SetGoodAccepted(]]..
dZ_T..
[[, true);
            elseif Accepted and Locked then
                Store:SetGoodLocked(]]..
dZ_T..

[[, false);
                Store:SetGoodAccepted(]]..
dZ_T..
[[, false);
            elseif not Accepted and not Locked then
                Store:SetGoodAccepted(]]..
dZ_T..

[[, true);
            else
                Store:SetGoodLocked(]]..dZ_T..
[[, false);
                Store:SetGoodAccepted(]]..dZ_T..[[, true);
            end
        ]])end end
function AddOnCastleStore.Local.CastleStore:DestroyGoodsClicked(T9)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")if self:HasCastleStore(T9)then
QSB.CastleStore.ToggleStore()end end
function AddOnCastleStore.Local.CastleStore:SelectionChanged(TwH9I)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")
if self:HasCastleStore(TwH9I)then local giotE=GUI.GetSelectedEntity()if
Logic.GetHeadquarters(TwH9I)==giotE then self:ShowCastleMenu()else
self:RestoreStorehouseMenu()end end end
function AddOnCastleStore.Local.CastleStore:UpdateBehaviorTabs(gcNJ)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")if
not QSB.CastleStore:HasCastleStore(GUI.GetPlayerID())then return end
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons",0)
if self.Data[gcNJ].StoreMode==1 then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/StorehouseTabButtonUp",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/CityTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/Tab03Down",1)elseif self.Data[gcNJ].StoreMode==2 then
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/StorehouseTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/CityTabButtonUp",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/Tab03Down",1)else
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/StorehouseTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/CityTabButtonDown",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/Tab03Up",1)end end
function AddOnCastleStore.Local.CastleStore:UpdateGoodsDisplay(Fwx)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(Fwx)then return end
local kWfTukq="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InStorehouse/Goods"local u=""if self:GetLimit(Fwx)==self:GetTotalAmount(Fwx)then
u="{@color:255,32,32,255}"end
for hsEHPXH,G5R_2C2 in
pairs(self.Data[Fwx].Goods)do local TDd=Logic.GetGoodTypeName(hsEHPXH)local O=kWfTukq..
"/"..TDd.."/Amount"
local poRi=kWfTukq.."/"..TDd.."/Button"local gcaZM1=kWfTukq.."/"..TDd.."/BG"XGUIEng.SetText(O,"{center}"..u..
G5R_2C2[1])
XGUIEng.DisableButton(poRi,0)
if
self:IsAccepted(Fwx,hsEHPXH)and self:IsLocked(Fwx,hsEHPXH)then XGUIEng.SetMaterialColor(poRi,0,230,180,120,255)
XGUIEng.SetMaterialColor(poRi,1,230,180,120,255)XGUIEng.SetMaterialColor(poRi,7,230,180,120,255)elseif
not
self:IsAccepted(Fwx,hsEHPXH)and not self:IsLocked(Fwx,hsEHPXH)then XGUIEng.SetMaterialColor(poRi,0,190,90,90,255)
XGUIEng.SetMaterialColor(poRi,1,190,90,90,255)XGUIEng.SetMaterialColor(poRi,7,190,90,90,255)else
XGUIEng.SetMaterialColor(poRi,0,255,255,255,255)XGUIEng.SetMaterialColor(poRi,1,255,255,255,255)
XGUIEng.SetMaterialColor(poRi,7,255,255,255,255)end end end
function AddOnCastleStore.Local.CastleStore:UpdateStorageLimit(P)
assert(self==
AddOnCastleStore.Local.CastleStore,"Can not be used from instance!")if not self:HasCastleStore(P)then return end
local BkkAG0N=XGUIEng.GetCurrentWidgetID()local fy=GUI.GetPlayerID()
local MpHkXHA=QSB.CastleStore:GetTotalAmount(fy)local skDX4=QSB.CastleStore:GetLimit(fy)
local CRn=XGUIEng.GetStringTableText("UI_Texts/StorageLimit_colon")
local RVQ="{center}"..CRn.." "..MpHkXHA.."/"..skDX4;XGUIEng.SetText(BkkAG0N,RVQ)end
function AddOnCastleStore.Local.CastleStore:ToggleStore()
assert(self==nil,"This function is procedural!")
if QSB.CastleStore:HasCastleStore(GUI.GetPlayerID())then
if
Logic.GetHeadquarters(GUI.GetPlayerID())==GUI.GetSelectedEntity()then
if
XGUIEng.IsWidgetShown("/InGame/Root/Normal/AlignBottomRight/Selection/Castle")==1 then
QSB.CastleStore.ShowCastleStoreMenu(QSB.CastleStore)else
QSB.CastleStore.ShowCastleMenu(QSB.CastleStore)end end end end
function AddOnCastleStore.Local.CastleStore:RestoreStorehouseMenu()
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons",1)
XGUIEng.ShowAllSubWidgets("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InCity/Goods",1)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InCity",0)
SetIcon("/InGame/Root/Normal/AlignBottomRight/DialogButtons/PlayerButtons/DestroyGoods",{16,8})
local aBxe6Km="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/"
SetIcon(aBxe6Km.."StorehouseTabButtonUp/up/B_StoreHouse",{3,13})
SetIcon(aBxe6Km.."StorehouseTabButtonDown/down/B_StoreHouse",{3,13})
SetIcon(aBxe6Km.."CityTabButtonUp/up/CityBuildingsNumber",{8,1})
SetIcon(aBxe6Km.."TabButtons/CityTabButtonDown/down/CityBuildingsNumber",{8,1})
SetIcon(aBxe6Km.."TabButtons/Tab03Up/up/B_Castle_ME",{3,14})
SetIcon(aBxe6Km.."Tab03Down/down/B_Castle_ME",{3,14})
for S4TnvF5,l9mx8 in
ipairs{"G_Carcass","G_Grain","G_Milk","G_RawFish","G_Iron","G_Wood","G_Stone","G_Honeycomb","G_Herb","G_Wool"}do
local aBxe6Km="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/InStorehouse/Goods/"
XGUIEng.SetMaterialColor(aBxe6Km..l9mx8 .."/Button",0,255,255,255,255)
XGUIEng.SetMaterialColor(aBxe6Km..l9mx8 .."/Button",1,255,255,255,255)
XGUIEng.SetMaterialColor(aBxe6Km..l9mx8 .."/Button",7,255,255,255,255)end end
function AddOnCastleStore.Local.CastleStore:ShowCastleMenu()
local a_pa8="/InGame/Root/Normal/AlignBottomRight/"
XGUIEng.ShowWidget(a_pa8 .."Selection/BGBig",0)
XGUIEng.ShowWidget(a_pa8 .."Selection/Storehouse",0)
XGUIEng.ShowWidget(a_pa8 .."Selection/BGSmall",1)
XGUIEng.ShowWidget(a_pa8 .."Selection/Castle",1)
if g_HideSoldierPayment~=nil then
XGUIEng.ShowWidget(a_pa8 .."Selection/Castle/Treasury/Payment",0)
XGUIEng.ShowWidget(a_pa8 .."Selection/Castle/LimitSoldiers",0)end;GUI_BuildingInfo.PaymentLevelSliderUpdate()
GUI_BuildingInfo.TaxationLevelSliderUpdate()GUI_Trade.StorehouseSelected()
local iJz9mr,lKGoVZ=XGUIEng.GetWidgetLocalPosition(a_pa8 ..
"Selection/AnchorInfoForSmall")
XGUIEng.SetWidgetLocalPosition(a_pa8 .."Selection/Info",iJz9mr,lKGoVZ)
XGUIEng.ShowWidget(a_pa8 .."DialogButtons/PlayerButtons",1)
XGUIEng.ShowWidget(a_pa8 .."DialogButtons/PlayerButtons/DestroyGoods",1)
XGUIEng.DisableButton(a_pa8 .."DialogButtons/PlayerButtons/DestroyGoods",0)
SetIcon(a_pa8 .."DialogButtons/PlayerButtons/DestroyGoods",{10,9})end
function AddOnCastleStore.Local.CastleStore:ShowCastleStoreMenu()
local opk="/InGame/Root/Normal/AlignBottomRight/"
XGUIEng.ShowWidget(opk.."Selection/Selection/BGSmall",0)
XGUIEng.ShowWidget(opk.."Selection/Castle",0)
XGUIEng.ShowWidget(opk.."Selection/BGSmall",0)
XGUIEng.ShowWidget(opk.."Selection/BGBig",1)
XGUIEng.ShowWidget(opk.."Selection/Storehouse",1)
XGUIEng.ShowWidget(opk.."Selection/Storehouse/AmountContainer",0)
XGUIEng.ShowAllSubWidgets(opk.."Selection/Storehouse/TabButtons",1)GUI_Trade.StorehouseSelected()
local CfQt5,q=XGUIEng.GetWidgetLocalPosition(opk..
"Selection/AnchorInfoForBig")
XGUIEng.SetWidgetLocalPosition(opk.."Selection/Info",CfQt5,q)
XGUIEng.ShowWidget(opk.."DialogButtons/PlayerButtons",1)
XGUIEng.ShowWidget(opk.."DialogButtons/PlayerButtons/DestroyGoods",1)
XGUIEng.ShowWidget(opk.."Selection/Storehouse/InStorehouse",1)
XGUIEng.ShowWidget(opk.."Selection/Storehouse/InMulti",0)
XGUIEng.ShowWidget(opk.."Selection/Storehouse/InCity",1)
XGUIEng.ShowAllSubWidgets(opk.."Selection/Storehouse/InCity/Goods",0)
XGUIEng.ShowWidget(opk.."Selection/Storehouse/InCity/Goods/G_Beer",1)
XGUIEng.DisableButton(opk.."DialogButtons/PlayerButtons/DestroyGoods",0)local gyP8W=opk.."DialogButtons/PlayerButtons/"local GT=opk..
"Selection/Storehouse/TabButtons/"
SetIcon(gyP8W.."DestroyGoods",{3,14})
SetIcon(GT.."StorehouseTabButtonUp/up/B_StoreHouse",{10,9})
SetIcon(GT.."StorehouseTabButtonDown/down/B_StoreHouse",{10,9})
SetIcon(GT.."CityTabButtonUp/up/CityBuildingsNumber",{15,6})
SetIcon(GT.."CityTabButtonDown/down/CityBuildingsNumber",{15,6})
SetIcon(GT.."Tab03Up/up/B_Castle_ME",{7,1})
SetIcon(GT.."Tab03Down/down/B_Castle_ME",{7,1})self:UpdateBehaviorTabs(GUI.GetPlayerID())end
function AddOnCastleStore.Local:OverwriteInteractiveObject()
function BundleInteractiveObjects.Local:CanBeBought(T,F,zWkDUfk)
local N4nlpcU=GetPlayerGoodsInSettlement(F,T,true)
if
AddOnCastleStore.Local.CastleStore:HasCastleStore(T)then
if
Logic.GetGoodCategoryForGoodType(F)==GoodCategories.GC_Resource and F~=Goods.G_Gold then
local dHZp=AddOnCastleStore.Local.CastleStore:GetAmount(T,F)N4nlpcU=N4nlpcU+dHZp end end;if N4nlpcU<zWkDUfk then return false end;return true end
function BundleInteractiveObjects.Local:BuyObject(xnZZC1SR,fS6o,q8hmKJ)
if

Logic.GetGoodCategoryForGoodType(fS6o)~=GoodCategories.GC_Resource and fS6o~=Goods.G_Gold then local H5v14pe=GetPlayerEntities(xnZZC1SR,0)local wzuw=q8hmKJ
for Ni5=1,#H5v14pe do
if
Logic.IsBuilding(H5v14pe[Ni5])==1 and wzuw>0 then
if
Logic.GetBuildingProduct(H5v14pe[Ni5])==fS6o then
local Cb3N2Qh=Logic.GetAmountOnOutStockByIndex(H5v14pe[Ni5],0)for srmc1m=1,Cb3N2Qh do
API.Bridge("Logic.RemoveGoodFromStock("..H5v14pe[Ni5]..","..fS6o..",1)")wzuw=wzuw-1 end end end end else local fPaHGML=GetPlayerGoodsInSettlement(fS6o,xnZZC1SR,true)
local C=((
fPaHGML-q8hmKJ)>=0 and q8hmKJ)or fPaHGML
API.Bridge("AddGood("..fS6o..
", ".. (C* (-1))..", "..xnZZC1SR..")")
if
AddOnCastleStore.Local.CastleStore:HasCastleStore(xnZZC1SR)then q8hmKJ=q8hmKJ-C;if q8hmKJ>0 then
API.Bridge("QSB.CastleStore:GetInstance("..xnZZC1SR.."):Remove("..fS6o..
", "..q8hmKJ..")")end end end end end
function AddOnCastleStore.Local.CastleStore:HotkeyStoreGoods()
local nCusKIVw=GUI.GetPlayerID()
if
AddOnCastleStore.Local.CastleStore:HasCastleStore(nCusKIVw)==false then return end
AddOnCastleStore.Local.CastleStore:OnStorehouseTabClicked(nCusKIVw)end
function AddOnCastleStore.Local.CastleStore:HotkeyLockGoods()
local D5PCrHJF=GUI.GetPlayerID()
if
AddOnCastleStore.Local.CastleStore:HasCastleStore(D5PCrHJF)==false then return end
AddOnCastleStore.Local.CastleStore:OnCityTabClicked(D5PCrHJF)end
function AddOnCastleStore.Local.CastleStore:HotkeyEmptyStore()
local g=GUI.GetPlayerID()if
AddOnCastleStore.Local.CastleStore:HasCastleStore(g)==false then return end
AddOnCastleStore.Local.CastleStore:OnMultiTabClicked(g)end
function AddOnCastleStore.Local.CastleStore:ActivateHotkeys()
Input.KeyBindDown(
Keys.ModifierShift+Keys.B,"AddOnCastleStore.Local.CastleStore:HotkeyStoreGoods()",2,false)
Input.KeyBindDown(Keys.ModifierShift+Keys.N,"AddOnCastleStore.Local.CastleStore:HotkeyLockGoods()",2,false)
Input.KeyBindDown(Keys.ModifierShift+Keys.M,"AddOnCastleStore.Local.CastleStore:HotkeyEmptyStore()",2,false)end
function AddOnCastleStore.Local.CastleStore:DescribeHotkeys()
if
not self.HotkeysAddToList then
API.AddHotKey("Umschalt + B",{de="Burglager: Waren einlagern",en="Vault: Store goods"})
API.AddHotKey("Umschalt + N",{de="Burglager: Waren sperren",en="Vault: Lock goods"})
API.AddHotKey("Umschalt + M",{de="Burglager: Lager räumen",en="Vault: Empty store"})self.HotkeysAddToList=true end end
function AddOnCastleStore.Local:OverwriteGetStringTableText()
GetStringTableText_Orig_QSB_CatsleStore=XGUIEng.GetStringTableText
XGUIEng.GetStringTableText=function(Xn)local w1_aa=
(Network.GetDesiredLanguage()=="de"and"de")or"en"
local Wjm1IcF=GUI.GetSelectedEntity()local BTUBq=GUI.GetPlayerID()
local FmfFN=XGUIEng.GetCurrentWidgetID()
if Xn=="UI_ObjectNames/DestroyGoods"then
if
Logic.GetHeadquarters(BTUBq)==Wjm1IcF then
if
XGUIEng.IsWidgetShown("/InGame/Root/Normal/AlignBottomRight/Selection/Castle")==1 then return
AddOnCastleStore.Local.Description.ShowCastleStore.Text[w1_aa]else return
AddOnCastleStore.Local.Description.ShowCastle.Text[w1_aa]end end end;if Xn=="UI_ObjectDescription/DestroyGoods"then return""end
if Xn==
"UI_ObjectNames/CityBuildingsNumber"then
if Logic.GetHeadquarters(BTUBq)==Wjm1IcF then return
AddOnCastleStore.Local.Description.CityTab.Title[w1_aa]end end
if Xn=="UI_ObjectDescription/CityBuildingsNumber"then
if Logic.GetHeadquarters(BTUBq)==
Wjm1IcF then return
AddOnCastleStore.Local.Description.CityTab.Text[w1_aa]end end
if Xn=="UI_ObjectNames/B_StoreHouse"then
if
Logic.GetHeadquarters(BTUBq)==Wjm1IcF then return
AddOnCastleStore.Local.Description.StorehouseTab.Title[w1_aa]end end
if Xn=="UI_ObjectDescription/B_StoreHouse"then
if
Logic.GetHeadquarters(BTUBq)==Wjm1IcF then return
AddOnCastleStore.Local.Description.StorehouseTab.Text[w1_aa]end end
if Xn=="UI_ObjectNames/B_Castle_ME"then
local dsLwA5Id="/InGame/Root/Normal/AlignBottomRight/Selection/Storehouse/TabButtons/"local ZQ=dsLwA5Id.."Tab03Down/down/B_Castle_ME"local JyucOKnq=dsLwA5Id..
"Tab03Up/up/B_Castle_ME"
if
XGUIEng.GetWidgetPathByID(FmfFN)==ZQ or
XGUIEng.GetWidgetPathByID(FmfFN)==JyucOKnq then
if
Logic.GetHeadquarters(BTUBq)==Wjm1IcF then return
AddOnCastleStore.Local.Description.MultiTab.Title[w1_aa]end end end
if Xn=="UI_ObjectDescription/B_Castle_ME"then
if
Logic.GetHeadquarters(BTUBq)==Wjm1IcF then return
AddOnCastleStore.Local.Description.MultiTab.Text[w1_aa]end end
if Xn=="UI_ButtonDisabled/NotEnoughGoods"then
if
Logic.GetHeadquarters(BTUBq)==Wjm1IcF then return
AddOnCastleStore.Local.Description.GoodButtonDisabled.Text[w1_aa]end end;return GetStringTableText_Orig_QSB_CatsleStore(Xn)end end
function AddOnCastleStore.Local:OverwriteGameFunctions()
GameCallback_GUI_SelectionChanged_Orig_QSB_CastleStore=GameCallback_GUI_SelectionChanged
GameCallback_GUI_SelectionChanged=function(KlDw8j)
GameCallback_GUI_SelectionChanged_Orig_QSB_CastleStore(KlDw8j)
QSB.CastleStore:SelectionChanged(GUI.GetPlayerID())end;GUI_Trade.GoodClicked_Orig_QSB_CastleStore=GUI_Trade.GoodClicked
GUI_Trade.GoodClicked=function()
local x9=Goods[XGUIEng.GetWidgetNameByID(XGUIEng.GetWidgetsMotherID(XGUIEng.GetCurrentWidgetID()))]local to4RLYy=GUI.GetSelectedEntity()local KlQ0Zf=GUI.GetPlayerID()if
Logic.IsEntityInCategory(to4RLYy,EntityCategories.Storehouse)==1 then
GUI_Trade.GoodClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:GoodClicked(KlQ0Zf,x9)end
GUI_Trade.DestroyGoodsClicked_Orig_QSB_CastleStore=GUI_Trade.DestroyGoodsClicked
GUI_Trade.DestroyGoodsClicked=function()local aCdtkPnJ=GUI.GetSelectedEntity()
local GP1Pwyo=GUI.GetPlayerID()if
Logic.IsEntityInCategory(aCdtkPnJ,EntityCategories.Storehouse)==1 then
GUI_Trade.DestroyGoodsClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:DestroyGoodsClicked(GP1Pwyo)end;GUI_Trade.SellUpdate_Orig_QSB_CastleStore=GUI_Trade.SellUpdate
GUI_Trade.SellUpdate=function()
local W=GUI.GetSelectedEntity()local mB=GUI.GetPlayerID()if
Logic.IsEntityInCategory(W,EntityCategories.Storehouse)==1 then
GUI_Trade.SellUpdate_Orig_QSB_CastleStore()return end
QSB.CastleStore:UpdateGoodsDisplay(mB)end
GUI_Trade.CityTabButtonClicked_Orig_QSB_CastleStore=GUI_Trade.CityTabButtonClicked
GUI_Trade.CityTabButtonClicked=function()local nh=GUI.GetSelectedEntity()
local BWty=GUI.GetPlayerID()if
Logic.IsEntityInCategory(nh,EntityCategories.Storehouse)==1 then
GUI_Trade.CityTabButtonClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:OnCityTabClicked(BWty)end
GUI_Trade.StorehouseTabButtonClicked_Orig_QSB_CastleStore=GUI_Trade.StorehouseTabButtonClicked
GUI_Trade.StorehouseTabButtonClicked=function()local hilL7W1I=GUI.GetSelectedEntity()
local sGUh=GUI.GetPlayerID()if
Logic.IsEntityInCategory(hilL7W1I,EntityCategories.Storehouse)==1 then
GUI_Trade.StorehouseTabButtonClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:OnStorehouseTabClicked(sGUh)end
GUI_Trade.MultiTabButtonClicked_Orig_QSB_CastleStore=GUI_Trade.MultiTabButtonClicked
GUI_Trade.MultiTabButtonClicked=function()local E=GUI.GetSelectedEntity()
local _zkO=GUI.GetPlayerID()if
Logic.IsEntityInCategory(E,EntityCategories.Storehouse)==1 then
GUI_Trade.MultiTabButtonClicked_Orig_QSB_CastleStore()return end
QSB.CastleStore:OnMultiTabClicked(_zkO)end
GUI_BuildingInfo.StorageLimitUpdate_Orig_QSB_CastleStore=GUI_BuildingInfo.StorageLimitUpdate
GUI_BuildingInfo.StorageLimitUpdate=function()local HYPg=GUI.GetSelectedEntity()
local XjFq=GUI.GetPlayerID()if
Logic.IsEntityInCategory(HYPg,EntityCategories.Storehouse)==1 then
GUI_BuildingInfo.StorageLimitUpdate_Orig_QSB_CastleStore()return end
QSB.CastleStore:UpdateStorageLimit(XjFq)end
GUI_Interaction.SendGoodsClicked=function()
local rqKhXE1,mga=GUI_Interaction.GetPotentialSubQuestAndType(g_Interaction.CurrentMessageQuestIndex)if not rqKhXE1 then return end
local Am5=GUI_Interaction.GetPotentialSubQuestIndex(g_Interaction.CurrentMessageQuestIndex)local NYUbv=rqKhXE1.Objectives[1].Data[1]
local yDPca=rqKhXE1.Objectives[1].Data[2]local oo1LM7={NYUbv,yDPca}
local rD8SiH6q,wlApj=AreCostsAffordable(oo1LM7,true)local S=GUI.GetPlayerID()
if Logic.GetGoodCategoryForGoodType(NYUbv)==
GoodCategories.GC_Resource then
wlApj=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_NotEnough_Resources")rD8SiH6q=false
if QSB.CastleStore:IsLocked(S,NYUbv)then rD8SiH6q=
GetPlayerResources(NYUbv,S)>=yDPca else
rD8SiH6q=(GetPlayerResources(NYUbv,S)+
QSB.CastleStore:GetAmount(S,NYUbv))>=yDPca end end
local hmO_cqJ=rqKhXE1.Objectives[1].Data[6]and
rqKhXE1.Objectives[1].Data[6]or rqKhXE1.SendingPlayer;local NVT=PlayerSectorTypes.Thief
local W2k7dh=CanEntityReachTarget(hmO_cqJ,Logic.GetStoreHouse(GUI.GetPlayerID()),Logic.GetStoreHouse(hmO_cqJ),
nil,NVT)
if W2k7dh==false then
local eWx=XGUIEng.GetStringTableText("Feedback_TextLines/TextLine_GenericUnreachable")Message(eWx)return end
if rD8SiH6q==true then Sound.FXPlay2DSound("ui\\menu_click")
GUI.QuestTemplate_SendGoods(Am5)
GUI_FeedbackSpeech.Add("SpeechOnly_CartsSent",g_FeedbackSpeech.Categories.CartsUnderway,nil,nil)else Message(wlApj)end end
GUI_Tooltip.SetCosts=function(uR,lcZngZ,xdZK4us)local KsHg6r1=XGUIEng.GetWidgetPathByID(uR)local tsEFuAW=KsHg6r1 ..
"/1Good"local cmkFZ46=KsHg6r1 .."/2Goods"local nPUk=0;local x_JPkl
local w8q
for IHXt8b=2,#lcZngZ,2 do if lcZngZ[IHXt8b]~=0 then nPUk=nPUk+1 end end
if nPUk==0 then XGUIEng.ShowWidget(tsEFuAW,0)
XGUIEng.ShowWidget(cmkFZ46,0)return elseif nPUk==1 then XGUIEng.ShowWidget(tsEFuAW,1)
XGUIEng.ShowWidget(cmkFZ46,0)x_JPkl=tsEFuAW.."/Good1Of1"elseif nPUk==2 then
XGUIEng.ShowWidget(tsEFuAW,0)XGUIEng.ShowWidget(cmkFZ46,1)
x_JPkl=cmkFZ46 .."/Good1Of2"w8q=cmkFZ46 .."/Good2Of2"elseif nPUk>2 then
GUI.AddNote("Debug: Invalid Costs table. Not more than 2 GoodTypes allowed.")end;local hz67=1
for Mrv1H=1,#lcZngZ,2 do
if lcZngZ[Mrv1H+1]~=0 then local gUq3T6L=lcZngZ[Mrv1H]
local cHedPE2=lcZngZ[Mrv1H+1]local m;local xg4jH9Dx
if hz67 ==1 then m=x_JPkl.."/Icon"xg4jH9Dx=x_JPkl.."/Amount"else m=w8q..
"/Icon"xg4jH9Dx=w8q.."/Amount"end
SetIcon(m,g_TexturePositions.Goods[gUq3T6L],44)local ake5QHa=GUI.GetPlayerID()
local WFUGTmK=GetPlayerGoodsInSettlement(gUq3T6L,ake5QHa,xdZK4us)
if
Logic.GetGoodCategoryForGoodType(gUq3T6L)==GoodCategories.GC_Resource and gUq3T6L~=Goods.G_Gold then
if not
QSB.CastleStore:IsLocked(ake5QHa,gUq3T6L)then WFUGTmK=WFUGTmK+
QSB.CastleStore:GetAmount(ake5QHa,gUq3T6L)end end;local VOBnY7Ft=""
if WFUGTmK<cHedPE2 then VOBnY7Ft="{@script:ColorRed}"end
if cHedPE2 >0 then
XGUIEng.SetText(xg4jH9Dx,"{center}"..VOBnY7Ft..cHedPE2)else XGUIEng.SetText(xg4jH9Dx,"")end;hz67=hz67+1 end end end end;Core:RegisterBundle("AddOnCastleStore")
AddOnGameCutscenes={}API=API or{}CS=CS or{}
function CS.StartCutscene(PEt6_)if not GUI then
API.Bridge("CS.StartCutscene('"..PEt6_.."')")return end
if not CS.IsCutsceneActive()then if
BriefingSystem then BriefingSystem.isActive=true end
AddOnGameCutscenes.Local.Data.Active=true
AddOnGameCutscenes.Local:StartCutscene(PEt6_)return true else if BriefingSystem then
if BriefingSystem.IsBriefingActive()then return false end else
AddOnGameCutscenes.Local:AddToWaitList(PEt6_)end end end
function CS.IsCutsceneActive()if not GUI then
assert(false,"CS.IsCutsceneActive : is local function.")return end;return
AddOnGameCutscenes.Local:IsCutsceneActive()end
function CS.CreateCutscene_DEV_ONLY()if GUI then
API.Bridge("CS.CreateCutscene_DEV_ONLY()")return end
AddOnGameCutscenes.Global:StartCutsceneMaker()end
function CS.CreateCutsceneRealtime_DEV_ONLY()if GUI then
API.Bridge("CS.CreateCutsceneRealtime_DEV_ONLY()")return end
AddOnGameCutscenes.Global.Data.csMaker.realtime=true
API.Bridge("AddOnGameCutscenes.Local.Data.csMakerRealtime = true")
AddOnGameCutscenes.Global:StartCutsceneMaker()end
AddOnGameCutscenes={Global={Data={csMaker={coord={},mouse={}}}},Local={Data={Language="de",Active=false,WaitList={},Positions={}}}}
function AddOnGameCutscenes.Global:Install()
self.Data.csMaker.coord={xLook=0,yLook=0,zLook=0,xCam=0,yCam=0,zCam=0,r=0,a=0,d=100,s=30,src=-90}
self.Data.csMaker.mouse={currentX=0,currentY=0,savedX=0,savedY=0,maxX=0,maxY=0}end
function AddOnGameCutscenes.Global:StartCutsceneMaker()
self.Data.csMaker.pages={}self.Data.csMaker.oldDuration=5
self:CurrentMousePosition()
self.Data.csMaker.mouse.savedX=self.Data.csMaker.mouse.currentX
self.Data.csMaker.mouse.savedY=self.Data.csMaker.mouse.currentY;self.Data.csMaker.duration={}
if
AddOnGameCutscenes.Global.Data.csMaker.realtime then self.Data.csMaker.lastTime=Logic.GetTime()end
self.Data.csMaker.job=StartSimpleHiResJob("AddOnGameCutscenes_Global_CutsceneMaker_MouseJob")
API.Bridge("AddOnGameCutscenes.Local:StartCutsceneMaker()")end;function AddOnGameCutscenes.Global:EndCutsceneMaker()
EndJob(self.Data.csMaker.job)end;function AddOnGameCutscenes.Global:CurrentMousePosition()
API.Bridge("AddOnGameCutscenes.Local:CurrentMousePosition()")end
function AddOnGameCutscenes_Global_CutsceneMaker_MouseJob()
AddOnGameCutscenes.Global:CurrentMousePosition()
local SX2s5fL=AddOnGameCutscenes.Global.Data.csMaker.mouse.savedX
local xOvpv=AddOnGameCutscenes.Global.Data.csMaker.mouse.savedY
local slpTPdg=AddOnGameCutscenes.Global.Data.csMaker.mouse.currentX
local mf9Za6rS=AddOnGameCutscenes.Global.Data.csMaker.mouse.currentY;local zt6fyh=(SX2s5fL-slpTPdg)/2
local g=(xOvpv-mf9Za6rS)/2;local yS1=false
if zt6fyh~=0 then
yS1=AddOnGameCutscenes.Global:AddDeltaRotation(zt6fyh)elseif SX2s5fL==0 then
yS1=AddOnGameCutscenes.Global:AddDeltaRotation(2)elseif SX2s5fL>
AddOnGameCutscenes.Global.Data.csMaker.mouse.maxX then
yS1=AddOnGameCutscenes.Global:AddDeltaRotation(-2)end
if g~=0 then
yS1=AddOnGameCutscenes.Global:AddDeltaAngle(g)elseif xOvpv==0 then
yS1=AddOnGameCutscenes.Global:AddDeltaAngle(2)elseif xOvpv>
AddOnGameCutscenes.Global.Data.csMaker.mouse.maxY then
yS1=AddOnGameCutscenes.Global:AddDeltaAngle(-2)end
if yS1 then AddOnGameCutscenes.Global:Refresh()end
AddOnGameCutscenes.Global.Data.csMaker.mouse.savedX=slpTPdg
AddOnGameCutscenes.Global.Data.csMaker.mouse.savedY=mf9Za6rS end
function AddOnGameCutscenes.Global:AddDeltaRotation(OP6jj1)
self.Data.csMaker.coord.r=(
self.Data.csMaker.coord.r+OP6jj1)%360;return true end
function AddOnGameCutscenes.Global:AddDeltaAngle(ucmxe1vA)
if
self.Data.csMaker.coord.a==89 and ucmxe1vA<0 then return false end;if
self.Data.csMaker.coord.a==-89 and ucmxe1vA>0 then return false end;self.Data.csMaker.coord.a=
self.Data.csMaker.coord.a-ucmxe1vA
if
self.Data.csMaker.coord.a>=90 then self.Data.csMaker.coord.a=89 end;if self.Data.csMaker.coord.a<=-90 then self.Data.csMaker.coord.a=
-89 end;return true end
function AddOnGameCutscenes.Global:SetNewCameraPosition(iVgH)local iVgH=iVgH or 0
local Xc2Bf=self.Data.csMaker.coord.xLook;local s8O=self.Data.csMaker.coord.yLook
local GgCgqvR=self.Data.csMaker.coord.zLook
local u=self.Data.csMaker.coord.r+
self.Data.csMaker.coord.src+iVgH;local X=self.Data.csMaker.coord.a
local AEUk=self.Data.csMaker.coord.s;local wBh_=AEUk*math.cos(math.rad(X))local ZonB96=Xc2Bf+
math.cos(math.rad(u))*wBh_;local F4tGS8=s8O+
math.sin(math.rad(u))*wBh_;local wjS4H=AEUk*
math.sin(math.rad(X))
self.Data.csMaker.coord.xLook=ZonB96;self.Data.csMaker.coord.yLook=F4tGS8
if iVgH==0 then self.Data.csMaker.coord.zLook=
GgCgqvR+wjS4H elseif iVgH==180 then self.Data.csMaker.coord.zLook=
GgCgqvR-wjS4H end end;function AddOnGameCutscenes.Global:PressedUp()
self:SetNewCameraPosition(180)self:Refresh()end;function AddOnGameCutscenes.Global:PressedDown()
self:SetNewCameraPosition(0)self:Refresh()end;function AddOnGameCutscenes.Global:PressedLeft()
self:SetNewCameraPosition(270)self:Refresh()end;function AddOnGameCutscenes.Global:PressedRight()
self:SetNewCameraPosition(90)self:Refresh()end
function AddOnGameCutscenes.Global:PressedSpace()
self.Data.csMaker.coord.zLook=
self.Data.csMaker.coord.zLook+self.Data.csMaker.coord.s;self:Refresh()end
function AddOnGameCutscenes.Global:PressedGoDown()
self.Data.csMaker.coord.zLook=
self.Data.csMaker.coord.zLook-self.Data.csMaker.coord.s;self:Refresh()end
function AddOnGameCutscenes.Global:Refresh()
local kLn_f=self.Data.csMaker.coord.xLook;local H=self.Data.csMaker.coord.yLook
local ryxc=self.Data.csMaker.coord.zLook;local f=self.Data.csMaker.coord.r+
self.Data.csMaker.coord.src
local Ll9m6D=self.Data.csMaker.coord.a;local tbmHO=self.Data.csMaker.coord.d;local U2MbX=tbmHO*
math.cos(math.rad(Ll9m6D))local I7uAp=kLn_f+
math.cos(math.rad(f))*U2MbX;local l=H+
math.sin(math.rad(f))*U2MbX;local QSRSkes=ryxc+
tbmHO*math.sin(math.rad(Ll9m6D))
self.Data.csMaker.coord.xCam=I7uAp;self.Data.csMaker.coord.yCam=l
self.Data.csMaker.coord.zCam=QSRSkes
API.Bridge('Camera.ThroneRoom_SetLookAt('..
kLn_f..', '..H..', '..ryxc..')')
API.Bridge('Camera.ThroneRoom_SetPosition('..
I7uAp..', '..l..', '..QSRSkes..')')end
function AddOnGameCutscenes.Global:PressedAdd()self.Data.csMaker.coord.s=
self.Data.csMaker.coord.s+10
if
self.Data.csMaker.coord.s>100 then self.Data.csMaker.coord.s=100 end end
function AddOnGameCutscenes.Global:PressedSubtract()self.Data.csMaker.coord.s=
self.Data.csMaker.coord.s-10
if
self.Data.csMaker.coord.s<10 then self.Data.csMaker.coord.s=10 end end
function AddOnGameCutscenes.Global:PressedAddDuration(oh)
table.insert(self.Data.csMaker.duration,oh)local wjm=self:GetDurationPassive()
Logic.DEBUG_AddNote("Zeit der folgenden Pages : "..wjm)end
function AddOnGameCutscenes.Global:PressedEmptyDuration()
self.Data.csMaker.duration={}local TzsAps=self:GetDurationPassive()
Logic.DEBUG_AddNote("Duration Speicher geleert.")
Logic.DEBUG_AddNote("Zeit der folgenden Pages : "..TzsAps)end
function AddOnGameCutscenes.Global:GetDurationPassive()
local yR4ul=#self.Data.csMaker.duration;local agWAM
if yR4ul==0 then agWAM=self.Data.csMaker.oldDuration elseif yR4ul==1 then
agWAM=self.Data.csMaker.duration[1]else agWAM=self.Data.csMaker.duration[1]*10+
self.Data.csMaker.duration[2]end;return agWAM end
function AddOnGameCutscenes.Global:GetDurationDestructive()
local fIgy=#self.Data.csMaker.duration;local jQOAPel
if fIgy==0 then jQOAPel=self.Data.csMaker.oldDuration elseif fIgy==1 then
jQOAPel=self.Data.csMaker.duration[1]else jQOAPel=self.Data.csMaker.duration[1]*10+
self.Data.csMaker.duration[2]end;self.Data.csMaker.oldDuration=jQOAPel
self.Data.csMaker.duration={}return jQOAPel end
function AddOnGameCutscenes.Global:PressedJump()
local IyO5sFWE=self.Data.csMaker.coord.xCam;local BRyisSL=self.Data.csMaker.coord.yCam
local WRf9=self.Data.csMaker.coord.zCam
local uriwOS=
(self.Data.csMaker.coord.xLook-
self.Data.csMaker.coord.xCam)*10+self.Data.csMaker.coord.xCam
local U=
(self.Data.csMaker.coord.yLook-
self.Data.csMaker.coord.yCam)*10+self.Data.csMaker.coord.yCam
local DGPfqh=
(self.Data.csMaker.coord.zLook-
self.Data.csMaker.coord.zCam)*10+self.Data.csMaker.coord.zCam;local Uu82uxP
if
AddOnGameCutscenes.Global.Data.csMaker.realtime then local o32YMjn=Logic.GetTime()
Uu82uxP=o32YMjn-self.Data.csMaker.lastTime;self.Data.csMaker.lastTime=o32YMjn else
Uu82uxP=self:GetDurationDestructive()end
local KJ4w5Gwa=""..
IyO5sFWE..","..
BRyisSL..","..WRf9 ..
","..uriwOS..","..U..
","..DGPfqh..","..Uu82uxP..",0&"self:SavePageToProfile(KJ4w5Gwa)
local f8SnN0p5={Position={X=IyO5sFWE,Y=BRyisSL,Z=WRf9},LookAt={X=uriwOS,Y=U,Z=DGPfqh},Duration=Uu82uxP}
table.insert(self.Data.csMaker.pages,f8SnN0p5)
Logic.DEBUG_AddNote("Neue JumpToPage gespeichert.")
Logic.DEBUG_AddNote("Zeit des folgenden Pages : "..Uu82uxP)end
function AddOnGameCutscenes.Global:PressedFly()
local A2F=self.Data.csMaker.coord.xCam;local wYe=self.Data.csMaker.coord.yCam
local qL=self.Data.csMaker.coord.zCam
local p2Yq=
(self.Data.csMaker.coord.xLook-
self.Data.csMaker.coord.xCam)*10+self.Data.csMaker.coord.xCam
local Ztdw=
(self.Data.csMaker.coord.yLook-
self.Data.csMaker.coord.yCam)*10+self.Data.csMaker.coord.yCam
local UlXPqbUd=
(self.Data.csMaker.coord.zLook-
self.Data.csMaker.coord.zCam)*10+self.Data.csMaker.coord.zCam;local cutV
if
AddOnGameCutscenes.Global.Data.csMaker.realtime then local VIds=Logic.GetTime()
cutV=VIds-self.Data.csMaker.lastTime;self.Data.csMaker.lastTime=VIds else
cutV=self:GetDurationDestructive()end
local vOlS6to=""..A2F..
","..wYe..","..
qL..","..p2Yq..","..
Ztdw..","..UlXPqbUd..","..cutV..",1&"self:SavePageToProfile(vOlS6to)
local EJQO={Position={X=A2F,Y=wYe,Z=qL},LookAt={X=p2Yq,Y=Ztdw,Z=UlXPqbUd},Duration=cutV,FlyTime=cutV}
table.insert(self.Data.csMaker.pages,EJQO)
Logic.DEBUG_AddNote("Neue FlyToPage gespeichert.")
Logic.DEBUG_AddNote("Zeit des folgenden Pages : "..cutV)end;function AddOnGameCutscenes.Global:SavePageToProfile(yOF0)
API.Bridge("AddOnGameCutscenes.Local:SavePageToProfile('"..yOF0 ..
"')")end
function AddOnGameCutscenes.Global:PressedPreview()
self:EndCutsceneMaker()
API.Bridge("AddOnGameCutscenes.Local:EndCutsceneMaker()")
local RwbFLFt={barStyle="small",restoreCamera=true,skipAll=true,hideFoW=true,showSky=true,hideBorderPins=true}local Xopqtai=AddPages(RwbFLFt)for SE,Gq8aVS in
ipairs(self.Data.csMaker.pages)do
Xopqtai{text="Page "..SE,title="Title",view=Gq8aVS,action=function()end}end
RwbFLFt.finished=function()end;return StartCutscene(RwbFLFt)end
function AddOnGameCutscenes.Local:Install()
self.Data.Language=(
Network.GetDesiredLanguage()=="de"and"de")or"en"local Z,QAOj=GUI.GetScreenSize()
local zz1bLly,JI=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text")self.Data.Positions.Text={X=zz1bLly,Y=JI}
local Z,HKD5l=XGUIEng.GetWidgetSize("/InGame/ThroneRoomBars_2/BarBottom")
self.Data.Positions.TextSmall={X=zz1bLly,Y=QAOj-HKD5l+30}
local zz1bLly,JI=XGUIEng.GetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight")self.Data.Positions.Title={X=zz1bLly,Y=JI}
local Z,HKD5l=XGUIEng.GetWidgetSize("/InGame/ThroneRoomBars_2/BarTop")
self.Data.Positions.TitleSmall={X=zz1bLly,Y=HKD5l/2-30}self.Data.GameCallback_Escape=GameCallback_Escape
GameCallback_Escape=function()
if not
self.Data.Active then self.Data.GameCallback_Escape()end end end
function AddOnGameCutscenes.Local:IsCutsceneActive()
if BriefingSystem then if
BriefingSystem.IsBriefingActive()then return true end end;return self.Data.Active end;function AddOnGameCutscenes.Local:AddToWaitList(zo)
table.insert(self.Data.WaitList,zo)end
function AddOnGameCutscenes.Local:CheckWaitList()self.Data.Name=
nil
if#self.Data.WaitList>0 then
AddOnGameCutscenes.Local:StartCutscene(table.remove(self.Data.WaitList))else self.Data.Active=false
AddOnGameCutscenes.Local:UndoCutsceneOptic()if BriefingSystem then BriefingSystem.isActive=false end end end
function AddOnGameCutscenes.Local:StartCutscene(u)
AddOnGameCutscenes.Local:StartCutsceneOptic()Camera.StartCutscene(u)end
function AddOnGameCutscenes.Local:StartCutsceneOptic()
Display.SetRenderBorderPins(0)Display.SetRenderSky(1)
Display.SetUserOptionOcclusionEffect(0)Display.SetRenderFogOfWar(0)
XGUIEng.ShowWidget("/InGame/Root/Normal",0)
local b=XGUIEng.IsWidgetShownEx("/LoadScreen/LoadScreen")==1;if b then XGUIEng.PopPage()end
XGUIEng.ShowWidget("/InGame/Root/3dOnScreenDisplay",0)XGUIEng.ShowWidget("/InGame/ThroneRoom",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Skip",0)XGUIEng.PushPage("/InGame/ThroneRoomBars",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_2",false)
XGUIEng.PushPage("/InGame/ThroneRoom/Main",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_Dodge",false)
XGUIEng.PushPage("/InGame/ThroneRoomBars_2_Dodge",false)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/Frame",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/DialogBG",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/FrameEdges",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogBottomRight3pcs",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/KnightInfoButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/Briefing",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/BackButton",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/TitleContainer",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/StartButton",0)
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Text"," ")
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Title"," ")
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Objectives"," ")local m59A={GUI.GetScreenSize()}
local DMT4O=350* (m59A[2]/1080)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo",1)
XGUIEng.ShowAllSubWidgets("/InGame/ThroneRoom/KnightInfo",0)
XGUIEng.ShowWidget("/InGame/ThroneRoom/KnightInfo/Text",1)
XGUIEng.PushPage("/InGame/ThroneRoom/KnightInfo",false)
XGUIEng.SetText("/InGame/ThroneRoom/KnightInfo/Text","")
XGUIEng.SetTextColor("/InGame/ThroneRoom/KnightInfo/Text",255,255,255,255)
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/KnightInfo/Text",100,DMT4O)self.Data.timeFactor=Game.GameTimeGetFactor()
Game.GameTimeSetFactor(GUI.GetPlayerID(),1)
self.Data.cameraRestore={Camera.RTS_GetLookAtPosition()}
self.Data.selectedEntities={GUI.GetSelectedEntities()}GUI.ClearSelection()
GUI.ForbidContextSensitiveCommandsInSelectionState()GUI.ActivateCutSceneState()
GUI.SetFeedbackSoundOutputState(0)GUI.EnableBattleSignals(false)Mouse.CursorHide()
Input.CutsceneMode()
if b then XGUIEng.PushPage("/LoadScreen/LoadScreen",false)end;AddOnGameCutscenes.Local:ShowText()end
function AddOnGameCutscenes.Local:UndoCutsceneOptic()
Display.SetRenderBorderPins(1)Display.SetRenderSky(0)if
Options.GetIntValue("Display","Occlusion",0)>0 then
Display.SetUserOptionOcclusionEffect(1)end
Display.SetRenderFogOfWar(1)XGUIEng.PopPage()Display.UseStandardSettings()
Input.GameMode()Mouse.CursorShow()GUI.EnableBattleSignals(true)
GUI.SetFeedbackSoundOutputState(1)GUI.ActivateSelectionState()
GUI.PermitContextSensitiveCommandsInSelectionState()XGUIEng.ShowWidget("/InGame/Root/Normal",1)
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",self.Data.Positions.Title.X,self.Data.Positions.Title.Y)
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text",self.Data.Positions.Text.X,self.Data.Positions.Text.Y)
for UE,UoW82bB in ipairs(self.Data.selectedEntities)do if
not Logic.IsEntityDestroyed(UoW82bB)then GUI.SelectEntity(UoW82bB)end end
Camera.RTS_SetLookAtPosition(unpack(self.Data.cameraRestore))
Game.GameTimeSetFactor(GUI.GetPlayerID(),self.Data.timeFactor)XGUIEng.PopPage()XGUIEng.PopPage()
XGUIEng.PopPage()XGUIEng.PopPage()XGUIEng.PopPage()
XGUIEng.ShowWidget("/InGame/ThroneRoom",0)XGUIEng.ShowWidget("/InGame/ThroneRoomBars",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",0)
XGUIEng.ShowWidget("/InGame/Root/3dOnScreenDisplay",1)end
function AddOnGameCutscenes.Local:ShowText(eFBIbW,Gp,OAu7m,JP2,KmW,lnZ82WEv)local Dcon=eFBIbW or""local dq=Gp or""local gqr2=OAu7m or
false;local KvaO1=JP2 or false;local GzU7Q46j=KmW or false
local RiH=lnZ82WEv or false;local pQ_9E4RU=not RiH and 100 or 255
XGUIEng.ShowWidget("/InGame/ThroneRoomBars",(KvaO1 and
GzU7Q46j)and 1 or 0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_Dodge",(KvaO1 and GzU7Q46j)and 1 or 0)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars/BarBottom",1,pQ_9E4RU)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars/BarTop",1,pQ_9E4RU)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2",
(KvaO1 and not GzU7Q46j)and 1 or 0)
XGUIEng.ShowWidget("/InGame/ThroneRoomBars_2_Dodge",
(KvaO1 and not GzU7Q46j)and 1 or 0)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars_2/BarBottom",1,pQ_9E4RU)
XGUIEng.SetMaterialAlpha("/InGame/ThroneRoomBars_2/BarTop",1,pQ_9E4RU)
if gqr2 then local tA=0;local HNCorxp=string.len(Dcon)tA=tA+
math.ceil((HNCorxp/80))local DNvc0pEH=0
local iyzQ,czxkyuPQ=string.find(Dcon,"{cr}")while(czxkyuPQ)do DNvc0pEH=DNvc0pEH+1
iyzQ,czxkyuPQ=string.find(Dcon,"{cr}",czxkyuPQ+1)end;tA=tA+
math.floor((DNvc0pEH/2))local D={GUI.GetScreenSize()}tA=(
D[2]/2)- (tA*10)
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",self.Data.Positions.Title.X,
0+tA)
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text",self.Data.Positions.Text.X,
38+tA)else local rhKWD=self.Data.Positions.Title.X
local MiZANs=self.Data.Positions.Text.X
if GzU7Q46j then local k=self.Data.Positions.Title.Y
local AfSkY8=self.Data.Positions.Text.Y
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",rhKWD,k)
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text",MiZANs,AfSkY8)else local Kb1Xt=self.Data.Positions.TitleSmall.Y
local cXh9iV=self.Data.Positions.TextSmall.Y
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",rhKWD,Kb1Xt)
XGUIEng.SetWidgetScreenPosition("/InGame/ThroneRoom/Main/MissionBriefing/Text",MiZANs,cXh9iV)end end
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/MissionBriefing/Text",1)
XGUIEng.ShowWidget("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight",1)
XGUIEng.SetText("/InGame/ThroneRoom/Main/MissionBriefing/Text","{center}"..Dcon)
XGUIEng.SetText("/InGame/ThroneRoom/Main/DialogTopChooseKnight/ChooseYourKnight","{center}{darkshadow}{@color:244,184,0,255}"..dq)end
function AddOnGameCutscenes.Local:StartCutsceneMaker()
Profile.SetString("CutsceneAssistent","pages","")local v,o3GlLg8h=Camera.RTS_GetLookAtPosition()local SFKPRDo=
Display.GetTerrainHeight(v,o3GlLg8h)+1000
API.Bridge(
"AddOnGameCutscenes.Global.Data.csMaker.coord.xLook = "..v)
API.Bridge("AddOnGameCutscenes.Global.Data.csMaker.coord.yLook = "..o3GlLg8h)
API.Bridge("AddOnGameCutscenes.Global.Data.csMaker.coord.zLook = "..SFKPRDo)Display.SetUserOptionOcclusionEffect(0)
Display.SetRenderSky(1)Game.GameTimeSetFactor(GUI.GetPlayerID(),1)
Camera.SwitchCameraBehaviour(5)Display.SetRenderFogOfWar(0)
GUI.MiniMap_SetRenderFogOfWar(0)GUI.ActivateCutSceneState()
local C0iKEQE,kS=GUI.GetScreenSize()
API.Bridge("AddOnGameCutscenes.Global.Data.csMaker.mouse.maxX = "..C0iKEQE.." - 5")
API.Bridge("AddOnGameCutscenes.Global.Data.csMaker.mouse.maxY = "..kS.." - 5")
Input.KeyBindDown(Keys.Up,'API.Bridge("AddOnGameCutscenes.Global:PressedUp()")',2,true)
Input.KeyBindDown(Keys.Down,'API.Bridge("AddOnGameCutscenes.Global:PressedDown()")',2,true)
Input.KeyBindDown(Keys.Left,'API.Bridge("AddOnGameCutscenes.Global:PressedLeft()")',2,true)
Input.KeyBindDown(Keys.Right,'API.Bridge("AddOnGameCutscenes.Global:PressedRight()")',2,true)
Input.KeyBindDown(Keys.W,'API.Bridge("AddOnGameCutscenes.Global:PressedUp()")',2,true)
Input.KeyBindDown(Keys.S,'API.Bridge("AddOnGameCutscenes.Global:PressedDown()")',2,true)
Input.KeyBindDown(Keys.A,'API.Bridge("AddOnGameCutscenes.Global:PressedLeft()")',2,true)
Input.KeyBindDown(Keys.D,'API.Bridge("AddOnGameCutscenes.Global:PressedRight()")',2,true)
Input.KeyBindDown(Keys.Add,'API.Bridge("AddOnGameCutscenes.Global:PressedAdd()")',2,true)
Input.KeyBindDown(Keys.Subtract,'API.Bridge("AddOnGameCutscenes.Global:PressedSubtract()")',2,true)
Input.KeyBindDown(Keys.Space,'API.Bridge("AddOnGameCutscenes.Global:PressedSpace()")',2,true)
Input.KeyBindDown(Keys.Y,'API.Bridge("AddOnGameCutscenes.Global:PressedGoDown()")',2,true)
Input.KeyBindDown(Keys.J,'API.Bridge("AddOnGameCutscenes.Global:PressedJump()")',2,true)
Input.KeyBindDown(Keys.F,'API.Bridge("AddOnGameCutscenes.Global:PressedFly()")',2,true)
Input.KeyBindDown(Keys.P,'API.Bridge("AddOnGameCutscenes.Global:PressedPreview()")',2,true)
if
not AddOnGameCutscenes.Local.Data.csMakerRealtime then
Input.KeyBindDown(Keys.Back,'API.Bridge("AddOnGameCutscenes.Global:PressedEmptyDuration()")',2,true)
Input.KeyBindDown(Keys.NumPad0,'API.Bridge("AddOnGameCutscenes.Global:PressedAddDuration(0)")',2,true)
Input.KeyBindDown(Keys.NumPad1,'API.Bridge("AddOnGameCutscenes.Global:PressedAddDuration(1)")',2,true)
Input.KeyBindDown(Keys.NumPad2,'API.Bridge("AddOnGameCutscenes.Global:PressedAddDuration(2)")',2,true)
Input.KeyBindDown(Keys.NumPad3,'API.Bridge("AddOnGameCutscenes.Global:PressedAddDuration(3)")',2,true)
Input.KeyBindDown(Keys.NumPad4,'API.Bridge("AddOnGameCutscenes.Global:PressedAddDuration(4)")',2,true)
Input.KeyBindDown(Keys.NumPad5,'API.Bridge("AddOnGameCutscenes.Global:PressedAddDuration(5)")',2,true)
Input.KeyBindDown(Keys.NumPad6,'API.Bridge("AddOnGameCutscenes.Global:PressedAddDuration(6)")',2,true)
Input.KeyBindDown(Keys.NumPad7,'API.Bridge("AddOnGameCutscenes.Global:PressedAddDuration(7)")',2,true)
Input.KeyBindDown(Keys.NumPad8,'API.Bridge("AddOnGameCutscenes.Global:PressedAddDuration(8)")',2,true)
Input.KeyBindDown(Keys.NumPad9,'API.Bridge("AddOnGameCutscenes.Global:PressedAddDuration(9)")',2,true)end
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/MapFrame/Minimap/MinimapOverlay",0)end
function AddOnGameCutscenes.Local:EndCutsceneMaker()
Display.SetRenderSky(0)Game.GameTimeSetFactor(GUI.GetPlayerID(),1)
Camera.SwitchCameraBehaviour(0)Display.SetRenderFogOfWar(1)
GUI.MiniMap_SetRenderFogOfWar(1)XGUIEng.ShowWidget("/InGame/Root/Normal",1)
Input.KeyBindDown(Keys.Up,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.Down,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.Left,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.Right,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.W,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.S,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.A,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.D,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.Add,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.Subtract,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.Space,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.Y,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.J,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.F,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.P,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.Back,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.NumPad0,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.NumPad1,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.NumPad2,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.NumPad3,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.NumPad4,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.NumPad5,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.NumPad6,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.NumPad7,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.NumPad8,'KeyBindings_EnableDebugMode(0)',2)
Input.KeyBindDown(Keys.NumPad9,'KeyBindings_EnableDebugMode(0)',2)
XGUIEng.ShowWidget("/InGame/Root/Normal/AlignBottomRight/MapFrame/Minimap/MinimapOverlay",1)end
function AddOnGameCutscenes.Local:CurrentMousePosition()
local T9KC,em=GUI.GetMousePosition()
API.Bridge("AddOnGameCutscenes.Global.Data.csMaker.mouse.currentX = "..T9KC)
API.Bridge("AddOnGameCutscenes.Global.Data.csMaker.mouse.currentY = "..em)end
function AddOnGameCutscenes.Local:SavePageToProfile(UmHV)
local emcVMzvE=Profile.GetString("CutsceneAssistent","pages")
Profile.SetString("CutsceneAssistent","pages",""..emcVMzvE..""..UmHV.."")end;Core:RegisterBundle("AddOnGameCutscenes")
AddOnInteractiveObjectTemplates={}API=API or{}QSB=QSB or{}
function API.CreateIOMine(O,jzY,KLH,J,qJiI9H,SZa_yQ,gewubTg1)if GUI then
API.Dbg("API.CreateIOMine: Can not be used from local script!")return end
AddOnInteractiveObjectTemplates.Global:CreateIOMine(O,jzY,KLH,J,qJiI9H,SZa_yQ,gewubTg1)end;CreateIOMine=API.CreateIOMine
function API.CreateIOIronMine(KP_1J,YFY7S,fKr,YMZowD,Hoo,BIGpsChp)if GUI then
API.Dbg("API.CreateIOIronMine: Can not be used from local script!")return end
AddOnInteractiveObjectTemplates.Global:CreateIOIronMine(KP_1J,YFY7S,fKr,YMZowD,Hoo,BIGpsChp)end;CreateIOIronMine=API.CreateIOIronMine
function API.CreateIOStoneMine(MdMw2,f3XSj8,ii,gchclh,E6,FzQZJAb)if GUI then
API.Dbg("API.CreateIOStoneMine: Can not be used from local script!")return end
AddOnInteractiveObjectTemplates.Global:CreateIOStoneMine(MdMw2,f3XSj8,ii,gchclh,E6,FzQZJAb)end;CreateIOStoneMine=API.CreateIOStoneMine
function API.CreateIOBuildingSite(kGeoIQb,Tx5oiHV,x99,lKOR5,bry,M44,H,mWCLX,wRKN)if GUI then
API.Dbg("API.CreateIOBuildingSite: Can not be used from local script!")return end
AddOnInteractiveObjectTemplates.Global:CreateIOBuildingSite(kGeoIQb,Tx5oiHV,x99,lKOR5,bry,M44,H,mWCLX,wRKN)end;CreateIOBuildingSite=API.CreateIOBuildingSite
function API.CreateRandomChest(CPcdA6,K3ZE,Nhgn_S,VOEt,p8lmyyH4)if GUI then
API.Dbg("API.CreateRandomChest: Can not be used from local script!")return end
AddOnInteractiveObjectTemplates.Global:CreateRandomChest(CPcdA6,K3ZE,Nhgn_S,VOEt,p8lmyyH4)end;CreateRandomChest=API.CreateRandomChest
function API.CreateRandomGoldChest(K9P)if GUI then
API.Dbg("API.CreateRandomGoldChest('"..
K9P.."')")return end
AddOnInteractiveObjectTemplates.Global:CreateRandomChest(K9P,Goods.G_Gold,300,600)end;CreateRandomGoldChest=API.CreateRandomGoldChest
function API.CreateRandomResourceChest(a)if GUI then
API.Bridge(
"API.CreateRandomResourceChest('"..a.."')")return end
AddOnInteractiveObjectTemplates.Global:CreateRandomResourceChest(a)end;CreateRandomResourceChest=API.CreateRandomResourceChest
function API.CreateRandomLuxuryChest(P2_1)if GUI then
API.Bridge(
"API.CreateRandomLuxuryChest('"..P2_1 .."')")return end
AddOnInteractiveObjectTemplates.Global:CreateRandomLuxuryChest(P2_1)end;CreateRandomLuxuryChest=API.CreateRandomLuxuryChest
function API.CreateTrebuchetConstructionSite(A,hvEMs,kPiyF)if GUI then
API.Bridge(
"API.CreateTrebuchetConstructionSite('"..A.."', "..hvEMs..", "..kPiyF..")")return end
AddOnInteractiveObjectTemplates.Global:CreateTrebuchetConstructionSite(A,hvEMs,kPiyF)end;CreateTrebuchetConstructionSite=API.CreateTrebuchetConstructionSite
function API.DestroyTrebuchetConstructionSite(y6I)if
GUI then
API.Bridge("API.DestroyTrebuchetConstructionSite('"..y6I.."')")return end
AddOnInteractiveObjectTemplates.Global:DestroyTrebuchetConstructionSite(y6I)end;DestroyTrebuchetConstructionSite=API.DestroyTrebuchetConstructionSite
function API.GetTrebuchetByTrebuchetConstructionSite(l7fEx)if
GUI then
API.Dbg("API.GetTrebuchetByTrebuchetConstructionSite: Can only be used in global script!")return end
if not
self.Data.Trebuchet.Sites[l7fEx]then
API.Warn("API.GetTrebuchetByTrebuchetConstructionSite: Site '"..
tostring(l7fEx).."' does not exist!")return 0 end
return self.Data.Trebuchet.Sites[l7fEx].ConstructedTrebuchet end;GetTrebuchet=API.GetTrebuchetByTrebuchetConstructionSite
function API.GetReturningCartByTrebuchetConstructionSite(CwX7YlBc)if
GUI then
API.Dbg("API.GetReturningCartByTrebuchetConstructionSite: Can only be used in global script!")return end
if not
self.Data.Trebuchet.Sites[CwX7YlBc]then
API.Warn("API.GetReturningCartByTrebuchetConstructionSite: Site '"..tostring(CwX7YlBc)..
"' does not exist!")return 0 end
return self.Data.Trebuchet.Sites[CwX7YlBc].ReturningCart end;GetReturningCart=API.GetReturningCartByTrebuchetConstructionSite
function API.GetConstructionCartByTrebuchetConstructionSite(Tv24kDx)if
GUI then
API.Dbg("API.GetConstructionCartByTrebuchetConstructionSite: Can only be used in global script!")return end
if not
self.Data.Trebuchet.Sites[Tv24kDx]then
API.Warn("API.GetConstructionCartByTrebuchetConstructionSite: Site '"..tostring(Tv24kDx)..
"' does not exist!")return 0 end
return self.Data.Trebuchet.Sites[Tv24kDx].ConstructionCart end;GetConstructionCart=API.GetConstructionCartByTrebuchetConstructionSite
AddOnInteractiveObjectTemplates={Global={Data={ConstructionSite={Sites={},Description={Title={de="Gebäude bauen",en="Create building"},Text={de=
"Beauftragt den Bau eines Gebäudes. Ein Siedler wird aus".." dem Lagerhaus kommen und mit dem Bau beginnen.",en=
"Order a building. A worker will come out of the".." storehouse and erect it."},Unfulfilled={de="Das Gebäude kann derzeit nicht gebaut werden.",en="The building can not be built at the moment."}}},Mines={Description={Title={de="Mine errichten",en="Build pit"},Text={de="An diesem Ort könnt Ihr eine Mine errichten!",en="You're able to create a pit at this location!"},Unfulfilled={de="Die Mine kann nicht umgewandelt werden!",en="The mine can not be transformed!"}}},Chests={Description={Title={de="Schatztruhe",en="Treasure Chest"},Text={de="Diese Truhe enthält einen geheimen Schatz. Öffnet sie um den Schatz zu bergen.",en="This chest contains a secred treasure. Open it to salvage the treasure."}}},Trebuchet={Error={de="Euer Ritter benötigt einen höheren Titel!",en="Your knight need a higher title to use this site!"},Description={Title={de="Trebuchet anfordern",en="Order trebuchet"},Text={de="- Fordert ein Trebuchet aus der Stadt an {cr}- Trebuchet wird gebaut, wenn Wagen Baustelle erreicht {cr}- Fährt zurück, wenn Munition aufgebraucht {cr}- Trebuchet kann manuell zurückgeschickt werden",en="- Order a trebuchet from your city {cr}- The trebuchet is build after the cart has arrived {cr}- Returns after ammunition is depleted {cr}- The trebuchet can be manually send back to the city"}},Sites={},NeededKnightTitle=0,IsActive=false}}},Local={Data={}}}
function AddOnInteractiveObjectTemplates.Global:Install()end
function AddOnInteractiveObjectTemplates.Global:TrebuchetActivate()
if not
self.Data.Trebuchet.IsActive then
GameCallback_QSB_OnDisambleTrebuchet=AddOnInteractiveObjectTemplates.Global.OnTrebuchetDisambled;GameCallback_QSB_OnErectTrebuchet=function()end
StartSimpleJobEx(self.WatchTrebuchetsAndCarts)API.DisableRefillTrebuchet(true)
self.Data.Trebuchet.IsActive=true end end
function AddOnInteractiveObjectTemplates.Global.TrebuchetHasSufficentTitle()local SWk=1
for RCCk=1,8 do if
Logic.PlayerGetIsHumanFlag(RCCk)==1 then SWk=RCCk;break end end
return Logic.GetKnightTitle(SWk)>=
AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.NeededKnightTitle end;function AddOnInteractiveObjectTemplates.Global:TrebuchetSetNeededKnightTitle(OdpPJ0)
self.Data.Trebuchet.NeededKnightTitle=OdpPJ0 end
function AddOnInteractiveObjectTemplates.Global:CreateTrebuchetConstructionSite(O8zt,c8yNrz,j)
self:TrebuchetActivate()c8yNrz=c8yNrz or 4500;j=j or 35;local HN9esqY=GetID(O8zt)
Logic.SetModel(HN9esqY,Models.Buildings_B_BuildingPlot_8x8)Logic.SetVisible(HN9esqY,true)
self.Data.Trebuchet.Sites[O8zt]={ConstructedTrebuchet=0,ConstructionCart=0,ReturningCart=0}
CreateObject{Name=O8zt,Title=self.Data.Trebuchet.Description.Title,Text=self.Data.Trebuchet.Description.Text,Costs={Goods.G_Gold,c8yNrz,Goods.G_Wood,j},Distance=1000,State=0,Condition=self.TrebuchetHasSufficentTitle,ConditionUnfulfilled=self.Data.Trebuchet.Error,Callback=function(L,nlJmo89w)
AddOnInteractiveObjectTemplates.Global:SpawnTrebuchetCart(nlJmo89w,L.Name)end}end
function AddOnInteractiveObjectTemplates.Global:DestroyTrebuchetConstructionSite(Lo6wKOjR)
local q=self.Data.Trebuchet.Sites[Lo6wKOjR].ConstructionCart;DestroyEntity(q)
local gqn_=self.Data.Trebuchet.Sites[Lo6wKOjR].ConstructedTrebuchet;DestroyEntity(gqn_)
local QgUGF_s0=self.Data.Trebuchet.Sites[Lo6wKOjR].ReturningCart;DestroyEntity(QgUGF_s0)self.Data.Trebuchet.Sites[Lo6wKOjR]=
nil
Logic.SetVisible(GetID(Lo6wKOjR),false)RemoveInteractiveObject(Lo6wKOjR)end
function AddOnInteractiveObjectTemplates.Global:SpawnTrebuchetCart(EYtN8K6k,FP)
local BI=Logic.GetStoreHouse(EYtN8K6k)local QtUt,D=Logic.GetBuildingApproachPosition(BI)
local kZ=Logic.CreateEntity(Entities.U_SiegeEngineCart,QtUt,D,0,EYtN8K6k)Logic.SetEntitySelectableFlag(kZ,0)
self.Data.Trebuchet.Sites[FP].ConstructionCart=kZ end
function AddOnInteractiveObjectTemplates.Global:SpawnTrebuchet(F9Wff1N,fwGYy6Ss)
local _2=GetPosition(fwGYy6Ss)
local Z=Logic.CreateEntity(Entities.U_Trebuchet,_2.X,_2.Y,0,F9Wff1N)
self.Data.Trebuchet.Sites[fwGYy6Ss].ConstructedTrebuchet=Z end
function AddOnInteractiveObjectTemplates.Global:ReturnTrebuchetToStorehouse(Hmn,NMiXW)
local Vd6,A7,y4=Logic.EntityGetPos(NMiXW)
local DQV=Logic.CreateEntity(Entities.U_SiegeEngineCart,Vd6,A7,0,Hmn)Logic.SetEntitySelectableFlag(DQV,0)local zx3O
for H6zSmv,fV in
pairs(self.Data.Trebuchet.Sites)do if fV.ConstructedTrebuchet==NMiXW then zx3O=H6zSmv end end
if zx3O then
self.Data.Trebuchet.Sites[zx3O].ReturningCart=DQV
self.Data.Trebuchet.Sites[zx3O].ConstructedTrebuchet=0;Logic.SetVisible(GetID(zx3O),true)
DestroyEntity(NMiXW)else DestroyEntity(DQV)end end
function AddOnInteractiveObjectTemplates.Global.OnTrebuchetDisambled(HSE58,JmyZwZ,n6i83CC,lsj1XL,xC)
AddOnInteractiveObjectTemplates.Global:ReturnTrebuchetToStorehouse(JmyZwZ,HSE58)end
function AddOnInteractiveObjectTemplates.Global.WatchTrebuchetsAndCarts()
for xHp,Wx in
pairs(AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.Sites)do local pvy2bt6=GetID(xHp)
if Wx.ConstructionCart~=0 then
if
not IsExisting(Wx.ConstructionCart)then
AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.Sites[xHp].ConstructionCart=0;API.InteractiveObjectActivate(xHp)end
if not Logic.IsEntityMoving(Wx.ConstructionCart)then
local pvy2bt6=GetID(xHp)local pYZiw,fOHqT8E3,tM=Logic.EntityGetPos(pvy2bt6)
Logic.MoveSettler(Wx.ConstructionCart,pYZiw,fOHqT8E3)end
if IsNear(Wx.ConstructionCart,xHp,500)then
local Bk,XFd1u,pk=Logic.EntityGetPos(pvy2bt6)local oBFrzP0=Logic.EntityGetPlayer(Wx.ConstructionCart)
AddOnInteractiveObjectTemplates.Global:SpawnTrebuchet(oBFrzP0,xHp)DestroyEntity(Wx.ConstructionCart)
AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.Sites[xHp].ConstructionCart=0;Logic.SetVisible(pvy2bt6,false)
Logic.CreateEffect(EGL_Effects.E_Shockwave01,Bk,XFd1u,0)end end
if Wx.ConstructedTrebuchet~=0 then
if
not IsExisting(Wx.ConstructedTrebuchet)then
AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.Sites[xHp].ConstructedTrebuchet=0;Logic.SetVisible(pvy2bt6,true)
API.InteractiveObjectActivate(xHp)end
if
Logic.GetAmmunitionAmount(Wx.ConstructedTrebuchet)==0 and
BundleEntitySelection.Local.Data.RefillTrebuchet==false then
local w1=Logic.EntityGetPlayer(Wx.ConstructedTrebuchet)
AddOnInteractiveObjectTemplates.Global:ReturnTrebuchetToStorehouse(w1,Wx.ConstructedTrebuchet)end end
if Wx.ReturningCart~=0 then
if not IsExisting(Wx.ReturningCart)then
AddOnInteractiveObjectTemplates.Global.Data.Trebuchet.Sites[xHp].ReturningCart=0;API.InteractiveObjectActivate(xHp)end;local c=Logic.EntityGetPlayer(Wx.ReturningCart)
local e8MCZWvA=Logic.GetStoreHouse(c)
if not Logic.IsEntityMoving(Wx.ReturningCart)then
local Z,PPl7k0K=Logic.GetBuildingApproachPosition(e8MCZWvA)Logic.MoveSettler(Wx.ReturningCart,Z,PPl7k0K)end
if IsNear(Wx.ReturningCart,e8MCZWvA,1100)then
local c=Logic.EntityGetPlayer(Wx.ConstructionCart)DestroyEntity(Wx.ReturningCart)end end end end
function AddOnInteractiveObjectTemplates.Global:CreateRandomChest(xVhkm,P,h,FiAu7W,_)h=(
h~=nil and h>0 and h)or 1
FiAu7W=(
FiAu7W~=nil and FiAu7W>1 and FiAu7W)or 2;if not _ then _=function(ZrFDK)end end
assert(P~=nil,"CreateRandomChest: Good does not exist!")
assert(h<FiAu7W,"CreateRandomChest: min amount must be smaller than max amount!")
local DdjSHqYL=ReplaceEntity(xVhkm,Entities.XD_ScriptEntity,0)
Logic.SetModel(DdjSHqYL,Models.Doodads_D_X_ChestClose)Logic.SetVisible(DdjSHqYL,true)
CreateObject{Name=xVhkm,Title=self.Data.Chests.Description.Title,Text=self.Data.Chests.Description.Text,Reward={P,math.random(h,FiAu7W)},Texture={1,6},Distance=650,State=0,CallbackOpened=_,Callback=function(Ha)
ReplaceEntity(Ha.Name,Entities.D_X_ChestOpenEmpty)Ha.CallbackOpened(Ha)end}end
function AddOnInteractiveObjectTemplates.Global:CreateRandomGoldChest(_jku5G)
AddOnInteractiveObjectTemplates.Global:CreateRandomChest(_jku5G,Goods.G_Gold,300,600)end
function AddOnInteractiveObjectTemplates.Global:CreateRandomResourceChest(MQ4GML)
local P0zam7l1={Goods.G_Iron,Goods.G_Stone,Goods.G_Wood,Goods.G_Wool,Goods.G_Carcass,Goods.G_Herb,Goods.G_Honeycomb,Goods.G_Milk,Goods.G_RawFish,Goods.G_Grain}local ql2oo8=P0zam7l1[math.random(1,#P0zam7l1)]
AddOnInteractiveObjectTemplates.Global:CreateRandomChest(MQ4GML,ql2oo8,30,60)end
function AddOnInteractiveObjectTemplates.Global:CreateRandomLuxuryChest(tMBbY)
local pkvjY={Goods.G_Salt,Goods.G_Dye}
if g_GameExtraNo>=1 then table.insert(pkvjY,Goods.G_Gems)
table.insert(pkvjY,Goods.G_MusicalInstrument)table.insert(pkvjY,Goods.G_Olibanum)end;local df_=pkvjY[math.random(1,#pkvjY)]
AddOnInteractiveObjectTemplates.Global:CreateRandomChest(tMBbY,df_,50,100)end
function AddOnInteractiveObjectTemplates.Global:CreateIOMine(V,Pc4c8hr,cacYZBAE,iP99wz,Ph,hz,OU)
local BCef=ReplaceEntity(V,Entities.XD_ScriptEntity)local wnxFi8r=Models.Doodads_D_SE_ResourceIron_Wrecked
if
Pc4c8hr==Entities.R_StoneMine then wnxFi8r=Models.R_SE_ResorceStone_10 end;Logic.SetVisible(BCef,true)
Logic.SetModel(BCef,wnxFi8r)local C,yqhFJ,b=Logic.EntityGetPos(BCef)
local NMud=Logic.CreateEntity(Entities.D_ME_Rock_Set01_B_07,C,yqhFJ,0,0)Logic.SetVisible(NMud,false)
CreateObject{Name=V,Title=self.Data.Mines.Description.Title,Text=self.Data.Mines.Description.Text,Type=Pc4c8hr,Special=iP99wz,Costs=cacYZBAE,InvisibleBlocker=NMud,Distance=1500,Condition=self.ConditionBuildIOMine,CustomCondition=Ph,ConditionUnfulfilled=self.Data.Mines.Description.Unfulfilled,CallbackCreate=hz,CallbackDepleted=OU,Callback=self.ActionBuildIOMine}end
function AddOnInteractiveObjectTemplates.Global:CreateIOIronMine(I,tI88,c0M,x8uysOHh,lH,Zn9Zq)
assert(IsExisting(I))
if tI88 then assert(API.TraverseTable(tI88,Goods))assert(
type(c0M)=="number")end
if x8uysOHh then
assert(API.TraverseTable(x8uysOHh,Goods))assert(type(lH)=="number")end
self:CreateIOMine(I,Entities.R_IronMine,{tI88,c0M,x8uysOHh,lH},Zn9Zq)end
function AddOnInteractiveObjectTemplates.Global:CreateIOStoneMine(AYeZcqm,NLk0,oYy,HMi,vuPf,fJ7)
assert(IsExisting(AYeZcqm))
if NLk0 then assert(API.TraverseTable(NLk0,Goods))assert(
type(oYy)=="number")end
if HMi then assert(API.TraverseTable(HMi,Goods))assert(
type(vuPf)=="number")end
self:CreateIOMine(AYeZcqm,Entities.R_StoneMine,{NLk0,oYy,HMi,vuPf},fJ7)end
function AddOnInteractiveObjectTemplates.Global.ConditionBuildIOMine(KRjdPd)
if
KRjdPd.CustomCondition then return KRjdPd.CustomCondition(KRjdPd)==true end;return true end
function AddOnInteractiveObjectTemplates.Global.ActionBuildIOMine(fGAB)
ReplaceEntity(fGAB.Name,fGAB.Type)DestroyEntity(fGAB.InvisibleBlocker)
if
type(fGAB.CallbackCreate)=="function"then fGAB.CallbackCreate(fGAB)end
Trigger.RequestTrigger(Events.LOGIC_EVENT_EVERY_SECOND,"","ControlIOMine",1,{},{fGAB.Name})end
function AddOnInteractiveObjectTemplates.Global.ControlIOMine(EWJD)if not IO[EWJD]then return
true end
if not IsExisting(EWJD)then return true end;local XKGS=GetID(EWJD)
if
Logic.GetResourceDoodadGoodAmount(XKGS)==0 then
if IO[EWJD].Special==true then
local URQlwQ2=Models.Doodads_D_SE_ResourceIron_Wrecked;if IO[EWJD].Type==Entities.R_StoneMine then
URQlwQ2=Models.R_ResorceStone_Scaffold_Destroyed end
XKGS=ReplaceEntity(XKGS,Entities.XD_ScriptEntity)Logic.SetVisible(XKGS,true)
Logic.SetModel(XKGS,URQlwQ2)end;if type(IO[EWJD].CallbackDepleted)=="function"then
IO[EWJD].CallbackDepleted(IO[EWJD])end;return true end end
function AddOnInteractiveObjectTemplates.Global:ConstructionSiteActivate()if
self.Data.ConstructionSiteActivated then return end
self.Data.ConstructionSiteActivated=true
Core:AppendFunction("GameCallback_OnBuildingConstructionComplete",self.OnConstructionComplete)end
function AddOnInteractiveObjectTemplates.Global.OnConstructionComplete(R7SOm84q,TfX)
local GTOqKxV1=AddOnInteractiveObjectTemplates.Global.Data.ConstructionSite.Sites[TfX]if GTOqKxV1 ~=nil and GTOqKxV1.CompletedCallback then
GTOqKxV1.CompletedCallback(GTOqKxV1,TfX)end end
function AddOnInteractiveObjectTemplates.Global:CreateIOBuildingSite(q5PNmzQ,boCZfoJv,wt7,Up,x3dIh,_oY,wYK3,fVu2Nr,MS7_Fv)
AddOnInteractiveObjectTemplates.Global:ConstructionSiteActivate()
local Fp=Up or{Logic.GetEntityTypeFullCost(wt7)}
local DC9=wYK3 or self.Data.ConstructionSite.Description.Title
local T0z=Text or self.Data.ConstructionSite.Description.Text;local UQ=GetID(q5PNmzQ)
Logic.SetModel(UQ,Models.Buildings_B_BuildingPlot_10x10)Logic.SetVisible(UQ,true)
CreateObject{Name=q5PNmzQ,Title=DC9,Text=T0z,Texture=_oY or{14,10},Distance=x3dIh or 1500,Type=wt7,Costs=Fp,Condition=AddOnInteractiveObjectTemplates.Global.ConditionConstructionSite,ConditionUnfulfilled=AddOnInteractiveObjectTemplates.Global.Data.ConstructionSite.Description.Unfulfilled,PlayerID=boCZfoJv,CompletedCallback=MS7_Fv,Callback=AddOnInteractiveObjectTemplates.Global.CallbackIOConstructionSite}end
function AddOnInteractiveObjectTemplates.Global.CallbackIOConstructionSite(NVV0x)
local Rz8=GetPosition(NVV0x.Name)local uj=GetID(NVV0x.Name)
local ta6=Logic.GetEntityOrientation(uj)
local Uet=Logic.CreateConstructionSite(Rz8.X,Rz8.Y,ta6,NVV0x.Type,NVV0x.PlayerID)Logic.SetVisible(uj,false)if(Uet==nil)then
API.Dbg('AddOnInteractiveObjectTemplates.Global:CreateIOBuildingSite: Failed to place construction site!')return end
AddOnInteractiveObjectTemplates.Global.Data.ConstructionSite.Sites[Uet]=NVV0x
StartSimpleJobEx(AddOnInteractiveObjectTemplates.Global.ControlConstructionSite,Uet)end
function AddOnInteractiveObjectTemplates.Global.ConditionConstructionSite(rPsZuYJD)
local I=GetID(rPsZuYJD.Name)local gdi1cA3e=GetTerritoryUnderEntity(I)
local wnfj0Vd=Logic.GetTerritoryPlayerID(gdi1cA3e)
if Logic.GetStoreHouse(rPsZuYJD.PlayerID)==0 then return false end;if rPsZuYJD.PlayerID~=wnfj0Vd then return false end;return true end
function AddOnInteractiveObjectTemplates.Global.ControlConstructionSite(Tuta)
if
AddOnInteractiveObjectTemplates.Global.Data.ConstructionSite.Sites[Tuta]==nil then return true end
if not IsExisting(Tuta)then
local Ehz1=AddOnInteractiveObjectTemplates.Global.Data.ConstructionSite.Sites[Tuta].Name;Logic.SetVisible(GetID(Ehz1),true)
API.InteractiveObjectActivate(Ehz1)return true end end
function AddOnInteractiveObjectTemplates.Local:Install()end
Core:RegisterAddOn("AddOnInteractiveObjectTemplates")